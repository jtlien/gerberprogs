
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"
//
// add X0Y0D02 at the first LPC or LPD line without a G04
//    return 0 if one is added, 99 if not
//
int add00_call_out(char *infilestr, char *outfilestr)
{
int FIRST;
char thisline[300];
int endoffile;
int nf;
FILE *file1;
FILE *outfile;

   FIRST =  0;

   file1=fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In add00, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"w");
   if (outfile==NULL)
   {
	   printf("In add00, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    fprintf(outfile,"%s",thisline);   // $0

    if( (FIRST == 0) && ((strstr(thisline,"LPD") != NULL) || 
		                 (strstr(thisline,"LPC") != NULL) ) 
				     &&  (strstr(thisline,"G04") == NULL) )  // first LPC or LPD line
					                                          // without a G04
    {
      fprintf(outfile,"X0Y0D02*\n");
      FIRST = 1;
    }

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
   }

   fclose(file1);

   fclose(outfile);

   if( FIRST == 1)
   {
     return(0);
   }
   else 
   {
     return(99);
   }

}  // end add00_call


int add00_call(char *infilestr)
{
int FIRST;
char thisline[300];
int endoffile;
int nf;
FILE *file1;

   FIRST =  0;

   file1=fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In add00, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    printf("%s",thisline);   // $0

    if( (FIRST == 0) && ((strstr(thisline,"LPD") != NULL) || 
		                 (strstr(thisline,"LPC") != NULL) ) 
				     &&  (strstr(thisline,"G04") == NULL) )  // first LPC or LPD line
					                                          // without a G04
    {
      printf("X0Y0D02*\n");
      FIRST = 1;
    }

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
   }

   fclose(file1);

   if( FIRST == 1)
   {
     return(0);
   }
   else 
   {
     return(99);
   }

}  // end add00_call

/*
int main( int argc, char **argv)
{
int retval;

	if (argc != 2)
	{
		printf("In add00, wrong number of arguments \n");
		printf("Usage:  add00 infile \n");
		exit(-1);
	}
    else
	{
		retval = add00_call( argv[1]);
		exit(retval);
	}

}  // end main
*/

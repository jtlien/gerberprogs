#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

struct tolerance_stuff
{
	char layer[100];
	char tolval[40];
} tolerance_array[1000];

int tolerance_count;

struct mytolerance_stuff
{
	char layer_type[100];
	char tolval[40];
} mytolerance_array[1000];

int mytolerance_count;


// add_tol.awk (tsa)
// this program add the tolerance value from the offsets file for the cd.txt file

// Rev 1 released to users on 2/4/03



void add_to_my_tol( char *indexstr, char *valstr)
{
	if ( mytolerance_count < 1000)
	{
		strncpy(mytolerance_array[mytolerance_count].layer_type,indexstr,120);
		strncpy(mytolerance_array[mytolerance_count].tolval,valstr,40);
		mytolerance_count += 1;

	}
   else
   {
	   printf("add_to_mytolerance, array sized exceeded \n");
   }

}  // end add_to_mytolerance


void add_to_tolerance( char *indexstr, char *valstr)
{
	if ( tolerance_count < 1000)
	{
		strncpy(tolerance_array[tolerance_count].layer,indexstr,120);
		strncpy(tolerance_array[tolerance_count].tolval,valstr,40);
		tolerance_count += 1;

	}
   else
   {
	   printf("add_to_tolerance, array sized exceeded \n");
   }

}  // end add_to_tolerance

// returns true or false depending if the given string is found
//  int mytolerance_array
//
int find_in_my_tol( char *layertypestr)
{
int jj;

 jj =0;
 while(jj < mytolerance_count)
 {

	 if (strcmp(layertypestr,mytolerance_array[jj].layer_type)==0)
	 {
		 return(TRUE);
	 }

	jj += 1;
 }

 return(FALSE);
}   // 

// returns true or false depending if the given string is found
//  int mytolerance_array
//
char *get_from_my_tol( char *layertypestr)
{
int jj;

 jj =0;
 while(jj < mytolerance_count)
 {

	 if (strcmp(layertypestr,mytolerance_array[jj].layer_type)==0)
	 {
		 return(mytolerance_array[jj].tolval);
	 }

	jj += 1;
 }

 return(NULL);
}   // 


char *get_tolerance( char *layerstr)
{
int ii;
int tolerance_found;
  ii = 0;
  tolerance_found=FALSE;

  while((ii < tolerance_count) && (tolerance_found== FALSE))
  {
    if (strcmp(tolerance_array[ii].layer,layerstr)==0)
	{
		return(tolerance_array[ii].tolval);
	}

    ii +=1;
  }

  return(NULL);

}  // end get_tolerance

char *set_tol(char *layer,char *type)
{
char *retptr;
char layerup[300];
int kk;
char myindex[300];

     strncpy(myindex,layer,120);
	// strncat(myindex," ",4);
	 //strncat(myindex,type,120);

	 
     if( ! ( find_in_my_tol(myindex)) )
	 {
		strncpy(layerup,layer,120);
		kk=0;
		while(kk < (signed int) strlen(layerup) )
		{
			layerup[kk]=toupper(layerup[kk]);
		     kk += 1;
		}

        retptr = get_tolerance(layerup);
        add_to_my_tol(myindex,"    reference");
     }
     else
	 {
        retptr = get_from_my_tol(myindex); 
     }
     return(retptr);
}

void add_tol2_call_out( char *infile1str, char *infile2str, char *outfilestr)
{
int endoffile;
int nf;
char thisline[300];
char tol_val[300];
char *tol1;
FILE *file1, *file2;
FILE *outfile;
char myindex[300];
char singlequote;

   singlequote = '\23';

   tolerance_count=0;
   mytolerance_count=0;

   file1=fopen(infile1str,"r");

   if (file1 == NULL)
   {
	   printf("In get_cd, unable to open the input file = %s \n",infile1str);
	   exit(-1);
   }

  file2=fopen(infile2str,"r");

   if (file2 == NULL)
   {
	   printf("In get_cd, unable to open the input file = %s \n",infile2str);
	   exit(-1);
   }

   outfile =fopen(outfilestr,"w");

   if (outfile == NULL)
   {
	   printf("In get_cd, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while( endoffile == FALSE)
   {
    
     subs("'","",str_array[0]);              // just like awk sub but without regex

     //myindex = toupper($1);

	 cv_toupper(str_array[0],myindex);

    // tol_val = ("+/-" $3)
	 strncpy(tol_val,"+/-",10);
	 strncat(tol_val,str_array[2],120);

     // tolerance[myindex] = tol_val
	 add_to_tolerance(myindex,tol_val);

	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

   }
      
   fclose(file1);

  endoffile=getline(file2,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {
      tol1 = set_tol(str_array[0],str_array[1]);
     fprintf(outfile,"%-7s %-7s %7s %9s %11s\n",str_array[0],str_array[1],str_array[2],
		                               str_array[3],tol1);
	endoffile=getline(file2,thisline);
	nf=split_line(thisline);
  }

 fclose(outfile);
 fclose(file2);

}  // end add_tol2_call_out


void add_tol2_call( char *infile1str, char *infile2str)
{
int endoffile;
int nf;
char thisline[300];
char tol_val[300];
char *tol1;
FILE *file1, *file2;
char myindex[300];
char singlequote;

   singlequote = '\23';

   tolerance_count=0;
   mytolerance_count=0;

   file1=fopen(infile1str,"r");

   if (file1 == NULL)
   {
	   printf("In get_tol2, unable to open the input file = %s \n",infile1str);
	   exit(-1);
   }

  file2=fopen(infile2str,"r");

   if (file2 == NULL)
   {
	   printf("In get_tol2, unable to open the input file = %s \n",infile2str);
	   exit(-1);
   }
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while( endoffile == FALSE)
   {
    
     //sub("'","",$1)

	 subs( "'","",str_array[0]); 

     //myindex = toupper($1);

	 cv_toupper(str_array[0], myindex);

    // tol_val = ("+/-" $3)
	 strncpy(tol_val,"+/-",10);
	 strncat(tol_val,str_array[2],120);

     // tolerance[myindex] = tol_val
	 add_to_tolerance(myindex,tol_val);

	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

   }
      
   fclose(file1);

  endoffile=getline(file2,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {
      tol1 = set_tol(str_array[0],str_array[1]);
     printf("%-7s %-7s %7s %9s %11s\n",str_array[0],str_array[1],str_array[2],
		                               str_array[3],tol1);
	endoffile=getline(file2,thisline);
	nf=split_line(thisline);
  }

 fclose(file2);

}  // end add_tol2_call

/*
int main( int argc, char **argv)
{

   if (argc != 3)
   {
	   printf("In add_tol, wrong number of arguments \n");
	   printf("Usage: add_tol infile1 infile2 \n");
	   printf("       infile1 is offsets file \n");
	   exit(-1);
   }
   else
   {
	   add_tol2_call(argv[1],argv[2]);
   }
}

*/





#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include "dirent.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAXSTRING 200

//
//  This program is used to fix up the gerber output so that it has 
//      a * at the end of every line.   Also changes the M00 at the
//      end of the file to M02.
//


char scan_array[1000][200];
char fromfilestr[300];
char tofilestr[300];
char fname[1000][200];

int file_count;
int i;

char newfname[200];


//
// get an input line
//
int readline( FILE *infile, char *tline)  // get a line of input
{
int count;

 count = fread(tline,1,240,infile);

 if (count != 240)
 {
   return(count);
 }
 else
 {
	return (0);
 }
} // end getline

// check if directory exists
//

int dir_exists( char *dirname)
{
DIR *dir;

	dir = opendir( dirname);
	if (dir == NULL)
	{
		return(0);
	}
	else
	{
		closedir( dir);
		return(1);
	}
}

void copy_one_file( char *infile, char *outfile)
{
char buf[1024];
FILE *f_from;
FILE *f_to;


    /* copy source file to target file, line by line. */

/* open the source and the target files. */
    f_from = fopen(infile, "r");
    if (!f_from) {
	fprintf(stderr, "Cannot open source file: %s",infile);
	perror("");
	exit(1);
    }

    f_to = fopen(outfile, "w+");
    if (!f_to) {
	fprintf(stderr, "Cannot open target file: %s ",outfile);
	perror("");
	exit(1);
    }

/* copy source file to target file, line by line. */

    while (fgets(buf, 512, f_from)) 
	{
	 if (fputs(buf, f_to) == EOF)
	 {  /* error writing data */
	    fprintf(stderr, "Error writing to target file: ");
	    perror("");
	    exit(1);
	 }
    }
   fclose(f_from);
   fclose(f_to);
	
}  // copy_one_file


void replace_ext( char *fromstr, char *tostr, char *extstr)
{
char tstr[400];

char *dotptr;
int ii;

  strncpy(tstr,fromstr,120);

  dotptr = strstr( tstr,".");

  if (dotptr != NULL)
  {
	ii=0;
	while( (extstr[ii] != 0 ) && ( ii < strlen(extstr)))
	{
		*dotptr= extstr[ii];
	//	printf("adding %c\n", extstr[ii]);
		dotptr++;
		ii++;
	}
    *dotptr=0;
	strncpy(tostr,tstr,120);

  }
  else
  {
	  
   printf("Internal error \n");
  }

}
//
//
//   Scan directory for regular files that match a particular extension
//
int scandir_matchext(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr)		// starting dir, could be an arbitrary label
{

	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	int ll;
	int kk;
	char fname_ext[MAXSTRING];
	int scan_file_count;

	
	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	sprintf(szDir, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	scan_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE)
	{ 
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return(-1);
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;
		
		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			sprintf(newdir,"%s/%s",dir,fname);

    			scandir_matchext(newdir,recurse,matchstr);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name 
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/

			 // get the ext ( all chars after first dot )

			kk=0;
			ll=0;
			fname_ext[0]=0;
			while((fname[kk] != '.') && (kk < strlen(fname)) )
			{
				kk += 1;
			}
			if ( fname[kk] == '.')
			{
				fname_ext[ll]=fname[kk];
				kk += 1;
				ll += 1;
			}
			while( kk < strlen(fname))
			{
				fname_ext[ll] = fname[kk];
				kk += 1;
				ll += 1;
			}
			fname_ext[ll] = 0;

			// printf("fname_ext = %s \n",fname_ext);

			if (strcmp(fname_ext,matchstr) == 0 )
			{
			// printf("fname = %s \n",fname);
			  if (scan_file_count < 1000 )
			  {
				 strncpy(scan_array[scan_file_count],fname,120);
				 scan_file_count += 1;
			  }
			  else
			  {
				  printf("Number of files in the directory exceeds 1000 \n");
			  }

			}

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return(scan_file_count);
}



// fix up a gerber file from PAR,  add a "*" at the end of each line and replace
//
void addeol_call( char *infilestr, char *outfilestr)
{

char thisline[240];
FILE *file1;
FILE *file2;

int endoffile;
char holdline[200];
char holdline2[200];
char tempstr[200];
char outline[400];
char prevoutline[400];

int ii;
int jj;

    file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	}

    file2  = fopen(outfilestr, "w");

    if (file2 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",outfilestr);
	  exit(-1);
	}

	strncpy(prevoutline,"",4);

    endoffile = readline(file1, thisline);

	jj=0;
    while( endoffile == 0 )  // do a full buffer
	{	  
	 ii=0;
     
     while(  ( jj < 120) && (ii < 240) )
	 {
			 outline[jj] = thisline[ii];
			// printf("ii = %d jj = %d outline char = %c \n",ii,jj,thisline[ii]);

             if ( thisline[ii] == '*')
			 {
		      outline[jj+1]= 0;
		     // printf("outline = %s \n",outline);
              if ( (strstr(prevoutline,"X0Y0D02") != NULL) &&
				   (strstr(outline,"M00") != NULL))
			  {
				  outline[2]='2';
			  }
		      fprintf(file2,"%s\n",outline);
              strncpy(prevoutline,outline,200);

		      jj=0;
			 }
			 else
			 {
			  jj += 1;
			 }
		  ii += 1;
	 }
   
	 endoffile = readline(file1, thisline);

	}  // end while

   fclose(file1);
   ii=0;
     
     while(  ( jj < 120) && (ii < endoffile) ) // do what's left
	 {
			 outline[jj] = thisline[ii];
		//	 printf("ii = %d jj = %d outline char = %c \n",ii,jj,thisline[ii]);

             if ( thisline[ii] == '*')
			 {
		      outline[jj+1]= 0;
            //  printf("prevoutline = %s outline=%s\n",prevoutline,outline);
              if ( (strstr(prevoutline,"X0Y0D02") != NULL) &&
				   (strstr(outline,"M00") != NULL))
			  {
				  outline[2]='2';
			  }
		      fprintf(file2,"%s\n",outline);
              strncpy(prevoutline,outline,200);

		      jj=0;
			 }
			 else
			 {
			  jj += 1;
			 }
		  ii += 1;
	 }
   
   
   fclose(file2);


} // end main

// first parameter is a directory
//   find all the files in the directory that end with .gbr
//   and run addstar on them and put the results into .gbrf

int main( int argc, char **argv)
{


 if (dir_exists( argv[1]) )  // check if the directory exists
	{

	 file_count = scandir_matchext(argv[1],0,".gbr");  // get all .gbr files

	 // printf("file count = %d \n", file_count);

	 for(i=0; i < file_count; i += 1)
	 {
	  

	   replace_ext( scan_array[i], newfname,".gbro");

	   strncpy(fromfilestr,argv[1],120);
	   strncat(fromfilestr,"\\",5);
	   strncat(fromfilestr,scan_array[i],120);

      // printf("test i = %d \n",i);

	   strncpy(tofilestr,argv[1],120);
	   strncat(tofilestr,"\\",5);
       strncat(tofilestr,newfname,120);

	   copy_one_file( fromfilestr,tofilestr);

	   unlink(fromfilestr);

       addeol_call( tofilestr,fromfilestr);  // update the original

	 }

 }
 else
 {
	 printf("In addeolall, unable to open the directory = %s \n",argv[1]);
	 exit(-1);

 }

}

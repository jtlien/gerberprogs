#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//
//  This program is used to fix up the gerber output so that it has 
//      a * at the end of every line.   Also changes the M00 at the
//      end of the file to M02.
//


int ii;
char thisline[240];
FILE *file1;
FILE *file2;

int endoffile;
char holdline[200];
char holdline2[200];
char tempstr[200];


//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,240,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

int main( int argc, char  **argv)
{

	if (argc != 3)
	{
		printf("Usage: addstar infile outfile \n");
	    printf("   example: addstar nostar.gbr good.gbr\n");
		exit(-1);
	}

    file1  = fopen(argv[1], "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",argv[1]);
	  exit(-1);
	}

    file2  = fopen(argv[2], "w");

    if (file2 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",argv[2]);
	  exit(-1);
	}

    endoffile = getline(file1, thisline);

    while( endoffile == FALSE)
	{
	  
	 strncpy(tempstr,thisline,200);

	 if (thisline[0] != '%')   // not a percent line
	 {
	  if ( strstr(thisline,"G04") == NULL)  // not a comment line
	   {
	    thisline[strlen(tempstr)-1] = '*';
	    thisline[strlen(tempstr)] ='\n';
	    thisline[strlen(tempstr)+1] =0;
	   }
	 }

     if (strstr(thisline,"X0Y0D") != NULL)    // end of file artifacts
	 {
	   strncpy(holdline,thisline,200);

	   endoffile = getline(file1,thisline);
	   strncpy(tempstr,thisline,200);

       thisline[strlen(tempstr)-1] = '*';
	   thisline[strlen(tempstr)] ='\n';
	   thisline[strlen(tempstr)+1] =0;
        strncpy(holdline2,thisline,200);
	   if (strstr(thisline,"M00") != NULL)
	   {

		 strncpy(holdline2,thisline,200);
		 endoffile=getline(file1,thisline);
		 if (endoffile == TRUE)              // X0Y0D followed by M00,then eof print M02
		 {
			 fprintf(file2,"M02*\n");
		 }
		 else   // X0Y0D followd by M00 but not end of file
		 {

			fprintf(file2,"%s",holdline);
			fprintf(file2,"%s",holdline2);
		 }
	   }
	  else   // next line not X0Y0D not followed by M00
	  {
		  fprintf(file2,"%s",holdline);
	  }
     }

	 if (endoffile == FALSE) { fprintf( file2,"%s",thisline); }
	 endoffile = getline(file1, thisline);

	}  // end while

   fclose(file1);
   fclose(file2);


} // end main

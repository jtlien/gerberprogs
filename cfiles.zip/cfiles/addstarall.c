#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include "dirent.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//
//  This program is used to fix up the gerber output so that it has 
//      a * at the end of every line.   Also changes the M00 at the
//      end of the file to M02.
//




// fix up a gerber file from PAR,  add a "*" at the end of each line and replace
//
void addstar_call( char *infilestr, char *outfilestr)
{

char thisline[240];
FILE *file1;
FILE *file2;
int endoffile;
char holdline[200];
char holdline2[200];
char tempstr[200];


    file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	}

    file2  = fopen(outfilestr, "w");

    if (file2 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",outfilestr);
	  exit(-1);
	}

    endoffile = getline(file1, thisline);

    while( endoffile == FALSE)
	{
	  
	 strncpy(tempstr,thisline,200);

	 if (thisline[0] != '%')
	 {
	   if ( strstr(thisline,"G04") == NULL)
	   {
	    thisline[strlen(tempstr)-1] = '*';
	    thisline[strlen(tempstr)] ='\n';
	    thisline[strlen(tempstr)+1] =0;
	   }
	 }

     if (strstr(thisline,"X0Y0D") != NULL)    // end of file artifacts
	 {
	   strncpy(holdline,thisline,200);

	   endoffile = getline(file1,thisline);
	   strncpy(tempstr,thisline,200);

       thisline[strlen(tempstr)-1] = '*';
	   thisline[strlen(tempstr)] ='\n';
	   thisline[strlen(tempstr)+1] =0;
        strncpy(holdline2,thisline,200);
	   if (strstr(thisline,"M00") != NULL)
	   {

		 strncpy(holdline2,thisline,200);
		 endoffile=getline(file1,thisline);
		 if (endoffile == TRUE)              // X0Y0D followed by M00,then eof print M02
		 {
			 fprintf(file2,"M02*\n");
		 }
		 else   // X0Y0D followd by M00 but not end of file
		 {

			fprintf(file2,"%s",holdline);
			fprintf(file2,"%s",holdline2);
		 }
	   }
	  else   // next line not X0Y0D not followed by M00
	  {
		  fprintf(file2,"%s",holdline);
	  }
     }

	 if (endoffile == FALSE) { fprintf( file2,"%s",thisline); }
	 endoffile = getline(file1, thisline);

	}  // end while

   fclose(file1);
   fclose(file2);


} // end main

// first parameter is a directory
//   find all the files in the directory that end with .gbr
//   and run addstar on them and put the results into .gbrf

int main( int argc, char **argv)
{
int i;
char fromfilestr[300];
char tofilestr[300];
int file_count;
char newfname[300];

 if (argc != 2)
	{
	 printf("addstarall called with wrong number of arguments \n");
	 printf("Usage: addstarall  dirname \n");
	 printf("      dirname is the name of the directory \n");
	 exit(-1);
	}

 if (dir_exists( argv[1]) )  // check if the directory exists
	{

	 file_count = scandir_matchext(argv[1],0,".gbr");  // get all .gbr files

	 // printf("file count = %d \n", file_count);

	 for(i=0; i < file_count; i += 1)
	 {
	   // printf("test i = %d \n",i);

	   replace_ext( scan_array[i], newfname,".gbro");

	   strncpy(fromfilestr,argv[1],120);
	   strncat(fromfilestr,"\\",3);
	   strncat(fromfilestr,scan_array[i],120);

      // printf("test i = %d \n",i);

	   strncpy(tofilestr,argv[1],120);
	   strncat(tofilestr,"\\",3);
       strncat(tofilestr,newfname,120);

	  // printf(" i = %d fromfilestr = %s tofilestr = %s \n", i,fromfilestr, tofilestr);


	   cp_file( fromfilestr,tofilestr);

	   unlink(fromfilestr);

	   
       addstar_call( tofilestr,fromfilestr);  // update the original

	 }

 }
 else
 {
	 printf("In addstarall, unable to open the director = %s \n",argv[1]);
	 exit(-1);

 }

}

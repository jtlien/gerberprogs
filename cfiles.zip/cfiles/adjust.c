#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <process.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

#include "utilprogs.h"

// The above line allows this awk script to be executable

//  adjust  rev 1.0  8/14/95
//  written by Ted Ammann
//
//  The purpose of this program is to modify an existing Gerber
//  aperture file. The program adds the user input value (command line)
//  to the appropriate dimensions.  The dimension to add to is determined by
//  structure type (CIRCLE,LINE,SQUARE).
//  
//  Calling syntax is 
//   adjust myfile myval > myout
//    where:
//            myfile = aperture file to process
//            myval  = user adjustment value
//            myout  = output file

void adjust_call_out(char *infilestr, char *adjustvalstr, char *outfilestr)
{
 FILE *file1;
 FILE *outfile;

 int endoffile;
 double value;
 double value1;
 double value2;
 int nf;
 char thisline[300];
 double add_val;

      // The adjustment value from the command line is the
      // command line array called ARGV (see manual for info on ARGV 
      // and ARGC) and is stored in element 2

      add_val = atof( adjustvalstr); //  ARGV[2]


//***** START OF MAIN ********** 

   file1 = fopen(infilestr,"r");
   if (file1 == NULL)
   {
	   printf("In adjust, unable to open the input file = %s \n", infilestr);
	   exit(-1);
   }

   outfile = fopen(outfilestr,"w");
   if (outfile == NULL)
   {
	   printf("In adjust, unable to open the output file = %s \n", outfilestr);
	   exit(-1);
   }

   endoffile = getline(file1,thisline);
   nf=split_line(thisline);

  while(endoffile==FALSE)
  {
   // CIRCLE and LINE have the same format so we can handle them
   // together. Field #2 ($2) is the dimension to adjust and add_val
   // is the command line input parameter.   
   if ( (strstr(str_array[0],"CIRCLE") != NULL) ||
	    (strstr(str_array[0],"LINE") != NULL) )    
   {
       value = atof(str_array[1]) + add_val;   // $2 + add_val

       fprintf(outfile,"%-10s%10f%15s\n",str_array[0],value,str_array[2]);
   }
   else if ( strstr(str_array[0],"SQUARE") != NULL)   // 
   {
       value = atof(str_array[1]) + add_val;     //adjust field #2 for SQUARES
       fprintf(outfile,"%-10s%10f%10s%15s\n",str_array[0],value,str_array[2],str_array[3]);
   }
   else if ( (strstr(str_array[0],"RECTANGLE") != NULL) ||
	         (strstr(str_array[0],"OBLONG") != NULL) )    
   {
       value1 = atof(str_array[1]) + add_val;   // Adjust fields 2 and 3 for rectangles
       value2 = atof(str_array[2]) + add_val;
       fprintf(outfile,"%-10s%10f%10f%10s%5s\n",str_array[0],value1,value2,str_array[3],str_array[4]);
   }
   else 
   {
      fprintf(outfile,"%s",thisline); //  output all other lines.
   }

   endoffile = getline(file1,thisline);
   nf=split_line(thisline);

  } 

  fclose(file1);
  fclose(outfile);

} // end adjust_call_out


void adjust_call(char *infilestr, char *adjustvalstr)
{
 FILE *file1;
 int endoffile;
 double value;
 double value1;
 double value2;
 int nf;
 char thisline[300];
 double add_val;

      // The adjustment value from the command line is the
      // command line array called ARGV (see manual for info on ARGV 
      // and ARGC) and is stored in element 2

      add_val = atof( adjustvalstr); //  ARGV[2]


//***** START OF MAIN ********** 

   file1 = fopen(infilestr,"r");
   if (file1 == NULL)
   {
	   printf("In adjust, unable to open the input file = %s \n", infilestr);
	   exit(-1);
   }

   endoffile = getline(file1,thisline);
   nf=split_line(thisline);

  while(endoffile==FALSE)
  {
   // CIRCLE and LINE have the same format so we can handle them
   // together. Field #2 ($2) is the dimension to adjust and add_val
   // is the command line input parameter.   
   if ( (strstr(str_array[0],"CIRCLE") != NULL) ||
	    (strstr(str_array[0],"LINE") != NULL) )    
   {
       value = atof(str_array[1]) + add_val;   // $2 + add_val

       printf("%-10s%10f%15s\n",str_array[0],value,str_array[2]);
   }
   else if ( strstr(str_array[0],"SQUARE") != NULL)   // 
   {
       value = atof(str_array[1]) + add_val;     //adjust field #2 for SQUARES
       printf("%-10s%10f%10s%15s\n",str_array[0],value,str_array[2],str_array[3]);
   }
   else if ( (strstr(str_array[0],"RECTANGLE") != NULL) ||
	         (strstr(str_array[0],"OBLONG") != NULL) )    
   {
       value1 = atof(str_array[1]) + add_val;   // Adjust fields 2 and 3 for rectangles
       value2 = atof(str_array[2]) + add_val;
       printf("%-10s%10f%10f%10s%5s\n",str_array[0],value1,value2,str_array[3],str_array[4]);
   }
   else 
   {
      printf("%s",thisline); //  output all other lines.
   }

   endoffile = getline(file1,thisline);
   nf=split_line(thisline);

  } 

  fclose(file1);

} // end adjust_call

int main( int argc, char **argv)
{

	if (argc != 3)
	{
		printf("In adjust, wrong number of arguments \n");
		printf("Usage:   adjust myfile myval  \n");
		exit(-1);
	}
	else
	{
		adjust_call(argv[1], argv[2]);
	}

}  // end main
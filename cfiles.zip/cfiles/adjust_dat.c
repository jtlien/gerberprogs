#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void adjust_dat_call_out( char *infilestr, char *outfilestr)
{
char thisline[200];
int endoffile;
FILE *file1;
FILE *outfile;
int number_fields;   
	
   file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	}
	
    outfile = fopen(outfilestr, "w");

    if (outfile == NULL)
	{
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
	}

	endoffile=getline(file1, thisline);

    fprintf(outfile,"dimensions in millimeters\n");

	endoffile = getline(file1, thisline);
	number_fields = split_line( thisline);

    while( endoffile == FALSE)
	{
	  if ( number_fields == 8)
	  {
        fprintf(outfile,"%10.4f %10.4f %5d",atof(str_array[0])/1000,
		                         atof(str_array[1])/1000,
								  atoi(str_array[2]));

        fprintf(outfile," %3s %5s %5s %20s",str_array[3],str_array[4], str_array[5], 
			                                str_array[6]);

        if( atoi(str_array[7] ) == -1)
		{
          fprintf(outfile," %10.0f\n",atof(str_array[7]) );
		}
        else
		{
         fprintf(outfile," %10.4f\n",atof(str_array[7])/1000);
		}

	    endoffile = getline(file1, thisline);
        number_fields = split_line( thisline);
	  }
	 else
	 {
		 printf("Error: expected 8 fields in line , line = %s \n", thisline);
	     exit(-1);
	 }


	} // end while

	fclose(file1);
	fclose(outfile);


} // end adjust_dat_call_out

void adjust_dat_call( char *infilestr)
{
char thisline[200];
int endoffile;
FILE *file1;
int number_fields;   
	
   file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	}

	endoffile=getline(file1, thisline);

    printf("dimensions in millimeters\n");

	endoffile = getline(file1, thisline);
	number_fields = split_line( thisline);

    while( endoffile == FALSE)
	{
	  if ( number_fields == 8)
	  {
        printf("%10.4f %10.4f %5d",atof(str_array[0])/1000,
		                         atof(str_array[1])/1000,
								  atoi(str_array[2]));

        printf(" %3s %5s %5s %20s",str_array[3],str_array[4], str_array[5], str_array[6]);

        if( atoi(str_array[7] ) == -1)
		{
          printf(" %10.0f\n",atof(str_array[7]) );
		}
        else
		{
         printf(" %10.4f\n",atof(str_array[7])/1000);
		}

	    endoffile = getline(file1, thisline);
        number_fields = split_line( thisline);
	  }
	 else
	 {
		 printf("Error: expected 8 fields in line , line = %s \n", thisline);
	     exit(-1);
	 }


	} // end while

	fclose(file1);


} // end adjust_dat_call

/*
int main( int argc, char **argv)
{

	if (argc != 2)
	{
		printf("In adjust_dat, wrong number of arguments \n");
		printf("Usage: adjust_dat  fname\n");
		exit(-1);
	}
    else
	{
		adjust_dat_call(argv[1]);
	}


}  // end main
*/




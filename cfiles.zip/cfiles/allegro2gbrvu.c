#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define WINDOWS 1

#include "utilprogs.h"



void allegro2gbrvu_call_out( char *scalestr, char *infilestr, char *outfilestr)
{
int endoffile;
char thisline[300];
FILE *file1;
FILE *outfile;
int nf;
char dcode[120];
char size[120];
char type[120];
char shape[200];
double size_val;
double scale;
double wid;
double hgt;


  file1= fopen(infilestr,"r");
  if (file1 == NULL)
  {
	  printf("In allegro2gbrvu, unable to open the input file = %s \n", infilestr);
	  exit(-1);
  }

  outfile = fopen(outfilestr,"w");
  if (outfile == NULL)
  {
	  printf("In allegro2gbrvu, unable to open the output file = %s \n", outfilestr);
	  exit(-1);
  }


  fprintf(outfile,"APTUNITS mm\n");
  fprintf(outfile,"ARCRES 9.0000\n");
  fprintf(outfile,"CIRCULAR off\n");
  if (WINDOWS)
  {
   fprintf(outfile,"FONT C:\\WCAD\\asm500\\simplex.shx\n");
   fprintf(outfile,"FONTDIR C:\\WCAD\\asm500\n");
  }
  else
  {
   fprintf(outfile,"FONT /usr/local/cad_util/asm500/simplex.shx\n");
   fprintf(outfile,"FONTDIR /usr/local/cad_util/asm500/\n");
  }
  fprintf(outfile,"FORMAT 5.4\n");
  fprintf(outfile,"LINE d10\n");
  fprintf(outfile,"MSCALE 1.0\n");
  fprintf(outfile,"START_APT d10\n");
  fprintf(outfile,"OUTLINE off\n");
  fprintf(outfile,"GBR_END M02\n");
  fprintf(outfile,"ABSOLUTE on\n");
  fprintf(outfile,"CIRANG 360\n");
  fprintf(outfile,"FLASH on\n");
  fprintf(outfile,"TRACE off\n");
  fprintf(outfile,"PEND 0\n");
  fprintf(outfile,"OFFSET0 0.0 0.0\n");

// scale = 1

 
  scale=atof(scalestr);

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

 while(endoffile==FALSE)
 {
  strncpy(type,"n",4);
  if(strcmp(str_array[0],"LINE") == 0 )   
  {                                          // 
    //dcode=$3

	strncpy(dcode,str_array[2],120);
    size_val=atof(str_array[1])*scale;
	sprintf(size,"%f",size_val);
    strncpy(type,"d",5);
    strncpy(shape,"Round",20);
    wid=atof(str_array[1]) * scale;
    hgt=atof(str_array[1]) * scale;
  } 
  if(strcmp(str_array[0],"CIRCLE") == 0 )      // 
  {
    //dcode=$3
	strncpy(dcode,str_array[2],120);
    strncpy(size,"Cx",5);
    strncpy(type,"f",5);
    strncpy(shape,"Round",20);
    wid=atof(str_array[1]) * scale;
    hgt=atof(str_array[1]) * scale;
  } 
  if(strcmp(str_array[0],"SQUARE") == 0 )
  {
    //dcode=$4
	strncpy(dcode,str_array[3],120);
    strncpy(size,"Sx",5);
    strncpy(type,"f",5);
    strncpy(shape,"Square",20);
	wid=atof(str_array[1]) * scale;
    hgt=atof(str_array[1]) * scale;
  } 
  if(strcmp(str_array[0],"RECTANGLE") == 0 )
  {
   // dcode=$5
	strncpy(dcode,str_array[4],120);
    strncpy(size,"Rx",5);
    strncpy(type,"f",5);
    strncpy(shape,"Rect",20);
	wid=atof(str_array[1]) * scale;
    hgt=atof(str_array[2]) * scale;
  } 
  if (strcmp(str_array[0],"OBLONG") == 0 )
  {
    // dcode=$5
    strncpy(dcode,str_array[4],120);
    strncpy(size,"Ox",5);
    strncpy(type,"f",5);
    strncpy(shape,"Oblong",15);
	wid=atof(str_array[1]) * scale;
    hgt=atof(str_array[2]) * scale;
  } 
  
  
  if (strcmp(type,"d") ==0)
    fprintf(outfile,"%s %f %s %s %f %f\n",  dcode, size_val, type, shape, wid, hgt);
  else if (strcmp(type,"f") == 0 )
    fprintf(outfile,"%s %s%s %s %s %f %f\n", dcode, size, dcode, type, shape, wid, hgt);

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
 }

 fclose(file1);
 fclose(outfile);


}  // end allegro2gbrvu_call_out

void allegro2gbrvu_call( char *scalestr, char *infilestr)
{
int endoffile;
char thisline[300];
FILE *file1;
int nf;
char dcode[120];
char size[120];
char type[120];
char shape[200];
double size_val;
double scale;
double wid;
double hgt;

  printf("APTUNITS mm\n");
  printf("ARCRES 9.0000\n");
  printf("CIRCULAR off\n");
  if (WINDOWS)
  {
   printf("FONT C:\\WCAD\\asm500\\simplex.shx\n");
   printf("FONTDIR C:\\WCAD\\asm500\n");
  }
  else
  {
   printf("FONT /usr/local/cad_util/asm500/simplex.shx\n");
   printf("FONTDIR /usr/local/cad_util/asm500/\n");
  }
  
  printf("FORMAT 5.4\n");
  printf("LINE d10\n");
  printf("MSCALE 1.0\n");
  printf("START_APT d10\n");
  printf("OUTLINE off\n");
  printf("GBR_END M02\n");
  printf("ABSOLUTE on\n");
  printf("CIRANG 360\n");
  printf("FLASH on\n");
  printf("TRACE off\n");
  printf("PEND 0\n");
  printf("OFFSET0 0.0 0.0\n");

// scale = 1

  file1= fopen(infilestr,"r");
  if (file1 == NULL)
  {
	  printf("In allegro2gbrvu, unable to open the input file = %s \n", infilestr);
	  exit(-1);
  }

  scale=atof(scalestr);

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

 while(endoffile==FALSE)
 {
  strncpy(type,"n",4);
  if(strcmp(str_array[0],"LINE") == 0 )   
  {                                          // 
    //dcode=$3

	strncpy(dcode,str_array[2],120);
    size_val=atof(str_array[1])*scale;
	sprintf(size,"%f",size_val);
    strncpy(type,"d",5);
    strncpy(shape,"Round",20);
    wid=atof(str_array[1]) * scale;
    hgt=atof(str_array[1]) * scale;
  } 
  if(strcmp(str_array[0],"CIRCLE") == 0 )      // 
  {
    //dcode=$3
	strncpy(dcode,str_array[2],120);
    strncpy(size,"Cx",5);
    strncpy(type,"f",5);
    strncpy(shape,"Round",20);
    wid=atof(str_array[1]) * scale;
    hgt=atof(str_array[1]) * scale;
  } 
  if(strcmp(str_array[0],"SQUARE") == 0 )
  {
    //dcode=$4
	strncpy(dcode,str_array[3],120);
    strncpy(size,"Sx",5);
    strncpy(type,"f",5);
    strncpy(shape,"Square",20);
	wid=atof(str_array[1]) * scale;
    hgt=atof(str_array[1]) * scale;
  } 
  if(strcmp(str_array[0],"RECTANGLE") == 0 )
  {
   // dcode=$5
	strncpy(dcode,str_array[4],120);
    strncpy(size,"Rx",5);
    strncpy(type,"f",5);
    strncpy(shape,"Rect",20);
	wid=atof(str_array[1]) * scale;
    hgt=atof(str_array[2]) * scale;
  } 
  if (strcmp(str_array[0],"OBLONG") == 0 )
  {
    // dcode=$5
    strncpy(dcode,str_array[4],120);
    strncpy(size,"Ox",5);
    strncpy(type,"f",5);
    strncpy(shape,"Oblong",15);
	wid=atof(str_array[1]) * scale;
    hgt=atof(str_array[2]) * scale;
  } 
  
  
  if (strcmp(type,"d") ==0)
    printf("%s %f %s %s %f %f\n",  dcode, size_val, type, shape, wid, hgt);
  else if (strcmp(type,"f") == 0 )
    printf("%s %s%s %s %s %f %f\n", dcode, size, dcode, type, shape, wid, hgt);

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
 }

 fclose(file1);

}  // end allegro2gbrvu_call



int main(int argc, char **argv)
{

 if (argc != 3)
	{

	  printf("In allegro2gbrvu, wrong number of arguments \n");
	  printf("Usage:  allegro2gbrvu  scale_val infile \n");
	  exit(-1);
	}
  else
  {
	  allegro2gbrvu_call( argv[1], argv[2]);
  }

}  // end main
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// these are the values that need to be set 

#define WW 10
#define HH 10
#define XDLR 30
#define XDLC 40
#define XSLR 30
#define XSLC 40

double data[1000][1000];

void analyze_call( char *infilestr)
{
int i,j;
int cell;
int rr;
int cc;
double matrix_limit_x;
double matrix_limit_y;
double xdlr;
double xdlc;
double xdur;
double xduc;
double xslr;
double xslc;
double xsur;
double xsuc;
double x;
double y;
FILE *file1;
double die;
double total_die;
double non_stiffener;
double total_stiffener;
double total_non_stiffener;
double stiffener;
double metal;
double total_metal;
double matrix_step;
double pta;
double pnsa;
double psa;
double pda;
int endoffile;
int nf;
char thisline[300];

  cell = 1;
  rr   = 1;

  matrix_limit_x = WW;
  matrix_limit_y = HH;

// MAKE CHANGES HERE FOR YOUR PART
// Change these numbers to equal the corners of the die

  xdlr = -XDLR;
  xdlc = -XDLC;
  xdur = +XDLR;
  xduc = +XDLC;

// Change these numbers to equal the corners of the stiffener opening
  xslr = -XSLR;
  xslc = -XSLC;
  xsur = +XSLR;
  xsuc = +XSLC;

// END OF CHANGE-ABLE SECTION

  die = 0;
  total_die = 0;
  non_stiffener = 0;
  total_non_stiffener = 0;
  metal = 0;
  total_metal = 0;

  file1=fopen(infilestr,"r");
  if (file1==NULL)
  {
    printf("Unable to open the input file = %s \n",infilestr);
	exit(-1);
  }

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {
   for (i = 0; i < nf; i++) 
   {
    data[rr][i] = atof(str_array[i] ); // $i
   }
   rr++;
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);
  }
  fclose(file1);

  matrix_step = matrix_limit_x/nf;

  cc = i  - 1;
  rr = rr - 1;
  if ((cc != matrix_limit_x/matrix_step) || (rr != matrix_limit_y/matrix_step))
  {
    printf("ERROR [%d] -----------------------------------------------\n", nf);
  }

  else 
  {

    for (j = 1; j <= rr; j++) 
	{
      for (i = 1; i <= cc; i++) 
	  { 
     
        x = -matrix_limit_x/2+matrix_step*i;
        y = -matrix_limit_y/2+matrix_step*j;

        metal = metal + data[j][i];
        total_metal  = total_metal + matrix_step*matrix_step;

        if ((x >= xdlc) && (x <= xduc) && (y >= xdlr) && (y <= xdur)) 
		{
          die = die + data[j][i];
          total_die = total_die + matrix_step*matrix_step;
        }

        if ((x >= xslc) && (x <= xsuc) && (y >= xslr) && (y <= xsur)) 
		{
          non_stiffener = non_stiffener + data[j][i];
          total_non_stiffener = total_non_stiffener + matrix_step*matrix_step;
        }

      }
    }

    stiffener = metal - non_stiffener;
    total_stiffener = total_metal - total_non_stiffener;

    pta  = 100*(metal/total_metal);
    pnsa = 100*(non_stiffener/total_non_stiffener);
    psa  = 100*(stiffener/total_stiffener);
    pda  = 100*(die/total_die);

    printf("total area         = %10.4f mm^2  <out of> %10.4f mm^2 (%5.1f%)\n", 
		metal, total_metal, pta);
    printf("stiffener area     = %10.4f mm^2  <out of> %10.4f mm^2 (%5.1f%)\n",
 	    stiffener, total_stiffener, psa);
    printf("non stiffener area = %10.4f mm^2  <out of> %10.4f mm^2 (%5.1f%)\n",
	    non_stiffener, total_non_stiffener, pnsa);
    printf("die area           = %10.4f mm^2  <out of> %10.4f mm^2 (%5.1f%)\n", 
	      die, total_die, pda);

  }
}

int main( int argc, char **argv)
{

	if (argc != 2)
	{
		printf("In analyze, wrong number of arguments \n");
		printf("Usage: analyze infile \n");
		exit(-1);
	}
   else
   {
	   analyze_call( argv[1]);
   }

}  // end main


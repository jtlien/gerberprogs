#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

struct aptstuff
{
 char dcode[10];
 char name[30];
 char ftype[4];
 char shape[30];
 double xval;
 double yval;

} aper_array[1000], aper2_array[1000];

int aper_count;

// compare two aperture entries
//

int compare_apts( struct aptstuff apt1, struct aptstuff apt2)
{
 if ( strcmp( apt1.ftype, apt2.ftype) == 0 )
   {
     if (strcmp( apt1.shape, apt2.shape)==0 )
       {
         if (( apt1.xval == apt2.xval) && ( apt1.yval == apt2.yval))
          {
            return(TRUE);
          }
      }
  }

 return(FALSE);
}

// see if the apt is in the the aper_array
//
//
int find_in_apts( struct aptstuff aptin)
{
int ii;

 ii=0;
 while( ii < aper_count)
 {
	if (compare_apts( aptin, aper_array[ii]) )
	{
		return(ii);
	}

 ii += 1;
 }
 return(-1);

}

void apt_diff_call( char *infile1str, char *infile2str)
{
FILE *file1, *file2;
FILE *renamefile;
FILE *newfile;
int aptindex;

int endoffile;
int nf;
char thisline[300];
struct aptstuff thisapt;

  file1 = fopen( infile1str,"r");
  if (file1==NULL)
  {
    printf("Unable to open the input file = %s \n",infile1str);
	exit(-1);
  }

  aper_count=0;

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {

	if (nf==6)
	{
 
     strncpy(thisapt.dcode, str_array[0],10);
     strncpy(thisapt.name,str_array[1],30);
     strncpy(thisapt.ftype,str_array[2],3);
     strncpy(thisapt.shape,str_array[3],20);
     thisapt.xval= atof(str_array[4]);
     thisapt.yval= atof(str_array[5]);

	 if ( aper_count < 1000 )
	 {
		 aper_array[aper_count]= thisapt;
		 aper_count += 1;
	 }

	}


  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
  }

 fclose(file1);

  file2 = fopen( infile2str,"r");
  if (file2==NULL)
  {
    printf("Unable to open the input file = %s \n",infile2str);
	exit(-1);
  }

  renamefile= fopen("rename.apt","w");
  if (renamefile==NULL)
  {
	  printf("Unable to open the output file rename.apt \n");
	  exit(-1);
  }
  newfile= fopen("new.apt","w");
  if (newfile==NULL)
  {
	  printf("Unable to open the output file new.apt \n");
	  exit(-1);
  }
  endoffile=getline(file2,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {

	if (nf==6)
	{
 
     strncpy(thisapt.dcode, str_array[0],10);
     strncpy(thisapt.name,str_array[1],30);
     strncpy(thisapt.ftype,str_array[2],3);
     strncpy(thisapt.shape,str_array[3],20);
     thisapt.xval= atof(str_array[4]);
     thisapt.yval= atof(str_array[5]);

	 aptindex = find_in_apts( thisapt) ;

	 
	 if (aptindex != -1)  // an apt found in the first file
	 {
       fprintf(renamefile,"%s %s \n",thisapt.dcode,aper_array[aptindex].dcode);

	 }
	 else   // new apt not in first file apts
	 {
       fprintf(newfile,"%s %s %s %s %0.0f %0.0f \n",
		   str_array[0],str_array[1],str_array[2], str_array[3],
		   thisapt.xval, thisapt.yval);
	 }

    }

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
  }

 fclose(file1);

 fclose(newfile);
 fclose(renamefile);

  } // end apt_diff_call


int main( int argc, char **argv)
{
	if (argc != 3)
	{
		printf("In aptdiff, wrong number of arguments \n");
		printf("Usage: aptdiff infile1 infile2 \n");
		exit(-1);
	}
	else
	{
		apt_diff_call( argv[1], argv[2] );

	}

} // end main

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

int CODE;

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// Rev 1
// Title: AptINtoMM (Aperture file Inch to Millimeter Conversion)
// written by Ted Ammann  1/2/97

// calling Syntax
//     AptINtoMM   infile  outfile
// Program changes data in aperture file from inches to mm
// Note: program only changes data and DOES NOT change parameter
//       setting from inch to mm ( That is done when aperture file is
//       merged with panel aperture file).
//
// Note: if any input line that contains an aperture has less then 6 fields
//       program returns an error and exits 

// Revision history
//  Rev1  released on 1/2/97





//******************************************************************************
// function - convertapt
// input params - none
// returns CODE
// modifies aperture on current line. Exit if number of fields is less than 6
//********************************************************************************

int convertapt_out( char *fnamestr, char *outfilestr)
{
FILE *outfile;
FILE *file1;
int number_fields;
int endoffile;
char thisline[300];

      // read all lines upto first aperture and output the line

     file1  = fopen(fnamestr, "r");

      if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",fnamestr);
	   return(256);
	  }
      outfile  = fopen(outfilestr, "w");

      if (outfile == NULL)
	  {
	   printf("Error: Unable to open the output file = %s \n",outfilestr);
	   return(257);
	  }
      endoffile = getline(file1,thisline);
      number_fields = split_line(thisline);

      // while(getline < FILENAME && $1 !~ /[Dd][0-9]/){print $0} 
      while(( endoffile == FALSE)&& (( str_array[0][0] != 'd') && ( str_array[0][0] != 'D')
	    || ( ! isdigit( str_array[0][1] ))) )
	  {
	      fprintf(outfile,"%s",thisline);
          endoffile = getline(file1,thisline);
          number_fields = split_line(thisline);
        }

      // handle first d-code ( while above stops on first d-code line
      // so it must be handled special).
      // multipy fields 5 and 6 by 25.4 to convert to millimeters
      // if line has less than 6 fields set CODE to 255 and exit
      if(number_fields  >=  6)
	  {
	fprintf(outfile,"%-5s%-34s%2s %-10s  %0.4f  %0.4f\n",str_array[0],str_array[1],
                      str_array[2],str_array[3], (25.4 * atof(str_array[4])),
                               (25.4 * atof(str_array[5])));
      }
      else 
	  {
	  //CODE = 255;
	  return(255);
      }

      // read in the rest of the d-codes
      // handle all remaining lines just like the first d-code line
	  endoffile = getline(file1,thisline);
        number_fields = split_line(thisline);
      while(endoffile==FALSE )
	  {
         if(number_fields  >= 6)
		 {
	       fprintf(outfile,"%-5s%-34s%2s %-10s  %0.4f   %0.4f\n",str_array[0],str_array[1],
                      str_array[2],str_array[3], (25.4 * atof(str_array[4])),
                               (25.4 * atof(str_array[5])));
         }
         else 
		 {
	      //CODE = 255;
	      return(255);
         }
	    endoffile = getline(file1,thisline);
        number_fields = split_line(thisline);

      }   
      fclose(file1 );
	  fclose(outfile);

	  return(0);

} // convertapt_out

//******************************************************************************
// function - convertapt
// input params - none
// returns CODE
// modifies aperture on current line. Exit if number of fields is less than 6
//********************************************************************************

int convertapt( char *fnamestr)
{
FILE *file1;   // read all lines upto first aperture and output the line
int endoffile;
int number_fields;
char thisline[300];

     file1  = fopen(fnamestr, "r");

      if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",fnamestr);
	   return(256);
	  }
      endoffile = getline(file1,thisline);
      number_fields = split_line(thisline);

      // while(getline < FILENAME && $1 !~ /[Dd][0-9]/){print $0} 
      while(( endoffile == FALSE)&& (( str_array[0][0] != 'd') && ( str_array[0][0] != 'D')
	    || ( ! isdigit( str_array[0][1] ))) )
	  {
	      printf("%s",thisline);
          endoffile = getline(file1,thisline);
          number_fields = split_line(thisline);
        }

      // handle first d-code ( while above stops on first d-code line
      // so it must be handled special).
      // multiply fields 5 and 6 by 25.4 to convert to millimeters
      // if line has less than 6 fields set CODE to 255 and exit

      if(number_fields  >=  6){
	printf("%-5s%-34s%2s %-10s  %0.4f  %0.4f\n",str_array[0],str_array[1],
                      str_array[2],str_array[3], (25.4 * atof(str_array[4])),
                               (25.4 * atof(str_array[5])));
      }
      else 
	  {
	  // CODE = 255;
	  return(255);
      }

      // read in the rest of the d-codes
      // handle all remaining lines just like the first d-code line
      endoffile = getline(file1,thisline);
      number_fields = split_line(thisline);
      while(endoffile==FALSE )
	  {
         if(number_fields  >= 6)
		 {
	       printf("%-5s%-34s%2s %-10s  %0.4f   %0.4f\n",str_array[0],str_array[1],
                      str_array[2],str_array[3], (25.4 * atof(str_array[4])),
                               (25.4 * atof(str_array[5])));
         }
         else 
		 {
	      // CODE = 255;
	      return(CODE);
         }
	    endoffile = getline(file1,thisline);
        number_fields = split_line(thisline);

      }   
      fclose(file1 );

	  return(0);

}  // convertapt

//*****************************************************************************
// Begin - sets program return value to default of 0
//         the program returns a value based on 
//              if data is in inches or mm 
//              data format ( i.e., 5.4 5.2)
//              if data is absolute or incremental
//          a value of 255 is returned if an error is found in aperture file
//*****************************************************************************

int aptintomm2_call_out( char *infilestr, char *outfilestr)
{

int number_fields;
char thisline[300];
int kk;
int endoffile;
char a[120][120];
FILE *file1;
char absolute[120];
char units[120];
int MltCnt;
char fnamestr[120];
int debug;

   debug=0;

  CODE  = 0;

   file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  strncpy( fnamestr, infilestr,120);

//***************** Start of Main **********************************************

  endoffile = getline(file1,thisline);
  number_fields = split_line(thisline); 

  while(endoffile == FALSE)
   {
     for(kk=0; kk < (signed int ) strlen( str_array[0] ); kk += 1)
       {
         str_array[0][kk] = toupper(str_array[0][kk]);
	 }
    if( strcmp( str_array[0],"APTUNITS") == 0 )
	{                                          // get the units 
         for(kk=0; kk < (signed int) strlen( str_array[1]); kk += 1)
		 {
	      units[kk] = toupper(str_array[1][kk]);
         }
         units[kk] = 0;
      

        if( strcmp(units,"MM") != 0 )
		{                         // adjust code if units are millimeter
	      CODE += 100;
        }
	}
    if( strcmp( str_array[0],"FORMAT") == 0 )
      {                                          // get the scale factor 
         split(str_array[1],a[0],a[1],".");    // split at decimal point 
         MltCnt  = atoi(a[1]); // we want the number to the right of decimal point
	     if( MltCnt > 9) // exit if precision is too great
		 {
	      CODE = 255;
	      return(CODE);
         }
        CODE += atoi(a[1]);   // include the precision in the return value

    }
    if(strcmp( str_array[0],"ABSOLUTE") == 0 ) 
       { // absolute or incremental

         for(kk=0; kk < (signed int) strlen( str_array[1]); kk += 1)
		 {
	       absolute[kk] = toupper(str_array[1][kk]);
         }
         absolute[kk] = 0;

		// printf("absolute = %s \n",absolute);

	     if(strcmp(absolute,"ON") != 0 )
          {
              CODE += 10;   // adjust return value for data not being in Absolute mode.
		 }
      }
     
      endoffile=getline(file1,thisline);
      number_fields = split_line(thisline);

      if (debug) { printf("line in = %s \n", thisline); }

     }  // while end of file is false

    fclose( file1);    // close the input file

     // awk always runs the END function even if you exit from main
     // so test if you really wanted to exit
     if ( CODE != 255 )
	 {  // if no errors in main continue
        if( strcmp(units,"MM")!= 0) 
		{ // If data is in inches convert it. 
	     CODE=convertapt_out(fnamestr,outfilestr);
        }
     }
     return(CODE);  // exit returning CODE
} 


//*****************************************************************************
// Begin - sets program return value to default of 0
//         the program returns a value based on 
//              if data is in inches or mm 
//              data format ( i.e., 5.4 5.2)
//              if data is absolute or incremental
//          a value of 255 is returned if an error is found in aperture file
//*****************************************************************************
int aptintomm2_call( char *infilestr)
{

int number_fields;
char thisline[120];
int kk;
int endoffile;
char a[120][120];
FILE *file1;
char absolute[120];
char units[120];
int MltCnt;
char fnamestr[120];


  CODE  = 0;

   file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  strncpy( fnamestr, infilestr,120);

//***************** Start of Main **********************************************

  endoffile = getline(file1,thisline);
  number_fields = split_line(thisline);
  while(endoffile == FALSE)
   {
     for(kk=0; kk < (signed int) strlen( str_array[0] ); kk += 1)
       {
         str_array[0][kk] = toupper(str_array[0][kk]);
	 }
    if( strcmp( str_array[0],"APTUNITS") == 0 )
	{                                          // get the units 
         for(kk=0; kk < (signed int ) strlen( str_array[1]); kk += 1)
		 {
	      units[kk] = toupper(str_array[1][kk]);
         }
         units[kk] = 0;
       
        if( strcmp(units,"MM") != 0 )
		{                         // adjust code if units are millimeter
	      CODE += 100;
        }
	}
    if( strcmp( str_array[0],"FORMAT") == 0 )
      {                                          // get the scale factor 
         split(str_array[1],a[0],a[1],".");    // split at decimal point 
         MltCnt  = atoi(a[1]); // we want the number to the right of decimal point
	     if( MltCnt > 9) // exit if precision is too great
		 {
	      CODE = 255;
	      return(CODE);
         }
        CODE += atoi(a[1]);   // include the precision in the return value
    }
    if(strcmp( str_array[0],"ABSOLUTE") == 0 ) 
       { // absolute or incremental

         for(kk=0; kk < (signed int) strlen( str_array[1]); kk += 1)
		 {
	       absolute[kk] = toupper(str_array[1][kk]);
         }
         absolute[kk] = 0;

	     if(strcmp(absolute,"ON") != 0 )
          {
              CODE += 10;   // adjust return value for data not being in Absolute mode.
		 }
      }
     
      endoffile=getline(file1,thisline);
      number_fields = split_line(thisline);

     }  // while end of file is false

    fclose( file1);    // close the input file

     // awk always runs the END function even if you exit from main
     // so test if you really wanted to exit
     if ( CODE != 255 )
	 {  // if no errors in main continue
        if( strcmp(units,"MM")!= 0) 
		{ // If data is in inches convert it. 
	     CODE=convertapt(fnamestr);
        }
     }
     return(CODE);  // exit returning CODE
} 

/*
int main( int argc, char **argv)
{
  int retcode ;

  if (argc != 2)
    {
	  printf("In aptintomm2, wrong number of arguments \n");
	  printf("Usage: aptintomm2 aptfile \n");
	  exit(-1);
	}
  else
   {
    retcode = aptintomm2_call( argv[1]);

	if (retcode != 0 )
	{
		if ((retcode > 110) || ( retcode < 100 ) ) // not a conversion
		{
		 printf("code = %d \n",retcode);
		}
	}
    exit(retcode);
  }

 } 



 */




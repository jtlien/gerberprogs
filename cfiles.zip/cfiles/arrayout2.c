#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


// Rev 1
// Title: arrayout2
// written by Ted Ammann  7/25/96

// calling Syntax
//     arrayout2 -v file1=coordfile  infile > outfile

// Program arrays out gerber data in infile to outfile placeing a copy
// of the gerber data at each coordinate in the coordfile
//
// Program calls executable dooffset (created from dooffset.c) please
// see the source file for possible side effects or input requirements

// Revision history
//  Rev1  released on  7/25/96

void dooffset_call(char *fname, int in1 , int in2);

void arrayout2_call( char *coordfilestr, char *infilestr)
{
int nf;
char thisline[300];
int endoffile;
FILE *file1;

  file1=fopen( coordfilestr,"r");
  if (file1==NULL)
  {
	  printf("In arrayout2, unable to open the input file = %s \n",coordfilestr);
	  exit(-1);
  }

  // simply call dooffset for each coordinate in file1
  // ( $1 = X coord , $2  = Y coord)

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {
     dooffset_call(infilestr, atoi(str_array[0]), atoi(str_array[1]) ); // 
     
	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

  }
  fclose(file1);
}

int main( int argc, char **argv)
{

	if (argc != 3)
	{
		printf("In arrayout2, wrong number of arguments \n");
		printf("Usage: arrayout2 coordfile infile \n");
		exit(-1);
	}
	else
	{
		arrayout2_call( argv[1], argv[2]);
	}

} // end main

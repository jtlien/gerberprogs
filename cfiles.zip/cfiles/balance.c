#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"


// Created by bac 11-25-97
// create part vector artwork for one layer
// looks for mcm file that matches current directory name
// for vector, checks for existence of art_aper.txt
// Version 1.0

// requires cadence artwork in search path
// requires area program in search path
// requires a .mcm file and an art_aper.txt file in the current dir
// requires a .brd file in the current dir
// requires an arwork and area subdirectory

void out_paramfile( FILE *outfile)
{
  fprintf(outfile,"DEVICE-TYPE           GERBER6X00\n");
  fprintf(outfile,"OUTPUT-UNITS          MM\n");
  fprintf(outfile,"FILM-SIZE             3200000 3200000\n");
  fprintf(outfile,"FORMAT                5.4\n");
  fprintf(outfile,"ABORT-ON-ERROR        NO\n");
  fprintf(outfile,"SCALE                 1\n");
  fprintf(outfile,"G-CODES               YES\n");
  fprintf(outfile,"OPTIMIZE              YES\n");
  fprintf(outfile,"STATIONS-PER-WHEEL    999\n");
  fprintf(outfile,"COORDINATES           ABSOLUTE\n");
  fprintf(outfile,"SUPPRESS-LEAD-ZEROES  YES\n");
  fprintf(outfile,"SUPPRESS-TRAIL-ZEROES NO\n");
  fprintf(outfile,"SUPPRESS-EQUAL        YES\n");

  fclose(outfile);

}

void balance_call( char *layernamestr )
{
char localname[300];
char basename[300];
char pwdstr[200];
FILE *paramfile;
char commandstr[300];

//basename=${PWD##*\/}


    getwd(pwdstr);

	get_full_path_end( pwdstr, basename);

    //localname=${PWD##*\/}.mcm

   strncpy(localname,basename,200);
   strncat(localname,".mcm",10);

   if( ! (file_exists( localname) ) )      // -a $localname 
   {
      printf("%s  does not exist.\n",localname);
      exit(-1);
   }
   else
   {
      if( ! (file_exists("art_aper.txt") ) )     // -a art_aper.txt 
      {
         printf("No art_aper.txt file!\n");
         exit(-1);
	  }
      else  
	  {
         printf("Making vector artwork for film %s\n",layernamestr); //  $1
        // cp /usr/local/library/art_param.6x00 art_param.txt
		 paramfile=fopen("art_param.txt","w");
		 if (paramfile==NULL)
		 {
			 printf("In balance, unable to create the art_param.txt file for write \n");
			 exit(-1);
		 }
		 else
		 {
           out_paramfile(paramfile);
		 }
         //artwork -s -f $1 $basename
		 strncpy(commandstr,"artwork -s -f ",30);
		 strncat(commandstr,layernamestr,120);
		 strncat(commandstr," ",5);
		 strncat(commandstr,basename,120);
		 printf("running : %s \n",commandstr);
		 system(commandstr);

         rm_file("art_param.txt");
         system("mv *.art artwork");


         change_dir("area");

		 strncpy(commandstr,"area ",15);
		 strncat(commandstr,layernamestr,120);
		 strncat(commandstr,".ajf",10);

		 system(commandstr);

        // area $1.ajf
      }
   }

} // end balance_call

int main( int argc, char **argv)
{
char USAGE[300];
char WHERE[300];

strncpy(USAGE,"usage:  balance layername",80);
strncpy(WHERE,"\twith layername the film name",80);

 if(argc != 2)
 {
   printf("In balance, incorrect number of arguments\n");
   printf( "%s\n%s\n",USAGE,WHERE);
   exit(-1);
 }
 else
 {
	balance_call( argv[1]);
 }

}  // end main
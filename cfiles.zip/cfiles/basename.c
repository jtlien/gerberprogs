#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"


void  basename_call( char *infilestr)
{
char basestr[120];
int ii;

     if (strstr( infilestr,"/") == NULL)
	 {
	    get_full_path_end( infilestr, basestr);

	     printf("%s\n",basestr);
	 }
	 else
	 {
		 ii=0;
		 while(ii < ( signed int) strlen( infilestr) )
		 {
			 if ( infilestr[ii] == '/' )
			 {
				 infilestr[ii]='\\';
			 }
		   ii +=1;
		 }
		 get_full_path_end( infilestr, basestr);
		 printf("%s\n",basestr);
	 }




}  // end basename_call

void  basename_call_out(char *infilestr, char *outfilestr)
{
char basestr[120];
FILE *outfile;
int ii;

     outfile=fopen(outfilestr,"w");
	 if (outfile==NULL)
	 {
		 printf("In basename_call_out, unable to open the input file =%s \n",outfilestr);
		 exit(-1);
	 }

	  if (strstr( infilestr,"/") == NULL)
	 {
	    get_full_path_end( infilestr, basestr);

	     fprintf(outfile,"%s\n",basestr);
	 }
	 else
	 {
		 ii=0;
		 while(ii < ( signed int) strlen( infilestr) )
		 {
			 if ( infilestr[ii] == '/' )
			 {
				 infilestr[ii]='\\';
			 }
		   ii +=1;
		 }
		 get_full_path_end( infilestr, basestr);
		 fprintf(outfile,"%s\n",basestr);
	 }

	 fclose(outfile);

}  // end basename_call_out


int main( int argc, char **argv)
{
	
	if (argc != 2)
	{
		printf("In basename, wrong number of arguments \n");
		printf("Usage: basename filepath \n");
		exit(-1);
	}
	else
	{
      basename_call( argv[1]);
	  
	}

}  // end main

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


struct nodestuff 
{
	double xval;
	double yval;
} node_array[500000];


void buildtri( char *infile1str, char *infile2str, char *outfilestr)
{

FILE *file1, *file2;
FILE *outfile;
double xval1, yval1, xval2, yval2, xval3, yval3;
char str1[300];
char str2[300];
char str3[300];
char str4[400];
int index;
int index1;
int index2;
int index3;
double xval;
double yval;
int count;
   

   file1=fopen(infile1str,"r");

   if (file1 == NULL)
   {
	   printf("In get_cd, unable to open the input file = %s \n",infile1str);
	   exit(-1);
   }


   outfile=fopen(outfilestr,"w");

   if (outfile == NULL)
   {
	   printf("In buildtri, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }


   count=0;

   while( fscanf(file1,"%s %s %s", str1, str2, str3) == 3)
   {
	   index = atoi(str1);
	   xval = atof(str2);
	   yval=  atof(str3);

	   //printf("Index = %d \n",index);

	   if ((index < 500000)  && ( index > -1 ))
	   {
		   node_array[index].xval=xval;
		   node_array[index].yval=yval;
	   }

	 count += 1;

   }


   printf("Read the nodes , count = %d \n", count );

  fclose(file1);


  file2=fopen(infile2str,"r");

  count = 0;

   if (file2 == NULL)
   {
	   printf("In buildtri, unable to open the input file = %s \n",infile2str);
	   exit(-1);
   }

  while( fscanf(file2,"%s %s %s %s", str1, str2, str3, str4) == 4)
   {
	   index1 = atoi(str2);

	   xval1 = node_array[index1].xval;
	   yval1 = node_array[index1].yval;

	   fprintf(outfile,"X%0.0fY%0.0fD02*\n",xval1,yval1);

	   index2 = atoi(str3);
       xval2 = node_array[index2].xval;
	   yval2 = node_array[index2].yval;

	   fprintf(outfile,"X%0.0fY%0.0fD01*\n",xval2,yval2);

       index3 = atoi(str4);
       xval3 = node_array[index3].xval;
	   yval3 = node_array[index3].yval;

	   fprintf(outfile,"X%0.0fY%0.0fD01*\n",xval3,yval3);

       fprintf(outfile,"X%0.0fY%0.0fD01*\n",xval1,yval1);

       count += 1;
   }


  fclose(outfile);
  fclose(file2);

  printf("Read in the elem file , count = %d \n", count);

  

}  //



int main( int argc, char **argv)
{

   if (argc != 4)
   {
	   printf("In buildtri, wrong number of arguments \n");
	   printf("Usage: buildtri infile1 infile2 outfile\n");
	   exit(-1);
   }
   else
   {
	   buildtri(argv[1],argv[2], argv[3]);
   }
}





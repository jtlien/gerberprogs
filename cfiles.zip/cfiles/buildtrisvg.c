#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


struct nodestuff 
{
	double xval;
	double yval;
} node_array[500000];


 
void buildtri_svg_call( char *infile1str, char *infile2str, FILE *outfile, char *rgbstr)
{

FILE *file1, *file2;
double xval1, yval1, xval2, yval2, xval3, yval3;
char str1[300];
char str2[300];
char str3[300];
char str4[400];
int index;
int index1;
int index2;
int index3;
double xval;
double yval;
int count;
char quotchar;
double scale_factor;


    scale_factor=1.0;

    quotchar='"';


   file1=fopen(infile1str,"r");

   if (file1 == NULL)
   {
	   printf("In buildtri, unable to open the input file = %s \n",infile1str);
	   exit(-1);
   }



   // read header line

   fscanf(file1,"%s %s %s %s", str1, str2, str3,str4);
   count=0;

   while( fscanf(file1,"%s %s %s %s", str1, str2, str3,str4) == 4)
   {
	   index = atoi(str1);
	   xval = atof(str2);
	   yval=  atof(str3);

	   //printf("Index = %d \n",index);

	   if ((index < 500000)  && ( index > -1 ))
	   {
		   node_array[index].xval=xval;
		   node_array[index].yval=yval;
	   }

	 count += 1;

   }


  // printf("Read the nodes , count = %d \n", count );

  fclose(file1);


  file2=fopen(infile2str,"r");

  count = 0;

   if (file2 == NULL)
   {
	   printf("In buildtri, unable to open the input file = %s \n",infile2str);
	   exit(-1);
   }

   xval1=0.0;
   yval1=0.0;

   xval2=0.0;
   yval2=0.0;

   xval3=0.0;
   yval3=0.0;

   // read header line

   fscanf(file2,"%s %s %s ", str1, str2, str3);

  while( fscanf(file2,"%s %s %s %s", str1, str2, str3, str4) == 4)
   {

       fprintf(outfile,"<polygon fill=%c%s%c stroke=%c%s%c stroke-width=%c10%c points=%c \n",
		quotchar,rgbstr,quotchar,quotchar,rgbstr,quotchar,quotchar,quotchar,quotchar);

	   index1 = atoi(str2);

	   if ((index1 < 500000)&& (index1 > -1 ))
	   {
	   xval1 = node_array[index1].xval/scale_factor;
	   yval1 = node_array[index1].yval/scale_factor;
	   }

	   
	   fprintf(outfile,"%9.5f,%9.5f\n",xval1,yval1);

	   index2 = atoi(str3);

       if ((index2 < 500000)&& (index2 > -1 ))
	   {

        xval2 = node_array[index2].xval/scale_factor;
	    yval2 = node_array[index2].yval/scale_factor;
	   }

	   fprintf(outfile,"%9.5f,%9.5f \n",xval2,yval2);

       index3 = atoi(str4);

	   // printf("Indexs = %d %d %d \n", index1, index2, index3);

       if ((index3 < 500000)&& (index3 > -1 ))
	   {

        xval3 = node_array[index3].xval/scale_factor;
	    yval3 = node_array[index3].yval/scale_factor;
	   }

	   fprintf(outfile,"%9.5f,%9.5f",xval3,yval3);

     //  fprintf(outfile,"%0.0f %0.0f ",xval1,yval1);
	
       fprintf(outfile,"%c/>\n",quotchar);  // end of polygon
       count += 1;
   }


  fclose(file2);

  //printf("Read in the elem file , count = %d \n", count);

  

}  //


void buildtri_call( char *infile1str, char *infile2str, char *outfilestr)
{

FILE *file1, *file2;
FILE *outfile;
double xval1, yval1, xval2, yval2, xval3, yval3;
char str1[300];
char str2[300];
char str3[300];
char str4[400];
int index;
int index1;
int index2;
int index3;
double xval;
double yval;
int count;
   

   file1=fopen(infile1str,"r");

   if (file1 == NULL)
   {
	   printf("In buildtri, unable to open the input file = %s \n",infile1str);
	   exit(-1);
   }


   outfile=fopen(outfilestr,"w");

   if (outfile == NULL)
   {
	   printf("In buildtri, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }

   // read header line

   fscanf(file1,"%s %s %s %s", str1, str2, str3,str4);
   count=0;

   while( fscanf(file1,"%s %s %s %s", str1, str2, str3,str4) == 4)
   {
	   index = atoi(str1);
	   xval = atof(str2);
	   yval=  atof(str3);

	   //printf("Index = %d \n",index);

	   if ((index < 500000)  && ( index > -1 ))
	   {
		   node_array[index].xval=xval;
		   node_array[index].yval=yval;
	   }

	 count += 1;

   }


   printf("Read the nodes , count = %d \n", count );

  fclose(file1);


  file2=fopen(infile2str,"r");

  count = 0;

   if (file2 == NULL)
   {
	   printf("In buildtri, unable to open the input file = %s \n",infile2str);
	   exit(-1);
   }

   xval1=0.0;
   yval1=0.0;

   xval2=0.0;
   yval2=0.0;

   xval3=0.0;
   yval3=0.0;

   // read header line

   fscanf(file2,"%s %s %s ", str1, str2, str3);

  while( fscanf(file2,"%s %s %s %s", str1, str2, str3, str4) == 4)
   {
	   index1 = atoi(str2);

	   if ((index1 < 500000)&& (index1 > -1 ))
	   {
	   xval1 = node_array[index1].xval;
	   yval1 = node_array[index1].yval;
	   }

	   fprintf(outfile,"G36*\n");
	   fprintf(outfile,"X%0.0fY%0.0fD02*\n",xval1,yval1);

	   index2 = atoi(str3);

       if ((index2 < 500000)&& (index2 > -1 ))
	   {

        xval2 = node_array[index2].xval;
	    yval2 = node_array[index2].yval;
	   }

	   fprintf(outfile,"X%0.0fY%0.0fD01*\n",xval2,yval2);

       index3 = atoi(str4);

	   // printf("Indexs = %d %d %d \n", index1, index2, index3);

       if ((index3 < 500000)&& (index3 > -1 ))
	   {

        xval3 = node_array[index3].xval;
	    yval3 = node_array[index3].yval;
	   }

	   fprintf(outfile,"X%0.0fY%0.0fD01*\n",xval3,yval3);

       fprintf(outfile,"X%0.0fY%0.0fD01*\n",xval1,yval1);
	   fprintf(outfile,"G37*\n");


       count += 1;
   }


  fclose(outfile);
  fclose(file2);

  printf("Read in the elem file , count = %d \n", count);

  

}  //


/*
int main( int argc, char **argv)
{

   if (argc != 4)
   {
	   printf("In buildtri, wrong number of arguments \n");
	   printf("Usage: buildtri infile1 infile2 outfile\n");
	   exit(-1);
   }
   else
   {
	   buildtri_call(argv[1],argv[2], argv[3]);
   }
}

*/






//
// cat together two files and put into a third
//
void cat_files( char *infile1_str, char *infile2_str, char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
	 exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile1);
 fclose( outfile);

}  // end cat_files

//
// cat together three files and put into a fourth
//
void cat_3files( char *infile1_str, char *infile2_str, char *infile3_str,char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 fclose( outfile);

}  // end cat_3files
//
// cat together four files and put into a fifth
//
void cat_4files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str,char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);
 fclose( outfile);

}  // end cat_4files


//
// cat together five files and put into a sixth
//
void cat_5files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);
 fclose( outfile);

}  // end cat_5files


//
// cat together six files and put into a seventh
//
void cat_6files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);
 fclose( outfile);

}  // end cat_6files

//
// cat together seven files and put into a eighth
//
void cat_7files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile7_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);

 endfile = getline( infile7, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
 }
 fclose( infile7);

 fclose( outfile);

}  // end cat_7files

//
// cat together eight files and put into a ninth
//
void cat_8files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile7_str);
	 exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile8_str);
	 exit(-1);
 }
 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);

 endfile = getline( infile7, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
 }
 fclose( infile7);

 endfile = getline( infile8, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
 }
 fclose( infile8);

 fclose( outfile);

}  // end cat_8files

//
// cat together 9 files and put into a tenth
//
void cat_9files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *infile9;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile7_str);
	 exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile8_str);
	 exit(-1);
 }

 infile9 = fopen(infile9_str,"r");


 if (infile9 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile9_str);
	 exit(-1);
 }


 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);

 endfile = getline( infile7, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
 }
 fclose( infile7);

 endfile = getline( infile8, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
 }
 fclose( infile8);

 endfile = getline( infile9, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile9, thislinein);
 }
 fclose( infile9);

 fclose( outfile);

}  // end cat_9files

//
// cat together 10 files and put into an eleventh
//
void cat_10files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str, 
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *infile9;
FILE *infile10;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile7_str);
	 exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile8_str);
	 exit(-1);
 }

 infile9 = fopen(infile9_str,"r");


 if (infile9 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile9_str);
	 exit(-1);
 }

 infile10 = fopen(infile10_str,"r");


 if (infile10 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile10_str);
	 exit(-1);
 }


 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);

 endfile = getline( infile7, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
 }
 fclose( infile7);

 endfile = getline( infile8, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
 }
 fclose( infile8);

 endfile = getline( infile9, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile9, thislinein);
 }
 fclose( infile9);

 endfile = getline( infile10, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile10, thislinein);
 }
 fclose( infile10);

 fclose( outfile);

}  // end cat_10files

//
// cat together 11 files and put into a twelfth
//
void cat_11files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str, char *infile11_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *infile9;
FILE *infile10;
FILE *infile11;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile7_str);
	 exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile8_str);
	 exit(-1);
 }

 infile9 = fopen(infile9_str,"r");


 if (infile9 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile9_str);
	 exit(-1);
 }

 infile10 = fopen(infile10_str,"r");


 if (infile10 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile10_str);
	 exit(-1);
 }

 infile11 = fopen(infile11_str,"r");


 if (infile11 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile11_str);
	 exit(-1);
 }


 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);

 endfile = getline( infile7, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
 }
 fclose( infile7);

 endfile = getline( infile8, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
 }
 fclose( infile8);

 endfile = getline( infile9, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile9, thislinein);
 }
 fclose( infile9);

 endfile = getline( infile10, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile10, thislinein);
 }
 fclose( infile10);

 endfile = getline( infile11, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile11, thislinein);
 }
 fclose( infile11);

 fclose( outfile);

}  // end cat_11files



// cat together 13 files and put into a 14th
//
void cat_13files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str, char *infile11_str,char *infile12_str,
				 char *infile13_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *infile9;
FILE *infile10;
FILE *infile11;
FILE *infile12;
FILE *infile13;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile7_str);
	 exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile8_str);
	 exit(-1);
 }

 infile9 = fopen(infile9_str,"r");


 if (infile9 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile9_str);
	 exit(-1);
 }

 infile10 = fopen(infile10_str,"r");


 if (infile10 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile10_str);
	 exit(-1);
 }

 infile11 = fopen(infile11_str,"r");


 if (infile11 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile11_str);
	 exit(-1);
 }

 infile12 = fopen(infile12_str,"r");


 if (infile12 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile12_str);
	 exit(-1);
 }


 infile13 = fopen(infile13_str,"r");


 if (infile13 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile13_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);

 endfile = getline( infile7, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
 }
 fclose( infile7);

 endfile = getline( infile8, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
 }
 fclose( infile8);

 endfile = getline( infile9, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile9, thislinein);
 }
 fclose( infile9);

 endfile = getline( infile10, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile10, thislinein);
 }
 fclose( infile10);

 endfile = getline( infile11, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile11, thislinein);
 }
 fclose( infile11);

 endfile = getline( infile12, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile12, thislinein);
 }
 fclose( infile12);

 endfile = getline( infile13, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile13, thislinein);
 }
 fclose( infile13);

 fclose( outfile);

}  // end cat_13files


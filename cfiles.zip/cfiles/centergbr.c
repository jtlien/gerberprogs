#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0



//
// callable interface 
//

int centergbr_call( char *file1_instr, char *file2_instr, char *file3_instr)
{
int file_out_flag;

FILE *file1,*file2, *file3;
int number_fields;
int end_of_file;
char x_str[300];
char y_str[300];
double x_val;
double y_val;
double xoffset;
double yoffset;
int cnt;
char thisline[200];
int val;
int debug;
char a[12][120];
char b[12][120];
char c[12][120];
char d[12][120];

    debug=0;
    file_out_flag = 0;

    file1  = fopen(file1_instr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",file1_instr);
	  exit(-1);
	}

    file2 = fopen(file2_instr, "r");

    if (file2 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",file2_instr);
	  exit(-1);
	}

	if (strlen(file3_instr) != 0 )
	{
	  file3 = fopen(file3_instr,"w");
	  if (file3 == NULL)
	  { 
		printf("Error: Unable to open the output file = %s \n", file3_instr);
		exit(-1);
	  }
	  file_out_flag =1 ;
	}

	d[0][0]='\0';
	d[1][0]='\0';

    cnt = 0;
    end_of_file = getline(file1,thisline);
	number_fields = split_line(thisline);

    while (end_of_file == FALSE)
	{
	   strncpy(a[cnt],str_array[0],120);
	   cnt++;
	   end_of_file = getline(file1,thisline);
	   number_fields = split_line(thisline);
    } 
	fclose(file1);

    xoffset =  floor((atof(a[0]) + atof(a[1]))/2.0);
    yoffset =  floor((atof(a[2]) + atof(a[3]))/2.0);

	if (debug) { printf("xoffset = %f yoffset=%f \n",xoffset,yoffset); }

	if (file_out_flag)
	{
     fprintf(file3,"X%0.0fY%0.0fD02*\n", xoffset* -1, yoffset* -1);
	}
    else
	{
     printf("X%0.0fY%0.0fD02*\n", xoffset* -1, yoffset* -1);
	}
   end_of_file = getline(file2,thisline);

   while( end_of_file ==FALSE)
   {
    if (( strstr(thisline,"X") != NULL) && ( strstr(thisline,"Y") != NULL)
	  && ( strstr(thisline,"G54") == NULL) && ( thisline[0] != '%') )
	{
       split(thisline,a[0],a[1],"Y");
	   if (strstr(thisline,"D") != NULL)
	   {
         split(thisline,d[0],d[1],"D");

         val =  awk_index(a[0],"X");

         awk_substr( a[0],val +1,120,x_str );
          awk_substr( a[1],1,strlen(a[1]) -4,y_str); 
	   }
	   else
	   {
		   //strncpy(d[1],"",4);
		  // printf("Warning, bad gerber format, Missing Dxx\n");
           val =  awk_index(a[0],"X");

          awk_substr( a[0],val +1,120,x_str );
          awk_substr( a[1],1,strlen(a[1])-1,y_str); 
	   }


       if (debug) { 
		    printf("a[0] = %s a[1]=%s x_str=%s y_str=%s d1=%s\n",a[0],a[1],x_str,y_str,d[1]);
	   }
       x_val = atof(x_str) - xoffset;
       y_val = atof(y_str) - yoffset;


	   if (file_out_flag )
	   {
        fprintf(file3,"X%0.0fY%0.0fD%s\n", x_val,y_val,d[1]);
	   }
	   else
	   {
        printf("X%0.0fY%0.0fD%s\n", x_val,y_val,d[1]);
	   }
	}
    else if(( strstr(thisline,"Y") == NULL) && ( strstr(thisline,"X") != NULL))
	 {
      split(thisline,b[0],b[1],"X");
	  if (strstr(thisline,"D")!= NULL)
	  {
	   awk_substr(b[1],1,strlen(b[1]) - 4,x_str);
       split(thisline,d[0],d[1],"D");
	  }
	  else
	  {
		  //printf("Warning, bad gerber format, Missing Dxx\n");
		  awk_substr(b[1],1,strlen(b[1])-1,x_str);
		 // strncpy(d[1],"",4);
	  }
      // awk_substr(b[1],1,strlen(b[1]) - 4,x_str);

      x_val = atof(x_str) - xoffset;
	  if (file_out_flag) fprintf(file3,"X%0.0fD%s\n", x_val,d[1]);
      else printf("X%0.0fD%s\n", x_val,d[1]);
	}
    else if(( strstr(thisline,"X") == NULL) && ( strstr(thisline,"Y") != NULL))
	 {
      split(thisline,c[0],c[1],"Y");
      if (strstr(thisline,"D") != NULL)
	  {
		awk_substr(c[1],1,strlen(c[1]) - 4,y_str);
        split(thisline,d[0],d[1],"D");
	  }
	  else
	  {
		  // printf("Warning, bad gerber format, Missing Dxx\n");
		  awk_substr(c[1],1,strlen(c[1])-1,y_str);
		 // strncpy(d[1],"",4);
	  }

      // awk_substr(c[1],1,strlen(c[1]) - 4,y_str);
      y_val = atof(y_str) - yoffset;
      if (file_out_flag) fprintf(file3,"Y%0.0fD%s\n", y_val,d[1]);
	  else printf("Y%0.0fD%s\n", y_val,d[1]);
	}
    else
	{
      if (file_out_flag)  fprintf(file3,"%s",thisline);
	  else printf("%s",thisline);
	}
    end_of_file=getline(file2,thisline);
    if (debug) { printf("line in = %s \n",thisline); }
   }
   fclose(file2);
   if (file_out_flag)
   {
	   fclose(file3);
   }

  return(0);

}  // end centergbr_call

/*
int main( int argc, char **argv)
{
char file1_str[120];
char file2_str[120];

int retcode;

  if (argc==3) 
   {
     strncpy( file1_str, argv[1],120);
	 strncpy( file2_str, argv[2],120);

     retcode = centergbr_call(file1_str,file2_str,"");

     exit(retcode);
    }
   else if ( argc == 4)
   {
     strncpy( file1_str, argv[1],120);
	 strncpy( file2_str, argv[2],120);

     retcode = centergbr_call(file1_str,file2_str,argv[3]);

     exit(retcode);

   }
   else
   {
	 printf("In centergbr, wrong number of arguments \n");
	 printf("Usage: centergbr offsetfile gbrfile \n");
	 exit(-1);

     }
}  
 
*/







#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//
//  Check that units are correct
//

#include "utilprogs.h"

int check_units_call( char *infilestr)
{
char units[120];
int result;
char file_sep[10];
int ii;
char thisline[120];
FILE *file1;
int endoffile;
int number_fields;

    file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	}

    strncpy(file_sep,"!",3);

    endoffile = getline(file1, thisline);
	number_fields = split_line_seps( thisline, file_sep);

    while( endoffile == FALSE)
	{
	  units[0] = 0;
      if(strcmp(str_array[0],"S") == 0)
	  {
	   ii = 0;
	   while(ii < (signed int) strlen( str_array[1]))
	   {
        units[ii] = toupper(str_array[1][ii]);
	    ii += 1;
	   }
	   units[ii] = 0;
	  }

     if ( strcmp(units,"MICRONS") == 0)
	 {
        result = 1;
     }
     else
	 {
        result = 0;
     }
	 endoffile = getline(file1, thisline);
	 number_fields = split_line_seps( thisline, file_sep);

	}  // end while

   fclose(file1);

   return( result);

} // end main

/*
int main( int argc, char **argv)
{
int retcode;

  if (argc != 2)
  {
	  printf("In check_units, wrong number of arguments \n");
	  printf("Usage:  check_units fname \n");
	  exit(-1);
  }
  else
  {
	  retcode=check_units_call(argv[1]);
	  exit(retcode);
  }

} // end main

*/

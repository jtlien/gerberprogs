#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

int check_up_low_call( char *infilestr)
{

int result;
FILE *file1;
int endoffile;
int number_fields;
char thisline[200];


  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  
  result = 1;
   
  endoffile = getline(file1, thisline);
  number_fields = split_line(thisline);

  endoffile = getline(file1, thisline);
  number_fields = split_line(thisline);

  while(endoffile == FALSE)
  {
     if ((strstr(str_array[3],"U") != NULL) 
		 || (strstr(str_array[3],"L") != NULL))
	 {
       result = 0;
     }
  endoffile = getline(file1,thisline);
  number_fields = split_line(thisline);

  }
  fclose(file1);
  

  return(result);

}    // end check_up_low

int main( int argc, char **argv)
{
int retcode;

	if (argc != 2)
	{
		printf("In check_up_low, wrong number of arguments \n");
		printf("Usage: check_up_low fname  \n");
		exit(-1);
	}
    else
	{
		retcode=check_up_low_call(argv[1]);
	}

 exit(retcode);
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"


int check_z_call( char *infilestr)
{
int result;
FILE *datfile;
FILE *file1;
FILE *atmpfile;
int endoffile;
int number_fields;
char thisline[200];
char dat_file_str[20];
char tmp_file_str[20];

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  strncpy(dat_file_str,"z.dat",10);
  strncpy(tmp_file_str,"tmp.dat",10);

  atmpfile  = fopen(tmp_file_str, "w");

  if (atmpfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",tmp_file_str);
	  exit(-1);
  }

  datfile  = fopen(dat_file_str, "w");

  if (datfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",dat_file_str);
	  exit(-1);
  }
 
  result = 0;
   
  endoffile = getline(file1, thisline);

  fprintf(atmpfile,"%s",thisline); 
  
  endoffile = getline(file1,thisline);
  number_fields = split_line(thisline);

  while(endoffile == FALSE)
  {
     if (strstr(str_array[3],"Z") != NULL)
	 {
       result = 1;
       fprintf(datfile,"%s",thisline); 
     }
     else
	 {
       fprintf(atmpfile,"%s",thisline); 
     }
    endoffile = getline(file1,thisline);
    number_fields = split_line(thisline);
  }

  fclose(file1);
  fclose(datfile);
  fclose(atmpfile);


  return(result);

}    // end check_z_call

int main( int argc, char **argv)
{
int retcode;

	if (argc != 2)
	{
		printf("In check_z, wrong number of arguments \n");
		printf("Usage: check_z  fname\n");
		exit(-1);
	}
    else
	{
		retcode=check_z_call(argv[1]);
	}

 exit(retcode);
}



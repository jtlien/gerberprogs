#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


int result;
FILE *datfile;
FILE *file1;
FILE *atmpfile;
int endoffile;
int number_fields;
char str_array[120][120];
char thisline[200];
int retval;


char dat_file_str[20];
char tmp_file_str[20];


int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;

 ii = 0;

 strncpy( tstr, tline,200);

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 // for (jj=0; jj <ii ; jj += 1)
 //{
 //	 printf("str_array[%d] = %s \n",jj,str_array[jj]);
 //}

 return(ii);

} // end split_line

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

int check_z( char *file_in_str)
{

  file1  = fopen(file_in_str, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",file_in_str);
	  return(-1);
  }

  strncpy(dat_file_str,"z.dat",10);
  strncpy(tmp_file_str,"tmp.dat",10);

  atmpfile  = fopen("tmp_file_str", "w");

  if (atmpfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",tmp_file_str);
	  exit(-1);
  }

  datfile  = fopen("dat_file_str", "w");

  if (datfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",dat_file_str);
	  exit(-1);
  }
  strncpy(dat_file_str,"z.dat",10);
  strncpy(tmp_file_str,"tmp.dat",10);

  result = 0;
   
  endoffile = getline(file1, thisline);

  fprintf(atmpfile,"%s",thisline); 
  
  endoffile = getline(file1,thisline);
  number_fields = split_line(thisline);

  while(endoffile == FALSE)
  {
     if (strstr(str_array[3],"Z") != NULL)
	 {
       result = 1;
       fprintf(datfile,"%s",thisline); 
     }
     else
	 {
       fprintf(atmpfile,"%s",thisline); 
     }
    endoffile = getline(file1,thisline);
    number_fields = split_line(thisline);
  }

  fclose(file1);
  fclose(datfile);
  fclose(atmpfile);


  exit(result);

}    // end check_z

int main( int argc, char **argv)
{
  
  retval = check_z( argv[1] );
  return(retval);


}  // end main


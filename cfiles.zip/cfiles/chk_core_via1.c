#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


#include "utilprogs.h"

char corerel[100000][300];
char viaarray[100000][300];

int found_in_corerel(   char *instr, int ncore)
{
int ii;

 while( ii < ncore)
 {
	 if (strcmp(instr, corerel[ii]) == 0 )
	 {
		 return(TRUE);
	 }
	ii += 1;
 }
 return(FALSE);

}  // found_in_corerel

int chk_core_via1_call( char *file1str, char *infilestr)
{

int result;
int ncore;
FILE *file1;
FILE *infile;
int nvias;
int ngnd;
int nsig;
char infostr[300];
int endoffile;
int nf;
char thisline[300];
int viaarraycount;
int i;

  result = 0;
  ncore = 0;
  printf("reading core artwork file ... %s\n", file1str);  //  | "cat 1>&2"

  file1=fopen(file1str,"r");
  if (file1==NULL)
  {
	  printf("In chk_core_via1, unable to open the input file = %s \n",file1str);
	  exit(-1);
  }

 printf("reading core artwork file ... %s\n", file1str);  //  | "cat 1>&2"

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);


  while (endoffile==FALSE)
  {
     //corerel[$2,$4] = 1
	  strncpy(infostr,str_array[1],120);
	  strncat(infostr,",",10);
	  strncat(infostr,str_array[3],120);

	  if (ncore < 100000)
	  {
		  strncpy(corerel[ncore],infostr,300);
	  }
	  else
	  {
		  printf("corerel array size exceeded 100000 \n");
	  }

     ncore++;

	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);
  } 

  
  nvias= 0;
  ngnd = 0;
  nsig = 0;
  
  printf(" > found %d core flashes\n", ncore);
  printf("reading via artwork file =%s..\n",infilestr);

  infile=fopen(infilestr,"r");
  if (infile==NULL)
  {
	  printf("In chk_core_via1, unable to open the input file = %s \n",infilestr);
	  exit(-1);
  }

  endoffile=getline(infile,thisline);
  nf=split_line(thisline);
  viaarraycount=0;
  while(endoffile==FALSE)
  {
    // viaarray[$2,$4] = 1;
    strncpy(infostr,str_array[1],120);
	strncat(infostr,",",10);
	strncat(infostr,str_array[3],120);
	if (viaarraycount < 100000)
	{
		strncpy(viaarray[viaarraycount],infostr,300);
		viaarraycount+=1;
	}
	else
	{
		printf("viaarray size of 100000 exceeded \n");
	}

	endoffile=getline(infile,thisline);
	nf=split_line(thisline);
  }

  fclose(infile);

  i=0;

  while( i < viaarraycount )            // in viaarray )
  {
     if( found_in_corerel(viaarray[i] , ncore) )
	 {
      nsig++;
     }
     else
	 {
       ngnd++;
     }
	i+=1;
  }
  printf(" > found %d vias contacting the core\n", ngnd);     
  printf(" > found %d vias isolated from the core\n", nsig);

  if (nsig != ncore)
  {
    result = 1;
  }
  return(result);

}


int main( int argc, char **argv)
{
int retval;

	if (argc !=3 )
	{
       printf("chk_core_via1, wrong number of arguments \n");
	   printf("Usage: chk_core_via1 file1 infile \n");
	   exit(-1);
	}
	else
	{
		retval=chk_core_via1_call( argv[1], argv[2]);
		exit(retval);

	}

}  // end main

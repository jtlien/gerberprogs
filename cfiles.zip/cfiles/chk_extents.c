

void UpdateCircleExtents(double xc, double yc, double radius, double thickness)
{
    UpdateExtents(xc-radius-thickness/2, yc-radius-thickness/2,
                  xc+radius+thickness/2, yc+radius+thickness/2);
}

void UpdateLineExtents(double x1, double y1, double x2, double y2, double thickness)
{
    // xxx overcompensates for thickness
    if (x1 > x2 )
	{
        t = x2;
        x2 = x1;
        x1 = t;
	}
    if (y1 > y2)
	{
        t = y2;
        y2 = y1;
        y1 = t;
	}

    UpdateExtents(x1-thickness,y1-thickness,x2+thickness,y2+thickness);
}


void  UpdateArcExtents(double  x1, double y1, double x2, double y2, 
					   double startAngle, double extent, double thickness)
{
    // xxx doesn't do the arc bit right, pretends its a straight line! :-(
double theta;
double angleincr;
double angle;

     andlgeincr = theta/50;

	for(i=0; i < 50; i += 1)
	{

      UpdateLineExtents(x1, y1, x2, y2, thickness);

	  angle += angleincr;
	}

}

void ResetExtents()
{
    global gerberExtents
    gerberExtents = [1e6,1e6,-1e6,-1e6]; // xmin, ymin, xmax, ymax
}

void  UpdatePointExtents( double x1, double y1 )
{
 
    if (x1 < gerberExtents[0])
	{
        gerberExtents[0] = x1;
	}
    if (y1 < gerberExtents[1])
	{
        gerberExtents[1] = y1;
	}
    if (x1 > gerberExtents[2])
	{
        gerberExtents[2] = x1;
	}
    if( y1 > gerberExtents[3])
	{
        gerberExtents[3] = y1;
	}

}

void UpdateExtents(double x1, double y1, double x2, double y2)
{

    if(x1 > x2)
	{
        t = x2;
        x2 = x1;
        x1 = t;
	}
    if( y1 >  y2)
	{
        t = y2;
        y2 = y1;
        y1 = t;
	}
    if (x1 <  gerberExtents[0] )
        gerberExtents[0] = x1;
    if (y1 <  gerberExtents[1])
        gerberExtents[1] = y1;
    if (x2 >  gerberExtents[2])
        gerberExtents[2] = x2;
    if (y2 >  gerberExtents[3] )
        gerberExtents[3] = y2;
}


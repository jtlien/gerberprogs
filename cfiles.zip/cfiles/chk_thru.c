#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

char str_array[120][120];

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line


//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline


int chk_thru_call( char *file1str)
{
int exitvalue;
int thru;
int buried;
int endoffile;
char thisline[200];
char tmpstr[200];
FILE *file1;
int nf;
int kk;

    exitvalue = 0;
    thru = 0;
    buried = 0;

   file1=fopen(file1str,"r");
   if (file1==NULL)
   {
	   printf("In chk_thru, unable to open the input file = %s \n",file1str);
	   exit(-1);
   }
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
	strncpy(tmpstr,str_array[2],120);
	for(kk=0; kk < strlen(tmpstr); kk += 1)
	{
		tmpstr[kk] = toupper(tmpstr[kk]);
	}
    if( strcmp(tmpstr,"THRU") == 0 ) //  toupper( $3) == "THRU")
	{
       thru = 1;
    }
    if( strcmp(tmpstr,"BURIED")==0)
	{
        buried = 1;
    }

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);

   }

   fclose(file1);

    if( thru == 1 && buried == 1)
	{
	  printf( "ERROR:  BURIED and THRU layers not allowed TOGETHER  in  .ctl \n");
          exitvalue = 93;
    }
    else if ( thru == 1 && buried == 0)
	{
	  exitvalue = 2;
    }   
    else if ( thru == 0 && buried == 1)
	{
	  exitvalue = 1;
    }   
    printf( "chk_thru %d \n", exitvalue);  
    return(exitvalue); //  exitvalue
}

int main( int argc, char **argv)
{
int tint;
  tint=	chk_thru_call(argv[1]);
  exit(tint);
}


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"


// chk for unconnected nets
//    returns   2 if no lines with "Missing Connections"
//    returns   1 if lines with "Missing Connection" but none with col 2,3,4 all
//                zero
//    returns   0 if a line with "Missing Connections" and col 2,3,4 all 0

int chk_unconnected_nets_call( char *infilestr)
{

int hasmissing;
int result;
int endoffile;
int nf;
char thisline[200];
FILE *file1;

  hasmissing = 1;
  result = 1;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  endoffile=getline(file1,thisline);
  nf = split_line(thisline);

  while(endoffile==FALSE)
  {
    if (( strstr(thisline,"Missing Connections") != NULL) && (nf == 5))
    {
      hasmissing = 0;
       if( (strcmp(str_array[2],"0") == 0) &&
           (strcmp(str_array[3],"0") == 0) && 
           (strcmp(str_array[4],"0") == 0 ))
        {
	  result = 0;
       }
   }
   endoffile=getline(file1,thisline);
   nf = split_line(thisline);
  }         

  fclose(file1);
   
   if( hasmissing == 1 )
   {
     result = 2;
   }
   return(result);

} // end check_unconnected_nets_call


int main( int argc, char **argv)
{
int retcode;

   if ( argc != 2)
   {
	   printf("Error in chk_unconnected_nets, wrong number of arguments \n");
	   printf("Usage: chk_unconnected_nets  infile \n");
	   printf("returns   2 if no lines with 'Missing Connections' \n");
       printf("returns   1 if lines with 'Missing Connection' but \n");
	   printf("             none with col 2,3,4 all zero\n");
       printf("returns   0 if a line with 'Missing Connections' and \n");
	   printf("             col 2,3,4 all 0 \n");
	   exit(-1);
   }
   else
   {
	   retcode=chk_unconnected_nets_call(argv[1]);
	   printf("Result = %d \n",retcode);

	   exit(retcode);
   }
}



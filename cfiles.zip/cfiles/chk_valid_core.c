
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

int chk_valid_core_call_out( char *infilestr, char *outfilestr)
{
int endoffile;
int result;
char thisline[300];
char a[10][120];
char b[10][120];
char c[10][120];
char tmp[10][200];

int cut;
char X[120];
char Y[120];
char mode[120];
int modeval;
FILE *file1;
FILE *outfile;
int nf;
char head[300];
char filename[300];
int val;


   file1=fopen(infilestr,"r");
   if (file1==NULL)
   {
     printf("In chk_valid_core, unable to open the input file \n",infilestr);
	 exit(-1);
   }

   outfile=fopen(infilestr,"w");
   if (outfile==NULL)
   {
     printf("In chk_valid_core, unable to open the output file \n",outfilestr);
	 exit(-1);
   }
   strncpy(filename,infilestr,120);

   strncpy(X,"0",10);
   strncpy(Y,"0",10);
   result = 0;

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

 while(endoffile==FALSE)
 {
  awk_substr(thisline,1,3,head);
  if( (strstr(thisline,"G36")!=NULL ) && (strcmp(head,"G04")!=0) && 
	  (strstr(thisline,"%")==NULL))      // G36 without G04 and %
  {
   printf("FATAL ERROR: file:%s contains G36 (polygons not allowed)\n",filename);
   result = 98;
  }
  if( ((strstr(thisline,"D01") != NULL) ||
	  (strstr(thisline,"D02") != NULL) ||
	  (strstr(thisline,"D03") != NULL) ) && (strcmp(head,"G04") !=0) && 
	  (strstr(thisline,"%" ) == NULL) ) 
  {
	split(thisline,tmp[0],tmp[1],"D");
    awk_substr(tmp[1],1,2,mode);
	modeval=atoi(mode);
    if (modeval == 1)
	{
       printf("FATAL ERROR: file:%s contains D01 (draws not allowed)\n",filename);
       result = 99;
    } 
  
    cut = 4;
  }
  else 
  {
    cut = 1;
  } 
  if ( (strstr(thisline,"X")!=NULL) && 
	   (strstr(thisline,"Y")!=NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )              // X and Y 
  {
       split(thisline,a[0],a[1],"Y");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1, strlen(a[0]), X );
       awk_substr( a[1],1,strlen(a[1]) - cut,Y) ;
      if(modeval == 3 )                          //D03X...Y...
	  {
        fprintf(outfile,"X %0.0f Y %0.0f\n", atof(X),atof(Y) );
      }
  } 
  else if ((strstr(thisline,"X")!=NULL) &&      
	   (strstr(thisline,"Y")==NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )                // X but no Y
	  
  {
      split(thisline,b[0],b[1],"X");
      awk_substr(b[1],1,strlen(b[1]) - cut,X);
      if(modeval == 3 )                          // D03X....
	  {
        fprintf(outfile,"X %0.0f Y %0.0f\n",atof(X),atof(Y)) ;
      }
  }
  else if((strstr(thisline,"X")==NULL) &&      
	   (strstr(thisline,"Y")!=NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )   
	  
  {
      split(thisline,c[0],c[1],"Y");
      awk_substr(c[1],1,strlen(c[1]) - cut,Y);
      if(modeval == 3 )                          // D03Y
	  {
        fprintf(outfile,"X %0.0f Y %0.0f\n",atof(X),atof(Y)) ;
      }
  }
  
  else if( strcmp(thisline,"D03*")==0)
  {
        fprintf(outfile,"X %0.0f Y %0.0f\n", atof(X),atof(Y));
  }

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

}
fclose(file1);
fclose(outfile);

  return(result);


}    // end chk_valid_core_call

int chk_valid_core_call( char *infilestr)
{
int endoffile;
int result;
char thisline[300];
char a[10][120];
char b[10][120];
char c[10][120];
char tmp[10][200];

int cut;
char X[120];
char Y[120];
char mode[120];
int modeval;
FILE *file1;
int nf;
char head[300];
char filename[300];
int val;


   file1=fopen(infilestr,"r");
   if (file1==NULL)
   {
     printf("In chk_valid_core, unable to open the input file \n",infilestr);
	 exit(-1);
   }

   strncpy(filename,infilestr,120);

   strncpy(X,"0",10);
   strncpy(Y,"0",10);
   result = 0;

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

 while(endoffile==FALSE)
 {
  awk_substr(thisline,1,3,head);
  if( (strstr(thisline,"G36")!=NULL ) && (strcmp(head,"G04")!=0) && 
	  (strstr(thisline,"%")==NULL))      // G36 without G04 and %
  {
   printf("FATAL ERROR: file:%s contains G36 (polygons not allowed)\n",filename);
   result = 98;
  }
  if( ((strstr(thisline,"D01") != NULL) ||
	  (strstr(thisline,"D02") != NULL) ||
	  (strstr(thisline,"D03") != NULL) ) && (strcmp(head,"G04") !=0) && 
	  (strstr(thisline,"%" ) == NULL) ) 
  {
	split(thisline,tmp[0],tmp[1],"D");
    awk_substr(tmp[1],1,2,mode);
	modeval=atoi(mode);
    if (modeval == 1)
	{
       printf("FATAL ERROR: file:%s contains D01 (draws not allowed)\n",filename);
       result = 99;
    } 
  
    cut = 4;
  }
  else 
  {
    cut = 1;
  } 
  if ( (strstr(thisline,"X")!=NULL) && 
	   (strstr(thisline,"Y")!=NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )              // X and Y 
  {
       split(thisline,a[0],a[1],"Y");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1, strlen(a[0]), X );
       awk_substr( a[1],1,strlen(a[1]) - cut,Y) ;
      if(modeval == 3 )                          //D03X...Y...
	  {
        printf("X %0.0f Y %0.0f\n", atof(X),atof(Y) );
      }
  } 
  else if ((strstr(thisline,"X")!=NULL) &&      
	   (strstr(thisline,"Y")==NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )                // X but no Y
	  
  {
      split(thisline,b[0],b[1],"X");
      awk_substr(b[1],1,strlen(b[1]) - cut,X);
      if(modeval == 3 )                          // D03X....
	  {
        printf("X %0.0f Y %0.0f\n",atof(X),atof(Y)) ;
      }
  }
  else if((strstr(thisline,"X")==NULL) &&      
	   (strstr(thisline,"Y")!=NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )   
	  
  {
      split(thisline,c[0],c[1],"Y");
      awk_substr(c[1],1,strlen(c[1]) - cut,Y);
      if(modeval == 3 )                          // D03Y
	  {
        printf("X %0.0f Y %0.0f\n",atof(X),atof(Y)) ;
      }
  }
  
  else if( strcmp(thisline,"D03*")==0)
  {
        printf("X %0.0f Y %0.0f\n", atof(X),atof(Y));
  }

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

}
fclose(file1);

  return(result);


}    // end chk_valid_core_call


int main(int argc, char **argv)
{
int retval;
	
	if (argc != 2)
	{
		printf("In chk_valid_core, wrong number of arguments \n");
		printf("Usage: chk_valid_core infile \n");
		exit(-1);
	}
	else
	{
      retval=chk_valid_core_call( argv[1]);
	  exit(retval);
	}

}   // end main


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

int chk_wb_call(char *infilestr)
{
int number_fields;

FILE *file1;
int i;
int type;
int endoffile;
char thisline[200];

   file1  = fopen(infilestr, "r");

   if (file1 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
   }

    type = 0;
     endoffile = getline(file1,thisline);
	 number_fields = split_line(thisline);
	while(endoffile == FALSE)
	{
	 i = 0;
	 while( i < (signed int) strlen( thisline) )
	 {
		 if (isupper( thisline[i] ))
		 {
			 thisline[i] = tolower(thisline[i]);
		 }
	   i += 1;
	 }
     i = 0;
	 while( i < (signed int) strlen( str_array[0]) )
	 {
		 if (islower( str_array[0][i] ))
		 {
			 str_array[0][i] = toupper(str_array[0][i]);
		 }
	   i += 1;
	 }
	 i = 0;
     while( i < (signed int) strlen( str_array[1]) )
	 {
		 if (islower( str_array[1][i] ))
		 {
			 str_array[1][i] = toupper(str_array[1][i]);
		 }
	 i += 1;
	 }
     if(( strstr(thisline,"wirebond") != NULL) && 
		 (strcmp(str_array[0],"DIE") == 0))
	 {
      type = 1;
      return(type);
     }
     if(( strstr(thisline,"part") != NULL) && 
		 (strcmp(str_array[1],"WLBI") == 0))
	 {
      type = 2;
      return(type);
     }
    
	 endoffile = getline(file1,thisline);
	 number_fields = split_line(thisline);

	}

   fclose(file1);

   return(type);

} // end chk_wb_call

/*
int main( int argc, char **argv)
{
int retcode;

	if (argc != 2)
	{
		printf("In chk_wb, wrong number of arguments \n");
		printf("Usage: chk_wb makelogfile \n");
		exit(-1);
	}
    else
	{
		retcode=chk_wb_call(argv[1]);
		printf("type = %d \n",retcode);

	}

 exit(retcode);
}

  
*/


  
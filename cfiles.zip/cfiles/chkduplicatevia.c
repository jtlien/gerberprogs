#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define MAXVIAS 500000

#include "utilprogs.h"

char duplicate[MAXVIAS][60];
int dupcount;

struct myarraystuff
{
	int count;
	char xycoord[60];
} myarray[MAXVIAS];

int myarraycount;

int get_myarray_index( char *instr)
{
int ii;

  ii =0;
  while( ii < myarraycount)
  {
	  if (strcmp(myarray[ii].xycoord,instr) == 0 )
	  {
		  return(ii);
	  }
	ii += 1;

  }

return(-1);

}  // end get_myarray_index

void add_to_myarray( char *instr)
{

if ( myarraycount < MAXVIAS)
{
	strncpy(myarray[myarraycount].xycoord,instr,60);
	myarray[myarraycount].count=1;
	myarraycount+=1;

}
else
{
	printf("Error: more than %d different via locations \n",MAXVIAS);
}

}  // add_to_myarray

int found_in_myarray( char *instr)
{
int ii;

  ii =0;
  while( ii < myarraycount)
  {
	  if (strcmp(myarray[ii].xycoord,instr) == 0 )
	  {
		  return(TRUE);
	  }
	ii += 1;

  }

return(FALSE);

}  // end found_in_myarray

int chkduplicatevia_call_out( char *infilestr, char *outfilestr)
{
char thisline[300];
char fname[300];
char FILENAME[300];
char extstr[300];
int result;
FILE *file1;
FILE *outfile;
int nf;
char indexstr[300];
char xycoord[10][200];
int i;
int endoffile;
int myindex;

    myarraycount=0;
	dupcount=0;

    file1 =fopen(infilestr,"r");
	if (file1 == NULL)
	{
		printf("In chkduplicatevia, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

    outfile =fopen(outfilestr,"w");
	if (outfile == NULL)
	{
		printf("In chkduplicatevia, unable to open the output file = %s \n",outfilestr);
		exit(-1);
	}

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    //myarray[$2,$4]++;
	strncpy(indexstr,str_array[1],120);
	strncat(indexstr,",",10);
	strncat(indexstr,str_array[3],120);

    if ( found_in_myarray( indexstr) )
	{
      myindex=get_myarray_index( indexstr);
	  strncpy(duplicate[dupcount],indexstr,60);
	  if( dupcount < MAXVIAS)
	  {
		  dupcount += 1;
	  }
	  myarray[myindex].count+=1;
	}
	else
	{
		add_to_myarray(indexstr);
	}
	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
   }

   fclose(file1);

   result = 0;
   strncpy(FILENAME,infilestr,120);

   split(FILENAME,fname,extstr,".");

   i=0;
   while( i < myarraycount )       // in myarray )
   {
      if( myarray[i].count > 1)
	  {
         result = 99;
         //duplicate[i] = myarray[i]
      }
	 i+=1;
   }
   if(result == 99)
   {
       fprintf(outfile, "version 13.0\n");
	   fprintf(outfile,"\n");
       fprintf(outfile, "setwindow pcb\n");
	   fprintf(outfile,"\n");
       fprintf(outfile, "film param\n");
       fprintf(outfile, "setwindow form.film_control\n");
       fprintf(outfile, "FORM film_control %s edit Display\n",fname);
       fprintf(outfile, "FORM film_control done\n");
	   fprintf(outfile,"\n");

       fprintf(outfile, "delete\n");
       fprintf(outfile, "setwindow form.find\n");
       fprintf(outfile, "FORM find all_off\n");
       fprintf(outfile, "FORM find vias YES\n");
       fprintf(outfile, "setwindow pcb\n");
   
	   i=0;
       while( i < dupcount )          // in duplicate)
	   {
         
            split(duplicate[i],xycoord[0],xycoord[1],",");
            fprintf(outfile,"pick grid %.4f %.4f\n",atof(xycoord[0])/10000,
				atof(xycoord[1])/10000);
	   i+=1;
       }
	  fclose(outfile);
      printf( "done\n");
   }
   return(result);

}  // chkduplicatevia_call_out


int chkduplicatevia_call( char *infilestr)
{
char thisline[300];
char fname[300];
char FILENAME[300];
char extstr[300];
int result;
FILE *file1;
int nf;
char indexstr[300];
char xycoord[10][200];
int i;
int endoffile;
int myindex;

    myarraycount=0;
	dupcount=0;

    file1 =fopen(infilestr,"r");
	if (file1 == NULL)
	{
		printf("In chkduplicatevia, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    //myarray[$2,$4]++;
	strncpy(indexstr,str_array[1],120);
	strncat(indexstr,",",10);
	strncat(indexstr,str_array[3],120);

    if ( found_in_myarray( indexstr) )
	{
      myindex=get_myarray_index( indexstr);
	  strncpy(duplicate[dupcount],indexstr,60);
	  if( dupcount < MAXVIAS)
	  {
		  dupcount += 1;
	  }
	  myarray[myindex].count+=1;
	}
	else
	{
		add_to_myarray(indexstr);
	}
	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
   }

   fclose(file1);

   result = 0;
   strncpy(FILENAME,infilestr,120);

   split(FILENAME,fname,extstr,".");

   i=0;
   while( i < myarraycount )       // in myarray )
   {
      if( myarray[i].count > 1)
	  {
         result = 99;
         //duplicate[i] = myarray[i]
      }
	 i+=1;
   }
   if(result == 99)
   {
       printf( "version 13.0\n");
	   printf("\n");
       printf( "setwindow pcb\n");
	   printf("\n");
       printf("film param\n");
       printf( "setwindow form.film_control\n");
       printf("FORM film_control %s edit Display\n",fname);
       printf("FORM film_control done\n");
	   printf("\n");

       printf( "delete\n");
       printf( "setwindow form.find\n");
       printf( "FORM find all_off\n");
       printf( "FORM find vias YES\n");
       printf( "setwindow pcb\n");
   
	   i=0;
       while( i < dupcount )          // in duplicate)
	   {
         
            split(duplicate[i],xycoord[0],xycoord[1],",");
            printf("pick grid %.4f %.4f\n",atof(xycoord[0])/10000,
				atof(xycoord[1])/10000);
	   i+=1;
       }
      printf( "done\n");
   }
   return(result);

}  // chkduplicatevia_call


int main( int argc, char **argv)
{
int retval;

	if ( argc != 2)
	{
		printf("In chkduplicatevia, wrong number of arguments \n");
		printf("Usage: chkduplicatevia infile \n");
		exit(-1);
	}
	else
	{
		retval=chkduplicatevia_call( argv[1]);
		exit(retval);
	}

}  // end main

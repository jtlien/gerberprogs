
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// Barb's version of a generic design directory clean-up
// Placed in /usr/local/bin 9/19/99
// Added auto_in.pdf on 5/17/01, changed name to cleanit
// because cleanup is now a system utility Placed in /swtools/remote/bin

void cleanit_call()
{
system("rm *.log*"); // 2>/dev/null
system("rm *.jrl*"); //  2>/dev/null
system("rm *,*"); //  2>/dev/null
rm_files_ext(".bat"); //  2>/dev/null
rm_files_ext(".bak"); // 2>/dev/null
rm_files_ext(".bkp"); // *.bkp 2>/dev/null
rm_files_ext(".bku"); // *.bku 2>/dev/null
rm_files_ext(".job"); // *.job 2>/dev/null
rm_files_ext(".LST"); // *.LST 2>/dev/null
rm_files_ext(".RSP"); // *.RSP 2>/dev/null
rm_file( "auto_in.pdf");    //  2>/dev/null
if (WINDOWS)
{
system("rm *\\auto_in.pdf"); // 2>/dev/null
}
else
{
	system("rm */auto_in.pdf");
}

rm_file("master.tag"); //2>/dev/null
printf("Cleaned!\n");

}

int main(int argc, char **argv)
{


  if (argc != 1)
  {
	  printf("In cleanit, cleanit does not take any arguments \n");
	  printf("Usage:  cleanit \n");
	  exit(-1);
  }
  else
  {
	  cleanit_call();
  }

}  // end main

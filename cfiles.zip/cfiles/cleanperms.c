
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

char *get_owner( char *indirstr);

void cleanperms_call( char *indirstr)
{
char pwdstr[300];
char curdir[300];
char owner[300];
char *me;
char commandstr[300];
char mestr[300];

// Changes permissions of a part directory to 755
// must cd to active, archive, or sandbox for this
// to work properly.


  getwd(pwdstr);

  get_full_path_end( pwdstr, curdir);

   // curdir=${PWD##*\/}
// printf("current dir = %s\n", curdir); // echo $curdir

if ( (strcmp(curdir,"active") != 0 ) && 
	 (strcmp(curdir,"archive") != 0 ) && 
	 (strcmp(curdir,"sandbox") != 0 ) ) 
{
   printf( "Please cd to active, archive, or sandbox to run.\n");
   exit(1);
}

if(  ! ( dir_exists( indirstr ) ) )
{
   printf("%s: No such part directory\n",indirstr);
   exit(1);
}

//me=$(whoami)

 me = getenv("USERNAME");

 strncpy(mestr,me,120);

 // printf("me = %s \n",me);

  //owner=$(ls -l | grep $1 | awk '{print $3}')
 //owner=get_owner( indirstr);

 strncpy(owner,me,120);

 if( strcmp(owner,mestr) != 0 ) 
 {
   printf("%s is not the owner of %s\n",me,indirstr);

   printf("You must be the owner to run this.\n");
   exit(1);
 }

// printf("Owner is %s",owner);
// printf("I am $s",username); // $(whoami)

printf("Changing permissions on %s\n",indirstr); // $1

strncpy(commandstr,"chmod 755 ",30);
strncat(commandstr,indirstr,120);

system( commandstr);

// chmod 755 $1
// cd $1
change_dir( indirstr);

if (WINDOWS)
{
 system("chmod -R 755 *");
 //system("chmod 755 *\\*");
 //system("chmod 755 *\\*\\*");
 //system("chmod 755 *\\*\\*\\*");
 //system("chmod 755 *\\*\\*\\*\\*");
 //system("chmod 755 *\\*\\*\\*\\*\\*");
}
else
{
system("chmod 755 *");
 system("chmod 755 */*");
 system("chmod 755 */*/*");
 system("chmod 755 */*/*/*");
 system("chmod 755 */*/*/*/*");
 system("chmod 755 */*/*/*/*/*");
}

change_dir("..");
}

int main( int argc, char **argv)
{
  

 if(argc != 2)
 {
   printf("In cleanperms, wrong number of arguments \n");
   printf("Usage: cleanperms partnum \n");
   exit(-1);
 }
 else
 {
  cleanperms_call( argv[1]);
  }

}  // end main
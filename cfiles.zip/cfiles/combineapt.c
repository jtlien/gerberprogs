
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAX 255


char dcodes[5000][100];

//
// Put out an error message on stderr
//
void outwarning( char *message)
{
char outline[300];

  strncpy( outline,"From combineapt:  ",40);
  strncat( outline,message,120);
  //outline = ("From combineapt: " message)
  fprintf(stderr,"%s\n", outline ); //  | "cat 1>&2" // write to stderr

} // end outwarning

void combineapt_call_out(char *infile1str, char* mainfilestr, char *outfilestr)
{
FILE *file1;
FILE *file2;
FILE *combinefile;
FILE *outfile;

char maxstr[200];

int ii;
int kk;
int Found;
int largest;
int over;
int over2;
int aptcnt;
int i;
int cnt1;
char warn[300];
char tmp[300];
int tmpval;
char dcodes[5000][100];
int nf;
int endoffile;
int debug;
char thisline[300];

    debug=0;

	_snprintf(maxstr,80,"%d",MAX);           // just remove the _ for non Microsoft

	for(ii=0; ii < 1000; ii += 1)
	{
		strncpy(dcodes[ii],"",4);
	}

    cnt1 = 10;  // start from D10
    over = 0;   // indicator for if dcode  greater than D255
   // MAX  = 255;
    aptcnt =0;
    
    // This while loop simply builds up a an array with the 'Dcodes'
     // from the aperture file and gets largest aperture dcode
     //  ************* file1 is the "TO" aperture file name (panel)************************ 

     largest = cnt1;

	 file1= fopen(infile1str,"r");
     if (file1 == NULL)
	 {
		 printf("In combine_apt, unable to open the input file = %s \n",infile1str);
		 exit(-1);
	 }

	 outfile = fopen(outfilestr,"w");
     if (outfile == NULL)
	 {
		 printf("In combile_apt, nable to open the output file = %s \n",outfilestr);
		 exit(-1);
	 }

	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

     while( endoffile == FALSE) 
	 {
         if( ((str_array[0][0] == 'D') || (str_array[0][0]== 'd')) && 
			  (isdigit(str_array[0][1]) ) )
			
		 {
	      awk_substr(str_array[0],2,10,tmp);  // only need the number so strip off the D
		  tmpval=atoi(tmp);
		  if ((tmpval > 0 ) && (tmpval < 5000 ))
		  {
			for(kk=0; kk < ( signed int) strlen( thisline) ; kk += 1)
			{
				if (thisline[kk]== '\n')
				{
					thisline[kk]= '\0';
				}
			}
            strncpy(dcodes[tmpval],thisline,120); //  = $0
		  }
		  else
		  {
			  fprintf(stderr,"Dcode index out of range, dcode = %d \n",tmpval);
			  fprintf(stderr,"Only room for 5000 apertures \n");
			  exit(-1);
		  }
	      aptcnt++;
	      if( tmpval  >  largest)  
		  { 
	          largest = tmpval;
          }
         }
         else 
		 {
	      fprintf(outfile,"%s",thisline); // $0
         }
         if(( tmpval > MAX ) && (over != 1))
		 {
	     // warn = (file1 " has D-code greater than " MAX " \"so will output file\"" )
		  strncpy(warn,infile1str,120);
		  strncat(warn,"  has D-code greater than ",40);
		  strncat(warn,"255 ",10);
		  strncat(warn," so will output file",40);
	      outwarning( warn);
	      over = 1;   //output message once
         }

     endoffile=getline(file1,thisline);
	 if (debug) { printf("Line in = %s \n",thisline); }

	 nf=split_line(thisline);

    } 

	fclose(file1);

    over = 0; //reset over 
    over2 = 0;

   combinefile= fopen("combineaptref","w");

   if (combinefile == NULL)
   {
	 printf("Unable to open the output combineaptref file \n");
	 exit(-1);
   }

 fprintf(combinefile,"%5s%5s\n","OLD", "NEW"); //  > "combineaptref" 
                                              // output header in crossref file

//start of main loop
     file2= fopen(mainfilestr,"r");
     if (file2 == NULL)
	 {
		 printf("Unable to open the input file = %s \n",mainfilestr);
		 exit(-1);
	 }
    endoffile=getline(file2,thisline);
	nf=split_line(thisline);

    while(endoffile==FALSE)
	{
       //main input file is FROM aperture file (part)
       Found = 0;

       if( ((str_array[0][0] == 'd') || (str_array[0][0] == 'D'))
		    && ( isdigit(str_array[0][1]) ) ) //             $1 ~/[Dd][0-9]/)
	   {
         while( !Found) 
		 {                               //  loop until we find aperture
	      if ( !(strlen(dcodes[cnt1]) != 0))
		  {
	         //tmp  =  ("D"cnt1) 
			  _snprintf(tmp,80,"D%d",cnt1);

	         fprintf(combinefile,"%s %s\n", str_array[0],tmp); //  > "combineaptref"
		     // newcodes[($1 "*")] = tmp   // newcodes is never used
		    // $1 = tmp                    // does this affect the next line? yep
			 strncpy(str_array[0],tmp,120);

	         // printf("%s",thisline); // $0
			 for(kk=0; kk < nf; kk += 1)    // print out the updated line
			 {
				 fprintf(outfile,"%s ",str_array[kk]);
			 }
			 if (nf > 0 ) { fprintf(outfile,"\n"); }
		     aptcnt++;
	    	 Found = 1;
             if(( cnt1 > MAX ) && (over != 1))
			 {
	            strncpy(warn,mainfilestr,120);  // second parameter is FILENAME
				strncat(warn," has D-code greater than ",40);
				strncat(warn,maxstr,30);
	            outwarning( warn);
	            over = 1;   // output message once
			 }
          }
	    else
		{
	       fprintf(outfile,"%s\n", dcodes[cnt1]);
        } //endelse

        cnt1++;

        if(( cnt1 > MAX ) && (over2 != 1))
		{
	         // strncpy(warn,OUTPUT,120);    // OUTPUT =?
			 strncpy(warn," OUTPUT file have D-code greater than ",40);
			 strncat(warn,maxstr,40);
	         outwarning( warn);
	         over2  = 1;   // output message once
		}
		 }   //end of while
	   }//end of if 

     endoffile=getline(file2,thisline);
	 if (debug) { printf("Thisline = %s \n",thisline); }
	 str_array[0][0] = '\0';   // for null lines
	 nf=split_line(thisline);

	}//end main

	fclose(file2);
    fclose(combinefile);

   for( i = cnt1; i <=  largest ; i+=1 )
   { 
      if( strlen(dcodes[i]) != 0)
	  {
	   fprintf(outfile,"%s\n",dcodes[i]);
      }
   }

   // warn = ("Total Aperture count = " aptcnt)
   _snprintf(warn,80,"Total Aperture count = %d",aptcnt);

   outwarning( warn);

   fclose(outfile);

 } // end combineapt_call_out

void combineapt_call(char *infile1str, char* mainfilestr)
{
FILE *file1;
FILE *file2;
FILE *combinefile;

char maxstr[200];

int ii;
int kk;
int Found;
int largest;
int over;
int over2;
int aptcnt;
int i;
int cnt1;
char warn[300];
char tmp[300];
int tmpval;
int nf;
int endoffile;
char thisline[300];

	_snprintf(maxstr,80,"%d",MAX);

	for(ii=0; ii < 1000; ii += 1)
	{
		strncpy(dcodes[ii],"",4);
	}

    cnt1 = 10;  // start from D10
    over = 0;   // indicator for if dcode  greater than D255
   // MAX  = 255;
    aptcnt =0;
    
    // This while loop simply builds up a an array with the 'Dcodes'
     // from the aperture file and gets largest aperture dcode
     //  ************* file1 is the "TO" aperture file name (panel)*******

     largest = cnt1;
	 file1= fopen(infile1str,"r");
     if (file1 == NULL)
	 {
		 printf("In combine apt, unable to open the input file = %s \n",infile1str);
		 exit(-1);
	 }

	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

     while( endoffile == FALSE) 
	 {
         if( ((str_array[0][0] == 'D') || (str_array[0][0]== 'd')) && 
			  (isdigit(str_array[0][1]) ) )
			
		 {
	      awk_substr(str_array[0],2,10,tmp);  // only need the number so strip off the D
		  tmpval=atoi(tmp);
		  if ((tmpval > 0 ) && (tmpval < 1000))
		  {
			for(kk=0; kk < ( signed int) strlen( thisline) ; kk += 1)
			{
				if (thisline[kk]== '\n')
				{
					thisline[kk]= '\0';
				}
			}
		//	printf("Adding %s at %d \n",thisline,tmpval);

            strncpy(dcodes[tmpval],thisline,120); //  = $0
		  }
		  else
		  {
			  fprintf(stderr,"Dcode index out of range \n");
			  exit(-1);
		  }
	      aptcnt++;
	      if( tmpval  >  largest)  
		  { 
	          largest = tmpval;
          }
         }
         else 
		 {
	      printf("%s",thisline); // $0
         }
         if(( tmpval > MAX ) && (over != 1))
		 {
	     // warn = (file1 " has D-code greater than " MAX " \"so will output file\"" )
		  strncpy(warn,infile1str,120);
		  strncat(warn,"  has D-code greater than ",40);
		  strncat(warn,"255 ",10);
		  strncat(warn," so will output file",40);
	      outwarning( warn);
	      over = 1;   //output message once
         }

     endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

    } 

	fclose(file1);

    over = 0; //reset over 
    over2 = 0;

   combinefile= fopen("combineaptref","w");

   if (combinefile == NULL)
   {
	 printf("Unable to open the output combineaptref file \n");
	 exit(-1);
   }

 fprintf(combinefile,"%5s%5s\n","OLD", "NEW"); //  > "combineaptref" 
                                              // output header in crossref file

//start of main loop
     file2= fopen(mainfilestr,"r");
     if (file2 == NULL)
	 {
		 printf("Unable to open the input file = %s \n",mainfilestr);
		 exit(-1);
	 }
    endoffile=getline(file2,thisline);
	nf=split_line(thisline);

    while(endoffile==FALSE)
	{
       //main input file is FROM aperture file (part)
       Found = 0;

       if( ((str_array[0][0] == 'd') || (str_array[0][0] == 'D'))
		    && ( isdigit(str_array[0][1]) ) ) //             $1 ~/[Dd][0-9]/)
	   {
         while( !Found) 
		 {                               //  loop until we find aperture
	      if ( !(strlen(dcodes[cnt1]) != 0))
		  {
	         //tmp  =  ("D"cnt1) 
			  _snprintf(tmp,80,"D%d",cnt1);

			  // printf("Count = %d \n",cnt1);

			  fprintf(combinefile,"%s %s\n", str_array[0],tmp); //  > "combineaptref"
		     // newcodes[($1 "*")] = tmp   // newcodes is never used
		    // $1 = tmp                    // does this affect the next line? yep
			 strncpy(str_array[0],tmp,120);

	         // printf("%s",thisline); // $0
			 for(kk=0; kk < nf; kk += 1)    // print out the updated line
			 {
				 printf("%s ",str_array[kk]);
			 }
			 if (nf > 0 ) { printf("\n"); }
		     aptcnt++;
	    	 Found = 1;
             if(( cnt1 > MAX ) && (over != 1))
			 {
	            strncpy(warn,mainfilestr,120);  // second parameter is FILENAME
				strncat(warn," has D-code greater than ",40);
				strncat(warn,maxstr,30);
	            outwarning( warn);
	            over = 1;   // output message once
			 }
          }
	     else
		 {
	       printf("%s 100 \n", dcodes[cnt1]);
         } //endelse

          cnt1++;

          if(( cnt1 > MAX ) && (over2 != 1))
		  {
	         // strncpy(warn,OUTPUT,120);    // OUTPUT =?
			 strncpy(warn," OUTPUT file have D-code greater than ",40);
			 strncat(warn,maxstr,40);
	         outwarning( warn);
	         over2  = 1;   // output message once
		  }
		 }   //end of while not found

	   }//end of if 

     endoffile=getline(file2,thisline);
	 str_array[0][0]='\0';    // for null lines
	 nf=split_line(thisline);

	}//end main while

	fclose(file2);
    fclose(combinefile);

 //  printf("cnt1 = %d largest = %d \n",cnt1, largest);

   for( i = cnt1; i <=  largest ; i+=1 )
   { 
      if( strlen(dcodes[i]) != 0)
	  {
	   printf("%s\n",dcodes[i]);
      }
   }

   // warn = ("Total Aperture count = " aptcnt)
   _snprintf(warn,80,"Total Aperture count = %d",aptcnt);

   outwarning( warn);

 } // end combineapt_call

/*
int main(int argc, char **argv)
{

	if (argc == 3)
	{
	combineapt_call(argv[1],argv[2]);
	}
	else
	{
		printf("In combineapt, wrong number of arguments \n");
		printf("Usage combineapt aptfile partfile \n");
		exit(-1);
	}


}  

*/











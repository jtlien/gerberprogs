#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void creategbr_call( char *aptfilestr, char *infilestr);

//

void convertigi_call(char *infilestr)
{
char pwd_str[300];
char tmp[300];
char tmp1[300];

 getwd(pwd_str);


// tmp1 = the present working directory
// tmp1=`pwd`

 strncpy(tmp1,pwd_str,120);

// strip off path so tmp is only directiory name and add '.apt' extension 
// i.e  tmp1 = /users/dah/95020  then tmp becomes 95020.apt
//tmp=${tmp1##*/}".apt" 
 get_full_path_end(tmp1,tmp);

 strncat(tmp,".apt",10);

while( ! (file_exists(tmp) ) )  // if the file  doesn't exist prompt until they get it right
{
 printf("Please enter aperture filename (NO extension please)\n");
 //read -r tmp1
 gets(tmp1);
 // tmp=$tmp1".apt"
 strncpy(tmp,tmp1,120);
 strncat(tmp,".apt",10);
 //printf("tmp=%s\n",tmp);


}

// awk -f /usr/local/bin/creategbr.awk -v file1=$tmp $1 
 printf("aptfile=%s\n",tmp);
 creategbr_call(tmp, infilestr);


}  // end convertigi_call


int main( int argc, char **argv)
{

 if (argc != 2)
	{
	 printf("In convertigi, wrong number of arguments\n");
	 printf("Usage: convertigi infile \n");
	 exit(-1);
	}
 else
 {
	 convertigi_call( argv[1]);
 }

} // end main

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


//
// coreclean1.5
//
//  calling syntax
//       coreclean infile  outfile
//  return values
//   0 indicates core layer had to be stripped and outfile is valid
//   1 indicates core layer did not need to be stripped and infile is valid
//  99 indicates a problem processing core layer outfile should be destroyed
//     and infile should be looked at.
//



int coreclean_call_out( char *file1str, char *outfilestr)
{
FILE *file1;
FILE *outfile;
int LPDCNT;
int LPCCNT;
int debug;
int endoffile;
char thisline[200];

   debug = 0;
   LPDCNT = 0;
   LPCCNT = 0;

  file1= fopen( file1str,"r");
  if (file1 == FALSE)
  {
	  printf("Error in coreclean, unable to open input file = %s \n",file1str);
	  exit(-1);
  }

  outfile=fopen( outfilestr,"w");
  if (outfile == FALSE)
  {
	  printf("Error in coreclean, unable to open output file = %s \n",outfilestr);
	  exit(-1);
  }

  endoffile=getline(file1,thisline);

  while((endoffile==FALSE) &&  (strstr(thisline,"%LPD") == NULL )) //$0 !~ "%LPD" ) 
  {
        if( strstr(thisline,"%LPC") != NULL) // $0 ~ "%LPC")
		{
          LPCCNT++;
        }
        fprintf(outfile,"%s",thisline); // $0
	    endoffile=getline(file1,thisline);
  }

 if( strstr(thisline,"%LPD") != NULL)   // $0 ~/%LPD/ )
 {
    LPDCNT++;
 }

  endoffile=getline(file1,thisline);

  while(endoffile==FALSE)
  {
   if( strstr(thisline,"%LPD") != NULL)
   {
     LPDCNT++;
   }

   if( strstr(thisline,"%LPC") != NULL)
   {
     LPCCNT++;
   }

   if( (LPDCNT == 2 ) && (LPCCNT == 1))
   {
     printf("%s",thisline); // $0
   }
  endoffile=getline(file1,thisline);
  }

  fclose(file1);


   if ( debug == 1)
   {
      fprintf(stderr,"LPCCNT  %d \n", LPCCNT );  // | "cat 1>&2"
      fprintf(stderr,"LPDCNT  %d \n", LPDCNT );  //  | "cat 1>&2"
   } 
   if ( LPDCNT == 2 && LPCCNT == 1)
   {
      return(0);
   }
   if ( LPDCNT == 1 && LPCCNT == 0 )
   {
      return(1);
   }
   if ( LPDCNT == 2 && LPCCNT == 2 )
   {
      return(2);
   }
   return(99);
}


int coreclean_call( char *file1str)
{
FILE *file1;
int LPDCNT;
int LPCCNT;
int debug;
int endoffile;
char thisline[200];

   debug = 0;
   LPDCNT = 0;
   LPCCNT = 0;

  file1= fopen( file1str,"r");
  if (file1 == FALSE)
  {
	  printf("Error in coreclean, unable to open input file = %s \n",file1str);
	  exit(-1);
  }


  endoffile=getline(file1,thisline);

  while((endoffile==FALSE) &&  (strstr(thisline,"%LPD") == NULL )) //$0 !~ "%LPD" ) 
  {
        if( strstr(thisline,"%LPC") != NULL) // $0 ~ "%LPC")
		{
          LPCCNT++;
        }
        printf("%s",thisline); // $0
	    endoffile=getline(file1,thisline);
  }

 if( strstr(thisline,"%LPD") != NULL)   // $0 ~/%LPD/ )
 {
    LPDCNT++;
 }

  endoffile=getline(file1,thisline);

  while(endoffile==FALSE)
  {
   if( strstr(thisline,"%LPD") != NULL)
   {
     LPDCNT++;
   }

   if( strstr(thisline,"%LPC") != NULL)
   {
     LPCCNT++;
   }

   if( (LPDCNT == 2 ) && (LPCCNT == 1))
   {
     printf("%s",thisline); // $0
   }
  endoffile=getline(file1,thisline);
  }

  fclose(file1);


   if ( debug == 1)
   {
      fprintf(stderr,"LPCCNT  %d \n", LPCCNT );  // | "cat 1>&2"
      fprintf(stderr,"LPDCNT  %d \n", LPDCNT );  //  | "cat 1>&2"
   } 
   if ( LPDCNT == 2 && LPCCNT == 1)
   {
      return(0);
   }
   if ( LPDCNT == 1 && LPCCNT == 0 )
   {
      return(1);
   }
   if ( LPDCNT == 2 && LPCCNT == 2 )
   {
      return(2);
   }
   return(99);
}

/*
int main( int argc, char **argv)
{
int tint;

  if (argc !=2)
  {
    printf("In coreclean, wrong number of arguments \n");
	printf("Usage: coreclear infile \n");
	exit(-1);
  }
  else
  {
  tint = coreclean_call( argv[1] );
   //printf("corelean return = %d \n",tint);

  exit(tint);
  }

}   

  
*/

 



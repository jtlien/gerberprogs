#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <process.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

// external declarations for routines

void dimen_call_out(char *fromfilestr, char *tofilestr );
void pins_via_call_out( char *fromfilestr, char *secondfilestr, char *tofilestr);
void strip_call_out( char *fromfilestr, char *tofilestr );
void via_info_call_out( char *fromfilestr , char *secondfilestr,char  *tofilestr );
void length_call_out( char *fromfilestr, char *tofilestr );
void number_call_out( char *fromfilestr, char *secondfilestr, char *tofilestr);
void makegbr_call(char *file1str, char *file2str);
void swapul_call_out( char *infilestr, char *outfilestr);

#include "utilprogs.h"

// char dirsep[10];


//  create_probe  rev 1.0  7/28/95
//  written by Ted Ammann
//  This script generates a PROBE file for Test from Allegro output
//  files by calling the AWK scripts below.
// Please see the .awk files for descriptions 
// modified 2/26/96 
//    added call to makegbr.awk 
//   added while loop to get aperture file name if itdoesn't exist

void create_020_call( char *infilestr)
{
char fromfilestr[300];
char tofilestr[300];
char secondfilestr[300];
char testdirstr[300];
char rdirstr[300];
char pinsfilestr[30];
char commandstr[300];
char chkfilestr[300];
char tmp[300];
char tmp1[300];

printf("Generating Test data\n");


if (WINDOWS)
{
	strncpy(dirsep,"\\",6);
}
else
{
	strncpy(dirsep,"/",10);
}

strncpy(rdirstr,"report",30);  // report/
strncat(rdirstr,dirsep,10);

strncpy(testdirstr,"test",30);   // test/
strncat(testdirstr,dirsep,10);

strncpy(fromfilestr,rdirstr,100);    // report/$1.ecl
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".ecl",10);

strncpy(tofilestr,testdirstr,100);    // test/$1.tmp1
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".tmp1",10);

strip_call_out( fromfilestr , tofilestr );  // strip report/$1.ecl test/$1.tmp1

strncpy(fromfilestr,testdirstr,100);  // test/$1.tmp1
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".tmp1",10);

strncpy(tofilestr,testdirstr,100);     // test/$1.dist
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dist",10);

length_call_out( fromfilestr, tofilestr );  // test/$1.tmp1 test/$1.disk

strncpy(fromfilestr,rdirstr,100);   // report/$1.spn
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".spn",10);

strncpy(tofilestr,testdirstr,100);    // test/$1.tmp2
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".tmp2",10);

strip_call_out( fromfilestr, tofilestr );  // strip  report/$1.spn  test/$1.tmp2

strncpy(fromfilestr,rdirstr,100);   // report/Linfo
strncat(fromfilestr,"Linfo",120);

strncpy(secondfilestr,rdirstr,100);   // report/$1.pad
strncat(secondfilestr,infilestr,120);
strncat(secondfilestr,".pad",10);

strncpy(tofilestr,testdirstr,100);    // test/vias
strncat(tofilestr,"vias",10);

via_info_call_out( fromfilestr , secondfilestr, tofilestr );

strncpy(fromfilestr,testdirstr,100);   // test/vias
strncat(fromfilestr,"vias",120);

strncpy(secondfilestr,testdirstr,100);   // test/$1.tmp2
strncat(secondfilestr,infilestr,120);
strncat(secondfilestr,".tmp2",10);

strncpy(tofilestr,testdirstr,100);    // test/sortin
strncat(tofilestr,"sortin",10);

pins_via_call_out( fromfilestr, secondfilestr, tofilestr);

strncpy(pinsfilestr,testdirstr,100);   // test/$1.pins
strncat(pinsfilestr,infilestr,120);
strncat(pinsfilestr,".pins",10);

 // | sort -db -k 6,6 > test/$1.pins

strncpy(fromfilestr,testdirstr,100);    // test/sortin
strncat(fromfilestr,"sortin",10);

strncpy(commandstr,"gnu_sort -db -k 6,6 ",40);
strncat(commandstr,fromfilestr,120);
strncat(commandstr," -o ",10);
strncat(commandstr,pinsfilestr,100);

system(commandstr);

strncpy(tofilestr,testdirstr,100);    // test/$1.pins
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".pins",10);

// sortfun_call( fromfilestr, tofilestr);   // | sort -db -k 6,6 > test/$1.pins

strncpy(fromfilestr,rdirstr,100);   // report/$1.ecl
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".ecl",12);

strncpy(tofilestr,testdirstr,100);    // test/$1.dat1
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dat1",10);

dimen_call_out(fromfilestr, tofilestr );

strncpy(fromfilestr,testdirstr,100);   // test/$1.dist
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".dist",12);

strncpy(secondfilestr,testdirstr,100);   // test/$1.pins
strncat(secondfilestr,infilestr,120);
strncat(secondfilestr,".pins",10);

strncpy(tofilestr,testdirstr,100);    // test/.dat1
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dat1",10);

number_call_out( fromfilestr, secondfilestr, tofilestr);

// tmp1 = the present working directory
//tmp1=`pwd`

getwd(tmp1);

//strip off path so tmp is only directiory name and add '.apt' extension 
//i.e  tmp1 = /users/dah/95020  then tmp becomes 95020.apt

//tmp=${tmp1##*/}".apt" 

get_full_path_end(tmp1,tmp);   // get the last part of the full path
strncat(tmp,".apt",10);

strncpy(chkfilestr,"aper/",30);
strncat(chkfilestr,tmp,120);

while ( ! (file_exists( chkfilestr) )  ) //  if the file  doesn't exist prompt until they get it right
{
 printf("Please enter aperture (in aper directory) filename (NO extension please)\n");
 gets(tmp1);
// tmp=$tmp1".apt"

 strncpy(tmp,tmp1,120);        // $tmp1.apt
 strncat(tmp,".apt",10);

 strncpy(chkfilestr,"aper/",10);  // aper/tmp
 strncat(chkfilestr,tmp,120);

}
//these three lines swap U and L in .dat file

 strncpy(fromfilestr,testdirstr,100);  // test/$1.dat
 strncat(fromfilestr,infilestr,120);
 strncat(fromfilestr,".dat",20);

 strncpy(tofilestr,testdirstr,100);      // test/data.dat
 strncat(tofilestr,"data.dat",20);

 swapul_call_out( fromfilestr,tofilestr); //  test/$1.dat ,  test/data.dat);

 rm_file(fromfilestr);   //  rm  test/$1.dat

 strncpy(fromfilestr,testdirstr,100);  // test/data.dat
 strncat(fromfilestr,"data.dat",20);

 strncpy(tofilestr,testdirstr,100);  // test/$1.dat
 strncat(tofilestr,infilestr,120);
 strncat(tofilestr,".dat",20);

 cp_file( fromfilestr, tofilestr); 
 rm_file( fromfilestr);

 // mv test/data.dat test/$1.dat

// awk -f /usr/local/bin/makegbr.awk -v file1=aper/$tmp test/$1.dat

 strncpy(tofilestr,"test/",30);
 strncat(tofilestr,infilestr,120);
 strncat(tofilestr,".dat",10);

 makegbr_call( chkfilestr, tofilestr);  // aper/$tmp    test/$1.dat

strncpy(fromfilestr,testdirstr,100);   // test/$1.tmp1
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".tmp1",12);

rm_file( fromfilestr);

strncpy(fromfilestr,testdirstr,100);   // test/$1.dist
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".dist",12);

rm_file(  fromfilestr);

strncpy(fromfilestr,testdirstr,100);   // test/$1.tmp2
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".tmp2",12);

rm_file(fromfilestr);

strncpy(fromfilestr,testdirstr,100);   // test/vias
strncat(fromfilestr,"vias",120);

rm_file(fromfilestr);

strncpy(fromfilestr,testdirstr,100);   // test/$1.pins
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".pins",12);


rm_file(fromfilestr);

printf("Complete\n");

}  // end create_probe_call

/*
int main( int argc, char **argv)
{


   if (argc != 2)
   {
	   printf("In check_probe, wrong number of arguments \n");
	   printf("Usage: check_probe infile \n");
	   exit(-1);
   }
   else
   {
	   create_020_call( argv[1]);
   }

}   // end main

*/

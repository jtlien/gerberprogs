
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void create_gbr_274x_call( char *infilestr)
{
FILE *headfile;
FILE *upperfile;
FILE *lowerfile;
FILE *file1;

int endoffile;
int jj;

char head_file_str[20];
char lower_file_str[20];
char upper_file_str[20];
char thisline[200];
int number_fields;
char field3_str[120];
int has_up;
int has_low;


    file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	}

	strncpy(head_file_str,"head.tmp",20);
	strncpy(lower_file_str,"l.gbr",20);
	strncpy(upper_file_str,"u.gbr",20);

    headfile  = fopen(head_file_str, "w");

    if (headfile == NULL)
	{
	 printf("Error: Unable to open output file = %s\n", head_file_str);
	  exit(-1);
	}

    lowerfile  = fopen(lower_file_str, "w");

    if (lowerfile == NULL)
	{
	 printf("Error: Unable to open output file = %s\n", lower_file_str);
	  exit(-1);
	}

    upperfile  = fopen(upper_file_str, "w");

    if (lowerfile == NULL)
	{
	 printf("Error: Unable to open output file = %s\n", upper_file_str);
	  exit(-1);
	}

    fprintf(headfile, "%FSLAX45Y45*MOMM*%\n" );	
    fprintf(headfile,"%IR0*IPPOS*OFA0.00000B0.00000*MIA0B0*SFA1.00000B1.00000*%\n");	
    fprintf(headfile,"%ADD500C,.1*%\n" );
    fprintf(headfile,"%ADD501C,.1*%\n");

    fclose(headfile);
	
    fprintf(upperfile, "D500*"); 
    fprintf(lowerfile,"D501*"); 

    has_up = 0;
    has_low = 0;

    endoffile = getline(file1,thisline);
    number_fields = split_line(thisline);

    while(endoffile == FALSE)
	{
	 strncpy(field3_str, str_array[3],120);
	 jj = 0;
	 while( jj < (signed int) strlen( field3_str))
	 {
	   if( islower( field3_str[jj]) )
	   {
		   field3_str[jj] = toupper( field3_str[jj]);
	   }
	   jj += 1;
	 }
     if( strstr( field3_str,"U")  != NULL)
	 {
      fprintf(upperfile,"X%.0fY%.0fD03*\n",atof(str_array[0])* 100000.0,
		            atof(str_array[1])* 100000.0); 
      has_up = 1;
	 }
     else if ( strstr( field3_str,"L") != NULL)
	 {
      fprintf(lowerfile,"X%.0fY%.0fD03*\n",atof(str_array[0]) * 100000.0,
		                         atof(str_array[1]) * 100000.0);
      has_low = 1;
	 }
     endoffile = getline(file1,thisline);
     number_fields = split_line(thisline);

	}
  fclose(file1);
  fclose(upperfile);
  fclose(lowerfile);

  if ( has_up == 1)
   {
    // system("cat head.tmp u.gbr > upper.gbr");
	  cat_files("head.tmp","u.gbr","upper.gbr");

   }
   else
   {
     // system("rm -f u.gbr");
	   rm_file("u.gbr");
   }

  if ( has_low == 1)
  {
     // system("cat head.tmp l.gbr > lower.gbr");
	  cat_files("head.tmp","l.gbr","lower.gbr");
   }
   else
   {
     //system("rm -f l.gbr");
	   rm_file("l.gbr");
   }

} // end create_gbr_274x_call


int main( int argc, char **argv)
{
char REV[300];

	if (argc != 2)
	{

		printf(" In create_gbr_274x, wrong number of arguments \n");
		printf("Usage: create_gbr_274x infile\n");
		exit(-1);
	}
	else
	{
      strncpy(REV,"0.6",10);

      printf( "Running %s %s \n",argv[1],REV);

		create_gbr_274x_call( argv[1]);
	}


}  // end main

  

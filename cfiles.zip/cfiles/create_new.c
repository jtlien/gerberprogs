#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <process.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

// external declarations for routines

void dimen_call_out(char *fromfilestr, char *tofilestr );
void pins_via1_call_out( char *fromfilestr, char *secondfilestr, char *tofilestr);
void rm_unused05_call_out( char *fromfilestr, char *tofilestr);
void strip_call_out( char *fromfilestr, char *tofilestr );
void via_new_call_out( char *fromfilestr , char *secondfilestr,char  *tofilestr );
void length_call_out( char *fromfilestr, char *tofilestr );
void number2_call_out( char *fromfilestr, char *secondfilestr, char *tofilestr);

#include "utilprogs.h"

// char dirsep[10];

//  create_probe  rev 1.0  7/28/95
//  written by Ted Ammann
//  This script generates a PROBE file for Test from Allegro output
//  files by calling the AWK scripts below.
//  Please see the .awk files for descriptions 
// modified 2/26/96 
//    added call to makegbr.awk 
//    added while loop to get aperture file name if itdoesn't exist
// rev1.1 adds call to rm_unused to remove fids & mechincal pins from .dat file
// rev1.2 released to users 11/4/98
//    changes pn.dat & unused.dat tmt from unix to dos
// rev1.3 released to users on 4/10/00
//    now calls pins_via1.awk that puts lines with only 4 fileds into unused.dat file
// rev1.4 released to users 9/26/01
//    gets rid of check for aperture file
// rev1.45 released to users 10/24/02 
//    now calls rm_unused.05   
// rev1.46 released to users on 12/13/02 tsa
//    now calls number2.awk; this fixes a bug with net numbering

void create_new_call( char *infilestr)
{
char fromfilestr[300];
char tofilestr[300];
char secondfilestr[300];
char testdirstr[300];
char rdirstr[300];
char pinsfilestr[30];
char commandstr[300];

printf("Generating Test data\n");

if (WINDOWS)
{
	strncpy(dirsep,"\\",6);
}
else
{
	strncpy(dirsep,"/",10);
}

strncpy(rdirstr,"report",30);  //  report/
strncat(rdirstr,dirsep,10);

strncpy(testdirstr,"test",30);   // test/
strncat(testdirstr,dirsep,10);

strncpy(fromfilestr,rdirstr,100);    // report/$1.ecl
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".ecl",10);

strncpy(tofilestr,testdirstr,100);     // test/$1.tmp1
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".tmp1",10);

strip_call_out( fromfilestr , tofilestr );

strncpy(fromfilestr,testdirstr,100);  // test/$1.tmp1
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".tmp1",10);

strncpy(tofilestr,testdirstr,100);    // test/$1.dist
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dist",10);

length_call_out( fromfilestr, tofilestr );

strncpy(fromfilestr,rdirstr,100);   // report/$1.spn
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".spn",10);

strncpy(tofilestr,testdirstr,100);    // test/$1.tmp2
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".tmp2",10);

strip_call_out( fromfilestr, tofilestr );

strncpy(fromfilestr,rdirstr,100);   // report/Linfo
strncat(fromfilestr,"Linfo",120);

strncpy(secondfilestr,rdirstr,100);   // report/$1.pad
strncat(secondfilestr,infilestr,120);
strncat(secondfilestr,".pad",10);

strncpy(tofilestr,testdirstr,100);    // test/vias
strncat(tofilestr,"vias",10);

via_new_call_out( fromfilestr , secondfilestr, tofilestr );

strncpy(fromfilestr,testdirstr,100);   // test/vias
strncat(fromfilestr,"vias",120);

strncpy(secondfilestr,testdirstr,100);   // test/$1.tmp2
strncat(secondfilestr,infilestr,120);
strncat(secondfilestr,".tmp2",10);

strncpy(tofilestr,testdirstr,100);    // test/sortin
strncat(tofilestr,"sortin",10);

pins_via1_call_out( fromfilestr, secondfilestr, tofilestr);

strncpy(pinsfilestr,testdirstr,100);   // test/$1.pins
strncat(pinsfilestr,infilestr,120);
strncat(pinsfilestr,".pins",10);

 // | sort -db -k 6,6 > test/$1.pins

strncpy(fromfilestr,testdirstr,100);    // test/sortin
strncat(fromfilestr,"sortin",10);

strncpy(commandstr,"gnu_sort -db -k 6,6 ",40);
strncat(commandstr,fromfilestr,120);
strncat(commandstr," -o ",10);
strncat(commandstr,pinsfilestr,100);

system(commandstr);

strncpy(tofilestr,testdirstr,100);    // test/$1.pins
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".pins",10);

// sortfun_call( fromfilestr, tofilestr);   // | sort -db -k 6,6 > test/$1.pins

strncpy(fromfilestr,rdirstr,100);   // report/$1.ecl
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".ecl",12);

strncpy(tofilestr,testdirstr,100);    // test/$1.dat1
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dat1",10);

dimen_call_out(fromfilestr, tofilestr );

strncpy(fromfilestr,testdirstr,100);   // test/$1.dist
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".dist",12);

strncpy(secondfilestr,testdirstr,100);   // test/$1.pins
strncat(secondfilestr,infilestr,120);
strncat(secondfilestr,".pins",10);

strncpy(tofilestr,testdirstr,100);    // test/$1.dat1
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dat1",10);

number2_call_out( fromfilestr, secondfilestr, tofilestr);

strncpy(fromfilestr,testdirstr,100);   // test/$1.dat1
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".dat1",12);

strncpy(tofilestr,testdirstr,100);    // test/$1.dat
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dat",10);

rm_unused05_call_out( fromfilestr, tofilestr);

// ux2dos tmp.dat > test/$1.dat
// rm tmp.dat

if( file_exists( "unused.dat" ) )  // unused.dat may be created by rm_unused_call_out
{
   // ux2dos unused.dat > test/unused.dat  
	cp_file("unused.dat", tofilestr);
   rm_file("unused.dat");
}

//  tmp1 = the present working directory
// tmp1=`pwd`

strncpy(fromfilestr,testdirstr,100);   // test/$1.tmp1
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".tmp1",12);

rm_file( fromfilestr);

strncpy(fromfilestr,testdirstr,100);   // test/$1.dist
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".dist",12);

rm_file(  fromfilestr);

strncpy(fromfilestr,testdirstr,100);   // test/$1.dist
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".tmp2",12);

rm_file(fromfilestr);

strncpy(fromfilestr,testdirstr,100);   // test/vias
strncat(fromfilestr,"vias",12);

rm_file(fromfilestr);

strncpy(fromfilestr,testdirstr,100);   // test/$1.pins
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".pins",12);


rm_file(fromfilestr);

strncpy(fromfilestr,testdirstr,100);   // test/$1.dat1
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".dat1",12);

rm_file(fromfilestr);


printf("Complete\n");

}  // end create_new1.46


int main( int argc, char **argv)
{

   if (argc != 2)
   {
	   printf("In create_new, version 1.46 wrong number of arguments \n");
	   printf("Usage: create_new infile \n");
	   exit(-1);
   }
   else
   {
	   create_new_call(argv[1]);
   }

}  // end main
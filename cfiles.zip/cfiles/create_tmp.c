#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <process.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

// external declarations for routines

void dimen_call_out(char *fromfilestr, char *tofilestr );
void pins_via1_call_out( char *fromfilestr, char *secondfilestr, char *tofilestr);
void rm_unused_call_out( char *fromfilestr, char *tofilestr);
void strip_call_out( char *fromfilestr, char *tofilestr );
void via_tmp_call_out( char *fromfilestr , char *secondfilestr,char  *tofilestr );
void length_call_out( char *fromfilestr, char *tofilestr );
void number2_call_out( char *fromfilestr, char *secondfilestr, char *tofilestr);

//!/bin/ksh
//  create_probe  rev 1.0  7/28/95
//  written by Ted Ammann
//  This script generates a PROBE file for Test from Allegro output
//  files by calling the AWK scripts below.
//  Please see the .awk files for descriptions 
// modified 2/26/96 
//    added call to makegbr.awk 
//    added while loop to get aperture file name if itdoesn't exist
// rev1.1 adds call to rm_unused to remove fids & mechanical pins from .dat file
// rev1.2 released to users 11/4/98
//    changes pn.dat & unused.dat tmt from unix to dos
// rev1.3 released to users on 4/10/00
// now calls pins_via1.awk that puts lines with only 4 fileds into unused.dat file
// rev1.4 released to users 9/26/01
// gets rid of check for aperture file

void create_tmp_call(char *infilestr)
{
char rmfilestr[300];
char fromfilestr[300];
char tofilestr[300];
char rdirstr[300];
char testdirstr[300];
char basestr[300];
char secondfilestr[300];
char pinsfilestr[300];
char commandstr[300];

strncpy(basestr,infilestr,120);

printf("Generating Test data\n");

strncpy(rdirstr,"report",30);  //  report/
strncat(rdirstr,dirsep,10);

strncpy(testdirstr,"test",30);   // test/
strncat(testdirstr,dirsep,10);

strncpy(fromfilestr,rdirstr,100);    // report/$1.ecl
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".ecl",10);

strncpy(tofilestr,testdirstr,100);     // test/$1.tmp1
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".tmp1",10);

strip_call_out( fromfilestr , tofilestr );

strncpy(fromfilestr,testdirstr,100);  // test/$1.tmp1
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".tmp1",10);

strncpy(tofilestr,testdirstr,100);    // test/$1.dist
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dist",10);

length_call_out( fromfilestr, tofilestr );
//awk -f /usr/local/bin/strip.awk report/$1.ecl >  test/$1.tmp1
//awk -f /usr/local/bin/length.awk test/$1.tmp1 > test/$1.dist

strncpy(fromfilestr,rdirstr,100);   // report/$1.spn
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".spn",10);

strncpy(tofilestr,testdirstr,100);    // test/$1.tmp2
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".tmp2",10);

strip_call_out( fromfilestr, tofilestr );

// awk -f /usr/local/bin/strip.awk report/$1.spn > test/$1.tmp2

strncpy(fromfilestr,rdirstr,100);   // report/Linfo
strncat(fromfilestr,"Linfo",120);

strncpy(secondfilestr,rdirstr,100);   // report/$1.pad
strncat(secondfilestr,infilestr,120);
strncat(secondfilestr,".pad",10);

strncpy(tofilestr,testdirstr,100);    // test/vias
strncat(tofilestr,"vias",10);

via_tmp_call_out( fromfilestr , secondfilestr, tofilestr );

// gawk -f /usr/local/bin/via_tmp.awk -v file1=report/Linfo report/$1.pad > test/vias

strncpy(fromfilestr,testdirstr,100);   // test/vias
strncat(fromfilestr,"vias",120);

strncpy(secondfilestr,testdirstr,100);   // test/$1.tmp2
strncat(secondfilestr,infilestr,120);
strncat(secondfilestr,".tmp2",10);

strncpy(tofilestr,testdirstr,100);    // test/sortin
strncat(tofilestr,"sortin",10);
pins_via1_call_out( fromfilestr, secondfilestr, tofilestr);

// awk -f /usr/local/bin/pins_via1.awk -v file1=test/vias test/$1.tmp2 | sort -db -k 6,6 > test/$1.pins

strncpy(pinsfilestr,testdirstr,100);   // test/$1.pins
strncat(pinsfilestr,infilestr,120);
strncat(pinsfilestr,".pins",10);

 // | sort -db -k 6,6 > test/$1.pins

strncpy(fromfilestr,testdirstr,100);    // test/sortin
strncat(fromfilestr,"sortin",10);

strncpy(commandstr,"gnu_sort -db -k 6,6 ",40);
strncat(commandstr,fromfilestr,120);
strncat(commandstr," -o ",10);
strncat(commandstr,pinsfilestr,100);

system(commandstr);

strncpy(tofilestr,testdirstr,100);    // test/$1.pins
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".pins",10);

// sortfun_call( fromfilestr, tofilestr);   // | sort -db -k 6,6 > test/$1.pins

strncpy(fromfilestr,rdirstr,100);   // report/$1.ecl
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".ecl",12);

strncpy(tofilestr,testdirstr,100);    // test/$1.dat1
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dat1",10);

dimen_call_out(fromfilestr, tofilestr );

strncpy(fromfilestr,testdirstr,100);   // test/$1.dist
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".dist",12);

strncpy(secondfilestr,testdirstr,100);   // test/$1.pins
strncat(secondfilestr,infilestr,120);
strncat(secondfilestr,".pins",10);

strncpy(tofilestr,testdirstr,100);    // test/$1.dat1
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dat1",10);

number2_call_out( fromfilestr, secondfilestr, tofilestr);

strncpy(fromfilestr,testdirstr,100);   // test/$1.dat1
strncat(fromfilestr,infilestr,120);
strncat(fromfilestr,".dat1",12);

strncpy(tofilestr,testdirstr,100);    // test/$1.dat
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dat",10);

rm_unused_call_out( fromfilestr, tofilestr);

//awk -f /usr/local/bin/dimen.awk report/$1.ecl > test/$1.dat1
//awk -f /usr/local/bin/number.awk -v file1=test/$1.dist test/$1.pins >> test/$1.dat1
//rm_unused test/$1.dat1 > tmp.dat 

strncpy(tofilestr,"test/",20);    // test/$1.dat
strncat(tofilestr,infilestr,120);
strncat(tofilestr,".dat",10);

cp_file("tmp.dat", tofilestr);   // > test/$1.dat
rm_file( "tmp.dat");

if( file_exists(  "unused.dat" ) )
{
   cp_file("unused.dat", "test/unused.dat");
   
   rm_file( "unused.dat");
}

//  tmp1 = the present working directory
//tmp1=`pwd`

// done

strncpy( rmfilestr,"test/",30);
strncat( rmfilestr,basestr,120);
strncat( rmfilestr,".tmp1",10);

rm_file( rmfilestr);

//rm  test/$1.tmp1

strncpy( rmfilestr,"test/",30);
strncat( rmfilestr,basestr,120);
strncat( rmfilestr,".dist",10);

rm_file( rmfilestr);

// rm  test/$1.dist 

strncpy( rmfilestr,"test/",30);
strncat( rmfilestr,basestr,120);
strncat( rmfilestr,".tmp2",10);

rm_file(rmfilestr);

//rm test/$1.tmp2 

strncpy( rmfilestr,"test/",30);
strncat( rmfilestr,"vias",12);

rm_file(rmfilestr);

//rm test/vias

strncpy( rmfilestr,"test/",30);
strncat( rmfilestr,basestr,120);
strncat( rmfilestr,".pins",10);

rm_file(rmfilestr);

//rm test/$1.pins

strncpy( rmfilestr,"test/",30);
strncat( rmfilestr,basestr,120);
strncat( rmfilestr,".dat1",10);

rm_file(rmfilestr);

// rm test/$1.dat1
printf("Complete\n");

}  // end create_tmp_call


int main( int argc, char **argv)
{

   if (argc != 2)
   {
	   printf("In create_tmp,  wrong number of arguments \n");
	   printf("Usage: create_tmp infile \n");
	   exit(-1);
   }
   else
   {
	   create_tmp_call(argv[1]);
   }

}  // end main
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAXDCODE 900

#include "utilprogs.h"

char test[3000][120];
int dcodes[1000];


void creategbr_call(char *aptfilestr, char *infilestr)
 {
int i;
int ll,kk;
char thisline[300];
FILE *file1;
FILE *lowerfile;
FILE *aptfile;
char lower[200];
char upper[200];

double MULTIPLIER;
int units;
int MltCnt;
int AperExists;
int endoffile;
int cnt1;
int Found;
char MltCntStr[120];
int number_fields;
char tempstr[120];
double xval;
double yval;
int stop;
int tmp;
char filename[120];
char beginstr[200];
int debug;

// initialize test

       debug=0;

       for( i = 0 ; i < 2000;i++)
	   {
	    test[i][0] = 0;

       }
       // initialize dcodes
       for( i = 0 ; i < 900;i++)
	   {
	    dcodes[i] = -1;

       }

	  strncpy(filename,infilestr,120); // FILENAME is argv[1]
      // split (FILENAME,a,".");   

	  //printf("filename = %s \n",filename);

	  split(filename,lower,upper,".");

	  strcat(lower,".gbr");

	  // printf("lower = %s \n",lower);

      file1 =fopen(infilestr,"r");

	  if (debug) { printf("opening %s for read \n",infilestr); }

	  if (file1 == NULL)
	  {
		  printf("In creategbr, Unable to open the input file %s \n",infilestr);
		  exit(-1);
	  }


       // strip off nine dummy lines
       for( i = 0 ; i < 9 ;i++)
	   {
	   getline(file1, thisline);
       }

	 //  printf("Opening file = %s \n",lower);

	  lowerfile =fopen(lower,"w");

	  if (lowerfile == NULL)
	  {
		  printf("Unable to open the output file %s \n",lower);
		  exit(-1);
	  }
      // the while loop below simply looks at the aperture file
      // (held in file1) to determine the units. If it can't find millimeters
      // INCHES is assumed.  It also find the format line  so we know how to scale the data

      Found = 0;  //used to stop the while loop when we have the info we want

	  aptfile=fopen(aptfilestr,"r");
	  if (aptfile==NULL)
	  {
		  printf("Unable to open the input aperture file = %s \n", aptfilestr);
		  exit(-1);
	  }

      endoffile = getline(aptfile,thisline);
	  number_fields = split_line(thisline);

      while( (endoffile==FALSE ) && (!Found))
	  {
	   if( strstr(thisline,"APTUNITS") != NULL )
	   {                                          // get the units 
               if( (strcmp(str_array[1],"mm") == 0) || 
				       (strcmp(str_array[1],"MM")== 0)) 
			   {
	            units = 1;
		        MULTIPLIER = .0254;
               }
               else
			   {
	            units = 2;
		        MULTIPLIER = .001;
               }
	   }
      if( strstr(thisline, "FORMAT") != NULL)
	  {                                     // get the scale factor 
	      Found= 1;
	      split(str_array[1],beginstr,MltCntStr,".");  // split at decimal point 
	                     // we want the number to the right of decimal point
           MltCnt=atoi(MltCntStr);
	  }
	  endoffile = getline(aptfile,thisline);
	  number_fields = split_line(thisline);

     } 

	 fclose(aptfile);

	// printf("units = %d MULTIPLIER=%f MltCnt=%d\n",units, MULTIPLIER, MltCnt);
     // adjust MULTIPLIER based on MltCnt found above
     // (if format is x.4 then scale data in xxx.dat by 10000) 

     for( i =0 ; i < MltCnt ; i++)
	 {
           MULTIPLIER = MULTIPLIER * 10;
     }

     // This while loop simply builds up an array with the 'Dcodes'
     // from the aperture file

     stop = 0;  // count of number apertures found
     AperExists = 0;

	 aptfile=fopen(aptfilestr,"r");

     endoffile = getline(aptfile,thisline);
	 number_fields = split_line(thisline);

     while( (endoffile==FALSE)  && (stop < 1)) 
	 {
       if(( ( str_array[0][0] == 'D') || (str_array[0][0]== 'd')) 
		    && (isdigit( str_array[0][1] )))
		
	   {
	   // tmp = substr(str_array[1],2);  only need the number so strip off the D
	   ll =0;
	   for(kk=1;kk< (signed int) strlen(str_array[0]); kk +=1)
	   { 
		   tempstr[ll]=str_array[0][kk];
		   ll += 1;
	   }
	   tempstr[ll] = 0;

          // dcodes[tmp] = tmp;
	   tmp = atoi(tempstr);
       if (tmp < MAXDCODE )
	   {
	   dcodes[tmp] = tmp;
	   }
	   else
	   {
		   printf("D code = %d is greater than %d\n",tmp, MAXDCODE);
		   printf("In line = %s \n",thisline);

	   }
	   if (strstr(str_array[1],"test") != NULL )
	   {     
		   // check to see if the test apertures exist;
		   // if so prevent processing below
           // if the apertures exist store them so we can write 
		   // them to the gerber files
		   if (stop < 2000 )
		   {
	       strncpy(test[stop],str_array[0],120); 
		   stop++;
	      AperExists = 1;
		   }
		   else
		   {
			printf("Number of apetures exceeds 2000 \n");
		   }

	   }
	   }    // D followed by digit

      endoffile = getline(aptfile,thisline);
	  number_fields = split_line(thisline);

	 // printf("this line = %s \n", thisline);

     }
   
	fclose(aptfile);

    // if test apertures don't exist; find  unused Dcodes to use
    if(!AperExists )
	{
       cnt1 = 255; // work backwards from 255
       stop = 0; //  count of number apertures found
       while( (cnt1 >= 10) && ( stop <  1 ))
	   {  // loop until we find two apertures or we run out of apertures to look at
	     if ( dcodes[cnt1] == -1)
		 {
		  sprintf(tempstr,"D%d",cnt1);
          if (stop < 2000)
		  {
	      strncpy(test[stop],tempstr,120);     // store valid Dcodes in array 'test'
	      stop++;
		  }
		  else
		  {
			  printf("Number of apertures exceeds 2000 \n");
		  }

		 }
       cnt1--;
       }
    }
   

    // if two apertures exist then upper and lower get their own Dcode
    // else if only 1 aperture available then upper and lower use the same Dcode
    // else default to D10

    // reopen file1 as write append
      aptfile =fopen(aptfilestr,"a");

	  if (aptfile == NULL)
	  {
		  printf("Unable to open the output file (append) %s \n",aptfilestr);
		  exit(-1);
	  }

    if( stop == 1 )
	{    
       if(!AperExists)
	   {    // if apertures are new then update aperture file else only write to gerber files
          if (units == 1) 
		  {
             fprintf(aptfile,"%s %s\n",test[0],
			 "test                       f Square   .15     .15");
          }
          else 
		  {
	     fprintf(aptfile,"%s %s\n",test[0],
			 " test                        f Square   .005     .005");
          }
       }
       fprintf(lowerfile,"G54%s*\n",test[0]);
    }
    else
	{
       fprintf(lowerfile,"G54D10*\n");  // both layers get same dcode D10
    }
   fclose(aptfile);   // close again


// START OF MAIN
// Scale the x-y coordinates in $1 and $2 by the MULTIPLIER found above and write
// to correct output gerber file. 

   endoffile=getline(file1,thisline);
  number_fields=split_line(thisline);

   while(endoffile==FALSE)
   {
	if(strstr(str_array[0],"-1") == NULL)  // -1 not found
	{
		if (debug) { printf("%s %s %s \n",str_array[0], str_array[1], str_array[2]); }

	   xval = atof( str_array[1]);
	   yval = atof( str_array[2]);

       fprintf(lowerfile,"X%0.0fY%0.0fD03*\n",xval*MULTIPLIER,yval*MULTIPLIER);

    }
    endoffile=getline(file1,thisline);
	number_fields=split_line(thisline);

   }
fclose(lowerfile);
fclose(file1);

}  // end creategbr_call

/*
int main( int argc, char **argv)
{

	if ( argc != 3)
	{
      printf("In creategbr, wrong number of arguments \n");
	  printf("Usage: creategbr aptfile infile \n");
	  exit(-1);

	}
	else
	{
		creategbr_call( argv[1], argv[2]);
	}

} // end main  

  
*/


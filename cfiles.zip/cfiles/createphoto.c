#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// progname=${0##*/}
// USAGE="usage: $progname filename "
// EXAMPLE="\tex:  $progname layers" 

// read in the layer .cntl file and create appropriate photo files
//   layer.cntl has 8 columns
//    NAME FILENAME TYPE MFG  PHOTO LAYER MASKREV  PCMLAYER
//
int nf;
char thisline[200];
char str_array[120][120];
FILE *file1;
int endoffile;

char name_str[120];
char myfile_str[120];
char type_str[120];
char mfg_str[120];
char photo_str[120];
char layer_str[120];
char maskrev_str[120];
char pcmlayer_str[120];
char usage_str[120];
char example_str[120];
char outfilename[120];
char basename[200];
int kk;
char myfile_test_str[200];
char type_test_str[200];

void cp_file(  char *infile, char *outfile)
{
char buf[1024];
FILE *f_from;
FILE *f_to;


    /* copy source file to target file, line by line. */

/* open the source and the target files. */
    f_from = fopen(infile, "r");
    if (!f_from) {
	fprintf(stderr, "Cannot open source file: %s",infile);
	perror("");
	exit(1);
    }
    f_to = fopen(outfile, "w+");
    if (!f_to) {
	fprintf(stderr, "Cannot open target file: %s ",outfile);
	perror("");
	exit(1);
    }

/* copy source file to target file, line by line. */

    while (fgets(buf, 512, f_from)) 
	{
	 if (fputs(buf, f_to) == EOF)
	 {  /* error writing data */
	    fprintf(stderr, "Error writing to target file: ");
	    perror("");
	    exit(1);
	 }
    }
   fclose(f_from);
   fclose(f_to);
	
}  // cp_file

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline


void createphoto_call( char *file1str)
{
char *dotptr;
FILE *file1;
int endoffile;

char name_str[120];
char myfile_str[120];
char type_str[120];
char mfg_str[120];
char photo_str[120];
char layer_str[120];
char maskrev_str[120];
char pcmlayer_str[120];
char outfilename[120];
char basename[200];
int kk;
char myfile_test_str[200];
char type_test_str[200];

   
	file1 = fopen(file1str,"r");
    if ( file1 != NULL )
	{

	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

	 while(endoffile == FALSE)
	 {
         strncpy(name_str,str_array[0],50);
		 strncpy(myfile_str,str_array[1],50);
		 strncpy(type_str,str_array[2],50);
		 strncpy(mfg_str,str_array[3],50);
		 strncpy(photo_str,str_array[4],50);
		 strncpy(layer_str,str_array[5],50);
		 strncpy(maskrev_str,str_array[6],50);
		 strncpy(pcmlayer_str,str_array[7],50);

         for(kk=0; kk < strlen(type_str); kk += 1)
		 {
			 type_test_str[kk] = toupper(type_str[kk]);
		 }
		 type_test_str[kk] = 0;

         for(kk=0; kk < strlen(myfile_str); kk += 1)
		 {
			 myfile_test_str[kk] = toupper(myfile_str[kk]);
		 }
		 myfile_test_str[kk] = 0;

	     if (( strcmp(myfile_test_str,"NA") != 0 ) && (strcmp(type_test_str,"PS") != 0 ))
		 {
	      
			strncpy(basename,myfile_str,120);
			dotptr=strstr(basename,".");
			*dotptr=0;

		    strncpy(outfilename,basename,100);
			strncat(outfilename,".pho",10);

	       if(strcmp(photo_str,"PosLg") == 0 )
		   {
			   cp_file("photolg.gbr",  outfilename); // ${myfile%.*}.pho;
		   }
		   if(strcmp(photo_str,"PosSm") == 0 )
		   {
			   cp_file("photosm.gbr",  outfilename);
		   }
	       if(strcmp(photo_str,"NegLg") == 0 )
		   {
			   cp_file("revphotolg.gbr", outfilename);
		   } 
		  if(strcmp(photo_str,"NegSm") == 0 )
		   {
			   cp_file("revphotosm.gbr", outfilename);
		   }    
		   
		 }

      endoffile=getline(file1,thisline);
	  nf=split_line(thisline);
	 }
	 fclose(file1);
	}
    else
	{
       printf("File could not open for read = %s \n",file1str);
	   exit(-1);
    }

}   // end createphoto_call

int main( int argc, char **argv)
{
char usage_str[120];
char example_str[120];

	if (argc == 2)
	{
	  createphoto_call(argv[1] );
	}
	else
	{
     strncpy(usage_str,"usage: createphoto filename ",60);
     strncpy(example_str,"    ex: createphoto layers",40);
 
     printf( "incorrect number of arguments\n");
     printf( "%s \n %s \n", usage_str,example_str);
   }

}
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


#include "utilprogs.h"

void rmdirver( char *instr)
{
	if (dir_exists( instr) )
	{
	  //printf("removing directory %s \n",instr);
	  rmdir(instr);
	}
	else
	{
		printf("rmdir: %s: No such file or directory \n",instr);
	}

}

void deleter09_call( char *partnumstr)
{
char x[40];
char vers[40];
char fromfilestr[300];

// Version 0.5
// Sept 25, 1997
// Version 0.6
// Sept 29, 1997
// Verion 0.9
// Dec 23, 1997
// Version 0.91
// Feb 24, 1998
// Version 0.93
// Mar 28, 1999

strncpy(vers,"0.93",10);

// One last chance to back out!

if (WINDOWS)
{
	strncpy(dirsep,"\\",4);
}
else
{
	strncpy(dirsep,"/",4);
}

strncpy(x,"",10);

while( (strcmp(x,"y") != 0 )  && (strcmp(x,"n") != 0 )) 
{
   printf("Are you sure you want to delete %s? (y/n)",partnumstr);
   gets(x);
}

if( strcmp(x,"n") == 0 ) 
{
      exit(1);
}

printf("Deleting directories...\n");

change_dir( partnumstr); //  $1
rm_dir_files("area");

strncpy(fromfilestr,"area",20);   // area/analysis
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"analysis",20);

rm_dir_files( fromfilestr); // area/analysis/*

strncpy(fromfilestr,"area",20);   // area/log
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"log",10);

rm_dir_files( fromfilestr); // area/log

rm_dir_files("control");


strncpy(fromfilestr,"raw",20);   // raw/mech/src
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"mech",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"src",10);


rm_dir_files( fromfilestr);

//rm -f mech/src
rm_dir_files("padstack");
rm_dir_files("report"); 
rm_dir_files("symbols"); // 

rmdirver("274x");
rmdirver("aper");
strncpy(fromfilestr,"area",20);  // area/array
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"array",20);
rmdirver(fromfilestr);

// rmdir area/array

strncpy(fromfilestr,"area",20);  // area/analysis
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"analysis",20);
rmdirver(fromfilestr);

// rmdir area/analysis

strncpy(fromfilestr,"area",20);    // area/log
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"log",20);
rmdirver(fromfilestr);

// rmdir area/log

strncpy(fromfilestr,"area",20);    // area/mesh
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"mesh",20);
rmdirver(fromfilestr);

// rmdir area/mesh

rmdirver("area");
rmdirver("artwork");

strncpy(fromfilestr,"cam",20);  // cam/cam-exceptions
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"cam-exceptions",30);

rmdirver(fromfilestr);

//rmdir cam/cam-exceptions
rmdirver("cam");
rmdirver("control");
rmdirver("devices");
rmdirver("drill");
rmdirver("laser");
strncpy(fromfilestr,"mech",10);  // mech/dwg
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"dwg",10);

rmdirver( fromfilestr);

// rmdir("mech/dwg

strncpy(fromfilestr,"mech",10);  // mech/dxf
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"dxf",10);

rmdirver(fromfilestr);

// rmdir("mech/dxf

strncpy(fromfilestr,"mech",10);  // mech/dwf
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"dwf",10);

rmdirver(fromfilestr);

// rmdir("mech/dwf

rmdirver("mech");
rmdirver("mfg");
rmdirver("models");
rmdirver("netlist");
rmdirver("pre-bias");
rmdirver("padstack");

strncpy(fromfilestr,"raw",10);  // raw/mech/src
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"mech",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"src",10);

rmdirver(fromfilestr);   // raw/mech/src

strncpy(fromfilestr,"raw",10);  // raw/mech
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"mech",10);
rmdirver(fromfilestr);   // raw/mech

rmdirver("raw");
rmdirver("report");
rmdirver("review");
rmdirver("scm");
rmdirver("script");
strncpy(fromfilestr,"symbols",20); 
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"script",20);
rmdirver( fromfilestr);

strncpy(fromfilestr,"symbols",30);  // symbols/script
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"script",10);
//rmdir(" symbols/script
rmdirver("symbols");
rmdirver("test");


// Final check on file deletion
//x=0

strncpy(x,"",10);

while ( (strcmp(x,"y") != 0 ) && (strcmp(x,"n") != 0 ) )  //
{
   printf( "Ready to delete top-level files? (y/n) ");
   gets( x);
}

if( strcmp(x,"n") == 0 ) 
{
      exit(1);
}

printf("Deleting top-level files...\n");
rm_file("makeart");
rm_file("balance");
rm_file("makelog"); 
rm_file("panelize");
rm_files_ext(".txt"); // *.txt
rm_files_ext(".mcm"); // *.mcm temp?
system("rm -f temp?");                    // temp?

change_dir(".."); 
rmdir( partnumstr); // $1

printf("Done!\n");


}  // end deleter_call



int main( int argc, char **argv)
{

// Check for correct invocation
if(argc != 2)
{
      printf(" Usage: deleter partnumber \n");
      exit(1);
}

// Check for existence of specified directory

if( ! dir_exists( argv[1]) )
{
    printf( "Error in deleter, %s: No such directory!\n",argv[1]);
    exit(1);
}
else
{
   deleter09_call(argv[1]);
}

}  // end main
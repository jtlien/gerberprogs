#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  dimen.awk  rev 1.0  2/16/96
//  written by Ted Ammann

// This program is meant to work on the Allegro .ecl file

//  The results from dimen.awk are meant to be redirected (UNIX ">") to
//  another file for further processing

// The output of this file is one line indicating the units of the design.
// Is is meant to be header in the test/???.dat file

// The BEGIN section of this program simply looks for a line in the input
// file that contains the word 'dimensions'. If it finds that line it outputs
// ( to the re-direct stdout)the correct fields of that line.  If it can't 
// the find line it sends and errori message to stderr



void dimen_call_out( char *infilestr, char *outfilestr)
{
int number_fields;
int Found;
FILE *file1;
FILE *outfile;
int endoffile;
char thisline[200];


     Found = 0; // a variable to stop the while loop 
	            // (only need to find the first line with dimension)

     file1  = fopen(infilestr, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	 }
	 
	 outfile  = fopen(outfilestr, "w");

     if (outfile == NULL)
	 {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
	 }

      endoffile = getline(file1,thisline);
 	  number_fields = split_line(thisline);

     while(( endoffile == FALSE ) && (!Found ))
	 {
       if( ( strstr(thisline,"Dimensions") != NULL) || 
		    (strstr(thisline,"dimensions") != NULL))
	   {                     // I found the line output the right fields
         fprintf(outfile,"%s %s %s",str_array[1],str_array[2],str_array[3]); 
         Found = 1;
	   }
	  endoffile = getline(file1,thisline);
	  number_fields = split_line(thisline);
	 }

    fclose(file1);
    fclose(outfile);

    if( !Found)
	{                 // Couldn't find the line output Error Message
		               // write  to stderr
         fprintf(stderr,"UNITS can not be determined\n");
		 
         fprintf(stderr,"Please add a line to top of /test/???.dat file\n" ); 
         fprintf(stderr,"dimensions in mm/inches \n" );
     }


} // end dimen_call_out

void dimen_call( char *infilestr)
{
int number_fields;
int Found;
FILE *file1;
int endoffile;
char thisline[200];


     Found = 0; // a variable to stop the while loop 
	            // (only need to find the first line with dimension)

     file1  = fopen(infilestr, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	 }

      endoffile = getline(file1,thisline);
 	  number_fields = split_line(thisline);

     while(( endoffile == FALSE ) && (!Found ))
	 {
       if( ( strstr(thisline,"Dimensions") != NULL) || 
		    (strstr(thisline,"dimensions") != NULL))
	   {                     // I found the line output the right fields
         printf("%s %s %s",str_array[1],str_array[2],str_array[3]); 
         Found = 1;
	   }
	  endoffile = getline(file1,thisline);
	  number_fields = split_line(thisline);
	 }

    fclose(file1);

    if( !Found)
	{                 // Couldn't find the line output Error Message
		               // write  to stderr
         fprintf(stderr,"UNITS can not be determined\n");
		 
         fprintf(stderr,"Please add a line to top of /test/???.dat file\n" ); 
         fprintf(stderr,"dimensions in mm/inches \n" );
     }

} // end dimen_call

/*
int main( int argc, char **argv)
{

	if (argc != 2)
	{
		printf("In dimen, wrong number of arguments \n");
		printf("Usage: dimen  fname\n");
		exit(-1);
	}
    else
	{
	  dimen_call(argv[1]);
	}


}  // end main
*/


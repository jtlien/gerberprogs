#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINELEN  120
 char D[LINELEN];
char X[LINELEN];
char Y[LINELEN];
  //
 // like dooffsetn, but passes lines that start with % directly to output
 //                  so that some 274x style gerbers can be offset
 //
void getstring( char *val, char *myval)
{
  val++; // Skip past D or Y or X

  if ( *val == '-')
  {
	val++;
	*myval = '-';
	myval++;
    while( isdigit(*val) )
	{
     *myval = *val ;
     val++;
     myval++;
	}
  }
  else
  {
    while( isdigit(*val) )
	{
     *myval = *val ;
     val++;
     myval++;
	}
  }
  *myval = '\0';
}

ProcessStringEX(char thestring[])
{
     char* placeX;
     char* placeY;
     char* placeD; 
     


 if ( thestring[0] != '%')
 {
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) )
	 {
         getstring(placeX,X);
	     getstring(placeY,Y);
		 if ( placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
	      printf("X%dY%dD%s*\n",atoi(X),atoi(Y) ,D );
     }
     else if (  strchr(thestring,'X') != NULL )  
	 {
         getstring(placeX,X);
		 if (placeD != NULL)
		 {
	      getstring(placeD,D);
		 }
	    printf("X%dY%dD%s*\n",atoi(X), atoi(Y) ,D );
     }
     else if (  strchr(thestring,'Y') != NULL ) 
	 {
	   getstring(placeY,Y);
	   if ( placeD != NULL)
	   {
	    getstring(placeD,D);
	   }
	   printf("X%dY%dD%s*\n",atoi(X), atoi(Y) ,D );
     }
     else if ( strchr(thestring , 'M') == NULL)
	 {
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
 }
 else
 {
  printf("%s", thestring);
 }
}

ProcessStringEXOut(char thestring[],  FILE *outfile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
    

    if ( thestring[0] != '%')
	{ 
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) )
	 {
         getstring(placeX,X);
	     getstring(placeY,Y);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
	     fprintf(outfile,"X%dY%dD%s*\n",atoi(X) ,atoi(Y) ,D );
     }
     else if( strchr(thestring,'X') != NULL ) 
	 {
         getstring(placeX,X);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
	     fprintf(outfile,"X%dY%dD%s*\n",atoi(X), atoi(Y)  ,D );
     }
     else if ( strchr(thestring,'Y') != NULL ) 
	 {
	   getstring(placeY,Y);
	   if ( placeD != NULL)
	   {
	     getstring(placeD,D);
	   }
	   fprintf(outfile,"X%dY%dD%s*\n",atoi(X) , atoi(Y),D );
     }
     else if ( strchr(thestring , 'M') == NULL)
	 {
       fprintf(outfile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
	}
   else
   {
	   fprintf(outfile,"%s", thestring);
   }
}

void doexpand_call_out(char *fname,   char *outfilestr)
{
FILE *thisfile;
FILE *outfile;
int debug;
char oneline[300];

   debug=0;
   D[0] = '\n';

   if ( debug) { printf("In doexpand_call_out, fname = %s outfilestr = %s \n",fname,
	   outfilestr); }

   thisfile =  fopen( fname,"r");
   if ( thisfile == NULL)
   {
	   printf("In doexpand_call_out, unable to open the input file = %s \n",fname);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"w");
   if ( outfile == NULL)
   {
	   printf("In doexpand_call_out, unable to open the output file file = %s \n",outfilestr);
	   exit(-1);
   }

   if ((thisfile != NULL) && (outfile != NULL)) {
       while( fgets(oneline, LINELEN, thisfile) != NULL)
	   {
		  // printf("Linein = %s \n",oneline);
          ProcessStringEXOut(oneline, outfile);
       } 
   }
   fclose(thisfile);
   fclose(outfile);

}

void doexpand_call_append(char *fname,  char *outfilestr)
{
FILE *thisfile;
FILE *outfile;
int debug;
char oneline[300];

   debug=0;
   D[0] = '\n';

   if ( debug) { printf("In doexpand_call_append, fname = %s outfilestr = %s \n",fname,
	   outfilestr); }
 
   thisfile =  fopen( fname,"r");
   if (thisfile == NULL)
   {
	   printf("In doexpand_call_append, unable to open the input file = %s \n",fname);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"a");

   if (outfile == NULL)
   {
	   printf("In doexpand_call_append, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }
   if ((thisfile != NULL) && (outfile != NULL)) {
       while( fgets(oneline, LINELEN, thisfile) != NULL)
	   {  
		   // printf("Into outfilestr = %s , oneline=%s \n",outfilestr,oneline);
          ProcessStringEXOut(oneline, outfile);
       } 
   }
   fclose(thisfile);
   fclose(outfile);

}

void doexpand_call(char *fname)
{
FILE *thisfile;

   char line[LINELEN];

   D[0] = '\n';

   thisfile =  fopen( fname,"r");
   if (thisfile != NULL){
       while( fgets(line, LINELEN, thisfile) != NULL){
          ProcessStringEX(line);
       } 
   }
   fclose(thisfile);

}



int main( int argc, char **argv)
{
	if (argc != 2)
	{
		printf("In doexpand, wrong number of arguments \n");
        printf("Usage: doexpand filename  \n");
		exit(-1);
	}
	else
	{
		doexpand_call( argv[1] ) ;
	}

}  // end main






#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINELEN  120
 char D[LINELEN];

void getstring( char *val, char *myval)
{
  val++; // Skip past D or Y or X

  if ( *val == '-')
  {
	val++;
	*myval = '-';
	myval++;
    while( isdigit(*val) )
	{
     *myval = *val ;
     val++;
     myval++;
	}
  }
  else
  {
    while( isdigit(*val) )
	{
     *myval = *val ;
     val++;
     myval++;
	}
  }
  *myval = '\0';
}

ProcessString(char thestring[], int  Xval, int Yval)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char X[LINELEN];
     char Y[LINELEN];


     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) )
	 {
         getstring(placeX,X);
	     getstring(placeY,Y);
		 if ( placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
	      printf("X%dY%dD%s*\n",atoi(X)+  Xval,atoi(Y)+ Yval ,D );
     }
     else if (  strchr(thestring,'X') != NULL )  
	 {
         getstring(placeX,X);
		 if (placeD != NULL)
		 {
	      getstring(placeD,D);
		 }
	    printf("X%dD%s*\n",atoi(X)+  Xval ,D );
     }
     else if (  strchr(thestring,'Y') != NULL ) 
	 {
	   getstring(placeY,Y);
	   if ( placeD != NULL)
	   {
	    getstring(placeD,D);
	   }
	   printf("Y%dD%s*\n",atoi(Y)+  Yval,D );
     }
     else if ( strchr(thestring , 'M') == NULL)
	 {
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

ProcessStringOut(char thestring[], int  Xval, int Yval, FILE *outfile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char X[LINELEN];
     char Y[LINELEN];
     
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) )
	 {
         getstring(placeX,X);
	     getstring(placeY,Y);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
	     fprintf(outfile,"X%dY%dD%s*\n",atoi(X)+  Xval,atoi(Y)+ Yval ,D );
     }
     else if( strchr(thestring,'X') != NULL ) 
	 {
         getstring(placeX,X);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
	     fprintf(outfile,"X%dD%s*\n",atoi(X)+  Xval ,D );
     }
     else if ( strchr(thestring,'Y') != NULL ) 
	 {
	   getstring(placeY,Y);
	   if ( placeD != NULL)
	   {
	     getstring(placeD,D);
	   }
	   fprintf(outfile,"Y%dD%s*\n",atoi(Y)+  Yval,D );
     }
     else if ( strchr(thestring , 'M') == NULL)
	 {
       fprintf(outfile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

void dooffset_call_out(char *fname, int in1 , int in2, char *outfilestr)
{
FILE *thisfile;
FILE *outfile;
int debug;
char oneline[300];

   debug=0;
   D[0] = '\n';

   if ( debug) { printf("In dooffset_call_out, fname = %s outfilestr = %s \n",fname,
	   outfilestr); }

   thisfile =  fopen( fname,"r");
   if ( thisfile == NULL)
   {
	   printf("In doffset_call_out, unable to open the input file = %s \n",fname);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"w");
   if ( outfile == NULL)
   {
	   printf("In doffset_call_out, unable to open the output file file = %s \n",outfilestr);
	   exit(-1);
   }

   if ((thisfile != NULL) && (outfile != NULL)) {
       while( fgets(oneline, LINELEN, thisfile) != NULL)
	   {
		  // printf("Linein = %s \n",oneline);
          ProcessStringOut(oneline, in1, in2, outfile);
       } 
   }
   fclose(thisfile);
   fclose(outfile);

}

void dooffset_call_append(char *fname, int in1 , int in2, char *outfilestr)
{
FILE *thisfile;
FILE *outfile;
int debug;
char oneline[300];

   debug=0;
   D[0] = '\n';

   if ( debug) { printf("In dooffset_call_append, fname = %s outfilestr = %s \n",fname,
	   outfilestr); }
 
   thisfile =  fopen( fname,"r");
   if (thisfile == NULL)
   {
	   printf("In dooffset_call_append, unable to open the input file = %s \n",fname);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"a");

   if (outfile == NULL)
   {
	   printf("In dooffset_call_append, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }
   if ((thisfile != NULL) && (outfile != NULL)) {
       while( fgets(oneline, LINELEN, thisfile) != NULL)
	   {  
		   // printf("Into outfilestr = %s , oneline=%s \n",outfilestr,oneline);
          ProcessStringOut(oneline, in1, in2, outfile);
       } 
   }
   fclose(thisfile);
   fclose(outfile);

}

void dooffset_call(char *fname, int in1 , int in2)
{
FILE *thisfile;

   char line[LINELEN];

   D[0] = '\n';

   thisfile =  fopen( fname,"r");
   if (thisfile != NULL){
       while( fgets(line, LINELEN, thisfile) != NULL){
          ProcessString(line, in1, in2);
       } 
   }
   fclose(thisfile);

}

/*
int main( int argc, char **argv)
{
	if (argc != 4)
	{
		printf("In dooffset, wrong number of arguments \n");
        printf("Usage: dooffset filename xoff yoff \n");
		exit(-1);
	}
	else
	{
		dooffset_call( argv[1], atoi(argv[2]), atoi(argv[3] ) );
	}

}  // end main
*/



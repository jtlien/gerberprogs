#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINELEN  81

void getstring( char*  val, char* myval)
{
  val++;
  *myval= *val; 
  val++;
  myval++;
  while( isdigit(*val) ){
     *myval = *val ;
     val++;
     myval++;
  }
  *myval = '\0';
}

ProcessString(char thestring[], int  Xval, int Yval)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char X[LINELEN];
     char Y[LINELEN];
     char D[LINELEN];
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) ){
         getstring(placeX,X);
	 getstring(placeY,Y);
	 getstring(placeD,D);
	printf("X%dY%dD%s*\n",atoi(X)+  Xval,atoi(Y)+ Yval ,D );
     }
     else if (  strchr(thestring,'X') != NULL ){
         getstring(placeX,X);
	 getstring(placeD,D);
	printf("X%dD%s*\n",atoi(X)+  Xval ,D );
     }
     else if (  strchr(thestring,'Y') != NULL ){
	 getstring(placeY,Y);
	 getstring(placeD,D);
	printf("Y%dD%s*\n",atoi(Y)+  Yval,D );
     }
     else if ( strchr(thestring , 'M') == NULL){
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

ProcessString_Out(char thestring[], int  Xval, int Yval, FILE *outfile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char X[LINELEN];
     char Y[LINELEN];
     char D[LINELEN];
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) ){
         getstring(placeX,X);
	 getstring(placeY,Y);
	 getstring(placeD,D);
	 fprintf(outfile,"X%dY%dD%s*\n",atoi(X)+  Xval,atoi(Y)+ Yval ,D );
     }
     else if (  strchr(thestring,'X') != NULL ){
         getstring(placeX,X);
	 getstring(placeD,D);
	 fprintf(outfile,"X%dD%s*\n",atoi(X)+  Xval ,D );
     }
     else if (  strchr(thestring,'Y') != NULL ){
	 getstring(placeY,Y);
	 getstring(placeD,D);
	  fprintf(outfile,"Y%dD%s*\n",atoi(Y)+  Yval,D );
     }
     else if ( strchr(thestring , 'M') == NULL){
       fprintf(outfile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

 FILE*  INFILE;

void dooffset_call_append(char *fname, int in1 , int in2, char *outfilestr)
{
FILE *thisfile;
FILE *outfile;

   char line[LINELEN];
   thisfile =  fopen( fname,"r");
   outfile=fopen( outfilestr,"wa");

   if (INFILE != NULL){
       while( fgets(line, LINELEN, thisfile) != NULL){
          ProcessString_Out(line, in1, in2,outfile);
       } 
   }
   fclose(outfile);
}
void dooffset_call_out(char *fname, int in1 , int in2, char *outfilestr)
{
FILE *thisfile;
FILE *outfile;

   char line[LINELEN];
   thisfile =  fopen( fname,"r");
   outfile=fopen( outfilestr,"w");

   if (INFILE != NULL){
       while( fgets(line, LINELEN, thisfile) != NULL){
          ProcessString_Out(line, in1, in2,outfile);
       } 
   }
   fclose(outfile);
}

void dooffset_call(char *fname, int in1 , int in2)
{
FILE *thisfile;

   char line[LINELEN];
   thisfile =  fopen( fname,"r");
   if (INFILE != NULL){
       while( fgets(line, LINELEN, thisfile) != NULL){
          ProcessString(line, in1, in2);
       } 
   }
}

void main(int argc , char* argv[])
{

   char line[LINELEN];
   INFILE =  fopen( argv[1],"r");
   if (INFILE != NULL){
       while( fgets(line, LINELEN, INFILE) != NULL){
          ProcessString(line, atoi( argv[2]), atoi( argv[3]));
       } 
   }
}




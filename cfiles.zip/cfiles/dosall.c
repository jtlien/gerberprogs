#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

void ux2dos_call( char *infilestr, char *outfilestr)
{
char systemstr[300];
    
    strncpy(systemstr,"unix2dos ",30); // unix2dos infilestr outfilestr
	strncat(systemstr,infilestr,120);
	strncat(systemstr," ",4);
	strncat(systemstr,outfilestr,120);
	system( systemstr );

	
}

void dosall_call( char *inextstr, char *outextstr)
{
int i;
int file_count;
char thisfilestr[300];
char name[300];
char extstr[300];
char fromfilestr[300];
char tofilestr[300];


  //tmp=$(ls *$1)
  file_count=scandir_matchext( ".",0,inextstr);

  i=0;
  while( i < file_count)       // in $tmp
  { 
	  strncpy(thisfilestr,scan_array[i],120);

	  split(thisfilestr,name,extstr,".");
	  printf("name = %s \n",name);

     // name=${i%*$1}
     printf("converting %s%s to %s%s\n", name, inextstr, name,outextstr);

	 strncpy(fromfilestr,name,120);    // fromfilestr
	 strncat(fromfilestr,inextstr,30);

	 strncpy(tofilestr,name,120);        // tofilestr
	 strncat(tofilestr,outextstr,30);

     ux2dos_call( fromfilestr, tofilestr); // $name$1 , $name$2 );

	i += 1;
  }

} // end dosall_call



int main( int argc, char **argv)
{
char progname[300];
char USAGE[300];
char WHERE[300];
char EXAMPLE[300];

 strncpy(progname,"dosall",30);

// USAGE="usage: $progname .from .to"

 strncpy(USAGE,"usage: ",30);
 strncat(USAGE,progname,120);
 strncat(USAGE," .from .to",30);

 strncpy(WHERE,"\tfrom/to are filename extensions (NEED dot)",80);

 strncpy(EXAMPLE,"\tex:  ",30);
 strncat(EXAMPLE,progname,120);
 strncat(EXAMPLE," .gbr .art (converts dos *.gbr to  unix *.art)",80);

 if(argc != 3)
 {
   printf("In dosall, incorrect number of arguments\n");
   printf( "%s\n%s\n%s\n",USAGE,WHERE,EXAMPLE);
 }
 else
 {
	dosall_call( argv[1], argv[2]);
 }

}  // end main
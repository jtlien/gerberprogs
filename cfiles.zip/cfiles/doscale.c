#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINELEN  120
 char D[LINELEN];

 // like dooffsetn, but passes lines that start with % directly to output
 //                  so that some 274x style gerbers can be offset
 //
void getstring( char *val, char *myval)
{
  val++; // Skip past D or Y or X

  if ( *val == '-')
  {
	val++;
	*myval = '-';
	myval++;
    while( isdigit(*val) )
	{
     *myval = *val ;
     val++;
     myval++;
	}
  }
  else
  {
    while( isdigit(*val) )
	{
     *myval = *val ;
     val++;
     myval++;
	}
  }
  *myval = '\0';
}

ProcessStringDS(char thestring[], double scale)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char X[LINELEN];
     char Y[LINELEN];


 if ( thestring[0] != '%')
 {
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) )
	 {
         getstring(placeX,X);
	     getstring(placeY,Y);
		 if ( placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
	      printf("X%dY%dD%s*\n",(int) (atoi(X) * scale),(int) (atoi(Y) * scale) ,D );
     }
     else if (  strchr(thestring,'X') != NULL )  
	 {
         getstring(placeX,X);
		 if (placeD != NULL)
		 {
	      getstring(placeD,D);
		 }
	    printf("X%dD%s*\n",(int) (atoi(X) * scale) ,D );
     }
     else if (  strchr(thestring,'Y') != NULL ) 
	 {
	   getstring(placeY,Y);
	   if ( placeD != NULL)
	   {
	    getstring(placeD,D);
	   }
	   printf("Y%dD%s*\n",(int)  (atoi(Y)* scale) ,D );
     }
     else if ( strchr(thestring , 'M') == NULL)
	 {
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
 }
 else
 {
  printf("%s", thestring);
 }
}

ProcessStringDSOut(char thestring[], double scale, FILE *outfile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char X[LINELEN];
     char Y[LINELEN];

    if ( thestring[0] != '%')
	{ 
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) )
	 {
         getstring(placeX,X);
	     getstring(placeY,Y);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
	     fprintf(outfile,"X%dY%dD%s*\n",(int) (atoi(X) * scale) ,(int) (atoi(Y) * scale) ,D );
     }
     else if( strchr(thestring,'X') != NULL ) 
	 {
         getstring(placeX,X);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
	     fprintf(outfile,"X%dD%s*\n",(int) (atoi(X) * scale) ,D );
     }
     else if ( strchr(thestring,'Y') != NULL ) 
	 {
	   getstring(placeY,Y);
	   if ( placeD != NULL)
	   {
	     getstring(placeD,D);
	   }
	   fprintf(outfile,"Y%dD%s*\n",(int) (atoi(Y) * scale),D );
     }
     else if ( strchr(thestring , 'M') == NULL)
	 {
       fprintf(outfile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
	}
   else
   {
	   fprintf(outfile,"%s", thestring);
   }
}

void doscale_call_out(char *fname, double scale,  char *outfilestr)
{
FILE *thisfile;
FILE *outfile;
int debug;
char oneline[300];

   debug=0;
   D[0] = '\n';

   if ( debug) { printf("In dooffset_call_out, fname = %s outfilestr = %s \n",fname,
	   outfilestr); }

   thisfile =  fopen( fname,"r");
   if ( thisfile == NULL)
   {
	   printf("In doffset_call_out, unable to open the input file = %s \n",fname);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"w");
   if ( outfile == NULL)
   {
	   printf("In doffset_call_out, unable to open the output file file = %s \n",outfilestr);
	   exit(-1);
   }

   if ((thisfile != NULL) && (outfile != NULL)) {
       while( fgets(oneline, LINELEN, thisfile) != NULL)
	   {
		  // printf("Linein = %s \n",oneline);
          ProcessStringDSOut(oneline, scale, outfile);
       } 
   }
   fclose(thisfile);
   fclose(outfile);

}

void doscale_call_append(char *fname, double scale , char *outfilestr)
{
FILE *thisfile;
FILE *outfile;
int debug;
char oneline[300];

   debug=0;
   D[0] = '\n';

   if ( debug) { printf("In dooffset_call_append, fname = %s outfilestr = %s \n",fname,
	   outfilestr); }
 
   thisfile =  fopen( fname,"r");
   if (thisfile == NULL)
   {
	   printf("In dooffset_call_append, unable to open the input file = %s \n",fname);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"a");

   if (outfile == NULL)
   {
	   printf("In dooffset_call_append, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }
   if ((thisfile != NULL) && (outfile != NULL)) {
       while( fgets(oneline, LINELEN, thisfile) != NULL)
	   {  
		   // printf("Into outfilestr = %s , oneline=%s \n",outfilestr,oneline);
          ProcessStringDSOut(oneline, scale, outfile);
       } 
   }
   fclose(thisfile);
   fclose(outfile);

}

void doscale_call(char *fname, double scale )
{
FILE *thisfile;

   char line[LINELEN];

   D[0] = '\n';

   thisfile =  fopen( fname,"r");
   if (thisfile != NULL){
       while( fgets(line, LINELEN, thisfile) != NULL){
          ProcessStringDS(line, scale);
       } 
   }
   fclose(thisfile);

}


/*
int main( int argc, char **argv)
{
	if (argc != 3)
	{
		printf("In doscale, wrong number of arguments \n");
        printf("Usage: doscale filename scaleval  \n");
		exit(-1);
	}
	else
	{
		doscale_call( argv[1], atof(argv[2]) ) ;
	}

}  // end main

*/




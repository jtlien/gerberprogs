#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define WINDOWS 1

void mkdir( char *filestr);

// Download all files from RDB to area in current directory
// Translate from DOS format all non-binary files
// pre-release test version
// Version 0.2 Aug 3, 1998
// Changed source of data to /rdb2
// Added usage log 

// Version 0.3
// Sept 8, 1998
// adds gwk files to "don't translate" list

void download_call( char *partnumstr)  // $1=partnumstr
{
char mysrc[1000];
char temp[1000];
char *username;
char userdate[300];
char basename[400];
char vers[300];
char USELOG[300];
FILE *uselogfile;
int archfound;
FILE *downlogfile;
char dest[300];
char fromfilestr[300];
char tofilestr[300];
char commandstr[300];
char REV[300];
char ptype[100];
char apath[300];
char mypath[300];
char systemstr[300];
char downlogfilestr[300];
char dirsep[4];;

   strncpy(vers,"0.30",15);

   // Check for existence of part directory (overwrite protect)

   if (WINDOWS)
   {
	   dirsep[0] = '\\';
	   dirsep[1] = '\0';
   }
   else
   {
	   dirsep[0] = '/';
	   dirsep[1] = '\0';

   }

   if ( dir_exists(partnumstr) )         // $1
   {
      // echo $1:"\c"
      printf("%s directory present! Will not overwrite.\n",partnumstr);
      exit(1);
   }
   else
   {
	  if (WINDOWS)
	  {
	    strncpy(USELOG,"m:/design/software/mmm/usage/druselog",120);
	  }
	  else
	  {
      strncpy(USELOG,"/usr/local/bin/scripts/usage/druselog",120);
	  }

      //username=$(whoami)
	  username=getenv("LOTUSUSERNAME");
	  if (username==NULL)
	  {
		  username=getenv("USERNAME");
	  }

      //userdate=$(date)
	  get_date(userdate);

      strncpy(basename,partnumstr,200);        // $1
      strncpy(REV,"0.3",50);

	  uselogfile=fopen(USELOG,"a");
	  if (uselogfile == NULL)
	  {
		  printf("Unable to open the USELOG file = %s for append \n", USELOG);
		  exit(-1);
	  }

   // Log usage
      //echo $PROGNAME|awk '{printf("%-15s",$1)}'>>$USELOG
	  fprintf(uselogfile,"download     ");

      fprintf(uselogfile,"%s     %s     %s     %s\n",
	             REV, basename, username, userdate); // >> $USELOG

   // Get source info
      while( ( strcmp(ptype,"a")!=0 ) && (strcmp(ptype,"b")!=0) && 
		     ( strcmp(ptype,"c")!=0 ) )   // 2> /dev/null
      {
         printf("Enter:\n");
         printf("       a  to get part from active\n");
         printf("       b  to get part from archive\n");
         printf("       c  to get part from sandbox\n");
         gets(ptype);
      }
   
   // Active 
      if( strcmp(ptype,"a" )==0) 
      {
		 if (WINDOWS)
		 {
          strncpy(mysrc,"R:\\active\\",30);
		 }
		 else
		 {
			 strncpy(mysrc,"/rdb2/active/",20);
         }
	//	 strncat(mysrc,partnumstr,120);         //$1"
		 
		 archfound=0;
         while( archfound != 1 )
         {
	       printf("Enter the active subdirectory, i.e. a/1: \n");
	       gets(apath);
	       //temp=$mysrc/$apath
		   strncpy(temp,mysrc,200);   // $mysrc/$apath
		   strncat(temp,apath,100);
		   strncat(temp,dirsep,10);
		   strncat(temp,partnumstr,120);

       	   //mysrc=$temp

		   strncpy(mysrc,temp,200);
		 
	 // accept only inputs of length>2
	       if ( strlen( mysrc) > 2 )
		   {
	        // ls $mysrc >/dev/null
	        if ( !(dir_exists( mysrc) ) )       // $? = 2 )
			{
              printf("No such Active Directory! (%s) \n", mysrc);
 	         // exit(1);
			}
            else
			{
	          archfound=1;
            }
		   }
		 }   // while archfound ==0
      }
   
   // Archive & its subdirectories 
      if( strcmp(ptype,"b" )==0)
      {
		 if (WINDOWS)
		 {
          strncpy(mysrc,"R:\\archive\\",30);
		 }
		 else
		 {
		  strncpy(mysrc,"/rdb2/archive/",20);
		 }

	//	 strncat(mysrc,partnumstr,120);         //$1"
         // mysrc="/rdb2/archive/$1"
         archfound=0;
         while( archfound != 1 )
         {
	       printf("Enter the archive subdirectory, i.e. a/1: \n");
	       gets(apath);
	       //temp=$mysrc/$apath
		   strncpy(temp,mysrc,200);   // $mysrc/$apath
		   strncat(temp,apath,100);
		   strncat(temp,dirsep,10);
		   strncat(temp,partnumstr,120);

		   
       	   //mysrc=$temp

		   strncpy(mysrc,temp,400);

	 // accept only inputs of length>2
	       if ( strlen( mysrc) > 2 )
		   {
	        // ls $mysrc >/dev/null
	        if ( !(dir_exists( mysrc) ) )       // $? = 2 )
			{
              printf("No such Archive Directory! (%s) \n", mysrc);
 	          //exit(1);
			}
            else
			{
	          archfound=1;
            }
		   }
         }
      }
   
   // Sandbox
      if (strcmp(ptype,"c" )==0)
      {
         // mysrc="/rdb2/sandbox/$1"
		 if(WINDOWS)
		 {
			strncpy(mysrc,"R:\\sandbox\\",30);
		 }
		 else
		 {
           strncpy(mysrc,"/rdb2/sandox/",20);
		 }
		 strncat(mysrc,partnumstr,120);         //$1"
      }

   //echo $mysrc
   //ls $mysrc >/dev/null 2>/dev/null (this one suppresses the err message)
      //ls $mysrc >/dev/null 
      if ( !( dir_exists( mysrc) )  )       // $? = 2 
      {
         printf("%s   ",mysrc);
         printf(" No such Directory!\n");
         exit(1);
	  }
      else
	  {
         printf("%s   ",mysrc);
         printf("Directory found!\n");
      }
   
      // mypath=$PWD
	  getwd(mypath);

      //dest=$mypath/$1
	  strncpy(dest,mypath,120);    // $mypath/$1
	  strncat(dest,dirsep,10);
	  strncat(dest,partnumstr,120);

      mkdir(dest);
      //chmod 755 dest
      strncpy(downlogfilestr,dest,120);
      strncat(downlogfilestr,"/downlog",30);


      downlogfile = fopen(downlogfilestr,"a");
	  
      if (downlogfile == NULL)
	  {
	   printf("Unable to open the %s/downlog file for appending \n", dest);
	   exit(-1);
	  }

      // Start log file
      fprintf(downlogfile,"Download start time: %s \n", userdate) ; //\c">$dest/downlog
    //  date >>$dest/downlog
      fprintf(downlogfile,"Script version: %s\n",vers); // >>$dest/downlog
      fprintf(downlogfile,"Source directory: %s\n",mysrc); // >>$dest/downlog
      fprintf(downlogfile,"Destination directory: %s\n",dest); // >>$dest/downlog


// write start time stamp for performance testing
//      echo "Start copying: \c">$dest/timelog
//      date|cut -f 4 -d' '>>$dest/timelog
// Copy RDB files into destination area
      
      printf( "==========================================================\n");
      printf( "DOWNLOADING FILES FROM RELEASE DATABASE\n");
      printf( "==========================================================\n");
      printf( "  Source directory:      %s\n",mysrc);
      printf( "  Destination directory: %s\n",dest);
      printf( "==========================================================\n");


     // change_dir(dest);
	  strncpy(commandstr,"cp -R ",10);  // cp -R mysrc
	  strncat(commandstr,mysrc,200);
	  strncat(commandstr,"  .", 10);

	  system(commandstr);

	  //printf("Called the system with :   %s \n", commandstr);

   //   cp -R $mysrc\*
      system("chmod 755 *");
      system("chmod -R 755 *");
   
// write time stamp for performance testing
//      echo "Finished copying: \c">>$dest/timelog
//      date|cut -f 4 -d' '>>$dest/timelog

// lots of translateing from unix to dos was done here

   }

// Finish log file

   get_date(userdate);

   fprintf(downlogfile,"Download finished: %s\n",userdate); // >>$dest/downlog
   fclose(downlogfile);

   // date>>$dest/downlog

   fclose(downlogfile);

   strncpy(systemstr,"chmod 444 ", 40);
   strncat(systemstr,dest,120);
   strncat(systemstr,"/downlog",30);

   system(systemstr);

   //chmod 444 $dest/downlog

   //mv $dest/downlog $dest/report
   strncpy(fromfilestr,dest,200);   // $dest/downlog
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"downlog",15);

   strncpy(tofilestr,dest,200);   // $dest/report
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"report/",30);
   strncat(tofilestr,"downlog",30);


   cp_file(fromfilestr,tofilestr);
   rm_file(fromfilestr);

   printf("Run logupdate to get the newest makelog!\n");
   printf("\n");
   printf("Done!\n");
// write time stamp for performance testing
//   echo "Finished translating: \c">>$dest/timelog
//   date|cut -f 4 -d' '>>$dest/timelog
}

int main( int argc, char **argv)
{
char USAGE[300];
char WHERE[300];
char vers[100];

//PROGNAME=${0##*/}
strncpy(USAGE,"usage: download p/n ",80);

strncpy(WHERE,"\tp/n is the part to copy from the RDB",80);
strncpy(vers,"0.3",20);

printf("WARNING - Pre-release version! (%s) Report problems to Barb Clauson.\n",vers);

if( argc != 2)
{
   printf( "In download, incorrect number of arguments\n");
   printf( "%s\n%s\n",USAGE,WHERE);
   exit(-1);
}
else
{
	download_call( argv[1]);
}

}  // end main

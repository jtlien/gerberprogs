#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// Runs Cadence downrev and translator tools in correct sequence
// bac, Sept 8, 1998
// version 0.1

void downto11_call( char *basestr)
{
char chkfilestr[300];
char tofilestr[300];


   // Check for existence of part directory (overwrite protect)

	strncpy(chkfilestr,basestr,120);  // $1.cmd
	strncat(chkfilestr,".mcm",10);

   if ( !(file_exists( chkfilestr) ) )   //  -a $1.mcm )
   {
      // printf( $1.mcm:"\c"
      printf(" %s file not present in current directory.\n",chkfilestr);
      exit(-1);
   }
   cp_file( chkfilestr, "r12.mcm");

   system("mcm2brd r12");
   system("downrev r12.brd r11.brd");

   strncpy(tofilestr,basestr,120);   /// $1.brd
   strncat(tofilestr,".brd",10);

   cp_file( "r11.brd", tofilestr  );


}   // end downto11_call

int main( int argc, char **argv)
{
char USAGE[300];
char WHERE[300];
char vers[300];

strncpy(USAGE,"usage: downto11 p/n",120);
strncpy(WHERE,"\tp/n is the base name of the mcm file",120);

strncpy(vers,"0.1",10);


printf("WARNING - Pre-release version! (%s) Report problems to Barb Clauson.\n",vers);
if(argc != 2)
{
   printf("In downto11, incorrect number of arguments \n");
   printf( "%s\n%s\n",USAGE,WHERE);
}
else
{
	downto11_call( argv[1]);
}

}  // end main
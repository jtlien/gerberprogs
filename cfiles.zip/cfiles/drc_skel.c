#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

#include "utilprogs.h"

// DRC report parser
// Starts a DRC summary report by using only the summary section 
// of the APD drc report

// Creates new file report/drc_summ_skel
// This report is incomplete! The designer must add the reasons
// each DRC is acceptable. 

// rev 0.1
// 06-16-03
// bac


void grepout( char *infilestr, char *outfilestr)
{
FILE *infile,*outfile;
int endoffile;
char thisline[300];
int ll,kk;
int printoutflag;
char fixedline[300];

    infile=fopen(infilestr,"r");
	if (infile==NULL)
	{
		printf("Unable to open the input file = %s for read \n",infilestr);
		exit(-1);
	}
	outfile=fopen(outfilestr,"w");

	if (outfile== NULL)
	{
		printf("Unable to open the output file = %s \n",outfilestr);
		exit(-1);
	}

	endoffile=getline(infile,thisline);

	while(endoffile== FALSE)
	{
	 printoutflag=TRUE;

     if ( strstr(thisline,"|------") != NULL)  // what to grep out
	 {
       printoutflag=FALSE;
	 }

    if ( strstr(thisline,"|======") != NULL)  // what to grep out
	 {
       printoutflag=FALSE;
	 }
    if ( strstr(thisline,"|- - -") != NULL)  // what to grep out
	 {
       printoutflag=FALSE;
	 }
	 if (printoutflag)
	 {
		 ll=0;
		 kk=0;
		 while(kk < (signed int) strlen(thisline) )
		 {
			 if ( thisline[kk] != '|' )
			 {
				fixedline[ll]=thisline[kk];
				ll +=1;
			 }
			kk += 1;
		 }
		 fixedline[ll]='\0';

		 fprintf(outfile,"%s",fixedline);
		 //printf("outline=%s\n",fixedline);
	 }

	 endoffile=getline(infile,thisline);
	// printf("line in = %s \n",thisline);
	}

  fclose(outfile);
  fclose(infile);

} 


// 
//
//

int drc_skel_call( )
{
char username[300];
char *userdate;
char pwd_str[300];
char drcname[300];
char revstr[300];
char tofilestr[300];
char thisline[300];
char chk[300];
char chklower[300];
char *sptr;

int got2end;
FILE *sumfile;
FILE *tmpdrcfile;
int endoffile;
char basename[300];

 if (WINDOWS)
	{
	 strncpy(dirsep,"\\",3);
 }
 else
 {
	 strncpy(dirsep,"/",3);
 }

 // username=$(whoami)
 get_whoami(username);

 // userdate=$(date)
 userdate = gettime_str();

// drcname=report/${PWD##*\/}.drc
 getwd(pwd_str);
 get_full_path_end( pwd_str, basename);

 strncpy(drcname,"report",20);
 strncat(drcname,dirsep,10);
 strncat(drcname,basename,120);
 strncat(drcname,".drc",10);

 strncpy(revstr,"REV=0.1",20);


// Check existence
 if ( ! (file_exists(drcname ) ) )
 {
   printf("File %s does not exist.\n",drcname);
   return( 1);
 }

// Translate report and get rid of junk
 //dos2ux(drcname | grep -v '|------' | grep -v '|======' | grep -v '|- - -' | sed 's/|//' | sed 's/ |//' > tmpdrc

  grepout(drcname, "tmpdrc");

// Go through file looking for end. Start printing new report when summary line found


 got2end=0;


 tmpdrcfile=fopen("tmpdrc","r");

 if (tmpdrcfile==NULL)
	{
	 printf("Unable to open the tmpdrc file for read \n");
 }


 sumfile=fopen("sumfile","w");
 if (sumfile==NULL)
	{
	 printf("Cannot open the file sumfile for writing \n");
	 exit(-1);
	}

 endoffile=getline(tmpdrcfile,thisline);

 while(endoffile==FALSE)   //  read line
 {
   // chk=${line%%DESIGN*}
	 strncpy(chk,thisline,180);
	 // printf("chk = %s \n",chk);

	 sptr=strstr(chk,"DESIGN");
	 if (sptr != NULL)
	 {
	  *sptr='\0';
	 }
	 chk[6]='\0';   // at most 6 chars


   //typeset -L6 chk
   cv_tolower(chk,chklower);

   if ( got2end == 1 )
   {
      fprintf(sumfile,"%s", thisline); //  >> sumfile
   }
   if ( strcmp(chklower,"end of") == 0 )   // $chk = "end of" )
   {
	   fprintf(sumfile,"end\n"); //  ${line#*of }  );  // > sumfile
      fprintf(sumfile,"Created by %s on %s \n",username,userdate); // >> sumfile
      got2end=1;
   }
   endoffile=getline(tmpdrcfile,thisline);
   // printf("read line = %s \n",thisline);

 }  // < tmpdrc

 fclose(tmpdrcfile);
 fclose(sumfile);

// Check for strangeness
 if ( got2end != 1 )
 {
   printf( "ERROR! - Unable to detect end of DRC report.\n");
   return(2);
 }
 if ( ! (file_exists( "sumfile" ) ) )
 {
   printf("ERROR! - drc_summ_skel report not created.\n");
   rm_file("tmpdrc");
   return(3);
 }

 printf("DRC Skeleton Summary report created: report%sdrc_summ_skel \n",dirsep);
 printf("Edit this report to justify each DRC error or group of errors.\n");
 printf("Save it as report%sdrc_summary.\n",dirsep);

// Clean up
 strncpy( tofilestr,"report",20);
 strncat( tofilestr,dirsep,10);
 strncat( tofilestr,"drc_summ_skel",30);

 cp_file( "sumfile",  tofilestr);
 rm_file( "sumfile");
 rm_file("tmpdrc");

 return(0);

}  // end main

/*
int main( int argc, char **argv)
{
int retcode;

 if (argc == 1)
 {
  retcode= drc_skel_call( );
  exit(retcode);
 }
 else
 {
	 printf("In drc_skel, wrong number of arguments.  drc_skel takes no arguments \n");
	 exit(-1);
 }

}   // end main

  */



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

#define MAX_FNAMES 100000

int fname_count;

char fname_array[MAX_FNAMES][100];

int found_in_fnames( char *inname)
{
int kk;

  kk=0;
  while(kk < fname_count )
  {
	  if (strcmp(fname_array[kk],inname)==0 )
	  {
		  return(TRUE);
	  }
	kk += 1;
  }
return(FALSE);

} // found_in_fnames

// read thru a file that contains list of file names in xxxxx.yyy format in second column
//  check for duplicate xxxxxx's
//  if none, exitvalue=0 else exitvalue=99
//
int dup_filename_call( char *infilestr)
{
int nf;
int exitvalue;
int endoffile;
char thisline[300];
FILE *file1;
char tmp[10][120];

    exitvalue = 0;

	fname_count =0;

	file1=fopen(infilestr,"r");
	if (file1==NULL)
	{
		printf("In dup_filename_call, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
	{
     split(str_array[1],tmp[0],tmp[1],".");

	// printf("tmp 0 = %s \n",tmp[0]);

     if ( found_in_fnames(tmp[0]) ) 
	 {
        exitvalue = 99;
        //printf( "exit = %d \n",exitvalue);
 	    return(exitvalue); 
     }
     else
	 {
		 if (fname_count < MAX_FNAMES)
		 {
            strncpy(fname_array[fname_count],tmp[0],80); // tmp[0]); 
			fname_count += 1;
		 }
		 else
		 {
			 printf("In dup_filename, number of fnames too large \n");
		 }

     }
	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);
   }

  fclose(file1);

   // printf("%d \n",exitvalue);
    return( exitvalue);
}

int main( int argc, char **argv)
{
int retval;


	if(argc != 2)
	{
		printf("In dup_filename, wrong number of arguments \n");
		printf("Usage: dup_filename infile \n");
		exit(-1);
	}
	else
	{
		retval=dup_filename_call( argv[1] );
		if(retval != 0 ) { printf("exit  %d \n",retval); }

		exit(retval);
	}

}  // end main
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

#define MAX_MFG_LAYER 100000

int mfg_layer_count;

char mfg_layer_array[MAX_MFG_LAYER][100];

int found_in_mfglayer( char *inname)
{
int kk;

  kk=0;
  while(kk < mfg_layer_count )
  {
	  if (strcmp(mfg_layer_array[kk],inname)==0 )
	  {
		  return(TRUE);
	  }
	kk += 1;
  }
return(FALSE);

} // found_in_fnames

// read thru a file that contains list of file names in xxxxx.yyy format in second column
//  check for duplicate xxxxxx's
//  if none, exitvalue=0 else exitvalue=99
//
int dup_mfg_layer_call( char *infilestr)
{
int nf;
int exitvalue;
int endoffile;
char thisline[300];
FILE *file1;

    exitvalue = 0;

	mfg_layer_count =0;

	file1=fopen(infilestr,"r");
	if (file1==NULL)
	{
		printf("In dup_mfg_layer, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

 while(endoffile==FALSE)
 {
   if( strcmp( str_array[3],"NA")!= 0 )

   {
     
     if ( found_in_mfglayer(str_array[3]) ) 
	 {
        exitvalue = 99;
        //printf( "exit = %d \n",exitvalue);
 	    return(exitvalue); 
     }
     else
	 {
		 if (mfg_layer_count < MAX_MFG_LAYER)
		 {
            strncpy(mfg_layer_array[mfg_layer_count],str_array[3],80); // tmp[0]); 
			mfg_layer_count += 1;
		 }
		 else
		 {
			 printf("In dup_mfg_layer, number of mfg layers too large \n");
		 }

     }
   }
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
 }

  fclose(file1);

   // printf("%d \n",exitvalue);
    return( exitvalue);
}

int main( int argc, char **argv)
{
int retval;


	if(argc != 2)
	{
		printf("In dup_mfg_layer, wrong number of arguments \n");
		printf("Usage: dup_mfg_layer infile \n");
		exit(-1);
	}
	else
	{
		retval=dup_mfg_layer_call( argv[1] );
		if(retval != 0 ) { printf("exit  %d \n",retval); }

		exit(retval);
	}

}  // end main
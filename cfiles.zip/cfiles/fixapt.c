#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void fixapt_call( char *infilestr)
{
int nf;
int endoffile;
char thisline[300];
FILE *file1;
char reststr[300];
int ll,kk;

  

	file1=fopen(infilestr,"r");
	if (file1==NULL)
	{
		printf("In fixapt, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
	{

      if (strcmp(str_array[0],"ARCRES")==0)
	  {

	   reststr[0]='\n';
	   kk=6;                        // skip past ARCRES
	   while((thisline[kk] == ' ' ) && (thisline[kk]!= '\n') && 
		   ( thisline[kk] != '\0'))
	   {
		   kk += 1;
	   }
	   // skip space separators if any

       while((thisline[kk] != ' ' ) && (thisline[kk] != '\n') && 
		   ( thisline[kk] != '\0'))
	   {
		   kk += 1;
	   }
	   // skip second column
	   ll=0;
	   while((thisline[kk] != '\n') && ( thisline[kk] != '\0'))
	   {
		   reststr[ll]= thisline[kk];
		   ll += 1;
		   kk += 1;
	   }
	   reststr[ll]= '\0';

       printf("%s 15 %s \n",str_array[0], reststr); //  $2 = 15
	  }
	  else
	  {
       printf("%s",thisline);
	  }
    endoffile=getline(file1,thisline);
    nf=split_line(thisline);
   }

   fclose(file1);

}  // end fixapt_call

int main( int argc, char **argv)
{

	if(argc != 2)
	{
		printf("In fixapt, wrong number of arguments \n");
		printf("Usage: fixapt infile \n");
		exit(-1);
	}
	else
	{
		fixapt_call( argv[1] );
	}

}  // end main

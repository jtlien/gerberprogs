#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// fix the header of a ? file
//
// print all lines at the beginnin that start with %
//   then print  gsave
//   then print all lines that do not have either showpage or copypage
//   then print grestore

void fixheader_call( char *infilestr)
{
char thisline[300];
int endoffile;
FILE *file1;

   file1=fopen(infilestr,"r");
   if (file1==NULL)
   {
     printf("In fix header, unable to open the input file = %s \n",infilestr);
	 exit(-1);
   }

   endoffile=getline(file1,thisline);

   while( thisline[0] == '%' )           //substr($0,1,1) == "%")
   {
	printf("%s",thisline); // $0
	endoffile=getline(file1,thisline);
   }

   printf("gsave\n");
   printf("%s",thisline); //  $0

   endoffile=getline(file1,thisline);

   while(endoffile==FALSE)
   {
     if( (strstr(thisline,"showpage")==NULL) && 
		(strstr(thisline,"copypage")==NULL ) )
		                               // $0 !~ /showpage/ && $0 !~ /copypage/)
	 {
      printf("%s",thisline);   // $0
	 }

	 endoffile=getline(file1,thisline);
   }

  fclose(file1);

  printf("grestore\n");
}

void fixheader_call_out( char *infilestr, char *outfilestr)
{
char thisline[300];
int endoffile;
FILE *file1;
FILE *outfile;

   file1=fopen(infilestr,"r");
   if (file1==NULL)
   {
     printf("In fix header, unable to open the input file = %s \n",infilestr);
	 exit(-1);
   }

   outfile=fopen(outfilestr,"w");
   if (outfile==NULL)
   {
     printf("In fix header, unable to open the output file = %s \n",outfilestr);
	 exit(-1);
   }
   endoffile=getline(file1,thisline);

   while( thisline[0] == '%' )           //substr($0,1,1) == "%")
   {
	fprintf(outfile,"%s",thisline); // $0
	endoffile=getline(file1,thisline);
   }

   fprintf(outfile,"gsave\n");
   fprintf(outfile,"%s",thisline); //  $0

   endoffile=getline(file1,thisline);

   while(endoffile==FALSE)
   {
     if( (strstr(thisline,"showpage")==NULL) && 
		(strstr(thisline,"copypage")==NULL ) )
		                               // $0 !~ /showpage/ && $0 !~ /copypage/)
	 {
      fprintf(outfile,"%s",thisline);   // $0
	 }

	 endoffile=getline(file1,thisline);
   }

  fclose(file1);

  fprintf(outfile,"grestore\n");
  fclose(outfile);

}  // fixheader_call_out

/*
int main( int argc, char **argv)
{
	if (argc != 2 )
	{
		printf("In fixheader, wrong number of arguments \n");
		printf("Usage: fixheader infile \n");
		exit(-1);
	}
	else
	{
		fixheader_call( argv[1]);
	}

}  // end main

  */

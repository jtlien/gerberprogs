
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// This is nearly identical to getoffset3.
//  Figures out an outline that is 20000 more that the hull of the gerber
//
//  call interface to fixoutline3, write to stdout
//
void fixoutline3_call( char *infilestr)
{
int cnt;
int endoffile;
char X[200];
char Y[200];
char a[10][200];
char b[10][200];
char c[10][200];
int val;
FILE *file1;
double xmin;
double ymin;
double xmax;
double ymax;
double xval;
double yval;
char tmp[300];
int first;
char thisline[200];


  first=0;
  cnt=0;
  file1=fopen(infilestr,"r");
   if ( file1 == NULL)
   {
	   printf("In getoffset, unable to create the input file = %s \n",infilestr);
	   exit(-1);
   }
  endoffile=getline(file1,thisline);

  while(endoffile==FALSE)
  {
   if ( (strstr(thisline,"X") != NULL) && 
	   (strstr(thisline,"Y") != NULL) && 
	   (strstr(thisline,"G54") == NULL) &&
	   (strstr(thisline,"G04")==NULL) &&
	   (strstr(thisline,"%")==NULL) )    // $0 ~/X/ && $0 ~/Y/  &&  $0 !~/G54/)
   {
       split(thisline,a[0],a[1],"Y");

       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X);
	   if (strstr(a[1],"D")!=NULL)
	   {
         awk_substr( a[1],1,strlen(a[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( a[1],1,strlen(a[1]) -1, Y);    // no D
	   }
//       printf("%s %s\n", X,Y)
	   xval=atof(X);
	  yval=atof(Y);
	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   else if( (strstr(thisline,"Y") == NULL) &&
	       (strstr(thisline,"X") != NULL) &&
		   (strstr(thisline,"G54") == NULL) &&
	       (strstr(thisline,"G04")==NULL) &&
	       (strstr(thisline,"%")==NULL) )   //  $0 !~ /Y/ && $0 ~/X/ )
   {
      split(thisline,b[0],b[1],"X");
	  if (strstr(b[1],"D")!=NULL)
	   {
         awk_substr( b[1],1,strlen(b[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( b[1],1,strlen(b[1]) -1, Y);    // no D
	   }
//       printf("%s  %s\n", X,Y)
	  xval=atof(X);
	  yval=atof(Y);
	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   else if( (strstr(thisline,"X") == NULL) && 
	        (strstr(thisline,"Y") != NULL) &&
			(strstr(thisline,"G54") == NULL) &&
	        (strstr(thisline,"G04")==NULL) &&
	        (strstr(thisline,"%")==NULL)   )     // $0 !~ /X/ && $0 ~/Y/ )
   {
      split(thisline,c[0],c[1],"Y");
	  if (strstr(c[1],"D")!=NULL)
	   {
         awk_substr( c[1],1,strlen(c[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( c[1],1,strlen(c[1]) -1, Y);    // no D
	   }
      
//      printf("%s %s\n", X,Y)
	  xval=atof(X);
	  yval=atof(Y);
	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   endoffile=getline(file1,thisline);
  
  }
  fclose(file1);

  xmin = xmin - 20000;
  ymin = ymin - 20000;
  xmax = xmax + 20000;
  ymax = ymax + 20000;

  // tmp="%LPC*%"
  strncpy(tmp,"%LPC*%",10);

  file1=fopen(infilestr,"a");    // open for append
  if (file1==NULL)
  {
	  printf("Unable to open the file = %s for append \n",infilestr);
	  exit(-1);
  }


 fprintf(file1,"%s\nG01X%0.0fY%0.0fD02*\n",tmp,xmin,ymax);  // >> FILENAME

 fprintf(file1,"X%0.0fD01*\n",xmax);                     // >> FILENAME
 fprintf(file1,"Y%0.0fD01*\n",ymin);                     // >> FILENAME
 fprintf(file1,"X%0.0fD01*\n",xmin);                     // >> FILENAME
 fprintf(file1,"Y%0.0fD01*\n",ymax);                     // >> FILENAME
   
 fclose(file1);

} // end fixoutline3_call



int main( int argc, char **argv)

{
  if (argc != 2 )
  {
    printf("In fixoutline3, wrong number of arguments \n");
	printf("Usage: fixoutline3 infile \n");
	exit(-1);
   }
  else
  {
	 fixoutline3_call( argv[1]);

  }
}  
  


  

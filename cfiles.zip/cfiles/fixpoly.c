
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAX 255

#include <math.h>

#include "utilprogs.h"

char poly[5000][120];
int changed;
int MINDIST;

// fixup consecutive arcs that have arc lengths less than a threshold

double dist( double x1, double y1, double x2, double y2)
{
  double dx;
  double dy;
  double d;

  dx = (x2-x1) * (x2-x1);
  dy = (y2-y1) * (y2-y1);
  // d  = (dx+dy)^.5
  d= sqrt(dx+dy);

  return(d);
}

// uses data from poly array
//    sets changed flag
//

void fixarc( int i)
{
int start;
int stop;
char x1base[60];
char y1base[60];
char x2base[60];
char y2base[60];
char xseg[60];
char yseg[60];
char xout[60];
char yout[60];
int iout;
int jout;
char i1[120];
char j1[120];
char iout_str[120];
char jout_str[120];
char i2[120];
char j2[120];
double c2x;
double c2y;
double c1x;
double c1y;
double cx;
double cy;
char tmpoutstr[100];
int seglen;


  if( (strstr(poly[i - 1],"X") == NULL)  || 
	  (strstr(poly[i - 1],"Y") == NULL ) )
  {                           // need to have a valid X && Y
     printf("%s", poly[i] );
     printf("%s", poly[i + 1]);
     printf("%s", poly[i + 2]);
  }
  else
  {
      //find center of first arc
      start = awk_index(poly[i-1],"X")+1;
      if( strstr(poly[i-1],"I") != NULL )
	  {
           stop = awk_index(poly[i-1],"I") - start ;
      }
      else
	  {
          stop = awk_index(poly[i-1],"D") - start ;
      }
      awk_substr(poly[i-1],start,stop,x1base);
      start = awk_index(poly[i-1],"Y")+1;
      stop = awk_index(poly[i-1],"D") - start;
      awk_substr(poly[i-1],start,stop,y1base);
     // print x1base | "cat 1>&2"
     // print y1base | "cat 1>&2"

      start = awk_index(poly[i],"I")+1;
      stop = awk_index(poly[i],"J") - start; 
      awk_substr(poly[i],start,stop,i1);
      start = awk_index(poly[i],"J")+1;
      stop = awk_index(poly[i],"D") - start;
      awk_substr(poly[i],start,stop,j1);
     // print i1 | "cat 1>&2"
     // print j1 | "cat 1>&2"
      c1x = atof(x1base) + atof(i1);  // x & y coords of first arc
      c1y = atof(y1base) + atof(j1);
     // print "center of c1" | "cat 1>&2"
     // print c1x | "cat 1>&2"
     // print c1y | "cat 1>&2"
     // print "  " | "cat 1>&2"
      //get end of first arc/start of segment for length calculation
      start = awk_index(poly[i],"X")+1;
      stop = awk_index(poly[i],"Y") - start;
      awk_substr(poly[i],start,stop,xseg);
      start = awk_index(poly[i],"Y")+1;
      stop = awk_index(poly[i],"I") - start;
      awk_substr(poly[i],start,stop,yseg);
  
      // get center of second arc
      if( (strstr(poly[i + 1],"X") != NULL)  &&
		  (strstr(poly[i+1],"Y") != NULL) )       // both x and y
	  {
           start = awk_index(poly[i+1],"X")+1;
           stop = awk_index(poly[i+1],"Y") - start; 
           awk_substr(poly[i+1],start,stop,x2base);
           start = awk_index(poly[i+1],"Y")+1;
           stop = awk_index(poly[i+1],"D") - start;
           awk_substr(poly[i+1],start,stop,y2base);
      }
      else if( (strstr(poly[i + 1],"X") != NULL)  && 
		       (strstr(poly[i+1],"Y") == NULL) )      // x but no y
	  {
           start = awk_index(poly[i+1],"X")+1;
           stop = awk_index(poly[i+1],"D") - start;
           awk_substr(poly[i+1],start,stop,x2base);
           start = awk_index(poly[i],"Y")+1;
           stop = awk_index(poly[i],"I") - start;
           awk_substr(poly[i],start,stop,y2base);
      }
      else if( (strstr(poly[i+1],"X") == NULL)  && 
		       (strstr(poly[i+1],"Y" ) != NULL) )      // no x, but have y
	  {
           start = awk_index(poly[i],"X")+1;
           stop = awk_index(poly[i],"Y") - start;
           awk_substr(poly[i],start,stop,x2base);
           start = awk_index(poly[i+1],"Y")+1;
           stop = awk_index(poly[i+1],"D") - start; 
           awk_substr(poly[i+1],start,stop,y2base);
      }
   //  print x2base | "cat 1>&2"
   //  print y2base | "cat 1>&2"

      start = awk_index(poly[i+2],"I")+1;
      stop = awk_index(poly[i+2],"J") - start;
      awk_substr(poly[i+2],start,stop,i2);
      start = awk_index(poly[i+2],"J")+1;
      stop = awk_index(poly[i+2],"D") - start;
      awk_substr(poly[i+2],start,stop,j2);
    //  print i2 | "cat 1>&2"
    //  print j2 | "cat 1>&2"
      c2x = atof(x2base) + atof(i2);  // x & y coords of first arc
      c2y = atof(y2base) + atof(j2);  
    //  print "center of c2" | "cat 1>&2"
    //  print c2x | "cat 1>&2"
    //  print c2y | "cat 1>&2"

      //find center of new single arc 
      cx = (c1x + c2x)/2.0;
      cy = (c1y + c2y)/2.0;
    //  print "\n\nnew center is " | "cat 1>&2"
    //  print cx | "cat 1>&2"
    //  print cy | "cat 1>&2"

      // find differnce between new center & current position
      iout = (int)(cx - atof(x1base));
      jout = (int)(cy - atof(y1base));

    //  print iout | "cat 1>&2"
    //  print jout | "cat 1>&2"
   
      // only modify arc if segment length is too short
	seglen = (int )(dist(atof(xseg),atof(yseg),atof(x2base),atof(y2base) ));

   //  print "seglen  = " seglen | "cat 1>&2"
      if( seglen  <= MINDIST)
	  { 
         if( (strstr(poly[i+2],"X") != NULL) &&
			 (strstr(poly[i+2],"Y" ) != NULL) )           // both x and y
		 {
            start = awk_index(poly[i+2],"X")+1;
            stop = awk_index(poly[i+2],"Y") - start;
            awk_substr(poly[i+2],start,stop,xout);
            start = awk_index(poly[i+2],"Y")+1;
            stop = awk_index(poly[i+2],"I") - start;
            awk_substr(poly[i+2],start,stop,yout);
         }
         else if( (strstr(poly[i+2],"X") != NULL)  && 
			      (strstr(poly[i+2],"Y") == NULL) )        // x but not y 
		 {
            start = awk_index(poly[i+2],"X")+1;
            stop = awk_index(poly[i+2],"I") - start;
            awk_substr(poly[i+2],start,stop,xout);
            strncpy(yout,y2base,20);
         }
         else if( (strstr(poly[i+2],"X") == NULL) && 
			      (strstr(poly[i+2],"Y") != NULL) )     // not x, but have y
		 {
            strncpy(xout,x2base,20);
            start = awk_index(poly[i+2],"Y")+1;
            stop = awk_index(poly[i+2],"I") - start;
            awk_substr(poly[i+2],start,stop,yout);
         }
         else
		 {
            strncpy(xout,x2base,20);
	        strncpy(yout,y2base,20);
         } 
       awk_substr(poly[i+2],1,3,tmpoutstr);
	   sprintf(iout_str,"%d",iout);
	   sprintf(jout_str,"%d",jout);
	   printf("%sX%sY%sI%sJ%sD01*\n",tmpoutstr,xout,yout,iout_str,jout_str); 

	   changed = 1;
      }
      else
	  {
          printf("%s", poly[i]);
          printf("%s", poly[i+1] );
          printf("%s", poly[i+2] );
      }
  }    
}

void adjust_poly(int edgecount)
{
int i;

    printf("%s",poly[0]);
    for(i = 1 ; i < edgecount ;i++)
	{
       //print "i = " i "   " poly[i]  |  "cat 1>&2"
       if(( strstr(poly[i],"G01") !=NULL) && (strstr(poly[i+1],"G01")!=NULL) 
                     && (strstr(poly[i +2],"G02") != NULL))
        {
	     fixarc(i);
	     i+=2;
	   }
       else if(( strstr(poly[i],"G03") !=NULL) && (strstr(poly[i+1],"G01")!=NULL) 
                     && (strstr(poly[i +2],"G03") != NULL) ) 
	   {
	    fixarc(i);
	    i+=2;
       }
       else 
	   {
         printf("%s", poly[i]);
       }
    }
    printf("%s", poly[edgecount] );
}


int fixpoly_call( char *infilestr)
{
int polycount;
int endoffile;
char thisline[300];
FILE *file1;
int changed;
int cnt;

  polycount=0;

  file1 = fopen(infilestr,"r");
  if (file1 == NULL)
  {
    printf("In fixpoly, unable to open the input file = %s \n",infilestr);
	exit(-1);
  }

  endoffile=getline(file1,thisline);

  printf("%s",thisline); // $0

  while( (strstr(thisline,"LPD") == NULL) && (endoffile==FALSE)) //  !~ /LPD/)
  {
    endoffile=getline(file1,thisline);
    printf("%s",thisline); // $0
  }

  //strncpy(next1,"tmp",10);
  //strncpy(next2,"tmp",10);
  //strncpy(next3,"tmp",10);
  MINDIST = 3500;
  changed = 0;

  endoffile=getline(file1,thisline);
  while(endoffile == FALSE)
  {
   if( strstr(thisline,"G36") != NULL)   // G36 found
    {
      polycount++;
      cnt =0; 
	 
      while( strstr(thisline,"G37") == NULL )
	  {
         if (cnt < 5000 )
		 {
			 strncpy(poly[cnt],thisline,120); 
			 // printf("poly of %d = %s \n",cnt,thisline);
    	     cnt++;
		 }
         endoffile =getline(file1,thisline);
      }  // end while
      strncpy(poly[cnt],thisline,120);
      adjust_poly(cnt);
   }
   else 
   {
      printf("%s",thisline); //  $0
   }
   endoffile = getline(file1,thisline);
  }
  fclose(file1);

//   print polycount


    if ( changed == 1)
     {
       return(99);
    }
    else
	{
      return(0);
    }

}   // fixpoly_call


int main( int argc, char **argv)

{
int retcode;

	if (argc != 2)
	{
      printf("In fixpoly, wrong number of arguments \n");
	  printf("Usage: fixpoly infile  \n");
	  printf("Example:  fixpoly t.art  \n");
	  exit(-1);
	}
	else
	{
       retcode=fixpoly_call( argv[1]);
	}

  exit(retcode);

}   // end main
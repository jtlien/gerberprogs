#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//
// format the step.txt file for barcode
//

char str_array[120][120];


int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line


//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline
//
// output goes to stdout
//
int formatbarcode_call_out( char *infilestr, char *outfilestr)
{
char thisline[200];
int nf;
int endoffile;
FILE *file1;
FILE *outfile;
int kk;

    outfile = fopen(infilestr,"r");
	if (outfile == NULL)
	{
		printf("In formatbarcode, unable to open the output file = %s \n",outfilestr);
		exit(-1);
	}
    fprintf(outfile, "BARCODE  -157.48 -187.96\n");

	file1= fopen(infilestr,"r");
	if (file1 == NULL)
	{
		printf("In formatbarcode, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    while(endoffile==FALSE)
	{
	 kk=0;
	 while( (kk < strlen(str_array[1]) ) && (kk < 120))
	 {
		 str_array[1][kk]=toupper(str_array[1][kk]);
		 kk += 1;
	 }
     kk=0;
	 while( (kk < strlen(str_array[2]) ) && (kk < 120))
	 {
		 str_array[2][kk]=toupper(str_array[2][kk]);
		 kk += 1;
	 }
     fprintf(outfile,"%s   %s \n",str_array[1],str_array[2]); 

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
    }
	fclose(file1);
	


    fprintf(outfile, "ENDBARCODE\n");
	fclose(outfile);

	return(0);

}  // end formatbarcode_call

//
// output goes to stdout
//
int formatbarcode_call( char *infilestr)
{
char thisline[200];
int nf;
int endoffile;
FILE *file1;
int kk;

    printf( "BARCODE  -157.48 -187.96\n");

	file1= fopen(infilestr,"r");
	if (file1 == NULL)
	{
		printf("In formatbarcode, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    while(endoffile==FALSE)
	{
	 kk=0;
	 while( (kk < strlen(str_array[1]) ) && (kk < 120))
	 {
		 str_array[1][kk]=toupper(str_array[1][kk]);
		 kk += 1;
	 }
     kk=0;
	 while( (kk < strlen(str_array[2]) ) && (kk < 120))
	 {
		 str_array[2][kk]=toupper(str_array[2][kk]);
		 kk += 1;
	 }
     printf( "%s   %s \n",str_array[1],str_array[2]); 

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
    }
	fclose(file1);


    printf( "ENDBARCODE\n");
	return(0);

}  // end formatbarcode_call

int main( int argc, char **argv)
{
int tint;

 tint = formatbarcode_call( argv[1]);

}  // end main

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void formatsize_call( char *infilestr)
{
int nf;
int endoffile;
char thisline[300];
FILE *file1;

double xval;
double yval;

	file1=fopen(infilestr,"r");
	if (file1==NULL)
	{
		printf("In formatsize, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   if (nf > 1)
   {
    xval=atof( str_array[0]);
	yval=atof( str_array[1]);
	xval=xval/10000.0;
	yval=yval/10000.0;

	printf("%f %f \n",xval,yval);
   }
   else
   {
	   printf("Format wrong for input file \n");
	   exit(-1);
   }

   fclose(file1);

} //

   
void formatsize_call_out( char *infilestr, double xsize, double ysize)
{
int nf;
int endoffile;
char thisline[300];
FILE *file1;

double xval;
double yval;

	file1=fopen(infilestr,"r");
	if (file1==NULL)
	{
		printf("In formatsize, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   if (nf > 1)
   {
    xval=atof( str_array[0]);
	yval=atof( str_array[1]);
	xval=xval/10000.0;
	yval=yval/10000.0;

	// printf("%f %f \n",xval,yval);
	xsize=xval;
    ysize=yval;
   }
   else
   {
	   printf("Format wrong for input file \n");
	   exit(-1);
   }

   fclose(file1);

} // end formatsize_call_out

/*
int main( int argc, char **argv)
{

	if(argc != 2)
	{
		printf("In formatsize, wrong number of arguments \n");
		printf("Usage: formatsize infile \n");
		exit(-1);
	}
	else
	{
		formatsize_call( argv[1] );
	}

}  // end main

  */

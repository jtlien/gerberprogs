
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <process.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


#include "utilprogs.h"

void formatviagbr1_call_out( char *infilestr, char *outfilestr)
{
char thisline[300];
int endoffile;
int nf;
int cut;
char X[100];
char Y[100];
char head[100];
char tmp[10][100];
char mode[100];
int modeval;
int val;
char a[10][100];
char b[10][100];
char c[10][100];
FILE *file1;
FILE *outfile;

  strncpy( X,"0",10);
  strncpy(Y,"0",10);

  modeval=0;

  file1 = fopen(infilestr,"r");
  if (file1==NULL)
  {
	  printf("In formatviagbr1, unable to open the input file =%s \n",infilestr);
	  exit(-1);
  }
  outfile = fopen(outfilestr,"w");
  if (file1==NULL)
  {
	  printf("In formatviagbr1, unable to open the output file =%s \n",outfilestr);
	  exit(-1);
  }

 endoffile=getline(file1,thisline);
 nf=split_line(thisline);

 while(endoffile==FALSE)
 {
   awk_substr(thisline,1,3,head);
  
  if( ((strstr(thisline,"D01") != NULL) ||
	  (strstr(thisline,"D02") != NULL) ||
	  (strstr(thisline,"D03") != NULL) ) && (strcmp(head,"G04") !=0) && 
	  (strstr(thisline,"%" ) == NULL) ) 
  {
	split(thisline,tmp[0],tmp[1],"D");
    awk_substr(tmp[1],1,2,mode);
	modeval=atoi(mode);
    cut = 4;
  }
  else 
  {
    cut = 1;
  } 
  if ( (strstr(thisline,"X")!=NULL) && 
	   (strstr(thisline,"Y")!=NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )              // X and Y 
  {
       split(thisline,a[0],a[1],"Y");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1, strlen(a[0]), X );
       awk_substr( a[1],1,strlen(a[1]) - cut,Y) ;
      if(modeval == 3 )                          //D03X...Y...
	  {
        fprintf(outfile,"X %0.0f Y %0.0f\n", atof(X),atof(Y) );
      }
  } 
  else if ((strstr(thisline,"X")!=NULL) &&      
	   (strstr(thisline,"Y")==NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )                // X but no Y
	  
  {
      split(thisline,b[0],b[1],"X");
      awk_substr(b[1],1,strlen(b[1]) - cut,X);
      if(modeval == 3 )                          // D03X....
	  {
        fprintf(outfile,"X %0.0f Y %0.0f\n",atof(X),atof(Y)) ;
      }
  }
  else if((strstr(thisline,"X")==NULL) &&      // Y but no X
	   (strstr(thisline,"Y")!=NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )   
	  
  {
      split(thisline,c[0],c[1],"Y");
      awk_substr(c[1],1,strlen(c[1]) - cut,Y);
      if(modeval == 3 )                          // D03Y
	  {
        fprintf(outfile,"X %0.0f Y %0.0f\n",atof(X),atof(Y)) ;
      }
  }
  else if( strcmp(thisline,"D03*")==0)            // Line has just D03
  {
        fprintf(outfile,"X %0.0f Y %0.0f\n",atof(X),atof(Y));
  }
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
}

fclose(outfile);
fclose(file1);

}  // end formatviagbr1_call_out


void formatviagbr1_call( char *infilestr)
{
char thisline[300];
int endoffile;
int nf;
int cut;
char X[100];
char Y[100];
char head[100];
char tmp[10][100];
char mode[100];
int modeval;
int val;
char a[10][100];
char b[10][100];
char c[10][100];
FILE *file1;

  strncpy( X,"0",10);
  strncpy(Y,"0",10);

  modeval=0;

  file1 = fopen(infilestr,"r");
  if (file1==NULL)
  {
	  printf("In formatviagbr1, unable to open the input file =%s \n",infilestr);
	  exit(-1);
  }

 endoffile=getline(file1,thisline);
 nf=split_line(thisline);

 while(endoffile==FALSE)
 {
   awk_substr(thisline,1,3,head);
  
  if( ((strstr(thisline,"D01") != NULL) ||
	  (strstr(thisline,"D02") != NULL) ||
	  (strstr(thisline,"D03") != NULL) ) && (strcmp(head,"G04") !=0) && 
	  (strstr(thisline,"%" ) == NULL) ) 
  {
	split(thisline,tmp[0],tmp[1],"D");
    awk_substr(tmp[1],1,2,mode);
	modeval=atoi(mode);
    cut = 4;
  }
  else 
  {
    cut = 1;
  } 
  if ( (strstr(thisline,"X")!=NULL) && 
	   (strstr(thisline,"Y")!=NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )              // X and Y 
  {
       split(thisline,a[0],a[1],"Y");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1, strlen(a[0]), X );
       awk_substr( a[1],1,strlen(a[1]) - cut,Y) ;
      if(modeval == 3 )                          //D03X...Y...
	  {
        printf("X %0.0f Y %0.0f\n", atof(X),atof(Y) );
      }
  } 
  else if ((strstr(thisline,"X")!=NULL) &&      
	   (strstr(thisline,"Y")==NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )                // X but no Y
	  
  {
      split(thisline,b[0],b[1],"X");
      awk_substr(b[1],1,strlen(b[1]) - cut,X);
      if(modeval == 3 )                          // D03X....
	  {
        printf("X %0.0f Y %0.0f\n",atof(X),atof(Y)) ;
      }
  }
  else if((strstr(thisline,"X")==NULL) &&      // Y but no X
	   (strstr(thisline,"Y")!=NULL) && 
	   (strstr(thisline,"%")==NULL) &&
	   (strcmp(head,"G04")!=0) )   
	  
  {
      split(thisline,c[0],c[1],"Y");
      awk_substr(c[1],1,strlen(c[1]) - cut,Y);
      if(modeval == 3 )                          // D03Y
	  {
        printf("X %0.0f Y %0.0f\n",atof(X),atof(Y)) ;
      }
  }
  else if( strcmp(thisline,"D03*")==0)            // Line has just D03
  {
        printf("X %0.0f Y %0.0f\n",atof(X),atof(Y));
  }
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
}


fclose(file1);

}  // end formatviagbr1_call

/*
int main( int argc, char **argv)
{

	if (argc != 2)
	{
		printf("In formatviagbr1, wrong number of arguments \n");
		printf("Usage: formatviagbr1 infile \n");
		exit(-1);
	}
   else
   {
	   formatviagbr1_call( argv[1]);
   }

}  // end main

*/

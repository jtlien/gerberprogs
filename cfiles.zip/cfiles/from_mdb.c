#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include "dirent.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


#include "utilprogs.h"

//
//  This program will take all the .gbx files in an mdb directory
//      and offset them by the "Lower left" x, y value in the step.txt
//      file and put the results in the .fgbx files with the same 
//      root name.



char fromfilestr[300];
char tofilestr[300];



int file_count;
int i;

char newfname[300];


void off274x_call_out(char *infilestr, char *xvalstr, char *yvalstr, char *outfilestr);


// first parameter is a directory
//   find all the files in the directory that end with .gbr
//   and run addstar on them and put the results into .gbrf

int main( int argc, char **argv)
{

int debug;
FILE *stepfile;
int endoffile;
int lleft_notfound;
char thisline[300];
char junkstr[100];
double xval;
double yval;
char xstr[100];
char ystr[100];

    debug = 0;

 
	if (argc ==1)
	{

	 stepfile=fopen("step.txt","r");   // read step.txt to get the x,y offset

	 if (stepfile==NULL)
	 {
		 printf("Unable to open the step.txt file \n");
		 exit(-1);
	 }

	 endoffile=getline(stepfile,thisline);

	 lleft_notfound=TRUE;

	 while((lleft_notfound   ) && (endoffile==FALSE))
	 {

		 if (strstr(thisline,"Lower Left") != NULL)
		 {
			 lleft_notfound=FALSE;
		 }
		 else
		 {
		 endoffile=getline(stepfile,thisline);
		 }

	 }

	 if ( lleft_notfound == FALSE)
	 {
		 endoffile=getline(stepfile,thisline);

	//	 printf("line after Lower Left = %s \n",thisline);

	     split_line_seps(thisline,"=");
		 strncpy(junkstr,str_array[1],120);
         strncpy(ystr,str_array[2],120);

		 split_line_seps(junkstr,"Y");

		 strncpy(xstr,str_array[0],120);

		// printf("xstr,ystr = %s %s \n",xstr,ystr); 

		 xval=atof(xstr);
		 yval=atof(ystr);

		// printf("xval,yval = %f %f \n",xval,yval);
		 sprintf(xstr,"%d",(int) (-xval)*100000);
		 sprintf(ystr,"%d",(int) (-yval)*100000);

        // printf("xstr,ystr = %s %s \n",xstr,ystr); 

	 }
	 else
	 {
		 printf("Unable to find the (Lower Left) line in step.txt \n");
		 exit(-1);
	 }



	 fclose(stepfile);

	 file_count = scandir_matchext(".",0,".gbx");  // get all .gbx files

	 // printf("file count = %d \n", file_count);

	 for(i=0; i < file_count; i += 1)
	 {
	  

	   replace_ext( scan_array[i], newfname,".fgbx");

	   if (debug)
	   {
	   printf("Scan array = %s newfname = %s \n",scan_array[i], newfname);
	   }

	   strncpy(fromfilestr,scan_array[i],120);

	   if (debug)
	   {
	   printf("fromfilestr = %s \n",fromfilestr);
	   }


      // printf("test i = %d \n",i);

	   
       strncpy(tofilestr,newfname,120);

	   strncpy(fromfilestr,scan_array[i],120);

	   if (debug)
	   {
       printf("newfname = %s scan_array[i] = %s fromfilestr = %s tofilestr = %s xstr=%s ystr=%s\n",
		   newfname, scan_array[i], fromfilestr, tofilestr, xstr, ystr);
	   }

       off274x_call_out( fromfilestr, xstr, ystr, tofilestr);  // update the original

	 }


	} 
   else
   {
	   printf("Wrong number of arguments to from_mdb \n");
	   printf("Usage: from_mdb \n");
	   printf(" will run off274x on all .gbx files and put them in .fgbx files \n");
   }

}

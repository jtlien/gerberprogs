#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

#include "utilprogs.h"

// gather

// Gather data needed for panelization
// Get part data from RDB
// Case-shift file names where necessary
// NOT IMPLEMENTED:
// Confirm date integrity of biased data
// Completeness check

// updated 9-16-99
// Add more verbiage at beginning and end
// version 0.1

// updated 10-22-99
// Copy makelog file from RDB to top level - part type fields needed
// version 0.2

// updated 7-27-00
// allow use of path other than RDB as source
// add verbiage about golden control file
// Check separately for presence of brd_info directory
// Check for zero-length control file
// version 0.3

// Updated 05-14-01
// Change path variables for new server
// Target is current directory - checks this to be sure current
//  directory has contents to suggest it is the correct one
// Remove option to use RDB for source data
// Searches for control files, gives option to delete them
// Copies control folder from source
// If early exit, no data is modified
// Case-shifts all file names to lowercase, but makes OFFSETS uppercase
// Version 0.4

// Updated 08-30-01
// Clarify some prompts 
// Read .stagingpath file to look for source data path and allow
//  entry of source data path
// Correct case-shift code to use proper paths
// Add check for correctly-named post-bias.gwk file
// Version 0.5

// Updated 09-04-01
// Correct problem with case-shifting
// Version 0.51

void gather_call()
{
char REV[50];
char *HOME;
char PWD[300];
char RDB[300];
char basename[300];
char brdnum[300];
char fromfilestr[300];
char tofilestr[300];
char chkfilestr[500];
char validsource[300];
char stagepathstr[300];
char systemstr[300];
char sourcepath[300];
char fullpath[300];
char spath[300];
char rmfilestr[300];
char pp[20];
char thisline[300];
int endoffile;
char answr[30];

int conred;
int cdthere;
int offthere;
int minthere;
int res;
int release_stat;
int numartfiles;
char *homestr;
int ctlfilecnt;
int i;

FILE *stagingpathfile;
// FILE *ctllistfile;


   HOME=getenv("HOME");

   printf("HOME = %s \n",HOME);

   if (WINDOWS)
   {
	   strncpy(dirsep,"\\",10);
   }
   else
   {
	   strncpy(dirsep,"/",4);
   }

   strncpy(REV,"0.51",20);

   homestr= getenv("HOME");
   strncpy(HOME,homestr,120);


release_stat=1;       // change to 1 when released !!!!!!!!!!

// General variables

   getwd(PWD);
   printf( "******** GATHER: Prepare Data for Panelization ********\n");

   printf( "Some files will be copied from your RDB structure created with rdb-relprep.\n");

   printf( "Your target directory will be the current directory: ");
   printf( "%s\n",PWD);
   printf( "Checking current directory for valid contents... \n");

   getwd(PWD);

   //basename=${PWD##*\/}

   get_full_path_end( PWD, basename);

   conred=0;
   if ( ! (dir_exists( "274x" ) ) )  
   {
     conred = conred + 1;
   }
   else
   {
    // artfiles=$(ls 274x/*.art 2> /dev/null)
    numartfiles=scandir_matchext("274x",0,".art");
   
    if (numartfiles == 0)
    {
      conred = conred + 2;
    }
   }
 if ( file_exists("cd.txt" )   )    // exists and is ascii
 {
   res=sgrep("cd.txt",basename,100);           // >/dev/null 2>/dev/null

   if (res == 1)
   {
      conred = conred + 4;
   }
 }
 else
 {
	 conred = conred + 32;
 }

   strncpy(chkfilestr,"test",15);      //  test/$basename.ris
   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,basename,120);
   strncat(chkfilestr,".ris",10);

   //printf("chkfilestr = %s conred = %d \n",chkfilestr, conred);

   if ( ! (file_exists(chkfilestr) ) )    // -a test/$basename.ris )
   {
     conred = conred + 8;
  }
 
 
   strncpy(chkfilestr,"test",15);      //  test/$basename.dat
   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,basename,120);
   strncat(chkfilestr,".dat",10);

  // printf("chkfilestr = %s conred=%d\n",chkfilestr,conred);
   if ( ! (file_exists( chkfilestr) ) )   // -a test/$basename.dat
   {
     // conred = conred + 16;
      printf("Missing %s file \n", chkfilestr);
  }
 
 if ( ! (dir_exists( "brd_info") ) )   //  directory brd_info exists
   {
      conred = conred + 64;
  }
 if ( ! (dir_exists( "cam") ) )   //  cam directory exists
   {
      conred = conred + 128;
  }


 if (conred != 0)
 {
  printf( "OOPS! \n");
  printf( "Change to the board directory with your cam data and re-run. Error=%d\n",conred);

  if ( conred & 1)
  {
	  printf("Missing 274x subdirectory \n");
  }
 if ( conred & 2)
  {
	  printf("No .art files in 274x subdirectory \n");
  }
 if ( conred & 4)
  {
   printf("The cd.txt file does not reference %s \n",basename);
  }
 if ( conred & 8)
  {
	  printf("No  %s.ris file in test subdirectory\n",basename);
  }
 if ( conred & 16)
  {
	  printf("No  %s.dat file in test subdirectory\n",basename);
  }
 if ( conred & 32)
  {
	  printf("No  cd.txt file in current directory\n");
  }
 if ( conred & 64)
  {
	  printf("No brd_info subdirectory\n");
  }
 if ( conred & 128)
  {
	  printf("No cam subdirectory \n");
  }
  exit(-1);
 }
 else
 {
  printf( "OK!\n");
 }


// source data path switch 

strncpy(chkfilestr,HOME,120);    // $HOME/stagingpath
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,".stagingpath",30);

if ( ! (file_exists( chkfilestr) ) )    // -a $HOME/.stagingpath 
{
   strncpy(pp,"n",10);
}
else                               // .stagingpath exists
{
   //spath=$(cat $HOME/stagingpath)
	
	strncpy(stagepathstr,HOME,200);    // $HOME/.stagingpath
   strncat(stagepathstr,dirsep,10);
   strncat(stagepathstr,".stagingpath",30);

   stagingpathfile=fopen( stagepathstr,"r");

   if ( stagingpathfile == NULL)
   {
	   printf("Unable to open the HOME%s.stagingpath file for read \n",dirsep);
	   strncpy(spath,"",10);
   }
   else
   {
	   endoffile=getline(stagingpathfile,thisline);
	   strncpy(spath,thisline,120);
	   fclose(stagingpathfile);
   }

   if ( ! (file_exists( spath ) ) )
   {
      strncpy(pp,"n",10);
   }
   else
     {
      // fullpath=$spath/rdb/board/$basename

	   strncpy(fullpath,spath,120);  // fullpath = $spath/rdb/board/$basename
	   strncat(fullpath,dirsep,10);
	   strncat(fullpath,"rdb",10);
	   strncat(fullpath,dirsep,10);
	   strncat(fullpath,"board",15);
	   strncat(fullpath,dirsep,10);
	   strncat(fullpath,basename,120);

	   printf("RDB path = %s \n", fullpath );

      printf( "...............................\n");
      while ( (strcmp(pp,"y") != 0 ) && (strcmp(pp,"n") != 0 ) ) // 
      {
         printf( "Is your RDB data in %s ? (y/n) \n",fullpath);
         gets(pp);
      }
  }
}

strncpy(validsource,"",10);

if ( strcmp(pp,"n" ) == 0 )
{
   while ( strcmp(validsource,"yes" ) != 0 )
   {
      printf( "Enter the full path name of the RDB source data (must end in board number): \n");
      gets(sourcepath); 
      if ( dir_exists( sourcepath ) )
      {
	   strncpy(validsource,"yes",10);
      }
     else
      {
	   printf( "Your entry is not an existing directory!\n");
      }
   }
}
else
{
   strncpy(sourcepath,fullpath,200);
}


//brdnum=${sourcepath##*/}

get_full_path_end(sourcepath,brdnum);

if ( strcmp(brdnum,basename ) != 0 )
{
  printf( "ERROR! Your current directory name does not\n");
  printf( "match the board number in your RDB source path. Exiting!\n");
  printf( "Current Directory:   %s\n ",PWD);
  printf( "RDB Source Path Board #:  %s \n",brdnum);
   exit(-1);
}


strncpy(RDB,sourcepath,200);

// printf("RDB = %s \n",RDB);

if ( ! (dir_exists(RDB) ) )
{
  printf( "ERROR! Cannot find %s. Exiting!\n",RDB);
   exit(-1);
}


//printf("About to call chmod \n");

system("chmod 777  *");


if ( ! (dir_exists( "brd_info" ) ) )
{
  printf( "ERROR! No brd_info directory in current directory. Exiting!\n");
  exit(-1);
}


// Find and delete all control files  #####################
// Necessary to insure one good file 

//system("gfind . -name *.ctl -print > ctllist");  // gnu find find.exe renames from c:\doc\UnxUtils

ctlfilecnt = scandir_matchext("control",1,".ctl");

printf("%d control files found  \n", ctlfilecnt);

//if ( (file_exists( "ctllist" ) ) && ( file_not_empty( "ctllist") ) )

if ( ctlfilecnt > 0 )
{
   
   printf( "Control file in rdb structure will be used.\n");
   printf( "WARNING - control file(s) found in control subdirectory.\n");

 //   print_file("ctllist");
   for(i=0; i < ctlfilecnt; i += 1)
   {
	   printf("control%s%s \n",dirsep,scan_array[i]);
   }

	strncpy(answr,"",10);
   while ( (strcmp(answr,"y") !=0 ) && (strcmp(answr,"n") != 0 ) ) 
   {
      printf( "Want to delete them? (y/n) \n");
      gets(answr);
   }
   if ( strcmp(answr,"n") == 0 ) 
   {
     printf( "Re-name or move any files you want to keep and re-run.\n");
	 for(i=0; i < ctlfilecnt; i += 1)
	 {
	  printf("removing %s \n",scan_array[i]);

      rm_file(scan_array[i]);
	 }
      exit(-1);
   }
   else
   {
	  //ctllistfile = fopen("ctllist","r");
	  
	  //endoffile=getline(ctllistfile,thisline);

      //while(endoffile==FALSE)    //  read ctlfile
      //{
	//	 strncpy(ctlfile,thisline,120);
       //  printf( "...deleting %s\n",ctlfile);
       //  rm_file(ctlfile);

	//	 endoffile=getline(ctllistfile,thisline);
     // }   //< ctllist
	 // fclose(ctllistfile);

      // rm -f ctllist
	 // rm_file("ctllist");

      for(i=0; i < ctlfilecnt; i += 1)
	  {
	    printf("removing control\\%s \n",scan_array[i]);

		strncpy(rmfilestr,"control",30);
		strncat(rmfilestr,dirsep,10);
		strncat(rmfilestr,scan_array[i],120);
        rm_file(rmfilestr);
	  }

   }
}

// rm_file("ctllist");


// Check for control file in source path
  printf( "Checking presence of control file...\n");

strncpy(chkfilestr,RDB,100);   // $RDB/control/$basename.ctl
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"control",20);
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,basename,120);
strncat(chkfilestr,".ctl",10);

if ( ! (file_exists( chkfilestr) ) )   // -a $RDB/control/$basename.ctl 
{
   printf( "ERROR! %s%scontrol%s%s.ctl not present. Exiting!\n",
	               RDB,dirsep,dirsep,basename);
   exit(-1);
}

// Verify presence of CAM files


printf( "Verifying the presence of necessary files in cam\n");


if ( dir_exists("cam" ) )
{

   change_dir("cam");
 
   system("chmod 777 *");
   change_dir("..");

  // printf("Returned from chmod \n");

   // case-shift file names
   //tlist=$(ls cam 2>/dev/null)
   //for tfile in $tlist
   //{
    //  if ( -f cam/$tfile )
    //  {
      //   newname=$tfile
      //   typeset -l newname
      //   if ( $tfile != $newname )
      //   {
      //      mv cam/$tfile cam/$newname
      //  }
    // }
   //}

   strncpy(chkfilestr,"cam",10);      // cam/bias.rpt
   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,"bias.rpt",20);

   //ls cam/bias.rpt > /dev/null 2> /dev/null
   //rpthere=$? 
   printf("About to check if file exists = %s  \n",chkfilestr);

   if ( ! (file_exists( chkfilestr) ) )   // rpthere != 0 
   {
      printf( "ERROR! cam%sbias.rpt file missing. Exiting!\n",dirsep);
      exit(-1);
   }
   //ls cam/post-bias.gwk > /dev/null 2> /dev/null
   //pbthere=$?
   strncpy(chkfilestr,"cam",10);   // cam/post-bias.gwk
   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,"post-bias.gwk",30);

   if ( !(file_exists( chkfilestr) ) )         // pbthere != 0 
   {
      printf( "ERROR! cam%spost-bias.gwk file missing or mis-named. Exiting!\n",dirsep);
      exit(-1);
  }
  if (WINDOWS)
  {
   system("chmod 777 cam\\*\\*");


  }
  else
  {
	  system("chmod 777 cam/*/*");
  }

}
else
{
  printf( "ERROR! cam directory missing. Exiting!\n");
   exit(-1);
}


// Verify presence of 274x files
printf( "Verifying the presence of >= 1 art file in 274x...\n");
if ( dir_exists("274x" ) )
{
   // case-shift file names
   //xlist=$(ls 274x 2>/dev/null)
   //for xfile in $xlist
   //{
     // if ( -f 274x/$xfile )
      //{
       //  newname=$xfile
      //   typeset -l newname
       //  if ( $xfile != $newname )
       //  {
       //     mv 274x/$xfile 274x/$newname
       // }
    // }
   //}
   //artfiles=$(ls 274x/*.art 2> /dev/null)
   numartfiles=scandir_matchext("274x",0,".art");
   if (numartfiles == 0)
   {
      printf( "ERROR! No art files in 274x directory. Exiting!\n");
      exit(-1);
  }
 change_dir("274x");

 system("chmod 777 *");
 change_dir("..");

}
else
{
   printf( "ERROR! 274x directory missing. Exiting!\n");
   exit(-1);
}

//################ Need to chmod 777 on everything!!!!!!!!!!!!!!!!

printf( "There are %d art files in the 274x directory.\n",
                      numartfiles);
printf( "OK!\n");


strncpy(fromfilestr,RDB,200);     // $RDB/cd.txt
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"cd.txt",10);

cp_file(fromfilestr,"cd.txt");    // cd.txt

//cp $RDB/cd.txt . 2>/dev/null

// Verify presence of brd_info files
printf( "Verifying the presence of information files in brd_info...\n");

   
cdthere=1;
if (file_exists( "cd.txt") )
 {
	   cdthere = 0;
 }


//ls cd.txt > /dev/null 2> /dev/null
//cdthere=$?


if ( dir_exists( "brd_info" ) )
{
   // case-shift file names
   system("chmod 777 brd_info");
   change_dir("brd_info");
   system("chmod 777 *");
   change_dir("..");

   //bflist=$(ls brd_info 2>/dev/null)
   //for bfile in $bflist
   //{
     // if ( -f brd_info/$bfile )
     // {
	 //  newname=$bfile
	//   typeset -l newname
	 //  if ( $bfile != $newname )
	  //  { 
	  //  mv brd_info/$bfile brd_info/$newname
      //  }
     // }
  // }

   strncpy(chkfilestr,"brd_info",20);
   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,"offsets",30);
   offthere=1;
   if (file_exists( chkfilestr) )
   {
	   offthere = 0;
   }
  //ls brd_info/offsets > /dev/null 2> /dev/null
   //offthere=$?
   strncpy(chkfilestr,"brd_info",20);   // brd_info/min_clearance.txt
   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,"min_clearance.txt",30);
   minthere=1;
   if (file_exists( chkfilestr) )
   {
	   minthere = 0;
   }
   //ls brd_info/min_clearance.txt > /dev/null 2> /dev/null
  // minthere=$?
   if ( offthere == 0 && cdthere == 0 && minthere == 0 )
   {
      printf( "All necessary info files present!\n");

      // mv brd_info/offsets brd_info/OFFSETS      has not effect on windows
      system("chmod 777 *");
   }
   else
   {
      if ( offthere != 0 )
      {
	   printf( "ERROR! brd_info%soffsets file missing. Exiting!\n",dirsep);
	   rm_file("cd.txt");
	   exit(-1);
      }
      if ( cdthere != 0 )
      {
	   printf( "ERROR! cd.txt file missing. Exiting!\n");
	   exit(-1);
       }
      if ( minthere != 0 )
      {
	    printf( "ERROR! brd_info%smin_clearance.txt file missing. Exiting!\n",dirsep);
	    rm_file("cd.txt");
	    exit(-1);
      }
  }
}
else
{
  printf( "ERROR! brd_info directory missing. Exiting!\n");
   rm_file("cd.txt");
   exit(-1);
}


// Copy data from RDB to local directory
printf( "Copying data from %s.....\n",RDB);

// 274D artwork files.....

strncpy(systemstr,"cp -R ",20);  // cp -R $RDB/artwork .
strncat(systemstr,RDB,120);
strncat(systemstr,dirsep,10);
strncat(systemstr,"artwork .",30);

printf("Performing copy - %s \n",systemstr);
system(systemstr);

//cp  -R $RDB/artwork .

// case-shift file names
//chmod 777 artwork artwork/*
//alist=$(ls artwork 2>/dev/null)
//for afile in $alist
//{
 //  if ( -f artwork/$afile )
 //  {
  //    newname=$afile
  //    typeset -l newname
  //    if ( $afile != $newname )
  //    {
  //       mv artwork/$afile artwork/$newname
  //   }
  //}
//}

// control folder

strncpy(systemstr,"cp -R ",20);  // cp -R $RDB/control
strncat(systemstr,RDB,120);
strncat(systemstr,dirsep,10);
strncat(systemstr,"control .",20);

printf("Performing copy - %s \n",systemstr);
system(systemstr);

// cp -R $RDB/control .
system("chmod 777 control");
change_dir("control");
system("chmod 777 *");
change_dir("..");


// case-shift file names

//clist=$(ls control 2>/dev/null)
//for cfile in $clist
//{
 //  if ( -f control/$cfile )
 //  {
 //     newname=$cfile
 //     typeset -l newname
  //    if ( $cfile != $newname )
  //    {
  //       mv control/$cfile control/$newname
   //  }
  //}
//}

// test folder
system("chmod 777 test");
change_dir("test");
system("chmod 777 *");
change_dir("..");

// case-shift file names
//tlist=$(ls test 2>/dev/null)
//for tfile in $tlist
//{
  // if ( -f test/$tfile )
  // {
  //   newname=$tfile
   //   typeset -l newname
   //   if ( $tfile != $newname )
   //  {
    //     mv test/$tfile test/$newname
    // }
  //}
//}

// makelog for part type info

strncpy(fromfilestr,RDB,200);   // $RDB/report/makelog
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"report",20);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"makelog",20);

cp_file(fromfilestr,"makelog");

//cp $RDB/report/makelog .
system("chmod 777 makelog");

// aperture table
mkdir("aper");

strncpy(fromfilestr,RDB,120);   // $RDB/aper/$basename.prt
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"aper",20);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,basename,120);
strncat(fromfilestr,".prt",20);

strncpy(tofilestr,".",10);          // ./aper/basename.prt
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"aper",10);
strncat(tofilestr,dirsep,10);
strncat(tofilestr,basename,120);
strncat(tofilestr,".prt",20);

cp_file(fromfilestr,tofilestr);

//cp  $RDB/aper/$basename.prt ./aper

strncpy(fromfilestr,RDB,200);       // $RDB/history.txt
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"history.txt",30);

cp_file(fromfilestr,"history.txt");

// cp $RDB/history.txt .
change_dir("aper");
system("chmod 777 * \n");
change_dir("..");

system("chmod 777 *.txt");

// Do early check for problem file names
system("chmod 777 cam");

change_dir("cam");
system("chmod 777 *");
change_dir("..");

// case-shift file names
//cmlist=$(ls cam 2>/dev/null)
//for cmfile in $cmlist
//{
 //  if ( -f cam/$cmfile )
  // { 
  //    newname=$cmfile
  //    typeset -l newname
   //   if ( $cmfile != $newname )
    //  { 
//	 mv cam/$cmfile cam/$newname
   //  }
  //}
//}
strncpy(chkfilestr,"cam",10);   // cam/post-bias.gwk
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"post-bias.gwk",30);

if ( ! (file_exists( chkfilestr) ) ) // -f cam/post-bias.gwk 
{
   printf( "WARNING! Can't find cam%spost-bias.gwk! Assure it is named correctly!\n",dirsep);
}

printf( "FINISHED!\n");
printf( "Review control file for correct layers & mask revs.\n");

exit(0);

} // end 


int main (int argc, char **argv)
{
int numargs;

// Check for correct invocation
numargs=argc;
if (numargs != 1)
{
   printf( "Error in gather, no arguments allowed! \n");
   exit(-1);
}

  gather_call();

}  // end main

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include "dirent.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//
//  This program is used to gather multiple LPC segments into one big LPC 
//      
//     
//

char lpc_array[100000][300];


void gather_lpc_call( char *infilestr1, char *outfilestr)
{
  FILE *infile1;
  FILE *outfile;

  int endoffile;
  char thisline[300];
  
  int ii;
 
  int lpcflag;
  int lpdflag;
  int lpccount;

  int lpcindex;
  int lp_thisline;
  int mo2flag;
  int debug;

  char percentchar;

  percentchar='%';

  debug = 0;

  lpcindex=0;


  infile1 = fopen(infilestr1,"r");
  if (infile1==NULL)
    {
      printf("In gather_lpc, unable to open the input file = %s \n",
	     infilestr1);
      exit(-1);
    }

  outfile = fopen(outfilestr,"w");
  if (outfile==NULL)
    {
      printf("In gather_lpc, unable to open the output file = %s \n",
	     outfilestr);
      exit(-1);
    }

  endoffile=getline(infile1,thisline);

  lpdflag=TRUE;
  lpcflag=FALSE;
  lpccount=0;


  while(endoffile==FALSE)
    {

	  mo2flag=FALSE;

      lp_thisline=FALSE;

      if ((thisline[0] == 'M' ) && (thisline[1]=='0')
		  && (thisline[2]=='2') && (thisline[3]=='*') )  // M02
		
	  {
        mo2flag=TRUE;

	  }
      if ((thisline[0] == '%' ) && (thisline[1]=='L')
		  && (thisline[2]=='P') && (thisline[3]=='C')
		  && (thisline[4]=='*') && (thisline[5]=='%'))        // begin of an LPC block
	  {
          lp_thisline=TRUE;
		  lpcflag=TRUE;
		  lpdflag=FALSE;
		  lpccount+=1;
	  }

      if ((thisline[0] == '%' ) && (thisline[1]=='L')
		  && (thisline[2]=='P') && (thisline[3]=='D') 
		  && (thisline[4]=='*') && (thisline[5]=='%'))        // begin of an LPD block
	  {
          lp_thisline=TRUE;
		  lpcflag=FALSE;
		  lpdflag=TRUE;
	  }


	  if (lp_thisline==FALSE)
	  {
	   if ((lpdflag) && ( ! mo2flag))
	   {
         fprintf(outfile,"%s",thisline);
	   }
	   else
	   {
		   if (lpcindex < 100000 )
		   {
			if (mo2flag ==FALSE)
			{
		      strncpy(lpc_array[lpcindex],thisline,300);
              lpcindex +=1;
			}
		   }
		   else
		   {
			printf("Too many lpc lines in file , exceed 100000 \n");
			exit(-1);
		   }
	   }
	  }


	  endoffile=getline(infile1,thisline);

	 }

    fclose(infile1);


	printf("%d lines of LPC info read \n", lpcindex);

	fprintf(outfile,"%cLPC*%c\n",percentchar,percentchar);

	for (ii=0; ii < lpcindex; ii += 1)
	{
		fprintf(outfile,"%s",lpc_array[ii]);
	}

	fprintf(outfile,"%cLPD*%c\n",percentchar,percentchar);

	fprintf(outfile,"M02*\n");

    fclose(outfile);

	printf("LPC count = %d \n",lpccount);


}  // end of gather_lpc_call



int main( int argc, char **argv)
{


	if (argc != 3)
	{
       printf("In gatherlpc, wrong number of arguments\n");
	   printf("Usage: gatherlpc infile outfile \n");

	}
	else
	{
		gather_lpc_call(argv[1], argv[2]);
    }


}  // end main

  

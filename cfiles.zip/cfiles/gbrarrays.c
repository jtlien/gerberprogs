#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define LINELEN  120

// calling Syntax
//     gbrarray xcoord ycoord xstep ystep xstepcount ystepcount infile > outfile

// Program arrays out gerber data in infile to outfile placeing a copy
// of the gerber data at each coordinate in the coordfile
//
// Program calls executable dooffset (created from dooffset.c) please
// see the source file for possible side effects or input requirements

 // like dooffsetn, but passes lines that start with % directly to output
 //                  so that some 274x style gerbers can be offset
 //


void getstring274( val , myval)
char*  val; char*  myval;
{
  val++;
  *myval= *val; 
  val++;
  myval++;
  while( isdigit(*val) ){
     *myval = *val ;
     val++;
     myval++;
  }
  *myval = '\0';
}

void getbefore( mystring, myval , mychar)
char* mystring; char* myval ; char mychar;
{
  while( *mystring != mychar ){
     *myval = *mystring ;
     mystring++;
     myval++;
  }
  *myval = '\0';
}

void getrest( instring,  outstring,  mychar)
char*  instring; char*  outstring; char mychar;
{
  while( *instring != mychar ){
     instring++;
  }
  instring++;
  while( isdigit(*instring) || *instring == '-' ){
    instring++;
  }

  while( *instring != '\0' ){
       *outstring = *instring ;
       outstring++;
       instring++;
  }
  *outstring = '\0';
}

void ProcessString274(char *thestring, int Xval, int Yval)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];
    
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 printf("%sX%dY%d%s",FIRST,atoi(X)+  Xval,atoi(Y)+ Yval, REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	printf("%sX%d%s",FIRST,atoi(X)+  Xval ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	printf("%sY%d%s",FIRST,atoi(Y)+  Yval,REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

ProcessStringOut274(char *thestring,int  Xval, int  Yval, FILE *ofile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];

     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 fprintf(ofile,"%sX%dY%d%s",FIRST,atoi(X)+  Xval,atoi(Y)+ Yval, REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	fprintf(ofile,"%sX%d%s",FIRST,atoi(X)+  Xval ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	fprintf(ofile,"%sY%d%s",FIRST,atoi(Y)+  Yval,REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       fprintf(ofile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}


void dooffset_call(char *infilestr, int in1 , int in2)
{
FILE *thisfile;

   char line[LINELEN];


   thisfile =  fopen( infilestr ,"r");
   if (thisfile != NULL){
       while( fgets(line, LINELEN, thisfile) != NULL){
          ProcessString274(line, in1, in2);
       } 
   }
   fclose(thisfile);

}

void dooffset_call_out(char *infilestr, int in1 , int in2, char *outfilestr)
{
FILE *thisfile;
 FILE *ofile;

   char line[LINELEN];

   thisfile =  fopen( infilestr ,"r");

   ofile = fopen(outfilestr,"w");
   if (ofile != NULL)
     {
      if (thisfile != NULL)
        {
         while( fgets(line, LINELEN, thisfile) != NULL)
           {
	   ProcessStringOut274(line, in1, in2, ofile);
           } 
	}
      else
	{
          printf("Unable to open the input file = %s \n",infilestr);
          exit(-1);
        }  
     }
   else
     {
       printf("Unable to open the output file = %s \n",outfilestr);
       exit(-1);
     }
   fclose(thisfile);

}


// 
//  Array out a file of gerbers using step and repeat
//

void gbrarray_call( int xcoord, int ycoord, int xstep,int  ystep,int  xstpnum,int ystpnum , char *infilestr,char *outfilestr)
{
int nf;
char thisline[300];
int endoffile;
FILE *file1;
 int jj, kk;

 for (jj=0; jj < xstpnum; jj+=1)
   {
     for(kk=0; kk < ystpnum; kk+=1)
       {
	 dooffset_call_out(infilestr, xcoord+(jj*xstep), ycoord+(kk*ystep),
                             outfilestr );
       }
   }

} // 

int main( int argc, char **argv)
{

	if (argc != 9)
	{
		printf("In gbrarray, wrong number of arguments \n");
		printf("Usage: gbrarray xcoord ycoord xstep ystep xstepcount ystepcount infile outfile\n");
		exit(-1);
	}
	else
	{
	  gbrarray_call( atoi(argv[1]), atoi(argv[2]), 
                         atoi(argv[3]), atoi(argv[4]), 
                         atoi(argv[5]), atoi(argv[6]),
                          argv[7], argv[8]);
	}

} // end main

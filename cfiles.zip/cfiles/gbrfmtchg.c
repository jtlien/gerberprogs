
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// Rev 1
// Title: GbrFmtChg (Gerber Format Change)
// written by Ted Ammann  1/2/97
// calling syntax
//    GbrFmtChg -v mult1=3 infile > outfile

// Program changes the number of digits of gerber data to 4
// digits to the right of the decimal point.  It does this based on the 
// commnad line parameter "mult1".  It multplies all X and Y coordinate
// data by 10 raised to the difference of mult1 and 4.
// For example, say the input data had 5.2 format so that mult1 = 2
// All X and Y coordinates would be mulitpied by 100 (i.e., 10^2)
// so that it would then be in 5.4 format. 

// Revision history
//  Rev1  released on 1/2/97

//**************START OF MAIN *********************************
// handles data depending on if the line has  X & Y data,
// X data only, Y data only , or no X,Y data.
// Simply multiplies X,Y coordinates by 25.4 to convert to mm 
//********************************************************************


void gbrfmtchg_call_out(char *multstr, char *infilestr, char *outfilestr)
{
FILE *file1;
FILE *outfile;

char thisline[200];
int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];
double xval;
double yval;

char X[120];
char Y[120];
int val;
int mult1;
int tmp;
double mult;


    file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	}

    outfile  = fopen(outfilestr, "w");

    if (outfile == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",outfilestr);
	  exit(-1);
	}

// mult1 is command line varible that is current format

  mult1 = atoi(multstr);

  tmp = 4 - mult1;          

  //  output a warning if precision is x.5 or more

  if( tmp < 0)
  {
     printf("FORMAT IS GREATER THAN 5.4 \n" );
     printf("DATA MAY BE LOST \n");
  }

 // MULT = 10 ** tmp 
  mult = pow(10.0,tmp);


 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL))     // G54 preceeds aperture
   {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       
       
       xval=atof(X);
       yval=atof(Y);
       xval=xval*mult;
       yval=yval*mult;
       fprintf(outfile,"X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
  }
  // if line has only X data modify it
  else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {
      split(thisline,b[0],b[1],"X");
      split(thisline,d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
      xval=atof(X);
     
      xval= mult * xval;
      fprintf(outfile,"X%0.0fD%s\n", xval,d[1]);
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
      split(thisline,c[0],c[1],"Y");
      split(thisline,d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
   
      yval=atof(Y);
      yval=yval * mult;
      fprintf(outfile,"Y%0.0fD%s\n",yval,d[1]);
  }
  // line has no X or Y data so just output it
  else
  {
    fprintf(outfile,"%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }

 fclose(file1);

 fclose(outfile);
}  // end gbrfmtchg_call_out

void gbrfmtchg_call(char *multstr, char *infilestr)
{
FILE *file1;
char thisline[200];
int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];
double xval;
double yval;

char X[120];
char Y[120];
int val;
int mult1;
int tmp;
double mult;


    file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	}

// mult1 is command line varible that is current format

  mult1 = atoi(multstr);

  tmp = 4 - mult1;          

  //  output a warning if precision is x.5 or more

  if( tmp < 0)
  {
     printf("FORMAT IS GREATER THAN 5.4 \n" );
     printf("DATA MAY BE LOST \n");
  }

 // MULT = 10 ** tmp 
  mult = pow(10.0,tmp);


 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL))     // G54 preceeds aperture
   {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       
       
       xval=atof(X);
       yval=atof(Y);
       xval=xval*mult;
       yval=yval*mult;
       printf("X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
  }
  // if line has only X data modify it
  else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {
      split(thisline,b[0],b[1],"X");
      split(thisline,d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
      xval=atof(X);
     
      xval= mult * xval;
      printf("X%0.0fD%s\n", xval,d[1]);
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
      split(thisline,c[0],c[1],"Y");
      split(thisline,d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
   
      yval=atof(Y);
      yval=yval * mult;
      printf("Y%0.0fD%s\n",yval,d[1]);
  }
  // line has no X or Y data so just output it
  else
  {
    printf("%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }

 fclose(file1);

}  // end gbrfmtchg_call

int main( int argc, char **argv)
{
	if ( argc != 3)
	{
		printf("In gbrfmtchg, wrong number of arguments \n");
		printf("Usage: gbrfmtchg multval infile \n");
		exit(-1);
	}
	else
	{
		gbrfmtchg_call( argv[1], argv[2]);
	}

}  // end main
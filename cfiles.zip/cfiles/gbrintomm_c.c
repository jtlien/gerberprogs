
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

FILE *file1;

char thisline[200];
char str_array[120][120];
int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];

double xval;
double yval;

char X[120];
char Y[120];
int val;

// Rev 1
// Title: GbrINtoMM ( Gerber Inches to MM)
// written by Ted Ammann  1/2/97
// calling syntax
//   GbrINtoMM infile > outfile
// Program converts Gerber data from inches to millimeters
// Revision history
//  Rev1  released on 1/2/97

//**************START OF MAIN *********************************
// handles data depending on if the line has  X & Y data,
// X data only, Y data only , or no X,Y data.
// Simply multiplies X,Y coordinates by 25.4 to convert to mm 
//********************************************************************

void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk;

  ii=0;
  kk = 0;

 while((instr[ii] != srchstr[0]) && ( ii < strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;


}  // end split

//
// perform awk compatible awk_index, counts from 1 at the leftmost
//
int awk_index( char *instr, char *inchr)
{
int kk,ll,mm;
char tstr[120];

	if (strstr(instr, inchr) == NULL)    // not found at all in string, return 0
	{
		return(0);
	}
	else    // the inchr string is a substring
	{
		kk = 0;
		while( kk < strlen( instr))
		{
          ll = 0;
		  mm = kk;
		  while( mm < strlen( instr))
		  {
			tstr[ll] = instr[mm];
			mm += 1;
			ll += 1;
		  }
		  tstr[ll] = 0;
		  if (strstr( tstr,inchr) == NULL)  // no longer found as substring
		  {
			return(kk);
		  }
		 kk += 1;
		}
	}

  return(0);

 
} // awk compatible index


// perform awk compatible substr, except the 4th parameter is the
//   result string
//
void awk_substr( char *instr, int sbegin, int slength, char *resultstr)
{

char tstr[120];
int kk;
int ll;

     if ( sbegin > 0)
	 {
		 sbegin = sbegin-1;
	 }
     kk = sbegin;
     ll = 0;
	 while ( ( kk < strlen(instr) && ( ll < slength)) )
	 {
		 tstr[ll] = instr[kk];
		 kk += 1;
		 ll  += 1;
	 }
	 tstr[ll]=0;

	 strncpy( resultstr,tstr,slength+2);

}   // awk substr
//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

int gbrintomm_call(char *infile, char *outfile)
{

FILE *file1;
FILE *file2;

char thisline[200];

int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];

double xval;
double yval;

char X[120];
char Y[120];
int val;

  file1  = fopen(infile, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infile);
	  return(-1);
  }

  file2  = fopen(outfile, "w");

  if (file2 == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",outfile);
	  return(-1);
  }

 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL))
   {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       //	 X = X * 25.4;
       // Y = Y * 25.4;
       xval=atof(X);
	  // printf("Y = %s  strlen a1 = %d a1 = %s \n",Y,strlen(a[1]),a[1]);

       yval=atof(Y);
       xval=xval*25.4;
       yval=yval*25.4;
       fprintf(file2,"X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
  }
  // if line has only X data modify it
  else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {
      split(thisline,b[0],b[1],"X");
      split(thisline,d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
      xval=atof(X);
      // X = X * 25.4;
      xval=25.4 * xval;
      fprintf(file2,"X%0.0fD%s\n", xval,d[1]);
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
      split(thisline,c[0],c[1],"Y");
      split(thisline,d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
      // Y = Y * 25.4
      yval=atof(Y);
      yval=yval * 25.4;
      fprintf(file2,"Y%0.0fD%s\n",yval,d[1]);
  }
  // line has no X or Y data so just output it
  else
  {
    fprintf(file2,"%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }

 fclose(file1);
 fclose(file2);

 return(0);

}  // end grbintomm_call

int main( int argc, char **argv)
{
int errval;

   errval=gbrintomm_call(argv[1],argv[2]);


}


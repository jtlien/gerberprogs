#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include "evaluate.h"

#define MAXPOLY 100000
#define MAXMACROPARMS 100
#define MAXAPTMACROSTRINGS 1000
#define MAXAPTMACROSTRSIZE  30000
#define MAXAPTMACPRIMS 100
#define MAXAPTMACROS  100

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define MAXAPTS 1000
#define MAXMACROPARMS 100

#define PI 3.14159265358979323846

#define ARCPOINTS 10


void approxarc_extents( double beginx,
						double beginy,
						double endx,
						double endy, 
						double centerx,
				        double centery,
						double radius, 
						double arcwidth);
void do_include_file( char *paramstr, int cindex);
void do_rotate_x(int xval);
void do_rotate_end();
int evaluate(char *expr, struct val *result, struct vartable *vartable);
int find_in_macros( char *srchstr);
void buildtri_svg_call( char *infilestr, char *infile2str, FILE *outfile, char *rgbstr);


FILE *file1;
FILE *outfile;
FILE *errorfile;

double currentx;
double currenty;
double newx;
double newy;
double width;
double x_power_factor;
double y_power_factor;
double power_factor;
int line_point_count;
int currentdval;

int absolute_mode;
int incremental_mode;
int circular_interpret_mode;

int format_x_integers;
int format_x_decimals;
int format_y_integers;
int format_y_decimals;

int format_dcode_width;
int format_gcode_width;
int format_mcode_width;
int format_ncode_width;

char mode_str[30];
char image_pol_str[30];
char layer_pol_str[30];
char leading_trailing_str[30];
char absolute_incr_str[30];
int current_apt_value;
char current_apt_str[200];
char currentlayer[120];
char a_mirror_str[10];
char b_mirror_str[10];
int linear_mode;
int inch_mode;
int mm_mode;

int polymode;
int polycount;  // count of polygon pieces

char param_string[60000];   // huge string for multiline parameter strings
char film_name_str[80];
char errfilestr[120];

char image_just_xchar;
char image_just_ychar;
char image_just_xstr[80];  // image just , x floating value string
char image_just_ystr[80];  // image just, y floating value string

char offset_xstr[80];
char offset_ystr[80];
char scale_xstr[80];
char scale_ystr[80];

double offset_xval;
double offset_yval;
double scale_xval;
double scale_yval;
int ir_val;          // 0,90,180,270
int gcode_val;
int param_lines;  // count of parameter statement lines, limited to 500
int linecount;

int mirror_x_active;
int mirror_y_active;
int lpc_count;
int lpd_count;
int savecolor;

double gerberExtents[5];

char rgbstr[100];

struct primitive
{
	char *expr_str;
	int expr_count;
	int primitive_val;
} ;

char param_array[300][300];
char expr_array[MAXAPTMACROSTRINGS][MAXAPTMACROSTRSIZE];

int total_expr_count;
int group_count;

struct aptmacstuff
{
	struct primitive prim_array[MAXAPTMACPRIMS];
	int primitive_type_array[MAXAPTMACPRIMS];     // 1..22 , 1 is Circle, 2 Line Vect ... 22 is Line Lower Left
	char macroname[200];
	int primitive_count;
} aperture_macro[MAXAPTMACROS];

int aperture_mac_count;

struct aptstuff
{
	int isrect;
	int iscircle;
	int isoval;
	int ispolygon;
	int ismacro;
	char macro_name[200];     // macro associated with this apt if any
	int exp_mac_index;      // index into array of expanded macros
	double macro_parms[MAXMACROPARMS];  // value of macro params ( for ADmacroname,nn1Xnn2Xnn3X etc)
  //	char macro_strings[30][3000];    // raw strings from AM definition of macro
	double macro_vals[MAXMACROPARMS][20];    // for this AD, macro_parms -> macro_vals when expanded
	int macro_vals_parmcnt[MAXMACROPARMS];       // count of expanded vals for each macro line
	int macro_prim_count;      // count of primitives on the macro
	int hashole;
	int number_sides;      // for polygon
	double diam;
	double xsize;         // for polygon, xsize is outside dimension
	double ysize;         // for polygon, ysize is rotation
	double holediam;
	double holexsize;
	double holeysize;
	int macro_parm_count;  // old, 
}   apt_list[MAXAPTS];




struct polystuff
{
	int islinear_int;    // based on g01
	int iscircle_int;     // based on g02
	int isccwcircle_int;   // base on g03
	double ival;      // centerx
	double jval;      // centery
	double xval;     // ending x val
	double yval;     // ending y val
	double radius;    // radius of the arc if arc
	double xprev;
	double yprev;
	double width;
	double scale;

}   poly_list[MAXPOLY];

int poly_point_count;

char a_axis_char;
char b_axis_char;

double poly_points[MAXPOLY][2];
double poly_tpoints[MAXPOLY][2];

FILE *includefile_array[20];

int include_depth;


void UpdateExtents(double x1, double y1, double x2, double y2)
{
double t;
double tx1;
double tx2;
double ty1;
double ty2;

    
    tx1 = x1;
	tx2 = x2;

	ty1 = y1;
	ty2 = y2;

    if(tx1 > tx2)   // get the larger into x2, and smaller into x1
	{
        t = tx2;
        tx2 = tx1;
        tx1 = t;
	}
    if( ty1 >  ty2)  // get the larger into y2 and the smaller in y1
	{
        t = ty2;
        ty2 = ty1;
        ty1 = t;
	}
    if (tx1 <  gerberExtents[0] )
        gerberExtents[0] = tx1;
    if (ty1 <  gerberExtents[1])
        gerberExtents[1] = ty1;
    if (tx2 >  gerberExtents[2])
        gerberExtents[2] = tx2;
    if (ty2 >  gerberExtents[3] )
        gerberExtents[3] = ty2;
}

//
// Set the extents for a circular structure
//
void UpdateCircleExtents(double xc, double yc, double radius, double thickness)
{
    UpdateExtents(xc-radius-(thickness/2.0), yc-radius-(thickness/2.0),
                  xc+radius+(thickness/2.0), yc+radius+(thickness/2.0));
}

//
// Set the extents for a line structure
//
void UpdateLineExtents(double x1, double y1, double x2, double y2, double thickness)
{
double t;
double tx1;
double tx2;
double ty1;
double ty2;

    tx1 = x1;
	tx2 = x2;

	ty1 = y1;
	ty2 = y2;

    // xxx overcompensates for thickness
    if (tx1 > tx2 )
	{
        t = tx2;
        tx2 = tx1;
        tx1 = t;
	}
    if (y1 > y2)
	{
        t = ty2;
        ty2 = ty1;
        ty1 = t;
	}

    UpdateExtents(tx1-thickness,ty1-thickness,tx2+thickness,ty2+thickness);
}


void SetExtents()
{
    gerberExtents[0] = 1e9;   // xmin
	gerberExtents[1] = 1e9;   // ymin
	gerberExtents[2] = -1e9;  // xmax
	gerberExtents[3] = -1e9;  // ymax
}

void  UpdatePointExtents( double x1, double y1 )
{
 
//	printf("In UpdatePointExtents, x,y = %f %f \n", x1, y1 );

    if (x1 < gerberExtents[0])
	{
        gerberExtents[0] = x1;
	}
    if (y1 < gerberExtents[1])
	{
        gerberExtents[1] = y1;
	}
    if (x1 > gerberExtents[2])
	{
        gerberExtents[2] = x1;
	}
    if( y1 > gerberExtents[3])
	{
        gerberExtents[3] = y1;
	}

}


void set_clear( )
{
	 // white backround color
    strncpy(rgbstr,"white",30);

}
void set_dark( )
{
	
	  // black backround color
	strncpy(rgbstr,"black",30);

}


void set_color(int inlayer )
{
int layernum;

  layernum = inlayer % 7;

	if (layernum == 0 )
	{
		strncpy(rgbstr,"red",30);  // red

	}
    if (layernum == 1 )
	{ 
		strncpy(rgbstr,"green",30);  // green
	}
   if (layernum == 2 )
	{
	    strncpy(rgbstr,"blue",30);   // blue
		
	}
   if (layernum == 3 )
	{
	  	strncpy(rgbstr,"orange",30);    // orange
	}
    if (layernum == 4 )
	{
		strncpy(rgbstr,"aquamarine",30);     // blue green
	}
   if (layernum == 5 )
	{
		strncpy(rgbstr,"purple",30);       // purple
	} 
   if (layernum == 6 )
	{
		strncpy(rgbstr,"purple",30);       // yellow
	}

}


void do_aper_circle( char *paramstr, int cindex , int apt_num)
{
char diamstr[120];
char xvalstr[120];
char yvalstr[120];
	    
int kk;
int debug;

	 debug=0;

	 kk=0;
	    
    if (debug) { printf("in do_aper_circle , paramstr=%s \n", paramstr); }

   while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.')
	       ) && ( kk < 120))
        {
         diamstr[kk]=paramstr[cindex];
         kk+= 1;
         cindex+=1;
        }
	diamstr[kk] = '\0';

	if ( paramstr[cindex] == 'X')     // has one more parameter,
	{
	 kk=0;
	 cindex+=1;
	 while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.')
	       ) && ( kk < 120))
       {
           xvalstr[kk]=paramstr[cindex];
           kk+= 1;
           cindex+=1;
        }
	 xvalstr[kk] = '\0';

	 if ( paramstr[cindex] == 'X') // X followed by Y, rectangular hole
	 {
	  kk=0;
	  cindex+=1;
	  while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.')
	       ) && ( kk < 120))
           {
            yvalstr[kk]=paramstr[cindex];
            kk+= 1;
            cindex+=1;
           }
         yvalstr[kk] = '\0';

	   if (apt_num < MAXAPTS)
	   {
         apt_list[apt_num].iscircle=TRUE;
	     apt_list[apt_num].isrect=FALSE;
	     apt_list[apt_num].isoval=FALSE;
		 apt_list[apt_num].ispolygon=FALSE;
		 apt_list[apt_num].ismacro=FALSE;
		 apt_list[apt_num].hashole=TRUE;
		 apt_list[apt_num].diam=atof(diamstr);
		 apt_list[apt_num].holexsize=atof(xvalstr);
		 apt_list[apt_num].holeysize=atof(yvalstr);
		 apt_list[apt_num].holediam=0;              // indicates rect hole
         apt_num += 1;
	   }
	 }
	 else  //  Just 1 X , so circular flash, with circular hole
	 {
		 if (debug) { printf("adding aptnum=%d diam=%s\n",apt_num,diamstr); }

      if (apt_num < MAXAPTS)
		  {
			  apt_list[apt_num].iscircle=TRUE;
			  apt_list[apt_num].isrect=FALSE;
			  apt_list[apt_num].isoval=FALSE;
			  apt_list[apt_num].ispolygon=FALSE;
		      apt_list[apt_num].ismacro=FALSE;
			  apt_list[apt_num].hashole=TRUE;
			  apt_list[apt_num].diam=atof(diamstr);
			  apt_list[apt_num].xsize=0;
			  apt_list[apt_num].ysize=0;
			  apt_list[apt_num].holediam=atof(xvalstr);
              apt_num += 1;
	  }
      
     }
	}
   else     // just a diameter, circular flash, no hole
   {
      if (apt_num < MAXAPTS )
		  {

		  if (debug) { printf("adding an aperture at D%d = %f \n", apt_num, atof(diamstr)); }

			  apt_list[apt_num].iscircle=TRUE;
			  apt_list[apt_num].isrect=FALSE;
			  apt_list[apt_num].isoval=FALSE;
			  apt_list[apt_num].ispolygon=FALSE;
		      apt_list[apt_num].ismacro=FALSE;
              apt_list[apt_num].hashole=FALSE;
			  apt_list[apt_num].diam=atof(diamstr);
			  apt_list[apt_num].xsize=0;
			  apt_list[apt_num].ysize=0;
			  apt_list[apt_num].holediam=0;
              apt_num += 1;
	  }
	}
}

//
//  Approximate an arc by a series of points along the arc that can
//         be connected for polygon fill
//
void approx_arc_extents( double beginx, double beginy, double endx, double endy, double centerx,
				 double centery, double radius, double arcwidth)
{
double theta;   // angle between
double xdiff1;
double xdiff2;
double ydiff1;
double ydiff2;
double begintheta;
int steps;
double step_array[120][2];
double inctheta;
double steptheta;
int ii;
double xinc;
double yinc;

 steps=10;                        // was  50
 xdiff1=(beginx - centerx);
 xdiff2=(endx-centerx);
 ydiff1=(beginy - centery);
 ydiff2=(endy-centery);

 theta = acos( ((xdiff1 * xdiff2 ) + (ydiff1 * ydiff2))/ (radius * radius));

 inctheta= theta / (double) steps;

 begintheta = asin( xdiff1 / radius);

 for(ii=0; ii < steps; ii += 1)
 {
   steptheta= begintheta + (ii * inctheta);

   xinc = radius * cos( steptheta);
   yinc = radius * sin( steptheta);

   step_array[ii][0] = centerx + xinc;
   step_array[ii][1] = centery + yinc;

   if (ii > 0 )
   {
	  // printf("Checking line %f,%f to %f,%f  ii=%d\n",step_array[ii-1][0], step_array[ii-1][1],
		 //                step_array[ii][0],step_array[ii][1], ii);

	   UpdateLineExtents(step_array[ii-1][0], step_array[ii-1][1],
		                 step_array[ii][0],step_array[ii][1], arcwidth );
   }
 }

}   // end 
 

void do_aper_rectangle( char *paramstr, int cindex , int apt_num)
{
char xdimstr[120];
char ydimstr[120];
char xvalstr[120];  // hole x
char yvalstr[120];  // hole y
int xfound;
int yfound;
	    
int kk;
	    
   kk=0;
	    
   while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.')
	       ) && ( kk < 120))
     {
         xdimstr[kk]=paramstr[cindex];
         kk+= 1;
         cindex+=1;
        }
    xdimstr[kk] = '\0';

    if ( paramstr[cindex] == 'X')
	{
	 kk=0;
	 cindex+=1;
	 while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.')
	       ) && ( kk < 120))
          {
           ydimstr[kk]=paramstr[cindex];
           kk+= 1;
           cindex+=1;
          }
	     ydimstr[kk] = '\0';
       }
      else
      {
	// error, missing Y dimension for rectangle
      }
      xfound=FALSE;
      yfound=FALSE;
     if ( paramstr[cindex] == 'X') // X hole dimension
     {
	  kk=0;
	  cindex+=1;
	  while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.')
	       ) && ( kk < 120))
           {
            xvalstr[kk]=paramstr[cindex];
            kk+= 1;
            cindex+=1;
           }
	    xvalstr[kk] = '\0';
	    xfound=TRUE;
      }
    if (( paramstr[cindex] == 'X') &&(xfound==TRUE)) // Y hole dimension
     {
	  kk=0;
	  cindex+=1;
	  while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.')
	       ) && ( kk < 120))
           {
            yvalstr[kk]=paramstr[cindex];
            kk+= 1;
            cindex+=1;
           }
	   yvalstr[kk]='\0';
	   yfound=TRUE;
      }

	if (xfound==TRUE) 
	{
		if (yfound==TRUE)   // rectangle, with rect hole
		{
         if (apt_num < MAXAPTS )
		  {

			  apt_list[apt_num].iscircle=FALSE;
			  apt_list[apt_num].isrect=TRUE;
			  apt_list[apt_num].isoval=FALSE;
			  apt_list[apt_num].ispolygon=FALSE;
		      apt_list[apt_num].ismacro=FALSE;
              apt_list[apt_num].hashole=TRUE;
			  apt_list[apt_num].diam=0;
			  apt_list[apt_num].xsize=atof(xdimstr);
			  apt_list[apt_num].ysize=atof(ydimstr);
			  apt_list[apt_num].holediam=0;
              apt_list[apt_num].holexsize=atof(xvalstr);
			  apt_list[apt_num].holeysize=atof(yvalstr);
              apt_num += 1;
		 }
		}
	  else    // rectange with circular hole
		{

         if (apt_num < MAXAPTS )
		  {
			  apt_list[apt_num].iscircle=FALSE;
			  apt_list[apt_num].isrect=TRUE;
			  apt_list[apt_num].isoval=FALSE;
			  apt_list[apt_num].ispolygon=FALSE;
              apt_list[apt_num].hashole=TRUE;
			  apt_list[apt_num].diam=0;
			  apt_list[apt_num].xsize=atof(xdimstr);
			  apt_list[apt_num].ysize=atof(ydimstr);
			  apt_list[apt_num].holediam=atof(xvalstr);
              apt_list[apt_num].holexsize=0;
			  apt_list[apt_num].holeysize=0;
              apt_num += 1;
		 }
	  }
    }
   else   // X not found
	{

         if (apt_num < MAXAPTS )
		  {
			  apt_list[apt_num].iscircle=FALSE;
			  apt_list[apt_num].isrect=TRUE;
			  apt_list[apt_num].isoval=FALSE;
			  apt_list[apt_num].ispolygon=FALSE; 
			  apt_list[apt_num].ismacro=FALSE;
              apt_list[apt_num].hashole=FALSE;
			  apt_list[apt_num].diam=0;
			  apt_list[apt_num].xsize=atof(xdimstr);
			  apt_list[apt_num].ysize=atof(ydimstr);
			  apt_list[apt_num].holediam=0;
              apt_list[apt_num].holexsize=0;
			  apt_list[apt_num].holeysize=0;
              apt_num += 1;
		 }
	}
}


void do_aper_oval( char *paramstr, int cindex , int apt_num)
    {
      char xdimstr[120];
      char ydimstr[120];
      char xvalstr[120];  // hole x
      char yvalstr[120];  // hole y
      int xfound;
      int yfound;
	    
     int kk;
	    
	kk=0;
	    
    while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.' || paramstr[cindex]=='-'
		                                                           || paramstr[cindex]=='+')
	       ) && ( kk < 120))
     {
         xdimstr[kk]=paramstr[cindex];
         kk+= 1;
         cindex+=1;
      }
	xdimstr[kk] = '\0';

    if ( paramstr[cindex] == 'X')
	{
	 kk=0;
	 cindex+=1;
	 while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.' || paramstr[cindex]=='-' 
		                                                            || paramstr[cindex]=='+')
	       ) && ( kk < 120))
          {
           ydimstr[kk]=paramstr[cindex];
           kk+= 1;
           cindex+=1;
          }
	     ydimstr[kk] = '\0';
       }
      else
      {
	    printf("Missing y dimension for oval \n"); // error, missing Y dimension for rectangle
      }
      xfound=FALSE;
      yfound=FALSE;
     if ( paramstr[cindex] == 'X') // X hole dimension
     {
	  kk=0;
	  cindex+=1;
	  while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.' || paramstr[cindex]=='-' 
		                                                             || paramstr[cindex]=='+')
	       ) && ( kk < 120))
           {
            xvalstr[kk]=paramstr[cindex];
            kk+= 1;
            cindex+=1;
           }
	      xvalstr[kk] = '\0';
	      xfound=TRUE;
      }
    if (( paramstr[cindex] == 'X') &&(xfound==TRUE)) // Y hole dimension
     {
	  kk=0;
	  cindex+=1;
	  while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.' || paramstr[cindex]=='-' 
		                                                             || paramstr[cindex]=='+')
	       ) && ( kk < 120))
           {
            yvalstr[kk]=paramstr[cindex];
            kk+= 1;
            cindex+=1;
           }
	   yvalstr[kk]='\0';
	   yfound=TRUE;
      }

	if (xfound==TRUE) 
	{
		if (yfound==TRUE)   // rectangle, with rect hole
		{
         if (apt_num < MAXAPTS )
		  {

			  apt_list[apt_num].iscircle=FALSE;
			  apt_list[apt_num].isrect=FALSE;
			  apt_list[apt_num].isoval=TRUE;
			  apt_list[apt_num].ispolygon=FALSE;
			  apt_list[apt_num].ismacro=FALSE;
              apt_list[apt_num].hashole=TRUE;
			  apt_list[apt_num].diam=0;
			  apt_list[apt_num].xsize=atof(xdimstr);
			  apt_list[apt_num].ysize=atof(ydimstr);
			  apt_list[apt_num].holediam=0;
              apt_list[apt_num].holexsize=atof(xvalstr);
			  apt_list[apt_num].holeysize=atof(yvalstr);
              apt_num += 1;
		 }
		}
	  else    // rectange with circular hole
		{

         if (apt_num < MAXAPTS )
		  {
			  apt_list[apt_num].iscircle=FALSE;
			  apt_list[apt_num].isrect=FALSE;
			  apt_list[apt_num].isoval=TRUE;
			  apt_list[apt_num].ispolygon=FALSE;
			  apt_list[apt_num].ismacro=FALSE;
              apt_list[apt_num].hashole=TRUE;
			  apt_list[apt_num].diam=0;
			  apt_list[apt_num].xsize=atof(xdimstr);
			  apt_list[apt_num].ysize=atof(ydimstr);
			  apt_list[apt_num].holediam=atof(xvalstr);
              apt_list[apt_num].holexsize=0;
			  apt_list[apt_num].holeysize=0;
              apt_num += 1;
		 }
	  }
    }
   else   // X not found
	{

         if (apt_num < MAXAPTS )
		  {
			  apt_list[apt_num].iscircle=FALSE;
			  apt_list[apt_num].isrect=FALSE;
			  apt_list[apt_num].isoval=TRUE;
			  apt_list[apt_num].ispolygon=FALSE; 
			  apt_list[apt_num].ismacro=FALSE;
              apt_list[apt_num].hashole=FALSE;
			  apt_list[apt_num].diam=0;
			  apt_list[apt_num].xsize=atof(xdimstr);
			  apt_list[apt_num].ysize=atof(ydimstr);
			  apt_list[apt_num].holediam=0;
              apt_list[apt_num].holexsize=0;
			  apt_list[apt_num].holeysize=0;
              apt_num += 1;
		 }
	}
}


     
void do_aper_polygon( char *paramstr, int cindex , int apt_num)
{
char outdimstr[120];
char number_side_str[120];
char rotate_str[120];

char xvalstr[120];  // hole x
char yvalstr[120];  // hole y
int xfound;
int yfound;
	    
int kk;
	    
	kk=0;
	    
    while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.' || paramstr[cindex]=='-'
		                                                           || paramstr[cindex]=='+')
	       ) && ( kk < 120))
     {
         outdimstr[kk]=paramstr[cindex];
         kk+= 1;
         cindex+=1;
     }

	outdimstr[kk] = '\0';


    if ( paramstr[cindex] == 'X')
	{
	 kk=0;
	 cindex+=1;
	 while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.' || paramstr[cindex]=='-'
		                                                            || paramstr[cindex]=='+')
	       ) && ( kk < 120))
          {
           number_side_str[kk]=paramstr[cindex];
           kk+= 1;
           cindex+=1;
          }
	      number_side_str[kk]= '\0';
       }
      else
      {
	    printf("Missing number of sides for aperture polygon \n");  // error, missing Y dimension for rectangle
      } 

	  
     if ( paramstr[cindex] == 'X') // rotation
     {
	  kk=0;
	  cindex+=1;
	  while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.' || paramstr[cindex]=='-'
		                                                             || paramstr[cindex]=='+')
	       ) && ( kk < 120))
       {
            rotate_str[kk]=paramstr[cindex];
            kk+= 1;
            cindex+=1;
        }
	    rotate_str[kk] = '\0';
	
      }
      xfound=FALSE;
      yfound=FALSE;
     if ( paramstr[cindex] == 'X') // X hole dimension
     {
	  kk=0;
	  cindex+=1;
	  while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.' || paramstr[cindex]=='-'
		                                                             || paramstr[cindex]=='+')
	       ) && ( kk < 120))
       {
            xvalstr[kk]=paramstr[cindex];
            kk+= 1;
            cindex+=1;
        }
	    xvalstr[kk] = '\0';
	 
	    xfound=TRUE;
      }
    if (( paramstr[cindex] == 'X') &&(xfound==TRUE)) // Y hole dimension
     {
	  kk=0;
	  cindex+=1;
	  while(( isdigit(paramstr[cindex]) || ( paramstr[cindex] == '.' || paramstr[cindex]=='-'
		                                                             || paramstr[cindex]=='+')
	       ) && ( kk < 120))
           {
            yvalstr[kk]=paramstr[cindex];
            kk+= 1;
            cindex+=1;
           }
	      yvalstr[kk]='\0';
	      yfound=TRUE;
      }

	if (xfound==TRUE) 
	{
		if (yfound==TRUE)   // polygon flash with rectangular hole
		{
         if (apt_num < MAXAPTS )
		  {

			  apt_list[apt_num].iscircle=FALSE;
			  apt_list[apt_num].isrect=FALSE;
			  apt_list[apt_num].isoval=FALSE;
			  apt_list[apt_num].ispolygon=TRUE; 
			  apt_list[apt_num].ismacro=FALSE;
              apt_list[apt_num].hashole=TRUE;
			  apt_list[apt_num].diam=0;
			  apt_list[apt_num].xsize=atof(outdimstr);
			  apt_list[apt_num].ysize=atof(rotate_str);
			  apt_list[apt_num].number_sides=atoi(number_side_str);
			  apt_list[apt_num].holediam=0;
              apt_list[apt_num].holexsize=atof(xvalstr);
			  apt_list[apt_num].holeysize=atof(yvalstr);
              apt_num += 1;
		 }
		}
	  else    // polygon flash with circular hole
		{

         if (apt_num < MAXAPTS )
		  {
			  apt_list[apt_num].iscircle=FALSE;
			  apt_list[apt_num].isrect=FALSE;
			  apt_list[apt_num].isoval=FALSE;
			  apt_list[apt_num].ispolygon=TRUE; 
			  apt_list[apt_num].ismacro=FALSE;
              apt_list[apt_num].hashole=TRUE;
			  apt_list[apt_num].diam=0;
			  apt_list[apt_num].xsize=atof(outdimstr);
			  apt_list[apt_num].ysize=atof(rotate_str);
			  apt_list[apt_num].number_sides=atoi(number_side_str);
			  apt_list[apt_num].holediam=atof(xvalstr);
              apt_list[apt_num].holexsize=0;
			  apt_list[apt_num].holeysize=0;
              apt_num += 1;
		 }
	  }
    }
   else   // X not found
	{

         if (apt_num < MAXAPTS )   // polygon, no hole
		  {
			  apt_list[apt_num].iscircle=FALSE;
			  apt_list[apt_num].isrect=FALSE;
			  apt_list[apt_num].isoval=FALSE;
			  apt_list[apt_num].ispolygon=TRUE; 
			  apt_list[apt_num].ismacro=FALSE;
              apt_list[apt_num].hashole=FALSE;
			  apt_list[apt_num].diam=0;
			  apt_list[apt_num].xsize=atof(outdimstr);
			  apt_list[apt_num].ysize=atof(rotate_str);
			  apt_list[apt_num].number_sides=atoi(number_side_str);
			  apt_list[apt_num].holediam=0;
              apt_list[apt_num].holexsize=0;
			  apt_list[apt_num].holeysize=0;
              apt_num += 1;
		 }
	}
}

// ASA(X|Y)B(X|Y)
//
void do_axis_select( char *paramstr, int cindex)
{
int index;

 index = cindex;
 if (paramstr[index] == 'A')  // A given first
 {
	 index += 1;
	 if ((paramstr[index] == 'X' ) || ( paramstr[index] == 'Y'))
	 {
        a_axis_char = paramstr[index];
	 }
	 else
	 {
		 printf("Expected X or Y for assign A axis value, got %c \n", paramstr[index]);
	 }
	 index +=1;
     if (paramstr[index] == 'B')
	  {
       index += 1;
	   if ((paramstr[index] == 'X' ) || ( paramstr[index] == 'Y'))
	   {
        b_axis_char = paramstr[index];
	   }
	 }
	else
	{
		// B not stated
		if (a_axis_char == 'X')
		{
			b_axis_char = 'Y';
		}
		else
		{
			b_axis_char = 'X';
		}
	}
 }
 else   // not A, maybe B
 {
   if ( paramstr[index] == 'B')
   {
	   index += 1;
	   if ((paramstr[index] == 'X' ) || ( paramstr[index] == 'Y'))
	   {
		   b_axis_char = paramstr[index];
		   if (b_axis_char == 'X')
		   {
			   a_axis_char = 'Y';
		   }
		   else
		   {
			   a_axis_char = 'X';
		   }

	   }
	   else
	   {
		   printf("Expected X or Y for assign B axis value, got %c \n", paramstr[index]);
	   }
   }

 }


}   

// IJ followed by A 
//    or IJ followed by B
//    or IJ followed by A then B

void do_image_justify( char *paramstr, int cindex)
{
int index;
int ll;

    index = cindex;

	if (paramstr[index] == 'A')  //  A and B given
	{

		if ((paramstr[index+1]=='L') || ( paramstr[index+1] == 'C') )
		{
          image_just_xchar = paramstr[index+1];
		  index += 2;
		  if (paramstr[index] == 'B')
		  {
           if ((paramstr[index+1] == 'L' ) || ( paramstr[index+1] == 'C') )
			{
				image_just_ychar = paramstr[index];
			}
			else   // number offset for Y
			{
             ll=0;
			 index += 1;
		     while(( ( isdigit(paramstr[index] ) ) || (paramstr[index] == '+')  ||
				     (paramstr[index] == '-')  || ( paramstr[index] == '.') )  && (ll < 80))
			 {
              image_just_ystr[ll] = paramstr[index];
			  ll += 1;
			  index += 1;
			 }
		    image_just_ystr[ll] = '\0';
			}
		  }
		}
		else  // X has offset
		{
		  index += 1;
		  ll=0;
		  while(( ( isdigit(paramstr[index] ) ) || (paramstr[index]=='+') ||
			      (paramstr[index]=='-') || ( paramstr[index] == '.') )  && (ll < 80))
		  {
            image_just_xstr[ll] = paramstr[index];
			ll += 1;
			index += 1;
		  }
		  image_just_xstr[ll] = '\0';

		  if (paramstr[index] == 'B')
		  {
			if ((paramstr[index+1] == 'L' ) || ( paramstr[index+1] == 'C') )
			{
				image_just_ychar = paramstr[index];
			}
			else   // number offset for Y
			{
             ll=0;
			 index += 1;
		     while(( ( isdigit(paramstr[index] ) ) ||   (paramstr[index] == '+') ||
				     (paramstr[index] == '-')  || ( paramstr[index] == '.') )  && (ll < 80))
			 {
              image_just_ystr[ll] = paramstr[index];
			  ll += 1;
			  index += 1;
			 }
		    image_just_ystr[ll] = '\0';
			}
		  }   // B

		}  // X has offset
	}
	else
	{
		if (paramstr[index] == 'B')
		{
			if ((paramstr[index+1] == 'L' ) || ( paramstr[index+1] == 'C') )
			{
				image_just_ychar = paramstr[index];
			}
			else   // number offset for Y
			{
			 ll=0;
			 index += 1;
		     while(( ( isdigit(paramstr[index] ) ) ||  (paramstr[index] == '+') ||
				     (paramstr[index] == '-')  || ( paramstr[index] == '.') )  && (ll < 80))
			 {
              image_just_ystr[ll] = paramstr[index];
			  ll += 1;
			  index += 1;
			 }
		    image_just_ystr[ll] = '\0';

			}
		
		}
	}
}

// FS<L|T><I|A>[Nn][Gn]<Xn><Yn>[Dn][Mn]
void do_format_statement( char *paramstr, int cindex)
{
int index;
char int_digit[10];
int starfound;
int ll;
int debug;

  debug = 0;

  if (debug) { printf("Made it to do_format_statement , paramstr = %s cindex=%d\n",paramstr,
	              cindex ); }

  index = cindex;
  starfound = FALSE;

 
  while(( starfound ==FALSE)  && ( index < (int) strlen(paramstr)) )
  {
    if (paramstr[index] == 'X')
	{
		 index += 1;
		 if (isdigit( paramstr[index] ) )
		 {
           int_digit[0] = paramstr[index];
		   int_digit[1] = '\0';
           format_x_integers = atoi(int_digit);
		 }
		 index += 1;
         if (isdigit( paramstr[index] ) )
		 {
           int_digit[0] = paramstr[index];
		   int_digit[1] = '\0';
           format_x_decimals = atoi(int_digit);
		 }
		 index += 1;
	}
	x_power_factor = pow(10,format_x_decimals);

	if (debug) { printf(" x_power_factor = %f \n", x_power_factor ); }

	if (paramstr[index] == 'Y')
	{
		 index += 1;
		 if (isdigit( paramstr[index] ) )
		 {
           int_digit[0] = paramstr[index];
		   int_digit[1] = '\0';
           format_y_integers = atoi(int_digit);
		 }
		 index += 1;
         if (isdigit( paramstr[index] ) )
		 {
           int_digit[0] = paramstr[index];
		   int_digit[1] = '\0';
           format_y_decimals = atoi(int_digit);
		 }
		 index+=1;
	}	
	y_power_factor = pow(10,format_y_decimals);

	if (x_power_factor == y_power_factor)
	{
		power_factor = x_power_factor;
	}
    else
	{
		printf("Warning, X and Y decimal widths are not the same \n");
	}

    if (debug) { printf(" y_power_factor = %f \n", y_power_factor ); }

	if (paramstr[index] == 'D')
	{
	  index += 1;
      ll=0;
	  while(( isdigit( paramstr[index] ) ) && ( ll < 10))
	  {
			   int_digit[ll] = paramstr[index];
			   index+=1;
			   ll += 1;
	  }
     int_digit[ll] = '\0';
     format_dcode_width = atoi(int_digit);
	
	}
	if (paramstr[index] == 'M')
	{
	  index += 1;
      ll=0;
	  while(( isdigit( paramstr[index] ) ) && ( ll < 10))
	  {
			   int_digit[ll] = paramstr[index];
			   index+=1;
			   ll += 1;
	  }
     int_digit[ll] = '\0';
     format_mcode_width = atoi(int_digit);
	
	}
   if (paramstr[index] == 'G')
	{
	  index += 1;
      ll=0;
	  while(( isdigit( paramstr[index] ) ) && ( ll < 10))
	  {
			   int_digit[ll] = paramstr[index];
			   index+=1;
			   ll += 1;
	  }
     int_digit[ll] = '\0';
     format_gcode_width = atoi(int_digit);
	
	}
   if (paramstr[index] == 'N')
	{
	  index += 1;
      ll=0;
	  while(( isdigit( paramstr[index] ) ) && ( ll < 10))
	  {
			   int_digit[ll] = paramstr[index];
			   index+=1;
			   ll += 1;
	  }
     int_digit[ll] = '\0';
     format_ncode_width = atoi(int_digit);
	
	}

   if (paramstr[index] == '*')
   {
	   starfound = TRUE;
   }

  }  // end while

} // end do format statement


// OFA+-offsetB+=OFFSET

void do_offset( char *paramstr, int cindex)
{
int ll;
int index;

 ll=0;
 index=cindex;

 offset_xstr[0] = '\0';
 offset_ystr[0] = '\0';

  if ( paramstr[index] == 'A')
  {

    index += 1;
	ll=0;
	while((( isdigit( paramstr[index] ) ) || ( paramstr[index] == '.')
       || ( paramstr[index] == '+' ) || (paramstr[index] == '-')) && (ll < 80))
	   {
		 offset_xstr[ll] = paramstr[index];
		 ll += 1;
		 index += 1;
	}
	offset_xstr[ll] = '\0';

	if (paramstr[index] == 'B')
	{
		index += 1;
        ll=0;
  	    while((( isdigit( paramstr[index] ) ) || ( paramstr[index] == '.')
           || ( paramstr[index] == '+' ) || (paramstr[index] == '-')) && (ll < 80))
		{
		 offset_ystr[ll] = paramstr[index];
		 ll += 1;
		 index += 1;
		}
	   offset_ystr[ll] = '\0';
    }

  }
  else
  {
	  if (paramstr[index] == 'B')   // A understood to be zero
	  {

	index += 1;
        ll=0;
  	    while((( isdigit( paramstr[index] ) ) || ( paramstr[index] == '.')
           || ( paramstr[index] == '+' ) || (paramstr[index] == '-')) && (ll < 80))
		{
		 offset_ystr[ll] = paramstr[index];
		 ll += 1;
		 index += 1;
		}
	   offset_ystr[ll] = '\0';
	  }
  }

  offset_xval = atof( offset_xstr);
  offset_yval = atof( offset_ystr);

}
//
// IR90
// or IR180
// or IR270
// or IR0

void do_image_rotation( char *paramstr, int cindex)
{
int ll;
int index;
char ir_string[100];

 index = cindex;
 ll=0;

 while(( paramstr[index] != '*') && (paramstr[index] != '\0') && (ll < 80))
 {
	 ir_string[ll]=paramstr[index];
	 index += 1;
	 ll += 1;
 }
 ir_string[ll] = '\0';

 ir_val=atoi(ir_string);

 if (( ir_val == 0 ) || (ir_val == 90) || (ir_val == 180) || (ir_val == 270 ))
 {

	 if (ir_val > 0 )
	 {
	 do_rotate_x(ir_val);
	 }
	 else
	 {

       do_rotate_end();
	 }
 }
 else
 {
	 printf("Bad image rotation value , = %s \n", ir_string);
	 exit(-1);
 }

} //

void do_image_offset( char *paramstr, int cindex)
    {
    }

void do_step_repeat( char *paramstr, int cindex)
    {
    }

void get_macro_param_str( char *paramstr, int cindex, char *parmstr)
{
int ll;
int debug;

debug =0;
ll =0;
while( (paramstr[cindex] != 'X') && ( paramstr[cindex] != '*' ) && ( ll < 30))
{
	parmstr[ll] = paramstr[cindex];
	cindex += 1;
	ll += 1;
}
 
parmstr[ll] = '\0';

if (debug) { printf("Parmstr = %s \n", parmstr); }


}  // get_macro_param_str

void do_macro_expand( char *paramstr, int cindex, int dval)
{
int param_count;
char this_param[200];
char macro_name[200];
int ll;
double param_val;
int debug;
int apt_num;



    debug = 0;
    param_count = 0;
	ll=0;
	while((paramstr[cindex] != ',') && (paramstr[cindex] != '*') && ( ll < 200))
	{
		macro_name[ll] = paramstr[cindex];
		ll += 1;
		cindex += 1;
	}
	macro_name[ll] = '\0';

	apt_num = dval;

	strncpy(apt_list[apt_num].macro_name,macro_name,200);

    apt_list[apt_num].iscircle=FALSE;
	apt_list[apt_num].isrect=FALSE;
    apt_list[apt_num].isoval=FALSE;
	apt_list[apt_num].ispolygon=FALSE; 
    apt_list[apt_num].ismacro=TRUE;
    apt_list[apt_num].hashole=FALSE;
			  
	if (debug) { printf(" macro name = %s dval=%d\n", macro_name,dval); }

	if ( paramstr[cindex] == ',')  // has parameters
	{
		cindex += 1;

	    while( paramstr[cindex] != '*') 
		{
          get_macro_param_str( paramstr, cindex, this_param);
		  if (debug) { printf("this param = %s \n", this_param); }

	      param_val = atof( this_param);
         
		  apt_list[apt_num].macro_parms[param_count]= param_val;

		 // printf("setting in apt_list = %d param_count = %d param_val = %f \n",
		//	  apt_num, param_count, param_val);

    	  cindex = cindex + strlen(this_param);
	      if (paramstr[cindex] == 'X')
		  {
		    cindex += 1;
		  }
		 
	     param_count += 1;
        }
		if (debug)
		{
		printf("for apt_list entry %d set parm_count = %d \n",apt_num,param_count );
		}

		apt_list[apt_num].macro_parm_count = param_count;
	}
   apt_num += 1;
	  
}

//
// like do macro_expand, but uses the eval package to keep track of
//  variables   
//     This is performed when an AD is encoountered
//
void do_macro_expand_eval( char *paramstr, int cindex, int dval)
{
char *this_primitive;
int param_count;
char this_param[2000];
char macro_name[2000];
int ll;
double param_val;
int debug;
int apt_num;
struct vartable *vt;
struct val  result;
int macro_index;
int macro_parm_cnt;
char varstr[3000];
int kk,mm;
int starfound;
char next_eval_str[3000];
double this_prim_val;
int mcnt;

    debug = 0;
    param_count = 0;
	ll=0;
	while((paramstr[cindex] != ',') && (paramstr[cindex] != '*') && ( ll < 200))
	{
		macro_name[ll] = paramstr[cindex];
		ll += 1;
		cindex += 1;
	}
	macro_name[ll] = '\0';

	apt_num = dval;

	if (debug) { printf("expanding macro = %s for apt_num = %d \n", macro_name, apt_num); }

	strncpy(apt_list[apt_num].macro_name,macro_name,200);

    apt_list[apt_num].iscircle=FALSE;
	apt_list[apt_num].isrect=FALSE;
    apt_list[apt_num].isoval=FALSE;
	apt_list[apt_num].ispolygon=FALSE; 
    apt_list[apt_num].ismacro=TRUE;
    apt_list[apt_num].hashole=FALSE;
			  
	if (debug) { printf(" macro name = %s dval=%d\n", macro_name,dval); }
    vt = create_vartable();


	if ( paramstr[cindex] == ',')  // has parameters
	{
		cindex += 1;


	    while( paramstr[cindex] != '*') 
		{
          get_macro_param_str( paramstr, cindex, this_param);
		  if (debug) { printf("this param = %s \n", this_param); }

		    _snprintf(varstr,100,"$%d=",param_count+1);   // get the varstr set up 
			strncat(varstr,this_param,2000);

			if (debug) { printf("About to eval %s \n", varstr); }

			switch (evaluate(varstr, &result, vt)) 
			{
              case ERROR_SYNTAX:      printf("syntax error\n");       break;
              case ERROR_VARNOTFOUND: printf("variable not found\n"); break;
              case ERROR_NOMEM:       printf("not enough memory\n");  break;
              case ERROR_DIV0:        printf("division by zero\n");   break;
              case RESULT_OK: 
              if (result.type == T_INT) 
			  { 
				  param_val= (double ) result.ival;
			  }
              else 
			  {
				  param_val = result.rval;
			  }
			}
         
			if (debug) { printf(" for apt = %d setting macro_parm[ %d ] to %f \n",
				apt_num, param_count, param_val); }

		  apt_list[apt_num].macro_parms[param_count]= param_val;

		 // printf("setting in apt_list = %d param_count = %d param_val = %f \n",
		//	  apt_num, param_count, param_val);

    	  cindex = cindex + strlen(this_param);
	      if (paramstr[cindex] == 'X')
		  {
		    cindex += 1;
		  }
		 
	     param_count += 1;
        }
		if (debug)
		{
		printf("for apt_list entry %d set parm_count = %d \n",apt_num,param_count );
		}

		//apt_list[apt_num].macro_prim_count = param_count;
	}

   macro_index = find_in_macros( apt_list[apt_num].macro_name);
		  
   if (debug)
	{
     printf("looked up macro = %s found index  = %d \n",
	 apt_list[apt_num].macro_name, macro_index );
	}


    if (macro_index != -1)
	{
	  mcnt=0;
	  for( kk =0; kk < aperture_macro[macro_index].primitive_count; kk += 1)
		{
			if (kk < 30)
			{
			   if (debug) 
			   {  
				   printf("Top of loop , kk = %d primitive_count = %d\n", kk , 
					 aperture_macro[macro_index].primitive_count );
			   }
				//strncpy(apt_list[apt_num].macro_strings[kk], 
				//	aperture_macro[macro_index].prim_array[kk].expr_str,2000);
				this_primitive=aperture_macro[macro_index].prim_array[kk].expr_str;

				if (strstr(this_primitive,"=") == NULL)   // not an equation
				{
				  ll=0;
				  starfound=FALSE;
				  macro_parm_cnt=0;    // count parms for each macro line

				  while(starfound == FALSE)
				  {
					  mm = 0;
					  while(( this_primitive[ll] != ',') && (this_primitive[ll] != '*') &&
						  (this_primitive[ll] != '\0') && (this_primitive[ll] != '%' ) 
						      && ( ll < MAXAPTMACROSTRSIZE))
					  {
						  next_eval_str[mm] = this_primitive[ll];
						//  printf("this_primitive char = %c \n", this_primitive[ll]);
                          ll += 1;
						  mm += 1;
					  }
					  next_eval_str[mm] = '\0';
					  if (debug) { printf("next_eval_str = %s ll = %d \n", next_eval_str,ll); }

                      switch (evaluate(next_eval_str, &result, vt)) 
					  {
                        case ERROR_SYNTAX:      printf("syntax error\n");       break;
                        case ERROR_VARNOTFOUND: printf("variable not found\n"); break;
                        case ERROR_NOMEM:       printf("not enough memory\n");  break;
                        case ERROR_DIV0:        printf("division by zero\n");   break;
                        case RESULT_OK: 
                         if (result.type == T_INT) 
						 { 
				          this_prim_val= (double ) result.ival;
						 }
                         else 
						 {
				          this_prim_val = result.rval;
						 }
					  }
						 if (debug) { printf("For apt = %d , setting macro_vals[%d][%d] to %f \n",
							 apt_num, mcnt, macro_parm_cnt, this_prim_val); }

                       apt_list[apt_num].macro_vals[mcnt][macro_parm_cnt] = this_prim_val;
					 
					   if (macro_parm_cnt < MAXMACROPARMS)
					   {
                         macro_parm_cnt += 1;
					   }
					   else
					   {
						   printf("Too many parms in aperture macro definition for aper=%d, %s\n",
							   apt_num, apt_list[apt_num].macro_name);
					   }

					  if (this_primitive[ll] == '*')
					  {
						  starfound=TRUE;
					  }
					  else
					  {
						  if (this_primitive[ll] == ',')
						  {
						    ll += 1;    // skip comma
						  }
						  else
						  {
                             if (this_primitive[ll] == '\0')
							 {
								 ll += 1;
								 starfound=TRUE;
							 }
							else
							{
		printf("Unexpected character in macro string = %c, %d at position = %d , treating as end of line = %s\n",
								   this_primitive[ll], this_primitive[ll],ll,this_primitive);
							  ll += 1;
							  starfound=TRUE;
							}
						  }

					  }
				  }     // while not starfound

				  if (debug)
				  {
			        printf("for apt = %d setting macro_vals_parmcnt[%d] to %d \n",
				      apt_num, mcnt, macro_parm_cnt );
				  }
		          apt_list[apt_num].macro_vals_parmcnt[mcnt]=macro_parm_cnt;
				  mcnt += 1;         // count non equational lines

				  //printf("Update the apt_list \n");
				  
				 }
		        else          // an equation string, so eval it
				{

				 if (debug)
				 {
					 printf("About to evaluate %s \n",this_primitive); 
				 }
                  switch (evaluate(this_primitive, &result, vt)) 
					{
                        case ERROR_SYNTAX:      printf("syntax error\n");       break;
                        case ERROR_VARNOTFOUND: printf("variable not found\n"); break;
                        case ERROR_NOMEM:       printf("not enough memory\n");  break;
                        case ERROR_DIV0:        printf("division by zero\n");   break;
                        case RESULT_OK: 
                         if (result.type == T_INT) 
						 { 
				          this_prim_val= (double ) result.ival;
						 }
                         else 
						 {
				          this_prim_val = result.rval;
						 }

						 if (debug) { printf("Equational line result = %f \n", this_prim_val);
						 }
				  }
				}
			}
		   else  // more than 30
		   {
			   printf("Too many primitives in macro definition for apt = %d macro = %s\n",dval,
				   apt_list[apt_num].macro_name);
		   }

		} // for each macro line
	  
	}
    
	apt_list[apt_num].macro_prim_count=mcnt;
	if (debug)
	{
		printf("Done with  do_macro_expand_eval , macro_prim_count = %d \n",mcnt);
	}

   apt_num += 1;
  free_vartable(vt);

}  // do_macro_expand_eval




void do_aper_def( char *paramstr, int cindex)
{
char d_number_str[15];
char atype[120];
char atypep1;
int dval;
int ii;
int ll;
int save_index;

      cindex += 1;
	  ii=0;
	  while((isdigit(paramstr[cindex] )) && (ii < 10))
	  {
       d_number_str[ii]=paramstr[cindex];
	   cindex+=1;
	   ii += 1;
	  }
	  d_number_str[ii] = '\0';


	  dval=atoi(d_number_str);

//	  cindex+=1;

	  ll =0;
	  save_index=cindex;

	  while((ll < 80) && (paramstr[cindex] != ',') )
	  {
		  atype[ll] = paramstr[cindex];
		  ll += 1;
		  cindex += 1;
	  }
	  atype[ll] = '\0';

      atypep1= paramstr[cindex];
      cindex +=1;

	 
       if ((strcmp(atype,"C")==0) && ( atypep1 == ','))  // circle
        {
          do_aper_circle( paramstr, cindex, dval);
        }

       else if ((strcmp(atype,"R")==0) && ( atypep1 == ','))  // rectangle
        {
          do_aper_rectangle( paramstr, cindex, dval);
        }

       else if ((strcmp(atype,"O")==0 ) && ( atypep1 == ','))   //oval
        {
          do_aper_oval( paramstr, cindex, dval);
        }
       else if ((strcmp(atype,"P")== 0 ) && ( atypep1 == ','))  // polygon
        {
          do_aper_polygon(paramstr, cindex, dval);
        }
	   else
	   {
		   do_macro_expand(paramstr,save_index, dval);    // a named macro, so expand it
	   }

} // do_aper_def

// SFA<factor>B<factor>

void do_scale_factor( char *paramstr, int cindex)
{
int ll;
int index;

 ll=0;
 index=cindex;

 scale_xstr[0] = '\0';
 scale_ystr[0] = '\0';

  if ( paramstr[index] == 'A')
  {

    index += 1;
	ll=0;
	while((( isdigit( paramstr[index] ) ) || ( paramstr[index] == '.')
       || ( paramstr[index] == '+' ) || (paramstr[index] == '-')) && (ll < 80))
	   {
		 scale_xstr[ll] = paramstr[index];
		 ll += 1;
		 index += 1;
	}
	scale_xstr[ll] = '\0';

	if (paramstr[index] == 'B')
	{
		index += 1;
        ll=0;
  	    while((( isdigit( paramstr[index] ) ) || ( paramstr[index] == '.')
           || ( paramstr[index] == '+' ) || (paramstr[index] == '-')) && (ll < 80))
		{
		 scale_ystr[ll] = paramstr[index];
		 ll += 1;
		 index += 1;
		}
	   scale_ystr[ll] = '\0';
    }

  }
  else
  {
	  if (paramstr[index] == 'B')   // A understood to be zero
	  {

	    index += 1;
        ll=0;
  	    while((( isdigit( paramstr[index] ) ) || ( paramstr[index] == '.')
           || ( paramstr[index] == '+' ) || (paramstr[index] == '-')) && (ll < 80))
		{
		 scale_ystr[ll] = paramstr[index];
		 ll += 1;
		 index += 1;
		}
	   scale_ystr[ll] = '\0';
	  }
  }

  scale_xval = atof( scale_xstr);
  scale_yval = atof( scale_ystr);

}

// KO[C|D}<x coordinant ll>Y<y coordinant ll>I<width>J<height>or
//                                           K<border dimension>
//
void do_knock_out( char *paramstr, int cindex)
{

}


void do_layer_name( char *paramstr, int cindex)
{
     char layer_name_str[200];
     int kk;
	    
     kk=0;
     while((isalpha(paramstr[cindex]) ) && ( kk < 200))
     {
	     layer_name_str[kk]=paramstr[cindex];
	     kk+=1;
	     cindex+=1;
     }
     layer_name_str[kk] = '\0';
     
}  // do_layer_name
    
void do_image_name( char *paramstr, int cindex)
{
     char image_name_str[200];
     int kk;
	    
     kk=0;
     while((isalpha(paramstr[cindex]) ) && ( kk < 200))
     {
	     image_name_str[kk]=paramstr[cindex];
	     kk+=1;
	     cindex+=1;
     }
     image_name_str[kk] = '\0';
     
}  // do_image_name
    
void do_aper_macro( char *paramstr, int cindex)
{
  
int ll;
int index;
char primitive_nstr[40];
int primitive_val;
int primitive_count;
char this_macro_name[200];
int begin_index;
char this_expr_str[2000];
int debug;
char *tptr;

  debug =0;
  

   index=cindex;
   ll=0;
   while(( paramstr[index] != '*') && ( ll < 200) && ( index < (int) strlen(paramstr)) )
   {
	   this_macro_name[ll] = paramstr[index];
	   ll += 1;
	   index += 1;
   }
   this_macro_name[ll] = '\0';

   primitive_count=0;

   strncpy(aperture_macro[aperture_mac_count].macroname, this_macro_name,200);

   if (debug)
   {
   printf("Added in AM macro = %s at %d \n", this_macro_name, aperture_mac_count );
   }

   if (paramstr[index] != '*')
   {
	   printf("Macro missing body \n");
   }

   while( (paramstr[index] == '*') && (index < (int) strlen(paramstr) ) )
   {
	   index += 1;   // skip *
	   begin_index = index;
       ll=0;
	   while( isdigit( paramstr[index] ) && ( ll< 30))
	   {
         primitive_nstr[ll]=paramstr[index];
		 index += 1;
		 ll += 1;
	   }
	   primitive_nstr[ll] = '\0';
	   primitive_val = atoi(primitive_nstr);
	  
	   ll=0;
	   index=begin_index;

	   while((paramstr[index] != '*') && 
			            (index < (int) strlen(paramstr) ) )
		   {
			   this_expr_str[ll] = paramstr[index];
			   index += 1;
			   ll += 1;
		   }
	   this_expr_str[ll] = '\0';

	   //strncpy( aperture_macro[aperture_mac_count].prim_array[primitive_count].expr_str,
		   //   this_expr_str,120);

	   if ( total_expr_count < MAXAPTMACROSTRINGS)
	   {
		   strncpy(expr_array[total_expr_count], this_expr_str,MAXAPTMACROSTRSIZE);
		   tptr= expr_array[total_expr_count];
		   aperture_macro[aperture_mac_count].prim_array[primitive_count].expr_str=
			   tptr;
		   total_expr_count += 1;

	   }
	   else
	   {
		   printf("Array size exceeded for aperture macro expressions = %d\n",
			               MAXAPTMACROSTRSIZE);

	   }

	   aperture_macro[aperture_mac_count].prim_array[primitive_count].primitive_val
			                  =primitive_val;
	   if ( strlen( this_expr_str) > 0 )
	   {
		   if (primitive_count < MAXAPTMACPRIMS)
		   {
		     primitive_count += 1;
		   }
		   else
		   {
               printf("Aperture macro primitive count exceeds max = %d \n", MAXAPTMACPRIMS);
     		   printf("For macro = %s \n", aperture_macro[aperture_mac_count].macroname);
		   }

	   }
	
   }  // while pointing to '*'

   aperture_macro[aperture_mac_count].primitive_count = primitive_count;
  // printf("Setting primitive_count = %d \n", primitive_count);


   if (aperture_mac_count < MAXAPTMACROS )
   {
     aperture_mac_count += 1;
   }
   else
   {
	   printf("Too many aperture macros ( exceeds %d )\n",MAXAPTMACROS);

   }


}  // end

void do_rotate_x( int xval)
{
char quotchar;
     quotchar = '"';

	fprintf(outfile,"<g transform=");
	fprintf(outfile,"%crotation=%d)%c >\n",quotchar,xval,quotchar);
	group_count += 1;
}

void do_rotate_end()
{
//	fprintf(outfile,"</g>\n");
	group_count -=1;
}

void do_mirror_x( )
{
char quotchar;
     quotchar = '"';

	fprintf(outfile,"<g transform=");
	fprintf(outfile,"%c scale=(1,-1),translate=(0,0)%c >\n",quotchar,quotchar);
	group_count += 1;
}

void end_mirror_x()
{
	//fprintf(outfile,"</g>\n");
	group_count -=1;
}

void do_mirror_y( )
{
char quotchar;
     quotchar = '"';

	fprintf(outfile,"<g transform=");
	fprintf(outfile,"%c scale=(-1,1) translate=(0,0)%c >\n");
	group_count += 1;
}

void end_mirror_y()
{
	//fprintf(outfile,"</g>\n");
	group_count -=1;
}

void do_mirror_xy( )
{
char quotchar;
     quotchar = '"';

	fprintf(outfile,"<g transform=");
	fprintf(outfile,"%c scale=(-1,-1) translate=(0,0)%c >\n");
	group_count += 1;
}

void end_mirror_xy()
{
	//fprintf(outfile,"</g>\n");
	group_count -=1;
}

//
//  Film name to use   PF<name>*
//  
void do_plot_film( char *paramstr, int cindex)
{
int ll;
int index;

 index = cindex;

 ll = 0;
 while(( paramstr[index] != '*' ) && ( ll < 80) && (paramstr[index] != '\0') )
 {
	 film_name_str[ll] = paramstr[index];
	 index += 1;
	 ll += 1;
 }
 film_name_str[ll] = '\0';

}  // do_plot_film
    
void do_params(char *paramstr)
    {

    char paramcode[4];

    paramcode[0]=paramstr[1];
    paramcode[1]=paramstr[2];

    paramcode[2]='\0';

    if (strcmp(paramcode,"AD") == 0 )
      {
        do_aper_def( paramstr,3);
      }

    if (strcmp(paramcode,"AM") == 0 )
      {
        do_aper_macro( paramstr,3);
      }
    
    if (strcmp(paramcode,"AS") == 0 )
      {
        do_axis_select( paramstr,3);
       } 

    if (strcmp(paramcode,"FS") == 0 )  // FS<L|T><A|I>
      {
	   leading_trailing_str[0]=paramstr[3];
	   leading_trailing_str[1]='\0';
	   absolute_incr_str[0]=paramstr[4];
	    absolute_incr_str[1]='\0';
		if (strcmp(absolute_incr_str,"A")==0)
		{
			incremental_mode=FALSE;
			absolute_mode=TRUE;
		}
	   if (strcmp(absolute_incr_str,"I")==0)
		{
			incremental_mode=TRUE;
			absolute_mode=FALSE;
		}
        do_format_statement( paramstr,5);
      }    

    if (strcmp(paramcode,"IF") == 0 )
      {
        do_include_file( paramstr,3);
      }    

    if (strcmp(paramcode,"IJ") == 0 )
      {
        do_image_justify( paramstr,3);
      }    

    if (strcmp(paramcode,"IN") == 0 )
      {
        do_image_name( paramstr,3);
      }    

    if (strcmp(paramcode,"IO") == 0 )
      {
        do_image_offset( paramstr,3);
      }   

    if (strcmp(paramcode,"IR") == 0 )
      {
        do_image_rotation( paramstr,3);
      }    

    if (strcmp(paramcode,"IP") == 0 )
      {
        image_pol_str[0]=paramstr[3];
 	    image_pol_str[1]=paramstr[4];
	    image_pol_str[2]=paramstr[5];
	    image_pol_str[3]='\0';
      }    

    if (strcmp(paramcode,"KO") == 0 )
      {
        do_knock_out( paramstr,3);
      }     

    if (strcmp(paramcode,"LN") == 0)
      {
        do_layer_name( paramstr,3);
      }     

    if (strcmp(paramcode,"LP") == 0 )
      {
        layer_pol_str[0]=paramstr[3];
	layer_pol_str[1]='\0';
	if(layer_pol_str[0] == 'C')  // LPC
	  {
	    savecolor = lpc_count;
            lpc_count += 1;
	    set_clear();
          }
        if(layer_pol_str[0] == 'D')  // LPD
	  {
	    set_color( lpd_count);
            lpd_count += 1;
          }
      }     

    if (strcmp(paramcode,"MI") == 0 )
      {
	   strncpy(a_mirror_str,"0",4);
	      
        if (paramstr[3]=='A')
		{
	     a_mirror_str[0]=paramstr[4];
	     a_mirror_str[1]='\0';
		}
	    strncpy(b_mirror_str,"0",4);
	    if (paramstr[3]=='B')
		{
	    b_mirror_str[0]=paramstr[4];
	    b_mirror_str[1]='\0';
		}
    	if (paramstr[5]=='B')
		{
	    b_mirror_str[0]=paramstr[6];
	    b_mirror_str[1]='\0';
		}
		if (strcmp(a_mirror_str,"1" ) == 0 )
		{
			if (strcmp(b_mirror_str,"1") == 0 )
			{
				do_mirror_xy();
                mirror_x_active=1;
				mirror_y_active=1;
			}
			else
			{
				do_mirror_x();
                mirror_x_active=1;
				mirror_y_active=0;
			}
		}
		else   // MIA0
		{
			if (strcmp(b_mirror_str,"1") == 0 )
			{
				do_mirror_y();
                
				mirror_y_active=0;
			}
			if (strcmp(b_mirror_str,"0") == 0 )
			{
				mirror_x_active=0;
				mirror_y_active=0;
				end_mirror_xy();
			}
			if (strcmp(b_mirror_str,"") == 0 )
			{
				mirror_y_active=0;
				end_mirror_y();
			}
		}


      }     

    if (strcmp(paramcode,"MO") == 0 )
      {
        mode_str[0]=paramstr[3];
        mode_str[1]=paramstr[4];
	    mode_str[2]='\0';
      }   

    if (strcmp(paramcode,"OF") == 0 )
      {
        do_offset( paramstr,3);
      }   
  
    if (strcmp(paramcode,"PF") == 0 )
      {
        do_plot_film( paramstr,3);
      }   

    if (strcmp(paramcode,"SF") == 0 )
      {
        do_scale_factor( paramstr,3);
      }   

    if (strcmp(paramcode,"SR") == 0 )
      {
        do_step_repeat( paramstr,3);
      }   

   }  // end do_params


   // a filled polygon

void do_polygon( char *layer_color)
{
int ii;
char quotchar;

  quotchar='"';

  ii = 0;
  fprintf(outfile,"<polygon points= %c",quotchar);

  while(ii < poly_point_count)
  {
    fprintf(outfile," %0.0f,%0.0f ", poly_points[ii][0], poly_points[ii][1] );

	UpdatePointExtents( poly_points[ii][0],poly_points[ii][1]);

	if ((ii % 6 ) == 0 )
	{
		fprintf(outfile,"\n");
	}
  ii += 1;
  }
  fprintf(outfile,"%c\n",quotchar);
  fprintf(outfile," style=%cfill:%s;",quotchar,rgbstr);
  fprintf(outfile,"stroke:#000000;stroke-width:1%c />\n",quotchar,quotchar);

}     // end do_polygon


void do_six_sided( double x1, double y1, double x2, double y2, double x3, double y3,
				   double x4, double y4, double x5, double y5, double x6, double y6)
{
int ii;
char quotchar;

  quotchar='"';

  ii = 0;
  fprintf(outfile,"<polygon points= %c",quotchar);

 
    fprintf(outfile," %0.0f,%0.0f ", x1,y1 );
    UpdatePointExtents( x1,y1 );
	fprintf(outfile," %0.0f,%0.0f ", x2,y2 );
    UpdatePointExtents( x2,y2 );
    fprintf(outfile," %0.0f,%0.0f ", x3,y3 );
    UpdatePointExtents( x3, y3 );
	fprintf(outfile," %0.0f,%0.0f ", x4,y4 );
    UpdatePointExtents( x4, y4 );
	fprintf(outfile," %0.0f,%0.0f ", x5,y5 );
	UpdatePointExtents( x5, y5 );
	fprintf(outfile," %0.0f,%0.0f ", x6,y6 );
    UpdatePointExtents( x6, y6 );

		fprintf(outfile,"\n");
	
  fprintf(outfile,"%c\n",quotchar);
  fprintf(outfile," style=%cfill:%s;",quotchar,rgbstr);
fprintf(outfile,"stroke:#000000;stroke-width:1%c />\n",quotchar);

}     // end do_six_sided

void do_flash_circle( double xval, double yval, double diam, char *layer_color)
{
double radius;
char quotchar;
int debug;

  debug=0;
  if (debug) { printf("In do_flash, x,y = %f %f \n",xval,yval); }

  quotchar='"';

  radius=diam/2.0;

  fprintf(outfile,"<circle cx=%c%0.0f%c cy=%c%0.0f%c r=%c%0.0f%c stroke=%cblack%c \n",
	                 quotchar,xval,quotchar,quotchar,yval,quotchar,
					 quotchar,radius,quotchar, quotchar, quotchar);

  fprintf(outfile,"  stroke-width=%c2%c fill=%c%s%c />\n",quotchar,quotchar,quotchar,
	           layer_color,quotchar);

  UpdateCircleExtents(xval, yval, radius, 0.0);
}

// flash a rectangle
//<rect x="5" y="5" width="40" height="40" fill="red"/>
void do_flash_rect( double xval, double yval, double xsize, double ysize, char *layer_color)
{
char quotchar;
int debug;


 
  debug=0;
  if (debug) { printf("In do_flash_rect, x,y = %f %f \n",xval,yval); }

  quotchar='"';

  fprintf(outfile,"<rect fill=%cgreen%c stroke=%cblue%c stroke-width=%c10%c  \n",
		quotchar,quotchar,quotchar,quotchar,quotchar,quotchar);


  UpdatePointExtents(xval-(xsize/2.0),yval-(ysize/2.0));
  UpdatePointExtents(xval+(xsize/2.0),yval+(ysize/2.0));

  fprintf(outfile," x=%c%0.0f%c y=%c%0.0f%c width=%c%0.0f%c height=%c%0.0f%c ",
			 quotchar, xval-(xsize/2.0),quotchar,quotchar,yval-(ysize/2.0),quotchar,
			 quotchar,xsize,quotchar,quotchar,ysize,quotchar); 
   fprintf(outfile," />\n");

}

// flash a rectangle
//<rect x="5" y="5" width="40" height="40" fill="red"/>
// no longer called

void do_flash_oval(double xval, double yval, double xsize, double ysize, char *layer_color)
{
char quotchar;
int debug;


 
  debug=0;
  if (debug) { printf("In do_flash_oval, x,y = %f %f \n",xval,yval); }

  quotchar='"';

  fprintf(outfile,"<rect fill=%cgreen%c stroke=%cblue%c stroke-width=%c10%c  \n",
		quotchar,quotchar,quotchar,quotchar,quotchar,quotchar);

		  
  fprintf(outfile," x=%c%0.0f%c y=%c%0.0f%c width=%c%0.0f%c height=%c%0.0f%c ",
			 quotchar, xval,quotchar,quotchar,yval,quotchar,
			 quotchar,xsize,quotchar,quotchar,ysize,quotchar); 

   fprintf(outfile," />\n");

   UpdatePointExtents(xval-(xsize/2.0),yval-(ysize/2.0));  // just the box for now
   UpdatePointExtents(xval+(xsize/2.0),yval+(ysize/2.0));



}  // do_flash_oval

void do_svg_tail()
{

	fprintf(outfile,"</svg>\n");
}

void do_svg_head( )
{
char quotchar;
int widthval;
int heightval;

  widthval=2000000;
  heightval=2000000;
  quotchar='"';
  fprintf(outfile,"<?xml version=%c1.0%c standalone=%cno%c?>\n",quotchar,quotchar,quotchar,
	   quotchar);

  fprintf(outfile,"<!DOCTYPE svg PUBLIC %c-//W3C//DTD SVG 1.0//EN%c\n", quotchar,quotchar);

  fprintf(outfile,"%chttp://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd%c>\n",
	           quotchar,quotchar);

  fprintf(outfile,"<svg width='%dpx' height='%dpx' viewPort='-%d -%d %d %d'  >\n",
	   widthval, heightval, widthval/2, heightval/2, widthval, heightval);

}

void do_prim_thermal( double xval, double yval,
					  double xcen, double ycen, double out_diam,
					  double inside_diam, double cross_thickness,
					  double rot)
{
double quad_points_x[30];
double quad_points_y[30];
double quad0_x[30];
double quad1_x[30];
double quad2_x[30];
double quad3_x[30];
double quad0_y[30];
double quad1_y[30];
double quad2_y[30];
double quad3_y[30];

int jj;

double theta;
double inside_radius;
double outside_radius;
double angle;
double angle_increment;
double rotation;
double gamma;
double tx,ty;
char quotchar;

     quotchar = '"';
     rotation = (rot/2.0*PI);
	 
     inside_radius=(inside_diam/2.0);
	 outside_radius=(out_diam/2.0);

	 theta = asin( (cross_thickness/2.0)/ inside_radius ) ;
	 gamma = (PI/2.0)-2.0*theta;

	 
	 angle_increment = gamma/10.0;

	 angle=theta + angle_increment;

     quad_points_y[0] = (cross_thickness/2.0);
	 quad_points_x[0] = sqrt( (inside_radius * inside_radius) - ( quad_points_y[0] *
		                            quad_points_y[0]) ); 
	 quad_points_y[21] = (cross_thickness/2.0);
	 quad_points_x[21] = sqrt( (outside_radius * outside_radius) - ( quad_points_y[0] *
		                            quad_points_y[0]) );
	 for( jj=1; jj < 10; jj += 1)
	 {
		 quad_points_x[jj]= cos(angle) * inside_radius;
		 quad_points_x[21-jj]= cos(angle) * outside_radius;

         quad_points_y[jj]= sin(angle) * inside_radius;
		 quad_points_y[21-jj]= sin(angle) * outside_radius;

		 angle = angle + angle_increment;
	 }

	 quad_points_x[10] = cross_thickness/2.0;
	 quad_points_y[10] = sqrt( (inside_radius * inside_radius) - ( quad_points_x[10] *
		                            quad_points_x[10]) );
     quad_points_x[11] = cross_thickness/2.0;
	 quad_points_y[11] = sqrt( (outside_radius * outside_radius) - ( quad_points_x[10] *
		                            quad_points_x[10]) );

	 for(jj=0; jj < 22; jj += 1)
	 {
		 quad0_x[jj] = quad_points_x[jj];
		 quad1_x[jj] = - quad_points_x[jj];
		 quad2_x[jj] = - quad_points_x[jj];
		 quad3_x[jj] = quad_points_x[jj];

         quad0_y[jj] = quad_points_y[jj];
		 quad1_y[jj] = quad_points_y[jj];
		 quad2_y[jj] = - quad_points_y[jj];
		 quad3_y[jj] = - quad_points_y[jj];

	 }

	 if (rotation != 0.0)
	 {
		 for( jj = 0; jj < 22 ; jj += 1)
		 {
			 tx = quad0_x[jj];
			 ty = quad0_y[jj];
			 quad0_x[jj] = tx * cos( rotation) - ty * sin( rotation);
			 quad0_x[jj] = ty * cos( rotation) + tx * sin( rotation);

             tx = quad1_x[jj];
			 ty = quad1_y[jj];
			 quad1_x[jj] = tx * cos( rotation) - ty * sin( rotation);
			 quad1_x[jj] = ty * cos( rotation) + tx * sin( rotation);

             tx = quad2_x[jj];
			 ty = quad2_y[jj];
			 quad2_x[jj] = tx * cos( rotation) - ty * sin( rotation);
			 quad2_x[jj] = ty * cos( rotation) + tx * sin( rotation);

             tx = quad3_x[jj];
			 ty = quad3_y[jj];
			 quad3_x[jj] = tx * cos( rotation) - ty * sin( rotation);
			 quad3_x[jj] = ty * cos( rotation) + tx * sin( rotation);
		 }
	 }


	// print the four polygons

   fprintf(outfile,"<polygon points=%c",quotchar);

    for(jj=0; jj < 5; jj += 1)
	{
  
    fprintf(outfile," %0.0f,%0.0f ", xval+ quad0_x[4*jj],yval + quad0_y[4*jj]);
    UpdatePointExtents( xval+ quad0_x[4*jj],yval + quad0_y[4*jj]);

    fprintf(outfile," %0.0f,%0.0f ", xval+ quad0_x[(4*jj)+1],yval+ quad0_y[(4*jj)+1]);
    UpdatePointExtents( xval+ quad0_x[(4*jj)+1],yval+ quad0_y[(4*jj)+1] );

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad0_x[(4*jj)+2],yval+ quad0_y[(4*jj)+2]);
    UpdatePointExtents( xval+ quad0_x[(4*jj)+2],yval+ quad0_y[(4*jj)+2] );

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad0_x[(4*jj)+3],yval+ quad0_y[(4*jj)+3]);
    UpdatePointExtents( xval+ quad0_x[(4*jj)+2],yval+ quad0_y[(4*jj)+2] );
	fprintf(outfile,"\n");
	}

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad0_x[20],yval+ quad0_y[20]);
    UpdatePointExtents( xval+ quad0_x[20],yval+ quad0_y[20] );

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad0_x[21],yval+ quad0_y[21]);
	UpdatePointExtents( xval+ quad0_x[20],yval+ quad0_y[20] );


  fprintf(outfile,"%c\n",quotchar);
  fprintf(outfile," style=%cfill:%s;",quotchar,rgbstr);
  fprintf(outfile,"stroke:#000000;stroke-width:1%c />\n",quotchar);

   fprintf(outfile,"<polygon points=%c",quotchar);

    for(jj=0; jj < 5; jj += 1)
	{
  
    fprintf(outfile," %0.0f,%0.0f ", xval+ quad1_x[4*jj],yval + quad1_y[4*jj]);
    UpdatePointExtents( xval+ quad1_x[4*jj],yval + quad1_y[4*jj] );

    fprintf(outfile," %0.0f,%0.0f ", xval+ quad1_x[(4*jj)+1],yval+ quad1_y[(4*jj)+1]);
    UpdatePointExtents( xval+ quad1_x[4*jj],yval + quad1_y[4*jj] );

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad1_x[(4*jj)+2],yval+ quad1_y[(4*jj)+2]);
    UpdatePointExtents( xval+ quad1_x[(4*jj)+2],yval+ quad1_y[(4*jj)+2] );

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad1_x[(4*jj)+3],yval+ quad1_y[(4*jj)+3]);
    UpdatePointExtents(xval+ quad1_x[(4*jj)+3],yval+ quad1_y[(4*jj)+3]);

	fprintf(outfile,"\n");
	}
	fprintf(outfile," %0.0f,%0.0f ", xval+ quad1_x[20],yval+ quad1_y[20]);
    UpdatePointExtents(xval+ quad1_x[20],yval+ quad1_y[20]);

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad1_x[21],yval+ quad1_y[21]);
    UpdatePointExtents(xval+ quad1_x[21],yval+ quad1_y[21]);

  fprintf(outfile,"%c\n",quotchar);
  fprintf(outfile," style=%cfill:%s;",quotchar,rgbstr);
  fprintf(outfile,"stroke:#000000;stroke-width:1%c />\n",quotchar);

   fprintf(outfile,"<polygon points=%c",quotchar);

    for(jj=0; jj < 5; jj += 1)
	{
  

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad2_x[4*jj],yval + quad2_y[4*jj]);
    UpdatePointExtents(xval+ quad2_x[4*jj],yval + quad2_y[4*jj]);

    fprintf(outfile," %0.0f,%0.0f ", xval+ quad2_x[(4*jj)+1],yval+ quad2_y[(4*jj)+1]);
    UpdatePointExtents( xval+ quad2_x[(4*jj)+1],yval+ quad2_y[(4*jj)+1] );

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad2_x[(4*jj)+2],yval+ quad2_y[(4*jj)+2]);
    UpdatePointExtents( xval+ quad2_x[(4*jj)+2],yval+ quad2_y[(4*jj)+2]);

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad2_x[(4*jj)+3],yval+ quad2_y[(4*jj)+3]);
    UpdatePointExtents(xval+ quad2_x[(4*jj)+3],yval+ quad2_y[(4*jj)+3] );

	fprintf(outfile,"\n");
	}
	fprintf(outfile," %0.0f,%0.0f ", xval+ quad2_x[20],yval+ quad2_y[20]);
    UpdatePointExtents(xval+ quad2_x[20],yval+ quad2_y[20]);

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad2_x[21],yval+ quad2_y[21]);
    UpdatePointExtents(xval+ quad2_x[21],yval+ quad2_y[21]);


  fprintf(outfile,"%c\n",quotchar);
  fprintf(outfile," style=%cfill:%s;",quotchar,rgbstr);
  fprintf(outfile,"stroke:#000000;stroke-width:1%c />\n",quotchar);

   fprintf(outfile,"<polygon points=%c",quotchar);

    for(jj=0; jj < 5; jj += 1)
	{
  
    fprintf(outfile," %0.0f,%0.0f ", xval+ quad3_x[4*jj],yval + quad3_y[4*jj]);
    UpdatePointExtents( xval+ quad3_x[4*jj],yval + quad3_y[4*jj]);

    fprintf(outfile," %0.0f,%0.0f ", xval+ quad3_x[(4*jj)+1],yval+ quad3_y[(4*jj)+1]);
    UpdatePointExtents( xval+ quad3_x[(4*jj)+1],yval+ quad3_y[(4*jj)+1]);

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad3_x[(4*jj)+2],yval+ quad3_y[(4*jj)+2]);
    UpdatePointExtents( xval+ quad3_x[(4*jj)+2],yval+ quad3_y[(4*jj)+2]);

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad3_x[(4*jj)+3],yval+ quad3_y[(4*jj)+3]);
    UpdatePointExtents( xval+ quad3_x[(4*jj)+2],yval+ quad3_y[(4*jj)+2]);

	fprintf(outfile,"\n");
	}
	fprintf(outfile," %0.0f,%0.0f ", xval+ quad3_x[20],yval+ quad3_y[20]);
    UpdatePointExtents( xval+ quad3_x[20],yval+ quad3_y[20]);

	fprintf(outfile," %0.0f,%0.0f ", xval+ quad3_x[21],yval+ quad3_y[21]);
    UpdatePointExtents( xval+ quad3_x[21],yval+ quad3_y[21]);

  fprintf(outfile,"%c\n",quotchar);
  fprintf(outfile," style=%cfill:%s;",quotchar,rgbstr);
  fprintf(outfile,"stroke:#000000;stroke-width:1%c />\n",quotchar);
}  //

void do_flash_line( double xval1, double yval1, double xval2, double yval2, 
				   double width)
{
char quotchar;

 quotchar='"';

 fprintf(outfile,"<line x1=%c%0.0f%c y1=%c%0.0f%c x2=%c%0.0f%c y2=%c%0.0f%c\n",
	              quotchar,xval1,quotchar,quotchar,yval1,quotchar,
				  quotchar,xval2,quotchar,quotchar,yval2,quotchar);

 fprintf(outfile," stroke=%c%s%c stroke-width=%c%0.0f%c/>\n",quotchar,rgbstr,quotchar,
	                    quotchar,width/1000.0,quotchar);

  UpdatePointExtents( xval1, yval1 );
  UpdatePointExtents( xval2, yval2 );


}

void do_flash_donut( double xval, double yval,double outer_radius, 
					double inner_radius,
					char *color)
{

 do_flash_circle( xval, yval, outer_radius * 2.0,  color);
 do_flash_circle( xval, yval, inner_radius * 2.0, "white");

}

// moire is a series of concentric circles
//

void do_prim_moire(double xval, double yval,
					   double xcen, double ycen, double outside_diam, 
					   double circle_thick, double gap,
					   int circle_count, double cross_hair_thick, 
					   double  cross_hair_len, double rot)
{

double radius;
double remainder;
double inner_radius;
double outer_radius;
double inner_rad;
double outer_rad;
double xl_ch;
double yl_ch;
double xr_ch;
double yr_ch;
double xl_ch_new;
double yl_ch_new;
double xr_ch_new;
double yr_ch_new;
double rotation;
 
int ii;

 radius = outside_diam/2.0;


 ii =0;

 remainder=radius;

 outer_radius = radius;

 while((ii < circle_count) && (remainder > 0 ))
 {
   remainder = remainder - ( gap + circle_thick);

   inner_radius = outer_radius - circle_thick;

   outer_rad = outer_radius * power_factor;
   inner_rad = inner_radius * power_factor;

  do_flash_donut( xcen+ xval, ycen+yval, outer_rad, inner_rad, rgbstr);
   
   outer_radius = outer_radius - (gap + circle_thick);

   ii += 1;
 }


 rotation = PI*(rot/180.0);

 xl_ch = - ( cross_hair_len/2.0) * power_factor ;
 yl_ch = 0.0;

 xr_ch = (cross_hair_len/2.0)* power_factor;
 yr_ch = 0.0;

 if ( rotation == 0.0)
	{
     do_flash_line(xval+ xcen + xl_ch, ycen + yval, xval + xcen + xr_ch, 
	 ycen + yval ,cross_hair_thick * power_factor);
 }
 else
 {
	 xl_ch_new = xl_ch * cos( rotation) - yl_ch * sin(rotation);
	 yl_ch_new = yl_ch * cos( rotation) + xl_ch * sin(rotation);

     xr_ch_new = xr_ch * cos( rotation) - yr_ch * sin(rotation);
	 yr_ch_new = yr_ch * cos( rotation) + xr_ch * sin(rotation);


	 do_flash_line(xval+ xcen + xl_ch_new, ycen + yval + yl_ch_new,
		          xval + xcen + xr_ch_new, 
	 ycen + yval+ yr_ch_new ,cross_hair_thick* power_factor);
 }

 

 xl_ch = 0.0;
 yl_ch = - ( cross_hair_len/2.0) * power_factor ;
 
 xr_ch = 0.0;
 yr_ch = (cross_hair_len/2.0) * power_factor;

 if ( rotation == 0.0)
 {
do_flash_line(xval + xcen,yval+ ycen+yl_ch, xcen + xval, ycen + yval + yr_ch,
	 cross_hair_thick*power_factor);	
 }
 else
 {
     xl_ch_new = xl_ch * cos( rotation) - yl_ch * sin(rotation);
	 yl_ch_new = yl_ch * cos( rotation) + xl_ch * sin(rotation);

     xr_ch_new = xr_ch * cos( rotation) - yr_ch * sin(rotation);
	 yr_ch_new = yr_ch * cos( rotation) + xr_ch * sin(rotation);

     do_flash_line(xval + xcen + xl_ch_new,yval+ ycen+yl_ch_new,
		 xcen + xval+ xr_ch_new, ycen + yval + yr_ch_new,
	     cross_hair_thick*power_factor);	

 }

}

void do_prim_line(double xval, double yval,
					   int expose, double width, double xstart, double ystart,
					   double xend, double yend, double rot )
{
double xstart_new;
double ystart_new;
double xend_new;
double yend_new;
double rotangle;

 if ( rot != 0.0)
	{
	    rotangle = (rot * PI)/ 180.0;

		xstart_new = xstart * cos( rotangle) - ystart * sin( rotangle);
		ystart_new = ystart * cos( rotangle) + xstart * sin( rotangle);

        xend_new = xend * cos( rotangle) - yend * sin( rotangle);
		yend_new = yend * cos( rotangle) + xend * sin( rotangle);
 }
 else
 {
	 xstart_new = xstart;
	 ystart_new = ystart;

	 xend_new = xend;
	 yend_new = yend;
 }

 xstart_new = xstart_new + xval;
 ystart_new = ystart_new + yval;

 xend_new = xend_new + xval;
 yend_new = yend_new + yval;



 do_flash_line(xstart_new, ystart_new, xend_new, yend_new,width);
		

}

void do_prim_rectangle(double xval, double yval,
					   int expose, double width, double height, double xcen,
					   double ycen, double rot )
{
double llx;
double lly;
double lrx;
double lry;
double ulx;
double uly;
double urx;
double ury;
double llx_new;
double lly_new;
double lrx_new;
double lry_new;
double ulx_new;
double uly_new;
double urx_new;
double ury_new;
char quotchar;
double rotangle;
int debug;

    debug=0;

    quotchar = '"';

    llx = - (width*power_factor)/2.0;
	lly = - (height*power_factor)/2.0;

	lrx = - llx;
	lry = lly;

	ulx = llx;
	uly = -lly;

	urx = -llx;
	ury = -lly;

	llx =  xcen + llx;
    lly =  ycen + lly;

    lrx =  xcen + lrx;
    lry =  ycen + lry;

    ulx = xcen + ulx;
    uly = ycen + uly;

    urx = xcen + urx;
    ury = ycen + ury;

	if (rot != 0.0)
	{
		rotangle = (rot * PI)/ 180.0;

		if (debug) { printf("In do_prim_rectangle, rot angle = %f \n", rotangle); }

		llx_new = llx * cos( rotangle) - lly * sin( rotangle);
		lly_new = lly * cos( rotangle) + llx * sin( rotangle);
		llx = llx_new;
		lly = lly_new;
        
		lrx_new = lrx * cos( rotangle) - lry * sin( rotangle);
		lry_new = lry * cos( rotangle) + lrx * sin( rotangle);
		lrx = lrx_new;
		lry = lry_new;

        ulx_new = ulx * cos( rotangle) - uly * sin( rotangle);
		uly_new = uly * cos( rotangle) + ulx * sin( rotangle);
		ulx = ulx_new;
		uly = uly_new;

        urx_new = urx * cos( rotangle) - ury * sin( rotangle);
		ury_new = ury * cos( rotangle) + urx * sin( rotangle);
		urx = urx_new;
		ury = ury_new;

	}

  llx = xval  + llx;
  lly = yval  + lly;

  lrx = xval  + lrx;
  lry = yval  + lry;

  ulx = xval  + ulx;
  uly = yval  + uly;

  urx = xval  + urx;
  ury = yval  + ury;

  fprintf(outfile,"<polygon points=%c",quotchar);

  
    fprintf(outfile," %0.0f,%0.0f ", llx, lly);
    fprintf(outfile," %0.0f,%0.0f ", ulx, uly);
	fprintf(outfile," %0.0f,%0.0f ", urx, ury);
	fprintf(outfile," %0.0f,%0.0f ", lrx, lry);

	UpdatePointExtents( llx, lly );
	UpdatePointExtents( urx, uly );
	UpdatePointExtents( urx, ury );
	UpdatePointExtents( lrx, lry );

	if (debug)
	{
     printf(" %0.0f,%0.0f ", llx, lly);
     printf(" %0.0f,%0.0f ", ulx, uly);
	 printf(" %0.0f,%0.0f ", urx, ury);
	 printf(" %0.0f,%0.0f \n", lrx, lry);
	}

  fprintf(outfile,"%c\n",quotchar);
  fprintf(outfile," style=%cfill:%s;",quotchar,rgbstr);
fprintf(outfile,"stroke:#000000;stroke-width:1%c />\n",quotchar);

} 

void do_prim_polygon(double xval, double yval, int expose,
					   int vertice_count, double xcen, double ycen, double diameter,
					   double rot, char *colorstr)
{
double xpoint_list[12];
double ypoint_list[12];

char quotchar;
double increment_angle;
double radius;
int jj;
double this_angle;

quotchar = '"';

    
 if ((vertice_count > 2)  && (vertice_count < 11 ))
 {

	 increment_angle = 360.0 / vertice_count;

	 this_angle = rot;

	 radius = diameter/2.0;

	 for( jj=0; jj < vertice_count; jj += 1)
	 {

          xpoint_list[jj] = (radius * cos( this_angle * PI / 180.0)) + xcen;
		  ypoint_list[jj] = (radius * sin( this_angle * PI / 180.0)) + ycen;

		 this_angle = this_angle + increment_angle;
     }

	
   fprintf(outfile,"<polygon points=%c",quotchar);

  
   for (jj=0; jj < vertice_count; jj += 1)
   {
     if ((jj % 6) == 5)
	 {
       fprintf(outfile," %0.0f,%0.0f \n", xval + xpoint_list[jj], yval + ypoint_list[jj]);
	 }
	 else
     {
       fprintf(outfile," %0.0f,%0.0f", xval + xpoint_list[jj], yval + ypoint_list[jj]);
	 }

	 UpdatePointExtents( xval + xpoint_list[jj], yval + ypoint_list[jj]);

   }
   
  fprintf(outfile,"%c\n",quotchar);
  fprintf(outfile," style=%cfill:%s;",quotchar,rgbstr);
  fprintf(outfile,"stroke:#000000;stroke-width:1%c />\n",quotchar);
 }
 else
 {
   printf("Aperture macro polygon with too few or too many veritice, count = %d \n",
	   vertice_count);

 }
} 

// no equations for now, just substitute
//
void instantiate_macro( int ad_index, int mac_index, int prim_index, double xval, double yval)
{
int jj;
char *this_primitive;
int parm_count;
int star_found;
int ll;
//char param_array[300][30];
char *dolptr;
char *tptr;
char tp1;
char tp2;
char param_str[300];
char newparamstr[400];
char tempstr1[300];
char tempstr2[300];
char tempstr[300];
int prim_val;
int pindex;
int subval;
int debug;
double x_ll;
double y_ll;
double width;
double height;
double x_cen;
double y_cen;
double circ_x;
double circ_y;
double circ_radius;

      debug = 0;


//	 strncpy(this_primitive,aperture_macro[mac_index].prim_array[prim_index].expr_str, 200);
     this_primitive=aperture_macro[mac_index].prim_array[prim_index].expr_str;

	 if (debug) { printf("this_primitive = %s \n", this_primitive); }

	 parm_count=0;
	 pindex=0;
  
	 star_found = FALSE;

     while(( star_found == FALSE) && ( this_primitive[pindex] != '\0'))
	 {
		 ll =0;
		 while(( this_primitive[pindex] != ',' ) && ( this_primitive[pindex] != '*')
			         && (ll < 80 ))
		 {
			 param_str[ll] = this_primitive[pindex];
			 pindex += 1;
			 ll += 1;
		 }
		 param_str[ll] = '\0';

		 if ((this_primitive[pindex] == '*') || ( this_primitive[pindex]=='\0'))
		 {
			 star_found=TRUE;
		 }
		 pindex += 1;   // skip past , or *

		 if (debug) { printf("into parm_array, s = %s parm_count = %d \n",
			 param_str,parm_count); }

		 strncpy(param_array[parm_count], param_str,120);
		 parm_count +=1;

	 }

// now substitute in values from AD

	 for(jj=0; jj < parm_count; jj +=1)
	 {
		 dolptr =strstr(param_array[jj],"$");
		 if (debug)
		 {
		  printf("jj = %d param_array jj = %s jj+1 = %s\n", jj, param_array[jj],
			 param_array[jj+1]);
		 }
	 

		 while (dolptr != NULL)
		 {
			 strncpy(tempstr,param_array[jj],120);   // get the base
			 tptr=strstr(tempstr,"$");
			 *tptr='\0';
			 tptr++;
			 tp1 = *tptr;
			 
			 tptr++;
			 tp2 = *tptr;

			 if ( ( isdigit(tp1)) && (isdigit( tp2)) )
			 {
				 tempstr1[0]= tp1;
				 tempstr1[1]= tp2;
				 tempstr1[2]='\0';
                 tptr++;
			 }
			 else
			 {
				 if (isdigit(tp1) )
				 {
					 tempstr1[0] = tp1;
                     tempstr1[1] = '\0';
                 }
				 else
				 {
					 tempstr1[0] = 0;
					 tempstr1[1] = '\0';
					 printf("Non digit after $ in AM macro \n");
				 }
			 }
			subval = atoi( tempstr1);
			if (debug) { printf("subval = %d \n",subval); }

            if (subval <= apt_list[ad_index].macro_parm_count)
				 {
				     if (debug)
					 {
				     printf("Before sub, ad_index = %d val = %f \n",
						  ad_index,apt_list[ad_index].macro_parms[subval]); 
					 }

					 _snprintf(tempstr2,200,"%f",apt_list[ad_index].macro_parms[subval]);
					 if (debug)
					 {
					 printf("Substitute %f for $%d\n", 
						 apt_list[ad_index].macro_parms[subval],subval);
					 }

					 strncpy(newparamstr,tempstr,120);
					 strncat(newparamstr,tempstr2,120);
					 strncat(newparamstr,tptr,120);
					 if (debug) { printf("newparamstr = %s \n",newparamstr); }
					 
				 }
				 else
				 {
					 strncpy(newparamstr,tempstr,120);
					 strncat(newparamstr,tptr,120);

					 printf("AM macro param number = %d is larger than AD param count =%d\n",
						 subval, apt_list[ad_index].macro_parm_count);

				 }

				if (debug)
				{
				printf("copying newparamstr for jj = %d , newparamstr = %s \n",
					jj, newparamstr);
				}

              
			   strncpy(param_array[jj],newparamstr,120);
			   

			   dolptr =strstr(param_array[jj],"$");
		 }

	 }

// now instantiate the macro

	prim_val = (int) atof(param_array[0]);

	if (prim_val == 1)
	{
      if (parm_count == 5)
	  {
		  if (debug)
		  {
	 	  printf("Call do_primitive circle here , expose = %d \n",
			          (int) atof( param_array[1]));
          printf("Call do_primitive circle here , diameter = %f \n",
			           atof( param_array[2]));
		  printf("Call do_primitive circle here , x center pos = %f \n",
			           atof( param_array[3]));
          printf("Call do_primitive circle here , y center pos = %f \n",
			           atof( param_array[4]));
		  printf("Call do_primitive circle here , xval = %f \n",
			           xval);
          printf("Call do_primitive circle here , yval = %f \n",
			           yval);
		  }

		  circ_x = atof( param_array[3]) * power_factor;
		  circ_y = atof( param_array[4]) * power_factor;
		  circ_radius = atof( param_array[2]) * power_factor;

        do_flash_circle( circ_x + xval, circ_y + yval, circ_radius,rgbstr );

	  }
  	  else
	  {
		printf("Wrong number of parameters to am primitive 1, count = %d expected 5\n",
			parm_count);
	  }
	}
	if ((prim_val == 2) || ( prim_val == 20) )
	{
      if (parm_count == 8)
	  {
		  if (debug)
		  {
		  printf("Call do_primitive line here , expose = %d \n",
			          (int) atof( param_array[1]));
          printf("Call do_primitive line here , line width = %f \n",
			           atof( param_array[2]));
		  printf("Call do_primitive line here , x start pos = %f \n",
			           atof( param_array[3]));
          printf("Call do_primitive line here , y start pos = %f \n",
			           atof( param_array[4]));
	      printf("Call do_primitive line here , x end pos = %f \n",
			           atof( param_array[5]));
          printf("Call do_primitive line here , y end pos = %f \n",
			           atof( param_array[6]));
          printf("Call do_primitive line here , rotation = %f \n",
			           atof( param_array[7]));

		  }

         do_prim_line( xval, yval, (int) atof( param_array[1] ),
	  	   atof(param_array[2]),
		 	  atof(param_array[3]),
		 	  atof(param_array[4]),
			  atof(param_array[5]),
			  atof(param_array[6]),
			  atof(param_array[7]) );
	  }
  	  else
	  {	
		 printf("Wrong number of parameters to am primitive 2, count = %d expected 8\n",
			parm_count);
		
	  }
	}
	if (prim_val == 5)
	{
      if (parm_count == 7)
	  {
		if (debug)
		{
		  printf("Call do_primitive polygon here , expose = %d \n",
			          (int) atof( param_array[1]));
          printf("Call do_primitive polygon here , vertice count= %f \n",
			           atof( param_array[2]));
		  printf("Call do_primitive polygon here , x center pos = %f \n",
			           atof( param_array[3]));
          printf("Call do_primitive polygon here , y center pos = %f \n",
			           atof( param_array[4]));
	      printf("Call do_primitive polygon here , diameter = %f \n",
			           atof( param_array[5]));
          printf("Call do_primitive line here , rotation = %f \n",
			           atof( param_array[6]));
		}

          do_prim_polygon( xval, yval, (int) atof( param_array[1] ),
	 		  (int) atof(param_array[2]),
		 	  atof(param_array[3]),
			  atof(param_array[4]), atof(param_array[5]),
			  atof(param_array[6]), rgbstr );
	  }
  	  else
	  {
		printf("Wrong number of parameters to am primitive 5, count = %d expected 7\n",
			parm_count);
	  }
	}

	
	if (prim_val == 6)
	{
      if (parm_count == 10)
	  {
		  if (debug)
		  {
		  printf("Call do_primitive moire here ,  x center = %f \n",
			            atof( param_array[1]));
          printf("Call do_primitive moire here ,  y center = %f \n",
			           atof( param_array[2]));
		  printf("Call do_primitive moire here , outside diameter = %f \n",
			           atof( param_array[3]));
          printf("Call do_primitive moire here , circle line thickness = %f \n",
			           atof( param_array[4]));
	      printf("Call do_primitive moire here , gap between circles = %f \n",
			           atof( param_array[5]));
          printf("Call do_primitive moire here , number of circles = %f \n",
			           atof( param_array[6]));
          printf("Call do_primitive moire here , cross hair thickness = %f \n",
			           atof( param_array[7]));
          printf("Call do_primitive moire here , cross hair length = %f \n",
			           atof( param_array[8]));
          printf("Call do_primitive moire here , rotation = %f \n",
			           atof( param_array[9]));

          }

         do_prim_moire( xval, yval, atof( param_array[1] ),
		  atof(param_array[2]),
		  atof(param_array[3]),
		  atof(param_array[4]),
		  atof(param_array[5]),
		  (int) atof( param_array[6]),
		  atof(param_array[7]),
		  atof(param_array[8]),
		  atof(param_array[9]));
	  }
  	  else
	  {
		  printf("Wrong number of parameters to am primitive 6, count = %d expected 10\n",
			parm_count);
	  }
	}
 
   if (prim_val == 7)
	{
      if (parm_count == 7)
	  {
		  if (debug)
		  {
		  printf("Call do_primitive thermal here ,  x center = %f \n",
			            atof( param_array[1]));
          printf("Call do_primitive thermal here ,  y center = %f \n",
			           atof( param_array[2]));
		  printf("Call do_primitive thermal here , outside diameter = %f \n",
			           atof( param_array[3]));
          printf("Call do_primitive thermal here , inside diameter = %f \n",
			           atof( param_array[4]));
	      printf("Call do_primitive thermal here , cross hair thickness = %f \n",
			           atof( param_array[5]));
          printf("Call do_primitive thermal here , rotation = %f \n",
			           atof( param_array[6]));
          }

        do_prim_thermal( xval, yval, atof( param_array[1] ),
	 		  atof(param_array[2]),
		 	  atof(param_array[3]),
			  atof(param_array[4]),
			  atof(param_array[5]),
			  atof(param_array[6]) );
	  }
  	  else
	  {
		printf("Wrong number of parameters to am primitive 7, count = %d expected 7\n",
			parm_count);
	  }
	}

 if (prim_val == 21)
	{
      if (parm_count == 7)
	  {
		  if (debug)
		  {
		  printf("Call do_primitive rectangle here ,  expose = %d \n",
			           (int) atof( param_array[1]));
          printf("Call do_primitive rectangle here ,  rectangle width = %f \n",
			           atof( param_array[2]));
		  printf("Call do_primitive rectangle here , rectangle height = %f \n",
			           atof( param_array[3]));
          printf("Call do_primitive rectangle here , x center point  = %f \n",
			           atof( param_array[4]));
	      printf("Call do_primitive rectangle here , y center point  = %f \n",
			           atof( param_array[5]));
		  printf("Call do_primitive rectangle here , xval  = %f \n",
			                xval);
	      printf("Call do_primitive rectangle here , yval = %f \n",
			                yval);
          printf("Call do_primitive rectangle here , rotation = %f \n",
			           atof( param_array[6]));
		  }

         do_prim_rectangle( xval, yval, (int) atof( param_array[1] ),
	 		  atof(param_array[2]),
		      atof(param_array[3]),
		 	  atof(param_array[4]),
		      atof(param_array[5]),
			  atof(param_array[6]) );
	  }
  	  else
	  {
		printf("Wrong number of parameters to am primitive 21, count = %d expected 7\n",
			parm_count);
	  }
	}
 
  if (prim_val == 22)
	{
      if (parm_count == 7)
	  {
		if (debug)
		{
		  printf("Call do_primitive rectangle here ,  expose = %d \n",
			           (int) atof( param_array[1]));
          printf("Call do_primitive rectangle here ,  rectangle width = %f \n",
			           atof( param_array[2]));
		  printf("Call do_primitive rectangle here , rectangle height = %f \n",
			           atof( param_array[3]));
          printf("Call do_primitive rectangle here , x lower left = %f \n",
			           atof( param_array[4]));
	      printf("Call do_primitive rectangle here , y lower left = %f \n",
			           atof( param_array[5]));
          printf("Call do_primitive rectangle here , rotation = %f \n",
			           atof( param_array[6]));
		}

		 x_ll = atof( param_array[4]);
		 y_ll = atof( param_array[5]);
		 width=atof(param_array[2]);
		 height=atof(param_array[3]);

		 x_cen= x_ll + (width/2.0);
		 y_cen= y_ll + (height/2.0);

         do_prim_rectangle( xval, yval, (int) atof( param_array[1] ),
	 		  atof(param_array[2]),
		      atof(param_array[3]),
		 	  x_cen,
		      y_cen,
			  atof(param_array[6]) );
	  }
  	  else
	  {
		printf("Wrong number of parameters to am primitive 21, count = %d expected 7\n",
			parm_count);
	  }
	}
}  // end

//
// 
//
void instantiate_macro_new( int ad_index, int prim_index, double xval, double yval)
{
int parm_count;
double param_array[30];
int prim_val;
int debug;
double x_ll;
double y_ll;
double width;
double height;
double x_cen;
double y_cen;
double circ_x;
double circ_y;
double circ_radius;
int kk;
int ll;
int vertice_count;

      debug = 0;


// now substitute in values from AD


// now instantiate the macro

	prim_val = (int) apt_list[ad_index].macro_vals[prim_index][0]; 
	parm_count = apt_list[ad_index].macro_vals_parmcnt[prim_index];

	for(kk=1; kk < parm_count; kk += 1)
	{
		param_array[kk]= apt_list[ad_index].macro_vals[prim_index][kk];
		printf("Param_array[%d] = %f \n", kk, param_array[kk]);
	}

	if (prim_val == 1)
	{
      if (parm_count == 5)
	  {
		  if (debug)
		  {
	 	  printf("Call do_primitive circle here , expose = %d \n",
			          (int)  param_array[1]);
          printf("Call do_primitive circle here , diameter = %f \n",
			            param_array[2]);
		  printf("Call do_primitive circle here , x center pos = %f \n",
			            param_array[3]);
          printf("Call do_primitive circle here , y center pos = %f \n",
			            param_array[4]);
		  printf("Call do_primitive circle here , xval = %f \n",
			           xval);
          printf("Call do_primitive circle here , yval = %f \n",
			           yval);
		  }

		  circ_x =  param_array[3] * x_power_factor;
		  circ_y =  param_array[4] * y_power_factor;
		  circ_radius =  param_array[2] * power_factor;

        do_flash_circle( 10.0 * circ_x + xval, 10.0 * circ_y + yval, circ_radius,rgbstr );

	  }
  	  else
	  {
		printf("Wrong number of parameters to am primitive 1, count = %d expected 5\n",
			parm_count);
	  }
	}
	if ((prim_val == 2) || ( prim_val == 20) )
	{
      if (parm_count == 8)
	  {
		  if (debug)
		  {
		  printf("Call do_primitive line here , expose = %d \n",
			          (int)  param_array[1]);
          printf("Call do_primitive line here , line width = %f \n",
			            param_array[2]);
		  printf("Call do_primitive line here , x start pos = %f \n",
			            param_array[3]);
          printf("Call do_primitive line here , y start pos = %f \n",
			            param_array[4]);
	      printf("Call do_primitive line here , x end pos = %f \n",
			            param_array[5]);
          printf("Call do_primitive line here , y end pos = %f \n",
			            param_array[6]);
          printf("Call do_primitive line here , rotation = %f \n",
			            param_array[7]);

		  }

         do_prim_line( xval, yval, (int)  param_array[1] ,
	  	   param_array[2],
		 	  param_array[3],
		 	  param_array[4],
			  param_array[5],
			  param_array[6],
			  param_array[7] );
	  }
  	  else
	  {	
		 printf("Wrong number of parameters to am primitive 2, count = %d expected 8\n",
			parm_count);
		
	  }
	}

	if (prim_val == 4)  // Outline
	{
  
		if (debug)
		{
		  printf("Call do_primitive outline here , expose = %d \n",
			          (int)  param_array[1]);
          printf("Call do_primitive outline here , vertice count= %f \n",
			            param_array[2]);
		  printf("Call do_primitive outline here , x start pos = %f \n",
			            param_array[3]);
          printf("Call do_primitive outline here , y start pos = %f \n",
			            param_array[4]);
		  vertice_count= (int) param_array[2];

		  if ( (2 * vertice_count) + 4 == parm_count)
		  {
		    for(kk=1; kk < vertice_count; kk += 1)
			{
	        printf("Call do_primitive outline here x point %d  = %f \n",
			            kk,param_array[(2 * kk)+3]);
            printf("Call do_primitive outline here , y point %d  = %f \n",
			            kk,param_array[(2 * kk) + 4]);
			}
			printf("Call do_primitive outline here rotation = %f \n",
			            param_array[(2 * kk)+3]);
		  }
		}

	   vertice_count = ((int) param_array[2]) + 1;
       ll=0;
       if ( ((2 * vertice_count) + 4) == parm_count)
		  {
		    for(kk=0; kk < vertice_count; kk += 1)
			{
			 poly_points[ll][0] = param_array[(2 * kk)+3] + xval;
			 poly_points[ll][1] = param_array[(2 * kk)+4] + yval;
			 ll += 1;
			} 
			poly_point_count=ll;

			do_polygon( rgbstr );
		  }
	   else
	   {
		
		   printf("Outline macro parameter count mismatch\n");
		   printf("Got parm_count = %d expected = %d \n", parm_count,
		                       (2 * vertice_count) + 4);
		   printf("Vertice count = %d \n",vertice_count);

	   }


	}
	if (prim_val == 5)  // polygon
	{
      if (parm_count == 7)
	  {
		if (debug)
		{
		  printf("Call do_primitive polygon here , expose = %d \n",
			          (int)  param_array[1]);
          printf("Call do_primitive polygon here , vertice count= %f \n",
			            param_array[2]);
		  printf("Call do_primitive polygon here , x center pos = %f \n",
			            param_array[3]);
          printf("Call do_primitive polygon here , y center pos = %f \n",
			            param_array[4]);
	      printf("Call do_primitive polygon here , diameter = %f \n",
			            param_array[5]);
          printf("Call do_primitive line here , rotation = %f \n",
			            param_array[6]);
		}

          do_prim_polygon( xval, yval, (int)  param_array[1] ,
	 		  (int) param_array[2],
		 	  param_array[3],
			  param_array[4],
			  param_array[5],
			  param_array[6] , rgbstr);
	  }
  	  else
	  {
		printf("Wrong number of parameters to am primitive 5, count = %d expected 7\n",
			parm_count);
	  }
	}

	
	if (prim_val == 6)  // moire
	{
      if (parm_count == 10)
	  {
		  if (debug)
		  {
		  printf("Call do_primitive moire here ,  x center = %f \n",
			             param_array[1]);
          printf("Call do_primitive moire here ,  y center = %f \n",
			            param_array[2]);
		  printf("Call do_primitive moire here , outside diameter = %f \n",
			            param_array[3]);
          printf("Call do_primitive moire here , circle line thickness = %f \n",
			            param_array[4]);
	      printf("Call do_primitive moire here , gap between circles = %f \n",
			            param_array[5]);
          printf("Call do_primitive moire here , number of circles = %f \n",
			            param_array[6]);
          printf("Call do_primitive moire here , cross hair thickness = %f \n",
			            param_array[7]);
          printf("Call do_primitive moire here , cross hair length = %f \n",
			            param_array[8]);
          printf("Call do_primitive moire here , rotation = %f \n",
			            param_array[9]);

          }

         do_prim_moire( xval, yval,  param_array[1],
		  param_array[2],
		  param_array[3],
		  param_array[4],
		  param_array[5],
		  (int)  param_array[6],
		  param_array[7],
		  param_array[8],
		  param_array[9] );
	  }
  	  else
	  {
		  printf("Wrong number of parameters to am primitive 6, count = %d expected 10\n",
			parm_count);
	  }
	}
 
   if (prim_val == 7)
	{
      if (parm_count == 7)
	  {
		  if (debug)
		  {
		  printf("Call do_primitive thermal here ,  x center = %f \n",
			             param_array[1]);
          printf("Call do_primitive thermal here ,  y center = %f \n",
			            param_array[2]);
		  printf("Call do_primitive thermal here , outside diameter = %f \n",
			            param_array[3]);
          printf("Call do_primitive thermal here , inside diameter = %f \n",
			            param_array[4]);
	      printf("Call do_primitive thermal here , cross hair thickness = %f \n",
			            param_array[5]);
          printf("Call do_primitive thermal here , rotation = %f \n",
			            param_array[6]);
          }

        do_prim_thermal( xval, yval,  param_array[1] ,
	 		  param_array[2],
		 	  param_array[3],
			  param_array[4],
			  param_array[5],
			  param_array[6] );
	  }
  	  else
	  {
		printf("Wrong number of parameters to am primitive 7, count = %d expected 7\n",
			parm_count);
	  }
	}

 if (prim_val == 21)
	{
      if (parm_count == 7)
	  {
		  
		  if (debug)
		  {
		  printf("Call do_primitive rectangle here ,  expose = %d \n",
			           (int)  param_array[1]);
          printf("Call do_primitive rectangle here ,  rectangle width = %f \n",
			            param_array[2]);
		  printf("Call do_primitive rectangle here , rectangle height = %f \n",
			            param_array[3]);
          printf("Call do_primitive rectangle here , x center point  = %f \n",
			            param_array[4]);
	      printf("Call do_primitive rectangle here , y center point  = %f \n",
			            param_array[5]);
		  printf("Call do_primitive rectangle here , xval  = %f \n",
			                xval);
	      printf("Call do_primitive rectangle here , yval = %f \n",
			                yval);
          printf("Call do_primitive rectangle here , rotation = %f \n",
			            param_array[6]);
		  }

         do_prim_rectangle( xval, yval, (int)  param_array[1],
	 		  param_array[2],
		      param_array[3],
		 	  param_array[4],
		      param_array[5],
			  param_array[6] );
		 
	  }
  	  else
	  {
		printf("Wrong number of parameters to am primitive 21, count = %d expected 7\n",
			parm_count);
	  }
	}
 
  if (prim_val == 22)
	{
      if (parm_count == 7)
	  {
		if (debug)
		{
		  printf("Call do_primitive rectangle here ,  expose = %d \n",
			           (int)  param_array[1]);
          printf("Call do_primitive rectangle here ,  rectangle width = %f \n",
			            param_array[2]);
		  printf("Call do_primitive rectangle here , rectangle height = %f \n",
			            param_array[3]);
          printf("Call do_primitive rectangle here , x lower left = %f \n",
			            param_array[4]);
	      printf("Call do_primitive rectangle here , y lower left = %f \n",
			            param_array[5]);
          printf("Call do_primitive rectangle here , rotation = %f \n",
			            param_array[6]);
		}

		 x_ll =  param_array[4];
		 y_ll =  param_array[5];
		 width=param_array[2];
		 height=param_array[3];

		 x_cen= x_ll + (width/2.0);
		 y_cen= y_ll + (height/2.0);

         do_prim_rectangle( xval, yval, (int)  param_array[1],
	 		  param_array[2],
		      param_array[3],
		 	  x_cen,
		      y_cen,
			  param_array[6] );
	  }
  	  else
	  {
		printf("Wrong number of parameters to am primitive 22, count = %d expected 7\n",
			parm_count);
	  }
	}
}  // end


int find_in_macros( char *ad_macro)
{
int kk;
int foundval;

  foundval = -1;


  kk = 0;
  while( ( kk < aperture_mac_count) && (foundval == -1))
  {
	  if (strcmp( aperture_macro[kk].macroname,ad_macro)== 0 )
	  {
		  foundval = kk;
		   return(kk);
	  }
	kk += 1;
  }
  
 // printf("Could not find macro = %s \n",ad_macro );
  return(foundval);
}

void do_flash( double xval, double yval, int current_apt, char *current_layer)
{
int debug;
double diam;
double xsizeval;
double ysizeval;
int macro_index;
int kk;
double xholesize;
double yholesize;
int numsides;
double rot;
double sidelen;

  debug =0;

 
  if (debug) { printf("In do_flash , current_apt = %d \n", current_apt); }

  if ( current_apt < MAXAPTS)
	 {
	  if (apt_list[current_apt].iscircle )
	  {
		  
	   diam= apt_list[current_apt].diam;     // need to get layer color assignment
       diam=diam* power_factor;

	   do_flash_circle(xval,yval,diam,rgbstr);
		
       if (apt_list[current_apt].hashole == TRUE)
		{
		  if (apt_list[current_apt].holediam == 0 ) //  rect apt hole
			{
			  if ((apt_list[current_apt].holexsize != 0 ) &&
					  (apt_list[current_apt].holeysize != 0 ))
				{
                   xholesize = apt_list[current_apt].holexsize * power_factor;
				   yholesize = apt_list[current_apt].holeysize * power_factor;
				   do_flash_rect(xval,yval,xholesize,yholesize,"white");
				}
			}
		   else    // circular apt hole
			{
			 xsizeval=apt_list[current_apt].holediam * power_factor;
             do_flash_circle(xval,yval,xsizeval,"white");
			}
		  }		   
	  }   // end iscircle

	  if (apt_list[current_apt].isrect )
	  {
		
		xsizeval= apt_list[current_apt].xsize;     // need to get layer color assignment
		ysizeval= apt_list[current_apt].ysize;
        xsizeval=xsizeval*power_factor;
		ysizeval=ysizeval*power_factor;

		do_flash_rect(xval,yval,xsizeval,ysizeval,rgbstr);
		if (apt_list[current_apt].hashole == TRUE)
		{  
          if (apt_list[current_apt].holediam == 0 ) //  rect apt hole
		  {
			 if ((apt_list[current_apt].holexsize != 0 ) &&
					  (apt_list[current_apt].holeysize != 0 ))
				{
                   xholesize = apt_list[current_apt].holexsize * power_factor;
				   yholesize = apt_list[current_apt].holeysize * power_factor;
				   do_flash_rect(xval,yval,xholesize,yholesize,"white");
				}
		  }
		 else    // circular apt hole
		 {
			 xsizeval=apt_list[current_apt].holediam * power_factor;
             do_flash_circle(xval,yval,xsizeval,"white");
		  }
		}
	  }   // end isrect

	  if (apt_list[current_apt].isoval )
	  {
		 
		xsizeval= apt_list[current_apt].xsize;     // need to get layer color assignment
		ysizeval= apt_list[current_apt].ysize;
        xsizeval=xsizeval*power_factor;
		ysizeval=ysizeval*power_factor;

		if (xsizeval <= ysizeval)
		{
			ysizeval = ysizeval - xsizeval;
		}
		else
		{ 
			xsizeval= xsizeval - ysizeval;
		}

		do_flash_rect(xval,yval,xsizeval,ysizeval,rgbstr);
		if (xsizeval <= ysizeval)
		{
		 	do_flash_circle(xval,yval+(ysizeval/2.0),xsizeval,rgbstr);
			do_flash_circle(xval,yval-(ysizeval/2.0),xsizeval,rgbstr);
		}
		else
		{
			 do_flash_circle(xval+(xsizeval/2.0),yval,ysizeval,rgbstr);
			 do_flash_circle(xval-(xsizeval/2.0),yval,ysizeval,rgbstr);
		}

	   if (apt_list[current_apt].hashole == TRUE)
		{  
		 if (apt_list[current_apt].holediam == 0 ) //  rect apt hole
		 {
			if ((apt_list[current_apt].holexsize != 0 ) &&
					  (apt_list[current_apt].holeysize != 0 ))
				{
                   xholesize = apt_list[current_apt].holexsize * power_factor;
				   yholesize = apt_list[current_apt].holeysize * power_factor;
				   do_flash_rect(xval,yval,xholesize,yholesize,"white");
				}
		 }
		 else    // circular apt hole
		 {
			 xsizeval=apt_list[current_apt].holediam * power_factor;
             do_flash_circle(xval,yval,xsizeval,"white");
		 }
		}

	  } // end isoblong

     if (apt_list[current_apt].ispolygon)  // a polygonal flash
	  {
		 
		numsides= apt_list[current_apt].number_sides;     // number of sides to polygon
		sidelen = apt_list[current_apt].xsize;
        rot=apt_list[current_apt].ysize;

		if ((numsides > 2 ) && ( numsides < 12))
		{

          do_prim_polygon(xval, yval, 1, numsides, 0.0,0.0, 
			  ( sidelen / sin (PI/numsides) ),rot, rgbstr);
	
		}
		else
		{ 
			printf("Bad aperture definition,");
			printf("not enough (or too many) sides to a polygonal flash \n");			
		}
		

	   if (apt_list[current_apt].hashole == TRUE)
		{  
		 if (apt_list[current_apt].holediam == 0 ) //  rect apt hole
		 {
			if ((apt_list[current_apt].holexsize != 0 ) &&
					  (apt_list[current_apt].holeysize != 0 ))
				{
                   xholesize = apt_list[current_apt].holexsize * power_factor;
				   yholesize = apt_list[current_apt].holeysize * power_factor;
				   do_flash_rect(xval,yval,xholesize,yholesize,"white");
				}
		 }
		 else    // circular apt hole
		 {
			 xsizeval=apt_list[current_apt].holediam * power_factor;
             do_flash_circle(xval,yval,xsizeval,"white");
		 }
		}

	  } // end ispolygon

	  if (apt_list[current_apt].ismacro )
	  {
		  if (debug) { printf("Is a macro \n"); }
		  macro_index = find_in_macros( apt_list[current_apt].macro_name);
		  

		  if (debug)
		  {
			  printf("looked up macro = %s found index  = %d \n",
			  apt_list[current_apt].macro_name, macro_index );
		  }

		  if (macro_index != -1)
		  {
			for( kk =0; kk < aperture_macro[macro_index].primitive_count; kk += 1)
			{
				if (debug) { printf("Instantiate for kk = %d macro_index = %d \n",kk,
					macro_index); }

		      instantiate_macro( current_apt, macro_index, kk , xval, yval);
			}
		  }
	  }
	 }

 
  if (debug)
  {

	  printf("In do_flash xval, yval = %f %f ,dcode=%d  \n", xval,yval,current_apt );
		 
  }

}  // end do_flash

void draw_line( double beginx, double beginy, double endx, double endy, char *layerstr,
			     double scalefactor)
{
double width;
int debug;
double theta;

double rect_1b_x;
double rect_1b_y;
double rect_2b_x;
double rect_2b_y;
double rect_3b_x;
double rect_3b_y;
double rect_4b_x;
double rect_4b_y;

double rect_1e_x;
double rect_1e_y;
double rect_2e_x;
double rect_2e_y;
double rect_3e_x;
double rect_3e_y;
double rect_4e_x;
double rect_4e_y;
int col;
int box;

  debug = 0;

  if (polymode == FALSE)   // not in polygon mode
  {
	if ( apt_list[ current_apt_value].iscircle)
	{
      width= apt_list[current_apt_value].diam * power_factor;

	  do_flash(beginx,beginy,current_apt_value,currentlayer);

	  do_flash_line(beginx, beginy, endx, endy, width * 10.0);   // just flash the line

      do_flash(endx,endy,current_apt_value,currentlayer);
	  
	}
	if ( apt_list[ current_apt_value].isrect  )
	{
	  if (endx != beginx)
	  {
	    theta=atan( fabs( endy-beginy)/fabs(endx-beginx) );
	  }
	  else
	  {
		  theta = PI/2.0;
	  }
		if (debug) { printf("Drawing line with rectangular aperture \n"); } 

      rect_1b_x = beginx - (apt_list[current_apt_value].xsize/2.0)*power_factor;
      rect_1b_y = beginy + (apt_list[current_apt_value].ysize/2.0)*power_factor;
      rect_2b_x = beginx - (apt_list[current_apt_value].xsize/2.0)*power_factor;
      rect_2b_y = beginy - (apt_list[current_apt_value].ysize/2.0)*power_factor;
      rect_3b_x = beginx + (apt_list[current_apt_value].xsize/2.0)*power_factor;
      rect_3b_y = beginy - (apt_list[current_apt_value].ysize/2.0)*power_factor;
      rect_4b_x = beginx + (apt_list[current_apt_value].xsize/2.0)*power_factor;
      rect_4b_y = beginy + (apt_list[current_apt_value].ysize/2.0)*power_factor;

	  rect_1e_x = endx - (apt_list[current_apt_value].xsize/2.0)*power_factor;
      rect_1e_y = endy + (apt_list[current_apt_value].ysize/2.0)*power_factor;
      rect_2e_x = endx - (apt_list[current_apt_value].xsize/2.0)*power_factor;
      rect_2e_y = endy - (apt_list[current_apt_value].ysize/2.0)*power_factor;
      rect_3e_x = endx + (apt_list[current_apt_value].xsize/2.0)*power_factor;
      rect_3e_y = endy - (apt_list[current_apt_value].ysize/2.0)*power_factor;
      rect_4e_x = endx + (apt_list[current_apt_value].xsize/2.0)*power_factor;
      rect_4e_y = endy + (apt_list[current_apt_value].ysize/2.0)*power_factor;

	  if ( beginx < endx)
	  {
		  col=0;
	  }
	  if ( beginx == endx)
	  {
		  col = 1;
	  }
	  if (beginx > endx)
	  {
		  col = 2;
	  }

	  if (beginy < endy)
	  {
		  box = col;
	  }
	  if (beginy == endy)
	  {
		  box =  3 + col;
	  }
	  if (beginy > endy )
	  {
		  box = 6 + col;
	  }
	  switch(box)
	  {
	  case 0 : do_six_sided( rect_1b_x, rect_1b_y, rect_2b_x, rect_2b_y, rect_3b_x, rect_3b_y,
				             rect_3e_x, rect_3e_y, rect_4e_x, rect_4e_y, rect_1e_x, rect_1e_y);
		       break;
	  case 1 : do_flash( beginx, beginy, current_apt_value,currentlayer);       // vert
		       do_flash_line(beginx, beginy, endx, endy, apt_list[current_apt_value].xsize * 10.0);
			   do_flash( endx, endy, current_apt_value,currentlayer);
			   break;
      case 2 : do_six_sided( rect_4e_x, rect_4e_y, rect_1e_x, rect_1e_y, rect_2e_x, rect_2e_y,
				             rect_2b_x, rect_2b_y, rect_3b_x, rect_3b_y, rect_4b_x, rect_4b_y);
		       break;  
	  case 3 : do_flash( beginx, beginy, current_apt_value,currentlayer);       // horiz
		       do_flash_line(beginx, beginy, endx, endy, apt_list[current_apt_value].ysize * 10.0);
			   do_flash( endx, endy, current_apt_value,currentlayer);
			   break;
	  case 4 : do_flash( beginx, beginy, current_apt_value,currentlayer);      // no x,y change so just flash
		       break;
	  case 5 : do_flash( beginx, beginy, current_apt_value,currentlayer);       // horiz
		       do_flash_line(beginx, beginy, endx, endy, apt_list[current_apt_value].ysize * 10.0);
			   do_flash( endx, endy, current_apt_value,currentlayer);
			   break;
	  case 6 : do_six_sided( rect_4b_x, rect_4b_y, rect_1b_x, rect_1b_y, rect_2b_x, rect_2b_y,
				             rect_2e_x, rect_2e_y, rect_3e_x, rect_3e_y, rect_4e_x, rect_4e_y);
		       break;
	  case 7 : do_flash( beginx, beginy, current_apt_value,currentlayer);       // vert
		       do_flash_line(beginx, beginy, endx, endy, apt_list[current_apt_value].xsize);
			   do_flash( endx, endy, current_apt_value,currentlayer);
			   break;
	  case 8 : do_six_sided( rect_1e_x, rect_1e_y, rect_2e_x, rect_2e_y, rect_3e_x, rect_3e_y,
				             rect_3b_x, rect_3b_y, rect_4b_x, rect_4b_y, rect_1b_x, rect_1b_y);
		       break;
	  } 
	}
	if ( apt_list[ current_apt_value].isoval )  // oval , has caps 
	{
	  theta=atan( fabs( endy-beginy)/fabs(endx-beginx) );

      width= (apt_list[current_apt_value].xsize * sin(theta) + apt_list[current_apt_value].ysize * cos(theta)) 
		                           * power_factor;

	  if (apt_list[current_apt_value].xsize < apt_list[current_apt_value].ysize)  // account for caps
	  {
		width= (apt_list[current_apt_value].xsize * sin(theta) + 
			   (apt_list[current_apt_value].ysize  + apt_list[current_apt_value].xsize) * cos(theta)) 
		                           * power_factor;
	  }
	  else
	  {
		 width= ((apt_list[current_apt_value].xsize + apt_list[current_apt_value].ysize) * sin(theta)) + 
			   (apt_list[current_apt_value].ysize   * cos(theta)) 
		                           * power_factor;
	  }
	  do_flash(beginx,beginy,current_apt_value,currentlayer);

	  do_flash_line(beginx, beginy, endx, endy, width * 10.0);   // just flash the line

      do_flash(endx,endy,current_apt_value,currentlayer);
	  
	}
   
  }
  else   // just put into the poly_list for now
  {
      width= apt_list[current_apt_value].diam * power_factor;

	  if ( polycount < MAXPOLY)
	  {
		if (debug)
		{
        printf("Adding a polyline at %f %f %f %f \n",beginx, beginy, endx, endy );
		}

		poly_list[polycount].islinear_int=TRUE;
		poly_list[polycount].iscircle_int=FALSE;
		poly_list[polycount].isccwcircle_int=FALSE;
		poly_list[polycount].xval=endx;
		poly_list[polycount].yval=endy;
		poly_list[polycount].xprev=beginx;
		poly_list[polycount].yprev=beginy;
		poly_list[polycount].width=width;
	   
		polycount +=1;
	  }
  }
}  //end draw_line



void draw_arc( double beginx, double beginy, double endx, double endy, 
			   double centerx, double centery, char *layerstr,
			     double scalefactor)
{
double width;
int debug;

  debug=0;
  if (polymode == FALSE)   // not in polygon mode
  {
    width= apt_list[current_apt_value].diam * power_factor;

	// do_flash_arc( beginx, beginy, endx, endy, centerx,centery width);   // just flash the line
  }
  else   // just put into the poly_list for now
  {
      width= apt_list[current_apt_value].diam * power_factor;

	  if ( polycount < MAXPOLY)
	  {
       if (debug)
		{
		printf("Adding a polyarc = %f %f %f %f %f %f \n",beginx, beginy, endx,endy,
			           centerx, centery);
	   }
		poly_list[polycount].islinear_int=FALSE;
		poly_list[polycount].iscircle_int=TRUE;
		poly_list[polycount].isccwcircle_int=FALSE;
		poly_list[polycount].xval=endx;
		poly_list[polycount].yval=endy;
		poly_list[polycount].xprev=beginx;
		poly_list[polycount].yprev=beginy;
		poly_list[polycount].ival=centerx;
		poly_list[polycount].jval=centery;
		poly_list[polycount].width=width;
	    poly_list[polycount].radius= sqrt(( beginx - centerx) * (beginx-centerx) +
			                              ( beginy - centery) * (beginy-centery));
		polycount +=1;
	  }
  }
}  //end draw_arc

// draw arc clock wise
//
// counter clockwise
//
void draw_arc_svg_ccci( double radius, double beginx, double beginy, double endx, double endy, 
			   double centerx, double centery, char *layerstr,
			     double scalefactor)
{
double width;
int debug;
double end_dist;
double end_dist_sq;
double begin_angle;
double end_angle;

   debug=0;
  //debug=gdebug;

  end_dist_sq = (( endx - centerx) * (endx - centerx)) + ((endy - centery) * (endy - centery));
  end_dist = sqrt( end_dist_sq);

  if ( ((.95 * radius) < end_dist ) && ((1.05 * radius ) > end_dist))
  {
    
    if (polymode == FALSE)   // not in polygon mode
	{
      width= apt_list[current_apt_value].diam * power_factor;
	  end_angle = atan( ( endy - centery) / (endx - centerx ) ) * (180.0/PI);
	  if (end_angle < 0.0)
	  {
		  if (( endy- centery ) < 0.0)
		  {
			  end_angle = 360.0 + end_angle;
		  }
          if (( endx- centerx ) < 0.0)
		  {
			  end_angle = 180.0 + end_angle;
		  }
	  }
	  else
	  {
		  if (( endy- centery) < 0.0) 
		  {
			  end_angle = 180+ end_angle;
		  }
	  }
    
	  begin_angle = atan( ( beginy - centery) / (beginx -centerx)) * (180.0/PI);
	  if (begin_angle < 0.0)
	  {
		  if (( beginy- centery ) < 0.0)
		  {
			  begin_angle = 360.0 + begin_angle;
		  }
          if (( beginx- centerx ) < 0.0)
		  {
			  begin_angle = 180.0 + begin_angle;
		  }
	  }
	  else
	  {
		  if (( beginy- centery) < 0.0) 
		  {
			  begin_angle = 180+ begin_angle;
		  }
	  }

	  if (end_angle > begin_angle)
	  {
		  begin_angle = begin_angle + 360.0;
	  }

	  fprintf(outfile,"%f %f %f %f %f \n", centerx, centery, radius, end_angle,begin_angle);
	  fprintf(outfile,"%f\n",width);
	  fprintf(outfile,"1\n");
	  fprintf(outfile,"ArcOut\n");

      approxarc_extents( beginx, beginy, endx, endy, centerx, centery, radius, width );

	 //do_flash_arc_ps( beginx, beginy, endx, endy, centerx,centery, width);   // just flash the line
	}
    else   // just put into the poly_list for now
	{
      width= apt_list[current_apt_value].diam * power_factor;

	  if ( polycount < MAXPOLY)
	  {
       if (debug)
		{
		printf("Adding a polyarc = %f %f %f %f %f %f \n",beginx, beginy, endx,endy,
			           centerx, centery);
	   }
		poly_list[polycount].islinear_int=FALSE;
		poly_list[polycount].iscircle_int=FALSE;
		poly_list[polycount].isccwcircle_int=TRUE;  // G03
		poly_list[polycount].xval=endx;
		poly_list[polycount].yval=endy;
		poly_list[polycount].xprev=beginx;
		poly_list[polycount].yprev=beginy;
		poly_list[polycount].ival=centerx;
		poly_list[polycount].jval=centery;
		poly_list[polycount].width=width;
	    poly_list[polycount].radius= sqrt(( beginx - centerx) * (beginx-centerx) +
			                              ( beginy - centery) * (beginy-centery));
		poly_list[polycount].radius=poly_list[polycount].radius;   // was /10.0?
		polycount +=1;
	  }
	}
  }
  else
  {
	  printf("End point for circle interpolation ccw not compatible with radius and begin point\n");
	  printf("Begin x,y = %f %f \n", beginx, beginy );
	  printf("End   x,y = %f %f \n", endx, endy );
	  printf("Center x,y = %f %f \n", centerx, centery );
      printf("End dist = %f \n",end_dist);
	  printf("Radius = %f \n", radius );
  }

}  //end draw_arc_svg_ccci

void draw_arc_svg_cci( double radius, double beginx, double beginy, double endx, double endy, 
			   double centerx, double centery, char *layerstr,
			     double scalefactor)
{
double width;
int debug;
double end_dist;
double end_dist_sq;
double begin_angle;
double end_angle;

   debug=0;
  //debug=gdebug;

  end_dist_sq = (( endx - centerx) * (endx - centerx)) + ((endy - centery) * (endy - centery));
  end_dist = sqrt( end_dist_sq);

  if ( ((.95 * radius) < end_dist ) && ((1.05 * radius ) > end_dist))
  {
    
    if (polymode == FALSE)   // not in polygon mode
	{
      width= apt_list[current_apt_value].diam * power_factor;
	  end_angle = atan( ( endy - centery) / (endx - centerx ) ) * (180.0/PI);
	  if (end_angle < 0.0)
	  {
		  if (( endy- centery ) < 0.0)
		  {
			  end_angle = 360.0 + end_angle;
		  }
          if (( endx- centerx ) < 0.0)
		  {
			  end_angle = 180.0 + end_angle;
		  }
	  }
	  else
	  {
		  if (( endy- centery) < 0.0) 
		  {
			  end_angle = 180+ end_angle;
		  }
	  }
    
	  begin_angle = atan( ( beginy - centery) / (beginx -centerx)) * (180.0/PI);
	  if (begin_angle < 0.0)
	  {
		  if (( beginy- centery ) < 0.0)
		  {
			  begin_angle = 360.0 + begin_angle;
		  }
          if (( beginx- centerx ) < 0.0)
		  {
			  begin_angle = 180.0 + begin_angle;
		  }
	  }
	  else
	  {
		  if (( beginy- centery) < 0.0) 
		  {
			  begin_angle = 180+ begin_angle;
		  }
	  }

	  if (end_angle > begin_angle)
	  {
		  begin_angle = begin_angle + 360.0;
	  }

	  fprintf(outfile,"%f %f %f %f %f \n", centerx, centery, radius, end_angle,begin_angle);
	  fprintf(outfile,"%f\n",width);
	  fprintf(outfile,"1\n");
	  fprintf(outfile,"ArcOut\n");

      approxarc_extents( beginx, beginy, endx, endy, centerx, centery, radius, width );

	 //do_flash_arc_ps( beginx, beginy, endx, endy, centerx,centery, width);   // just flash the line
	}
    else   // just put into the poly_list for now
	{
      width= apt_list[current_apt_value].diam * power_factor;

	  if ( polycount < MAXPOLY)
	  {
       if (debug)
		{
		printf("Adding a polyarc = %f %f %f %f %f %f \n",beginx, beginy, endx,endy,
			           centerx, centery);
	   }
		poly_list[polycount].islinear_int=FALSE;
		poly_list[polycount].iscircle_int=TRUE;           // G02
		poly_list[polycount].isccwcircle_int=FALSE;
		poly_list[polycount].xval=endx;
		poly_list[polycount].yval=endy;
		poly_list[polycount].xprev=beginx;
		poly_list[polycount].yprev=beginy;
		poly_list[polycount].ival=centerx;
		poly_list[polycount].jval=centery;
		poly_list[polycount].width=width;
	    poly_list[polycount].radius= sqrt(( beginx - centerx) * (beginx-centerx) +
			                              ( beginy - centery) * (beginy-centery));
		poly_list[polycount].radius=poly_list[polycount].radius;   // was /10.0?
		polycount +=1;
	  }
	}
  }
  else
  {
	  printf("End point for circle interpolation not compatible with radius and begin point\n");
	  printf("Begin x,y = %f %f \n", beginx, beginy );
	  printf("End   x,y = %f %f \n", endx, endy );
	  printf("Center x,y = %f %f \n", centerx, centery );
      printf("End dist = %f \n",end_dist);
	  printf("Radius = %f \n", radius );
  }

}  //end draw_arc_svg_cci


// find the dot product of two vectors, v0 = x0,y0 to x1,y1
//                                      v1 = x2,y2 to x3,y3
//            dot product = ( v0 . v1) / |v0| |v1|
//
double dot_prod( double x0, double y0, double x1, double y1,
			   double x2, double y2, double x3, double y3 )
{
double v0x;
double v0y;
double v1x;
double v1y;   
double v0norm;
double v1norm;
double v0dotv1;

     //  printf("x0 y0 x1 y1 x2 y2 x3 y3 = %f %f %f %f %f %f %f %f \n",
	//	   x0,y0,x1,y1,x2,y2,x3,y3);

       v0x = x1-x0;
	   v0y = y1-y0;
       v0norm = (v0x * v0x) + (v0y * v0y);
	   v0norm = sqrt(v0norm);

	   v1x = x3-x2;
	   v1y = y3-y2;
       v1norm = (v1x * v1x) + (v1y * v1y);
	   // printf("v1x v1y = %f %f \n", v1x, v1y);

	   v1norm = sqrt(v1norm);

	   v0dotv1 = v0x * v1x + v0y * v1y;

	   // printf("v0norm v1norm = %f %f \n",v0norm, v1norm);

	   v0dotv1 = v0dotv1 / ( v0norm * v1norm) ;
	  // printf("dot_prod = %f \n", v0dotv1);

	   return(v0dotv1);
                
}



void  do_xyline( char *linein) // get X, Y, D
{
char xstr[40];
char ystr[40];
char dstr[10];
	  
double xval;
double yval;
int xfound;
int yfound;
int kk;
int dval;
int cindex;
int debug;


    
    debug = 0;

	if (debug) { printf("In do_xyline, linein = %s \n", linein); }

    xfound=FALSE;
    yfound=FALSE;
    xstr[0]='\0';
    ystr[0]='\0';
    dstr[0]='\0';
	  
	cindex=0;
    if ( linein[cindex] == 'X')
    {
	    xfound=TRUE;
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex] == '+' 
			                                                   || linein[cindex] == '-' )
		           && (kk < 40))
	       {
		 xstr[kk]= linein[cindex];
		kk += 1;
		 cindex+=1;
	       }
	      xstr[kk]='\0';
       }
	  
    if ( linein[cindex] == 'Y')
    {
	    yfound=TRUE;
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' ||  linein[cindex]=='+' || 
			linein[cindex]=='-')
		           && (kk < 40))
	       {
		    ystr[kk]= linein[cindex];
	   	    kk += 1;
		    cindex+=1;
	       }
	      ystr[kk]='\0';
       } 

	 

     if ( linein[cindex] == 'D')
     {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) )
		           && (kk < 40))
	       {
		     dstr[kk]= linein[cindex];
		     kk += 1;
		     cindex+=1;
	       }
	      dstr[kk]='\0';
		  dval=atoi(dstr);
     }
     else   // no dval
	 {

      dval = currentdval;    // a dval, not an aperture
	 }


       xval=atof(xstr);
       yval=atof(ystr);
       
       // dval=atoi(dstr);

	   if (debug){ printf("In do_xyline, xstr=%s ystr=%s, dstr=%s \n",xstr,ystr,dstr); }

       if (dval == 1)     // light on
       {
	    if (xfound== FALSE)
		{
	     newx = currentx;
	     if (yfound==TRUE)
		 {
	      newy=  yval;
		 }
	     else               // neither found
		 {
	      newy=currenty;
		 }
		}
	    else     // xfound
		{
	     newx= xval;
	     if ( yfound==TRUE)
		 {
	      newy=yval;
		 }
	     else
		 { 
	      newy=currenty;
		 }
        }    

	  
	  draw_line(currentx,currenty,newx,newy,currentlayer,width);

	  UpdateLineExtents( currentx, currenty, newx, newy, width);

	  currentx=newx;
	  currenty=newy;
	   
	   }  // end dval == 1

	   
    if (dval == 2)   // light off, just a move
     {
	  //if (line_point_count > 0 )
	  //{
	//	  do_line_end_ps();
	  //}
	  line_point_count = 0;

	  if (xfound== FALSE)
	  {
	   newx = currentx;
	   if (yfound==TRUE)
	   {
	     newy=  yval;
	   }
	   else
	   {
	     newy=currenty;
	   }
	  }
	 else     // xfound 
	 {
	   newx= xval;
	   if ( yfound==TRUE)
	   {
	     newy=yval;
	   }
	   else
	   { 
	     newy=currenty;
	   }
	 }  // end else xfound

      currentx=newx;  // just move
      currenty=newy;	  
	} // end dval==2

   if (dval == 3)   // do a flash
     {

     // if (line_point_count > 0 )
	 // {
	//	  do_line_end_ps();
	 // }
	  line_point_count = 0;

	  if (xfound== FALSE)
	  {
	   newx = currentx;
	   if (yfound==TRUE)  // x not found , buy y is
	   {
	     newy=  yval;
		 newx= currentx;
	   }
	   else     // neither one, shouldn't happen
	   {
	     newy=currenty;
		 newx=currentx;
	   }
	  }
	 else     // xfound 
	 {
	   newx= xval;
	   if ( yfound==TRUE) // both x and y found
	   {
	     newy=yval;
		 newx=xval;
	   }
	   else      // just x
	   { 
	     newy=currenty;
		 newx=xval;
	   }
	 }  // end else xfound

	 if (debug)
	 {
	  printf("About to flash, current_apt_value = %d newx,newy = %f %f\n",current_apt_value,
		  newx,newy);
	 }

     do_flash( newx, newy, current_apt_value, currentlayer);
	 UpdatePointExtents( newx, newy);

	 currentx=newx;
	 currenty=newy;

	} // end dval==3

    currentdval = dval;

} // do_xy_line

// xy_line for incremental mode

void  do_xyline_increm( char *linein) // get X, Y, D
{
char xstr[40];
char ystr[40];
char dstr[10];
	  
double xval;
double yval;
int xfound;
int yfound;
int kk;
int dval;
int cindex;
int debug;


    debug = 0;

	if (debug) { printf("In do_xyline, linein = %s \n", linein); }

    xfound=FALSE;
    yfound=FALSE;
    xstr[0]='\0';
    ystr[0]='\0';
    dstr[0]='\0';
	  
	cindex=0;
    if ( linein[cindex] == 'X')
    {
	    xfound=TRUE;
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex] == '-' 
			                                                   || linein[cindex] == '+')
		           && (kk < 40))
	       {
		 xstr[kk]= linein[cindex];
		kk += 1;
		 cindex+=1;
	       }
	      xstr[kk]='\0';
       }
	  
    if ( linein[cindex] == 'Y')
    {
	    yfound=TRUE;
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' ||  linein[cindex]=='-'
			                                                   ||  linein[cindex]=='+')
		           && (kk < 40))
	       {
		 ystr[kk]= linein[cindex];
		kk += 1;
		 cindex+=1;
	       }
	      ystr[kk]='\0';
       } 

     if ( linein[cindex] == 'D')
     {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) )
		           && (kk < 40))
	       {
		 dstr[kk]= linein[cindex];
		kk += 1;
		 cindex+=1;
	       }
	      dstr[kk]='\0';
       }
       xval=atof(xstr);
       yval=atof(ystr);
       
       dval=atoi(dstr);

	   if (debug){ printf("In do_xyline_increm, xstr=%s ystr=%s, dstr=%s \n",xstr,ystr,dstr); }
       if (dval == 1)     // light on
       {
	    if (xfound== FALSE)
		{
	     newx = currentx;
	     if (yfound==TRUE)
		 {
	      newy=  currenty + yval;
		 }
	     else               // neither found
		 {
	      newy=currenty;
		 }
		}
	   else     // xfound
	   {
	    newx= xval+ currentx;
	    if ( yfound==TRUE)
		{
	     newy=yval+ currenty;
		}
	    else
		{ 
	     newy=currenty;
		}
       }    
	  draw_line(currentx,currenty,newx,newy,currentlayer,width);
	  currentx=newx;
	  currenty=newy;
     }	   
	   
    if (dval == 2)   // light off, just a move
     {
	  if (xfound== FALSE)
	  {
	   newx = currentx;
	   if (yfound==TRUE)
	   {
	     newy=  yval+currenty;
	   }
	   else
	   {
	     newy=currenty;
	   }
	  }
	 else     // xfound 
	 {
	   newx= xval + currentx;
	   if ( yfound==TRUE)
	   {
	     newy=yval+currenty;
	   }
	   else
	   { 
	     newy=currenty;
	   }
	 }  // end else xfound

      currentx=newx;  // just move
      currenty=newy;	  
	} // end dval==2

   if (dval == 3)   // do a flash
     {
	  if (xfound== FALSE)
	  {
	   newx = currentx;
	   if (yfound==TRUE)  // x not found , but y is
	   {
	     newy=  yval+currenty;
		 newx= currentx;
	   }
	   else     // neither one, shouldn't happen
	   {
	     newy=currenty;
		 newx=currentx;
	   }
	  }
	 else     // xfound 
	 {
	   newx= xval+currentx;
	   if ( yfound==TRUE) // both x and y found
	   {
	     newy=yval+currenty;
		 newx=xval;
	   }
	   else      // just x
	   { 
	     newy=currenty;
		 newx=xval;
	   }
	 }  // end else xfound

	 if (debug)
	 {
	  printf("About to flash, current_apt_value = %d newx,newy = %f %f\n",current_apt_value,
		  newx,newy);
	 }

     do_flash( newx, newy, current_apt_value, currentlayer);
	 currentx=newx;
	 currenty=newy;

	} // end dval==3

} // do_xy_line_increm
 
//
//  Approximate an arc by a series of points along the arc that can
//         be connected for polygon fill
//
void approx_arc( double beginx, double beginy, double endx, double endy, double centerx,
				 double centery, double radius)
{
double theta;   // angle between
double xdiff1;
double xdiff2;
double ydiff1;
double ydiff2;
double begintheta;
int steps;
double step_array[10][2];
double inctheta;
double steptheta;
int ii;
double xinc;
double yinc;

 steps=10;
 xdiff1=(beginx - centerx);
 xdiff2=(endx-centerx);
 ydiff1=(beginy - centery);
 ydiff2=(endy-centery);

 theta = acos( ((xdiff1 * xdiff2 ) + (ydiff1 * ydiff2))/ (radius * radius));

 inctheta= theta / (double) steps;

 begintheta = asin( xdiff1 / radius);

 for(ii=0; ii < steps; ii += 1)
 {
   steptheta= begintheta + (ii * inctheta);

   xinc = radius * cos( steptheta);
   yinc = radius * sin( steptheta);

   step_array[ii][0] = centerx + xinc;
   step_array[ii][1] = centery + yinc;
 }

}   // end 

//
//  Approximate an arc by a series of points along the arc that can
//         be connected for polygon fill
//
void approxarc_extents( double beginx,
						double beginy,
						double endx,
						double endy, 
						double centerx,
				        double centery,
						double radius, 
						double arcwidth)
{
double theta;   
double xdiff1;
double xdiff2;
double ydiff1;
double ydiff2;
double begintheta;
int steps;
double step_array[40][2];
double inctheta;
double steptheta;
int ii;
double xinc;
double yinc;

 steps=30;                        // was  50
 xdiff1=(beginx - centerx);
 xdiff2=(endx-centerx);
 ydiff1=(beginy - centery);
 ydiff2=(endy-centery);

 theta = acos( ((xdiff1 * xdiff2 ) + (ydiff1 * ydiff2))/ (radius * radius));

 inctheta= theta / (double) steps;

 begintheta = asin( xdiff1 / radius);

 for(ii=0; ii < steps; ii += 1)
 {
   steptheta= begintheta + (ii * inctheta);

   xinc = radius * cos( steptheta);
   yinc = radius * sin( steptheta);

   step_array[ii][0] = centerx + xinc;
   step_array[ii][1] = centery + yinc;

   if (ii > 0 )
   {
	   UpdateLineExtents(step_array[ii-1][0], step_array[ii-1][1],
		                 step_array[ii][0],step_array[ii][1], arcwidth );
   }
 }

}   // end 

void  do_g_li_move( char *linein, int cindex, double scalein ) // get X, Y, D
{
char xstr[40];
char ystr[40];
char dstr[10];
	  
double xval;
double yval;
int xfound;
int yfound;
int kk;
int dval;
int debug;

    debug=0;

	if (debug) { printf("In do_g_li_move, linein = %s \n", linein); }

	  
    xfound=FALSE;
    yfound=FALSE;
    xstr[0]='\0';
    ystr[0]='\0';
    dstr[0]='\0';
	  
    if ( linein[cindex] == 'X')
    {
	    xfound=TRUE;
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex]=='-'
			                                                   ||  linein[cindex]=='+')
		           && (kk < 40))
	       {
		    xstr[kk]= linein[cindex];
		    kk += 1;
		    cindex+=1;
	       }
	      xstr[kk]='\0';
       }
	  
    if ( linein[cindex] == 'Y')
    {
	    yfound=TRUE;
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex]=='-'
			                                                   || linein[cindex]=='+')
		           && (kk < 40))
	     {
		  ystr[kk]= linein[cindex];
		  kk += 1;
		   cindex+=1;
	     }
	     ystr[kk]='\0';
       } 

     if ( linein[cindex] == 'D')
     {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) )
		           && (kk < 40))
	       {
		    dstr[kk]= linein[cindex];
		    kk += 1;
	     	 cindex+=1;
	       }
	      dstr[kk]='\0';
       }


     xval=atof(xstr);
     yval=atof(ystr);
       
     dval=atoi(dstr);
     if (dval == 1)
      {
	   if (xfound== FALSE)
	   {
	    newx = currentx;
	    if (yfound==TRUE)
		{
	     newy=  yval;
		}
	    else
		{
	     newy=currenty;
		}
	   }
	  else     // xfound
	  {
	   newx= xval;
	   if ( yfound==TRUE)
	   {
	     newy=yval;
	   }
	   else
	   { 
	     newy=currenty;
	   }
      }
	  draw_line(currentx,currenty,newx,newy,currentlayer,width);
	  currentx=newx;
	  currenty=newy;
     }	   
	 
     if (dval == 2)  // D02
      {
	
 	   if (xfound== FALSE)
	   {
	   newx = currentx;
	    if (yfound==TRUE)
		{
	     newy=  yval;
		}
	    else
		{
	     newy=currenty;
		}
	   }
	  else     // xfound
	  {
	   newx= xval;
	   if ( yfound==TRUE)
	   {
	     newy=yval;
	   }
	   else
	   { 
	     newy=currenty;
	   }
      }
	 
      currentx=newx;
      currenty=newy;	  
     }
       
 } // do_g_li_move

 

 // counter clockwise circular interpolation
 //

void do_g_ccci_move( char *linein, int cindex)
{ 
	char xstr[40];
    char ystr[40];
    char istr[40];
    char jstr[40];
    char dstr[10];
	  
    double xval;
    double yval;
    double ival;
    double jval;
    double radius;
    double centerx;
	double centery;

	int dval;
	  
    int kk;
	int debug;
	int xfound;
    int yfound;

	debug = 0;
	


	if (debug) { printf("In do g_ccci_move  linein char = %c \n",linein[cindex] ); } 

    xstr[0]='\0';
    ystr[0]='\0';
    istr[0]='\0';
    jstr[0]='\0';
    dstr[0]='\0';
	  
	xfound=FALSE;

    if ( linein[cindex] == 'X')
    {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex]=='-'
			                                                   || linein[cindex]=='+')
		           && (kk < 40))
	       {
		    xstr[kk]= linein[cindex];
		    kk += 1;
		    cindex+=1;
	       }
	      xstr[kk]='\0';
		xfound=TRUE;

       }
	 
	yfound=FALSE;

    if ( linein[cindex] == 'Y')
    {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex]=='-'
			                                                   || linein[cindex]=='+')
		           && (kk < 40))
	       {
		    ystr[kk]= linein[cindex];
		    kk += 1;
		    cindex+=1;
	       }
	      ystr[kk]='\0';
		  yfound=TRUE;
       } 

    if ( linein[cindex] == 'I')
     {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex]=='-'
			                                                   || linein[cindex]=='+')
		           && (kk < 40))
	       {
		    istr[kk]= linein[cindex];
		    kk += 1;
		    cindex+=1;
	       }
	      istr[kk]='\0';
       }
    if ( linein[cindex] == 'J')
     {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex]=='-'
			                                                   || linein[cindex]=='+')
		           && (kk < 40))
	       {
		    jstr[kk]= linein[cindex];
		    kk += 1;
		    cindex+=1;
	       }
	      jstr[kk]='\0';
       }
     if ( linein[cindex] == 'D')
     {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) )
		           && (kk < 40))
	       {
		    dstr[kk]= linein[cindex];
		    kk += 1;
		     cindex+=1;
	       }
	      dstr[kk]='\0';
       }
	   if (xfound ==TRUE)
	   {
          xval=atof(xstr);
	   }
	   else
	   {
		   xval = currentx;
	   }
	   if (yfound ==TRUE)
	   {
         yval=atof(ystr);
	   }
	   else
	   {
		   yval = currenty;
	   }
       ival=atof(istr);
       jval=atof(jstr);
       dval=atoi(dstr);
 
	 
	   if ( debug ) { printf(" xval = %f yval = %f ival = %f jval = %f dval = %d \n",
		   xval,yval,ival,jval,dval); }

	   if (dval == 1)   // actually draw an arc
	   {

	
		radius=(ival*ival) + (jval * jval);
		radius=sqrt(radius);
	 //	printf("ccci I = %f J = %f radius = %f \n",ival, jval, radius);

		centerx = currentx + ival;
		centery = currenty + jval;  // may be minus

		if (absolute_mode )
		{
		// draw_arc( currentx,currenty,xval,yval,centerx,centery,currentlayer,width);
		 draw_arc_svg_ccci(radius, currentx,currenty,xval,yval,centerx,centery,currentlayer,width);
		 currentx=xval;
		 currenty=yval;
		}

        if (incremental_mode )
		{
		//draw_arc(currentx,currenty,xval+currentx,yval+currenty
			   //       ,centerx,centery,currentlayer,width);
		 draw_arc_svg_ccci(radius, currentx,currenty,xval,yval,centerx,centery,currentlayer,width);
		 currentx= currentx+xval;
		 currenty= currenty+yval;
		}
	   }
	  if (dval == 2)   // just move, no arc draw
	   {

		radius=(ival*ival) + (jval * jval);
		radius=sqrt(radius);
		centerx = currentx + ival;
		centery = currenty + jval;  // may be minus

		if (absolute_mode )
		{
		 currentx=xval;
		 currenty=yval;
		}

        if (incremental_mode )
		{
		 currentx= currentx+xval;
		 currenty= currenty+yval;
		}
	   }
}

// do a clock wise move
//
void  do_g_cci_move( char *linein, int cindex) // get X, Y, I, J, D
  {
    char xstr[40];
    char ystr[40];
    char istr[40];
    char jstr[40];
    char dstr[10];
	  
    double xval;
    double yval;
    double ival;
    double jval;
    double radius;
    double centerx;
	double centery;

	int dval;
	  
    int kk;
	int debug;
	int xfound;
    int yfound;

	debug = 0;

	if (debug) { printf("In do g_cci_move \n"); } 

    xstr[0]='\0';
    ystr[0]='\0';
    istr[0]='\0';
    jstr[0]='\0';
    dstr[0]='\0';
	  
	xfound=FALSE;

    if ( linein[cindex] == 'X')
    {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex]=='-'
			                                                   || linein[cindex]=='+')
		           && (kk < 40))
	       {
		    xstr[kk]= linein[cindex];
		    kk += 1;
		    cindex+=1;
	       }
	      xstr[kk]='\0';
		  xfound=TRUE;

       }
	yfound=FALSE;
	
    if ( linein[cindex] == 'Y')
    {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex]=='-'
			                                                   || linein[cindex]=='+')
		           && (kk < 40))
	       {
		 ystr[kk]= linein[cindex];
		kk += 1;
		 cindex+=1;
	       }
	      ystr[kk]='\0';
		yfound=TRUE;

       } 
    if ( linein[cindex] == 'I')
     {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex]=='-'
			                                                   || linein[cindex]=='+')
		           && (kk < 40))
	       {
		 istr[kk]= linein[cindex];
		kk += 1;
		 cindex+=1;
	       }
	      istr[kk]='\0';
       }
    if ( linein[cindex] == 'J')
     {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) || linein[cindex]=='.' || linein[cindex]=='-'
			                                                   || linein[cindex]=='+')
		           && (kk < 40))
	       {
		 jstr[kk]= linein[cindex];
		kk += 1;
		 cindex+=1;
	       }
	      jstr[kk]='\0';
       }
     if ( linein[cindex] == 'D')
     {
	    cindex += 1;
	    kk=0;
	    while( (isdigit(linein[cindex]) )
		           && (kk < 40))
	       {
		    dstr[kk]= linein[cindex];
		    kk += 1;
		     cindex+=1;
	       }
	      dstr[kk]='\0';
       }

       if (xfound ==TRUE)
	   {
          xval=atof(xstr);
	   }
	   else
	   {
		   xval = currentx;
	   }
       
	   if (yfound ==TRUE)
	   {
         yval=atof(ystr);
	   }
	   else
	   {
		   yval=currenty;
	   }
       ival=atof(istr);
       jval=atof(jstr);
       dval=atoi(dstr);
 
	   if ( debug ) { printf(" xval = %f yval = %f ival = %f jval = %f dval = %d \n",
		   xval,yval,ival,jval,dval); }

	   if (dval == 1)   // actually draw an arc
	   {

		radius=(ival*ival) + (jval * jval);
		radius=sqrt(radius);

       // printf("cci, I = %f J = %f radius = %f \n",ival, jval, radius);

		centerx = currentx + ival;
		centery = currenty + jval;  // may be minus

		if (absolute_mode )         //draw arc cci?
		{
		// draw_arc(currentx,currenty,xval,yval,centerx,centery,currentlayer,width);
         draw_arc_svg_cci(radius, currentx,currenty,xval,yval,centerx,centery,
			                                currentlayer,width);
		 currentx=xval;
		 currenty=yval;
		}

        if (incremental_mode )            //draw arc cci?
		{
	//	draw_arc( currentx,currenty,xval+currentx,yval+currenty
			      //    ,centerx,centery,currentlayer,width);
		 draw_arc_svg_cci(radius, currentx,currenty,xval,yval,centerx,centery,
			                                currentlayer,width);
		 currentx= currentx+xval;
		 currenty= currenty+yval;
		}
	   }
	  if (dval == 2)   // just move, no arc draw
	   {

		radius=(ival*ival) + (jval * jval);
		radius=sqrt(radius);
		centerx = currentx + ival;
		centery = currenty + jval;  // may be minus

		if (absolute_mode )
		{
		 currentx=xval;
		 currenty=yval;
		}

        if (incremental_mode )
		{
		 currentx= currentx+xval;
		 currenty= currenty+yval;
		}
	   }
	   



  } // do_g_cci_move

void do_g_move()
{

}

// filter out the list of polygon x,y points to eliminate duplicate points
//      and points that are collinear
//

int filter_poly(  int num_points_in)
{
int l,k;
int pointcnt;
int lastcollinear;




  poly_tpoints[0][0] = poly_points[0][0];
  poly_tpoints[0][1] = poly_points[0][1];
  l=1;
  for( k=1; k < num_points_in ; k += 1)
   {
	  // printf("Gerb X%0.0fY%0.0fD01*\n",poly_points[k][0],poly_points[k][1] );
	  if (( poly_points[k-1][0] != poly_points[k][0]) || 
		  ( poly_points[k-1][1] != poly_points[k][1]) )
	  {
		  poly_tpoints[l][0] = poly_points[k][0];
		  poly_tpoints[l][1] = poly_points[k][1];
		  l+=1;
	  }
      
   }
 
  pointcnt=l;


   
  lastcollinear=FALSE;

  poly_points[0][0] = poly_tpoints[0][0];
  poly_points[0][1] = poly_tpoints[0][1];

  poly_points[1][0] = poly_tpoints[1][0];
  poly_points[1][1] = poly_tpoints[1][1];

  l=2;
  for( k=2; k < pointcnt; k += 1)
    {
	  
      if (!points_3_collinear( poly_tpoints[k-2][0], poly_tpoints[k-2][1],
			                      poly_tpoints[k-1][0], poly_tpoints[k-1][1],
								  poly_tpoints[k][0],poly_tpoints[k][1]) )      // not collinear
	  {
			
	    if (lastcollinear == FALSE)
		{
	      poly_points[l][0]=poly_tpoints[k][0];
		  poly_points[l][1]=poly_tpoints[k][1];
		  l+=1;
		}
		else
		{
		 lastcollinear = FALSE;
                 
		 poly_points[l][0]=poly_tpoints[k-1][0];
		 poly_points[l][1]=poly_tpoints[k-1][1];

         l+=1;
               
	     poly_points[l][0]=poly_tpoints[k][0];
		 poly_points[l][1]=poly_tpoints[k][1];

 
		 l+=1;
		}
	  }
	else    // collinear, do not add to poly_points
	{
			 lastcollinear=TRUE;
	}


  }  // end for loop

  return(l);

} // end

void do_g_polyfill()
{

	polymode=TRUE;

}
// put out a filled polygon
//
//         Use ARCPOINTS to specify how many points along arc
//
void do_g_polyfilloff()
{
int ii;
int debug;
double arccenterx;
double arccentery;
double theta1;
double theta2;
double thetadiff;
double thetainc;
double newx;
double newy;
double newtheta;
double radius;
int jj;
int pointcnt;
char quotchar;
int outcnt;      // count of points after filtering
int quietop;
FILE *polyfile;
int k;

     quietop=1;

     debug=0;

   // debug = gdebug;

	pointcnt=0;

	quotchar = '"';

	if (debug) { printf("In do_g_polyfilloff, polycount= %d \n",polycount); }

	//fprintf(outfile,"<polygon fill=%c%s%c stroke=%cblue%c stroke-width=%c10%c points=%c \n",
	//	quotchar,rgbstr,quotchar,quotchar,quotchar,quotchar,quotchar,quotchar);

	for(ii=0; ii < polycount; ii += 1)  // put out the polygon
	{

      if (poly_list[ii].islinear_int )    // linear interpolation, G01
	  {
		 // printf("linear_int %0.0f,%0.0f %0.0f,%0.0f ",
		//	  poly_list[ii].xprev, poly_list[ii].yprev,poly_list[ii].xval, poly_list[ii].yval);
	  

            //fprintf(outfile," %0.0f %0.0f \n",
			// poly_list[ii].xval, poly_list[ii].yval);
		     poly_points[pointcnt][0]=poly_list[ii].xval;
			 poly_points[pointcnt][1]=poly_list[ii].yval;
			
			UpdatePointExtents(poly_list[ii].xval, poly_list[ii].yval);
		     pointcnt += 1;


	  }

	  if (poly_list[ii].iscircle_int )    // circular interpolation, G02
	  {
		//printf("doint a poly, x,y= %f %f, xprev,yprev = %f %f ival, jval = %f %f \n",
		//	 poly_list[ii].xval,poly_list[ii].yval, poly_list[ii].xprev, poly_list[ii].yprev,
		//	 poly_list[ii].ival,poly_list[ii].jval);
	    arccenterx =  poly_list[ii].ival;
		arccentery =  poly_list[ii].jval;

		radius = poly_list[ii].radius;

		if ( arccenterx != poly_list[ii].xval) 
		{
	 	   theta2 = atan( (poly_list[ii].yval - arccentery) /  (poly_list[ii].xval- arccenterx) );
		}
		else      // no change in X,
		{
			if ( arccentery > poly_list[ii].yval)
			{ 
			theta2 = -PI/2.0;
			}
	  	    else
		   { 
			theta2 = PI/2.0;
			}
		}
		if ( arccenterx != poly_list[ii].xprev) 
		{
	 	   theta1 = atan( (poly_list[ii].yprev - arccentery) / (poly_list[ii].xprev- arccenterx));
		}
		else   // no change in x
		{
			if ( arccentery > poly_list[ii].yprev)
			{ 
			theta1 =  -PI/2.0;
			}
		    else
			{ 
			theta1 =  PI/2.0;
			}
		}

	   if (theta1 < 0 )  // in quadrant 2 or 4
		{
			if (( poly_list[ii].xprev - arccenterx ) >= 0 )  // quad 4, or -PI/2.0
			{
			  theta1 = 2*PI + theta1;
			}
			else   // quad 2
			{
				
				 theta1 = PI + theta1;
			}
		}
		else       // quadrant 1 or 3 
		{
		   if ( theta1 != 0 )             // strickly positive 
		   {
			  if (( poly_list[ii].xprev - arccenterx ) <  0 )
			  {

			  theta1 = PI + theta1;
			  }
		   }	
		   else  // theta1 == 0
			{
              if (poly_list[ii].xprev < arccenterx )   // PI
			  {
				  theta1 = PI;
			  }
			}
		}
				

	   if (theta2 < 0 )  // in quadrant 2 or 4
		{
			if (( poly_list[ii].xval - arccenterx ) >= 0 )  // quad 4 or -PI/2.0
			{
			  theta2 = 2*PI + theta2;
			}
			else
			{
				
				 theta2 = PI + theta2;
				
			}
		}
		else       // quadrant 1 or 3 
		{
		  if (theta2 != 0 )
		  {
			if (( poly_list[ii].xval - arccenterx ) <  0 )
			{

			  theta2 = PI + theta2;
			}
		  }
		  else  // theta2 == 0
		  {
              if (poly_list[ii].xval < arccenterx )   // PI
			  {
				  theta2 = PI;
			  }
		  }
		}

	
		
	    if (debug) { printf(" cenx, ceny = %f %f radius = %f theta1 = %f theta2=%f new = %f %f prev=%f %f\n", 
			arccenterx, arccentery, radius, theta1, theta2, poly_list[ii].xval, poly_list[ii].yval,
			                        poly_list[ii].xprev,
			                         poly_list[ii].yprev); }
       

		if (theta1 > theta2 )           // starting angle larger than ending
		{
			thetadiff=theta1 - theta2;
			thetainc = ( thetadiff / ARCPOINTS );
			newtheta = theta1 - thetainc;
			for ( jj=1; jj < ARCPOINTS ; jj += 1)
			{
              newx = arccenterx + radius * cos(newtheta);
			  newy = arccentery + radius * sin(newtheta);
			 
			 // printf("newx,newy = %f %f %d\n", newx, newy,jj);
             // fprintf(outfile," %0.0f %0.0f \n",newx,newy);
			  poly_points[pointcnt][0]=newx;
			  poly_points[pointcnt][1]=newy;

              UpdatePointExtents(newx, newy);
		      pointcnt += 1;
		     
			  newtheta=newtheta - thetainc;
			}
		}
	   else
	   {
	     if (theta2 > theta1 )        // ending angle larger than starting
		 {
			thetadiff=(2*PI) - (theta2 - theta1);
			thetainc = ( thetadiff / ARCPOINTS);
			newtheta = theta1 - thetainc;
			for ( jj=1; jj < ARCPOINTS; jj += 1)
			{
              newx = arccenterx + radius * cos(newtheta);
			  newy = arccentery + radius * sin(newtheta);
             // printf("newx,newy = %f %f jj=%d\n", newx, newy, jj);
             // fprintf(outfile," %0.0f %0.0f \n",newx,newy);
             poly_points[pointcnt][0]=newx;
			 poly_points[pointcnt][1]=newy;


             UpdatePointExtents(newx, newy);
		     pointcnt += 1;
		     
			  newtheta=newtheta - thetainc;
			}
		}	
		else  // equal angles
		{
           // printf("Equal angles , theta1 , theta2 = %f %f \n",theta1,theta2);

			//thetadiff= 2 * theta1;
			thetadiff=2*PI;
			thetainc = ( thetadiff / ARCPOINTS);
			newtheta = theta2 - thetainc;
			for ( jj=1; jj < ARCPOINTS; jj += 1)
			{
              newx = arccenterx + radius * cos(newtheta);
			  newy = arccentery + radius * sin(newtheta);

              poly_points[pointcnt][0]=newx;
			  poly_points[pointcnt][1]=newy;

           //  fprintf(outfile," %0.0f %0.0f \n",newx,newy); 
			 UpdatePointExtents(newx, newy);
		     pointcnt += 1;
		     
			  newtheta=newtheta - thetainc;
			}
		}
	   }
	   //fprintf(outfile," %0.0f %0.0f \n",poly_list[ii].xval, poly_list[ii].yval);

       poly_points[pointcnt][0]=poly_list[ii].xval;
	   poly_points[pointcnt][1]=poly_list[ii].yval;

	   UpdatePointExtents(poly_list[ii].xval, poly_list[ii].yval);

	   pointcnt += 1;
	
	  }   // circular int

     if (poly_list[ii].isccwcircle_int )    // ccw circular interpolation, G03
	  {
		//printf("doint a poly, x,y= %f %f, xprev,yprev = %f %f ival, jval = %f %f \n",
		//	 poly_list[ii].xval,poly_list[ii].yval, poly_list[ii].xprev, poly_list[ii].yprev,
		//	 poly_list[ii].ival,poly_list[ii].jval);
	    arccenterx =  poly_list[ii].ival;
		arccentery =  poly_list[ii].jval;
		radius = poly_list[ii].radius;

	    if ( arccenterx != poly_list[ii].xval) 
		{
	 	   theta2 = atan( (poly_list[ii].yval - arccentery) /  (poly_list[ii].xval- arccenterx) );
		}
		else
		{
			if ( arccentery > poly_list[ii].yval)
			{ 
			theta2 = -PI/2.0;
			}
	  	    else
		   { 
			theta2 = PI/2.0;
			}
		}
		if ( arccenterx != poly_list[ii].xprev) 
		{
	 	   theta1 = atan( (poly_list[ii].yprev - arccentery) /  (poly_list[ii].xprev- arccenterx) );
		}
		else
		{
			if ( arccentery > poly_list[ii].yprev)
			{ 
			theta1 = -PI/2.0;
			}
		    else
			{ 
			theta1 = PI/2.0;
			}
		}

		// printf("Raw theta1, theta2 = %f %f \n", theta1, theta2);

		if (theta1 < 0 )  // in quadrant 2 or 4
		{
			if (( poly_list[ii].xprev - arccenterx ) >= 0.0 )  // quadrent 4, or -PI/2.0
			{
			  theta1 = 2*PI + theta1;
			}
			else  // quadrant 2 
			{
				
			 theta1 = PI + theta1;
				
			}
		}
		else       // quadrant 1 or 3 
		{
			if (theta1 != 0.0 )
			{
			 if (( poly_list[ii].xprev - arccenterx ) <  0 ) // quad 3 
			 {

			  theta1 = PI + theta1;
			 }
			}
			else  // theta1 == 0
			{

              if (poly_list[ii].xprev < arccenterx )   // PI
			  {
				  theta1 = PI;
			  }
			}
				  
		}
				

	   if (theta2 < 0.0 )  // in quadrant 2 or 4
		{
			if (( poly_list[ii].xval - arccenterx ) >= 0 )  // quad4 or -PI/2.0
			{
			  theta2 = 2*PI + theta2;
			}
			else     //  quad 2
			{
				
				  theta2 = PI + theta2;
			}
		}
		else       // quadrant 1 or 3, theta2 > or == zero
		{
			if (theta2 != 0.0 )
			{
			 if (( poly_list[ii].xval - arccenterx ) <  0 )
			 {

			  theta2 = PI + theta2;
			 }
			}
           else  // theta2 == 0
			{

              if (poly_list[ii].xval < arccenterx )
			  {
				  theta2 = PI;
			  }
		   }
		}
				


	/*	theta1 = acos( dot_prod( arccenterx, arccentery, 
			                     arccenterx + poly_list[ii].radius, arccentery,
								 arccenterx, arccentery,
								 poly_list[ii].xval, poly_list[ii].yval) );
		theta2 = acos( dot_prod( arccenterx, arccentery, 
			                     arccenterx + poly_list[ii].radius, arccentery,
								 arccenterx, arccentery,
								 poly_list[ii].xprev, poly_list[ii].yprev) );

  */

		
		if (debug) { printf("ccw, cenx, ceny = %f %f radius = %f theta1 = %f theta2=%f new = %f %f prev=%f %f\n", 
			arccenterx, arccentery, radius, theta1, theta2, poly_list[ii].xval, poly_list[ii].yval,
			                        poly_list[ii].xprev,
			                         poly_list[ii].yprev); }


		if (theta1 > theta2 )             // begin angle larger than end angle
			                                 // so ccw is from larger 
		{
			thetadiff=(2*PI) - (theta1 - theta2) ;
			thetainc = ( thetadiff / ARCPOINTS);
			newtheta = theta1 + thetainc;
			for ( jj=1; jj < ARCPOINTS; jj += 1)
			{
              newx = arccenterx + radius * cos(newtheta);
			  newy = arccentery + radius * sin(newtheta);
			 
			 // printf("newx,newy = %f %f %d\n", newx, newy,jj);
             // fprintf(outfile," %0.0f %0.0f \n",newx,newy);
              poly_points[pointcnt][0]=newx;
			  poly_points[pointcnt][1]=newy;

              UpdatePointExtents(newx, newy);
			  pointcnt += 1;
		     
			  newtheta=newtheta + thetainc;
			}
		}
	   else                               // begin angle is smaller
	   {
	     if (theta2 > theta1 )
		 {
			thetadiff=theta2 - theta1;
			thetainc = ( thetadiff / ARCPOINTS);
			newtheta = theta1 + thetainc;
			for ( jj=1; jj < ARCPOINTS; jj += 1)
			{
              newx = arccenterx + radius * cos(newtheta);
			  newy = arccentery + radius * sin(newtheta);
            
             //fprintf(outfile," %0.0f %0.0f \n",newx,newy);
              poly_points[pointcnt][0]=newx;
			  poly_points[pointcnt][1]=newy;


             UpdatePointExtents(newx, newy);
			 pointcnt += 1;
		     
			  newtheta=newtheta + thetainc;
			}
		}	
		else  // equal angles
		{
       
		//	printf("Equal angles ccw, theta1 , theta2 = %f %f \n",theta1,theta2);

			//thetadiff= 2 * theta1;
			thetadiff=2*PI;

			thetainc = ( thetadiff / ARCPOINTS);
			newtheta = theta2 - thetainc;
			for ( jj=1; jj < ARCPOINTS; jj += 1)
			{
              newx = arccenterx + radius * cos(newtheta);
			  newy = arccentery + radius * sin(newtheta);
        
             //fprintf(outfile," %0.0f %0.0f \n",newx,newy);
			 
			  poly_points[pointcnt][0]=newx;
			  poly_points[pointcnt][1]=newy;

              UpdatePointExtents(newx, newy);

		      pointcnt += 1;
		     
			  newtheta=newtheta - thetainc;
			}
		}
	   }

	   //fprintf(outfile," %0.0f %0.0f \n",poly_list[ii].xval, poly_list[ii].yval);

       poly_points[pointcnt][0]=poly_list[ii].xval;
	   poly_points[pointcnt][1]=poly_list[ii].yval;

	   UpdatePointExtents(poly_list[ii].xval, poly_list[ii].yval);

	   pointcnt += 1;
	
	  }   // ccw circular int
	}

	if (debug) { printf("At end of polygon, pointcnt = %d \n",pointcnt); }



	outcnt= filter_poly( pointcnt);

	if (outcnt <  10000 )
	{
       fprintf(outfile,"<polygon fill=%c%s%c stroke=%c%s%c stroke-width=%c10%c points=%c \n",
		quotchar,rgbstr,quotchar,quotchar,rgbstr,quotchar,quotchar,quotchar,quotchar);

	   for (ii=0; ii < outcnt-1; ii += 1)
	   {
		fprintf(outfile," %0.0f,%0.0f \n",poly_points[ii][0],poly_points[ii][1]);
	   }
      fprintf(outfile," %0.0f,%0.0f\n",poly_points[ii][0],poly_points[ii][1]);
	  fprintf(outfile," %c />\n",quotchar);

	}
	else
	{


	 polyfile=fopen("E.poly","w");

	 if (polyfile != NULL)
	 {
      fprintf(polyfile,"%d 2 0 0\n",outcnt-1);

      fprintf(polyfile,"1  %0.0f %0.0f \n",poly_points[0][0],poly_points[0][1]);
	  
	  for(k=2; k < outcnt; k += 1)
	  {

	    fprintf(polyfile,"%d  %0.0f %0.0f \n",k,poly_points[k][0],poly_points[k][1]);
	  }

	  fprintf(polyfile,"%d 0 0 \n",outcnt-1);
	  fprintf(polyfile,"%d %d 1 \n",1,outcnt-1,1 );

      for( k=2; k < outcnt ; k += 1)
	  {
	 
	   fprintf(polyfile,"%d  %d %d \n",k, k-1, k);
      
	  }
      fprintf(polyfile,"0 \n");
      //printf("POLY End\n");
	  fclose(polyfile);
	}
	else
	{
		printf("Unable to open the output E.poly \n");
		
	}

	if (quietop)
	{
	  system("triangle -p -Q E.poly");
	}
	else
	{
	  system("triangle -p E.poly");
	}
    
	buildtri_svg_call("E.1.node","E.1.ele",outfile, rgbstr);



	system("rm E.1.node");
	system("rm E.1.ele");
	system("rm E.1.poly");
	}


   	polycount=0;
	polymode= FALSE;
	

}



void  do_gerber( char *infilestr)
{

int endoffile;
char thisline[3000];
int gcode_val;
char gcode_str[120];
int ll;
int kk;
int debug;
char *percent_ptr;
char *percent_ptr1;
int multiline_flag;
char nextline[3000];
int mm;
int line_point_count;
char percentchar;

       percentchar='%';

       debug =0;

	   linecount = 0;

       polymode = FALSE;

       file1=fopen(infilestr,"r");
	   includefile_array[include_depth] = file1;
	   if (include_depth < 11)
	   {
	     include_depth += 1;
	   }
	   else
	   {
		   printf("Too many levels of include nesting ( > 10 ) \n");
		   exit(-1);
	   }

	   if (file1==NULL)
	   {
		   printf("In do_gerber, unable to open the input file = %s \n",infilestr);
		   exit(-1);
	   }


	   endoffile=getline(file1,thisline);

	  // printf("About to begin main loop \n");

	   while(endoffile==FALSE)
	   {
		 strncpy(param_string,thisline,200);
		 param_lines=0;
		 multiline_flag = FALSE;
	     if (thisline[0] == '%')  // start of param line
		   {
			 thisline[ strlen(thisline)-1]='\0';
			 strncpy(param_string,thisline,200);
			 mm=1; 
			
			 while(( thisline[mm] != '\0') && (thisline[mm] != '%') )  
			 {
				 mm += 1;
			 }
             if (thisline[mm] != '%' )  // line begins with % but continues onto next line
			 {
			   endoffile=getline(file1,thisline);
			   while(( strstr(thisline,"%") == NULL) &&    
				   (endoffile == FALSE) )      // add to param_string as long as no "%"
			   {
				if (strlen( thisline) > 0 )
				{
					if (thisline[strlen(thisline)-1] == '\n')
					{
				     thisline[strlen(thisline)-1]='\0';  // get rid of newline
					}
				}
				strncat(param_string,thisline,400);
				endoffile = getline(file1,thisline);

                if (param_lines < 500 )
				{
			  	 param_lines+=1;
				}
				else
				{
					printf("Number of lines in a %c .. %c parameter string exceeds 500 \n",
						percentchar,percentchar);
				    printf("Possibly a missing %c in file=%s\n",percentchar,infilestr);
					exit(-1);
				}

			   }

			   if ( strstr(thisline,"%" ) != NULL )     // has a "%"
			   {
                percent_ptr = strstr(thisline,"%");
				percent_ptr1= percent_ptr;
				percent_ptr1++;

				strncpy(nextline,percent_ptr1,120);
				*percent_ptr = '\0';
				strncat(param_string,thisline,120);
				if (strlen( nextline) > 0 )
				{
				  multiline_flag = TRUE;
				}
			   }
			 }   // handle a param string not all on one line

			 if (debug)
			 {
			 printf("param_string = %s \n",param_string);
			 }

		     do_params(param_string);   // param_string can be huge
		   }


         if (thisline[0] == 'G')
	       {
			 //if (line_point_count > 0 )
			// {
			//	 do_line_end_ps();
			// }


			 line_point_count =0;

		   gcode_str[0]=thisline[1];
		   gcode_str[1]=thisline[2];
		   gcode_str[2]='\0';
		   gcode_val=atoi(gcode_str);
		   if (gcode_val == 0)
		   {
			 do_g_move();
		   }
		  if (gcode_val == 1)
		  {
			  linear_mode=TRUE;
			 do_g_li_move(thisline, 3,1.0);
		  }
		  if (gcode_val == 2)
		  {
			 do_g_cci_move(thisline,3);       // clockwise circular interpolation
		  }
		  if (gcode_val == 3)
		  {
			 do_g_ccci_move(thisline,3);       // counter clockwise circular interpolation
		  }  
		  if (gcode_val == 4)
		  {
			// ignore, just a comment line
		  }  
		  if (gcode_val == 10)
		  { 
			 linear_mode=TRUE;
			 do_g_li_move(thisline, 3,10.0);
		  }  
		  if (gcode_val == 11)
		  {
			 do_g_li_move(thisline,3,.1);
		  }  
		  if (gcode_val == 12)
		  {
			  linear_mode=TRUE;
			 do_g_li_move(thisline,3,.01);
		  }  
		  if (gcode_val == 36)  // G36
		  {
			 do_g_polyfill();
		  }   
		  if (gcode_val == 37)  // filled polygon
		  {
			 do_g_polyfilloff();
		  }   
		  if (gcode_val == 54)   // G54
		  {
		     if ( thisline[3] == 'D')
		     {
				 // printf("D code to add to aperture = %c%c\n");
				 kk=4;
				 ll=0;
				 while((thisline[kk] != '*') && (isdigit(thisline[kk])) && (ll < 120))
				 {
			      current_apt_str[ll]=thisline[kk];
				  kk += 1;
				  ll += 1;
				 }
			      
		       	current_apt_str[ll]='\0';
			    current_apt_value=atoi(current_apt_str);
			
		     }
		  }   
		  if (gcode_val == 70 ) // inches
		  {
			inch_mode=TRUE;
			mm_mode=FALSE;
		  } 
		  if (gcode_val == 71) // mm
		  {
			  inch_mode = FALSE;
			  mm_mode=TRUE;
			
		  }   
		  if (gcode_val == 74) // Disable 360 circular interpolation
		  {
			circular_interpret_mode = FALSE;
		  }    
		  if (gcode_val == 75) // Enable 360 circular interpolation
		  {
			circular_interpret_mode = TRUE;
		  }   
		  if (gcode_val == 90) // absolute format
		  {
			absolute_mode = TRUE;
			incremental_mode = FALSE;
		  }    
		  if (gcode_val == 91) // incremental format
		  {
			incremental_mode = TRUE;
			absolute_mode =FALSE;
		  }     
		 }  // G line

	   if( thisline[0] == 'X' || thisline[0] == 'Y')
	    {
		 if ( absolute_mode)
		 {
	  	   do_xyline( thisline);
		 }
		 else
		 {
			 do_xyline_increm( thisline);
		 }
	    } 
	   if( thisline[0] == 'D')   // D01, D02,D03 or DXXX
	    {
		 if (( thisline[1] == '0') && ( thisline[2] == '1')  && (thisline[3] == '\n' )) // 
		 {
	  	   // dummy move no, action, no x,y on line
		 }
		if (( thisline[1] == '0') && ( thisline[2] == '2')  && (thisline[3] == '\n' )) // 
		 {
	  	   // dummy move no, action, no x,y on line
		 }
		if (( thisline[1] == '0') && ( thisline[2] == '3')  && (thisline[3] == '\n' )) // 
		 {
            do_flash( currentx, currenty, current_apt_value, currentlayer);
	  	    
		 }	
		if ( thisline[1] != '0') //  set current aperture? just like G54?
		 {
	         // printf("D code to add to aperture = %c%c\n");
				 kk=1;
				 ll=0;
				 while((thisline[kk] != '*') && (isdigit(thisline[kk])) && (ll < 120))
				 {
			      current_apt_str[ll]=thisline[kk];
				  kk += 1;
				  ll += 1;
				 }
			      
		       	current_apt_str[ll]='\0';
			    current_apt_value=atoi(current_apt_str);
			//	printf("D at beginning, setting apt = %d \n",current_apt_value);

	  	   
		 }
	    }
	   if ((thisline[0] == 'M') && (thisline[1]== '0'))
	   {
		   if (thisline[2]=='0')  // M00 program stop
		   {

		   }
		   if (thisline[2]=='1')  // M01 optional stop
		   {

		   }
		   if (thisline[2]=='2')  // M02 End of program
		   {

		   }
	   }
	  if (multiline_flag == FALSE)
	  {
	    endoffile=getline(file1,thisline);
	  }
	  else
	  {
		  strncpy(thisline, nextline,200);
	  }
	  linecount += 1;
	  if (debug) { printf("Next line = %s ", thisline); }
	}
	

	fclose(file1);
	include_depth -=1;

	if (include_depth > 0)
	{
		file1 = includefile_array[include_depth-1];

	}
   // fclose(outfile);

}




void do_include_file( char *paramstr, int cindex)
{
char filenamestr[200];
int ll;
int kk;

  ll =0;
  kk = cindex;
  while(( ll < 120) && (paramstr[kk] != '*' ) && (paramstr[kk] != '\0' ))
  {
	  filenamestr[ll] = paramstr[kk];
	  ll += 1;
	  kk += 1;
  }
  filenamestr[kk] = '\0';

  printf("Including file = %s \n", filenamestr);

  if (file_exists ( filenamestr) )
  {
	  do_gerber( filenamestr);
  }
  else
  {
	  printf("Unable to open the include file = %s \n",filenamestr);
  }

}  // do_include

int main(int argc, char **argv)
{ 
	include_depth=0; 
	strncpy(errfilestr,"partinfo.txt",30);
	aperture_mac_count = 0;
	absolute_mode = TRUE;
	lpc_count=0;
	lpd_count=0;
	incremental_mode = FALSE;
	circular_interpret_mode=FALSE;
    mirror_x_active = 0;
	mirror_y_active = 0;
	group_count=0;
	mm_mode=TRUE;
	inch_mode=FALSE;
	total_expr_count=0;

	strncpy(rgbstr,"red",10);

	x_power_factor = 10000;
	y_power_factor = 10000;
        power_factor=10000;

	SetExtents();   //reset the extents

	outfile=fopen("svgout","w");
	if (outfile==NULL)
	   {
		   printf("In do_gerber, unable to open the output file = %s \n","svgout");
		   exit(-1);
	   }

	do_svg_head();
	if (argc > 1)
	{
	 do_gerber(argv[1]);
	 do_svg_tail();


     errorfile=fopen(errfilestr,"a");
	 if (errorfile == NULL)
	 {
		 printf("Unable to open the errorfile for writing \n");
		 exit(-1);
	 }

      printf("Extents = %f %f %f %f \n",gerberExtents[0], gerberExtents[1],
		                              gerberExtents[2], gerberExtents[3]);

      fprintf(errorfile,"Extents = %f %f %f %f \n",gerberExtents[0], gerberExtents[1],
		                              gerberExtents[2], gerberExtents[3]); 


	  if ( ((( gerberExtents[0] + gerberExtents[2] ) / 2.0 ) != 0 )
	     ||  ((( gerberExtents[1] + gerberExtents[3] ) / 2.0) != 0 ) )
		{

		 printf("Layer %s has offset = %f %f \n", argv[1],( gerberExtents[0] + gerberExtents[2] )/2.0,
			                      ( gerberExtents[1] + gerberExtents[3])/2.0); 
		 fprintf(errorfile,"Layer %s has offset = %f %f \n",argv[1], ( gerberExtents[0] + gerberExtents[2] )/2.0,
			                      ( gerberExtents[1] + gerberExtents[3])/2.0);
	  }
	  else
	  {
		printf("Layer %s is centered \n",argv[1]);
		fprintf(errorfile,"Layer %s is centered\n",argv[1]);

	  }

	  fclose(errorfile);

	 fclose(outfile);
	}




}

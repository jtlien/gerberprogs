#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINELEN  120
char X[LINELEN];
char Y[LINELEN];
char D[LINELEN];

void getstring( char*  val, char* myval)
{
  val++;
  *myval= *val; 
  val++;
  myval++;
  while( isdigit(*val) ){
     *myval = *val ;
     val++;
     myval++;
  }
  *myval = '\0';
}


void ProcessStringOut(char thestring[], FILE *outfile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char X[LINELEN];
     char Y[LINELEN];
     char D[LINELEN];
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) ){
         getstring(placeX,X);
	 getstring(placeY,Y);
	 getstring(placeD,D);
	fprintf(outfile,"X%d Y%d \n",atoi(X),atoi(Y)  );
     }
     else if (  strchr(thestring,'X') != NULL ){
         getstring(placeX,X);
	 getstring(placeD,D);
	fprintf(outfile,"X%d Y%d \n",atoi(X), atoi(Y) );
     }
     else if (  strchr(thestring,'Y') != NULL ){
	 getstring(placeY,Y);
	 getstring(placeD,D);
	fprintf(outfile,"X%d Y%d \n",atoi(X),atoi(Y) );
     }
     else if ( strchr(thestring , 'M') == NULL){
       // fprintf(outfile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

void ProcessString(char thestring[])
{
     char* placeX;
     char* placeY;
     char* placeD; 
    
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) ){
         getstring(placeX,X);
	 getstring(placeY,Y);
	 getstring(placeD,D);
	 printf("X%d Y%d \n",atoi(X),atoi(Y)  );
     }
     else if (  strchr(thestring,'X') != NULL ){
         getstring(placeX,X);
	 getstring(placeD,D);
	 printf("X%d Y%d \n",atoi(X), atoi(Y) );
     }
     else if (  strchr(thestring,'Y') != NULL ){
	 getstring(placeY,Y);
	 getstring(placeD,D);
	 printf("X%d Y%d \n",atoi(X),atoi(Y) );
     }
     else if ( strchr(thestring , 'M') == NULL){
       // fprintf(outfile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}


void gbrxy_call(char *fname)
{
FILE *thisfile;

   char line[LINELEN];
   thisfile =  fopen( fname,"r");
   X[0]='\0';
   Y[0]='\0';

   if (thisfile != NULL){
       while( fgets(line, LINELEN, thisfile) != NULL){
          ProcessString(line);
       } 
   }
   else
   {
	   printf("Unable to open the input file = %s \n",fname);
	   exit(-1);
   }
   fclose(thisfile);

}


int main( int argc, char **argv)
{
	if (argc != 2)
	{
		printf("In gbrxy, wrong number of arguments \n");
        printf("Usage: gbrxy filename \n");
		exit(-1);
	}
	else
	{
		gbrxy_call( argv[1]);
	}

}  // end main


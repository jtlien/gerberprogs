#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

int gen_wb_ext_call_out( char *infilestr, char *outfilestr)
{
int cnt;
int endoffile;
FILE *file1;
FILE *outfile;

int number_fields;
char thisline[200];
char tstr[120];

     // FS = "!"

     file1  = fopen(infilestr, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	 }


     outfile = fopen(outfilestr, "w");

     if (outfile == NULL)
	 {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
	 }

     fprintf(outfile,"CONNECTIVITY\n");
     fprintf(outfile,"CLASS = 'ETCH'\n");
     cnt = 0;

     endoffile=getline(file1,thisline);
     number_fields=split_line_seps(thisline,"!");

     while(endoffile == FALSE)
	 {
      if(strcmp(str_array[0],"S") == 0) 
	  {
	   tstr[0] = toupper( str_array[1][0]);
	   tstr[1] = toupper( str_array[1][1]);
	   tstr[2] = 0;
       if(strcmp(tstr,"WB") == 0 )
	   {
         if( cnt > 0)
		 { fprintf(outfile, "OR\n"); }
         fprintf(outfile,"SUBCLASS = '%s'\n",str_array[1]);
         cnt++;
	   }
	  }
     endoffile=getline(file1,thisline);
     number_fields=split_line_seps(thisline,"!");

	 }

  fclose(file1);

   fprintf(outfile,"NET_NAME\n");
   fprintf(outfile,"GRAPHIC_DATA_NAME\n");
   fprintf(outfile,"GRAPHIC_DATA_10\n");
   fprintf(outfile,"GRAPHIC_DATA_1\n");
   fprintf(outfile,"GRAPHIC_DATA_2\n");
   fprintf(outfile,"GRAPHIC_DATA_3\n");
   fprintf(outfile,"GRAPHIC_DATA_4\n");

   fclose(outfile);

   return(cnt);
}

int gen_wb_ext_call( char *infilestr)
{
int cnt;
int endoffile;
FILE *file1;
int number_fields;
char thisline[200];
char tstr[120];

     // FS = "!"

     file1  = fopen(infilestr, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	 }


     printf("CONNECTIVITY\n");
     printf("CLASS = 'ETCH'\n");
     cnt = 0;

     endoffile=getline(file1,thisline);
     number_fields=split_line_seps(thisline,"!");

     while(endoffile == FALSE)
	 {
      if(strcmp(str_array[0],"S") == 0) 
	  {
	   tstr[0] = toupper( str_array[1][0]);
	   tstr[1] = toupper( str_array[1][1]);
	   tstr[2] = 0;
       if(strcmp(tstr,"WB") == 0 )
	   {
        if( cnt > 0)
		{ printf( "OR\n"); }
        printf("SUBCLASS = '%s'\n",str_array[1]);
        cnt++;
	   }
	  }
     endoffile=getline(file1,thisline);
     number_fields=split_line_seps(thisline,"!");

	 }

  fclose(file1);

   printf("NET_NAME\n");
   printf("GRAPHIC_DATA_NAME\n");
   printf("GRAPHIC_DATA_10\n");
   printf("GRAPHIC_DATA_1\n");
   printf("GRAPHIC_DATA_2\n");
   printf("GRAPHIC_DATA_3\n");
   printf("GRAPHIC_DATA_4\n");

   return(cnt);
}


int main( int argc, char **argv)
{
int retcode;

	if (argc != 2)
	{
		printf("In gen_wb_ext, wrong number of arguments \n");
		printf("Usage: gen_wb_ext  fname\n");
		exit(-1);
	}
    else
	{
		retcode=gen_wb_ext_call(argv[1]);
	}

 exit(retcode);
}



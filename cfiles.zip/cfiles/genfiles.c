#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"


void genfiles_call( char *infilestr)
{
  int cnt;
  FILE *fnamefile;
  FILE *file1;
  char arr[10][120];
  char name[120];
  char cntstr[120];
  char fname[300];
  char FILENAME[300];
  int endoffile;
  char thisline[300];

  strncpy(FILENAME,infilestr,120);


  split(FILENAME,arr[0],arr[1],".");
  strncpy(name,arr[0],120);

   cnt = 1;
   //fname = (name".all")
   strncpy(fname,name,120);
   strncat(fname,".all",10);

   fnamefile=fopen(fname,"w");

   if ( fnamefile== NULL)
   {
	   printf("In genfiles, unable to open the output file = %s \n",
		        fname);
	   exit(-1);
   }

   file1=fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In genfiles, unable to open the input file = %s \n", infilestr);
	   exit(-1);
   }

  endoffile=getline(file1,thisline);

 while(endoffile==FALSE)
  {
  if(strstr(thisline,"%LP") != NULL) //  $0 ~ /%LP/
   {
      cnt++;
      // fname = (name"."cnt)
	  strncpy(fname,name,120);
      strncat(fname,".",4);
      sprintf(cntstr,"%d",cnt);
      strncat(fname,cntstr,30);
      fclose(fnamefile);
      fnamefile=fopen(fname,"w");
      if (fnamefile==NULL)
	  {
	    printf("In genfiles, unable to open the output file = %s \n",
		 fname);
          exit(-1);
      }
   }
  fprintf(fnamefile,"%s",thisline); // $0 > fname

  endoffile=getline(file1,thisline);
 }


fclose(file1);
fclose(fnamefile);
}

int main( int argc, char **argv)
{

  if ( argc != 2)
    {
      printf("In genfiles, wrong number of arguments \n");
      printf("Usage: genfiles infile \n");
      exit(-1);
    }
  else
    {
      genfiles_call( argv[1]); 

    }

}  // end main

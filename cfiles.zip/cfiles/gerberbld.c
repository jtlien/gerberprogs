#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <math.h>

#include "utilprogs.h"


void dooffset_call_out(char *fname, int in1 , int in2, char *outfilestr);
void dooffsetfx_call_out(char *fname, int in1 , int in2, char *outfilestr);
void dooffsetfy_call_out(char *fname, int in1 , int in2, char *outfilestr);
void dooffsetfxy_call_out(char *fname, int in1 , int in2, char *outfilestr);

char loc_scan_array[1000][200];
char locs_scan_array[1000][200];
char dir_array[1000][200];

FILE *locfile;

int dir_count;

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// Rev 1
// Title: gerberbld.c
// written by John Lien 2006

// calling Syntax
//     gerberbld   

//  This program will read all the files with a .loc extention.
//    The for each line in the .loc file that gives and x,y location
//      array out all files in the directory with the same base name as
//      
//
//   Scan directory for regular files that match a particular base
//

void add_to_dir_list( char *instr)
{
int dir_found;
int ii;
int debug;

ii = 0;
dir_found = FALSE;


debug =0;

if (debug)
{
printf("In add_to_dir_list, dir = %s \n",instr);
}

while( ii < dir_count)        // check if already there
{
	if (strcmp(dir_array[ii], instr) ==0 )
	{
		dir_found = TRUE;
		return;
	}
  ii += 1;
}

// no dir_found already so add this one


strncpy( dir_array[dir_count],instr, 120);

dir_count += 1;

}

int found_in_dir_list( char *instr)
{
int dir_found;
int ii;
int debug;

ii = 0;
dir_found = FALSE;


debug =0;

if (debug)
{
printf("In add_to_dir_list, dir = %s \n",instr);
}

while(( ii < dir_count)  && ( dir_found == FALSE))
{
	if (strcmp(dir_array[ii], instr) ==0 )
	{
		dir_found = TRUE;
		return(TRUE);
	}
  ii += 1;
}

return(FALSE);

}

void gerberbld_call()
{

int number_loc_files;
int number_base_files;

char basestr[300];
char extstr[300];

char array_base[300];
char array_ext[300];
char dest_file_str[300];
char loc_file_str[300];
char array_file_str[300];
char dir_name_str[200];
char dirstr[300];
char fromfilestr[300];
char base_srchstr[300];

int endoffile;
char thisline[300];

char xstr[300];
char ystr[300];
int xval;
int yval;
int nf;
char istr[100];
char flipstr[100];
char systemstr[400];
int gbrcnt;

int i;
int j;
int k;
int debug;

//   This section reads all the .loc files.   The loc file specifies a "stack" of
//    gerbers at a given x,y location.   for each base_name.dir_ext file,
//     put the base_name.base_name gerber file at the x,y location in the dir_ext 
//     directory.
//

     debug = 0;
     strncpy(dirsep,"\\",3);
     dir_count = 0;

	 strncpy(extstr,".loc",10);

	 number_loc_files =scandir_matchext(".",0,extstr);    // not recursive

	 for(i=0; i < number_loc_files ; i += 1)  // save scan info
	 {
		 strncpy(loc_scan_array[i],scan_array[i],120);
	 }

	 i=0;

	 printf("number of loc files = %d \n", number_loc_files);

     while( i < number_loc_files)   // 
        {
			strncpy(loc_file_str,loc_scan_array[i],120);
			
			if (debug) { printf("About to open %s \n",loc_file_str); }

			locfile = fopen(loc_file_str,"r");

			split(loc_file_str,basestr,extstr,".");
			strncpy(base_srchstr,basestr,120);

			strncat(basestr,".",3);

			if (locfile == NULL)
			{
				printf("Unable to open the location file = %s for reading \n",loc_file_str);
				exit(-1);
			}

			endoffile=getline(locfile,thisline);
			nf=split_line(thisline);
            k = 0;

			while(endoffile == FALSE)
			{

			//  strncpy(dirstr,str_array[1],120);  // which dir to put it into?

			  strncpy(xstr,str_array[0],120);
			  strncpy(ystr,str_array[1],120);

			  if ( nf < 3)   // 3rd parameter not given ( orientation = no, fx, fy, fxy )
			  {
				  strncpy(flipstr,"no",10);
			  }
			  else
			  {
			   strncpy(flipstr,str_array[2],100);
			  }

			  xval = atoi( xstr);
			  yval = atoi( ystr);

			  if (debug) { printf("basestr = %s xstr = %s ystr = %s \n",basestr,xstr, ystr); }


			  number_base_files = scandir_matchbase(".",0,base_srchstr);

			  if (debug)
			  {
               printf("number_base_files = %d for base_srchstr = %s\n",number_base_files,
				   base_srchstr);
			  }

			  j=0;
			  while( j < number_base_files)
			  {

				  strncpy( array_file_str, scan_array[j], 120);

				  if (debug) { printf("array_file_str = %s \n", array_file_str); }

				
				  split(array_file_str,array_base,array_ext,".");

				  if ((strcmp(array_ext,"loc") != 0 ) && ( strcmp(array_ext,"") != 0 ) )
				  {
				   if (debug) 
				   { printf("array_base = %s array_ext = %s \n",array_base, array_ext); }

				   if ( dir_exists( array_ext ) )
				   {
					   if ( ! found_in_dir_list( array_ext) )  // left over dir, rm *.gbr from
					   {
						   if (debug)
						   { 
							   printf("Cleaning out the old dir = %s for array_base = %s\n", 
								   array_ext,array_base); }

						   gbrcnt=scandir_matchext_count(array_ext,0,".gbr");
						   if (gbrcnt > 0 )
						   {
						    strncpy(systemstr,"rm ",10);
						    strncat(systemstr,array_ext,120);
						    strncat(systemstr,"/*.gbr",30);
						    system(systemstr);
						  
						   }
					   }
				   }
				   else
				   {
					   if (debug) { printf("Makeing the %s array \n", array_ext); }
					   mkdir( array_ext);
				   }
				   add_to_dir_list( array_ext );  // if not already there

				   strncpy( dest_file_str,array_ext,120);
				   strncat( dest_file_str,dirsep,10);
				   strncat( dest_file_str,array_base,120);
				   strncat( dest_file_str,"_", 3);
				   sprintf(istr,"%d_%d",i,k);
				   strncat( dest_file_str,istr,30);
				   strncat( dest_file_str,".gbr",10);

				   if ( strcmp( flipstr,"no") == 0 )
					  {
						 // printf("dooffset_call_out, from = %s x,y = %d %d to=%s \n",
						//	  array_file_str, xval, yval, dest_file_str);

                       dooffset_call_out( array_file_str, xval, yval, dest_file_str);
					  }

                   if ( strcmp( flipstr,"fx") == 0 )
					  {
						 //printf("dooffsetfx_call_out, from = %s x,y = %d %d to=%s \n",
							//  array_file_str, xval, yval, dest_file_str);
                       dooffsetfx_call_out( array_file_str, xval, yval, dest_file_str);
					  }
                   if ( strcmp( flipstr,"fy") == 0 )
					  { 
						// printf("dooffsetfy_call_out, from = %s x,y = %d %d to=%s \n",
						//	  array_file_str, xval, yval, dest_file_str);
                       dooffsetfy_call_out( array_file_str, xval, yval, dest_file_str);
					  }
				   if ( strcmp( flipstr,"fxy") == 0 )
					  { 
						 //printf("dooffsetfxy_call_out, from = %s x,y = %d %d to=%s \n",
						//	  array_file_str, xval, yval, dest_file_str);
                       dooffsetfxy_call_out( array_file_str, xval, yval, dest_file_str);
					  }
				   }
				
				j += 1;
			  } 
			  k += 1;
	          endoffile=getline(locfile,thisline);
			  nf=split_line(thisline);
			}

          fclose(locfile);
		  // printf("Closing locfile,i = %d \n",i);
	      i += 1;

		}   // for all .loc files



//	printf("Done with .loc files \n");

	debug = 0;

 // This section looks for all .locs files.   Use the .locs files to 
 // read  base_name.base_name as the source gerber and
 // put this gerber in the directory specified by the 1st column in the locs
 // file.   columns 2 and 3 specify the x,y location to center the gerber
 // and column 4 the orientation

	 strncpy(extstr,".locs",10);

	 number_loc_files =scandir_matchext(".",0,extstr);    // not recursive

	 for(i=0; i < number_loc_files ; i += 1)  // save scan info
	 {
		 strncpy(locs_scan_array[i],scan_array[i],120);
	 }


	 //printf("Past copy of scan_array \n");

     j=0;
     while( j < number_loc_files)   // 
        {
			strncpy(loc_file_str,locs_scan_array[j],120);
			
			if (debug) { printf("About to open %s \n",loc_file_str); }

			locfile = fopen(loc_file_str,"r");

			split(loc_file_str,basestr,extstr,".");
			

			if (locfile == NULL)
			{
				printf("Unable to open the location file = %s for reading \n",loc_file_str);
				exit(-1);
			}

			endoffile=getline(locfile,thisline);
			nf=split_line(thisline);
            k = 0;

			while(endoffile == FALSE)
			{

			  strncpy(dirstr,str_array[0],120);  // which dir to put it into?

			  strncpy(xstr,str_array[1],120);
			  strncpy(ystr,str_array[2],120);

			  if ( nf < 4)   // 4th parameter missing, orientation
			  {
				  strncpy(flipstr,"no",10);
			  }
			  else
			  {
			   strncpy(flipstr,str_array[3],100);
			  }

			  xval = atoi( xstr);
			  yval = atoi( ystr);

			 // printf("for locs, basestr = %s xstr = %s ystr = %s  dirstr = %s\n",
			//	  basestr,xstr, ystr,dirstr);

			  
				 
		       if ( dir_exists( dirstr ) )
			   {
				   if (! found_in_dir_list( dirstr) )
				   {
					   gbrcnt=scandir_matchext(dirstr,0,".gbr");
					   if (gbrcnt > 0 )
						   {
					       //rm_files_ext( dirstr,0, ".gbr");
					         strncpy(systemstr,"rm ",10);
						     strncat(systemstr,dirstr,120);
						     strncat(systemstr,"/*.gbr",30);
						     system(systemstr);
						   }   
				   }
			   }
			   else
			   {
				   mkdir (dirstr);
			   }
			   add_to_dir_list( dirstr );  // if not already there

			   strncpy(fromfilestr,basestr,120);
			   strncat(fromfilestr,".",10);
			   strncat(fromfilestr,basestr,120);

			   strncpy( dest_file_str,dirstr,120);
			   strncat( dest_file_str,dirsep,10);
			   strncat( dest_file_str,basestr,120);
			   strncat( dest_file_str,"_", 3);
			   sprintf(istr,"%d_%d",i,k);
			   strncat( dest_file_str,istr,30);
			   strncat( dest_file_str,".gbr",10);

			   if ( strcmp( flipstr,"no") == 0 )
			   {
						//  printf("dooffset_call_out, from = %s x,y = %d %d to=%s \n",
							//  fromfilestr, xval, yval, dest_file_str);

                       dooffset_call_out( fromfilestr, xval, yval, dest_file_str);
			   }

              if ( strcmp( flipstr,"fx") == 0 )
			  {
					//	 printf("dooffsetfx_call_out, from = %s x,y = %d %d to=%s \n",
							//  fromfilestr, xval, yval, dest_file_str);
                       dooffsetfx_call_out( fromfilestr, xval, yval, dest_file_str);
			  }
              if ( strcmp( flipstr,"fy") == 0 )
			  { 
						// printf("dooffsetfy_call_out, from = %s x,y = %d %d to=%s \n",
							 // fromfilestr, xval, yval, dest_file_str);
                       dooffsetfy_call_out( fromfilestr, xval, yval, dest_file_str);
			  }
			  if ( strcmp( flipstr,"fxy") == 0 )
			  { 
						//printf("dooffsetfxy_call_out, from = %s x,y = %d %d to=%s \n",
							 // array_file_str, xval, yval, dest_file_str);
                       dooffsetfxy_call_out( fromfilestr, xval, yval, dest_file_str);
			  }
			
	          endoffile=getline(locfile,thisline);
			  nf=split_line(thisline);
			  k += 1;
			}

          fclose(locfile);
	      i += 1;
		  j +=1;

		}   // for all .loc files

	 // in each dir, cat all the .gbr files together to make one big one

  for( k = 0; k < dir_count ; k += 1)
  {

	  strncpy(dir_name_str, dir_array[k],120);

	  strncpy(systemstr,"cat ",10);
	  strncat(systemstr,dir_name_str,120);
	  strncat(systemstr,dirsep,10);
	  strncat(systemstr,"*.gbr >",20);
	  strncat(systemstr,dir_name_str,120);
	  strncat(systemstr,"_all.gbr",20);

	  debug=1;
	  if (debug) { printf("systemstr = %s \n",systemstr); }
      debug=0;

	  system(systemstr);


  }
}  // end gerberbld_call



int main( int argc, char **argv)
{

  if ( argc != 1 )
   {
    printf("In gerberbld, wrong number of arguments \n");
	printf("Usage: gerberbld \n");
	printf("Example: gerberbld   \n");
	exit(-1);
   }
   else
   {
     gerberbld_call( );
	}

}  







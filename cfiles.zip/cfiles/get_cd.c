#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"
#include "padutils.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

struct offsetstuff
{
    double aval;
	char offstr[100];
} offset_array[200];

int offcount;

// get_cd.awk (tsa)

//This awk script parses the output of extract for scms for Xcd
// it also applies the offset from the offset file

// rev 1 released to users on 2/4/03

double get_from_offset( char *instr)
{
int jj;

 jj=0;
 while(jj < offcount)
 {
	 if (strcmp(offset_array[jj].offstr,instr) == 0 )
	 {
		 return(offset_array[jj].aval);
	 }
	jj += 1;
 }

 return(0);

}  // get_from_offset

// add this pair of string, val to offset table
//
void add_to_offset( char *instr, double inval)
{

 if (offcount < 2000)
	{
     strncpy(offset_array[offcount].offstr,instr,120);

     offcount +=1;
	}
 else
 {
	 printf("Error in get_cd, offset array too small \n");
	 exit(-1);
 }

}



void get_cd_call_out(char *infile1str, char *infile2str, char *outfilestr) 
{
int kk;
int ll;
char compstr[200];
char myindex[200];
char tol_val[200];
char tempstr[200];
char thisline[300];
char units[300];
char singlequote;

double multval;
double offval;
FILE *file1, *file2;
FILE *outfile;
double mult;
int endoffile;
int nf;
int res;

   singlequote = '\23';
   //an array of valid choices for regular pad types
  
   offcount=0;

   file1=fopen(infile1str,"r");

   if (file1 == NULL)
   {
	   printf("In get_cd, unable to open the input file = %s \n",infile1str);
	   exit(-1);
   }

  file2=fopen(infile2str,"r");

   if (file2 == NULL)
   {
	   printf("In get_cd, unable to open the input file = %s \n",infile2str);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"w");

   if (outfile == NULL)
   {
	   printf("In get_cd, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while( endoffile==FALSE)
   {
     //sub("'","",$1)

	 kk=0;
	 ll=0;
     while(kk < (signed int ) strlen(str_array[0]) )
	 {
		 if (str_array[0][kk] != singlequote )
		 {
           tempstr[ll]=str_array[0][kk];
		   ll+=1;
		 }
		kk += 1;
	 }
	 tempstr[ll] = '\0';
	 strncpy(str_array[0],tempstr,120);


     //myindex = toupper($1);
	 strncpy(myindex, str_array[0],120);
	 kk=0;
	 while(kk < (signed int) strlen(myindex))
	 {
         myindex[kk]=toupper(myindex[kk]);

		 kk += 1;
	 }
     add_to_offset(myindex,fabs(atof(str_array[1])) );

    // tol_val = ("+/-" $3)
	 strncpy(tol_val,"+/-",10);
	 strncat(tol_val,str_array[2],120);

     // tolerance[myindex] = tol_val
	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

   }
      
   fclose(file1);

   // FS = "!"

   endoffile=getline(file2,thisline);
   nf=split_line_seps(thisline,"!");

  while(endoffile==FALSE)
  {
   strncpy(compstr,str_array[0],120);
   kk=0;
   while(kk < (signed int) strlen(compstr) )
   {
	   compstr[kk]=toupper(compstr[kk]);
	   kk+=1;
   }
   if(strcmp(compstr,"J") == 0 ) 
   {
      //units = toupper($9)
	  strncpy(units,str_array[8],120);
	  kk=0;
	  while(kk < (signed int) strlen(units) )
	  {
		  units[kk]=toupper(units[kk]);
		  kk+=1;
	  }
      if (strcmp(units,"MILLIMETERS") == 0)
	  {
         mult = 1000;
         res = 0;
      }
      else if ( strcmp(units,"MICRONS")==0)
	  {
         mult = 1;
         res = 0;
      }
      else 
	  {
         res = 1;
      }
   }

   if ( ((strcmp(str_array[2],"C4")==0) ||
	    (strcmp(str_array[2],"CAPC4")==0) ||
	    (strcmp(str_array[2],"BGA")==0) ) && (strstr(str_array[1],"DISPLAY")==NULL)  )
   {
	 multval=atof(str_array[5])*mult;
	 offval=get_from_offset(str_array[1]);

     fprintf(outfile,"%-7s %-9s %3.0fum %7.0fum \n",str_array[1] , str_array[2] ,
		 multval,multval+offval);
   }
   else if ( (strcmp(str_array[1],"CORE")==0) && 
	   (strstr(str_array[2],"V") !=NULL) && 
	   (strcmp(str_array[3],"CIRCLE")==0)  )
   {
	 multval=atof(str_array[5])*mult;
	 offval=get_from_offset(str_array[1]);
     fprintf(outfile,"%-7s %-9s %3.0fum %7.0fum \n", str_array[1], "RELIEF" ,multval,multval-offval);
   }
   else if ((strcmp(str_array[3],"LINE")==0) && (strcmp(str_array[4],"CONNECT")==0) )
   {
	 multval=atof(str_array[6])*mult;
     offval=get_from_offset(str_array[1]);
     fprintf(outfile,"%-7s %-9s %3.0fum %7.0fum \n",str_array[1] ,str_array[3] ,multval,multval+offval);
   }
   else if ( (strstr(str_array[1],"V")!=NULL)  && (find_vnum(str_array[2]) ) )
   {
	   multval=atof(str_array[5])*mult;
	   offval=get_from_offset(str_array[1]);
     fprintf(outfile,"%-7s %-9s %3.0fum %7.0fum \n",str_array[1], "VIA" , multval+offval,multval);
   }
   else if ((strstr(str_array[1],"V")==NULL) && (find_vnum(str_array[2])) &&
	             (find_in_pad_type(str_array[3]))) 
   {
	 multval=atof(str_array[5])*mult;
     offval=get_from_offset(str_array[1]);
     fprintf(outfile,"%-7s %-9s %3.0fum %7.0fum \n",str_array[1],"V-PAD",multval,multval+offval);
   }
   else if ((strcmp(str_array[3],"ARC")==0) && (strcmp(str_array[4],"VOID")==0) )
   {
	 multval=atof(str_array[7])*mult;
     offval=get_from_offset(str_array[1]);
     fprintf(outfile,"%-7s %-9s %3.0fum %7.0fum \n",str_array[1],"RELIEF", multval,multval-offval);
   }

   endoffile=getline(file2,thisline);
   nf=split_line_seps(thisline,"!");

  }
  fclose(file2);
  fclose(outfile);

}                // end



void get_cd_call(char *infile1str, char *infile2str) 
{
int kk;
int ll;
char compstr[200];
char myindex[200];
char tol_val[200];
char tempstr[200];
char thisline[300];
char units[300];
char singlequote;

double multval;
double offval;
FILE *file1, *file2;
double mult;
int endoffile;
int nf;
int res;

   singlequote = '\23';
   //an array of valid choices for regular pad types
  
   offcount=0;

   file1=fopen(infile1str,"r");

   if (file1 == NULL)
   {
	   printf("In get_cd, unable to open the input file = %s \n",infile1str);
	   exit(-1);
   }

  file2=fopen(infile2str,"r");

   if (file2 == NULL)
   {
	   printf("In get_cd, unable to open the input file = %s \n",infile2str);
	   exit(-1);
   }
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while( endoffile==FALSE)
   {
     //sub("'","",$1)

	 kk=0;
	 ll=0;
     while(kk < (signed int ) strlen(str_array[0]) )
	 {
		 if (str_array[0][kk] != singlequote )
		 {
           tempstr[ll]=str_array[0][kk];
		   ll+=1;
		 }
		kk += 1;
	 }
	 tempstr[ll] = '\0';
	 strncpy(str_array[0],tempstr,120);


     //myindex = toupper($1);
	 strncpy(myindex, str_array[0],120);
	 kk=0;
	 while(kk < (signed int) strlen(myindex))
	 {
         myindex[kk]=toupper(myindex[kk]);

		 kk += 1;
	 }
     add_to_offset(myindex,fabs(atof(str_array[1])) );

    // tol_val = ("+/-" $3)
	 strncpy(tol_val,"+/-",10);
	 strncat(tol_val,str_array[2],120);

     // tolerance[myindex] = tol_val
	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

   }
      
   fclose(file1);

   // FS = "!"

   endoffile=getline(file2,thisline);
   nf=split_line_seps(thisline,"!");

  while(endoffile==FALSE)
  {
   strncpy(compstr,str_array[0],120);
   kk=0;
   while(kk < (signed int) strlen(compstr) )
   {
	   compstr[kk]=toupper(compstr[kk]);
	   kk+=1;
   }
   if(strcmp(compstr,"J") == 0 ) // handle units info
   {
      //units = toupper($9)
	  strncpy(units,str_array[8],120);
	  kk=0;
	  while(kk < (signed int) strlen(units) )
	  {
		  units[kk]=toupper(units[kk]);
		  kk+=1;
	  }
      if (strcmp(units,"MILLIMETERS") == 0)
	  {
         mult = 1000;
         res = 0;
      }
      else if ( strcmp(units,"MICRONS")==0)
	  {
         mult = 1;
         res = 0;
      }
      else 
	  {
         res = 1;
      }
   }

   if ( ((strcmp(str_array[2],"C4")==0) ||
	    (strcmp(str_array[2],"CAPC4")==0) ||
	    (strcmp(str_array[2],"BGA")==0) ) && (strstr(str_array[1],"DISPLAY")==NULL) )
   {
	 multval=atof(str_array[5])*mult;
	 offval=get_from_offset(str_array[1]);

     printf("%-7s %-9s %3.0fum %7.0fum \n",str_array[1] , str_array[2] ,
		 multval,multval+offval);
   }
   else if ( (strcmp(str_array[1],"CORE")==0) && 
	   (strstr(str_array[2],"V") !=NULL) && 
	   (strcmp(str_array[3],"CIRCLE")==0)  )
   {
	 multval=atof(str_array[5])*mult;
	 offval=get_from_offset(str_array[1]);
     printf("%-7s %-9s %3.0fum %7.0fum \n", str_array[1], "RELIEF" ,multval,multval-offval);
   }
   else if ((strcmp(str_array[3],"LINE")==0) && (strcmp(str_array[4],"CONNECT")==0) )
   {
	 multval=atof(str_array[6])*mult;
     offval=get_from_offset(str_array[1]);
     printf("%-7s %-9s %3.0fum %7.0fum \n",str_array[1] ,str_array[3] ,multval,multval+offval);
   }
   else if ( (strstr(str_array[1],"V")!=NULL)  && (find_vnum(str_array[2]) ) )
   {
	   multval=atof(str_array[5])*mult;
	   offval=get_from_offset(str_array[1]);
     printf("%-7s %-9s %3.0fum %7.0fum \n",str_array[1], "VIA" , multval+offval,multval);
   }
   else if ((strstr(str_array[1],"V")==NULL) && (find_vnum(str_array[2])) &&
	             (find_in_pad_type(str_array[3]))) 
   {
	 multval=atof(str_array[5])*mult;
     offval=get_from_offset(str_array[1]);
     printf("%-7s %-9s %3.0fum %7.0fum \n",str_array[1],"V-PAD",multval,multval+offval);
   }
   else if ((strcmp(str_array[3],"ARC")==0) && (strcmp(str_array[4],"VOID")==0) )
   {
	 multval=atof(str_array[7])*mult;
     offval=get_from_offset(str_array[1]);
     printf("%-7s %-9s %3.0fum %7.0fum \n",str_array[1],"RELIEF", multval,multval-offval);
   }

   endoffile=getline(file2,thisline);
   nf=split_line_seps(thisline,"!");

  }
  fclose(file2);

}                // end

/*
int main( int argc, char **argv)
{

	if ( argc != 3)
	{
		printf("In get_cd, wrong number of arguments.   Usage: get_cd file1 file2 \n");
		exit(-1);
	}
    else
	{
		get_cd_call(argv[1], argv[2]);
	}
}
*/



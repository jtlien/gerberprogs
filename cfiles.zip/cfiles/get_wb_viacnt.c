#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

#define MAX_LAYER_INFO  5000

// revision 1 released to users on 11/15/02 - tsa
//  provides information on wirebond parts, includes Bond finger and die pad counts

struct layerstuff
{
	char layerinfo[200];
	int mycnt;
}  layer_info_array[MAX_LAYER_INFO];

int layerinfo_count;


int info_index( char *tstr)
{
int found;
int ii;

found=FALSE;

ii=0;
while(ii < layerinfo_count)
{

	if (strcmp(tstr,layer_info_array[ii].layerinfo)==0 )
	{
		return(ii);
	}

  ii += 1;
}

 return(-1);

}  // info_index


int find_in_info( char *tstr)
{
int found;
int ii;

found=FALSE;

ii=0;
while(ii < layerinfo_count)
{

	if (strcmp(tstr,layer_info_array[ii].layerinfo)==0 )
	{
		return(TRUE);
	}

  ii += 1;
}

 return(FALSE);

}  // find_in_info

void add_to_info( char *tstr)
{
	strncpy(layer_info_array[layerinfo_count].layerinfo,tstr,100);
	layer_info_array[layerinfo_count].mycnt=1;
	if ( layerinfo_count < 3000 )
	{
		layerinfo_count += 1;
	}
	else
	{
		printf("In add_to_info, array size of 3000 exceeded \n");
		exit(-1);
	}
}


void get_wb_viacnt_call_out( char *infilestr, char *outfilestr)
{
int endoffile;
int nf;
char thisline[300];
char substr1[300];
char substr2[300];
char tmp1[300];
char tmp2[300];
char tmp3[300];
char tmp4[300];
char layers[10][300];
char teststr[300];
int i;
int index;
int diecnt;
int wbcnt;
FILE *file1;
FILE *outfile;

     // FS="!"

  layerinfo_count=0;

  file1=fopen(infilestr,"r");
  if (file1 == NULL)
  {
    printf("In get_wb_viacnt, unable to open the input file = %s \n",infilestr);
	exit(-1);
  }

  outfile=fopen(outfilestr,"w");
  if (outfilestr == NULL)
  {
    printf("In get_wb_viacnt, unable to open the output file = %s \n",outfilestr);
	exit(-1);
  }

  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");

  while(endoffile==FALSE)
  {
   if( strcmp(str_array[0],"S") == 0 )   // $1 == "S")
   {
    
	strncpy(teststr,str_array[4],120);
	strncat(teststr,",",4);
	strncat(teststr,str_array[5],120);

	if (find_in_info( teststr) )
	{
		index=info_index( teststr);
		layer_info_array[index].mycnt++;
	}
	else
	{
		add_to_info( teststr);
	}
    
    
   }
  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");
  }

  fclose(file1);
 
  diecnt=0;
  wbcnt=0;
   
  i=0;
  while( i < layerinfo_count)       // in mycnt)
  {
     split(layer_info_array[i].layerinfo, layers[0],layers[1],",");
	 awk_substr(layers[0],1,2,substr1);
	 awk_substr(layers[1],1,2,substr2);
     cv_toupper(substr1,tmp1);
     cv_toupper(substr2,tmp2); 
     cv_toupper(layers[0],tmp3);
     cv_toupper(layers[1],tmp4);
     if( (strcmp(tmp1,"WB") ==0) && (strcmp(tmp2,"WB")==0) )
	 {
         diecnt += layer_info_array[i].mycnt;
     }
     if( ((strcmp(tmp1,"WB")==0) && (strcmp(tmp4,"L01")==0)) || 
		 ((strcmp(tmp2,"WB")==0) && (strcmp(tmp3,"L01")==0))  )
	 {
         wbcnt += layer_info_array[i].mycnt;  
     }
	i+=1;
  }

  fprintf(outfile, "Bond Fingers = %d \n", wbcnt );
  fprintf(outfile, "Die Pads = %d", diecnt );

  fclose(outfile);

}   // end  get_wb_viacnt_call

void get_wb_viacnt_call_append( char *infilestr, char *outfilestr)
{
int endoffile;
int nf;
char thisline[300];
char substr1[300];
char substr2[300];
char tmp1[300];
char tmp2[300];
char tmp3[300];
char tmp4[300];
char layers[10][300];
char teststr[300];
int i;
int index;
int diecnt;
int wbcnt;
FILE *file1;
FILE *outfile;

     // FS="!"

  layerinfo_count=0;

  file1=fopen(infilestr,"r");
  if (file1 == NULL)
  {
    printf("In get_wb_viacnt, unable to open the input file = %s \n",infilestr);
	exit(-1);
  }

  outfile=fopen(outfilestr,"a");
  if (outfilestr == NULL)
  {
    printf("In get_wb_viacnt, unable to open the output append file = %s \n",outfilestr);
	exit(-1);
  }

  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");

  while(endoffile==FALSE)
  {
   if( strcmp(str_array[0],"S") == 0 )   // $1 == "S")
   {
    
	strncpy(teststr,str_array[4],120);
	strncat(teststr,",",4);
	strncat(teststr,str_array[5],120);

	if (find_in_info( teststr) )
	{
		index=info_index( teststr);
		layer_info_array[index].mycnt++;
	}
	else
	{
		add_to_info( teststr);
	}
    
    
   }
  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");
  }

  fclose(file1);
 
  diecnt=0;
  wbcnt=0;
   
  i=0;
  while( i < layerinfo_count)       // in mycnt)
  {
     split(layer_info_array[i].layerinfo, layers[0],layers[1],",");
	 awk_substr(layers[0],1,2,substr1);
	 awk_substr(layers[1],1,2,substr2);
     cv_toupper(substr1,tmp1);
     cv_toupper(substr2,tmp2); 
     cv_toupper(layers[0],tmp3);
     cv_toupper(layers[1],tmp4);
     if( (strcmp(tmp1,"WB") ==0) && (strcmp(tmp2,"WB")==0) )
	 {
         diecnt += layer_info_array[i].mycnt;
     }
     if( ((strcmp(tmp1,"WB")==0) && (strcmp(tmp4,"L01")==0)) || 
		 ((strcmp(tmp2,"WB")==0) && (strcmp(tmp3,"L01")==0))  )
	 {
         wbcnt += layer_info_array[i].mycnt;  
     }
	i+=1;
  }

  fprintf(outfile, "Bond Fingers = %d \n", wbcnt );
  fprintf(outfile, "Die Pads = %d", diecnt );

  fclose(outfile);

}   // end  get_wb_viacnt_call_append

//
//  Do not print any resuls out, if select_val == 0 return wbcnt
//            else return diecnt
//
int get_wb_viacnt_call_count( char *infilestr , int select_val)
{
int endoffile;
int nf;
char thisline[300];
char substr1[300];
char substr2[300];
char tmp1[300];
char tmp2[300];
char tmp3[300];
char tmp4[300];
char layers[10][300];
char teststr[300];
int i;
int index;
int diecnt;
int wbcnt;
FILE *file1;

     // FS="!"

  layerinfo_count=0;

  file1=fopen(infilestr,"r");
  if (file1 == NULL)
  {
    printf("In get_wb_viacnt, unable to open the input file = %s \n",infilestr);
	exit(-1);
  }

  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");

  while(endoffile==FALSE)
  {
   if( strcmp(str_array[0],"S") == 0 )   // $1 == "S")
   {
    
	strncpy(teststr,str_array[4],120);
	strncat(teststr,",",4);
	strncat(teststr,str_array[5],120);

	if (find_in_info( teststr) )
	{
		index=info_index( teststr);
		layer_info_array[index].mycnt++;
	}
	else
	{
		add_to_info( teststr);
	}
    
    
   }
  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");
  }

  fclose(file1);
 
  diecnt=0;
  wbcnt=0;
   
  i=0;
  while( i < layerinfo_count)       // in mycnt)
  {
     split(layer_info_array[i].layerinfo, layers[0],layers[1],",");
	 awk_substr(layers[0],1,2,substr1);
	 awk_substr(layers[1],1,2,substr2);
     cv_toupper(substr1,tmp1);
     cv_toupper(substr2,tmp2); 
     cv_toupper(layers[0],tmp3);
     cv_toupper(layers[1],tmp4);
     if( (strcmp(tmp1,"WB") ==0) && (strcmp(tmp2,"WB")==0) )
	 {
         diecnt += layer_info_array[i].mycnt;
     }
     if( ((strcmp(tmp1,"WB")==0) && (strcmp(tmp4,"L01")==0)) || 
		 ((strcmp(tmp2,"WB")==0) && (strcmp(tmp3,"L01")==0))  )
	 {
         wbcnt += layer_info_array[i].mycnt;  
     }
	i+=1;
  }
  //printf( "Bond Fingers = %d \n", wbcnt );
  //printf( "Die Pads = %d", diecnt );

  if (select_val == 0 )
  {
	  return(wbcnt);
  }
  else
  {
	   return(diecnt);
  }
}   // end  get_wb_viacnt_call_count

void get_wb_viacnt_call( char *infilestr )
{
int endoffile;
int nf;
char thisline[300];
char substr1[300];
char substr2[300];
char tmp1[300];
char tmp2[300];
char tmp3[300];
char tmp4[300];
char layers[10][300];
char teststr[300];
int i;
int index;
int diecnt;
int wbcnt;
FILE *file1;

     // FS="!"

  layerinfo_count=0;

  file1=fopen(infilestr,"r");
  if (file1 == NULL)
  {
    printf("In get_wb_viacnt, unable to open the input file = %s \n",infilestr);
	exit(-1);
  }

  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");

  while(endoffile==FALSE)
  {
   if( strcmp(str_array[0],"S") == 0 )   // $1 == "S")
   {
    
	strncpy(teststr,str_array[4],120);
	strncat(teststr,",",4);
	strncat(teststr,str_array[5],120);

	if (find_in_info( teststr) )
	{
		index=info_index( teststr);
		layer_info_array[index].mycnt++;
	}
	else
	{
		add_to_info( teststr);
	}
    
    
   }
  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");
  }

  fclose(file1);
 
  diecnt=0;
  wbcnt=0;
   
  i=0;
  while( i < layerinfo_count)       // in mycnt)
  {
     split(layer_info_array[i].layerinfo, layers[0],layers[1],",");
	 awk_substr(layers[0],1,2,substr1);
	 awk_substr(layers[1],1,2,substr2);
     cv_toupper(substr1,tmp1);
     cv_toupper(substr2,tmp2); 
     cv_toupper(layers[0],tmp3);
     cv_toupper(layers[1],tmp4);
     if( (strcmp(tmp1,"WB") ==0) && (strcmp(tmp2,"WB")==0) )
	 {
         diecnt += layer_info_array[i].mycnt;
     }
     if( ((strcmp(tmp1,"WB")==0) && (strcmp(tmp4,"L01")==0)) || 
		 ((strcmp(tmp2,"WB")==0) && (strcmp(tmp3,"L01")==0))  )
	 {
         wbcnt += layer_info_array[i].mycnt;  
     }
	i+=1;
  }
  printf( "Bond Fingers = %d \n", wbcnt );
  printf( "Die Pads = %d", diecnt );

}   // end  get_wb_viacnt_call

/*
int main( int argc, char **argv)
{

	if (argc != 2)
	{
		printf("In get_wb_viacnt, wrong number of arguments \n");
		printf("Usage: get_wb_viacnt infile  \n");
		exit(-1);
	}
	else
	{
	   get_wb_viacnt_call(argv[1] );
	}

}  // end main
*/

  

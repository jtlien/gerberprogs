
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

int  get_wb_vias_call_out( char *infile1str, char *infile2str, char *outfilestr)
{
int cnt;
char tmp4[200];
char tmp5[200];
char toplayer[300];
char mylayer[300];
char thisline[300];
int endoffile;
FILE *file1;
FILE *file2;
FILE *outfile;
int nf;
int result;


   file1  = fopen(infile1str, "r");

   if (file1 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
   }

    // FS = "!"
    endoffile=getline(file1,thisline);
	nf=split_line_seps(thisline,"!");

    // toplayer = $1
	strncpy(toplayer,str_array[0],120);

	fclose(file1);

   file2  = fopen(infile2str, "r");

   if (file2 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",infile2str);
	  exit(-1);
   }

   outfile=fopen(outfilestr,"w");

   if (outfile == NULL)
   {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
   }

    cnt = 0;

    endoffile=getline(file2,thisline);
	
    endoffile=getline(file2,thisline);


  endoffile=getline(file2,thisline);
   nf=split_line_seps(thisline,"!");

  cv_toupper(toplayer,mylayer);
  while(endoffile==FALSE)
  {
   cnt++;
   //cv_toupper(toplayer,mylayer);
   cv_toupper(str_array[3],tmp4);
   cv_toupper(str_array[4],tmp5);

   if( ((strstr(tmp4,"WB") != NULL) && (strcmp(tmp5,mylayer)==0) ) || 
	   ((strcmp(tmp4,mylayer)==0) && (strstr(tmp5,"WB") != NULL) ) )
   {
	   if (strstr(str_array[6],"\n")!=NULL)   //  eoln at end 
	   {
        fprintf(outfile,"%s %s %s",str_array[2],str_array[5],str_array[6]); // $3,$6,$7) 
	   }
	   else
	   {
        fprintf(outfile,"%s %s %s\n",str_array[2],str_array[5],str_array[6]); // $3,$6,$7) 
	   }
   }
   endoffile=getline(file2,thisline);
   nf=split_line_seps(thisline,"!");
  }

  fclose(file2);
  fclose(outfile);

   if ( cnt == 0)
   {
      result = 1;
   }
   else
   {
      result = 0;
   }
   
   return(result);


} // end get_wb_vias_call_out

int  get_wb_vias_call( char *infile1str, char *infile2str)
{
int cnt;
char tmp4[200];
char tmp5[200];
char toplayer[300];
char mylayer[300];
char thisline[300];
int endoffile;
FILE *file1;
FILE *file2;
int nf;
int result;


   file1  = fopen(infile1str, "r");

   if (file1 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
   }

    // FS = "!"
    endoffile=getline(file1,thisline);
	nf=split_line_seps(thisline,"!");

    // toplayer = $1
	strncpy(toplayer,str_array[0],120);

	fclose(file1);

   file2  = fopen(infile2str, "r");

   if (file2 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",infile2str);
	  exit(-1);
   }

    cnt = 0;

    endoffile=getline(file2,thisline);
	
    endoffile=getline(file2,thisline);


  endoffile=getline(file2,thisline);
   nf=split_line_seps(thisline,"!");
  cv_toupper(toplayer,mylayer);

  while(endoffile==FALSE)
  {
   cnt++;
   cv_toupper(str_array[3],tmp4);
   cv_toupper(str_array[4],tmp5);

   if( ((strstr(tmp4,"WB") != NULL) && (strcmp(tmp5,mylayer)==0) ) || 
	   ((strcmp(tmp4,mylayer)==0) && (strstr(tmp5,"WB") != NULL) ) )
   {
	   if (strstr(str_array[6],"\n")!=NULL)
	   {
        printf("%s %s %s",str_array[2],str_array[5],str_array[6]); // $3,$6,$7) 
	   }
	   else
	   {
       printf("%s %s %s\n",str_array[2],str_array[5],str_array[6]); // $3,$6,$7) 
	   }
   }
   endoffile=getline(file2,thisline);
   nf=split_line_seps(thisline,"!");
  }

  fclose(file2);

   if ( cnt == 0)
   {
      result = 1;
   }
   else
   {
      result = 0;
   }
   
   return(result);


} // end get_wb_vias_call

/*
int main(int argc, char **argv)
{
int retcode;

	if( argc != 3)
	{

		printf("In get_wb_vias, wrong number of arguments \n");
		printf("Usage:  get_wb_vias  fname1 fname2 \n");
		exit(-1);
	}
	else
	{
        retcode= get_wb_vias_call( argv[1], argv[2]);

	}

}  // end main

*/



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


#include "utilprogs.h"

// revision 1 released to users on 11/15/02 - tsa
// provides wire count information for wirebond parts

void get_wbcnt_call_out( char *infilestr, char *outfilestr)
{
int endoffile;
char thisline[300];
int nf;
char str0[300];
char str8[300];
char tmp[300];
char suboutstr[300];
FILE *file1;
FILE *outfile;
int wbcnt;
int ii;

file1=fopen(infilestr,"r");
if (file1==NULL)
{
	printf("In get_wbcnt, unable to open the input file = %s \n",infilestr);
	exit(-1);
}

outfile=fopen(outfilestr,"r");
if (outfile==NULL)
{
	printf("In get_wbcnt, unable to open the output file = %s \n",outfilestr);
	exit(-1);
}
endoffile=getline(file1,thisline);
nf=split_line_seps(thisline,"!");
wbcnt=0;

while(endoffile==FALSE)
{
   awk_substr(str_array[1],1,2,suboutstr);
   cv_toupper(suboutstr,tmp);

   cv_toupper(str_array[0],str0);
   cv_toupper(str_array[8],str8);

   for(ii=0; ii < ( signed int) strlen(str8); ii += 1)
   {
	   if (str8[ii] == '\n')
	   {
		   str8[ii]='\0';
	   }
   }
   if( (strcmp(str0,"S") == 0 ) && (strcmp(str8,"CONNECT")==0) &&
	   (strcmp(tmp,"WB") == 0 ) )
   {
       wbcnt++;
   }

   endoffile=getline(file1,thisline);
   nf=split_line_seps(thisline,"!");
}

fclose(file1);

fprintf(outfile, "Wires  = %d\n", wbcnt);
fclose(outfile);

}  // end get_wbcnt_call

void get_wbcnt_call_append( char *infilestr, char *outfilestr)
{
int endoffile;
char thisline[300];
int nf;
char str0[300];
char str8[300];
char tmp[300];
char suboutstr[300];
FILE *file1;
FILE *outfile;
int wbcnt;
int ii;

file1=fopen(infilestr,"r");
if (file1==NULL)
{
	printf("In get_wbcnt, unable to open the input file = %s \n",infilestr);
	exit(-1);
}

outfile=fopen(outfilestr,"a");
if (outfile==NULL)
{
	printf("In get_wbcnt, unable to open the output append file = %s \n",outfilestr);
	exit(-1);
}
endoffile=getline(file1,thisline);
nf=split_line_seps(thisline,"!");
wbcnt=0;

while(endoffile==FALSE)
{
   awk_substr(str_array[1],1,2,suboutstr);
   cv_toupper(suboutstr,tmp);

   cv_toupper(str_array[0],str0);
   cv_toupper(str_array[8],str8);

   for(ii=0; ii < ( signed int) strlen(str8); ii += 1)
   {
	   if (str8[ii] == '\n')
	   {
		   str8[ii]='\0';
	   }
   }
   if( (strcmp(str0,"S") == 0 ) && (strcmp(str8,"CONNECT")==0) &&
	   (strcmp(tmp,"WB") == 0 ) )
   {
       wbcnt++;
   }

   endoffile=getline(file1,thisline);
   nf=split_line_seps(thisline,"!");
}

fclose(file1);

fprintf(outfile, "Wires  = %d\n", wbcnt);
fclose(outfile);

}  // end get_wbcnt_call_out

// no printing version, just return a count

int get_wbcnt_call_count( char *infilestr)
{
int endoffile;
char thisline[300];
int nf;
char str0[300];
char str8[300];
char tmp[300];
char suboutstr[300];
FILE *file1;
int wbcnt;
int ii;

file1=fopen(infilestr,"r");
if (file1==NULL)
{
	printf("In get_wbcnt, unable to open the input file = %s \n",infilestr);
	exit(-1);
}

endoffile=getline(file1,thisline);
nf=split_line_seps(thisline,"!");
wbcnt=0;

while(endoffile==FALSE)
{
   awk_substr(str_array[1],1,2,suboutstr);
   cv_toupper(suboutstr,tmp);

   cv_toupper(str_array[0],str0);
   cv_toupper(str_array[8],str8);


   for(ii=0; ii < ( signed int) strlen(str8); ii += 1)
   {
	   if (str8[ii] == '\n')
	   {
		   str8[ii]='\0';
	   }
   }
  // printf("str0=%s str8=%s tmp=%s \n", str0, str8, tmp);

   if( (strcmp(str0,"S") == 0 ) && (strcmp(str8,"CONNECT")==0) &&
	   (strcmp(tmp,"WB") == 0 ) )
   {
       wbcnt++;
   }

   endoffile=getline(file1,thisline);
   nf=split_line_seps(thisline,"!");
}

fclose(file1);

//printf( "Wires  = %d\n", wbcnt);

 return(wbcnt);

}  // end get_wbcnt_call_count

void get_wbcnt_call( char *infilestr)
{
int endoffile;
char thisline[300];
int nf;
char str0[300];
char str8[300];
char tmp[300];
char suboutstr[300];
FILE *file1;
int wbcnt;
int ii;

file1=fopen(infilestr,"r");
if (file1==NULL)
{
	printf("In get_wbcnt, unable to open the input file = %s \n",infilestr);
	exit(-1);
}

endoffile=getline(file1,thisline);
nf=split_line_seps(thisline,"!");
wbcnt=0;

while(endoffile==FALSE)
{
   awk_substr(str_array[1],1,2,suboutstr);
   cv_toupper(suboutstr,tmp);

   cv_toupper(str_array[0],str0);
   cv_toupper(str_array[8],str8);


   for(ii=0; ii < ( signed int) strlen(str8); ii += 1)
   {
	   if (str8[ii] == '\n')
	   {
		   str8[ii]='\0';
	   }
   }
  // printf("str0=%s str8=%s tmp=%s \n", str0, str8, tmp);

   if( (strcmp(str0,"S") == 0 ) && (strcmp(str8,"CONNECT")==0) &&
	   (strcmp(tmp,"WB") == 0 ) )
   {
       wbcnt++;
   }

   endoffile=getline(file1,thisline);
   nf=split_line_seps(thisline,"!");
}

fclose(file1);

printf( "Wires  = %d\n", wbcnt);


}  // end get_wbcnt_call

/*
int main( int argc, char **argv)
{


	if (argc != 2)
	{
		printf("get_wbcnt, wrong number of arguments \n");
		printf("Usage: get_wbcnt infile \n");
		exit(-1);
	}
	else
	{
		get_wbcnt_call( argv[1]);
	}
}

*/




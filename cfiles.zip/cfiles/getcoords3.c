#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"
#include "makepan.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

double xstep;
double ystep;
double xsize;
double ysize;
double MMtoIN;
double XFirst;
double YFirst;
double myx;
double myy;
double myx1;
double myy1;
int NumXparts;
int NumYparts;
double mymult;

void test_set( )
{

	panel_x_width= 400.0;
	panel_y_width= 400.0;

	panel_to_active_x = 2.0;
	panel_to_active_y = 2.0;

} 
// calling syntax:
//           getcoords -v mult=4 -v kerf=2 partsize > partcoords
//      where mult is number of positions to right of decimal point (apetrue file FORMAT statement)
//            : 

void outerror( instring )
{
   fprintf(stderr, "** FATAL ERROR ** \n");  //  | "cat 1>&2"
   fprintf(stderr, "** In getcoords3 ** \n");
   fprintf(stderr, "** EXECUTION HALTED **\n"); // | "cat 1>&2" 
   fprintf(stderr,"%s\n",instring); //   | "cat 1>&2"
}

void outstep()
{
FILE *stepfile;
FILE *singfile;
double dist;   
double indist;
double inmyx;
double inmyy;  
double inXstep;
double inYstep;
double myxsize;
double myysize;
double inxsize;
double inysize;

   stepfile=fopen("step.txt","w");
   if (stepfile == NULL)
   {
	   printf("In getcoords3 , unable to open step.txt for writing\n");
	   exit(-1);
   }

   singfile=fopen("singulate.txt","w");
   if (singfile == NULL)
   {
	   printf("In getcoords3 , unable to open singulate.txt for writing\n");
	   exit(-1);
   }
   fprintf(stepfile,"Xstep = %0.5f Ystep = %0.5f\nXnum  = %d       Ynum  = %d\n",xstep,ystep,NumXparts,NumYparts); 
   fprintf(stepfile,"Lower Left\n X = %.5f  Y = %.5f\n",XFirst/mymult,YFirst/mymult); //  > "step.txt"

   dist = fabs( -( total_x_width/ 2.0) * mymult - XFirst)/mymult;  // was -177.8 
   indist = dist/MMtoIN;
   inmyx  = myx/MMtoIN;
   inmyy  = myy/MMtoIN;
   inXstep = xstep/MMtoIN;
   inYstep = ystep/MMtoIN;
   myxsize = xsize/mymult;
   myysize = ysize/mymult;
   inxsize = myxsize/MMtoIN;
   inysize = myysize/MMtoIN;
   fprintf(singfile,"Partsize (X x Y) %9.5f x %.5f (%.5f x %7.5f)\n",
	   myxsize,myysize,inxsize,inysize); // >"singulate.txt"
   fprintf(singfile,"Arraysize: Xnum = %d  Ynum = %d\n",NumXparts,NumYparts); // >"singulate.txt"
   fprintf(singfile,"A1  X = %10.5f (%.5f)     Y = %9.5f (%.5f)\n",myx,inmyx,myy,inmyy); //>"singulate.txt"
   fprintf(singfile,"Xstep = %10.5f (%.5f)  Ystep = %9.5f (%.5f)\n",xstep,inXstep,ystep,inYstep); //
   // >"singulate.txt"
   fprintf(singfile,"X Dist. to target %9.5f (%.5f)",dist,indist); //  > "singulate.txt"

   fclose(singfile);
   fclose(stepfile);
}

int getcoords3_call_out(char *multstr, char *kerfstr, char *infilestr, char *outfilestr)
{
char thisline[200];
int endoffile;
FILE *file1;
FILE *outfile;
FILE *numpartfile;
FILE *srfile;

int nf;

char outstring[200];

int numpts;
double panelxsize;
double panelysize;
double activeareax;
double activeareay;
double xoff;
double yoff;
double powval;

int CODE;
int i,j;
int mult;
int multiplier;
double kerf;
double XDisplacement;
double YDisplacement;
double XTotalSize;
double YTotalSize;
char percentchar;

	   mult=atoi(multstr);
 
	   kerf=atof(kerfstr);

	   file1=fopen(infilestr,"r");
	   if (file1 == NULL)
	   {
		   fprintf(stderr,"In getcoords3, unable to open the input file = %s \n",infilestr);
		   exit(-1);
	   }

       outfile=fopen(outfilestr,"w");
	   if (outfile == NULL)
	   {
		   fprintf(stderr,"In getcoords3, unable to open the output file = %s \n",outfilestr);
		   exit(-1);
	   }

       endoffile=getline(file1,thisline);
	   nf=split_line(thisline);

       xsize = atof(str_array[0]);
       ysize = atof(str_array[1]); // $2

       endoffile=getline(file1,thisline);
	   nf=split_line(thisline);
       numpts = atoi(str_array[0]);  // $1
  
	   fclose(file1);

       CODE = 0;
       panelxsize =  panel_x_width;           // 306.8;   
	   panelysize =  panel_y_width;

       activeareax = panelxsize - panel_to_active_x;        // 304.8;
	   activeareay = panelysize - panel_to_active_y;

       xoff = -( activeareax/2.0); // -152.4;
       yoff = -( activeareay/2.0); //152.4;
       MMtoIN  = 25.4;

 // mult is a passed in variable if not provide then default of 4 
 if ( mult  >  0 )
 {
    multiplier = mult;
 }
 else{
    multiplier = 4;
 }
 
 panelxsize = panelxsize * pow(10,multiplier);
 panelysize = panelysize * pow(10,multiplier);

 // kerf is passed in parameter if not provided will be 0
 mymult = pow(10,multiplier);   // 10 **  multiplier;
 kerf = kerf * pow(10,multiplier); // 10  ** multiplier
 xoff = xoff * pow(10,multiplier);  // 10 ** multiplier
 yoff = yoff * pow(10,multiplier);   // 10 ** multiplier
 activeareax = activeareax * pow(10,multiplier); // 10 ** multiplier
 activeareay = activeareay * pow(10,multiplier); // 10 ** multiplier


 NumXparts = (int )( (activeareax+ kerf) / (xsize + kerf) );
 NumYparts = (int )( (activeareay+ kerf) / (ysize + kerf) );
 XDisplacement = xsize + kerf;
 YDisplacement = ysize + kerf;
 numpartfile=fopen("numparts","w");

 if (numpartfile == NULL)
	{
	 fprintf(stderr,"In getcoords, unable to open the numparts file for writine \n");
	 exit(-1);
 }

 srfile=fopen("sr274x","w");

 if (srfile == NULL)
	{
	 fprintf(stderr,"In getcoords, unable to open the sr247x file for writing \n");
	 exit(-1);
 }

 fprintf(numpartfile,"%d\n%d\n", NumXparts, NumYparts); //  > "numparts"

 percentchar='%';
	                  
 fclose(numpartfile);
 

 xstep = XDisplacement/mymult;
 ystep = YDisplacement/mymult;

 if( (xsize  > panelxsize ) || ( ysize > panelysize) )
 {
   sprintf(outstring,"PART IS TOO BIG -- Xsize = %f Ysize =  %f \n",xsize,ysize);
   outerror( outstring );
   CODE = 255;
 }
 else if(  (xsize == panelxsize) && (ysize == panelysize) ) 
 {
    fprintf(outfile, "0 0 \n");  // partcoords
    myx = 0;
    myy = 0;
    xstep = 0;
    ystep = 0;
    XFirst = 0;
    YFirst = 0;
	if (xsize == panelxsize )
	{
		NumXparts = 1;
		XFirst=0;
	}
	if (ysize == panelysize )
	{
		NumYparts = 1;
		YFirst=0;
	}

    XTotalSize = NumXparts * (xsize + kerf) - kerf;
    YTotalSize = NumYparts * (ysize + kerf) - kerf;

    outstep();
	percentchar='%';
    
	fclose(outfile);

    fprintf(srfile,"%cSRX%dY%dI%0.5fJ%0.5f*%c\n",percentchar,NumXparts,NumYparts,
	            XDisplacement/mymult, 
	             YDisplacement/mymult,percentchar);
	                  

    fclose(srfile);
    
 }
 else
 {
    XTotalSize = NumXparts * (xsize + kerf) - kerf;
    YTotalSize = NumYparts * (ysize + kerf) - kerf;

   XFirst = (activeareax - XTotalSize)/2 + xoff  + xsize/2;
   YFirst = (activeareay - YTotalSize)/2 + yoff  + ysize/2;
   for( i = 0 ; i < NumXparts  ; i++ )
   {
     for( j = 0; j < NumYparts ; j++)
	 {
	   myx1 = XFirst + (XDisplacement * i);
	   myy1 = YFirst + (YDisplacement * j);
       fprintf(outfile,"%0.0f %0.0f\n",XFirst +(XDisplacement * i), YFirst +(YDisplacement * j));
     }
     if( i == 0)
	 {
         myx = myx1/mymult;
	     myy = myy1/mymult;
     }

  }
  fclose(outfile);
  outstep();

  powval=pow(10,(5-multiplier));
  //fprintf(srfile,"X%dY%d*\n",(int)(XFirst* powval),(int)(YFirst * powval));


  fprintf(srfile,"%cSRX%dY%dI%0.5fJ%0.5f*%c\n",percentchar,NumXparts,NumYparts,
	            XDisplacement/mymult, 
	             YDisplacement/mymult,percentchar);
	                  

   fclose(srfile);
 } 
 return(CODE);

} // getcoords3_call_out

int getcoords3_call(char *multstr, char *kerfstr, char *infilestr)
{
char thisline[200];
int endoffile;
FILE *file1;
FILE *numpartfile;
FILE *srfile;
char percentchar;

int nf;

char outstring[200];

int numpts;
double panelxsize;
double panelysize;
double activeareax;
double activeareay;
double xoff;
double yoff;
double powval;

int CODE;
int i,j;
int mult;
int multiplier;
double kerf;
double XDisplacement;
double YDisplacement;
double XTotalSize;
double YTotalSize;
      
	   mult=atoi(multstr);
 
	   kerf=atof(kerfstr);

	   file1=fopen(infilestr,"r");
	   if (file1 == NULL)
	   {
		   fprintf(stderr,"In getcoords3, unable to open the input file = %s \n",infilestr);
		   exit(-1);
	   }


       endoffile=getline(file1,thisline);
	   nf=split_line(thisline);

       xsize = atof(str_array[0]);
       ysize = atof(str_array[1]); // $2

       endoffile=getline(file1,thisline);
	   nf=split_line(thisline);
       numpts = atoi(str_array[0]);  // $1
  
	   fclose(file1);

       CODE = 0;
       panelxsize =  panel_x_width;           // 306.8;
	   panelysize =  panel_y_width;

       activeareax = panelxsize - panel_to_active_x;        // 304.8;
	   activeareay = panelysize - panel_to_active_y;

       xoff = -( activeareax/2.0); // -152.4;
       yoff = -( activeareay/2.0); //152.4;
       MMtoIN  = 25.4;

 // mult is a passed in variable if not provide then default of 4 
 if ( mult  >  0 )
 {
    multiplier = mult;
 }
 else{
    multiplier = 4;
 }
 
 panelxsize = panelxsize * pow(10,multiplier);
 panelysize = panelysize * pow(10,multiplier);

 // kerf is passed in parameter if not provided will be 0
 mymult = pow(10,multiplier);   // 10 **  multiplier;
 kerf = kerf * pow(10,multiplier); // 10  ** multiplier
 xoff = xoff * pow(10,multiplier);  // 10 ** multiplier
 yoff = yoff * pow(10,multiplier);   // 10 ** multiplier
 activeareax = activeareax * pow(10,multiplier); // 10 ** multiplier
 activeareay = activeareay * pow(10,multiplier); // 10 ** multiplier


 NumXparts = (int )( (activeareax+ kerf) / (xsize + kerf) );
 NumYparts = (int )( (activeareay+ kerf) / (ysize + kerf) );
 XDisplacement = xsize + kerf;
 YDisplacement = ysize + kerf;
 numpartfile=fopen("numparts","w");

 if (numpartfile == NULL)
	{
	 fprintf(stderr,"In getcoords, unable to open the numparts file for writing \n");
	 exit(-1);
 }

 srfile=fopen("sr274x","w");

 if (srfile == NULL)
	{
	 fprintf(stderr,"In getcoords, unable to open the sr247x file for writing \n");
	 exit(-1);
 }

 fprintf(numpartfile,"%d\n%d\n", NumXparts, NumYparts); //  > "numparts"

	                  
 fclose(numpartfile);
 

 xstep = XDisplacement/mymult;
 ystep = YDisplacement/mymult;

 if( (xsize  > panelxsize ) || ( ysize > panelysize) )
 {
   sprintf(outstring,"PART IS TOO BIG -- Xsize = %f Ysize =  %f \n",xsize,ysize);
   outerror( outstring );
   CODE = 255;
 }
 else if(  (xsize == panelxsize) || (ysize == panelysize) ) 
 {
    printf( "0 0 \n");
    myx = 0;
    myy = 0;
    xstep = 0;
    ystep = 0;
    XFirst = 0;
    YFirst = 0;
    XTotalSize = NumXparts * (xsize + kerf) - kerf;
    YTotalSize = NumYparts * (ysize + kerf) - kerf;

    outstep();
	percentchar='%';

    fprintf(srfile,"%cSRX%dY%dI%0.5fJ%0.5f*%c\n",percentchar,NumXparts,NumYparts,
	            XDisplacement/mymult, 
	             YDisplacement/mymult,percentchar);
	                  

    fclose(srfile);

 }
 else
 {
    XTotalSize = NumXparts * (xsize + kerf) - kerf;
    YTotalSize = NumYparts * (ysize + kerf) - kerf;

   XFirst = (activeareax - XTotalSize)/2 + xoff  + xsize/2;
   YFirst = (activeareay - YTotalSize)/2 + yoff  + ysize/2;
   for( i = 0 ; i < NumXparts  ; i++ )
   {
     for( j = 0; j < NumYparts ; j++)
	 {
	   myx1 = XFirst + (XDisplacement * i);
	   myy1 = YFirst + (YDisplacement * j);
       printf("%0.0f %0.0f\n",XFirst +(XDisplacement * i), YFirst +(YDisplacement * j));
     }
     if( i == 0)
	 {
         myx = myx1/mymult;
	     myy = myy1/mymult;
     }

  }

 
  outstep();

  percentchar='%';

  powval=pow(10,(5-multiplier));
  //fprintf(srfile,"X%dY%d*\n",(int)(XFirst* powval),(int)(YFirst * powval));

  fprintf(srfile,"%cSRX%dY%dI%0.5fJ%0.5f*%c\n",percentchar,NumXparts,NumYparts,
	            XDisplacement/mymult, 
	             YDisplacement/mymult,percentchar);
	                  

   fclose(srfile);

 } 
 return(CODE);

} // getcoords3_call



int main( int argc, char **argv)
{
int retcode;

  //test_set( );  // set size parameters for testing

  if (argc != 4)
  {
    printf("In getcoords3, wrong number of arguments \n");
	printf("Usage: getcoords3 multiplier kerf partsizefile \n");
	exit(-1);

  }
  else
  {

  retcode=getcoords3_call( argv[1], argv[2], argv[3]);

  exit(retcode);

   }
} 

  

 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

double xstep;
double ystep;
double xsize;
double ysize;
double MMtoIN;
double XFirst;
double YFirst;
double myx;
double myy;
double myx1;
double myy1;
int NumXparts;
int NumYparts;
double mymult;

char str_array[120][120];

// calling syntax:
//           getcoords -v mult=4 -v KERF=2 partsize > partcoords
//      where mult is number of positions to right of decimal point (apetrue file FORMAT statement)
//            : 

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line
//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline


void outerror( instring )
{
   fprintf(stderr, "** FATAL ERROR ** \n");  //  | "cat 1>&2"
   fprintf(stderr, "** EXECUTION HALTED **\n"); // | "cat 1>&2" 
   fprintf(stderr,"%s\n",instring); //   | "cat 1>&2"
}

void outstep()
{
FILE *stepfile;
FILE *singfile;
double dist;   
double indist;
double inmyx;
double inmyy;  
double inXstep;
double inYstep;
double myxsize;
double myysize;
double inxsize;
double inysize;

   stepfile=fopen("step.txt","w");
   if (stepfile == NULL)
   {
	   printf("In getcoords3 , unable to open step.txt for writing\n");
	   exit(-1);
   }

   singfile=fopen("singulate.txt","w");
   if (singfile == NULL)
   {
	   printf("In getcoords3 , unable to open singulate.txt for writing\n");
	   exit(-1);
   }
   fprintf(stepfile,"Xstep = %0.5f Ystep = %0.5f\nXnum  = %d       Ynum  = %d\n",xstep,ystep,NumXparts,NumYparts); 
   fprintf(stepfile,"Lower Left\n X = %.5f  Y = %.5f\n",XFirst/mymult,YFirst/mymult); //  > "step.txt"

   dist = fabs( -177.8 * mymult - XFirst)/mymult;   //-177.8=70000*25.4/10000
   indist = dist/MMtoIN;
   inmyx  = myx/MMtoIN;
   inmyy  = myy/MMtoIN;
   inXstep = xstep/MMtoIN;
   inYstep = ystep/MMtoIN;
   myxsize = xsize/mymult;
   myysize = ysize/mymult;
   inxsize = myxsize/MMtoIN;
   inysize = myysize/MMtoIN;
   fprintf(singfile,"Partsize (X x Y) %9.5f x %.5f (%.5f x %7.5f)\n",
	   myxsize,myysize,inxsize,inysize); // >"singulate.txt"
   fprintf(singfile,"Arraysize: Xnum = %d  Ynum = %d\n",NumXparts,NumYparts); // >"singulate.txt"
   fprintf(singfile,"A1  X = %10.5f (%.5f)     Y = %9.5f (%.5f)\n",myx,inmyx,myy,inmyy); //>"singulate.txt"
   fprintf(singfile,"Xstep = %10.5f (%.5f)  Ystep = %9.5f (%.5f)\n",xstep,inXstep,ystep,inYstep); //
   // >"singulate.txt"
   fprintf(singfile,"X Dist. to target %9.5f (%.5f)",dist,indist); //  > "singulate.txt"

   fclose(singfile);
   fclose(stepfile);
}

//
//  getcoordsk_call_out  multstr specifies then 10^mult multiplier
//              kerfstr, specifies kerf width in tenths of centimeters?
//              infilestr, specifies input file, first line of which
//                has relevant information xsize, ysize
//                outfilestr, specifies output file
//
int getcoordsk_call_out(char *multstr, char *kerfstr, 
						double activexval,
						double activeyval,
						char *infilestr, char *outfilestr)
{
char thisline[200];
int endoffile;
FILE *file1;
FILE *outfile;
FILE *numpartfile;
int nf;

char outstring[200];

int numpts;
double PANELSIZE;
double ACTIVEAREAX;
double ACTIVEAREAY;
double XOFF;
double YOFF;

int CODE;
int i,j;
int mult;
int multiplier;
double KERF;
double XDisplacement;
double YDisplacement;
double XTotalSize;
double YTotalSize;
      
	   mult=atoi(multstr);
 
	   KERF=atof(kerfstr);

	   file1=fopen(infilestr,"r");
	   if (file1 == NULL)
	   {
		   fprintf(stderr,"In getcoords3, unable to open the input file = %s \n",infilestr);
		   exit(-1);
	   }

       outfile=fopen(outfilestr,"w");
	   if (outfile == NULL)
	   {
		   fprintf(stderr,"In getcoords3, unable to open the output file = %s \n",outfilestr);
		   exit(-1);
	   }

       endoffile=getline(file1,thisline);
	   nf=split_line(thisline);

       xsize = atof(str_array[0]);
       ysize = atof(str_array[1]); // $2

       endoffile=getline(file1,thisline);
	   nf=split_line(thisline);
       numpts = atoi(str_array[0]);  // $1
  
	   fclose(file1);

       CODE = 0;
       PANELSIZE =  306.8;    // 110000
       ACTIVEAREAX = activexval;    
	   ACTIVEAREAY = activeyval;
       XOFF = -(ACTIVEAREAX/2);            // half of activeareax
       YOFF = -(ACTIVEAREAY/2);            // half of activeareay 
       MMtoIN  = 25.4;

 // mult is a passed in variable if not provide then default of 4 
 if ( mult  >  0 )
 {
    multiplier = mult;
 }
 else{
    multiplier = 4;
 }
 
 PANELSIZE = PANELSIZE * pow(10,multiplier);
 // KERF is passed in parameter if not provided will be 0
 mymult = pow(10,multiplier);   // 10 **  multiplier;
 KERF = KERF * pow(10,multiplier); // 10  ** multiplier
 XOFF = XOFF * pow(10,multiplier);  // 10 ** multiplier
 YOFF = YOFF * pow(10,multiplier);   // 10 ** multiplier
 ACTIVEAREAX = ACTIVEAREAX * pow(10,multiplier); // 10 ** multiplier
 ACTIVEAREAY = ACTIVEAREAY * pow(10,multiplier); // 10 ** multiplier

 NumXparts = (int )( (ACTIVEAREAX+ KERF) / (xsize + KERF) );
 NumYparts = (int )( (ACTIVEAREAY+ KERF) / (ysize + KERF) );
 XDisplacement = xsize + KERF;
 YDisplacement = ysize + KERF;
 numpartfile=fopen("numparts","w");

 if (numpartfile == NULL)
	{
	 fprintf(stderr,"In getcoords, unable to open the numparts file for writine \n");
	 exit(-1);
 }

 fprintf(numpartfile,"%d\n%d\n", NumXparts, NumYparts); //  > "numparts"

 fclose(numpartfile);

 xstep = XDisplacement/mymult;
 ystep = YDisplacement/mymult;

 if( (xsize  > ACTIVEAREAX ) || ( ysize > ACTIVEAREAY) )
 {
   sprintf(outstring,"PART IS TOO BIG -- Xsize = %f Ysize =  %f \n",xsize,ysize);
   outerror( outstring );
   CODE = 255;
 }
 else if(  (xsize == ACTIVEAREAX) || (ysize == ACTIVEAREAY) ) 
 {
    fprintf(outfile, "0 0 \n");
    myx = 0;
    myy = 0;
    xstep = 0;
    ystep = 0;
    XFirst = 0;
    YFirst = 0;
    XTotalSize = NumXparts * (xsize + KERF) - KERF;   // count only KERFS between parts
    YTotalSize = NumYparts * (ysize + KERF) - KERF;
    outstep();
 }
 else
 {
    XTotalSize = NumXparts * (xsize + KERF) - KERF;
    YTotalSize = NumYparts * (ysize + KERF) - KERF;

   XFirst = (ACTIVEAREAX - XTotalSize)/2 + XOFF  + xsize/2;
   YFirst = (ACTIVEAREAY - YTotalSize)/2 + YOFF  + ysize/2;
   for( i = 0 ; i < NumXparts  ; i++ )
   {
     for( j = 0; j < NumYparts ; j++)
	 {
	   myx1 = XFirst + (XDisplacement * i);
	   myy1 = YFirst + (YDisplacement * j);
       fprintf(outfile,"%0.0f %0.0f\n",XFirst +(XDisplacement * i), YFirst +(YDisplacement * j));
     }
     if( i == 0)
	 {
         myx = myx1/mymult;
	     myy = myy1/mymult;
     }

  }
  fclose(outfile);
  outstep();
 } 
 return(CODE);

} 

//
//  getcoordsk  multstr specifies then 10^mult multiplier
//              kerfstr, specifies kerf width in tenths of centimeters?
//              infilestr, specifies input file, first line of which
//                has relevant information xsize, ysize
//
int getcoordsk_call(char *multstr, char *kerfstr,
					double activexval, double activeyval,
					char *infilestr)
{
char thisline[200];
int endoffile;
FILE *file1;

FILE *numpartfile;
int nf;

char outstring[200];

int numpts;
double PANELSIZE;
double ACTIVEAREAX;
double ACTIVEAREAY;
double XOFF;
double YOFF;

int CODE;
int i,j;
int mult;
int multiplier;
double KERF;
double XDisplacement;
double YDisplacement;
double XTotalSize;
double YTotalSize;
      
	   mult=atoi(multstr);
 
	   KERF=atof(kerfstr);

	   file1=fopen(infilestr,"r");
	   if (file1 == NULL)
	   {
		   fprintf(stderr,"In getcoords3, unable to open the input file = %s \n",infilestr);
		   exit(-1);
	   }


       endoffile=getline(file1,thisline);
	   nf=split_line(thisline);

       xsize = atof(str_array[0]);
       ysize = atof(str_array[1]); // $2

       endoffile=getline(file1,thisline);
	   nf=split_line(thisline);
       numpts = atoi(str_array[0]);  // $1
  
	   fclose(file1);

       CODE = 0;
       PANELSIZE =  306.8;    // 110000
       ACTIVEAREAX = activexval;    
	   ACTIVEAREAY = activeyval;
       XOFF = -(ACTIVEAREAX/2);            // half of activeareax
       YOFF = -(ACTIVEAREAY/2);            // half of activeareay 
      
       MMtoIN  = 25.4;

 // mult is a passed in variable if not provide then default of 4 
 if ( mult  >  0 )
 {
    multiplier = mult;
 }
 else{
    multiplier = 4;
 }
 
 PANELSIZE = PANELSIZE * pow(10,multiplier);
 // KERF is passed in parameter if not provided will be 0
 mymult = pow(10,multiplier);   // 10 **  multiplier;
 KERF = KERF * pow(10,multiplier); // 10  ** multiplier
 XOFF = XOFF * pow(10,multiplier);  // 10 ** multiplier
 YOFF = YOFF * pow(10,multiplier);   // 10 ** multiplier
 ACTIVEAREAX = ACTIVEAREAX * pow(10,multiplier); // 10 ** multiplier
 ACTIVEAREAY = ACTIVEAREAY * pow(10,multiplier); // 10 ** multiplier

 NumXparts = (int )( (ACTIVEAREAX+ KERF) / (xsize + KERF) );
 NumYparts = (int )( (ACTIVEAREAY+ KERF) / (ysize + KERF) );
 XDisplacement = xsize + KERF;
 YDisplacement = ysize + KERF;
 numpartfile=fopen("numparts","w");

 if (numpartfile == NULL)
	{
	 fprintf(stderr,"In getcoords, unable to open the numparts file for writine \n");
	 exit(-1);
 }

 fprintf(numpartfile,"%d\n%d\n", NumXparts, NumYparts); //  > "numparts"

 fclose(numpartfile);

 xstep = XDisplacement/mymult;
 ystep = YDisplacement/mymult;

 if( (xsize  > ACTIVEAREAX ) || ( ysize > ACTIVEAREAY) )
 {
   sprintf(outstring,"PART IS TOO BIG -- Xsize = %f Ysize =  %f \n",xsize,ysize);
   outerror( outstring );
   CODE = 255;
 }
 else if(  (xsize == ACTIVEAREAX) || (ysize == ACTIVEAREAY) ) 
 {
    printf("0 0 \n");
    myx = 0;
    myy = 0;
    xstep = 0;
    ystep = 0;
    XFirst = 0;
    YFirst = 0;
    XTotalSize = NumXparts * (xsize + KERF) - KERF;   // count only KERFS between parts
    YTotalSize = NumYparts * (ysize + KERF) - KERF;
    outstep();
 }
 else
 {
    XTotalSize = NumXparts * (xsize + KERF) - KERF;
    YTotalSize = NumYparts * (ysize + KERF) - KERF;

   XFirst = (ACTIVEAREAX - XTotalSize)/2 + XOFF  + xsize/2;
   YFirst = (ACTIVEAREAY - YTotalSize)/2 + YOFF  + ysize/2;
   for( i = 0 ; i < NumXparts  ; i++ )
   {
     for( j = 0; j < NumYparts ; j++)
	 {
	   myx1 = XFirst + (XDisplacement * i);
	   myy1 = YFirst + (YDisplacement * j);
       printf("%0.0f %0.0f\n",XFirst +(XDisplacement * i), YFirst +(YDisplacement * j));
     }
     if( i == 0)
	 {
         myx = myx1/mymult;
	     myy = myy1/mymult;
     }

  }
  
  outstep();
 } 
 return(CODE);

} 


int main( int argc, char **argv)
{
int retcode;

  retcode=getcoordsj_call( argv[1], argv[2], argv[3]);

  exit(retcode);

}

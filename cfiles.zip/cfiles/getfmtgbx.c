#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

FILE *file1;

char thisline[200];
char str_array[120][120];
int endoffile;


int xdefault;
int ydefault;
int Xmult;
int Ymult;
char xmultstr[120];
char ymultstr[120];
char tmp1[10][120];
char tmp2[10][120];
int code;

int flag;

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} 


void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk;

  ii=0;
  kk = 0;

 while((instr[ii] != srchstr[0]) && ( ii < strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;


}  // end split


// perform awk compatible substr, except the 4th parameter is the
//   result string
//
void awk_substr( char *instr, int sbegin, int slength, char *resultstr)
{

char tstr[120];
int kk;
int ll;

     if ( sbegin > 0)
	 {
		 sbegin = sbegin-1;
	 }
     kk = sbegin;
     ll = 0;
	 while ( ( kk < strlen(instr) && ( ll < slength)) )
	 {
		 tstr[ll] = instr[kk];
		 kk += 1;
		 ll  += 1;
	 }
	 tstr[ll]=0;

	 strncpy( resultstr,tstr,slength+2);

}   // awk substr


int getfmtgbx_call ( char *flagstr, char *infilestr)
{
  flag = atoi(flagstr);

  file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: In getfmtgbx, unable to open input file = %s \n",infilestr);
	  exit(-1);
	}

  xdefault = 5;
  ydefault = 5;
  strncpy(xmultstr,"-1",20);
  strncpy(ymultstr,"-1",20);

     code = 0;

   endoffile=getline(file1,thisline);

   while(endoffile == FALSE)
    {
	   // look for %FSXnnYnn
	   //  nn is 2 digits, first specifies integer width, second is number decimal
	   //          places to the right of the decimal point
	   //
    if(( strstr(thisline,"%")!= NULL) && (strstr(thisline,"FS") != NULL ) )
     {
      split(thisline,tmp1[0],tmp1[1],"FS");
	  tmp2[0][0]=0;
	  tmp2[1][0]=0;

      split(tmp1[1],tmp2[0],tmp2[1],"X");
      if (strlen(tmp2[1]) > 0 )            // Something beyond the X
	  {
          awk_substr(tmp2[1],2,1,xmultstr);
         }
      tmp2[0][0]=0;
	  tmp2[1][0]=0;
      split(tmp1[1],tmp2[0],tmp2[1],"Y");

     if( strlen(tmp2[1]) > 0)   // Something beyond Y
      {
       awk_substr(tmp2[1],2,1,ymultstr);
       }
    }
   endoffile=getline(file1,thisline);

  }
  fclose(file1);

  Xmult = atoi(xmultstr);
  Ymult = atoi(ymultstr);

  if( (Xmult != xdefault) || (Ymult != ydefault) )
   {
   code = 255;
  }
  // flag is a passed in variable
  if (flag == 1)
    printf("%s %s",xmultstr,ymultstr); // Xmult " " Ymult

  return(code);

}

/*
int main( int argc, char **argv)
{
int retval;

    if (argc != 3)
	{
		printf("In getfmtgbx, wrong number of arguments \n");
		printf("Usage: getfmtgbx flag infile \n");
		printf(" flag =1 prints out the XMULT and YMULT values, otherwise set flag=0 \n");
		exit(-1);
	}
	else
	{ 
    retval=getfmtgbx_call( argv[1], argv[2]);
	}

	exit(retval);
}

  */

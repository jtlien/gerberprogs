#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


#define MAXARRAY 10000

char x[MAXARRAY][40];
char y[MAXARRAY][40];

// getlabelcoords reads in the partcoords file ( created by getcoords3 and
//             getpcmkerf11) 
//           It will use the first line of partcoords as the base for x and y
//           It will output to the output file all the coordinants that match either this
//              X base or this Y base
//           The X's that match are put out first 
//           then the Y's that match


void getlabelcoords_call_out( char *file1str, char *outfilestr)
 {
int xcnt;
int ycnt;
char XBASE[120];
char YBASE[120];
char thisline[200];
int endoffile;
int nf;
FILE *file1;
FILE *outfile;
int i;

   file1  = fopen(file1str, "r");

   if (file1 == NULL)
   {
	  printf("Error: In getlabelcoords, unable to open input file = %s \n",file1str);
	  exit(-1);
   }
   outfile = fopen(outfilestr, "w");

   if (file1 == NULL)
   {
	  printf("Error: In getlabelcoords, unable to open the output file = %s \n",outfilestr);
	  exit(-1);
   }
    endoffile=getline(file1,thisline);
    nf=split_line(thisline);

    // getline   get first part coor.
    strncpy(XBASE,str_array[0],120);
    strncpy(YBASE,str_array[1],120); 
    xcnt = 0;
    ycnt = 0;
    strncpy(x[xcnt],XBASE,120);  //
    strncpy(y[ycnt],YBASE,120);   //
    xcnt++;
    ycnt++;

    // end of BEGIN

    endoffile=getline(file1,thisline);
    nf=split_line(thisline);

    while(endoffile==FALSE)
    {
      if(strcmp(str_array[0],XBASE) == 0)
	{
	  if (ycnt < MAXARRAY)
	    {
	     strncpy(y[ycnt],str_array[1],40);
	     ycnt++;
            }
          else
	    {
              printf("array size exceeded in getlabelcoords \n");
              exit(-1);
            }
      }
      if( strcmp(str_array[1],YBASE)== 0 )
	  {
	   if (xcnt < MAXARRAY)
	    {
	     strncpy(x[xcnt],str_array[0],40); 
	     xcnt++;
            }
       else
            {
              printf("array size exceeded in getlabelcoords \n");
              exit(-1);
            }
       }
      endoffile=getline(file1,thisline);
      nf=split_line(thisline);
    }
   fclose(file1);

   for( i = 0; i < xcnt ; i++)
     {
       fprintf(outfile,"X %s \n", x[i]);
     }

   for( i = ycnt -1 ; i >= 0  ; i--)
     {
       fprintf(outfile,"Y %s\n",y[i]);
     }

   fclose(outfile);

 }  // end getlabelcoords_call_out


void getlabelcoords_call( char *file1str)
 {
int xcnt;
int ycnt;
char XBASE[120];
char YBASE[120];
char thisline[200];
int endoffile;
int nf;
FILE *file1;
int i;

   file1  = fopen(file1str, "r");

   if (file1 == NULL)
   {
	  printf("Error: In getlabelcoords, unable to open input file = %s \n",file1str);
	  exit(-1);
   }

    endoffile=getline(file1,thisline);
    nf=split_line(thisline);

    // getline   get first part coor.
    strncpy(XBASE,str_array[0],120);
    strncpy(YBASE,str_array[1],120); 
    xcnt = 0;
    ycnt = 0;
    strncpy(x[xcnt],XBASE,120);  //
    strncpy(y[ycnt],YBASE,120);   //
    xcnt++;
    ycnt++;

    // end of BEGIN

    endoffile=getline(file1,thisline);
    nf=split_line(thisline);

    while(endoffile==FALSE)
    {
      if(strcmp(str_array[0],XBASE) == 0)
	{
	  if (ycnt < MAXARRAY)
	    {
	     strncpy(y[ycnt],str_array[1],40);
	     ycnt++;
            }
          else
	    {
              printf("array size exceeded in getlabelcoords \n");
              exit(-1);
            }
      }
      if( strcmp(str_array[1],YBASE)== 0 )
	  {
	   if (xcnt < MAXARRAY)
	    {
	     strncpy(x[xcnt],str_array[0],40); 
	     xcnt++;
            }
       else
            {
              printf("array size exceeded in getlabelcoords \n");
              exit(-1);
            }
       }
      endoffile=getline(file1,thisline);
      nf=split_line(thisline);
    }
   fclose(file1);

   for( i = 0; i < xcnt ; i++)
     {
       printf("X %s \n", x[i]);
     }

   for( i = ycnt -1 ; i >= 0  ; i--)
     {
       printf("Y %s\n",y[i]);
     }

 }  // end getlabelcoords_call

/*
int main( int argc, char **argv)
{

  if (argc != 2 )
  {
    printf("In getlabelcoords, wrong number of arguments \n");
	printf("Usage: getlabelcoords infile \n");
	exit(-1);
   }
  else
  {
  getlabelcoords_call( argv[1]);
  }
}  
*/

  

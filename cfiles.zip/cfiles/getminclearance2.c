#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

FILE *file1,*file2,*file3;

int MIN;
int PCM;
int MAX;
int REL;
int CORE;
int REL1;
int col;
char msg[40];
char tstr[100];
char value[10][200];
int tmp;
int i;
int k;

int endoffile;
char str_array[120][120];
char thisline[200];
int nf;


struct default_stuff
{
	int value;
	char layer[60];

}  default_array[1000];

int default_count;

struct relief_stuff
{

	 int value;
	 char layer[60];

}  relief[1000];

int relief_count;

struct minrelief_stuff
{

	 int value;
	 char layer[60];

}  minrelief[1000];

int minrelief_count;

void add_to_default( char *instr, int inval)
{
int kk;
char tmpstr[120];
  
    strncpy(tmpstr,instr,120);
	for(kk=0; kk < strlen(instr); kk += 1)
	{
		tmpstr[kk]=toupper(tmpstr[kk]);
	}
	if (default_count < 1000)
	{
	 strncpy(default_array[default_count].layer,tmpstr,60);
	 default_array[default_count].value=inval;
	 default_count += 1;
	}
   else
   {
	   printf("In get min clearance, default array index too large \n");
   }
}

void add_to_relief( char *instr, int inval)
{
int kk;
char tmpstr[120];
  
    strncpy(tmpstr,instr,120);
	for(kk=0; kk < strlen(instr); kk += 1)
	{
		tmpstr[kk]=toupper(tmpstr[kk]);
	}
	if (relief_count < 1000)
	{
	 strncpy(relief[relief_count].layer,tmpstr,60);
	 relief[relief_count].value=inval;
	 relief_count += 1;
	}
   else
   {
	   printf("In get min clearance, relief array index too large \n");
   }
}

// subtract off the offset
//


void  update_relief( char *instr, int inval)
{
int kk;
char tmpstr[120];
int jj;

     strncpy(tmpstr,instr,120);
	 for(kk=0;kk<strlen(tmpstr); kk += 1)
	 {
		 tmpstr[kk]=toupper(tmpstr[kk]);
	 }
	 jj=0;
	 while(jj< relief_count )
	 {
		 if (strcmp(tmpstr,relief[jj].layer) == 0 )
		 {
			 relief[jj].value=relief[jj].value-inval;
		 }
	   jj += 1;
	 }

   if ( jj==relief_count)
   {
	   printf("error in getminclearance2\n");
   }

}

void add_to_minrelief( char *instr, int inval)
{
int kk;
char tmpstr[120];
  
    strncpy(tmpstr,instr,120);
	for(kk=0; kk < strlen(instr); kk += 1)
	{
		tmpstr[kk]=toupper(tmpstr[kk]);
	}
	if (minrelief_count < 1000)
	{
	 strncpy(minrelief[minrelief_count].layer,tmpstr,60);
	 minrelief[minrelief_count].value=inval;
	 minrelief_count += 1;
	}
   else
   {
	   printf("In get min clearance, minrelief array index too large \n");
   }
}


int find_in_default( char *instr)
{
int kk;
char tmpstr[120];
int jj;

     strncpy(tmpstr,instr,120);
	 for(kk=0;kk<strlen(tmpstr); kk += 1)
	 {
		 tmpstr[kk]=toupper(tmpstr[kk]);
	 }
	 jj=0;
	 while(jj< relief_count )
	 {
		 if (strcmp(tmpstr,default_array[jj].layer) == 0 )
		 {
			 return(default_array[jj].value);
		 }
	   jj += 1;
	 }

   return(0);
}

int find_in_relief( char *instr)
{
int kk;
char tmpstr[120];
int jj;

     strncpy(tmpstr,instr,120);
	 for(kk=0;kk<strlen(tmpstr); kk += 1)
	 {
		 tmpstr[kk]=toupper(tmpstr[kk]);
	 }
	 jj=0;
	 while(jj< relief_count )
	 {
		 if (strcmp(tmpstr,relief[jj].layer) == 0 )
		 {
			 return(relief[jj].value);
		 }
	   jj += 1;
	 }

   return(0);
}

int find_in_minrelief( char *instr)
{
int kk;
char tmpstr[120];
int jj;

     strncpy(tmpstr,instr,120);
	 for(kk=0;kk<strlen(tmpstr); kk += 1)
	 {
		 tmpstr[kk]=toupper(tmpstr[kk]);
	 }
	 jj=0;
	 while(jj< relief_count )
	 {
		 if (strcmp(tmpstr,minrelief[jj].layer) == 0 )
		 {
			 return(minrelief[jj].value);
		 }
	   jj += 1;
	 }

   return(0);
}


// split a string in two pieces

void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk;

  ii=0;
  kk = 0;

 while((instr[ii] != srchstr[0]) && ( ii < strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;


}  // end split

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line


//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

void getminclearance2_call(char *pcmstr, char *relstr,
						   char *file1str, char *file2str, char *file3str)
{

	file1 = fopen( file1str,"r");
	file2 = fopen( file2str,"r");

      MIN = 75;
      MAX = 280;
     // REL=atoi(argv[1]);
     // PCM=atoi(argv[2]);
     // CORE=atoi(argv[3]);

      REL1 = atoi(relstr) * 2; // REL *2;

      // default values based on Cobalt product(98244) 

	  default_count =0;

      add_to_default("L03",180);
      add_to_default("CORE",140);
      add_to_default("L04",180);


       // Set to bogus values 

	  relief_count=0;

      add_to_relief("L03",9999);
      add_to_relief("CORE",9999);
      add_to_relief("L04",9999);
    
       // read in cd.txt file 

     endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

     while(endoffile==FALSE)
	 {
       if( strstr(thisline,"layer") != NULL)   // found a line with layer
	   {
           if ( strcmp(str_array[2],"drawn") == 0)
		   { 
	        col = 4;
           }
           else
		   { 
	         col = 3;
           }
       }
       for(k=0;k<strlen(str_array[1]);k+=1)
	   {
	   tstr[k]= toupper( str_array[1][k] );
        }
	   tstr[strlen(str_array[1])]=0;

       if(strcmp(tstr,"RELIEF") == 0 ) 
	   {
           split(str_array[col-1],value[0],value[1],"u");
           if (atoi(value[0]) <  find_in_relief(str_array[0]))
		   {
              add_to_relief(str_array[0],atoi(value[0]));
           }
       }

      endoffile=getline(file1,thisline);
	  nf=split_line(thisline);

     }

	 fclose(file1);

     //  read in min_clearance.txt file

	 endoffile=getline(file2,thisline);
	 nf=split_line(thisline);

	 minrelief_count=0;

     while( endoffile==FALSE)
	 {
        add_to_minrelief(str_array[0],atoi(str_array[1]) ) ; // $2;

		getline(file2,thisline);
		nf=split_line(thisline);
     }

     fclose(file2);

    endoffile = getline(file1,thisline);
    nf=split_line(thisline);

   while( endoffile == FALSE)
   {
    // process the the OFFSETS file
    if(strstr(thisline,"Clearance")!= NULL)
	{
     update_relief(str_array[0],atoi(str_array[1])); //  - $2;
	}
    endoffile = getline(file3,thisline);
    nf=split_line(thisline);

   } 
   fclose(file3);

  //  check & output the minclearances here
  

   while(i < relief_count)
   {
     if( relief[i].value != 9999 )
	 {
         if( (relief[i].value /1000 )!= find_in_minrelief(relief[i].layer))
		 {
           printf("%s  Design = %d   Cam = %d\n",i,relief[i].value,minrelief[i]);
	       exit(99);
         }
         tmp = relief[i].value + REL1;
         if(tmp < MIN)
		 {
	      tmp = MIN;
	       strncpy(msg,"# Set to MIN",40);
         }
         if(tmp  > MAX)
		 {
	       tmp = MAX;
           strncpy( msg,"#Set to MAX",40);
         }
         printf("%s %.4f %s\n",i, (tmp )/1000,msg);
     }
     else if(( strcmp(pcmstr,"7layer") == 0) || 
      ((strcmp(relief[i].layer,"CORE")==0) && (strcmp(pcmstr,"5layer")== 0)))
	 {
       tmp = find_in_default( relief[i].layer);
       strncpy(msg,"#Set to Nominal",40);
        printf("%d %.4f %s\n",i, (tmp )/1000,msg);
     }
  }
 i+=1;
}

int main(int argc, char **argv)
{


    getminclearance2_call( argv[1], argv[2], argv[3], argv[4], argv[5]);

}  // end main
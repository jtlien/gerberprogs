
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// get the ADD numbers from a file, using an output file

void getnum_call_out( char *infile, char *outfile)
{

char foo[10][120];
int endoffile;
FILE *file1;
FILE *file2;
char thisline[200];
int kk;
char *sptr;

 file1=fopen(infile,"r");
 if (file1 == NULL)
 {
	 printf("Unable to open the input file = %s \n",infile);
	 exit(-1);
 }

 file2=fopen(outfile,"w");
 if (file2 == NULL)
 {
	 printf("Unable to open the output file = %s \n",outfile);
	 exit(-1);
 }
 endoffile = getline(file1,thisline);

 while(endoffile==FALSE)
 {
    if ( strstr( thisline,"DD") != NULL) 
	{
	  sptr=strstr(thisline,"DD");
	  sptr++;
	  sptr++;
	  kk=0;
	  while(( isdigit(*sptr) && ( kk < 300))
	  {
		  tmpstr[kk]=*sptr;
		  sptr++;
	  }
	  tmpstr[kk]='\0';

	  fprintf(outfile,"%s\n",tmpstr);
	}
	else
	{
		printf(outfile,"0\n");
	}

	endoffile=getline(file1,thisline);
 }
 
 fclose(file1);
 fclose(file2);

} // end getnum_call

// get the ADD numbers from a file

void getnum_call( char *infile)
{

char foo[10][120];
int endoffile;
FILE *file1;
char thisline[200];
int kk;
char *sptr;

 file1=fopen(infile,"r");
 if (file1 == NULL)
 {
	 printf("Unable to open the input file = %s \n",infile);
	 exit(-1);
 }

 endoffile = getline(file1,thisline);

 while(endoffile==FALSE)
 {
    if ( strstr( thisline,"DD") != NULL) 
	{
	  sptr=strstr(thisline,"DD");
	  sptr++;
	  sptr++;
	  kk=0;
	  while(( isdigit(*sptr) && ( kk < 300))
	  {
		  tmpstr[kk]=*sptr;
		  sptr++;
	  }
	  tmpstr[kk]='\0';

	  printf("%s\n",tmpstr);
	}
	else
	{
		printf("0\n");
	}

	endoffile=getline(file1,thisline);
 }

 fclose(file1);

} // end getnum_call



int main( int argc, char **argv)
{

	if (argc != 2)
	{
		printf("In getnum, wrong number of arguments \n");
		printf("Usage: getnum infile \n");
		exit(-1);
	}
    else
	{
    getnum_call( argv[1]);

	}

}  // end main
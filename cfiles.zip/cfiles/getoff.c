
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define MAXARRAY 200000

double x[MAXARRAY];
double y[MAXARRAY];
char str_array[120][120];


void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk;

  ii=0;
  kk = 0;

 while((instr[ii] != srchstr[0]) && ( ii < strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;


}  // end split

//
// perform awk compatible awk_index, counts from 1 at the leftmost
//
int awk_index( char *instr, char *inchr)
{
int kk,ll,mm;
char tstr[120];

	if (strstr(instr, inchr) == NULL)    // not found at all in string, return 0
	{
		return(0);
	}
	else    // the inchr string is a strstring
	{
		kk = 0;
		while( kk < strlen( instr))
		{
          ll = 0;
		  mm = kk;
		  while( mm < strlen( instr))
		  {
			tstr[ll] = instr[mm];
			mm += 1;
			ll += 1;
		  }
		  tstr[ll] = 0;
		  if (strstr( tstr,inchr) == NULL)  // no longer found as strstring
		  {
			return(kk);
		  }
		 kk += 1;
		}
	}

  return(0);

 
} // awk compatible index


// perform awk compatible substr, except the 4th parameter is the
//   result string
//
void awk_substr( char *instr, int sbegin, int slength, char *resultstr)
{

char tstr[120];
int kk;
int ll;

     if ( sbegin > 0)
	 {
		 sbegin = sbegin-1;
	 }
     kk = sbegin;
     ll = 0;
	 while ( ( kk < strlen(instr) && ( ll < slength)) )
	 {
		 tstr[ll] = instr[kk];
		 kk += 1;
		 ll  += 1;
	 }
	 tstr[ll]=0;

	 strncpy( resultstr,tstr,slength+2);

}   // awk substr

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

//
//  call interface to getoffset, write to stdout
//
void getoffset_call( char *infilestr)
{

int cnt;
int i;
int endoffile;
char X[200];
char Y[200];
char a[10][200];
char b[10][200];
char c[10][200];
int val;
FILE *file1;
FILE *partsizefile;
FILE *offvalfile;
double xmin;
double ymin;
double xmax;
double ymax;
char thisline[200];

  cnt = 0;
  file1=fopen(infilestr,"r");
   if ( file1 == NULL)
   {
	   printf("In getoffset, unable to create the input file = %s \n",infilestr);
	   exit(-1);
   }
  endoffile=getline(file1,thisline);

  while(endoffile==FALSE)
  {
   if ( (strstr(thisline,"X") != NULL) && 
	   (strstr(thisline,"Y") != NULL) && 
	   (strstr(thisline,"G54") == NULL))    // $0 ~/X/ && $0 ~/Y/  &&  $0 !~/G54/)
   {
       split(thisline,a[0],a[1],"Y");

       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X);
       awk_substr( a[1],1,strlen(a[1]) -4, Y);
//       printf("%s %s\n", X,Y)
	   if (cnt < MAXARRAY)
	   {
        x[cnt] = atof(X);
        y[cnt] = atof(Y);
        cnt++;
	   }
	   else
	   {
		   printf("In getoffset, array size exceeded \n");
		   exit(-1);
	   }

   }
   else if( (strstr(thisline,"Y") == NULL) &&
	       (strstr(thisline,"X") != NULL) )   //  $0 !~ /Y/ && $0 ~/X/ )
   {
      split(thisline,b[0],b[1],"X");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
//       printf("%s  %s\n", X,Y)
	  if (cnt < MAXARRAY)
	  {
       x[cnt] = atof(X);
       y[cnt] = atof(Y);
       cnt++;
	  }
	  else
	  {   
		  printf("In getoffset, array size exceeded \n");
		   exit(-1);
	   }
   }
   else if( (strstr(thisline,"X") == NULL) && 
	        (strstr(thisline,"Y") != NULL) )     // $0 !~ /X/ && $0 ~/Y/ )
   {
      split(thisline,c[0],c[1],"Y");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
//      printf("%s %s\n", X,Y)
	  if ( cnt < MAXARRAY)
	  {
       x[cnt] = atof(X);
       y[cnt] = atof(Y);
       cnt++;
	  }
	  else
	  {   
		  printf("In getoffset, array size exceeded \n");
		   exit(-1);
	   }
   }
   endoffile=getline(file1,thisline);
  
  }
  fclose(file1);

   ymin= y[0];  // so items will be treated as numbers NOT STRINGS
   ymax= y[0]; 
   xmin= x[0]; 
   xmax= x[0]; 

   for(i = 1; i < cnt; i++)
   {
     if( x[i]    > xmax )
	 {
	 xmax = x[i];
     }
     else if( x[i]   < xmin )
	 {
	 xmin = x[i];
     }
   }

   for(i = 1; i < cnt; i++)
   {
     if( y[i]   > ymax )
	 {
	 ymax = y[i];
     }
     else if( y[i]   < ymin )
	 {
	 ymin = y[i]; 
     }
   }
   printf("%0.0f\n",xmin);
   printf("%0.0f\n",xmax);
   printf("%0.0f\n",ymin);
   printf("%0.0f\n",ymax);

   partsizefile=fopen("partsize","w");
   if ( partsizefile == NULL)
   {
	   printf("In getoffset, unable to create the output file = partsize \n");
	   exit(-1);
   }
   offvalfile=fopen("offval1","w");
   if ( offvalfile == NULL)
   {
	   printf("In getoffset, unable to create the output file = offval1 \n");
	   exit(-1);
   }
   fprintf(partsizefile,"%0.0f %0.0f\n", xmax - xmin , ymax - ymin ); //  > "partsize" 
   fprintf(partsizefile,"%d\n", cnt ); // > "partsize"
   fprintf(offvalfile,"%0.0f %0.0f",(xmax + xmin)/-2  , (ymax + ymin)/-2); // > "offval1"

   fclose(partsizefile);
   fclose(offvalfile);

} // end getoffset_call

//
//  call interface to getoffset, write to stdout
//
void getoffset_call_out( char *infilestr, char *outfilestr)
{

int cnt;
int i;
int endoffile;
char X[200];
char Y[200];
char a[10][200];
char b[10][200];
char c[10][200];
int val;
FILE *file1;
FILE *partsizefile;
FILE *offvalfile;
FILE *outfile;

double xmin;
double ymin;
double xmax;
double ymax;
char thisline[200];

  cnt = 0;
  file1=fopen(infilestr,"r");
   if ( file1 == NULL)
   {
	   printf("In getoffset, unable to create the input file = %s \n",infilestr);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"w");
   if ( outfile == NULL)
   {
	   printf("In getoffset, unable to create the output file = %s \n",outfilestr);
	   exit(-1);
   }

  endoffile=getline(file1,thisline);

  while(endoffile==FALSE)
  {
   if ( (strstr(thisline,"X") != NULL) && 
	   (strstr(thisline,"Y") != NULL) && 
	   (strstr(thisline,"G54") == NULL))    // $0 ~/X/ && $0 ~/Y/  &&  $0 !~/G54/)
   {
       split(thisline,a[0],a[1],"Y");

       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X);
       awk_substr( a[1],1,strlen(a[1]) -4, Y);
//       printf("%s %s\n", X,Y)
	   if (cnt < MAXARRAY)
	   {
        x[cnt] = atof(X);
        y[cnt] = atof(Y);
        cnt++;
	   }
	   else
	   {
		   printf("In getoffset, array size exceeded \n");
		   exit(-1);
	   }

   }
   else if( (strstr(thisline,"Y") == NULL) &&
	       (strstr(thisline,"X") != NULL) )   //  $0 !~ /Y/ && $0 ~/X/ )
   {
      split(thisline,b[0],b[1],"X");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
//       printf("%s  %s\n", X,Y)
	  if (cnt < MAXARRAY)
	  {
       x[cnt] = atof(X);
       y[cnt] = atof(Y);
       cnt++;
	  }
	  else
	  {   
		  printf("In getoffset, array size exceeded \n");
		   exit(-1);
	   }
   }
   else if( (strstr(thisline,"X") == NULL) && 
	        (strstr(thisline,"Y") != NULL) )     // $0 !~ /X/ && $0 ~/Y/ )
   {
      split(thisline,c[0],c[1],"Y");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
//      printf("%s %s\n", X,Y)
	  if ( cnt < MAXARRAY)
	  {
       x[cnt] = atof(X);
       y[cnt] = atof(Y);
       cnt++;
	  }
	  else
	  {   
		  printf("In getoffset, array size exceeded \n");
		   exit(-1);
	   }
   }
   endoffile=getline(file1,thisline);
  
  }
  fclose(file1);

   ymin= y[0];  // so items will be treated as numbers NOT STRINGS
   ymax= y[0]; 
   xmin= x[0]; 
   xmax= x[0]; 

   for(i = 1; i < cnt; i++)
   {
     if( x[i]    > xmax )
	 {
	 xmax = x[i];
     }
     else if( x[i]   < xmin )
	 {
	 xmin = x[i];
     }
   }

   for(i = 1; i < cnt; i++)
   {
     if( y[i]   > ymax )
	 {
	 ymax = y[i];
     }
     else if( y[i]   < ymin )
	 {
	 ymin = y[i]; 
     }
   }
   fprintf(outfile,"%0.0f\n",xmin);
   fprintf(outfile,"%0.0f\n",xmax);
   fprintf(outfile,"%0.0f\n",ymin);
   fprintf(outfile,"%0.0f\n",ymax);

   fclose(outfile);

   partsizefile=fopen("partsize","w");
   if ( partsizefile == NULL)
   {
	   printf("In getoffset, unable to create the output file = partsize \n");
	   exit(-1);
   }
   offvalfile=fopen("offval1","w");
   if ( offvalfile == NULL)
   {
	   printf("In getoffset, unable to create the output file = offval1 \n");
	   exit(-1);
   }
   fprintf(partsizefile,"%0.0f %0.0f\n", xmax - xmin , ymax - ymin ); //  > "partsize" 
   fprintf(partsizefile,"%d\n", cnt ); // > "partsize"
   fprintf(offvalfile,"%0.0f %0.0f",(xmax + xmin)/-2  , (ymax + ymin)/-2); // > "offval1"

   fclose(partsizefile);
   fclose(offvalfile);
   
} // end getoffset_call_out

int main( int argc, char **argv)

{

	 getoffset_call( argv[1]);

}
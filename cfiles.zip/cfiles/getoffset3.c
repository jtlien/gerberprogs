
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


//
//  call interface to getoffset, write to stdout
//
void getoffset3_call( char *infilestr)
{
int cnt;
int endoffile;
char X[200];
char Y[200];
char a[10][200];
char b[10][200];
char c[10][200];
int val;
FILE *file1;
FILE *partsizefile;
FILE *offvalfile;
double xmin;
double ymin;
double xmax;
double ymax;
double xval;
double yval;

int first;
char thisline[200];


  first=0;
  cnt=0;
  file1=fopen(infilestr,"r");
   if ( file1 == NULL)
   {
	   printf("In getoffset, unable to create the input file = %s \n",infilestr);
	   exit(-1);
   }
  endoffile=getline(file1,thisline);

  while(endoffile==FALSE)
  {
   if ( (strstr(thisline,"X") != NULL) && 
	   (strstr(thisline,"Y") != NULL) && 
	   (strstr(thisline,"G54") == NULL) &&
	   (strstr(thisline,"G04")==NULL) &&
	   (strstr(thisline,"%")==NULL) )    // $0 ~/X/ && $0 ~/Y/  &&  $0 !~/G54/)
   {
       split(thisline,a[0],a[1],"Y");

       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X);
	   if (strstr(a[1],"D")!=NULL)
	   {
         awk_substr( a[1],1,strlen(a[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( a[1],1,strlen(a[1]) -1, Y);    // no D
	   }
//       printf("%s %s\n", X,Y)
	   xval=atof(X);
	  yval=atof(Y);
	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   else if( (strstr(thisline,"Y") == NULL) &&
	       (strstr(thisline,"X") != NULL) &&
		   (strstr(thisline,"G54") == NULL) &&
	       (strstr(thisline,"G04")==NULL) &&
	       (strstr(thisline,"%")==NULL) )   //  $0 !~ /Y/ && $0 ~/X/ )
   {
      split(thisline,b[0],b[1],"X");
	  if (strstr(b[1],"D")!=NULL)
	   {
         awk_substr( b[1],1,strlen(b[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( b[1],1,strlen(b[1]) -1, Y);    // no D
	   }
//       printf("%s  %s\n", X,Y)
	  xval=atof(X);
	  yval=atof(Y);
	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   else if( (strstr(thisline,"X") == NULL) && 
	        (strstr(thisline,"Y") != NULL) &&
			(strstr(thisline,"G54") == NULL) &&
	        (strstr(thisline,"G04")==NULL) &&
	        (strstr(thisline,"%")==NULL)   )     // $0 !~ /X/ && $0 ~/Y/ )
   {
      split(thisline,c[0],c[1],"Y");
	  if (strstr(c[1],"D")!=NULL)
	   {
         awk_substr( c[1],1,strlen(c[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( c[1],1,strlen(c[1]) -1, Y);    // no D
	   }
      
//      printf("%s %s\n", X,Y)
	  xval=atof(X);
	  yval=atof(Y);
	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   endoffile=getline(file1,thisline);
  
  }
  fclose(file1);

   
   printf("%0.0f\n",xmin);
   printf("%0.0f\n",xmax);
   printf("%0.0f\n",ymin);
   printf("%0.0f\n",ymax);

   partsizefile=fopen("partsize","w");
   if ( partsizefile == NULL)
   {
	   printf("In getoffset, unable to create the output file = partsize \n");
	   exit(-1);
   }
   offvalfile=fopen("offval1","w");
   if ( offvalfile == NULL)
   {
	   printf("In getoffset, unable to create the output file = offval1 \n");
	   exit(-1);
   }
   fprintf(partsizefile,"%0.0f %0.0f\n", xmax - xmin , ymax - ymin ); //  > "partsize" 
   fprintf(partsizefile,"%d\n", cnt ); // > "partsize"
   fprintf(offvalfile,"%0.0f %0.0f",(xmax + xmin)/-2  , (ymax + ymin)/-2); // > "offval1"

   fclose(partsizefile);
   fclose(offvalfile);

} // end getoffset3_call

//
//  call interface to getoffset, write to stdout
//
void getoffset3_call_out( char *infilestr, char *outfilestr)
{

int cnt;
int endoffile;
char X[200];
char Y[200];
char a[10][200];
char b[10][200];
char c[10][200];
int val;
FILE *file1;
FILE *partsizefile;
FILE *offvalfile;
FILE *outfile;
int first;

double xval;
double yval;
double xmin;
double ymin;
double xmax;
double ymax;
char thisline[200];

  cnt = 0;
  first=0;
  file1=fopen(infilestr,"r");
   if ( file1 == NULL)
   {
	   printf("In getoffset, unable to create the input file = %s \n",infilestr);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"w");
   if ( outfile == NULL)
   {
	   printf("In getoffset, unable to create the output file = %s \n",outfilestr);
	   exit(-1);
   }

  endoffile=getline(file1,thisline);

  while(endoffile==FALSE)
  {
   if ( (strstr(thisline,"X") != NULL) && 
	   (strstr(thisline,"Y") != NULL) && 
	   (strstr(thisline,"G54") == NULL))    // $0 ~/X/ && $0 ~/Y/  &&  $0 !~/G54/)
   {
       split(thisline,a[0],a[1],"Y");

       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X);
       awk_substr( a[1],1,strlen(a[1]) -4, Y);
//       printf("%s %s\n", X,Y)
	  
	    xval=atof(X);
	  yval=atof(Y);
	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   else if( (strstr(thisline,"Y") == NULL) &&
	       (strstr(thisline,"X") != NULL) )   //  $0 !~ /Y/ && $0 ~/X/ )
   {
      split(thisline,b[0],b[1],"X");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
//       printf("%s  %s\n", X,Y)
	  xval=atof(X);
	  yval=atof(Y);
	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   else if( (strstr(thisline,"X") == NULL) && 
	        (strstr(thisline,"Y") != NULL) )     // $0 !~ /X/ && $0 ~/Y/ )
   {
      split(thisline,c[0],c[1],"Y");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
//      printf("%s %s\n", X,Y)
	    xval=atof(X);
	  yval=atof(Y);
	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   endoffile=getline(file1,thisline);
  
  }
  fclose(file1);

   
   fprintf(outfile,"%0.0f\n",xmin);
   fprintf(outfile,"%0.0f\n",xmax);
   fprintf(outfile,"%0.0f\n",ymin);
   fprintf(outfile,"%0.0f\n",ymax);

   fclose(outfile);

   partsizefile=fopen("partsize","w");
   if ( partsizefile == NULL)
   {
	   printf("In getoffset, unable to create the output file = partsize \n");
	   exit(-1);
   }
   offvalfile=fopen("offval1","w");
   if ( offvalfile == NULL)
   {
	   printf("In getoffset, unable to create the output file = offval1 \n");
	   exit(-1);
   }
   fprintf(partsizefile,"%0.0f %0.0f\n", xmax - xmin , ymax - ymin ); //  > "partsize" 
   fprintf(partsizefile,"%d\n", cnt ); // > "partsize"
   fprintf(offvalfile,"%0.0f %0.0f",(xmax + xmin)/-2  , (ymax + ymin)/-2); // > "offval1"

   fclose(partsizefile);
   fclose(offvalfile);
   
} // end getoffset3_call_out

/*
int main( int argc, char **argv)

{
  if (argc != 2 )
  {
    printf("In getoffset3, wrong number of arguments \n");
	printf("Usage: getoffset3 infile \n");
	exit(-1);
   }
  else
  {
	 getoffset3_call( argv[1]);

  }
}  
  

*/

  

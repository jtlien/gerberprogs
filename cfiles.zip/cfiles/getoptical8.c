#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


char str_array[120][120];


int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line


//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline


void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk;

  ii=0;
  kk = 0;

 while((instr[ii] != srchstr[0]) && ( ii < strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;


}  // end split

void getoptical8_call_out( char *file1str, char *outfilestr)
{

FILE *rfile0, *rfile1, *rfile2, *rfile3;
FILE *subfile, *file1, *maskfile, *viamaskfile;
FILE *outfile;
int myindex;
char thisline[200];

int kk;
char name[120][120];
char subfilestr[120];
int number_fields;
int romanYcoord[10];
int YCOORDS[10];
char rfilestr[120];
char fname[120];
char rname[120][40];
int endoffile;
char maskfilestr[120];
char viamaskfilestr[120];


     // Xright = 1543050
     // Xleft =  -1 * Xright

      YCOORDS[1] = 222250;
      YCOORDS[2] = 95250;
      YCOORDS[3] = -31750;
      YCOORDS[0] = -158750;

      romanYcoord[1] = 190500;
      romanYcoord[2] = 63500;
      romanYcoord[3] = -63500;
      romanYcoord[0] = -190500;

     strncpy(rname[1],"roman1",30);
     strncpy(rname[2],"roman2",30);
     strncpy(rname[3],"roman3",30);
     strncpy(rname[0],"roman4",30);



// for mask,mask2,substrate,substrate2 below the left and right side marks are in the
// gerber file.  For the roman numbers (rname) left and right are placed separately

  file1= fopen( file1str,"r");
  if (file1 == NULL)
  {
	  printf("In getoptical8, unable to open the input file = %s\n", file1str);
  }

  outfile= fopen( outfilestr,"w");
  if (outfile == NULL)
  {
	  printf("In getoptical8, unable to open the output file = %s\n", outfilestr);
  }

  endoffile = getline(file1,thisline);
  number_fields=split_line(thisline);

  while(endoffile==FALSE)
  {  
      split(str_array[1],name[0],name[1],".");

	  for(kk=0; kk < strlen(name[1]); kk += 1)
	  {
		  name[1][kk] = toupper(name[1][kk]);
	  }
      if( ( strcmp(str_array[3],"NA") != 0 ) && (strcmp(str_array[2],"PS") != 0)
		  && ( strcmp(name[1],"NA") != 0 ))
	  {
        myindex = abs( atoi(str_array[3] ));
	 
        strncpy(fname,name[0],30);
		strncpy(subfilestr,"substrate.",30);
		strncat(subfilestr,fname,60);

		subfile=fopen(subfilestr,"w");

		strncpy(maskfilestr,"mask.",30);
		strncat(maskfilestr,fname,60);

		maskfile=fopen(maskfilestr,"w");

        strncpy(viamaskfilestr,"viamask.",30);
		strncat(viamaskfilestr,fname,60);

		viamaskfile=fopen(viamaskfilestr,"w");

	    strncpy(rfilestr,rname[(myindex+1)%4],120);
		strncat(rfilestr,".",5);
		strncat(rfilestr,fname,60);
		rfile0 = fopen(rfilestr,"w");

		strncpy(rfilestr,rname[(myindex+2)%4],120);
		strncat(rfilestr,".",5);
		strncat(rfilestr,fname,60);
		rfile1 = fopen(rfilestr,"w");

        strncpy(rfilestr,rname[(myindex+3)%4],120);
		strncat(rfilestr,".",5);
		strncat(rfilestr,fname,60);
		rfile2 = fopen(rfilestr,"w");

		strncpy(rfilestr,rname[(myindex+0)%4],120);
		strncat(rfilestr,".",5);
		strncat(rfilestr,fname,60);
		rfile3 = fopen(rfilestr,"w");

        if( (myindex) >  0 )
		{
	     fprintf(maskfile,"%s %d\n", "0", YCOORDS[myindex%4]);  // > ("mask." fname)

	     if ( (myindex % 4) == 0 )
		 {
	      fprintf(outfile,"%s %d\n", fname, 4);
          }
	     else{
	      fprintf(outfile,"%s %d\n", fname, myindex%4);
         }

	    if((strcmp(str_array[2],"BLINDIN")== 0) || (strcmp(str_array[2],"BLINDOUT")== 0))
		{
	      fprintf(viamaskfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]);  // > ("viamask." fname)
          if ( ((myindex+1) % 4) == 0)
		  {
	       fprintf(rfile0,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
		  }
		  if ( ((myindex+1) % 4) == 1)
		  {
	       fprintf(rfile1,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
		  }
          if ( ((myindex+1) % 4) == 2)
		  {
	       fprintf(rfile2,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
		  }
		  if ( ((myindex+1) % 4) == 3)
		  {
	       fprintf(rfile3,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
		  }
		}
	   if( strcmp(str_array[2],"METAL" )== 0)
	   {
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]); // > ("substrate." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+2)%4]); //> ("substrate." fname)
         if ( ((myindex+1) % 4) == 0)
		 {
	      fprintf(rfile0,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile1,"%s %d\n", "0" ,romanYcoord[(myindex+2)%4]); //> (rname[(myindex+2)%4]"."fname)
		 }
		 if ( ((myindex+1) % 4) == 1)
		 {
	      fprintf(rfile1,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile2,"%s %d\n", "0" ,romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
		 }
		 if ( ((myindex+1) % 4) == 2)
		 {
	      fprintf(rfile2,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile3,"%s %d\n", "0" ,romanYcoord[(myindex+2)%4]); //> (rname[(myindex+2)%4]"."fname)
		 }
		 if ( ((myindex+1) % 4) == 3)
		 {
	      fprintf(rfile3,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile0,"%s %d\n", "0" ,romanYcoord[(myindex+2)%4]); //> (rname[(myindex+2)%4]"."fname)
		 }
	   }
	   if( strcmp(str_array[2],"TESTIN") ==0)
	   {
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]); // > ("substrate." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+2)%4]); // > ("substrate." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+3)%4]); // > ("substrate." fname)
		 if ( ((myindex+1) % 4) == 0)
		 {
	      fprintf(rfile0,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile1,"%s %d\n", "0",romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
	      fprintf(rfile2,"%s %d\n", "0",romanYcoord[(myindex+3)%4]); // > (rname[(myindex+3)%4]"."fname)
		 }
         if ( ((myindex + 1) % 4) == 1)
		 {
	      fprintf(rfile1,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile2,"%s %d\n", "0",romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
	      fprintf(rfile3,"%s %d\n", "0",romanYcoord[(myindex+3)%4]); // > (rname[(myindex+3)%4]"."fname)
		 }
	     if ( ((myindex + 1) % 4) == 2)
		 {
	      fprintf(rfile2,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile3,"%s %d\n", "0",romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
	      fprintf(rfile0,"%s %d\n", "0",romanYcoord[(myindex+3)%4]); // > (rname[(myindex+3)%4]"."fname)
		 }
         if ( ((myindex + 1) % 4) == 3)
		 {
	      fprintf(rfile3,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile0,"%s %d\n", "0",romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
	      fprintf(rfile1,"%s %d\n", "0",romanYcoord[(myindex+3)%4]); // > (rname[(myindex+3)%4]"."fname)
		 }
       }
	   if(( strcmp(str_array[2],"TSM") == 0) || (strcmp(str_array[2],"BSM") == 0 ))
	   {
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]);
         if ( ((myindex + 1) % 4) == 0)
		 {
	      fprintf(rfile0,"%s %d\n", "0" ,romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
         }
         if ( ((myindex + 1) % 4) == 1)
		 {
	      fprintf(rfile1,"%s %d\n", "0" ,romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
		 }
         if ( ((myindex + 1) % 4) == 2)
		 {
	     fprintf(rfile2,"%s %d\n", "0" ,romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
         }
         if ( ((myindex + 1) % 4) == 3)
		 {
	     fprintf(rfile3,"%s %d\n", "0" ,romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
         }
       }
      }
	 }
	 endoffile = getline(file1,thisline);
	 number_fields=split_line(thisline);

	}

  fclose(file1);
  fclose(rfile0);
  fclose(rfile1);
  fclose(rfile2);
  fclose(rfile3);
  fclose(subfile);
  fclose(viamaskfile);
  fclose(maskfile);
  fclose(outfile);

} // end getoptical8_call_out


void getoptical8_call( char *file1str)
{

FILE *rfile0, *rfile1, *rfile2, *rfile3;
FILE *subfile, *file1, *maskfile, *viamaskfile;

int myindex;
char thisline[200];

int kk;
char name[120][120];
char subfilestr[120];
int number_fields;
int romanYcoord[10];
int YCOORDS[10];
char rfilestr[120];
char fname[120];
char rname[120][40];
int endoffile;
char maskfilestr[120];
char viamaskfilestr[120];


     // Xright = 1543050
     // Xleft =  -1 * Xright

      YCOORDS[1] = 222250;
      YCOORDS[2] = 95250;
      YCOORDS[3] = -31750;
      YCOORDS[0] = -158750;

      romanYcoord[1] = 190500;
      romanYcoord[2] = 63500;
      romanYcoord[3] = -63500;
      romanYcoord[0] = -190500;

     strncpy(rname[1],"roman1",30);
     strncpy(rname[2],"roman2",30);
     strncpy(rname[3],"roman3",30);
     strncpy(rname[0],"roman4",30);



// for mask,mask2,substrate,substrate2 below the left and right side marks are in the
// gerber file.  For the roman numbers (rname) left and right are placed separately

  file1= fopen( file1str,"r");
  if (file1 == NULL)
  {
	  printf("In getoptical8, unable to open the input file = %s\n", file1str);
  }

  endoffile = getline(file1,thisline);
  number_fields=split_line(thisline);

  while(endoffile==FALSE)
  {  
      split(str_array[1],name[0],name[1],".");

	  for(kk=0; kk < strlen(name[1]); kk += 1)
	  {
		  name[1][kk] = toupper(name[1][kk]);
	  }
      if( ( strcmp(str_array[3],"NA") != 0 ) && (strcmp(str_array[2],"PS") != 0)
		  && ( strcmp(name[1],"NA") != 0 ))
	  {
        myindex = abs( atoi(str_array[3] ));
	 
        strncpy(fname,name[0],30);
		strncpy(subfilestr,"substrate.",30);
		strncat(subfilestr,fname,60);

		subfile=fopen(subfilestr,"w");

		strncpy(maskfilestr,"mask.",30);
		strncat(maskfilestr,fname,60);

		maskfile=fopen(maskfilestr,"w");

        strncpy(viamaskfilestr,"viamask.",30);
		strncat(viamaskfilestr,fname,60);

		viamaskfile=fopen(viamaskfilestr,"w");

	    strncpy(rfilestr,rname[(myindex+1)%4],120);
		strncat(rfilestr,".",5);
		strncat(rfilestr,fname,60);
		rfile0 = fopen(rfilestr,"w");

		strncpy(rfilestr,rname[(myindex+2)%4],120);
		strncat(rfilestr,".",5);
		strncat(rfilestr,fname,60);
		rfile1 = fopen(rfilestr,"w");

        strncpy(rfilestr,rname[(myindex+3)%4],120);
		strncat(rfilestr,".",5);
		strncat(rfilestr,fname,60);
		rfile2 = fopen(rfilestr,"w");

		strncpy(rfilestr,rname[(myindex+0)%4],120);
		strncat(rfilestr,".",5);
		strncat(rfilestr,fname,60);
		rfile3 = fopen(rfilestr,"w");

        if( (myindex) >  0 )
		{
	     fprintf(maskfile,"%s %d\n", "0", YCOORDS[myindex%4]);  // > ("mask." fname)

	     if ( (myindex % 4) == 0 )
		 {
	      printf("%s %d\n", fname, 4);
          }
	     else{
	      printf("%s %d\n", fname, myindex%4);
         }

	    if((strcmp(str_array[2],"BLINDIN")== 0) || (strcmp(str_array[2],"BLINDOUT")== 0))
		{
	      fprintf(viamaskfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]);  // > ("viamask." fname)
          if ( ((myindex+1) % 4) == 0)
		  {
	       fprintf(rfile0,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
		  }
		  if ( ((myindex+1) % 4) == 1)
		  {
	       fprintf(rfile1,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
		  }
          if ( ((myindex+1) % 4) == 2)
		  {
	       fprintf(rfile2,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
		  }
		  if ( ((myindex+1) % 4) == 3)
		  {
	       fprintf(rfile3,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
		  }
		}
	   if( strcmp(str_array[2],"METAL" )== 0)
	   {
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]); // > ("substrate." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+2)%4]); //> ("substrate." fname)
         if ( ((myindex+1) % 4) == 0)
		 {
	      fprintf(rfile0,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile1,"%s %d\n", "0" ,romanYcoord[(myindex+2)%4]); //> (rname[(myindex+2)%4]"."fname)
		 }
		 if ( ((myindex+1) % 4) == 1)
		 {
	      fprintf(rfile1,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile2,"%s %d\n", "0" ,romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
		 }
		 if ( ((myindex+1) % 4) == 2)
		 {
	      fprintf(rfile2,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile3,"%s %d\n", "0" ,romanYcoord[(myindex+2)%4]); //> (rname[(myindex+2)%4]"."fname)
		 }
		 if ( ((myindex+1) % 4) == 3)
		 {
	      fprintf(rfile3,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile0,"%s %d\n", "0" ,romanYcoord[(myindex+2)%4]); //> (rname[(myindex+2)%4]"."fname)
		 }
	   }
	   if( strcmp(str_array[2],"TESTIN") ==0)
	   {
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]); // > ("substrate." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+2)%4]); // > ("substrate." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+3)%4]); // > ("substrate." fname)
		 if ( ((myindex+1) % 4) == 0)
		 {
	      fprintf(rfile0,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile1,"%s %d\n", "0",romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
	      fprintf(rfile2,"%s %d\n", "0",romanYcoord[(myindex+3)%4]); // > (rname[(myindex+3)%4]"."fname)
		 }
         if ( ((myindex + 1) % 4) == 1)
		 {
	      fprintf(rfile1,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile2,"%s %d\n", "0",romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
	      fprintf(rfile3,"%s %d\n", "0",romanYcoord[(myindex+3)%4]); // > (rname[(myindex+3)%4]"."fname)
		 }
	     if ( ((myindex + 1) % 4) == 2)
		 {
	      fprintf(rfile2,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile3,"%s %d\n", "0",romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
	      fprintf(rfile0,"%s %d\n", "0",romanYcoord[(myindex+3)%4]); // > (rname[(myindex+3)%4]"."fname)
		 }
         if ( ((myindex + 1) % 4) == 3)
		 {
	      fprintf(rfile3,"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rfile0,"%s %d\n", "0",romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
	      fprintf(rfile1,"%s %d\n", "0",romanYcoord[(myindex+3)%4]); // > (rname[(myindex+3)%4]"."fname)
		 }
       }
	   if(( strcmp(str_array[2],"TSM") == 0) || (strcmp(str_array[2],"BSM") == 0 ))
	   {
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]);
         if ( ((myindex + 1) % 4) == 0)
		 {
	      fprintf(rfile0,"%s %d\n", "0" ,romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
         }
         if ( ((myindex + 1) % 4) == 1)
		 {
	      fprintf(rfile1,"%s %d\n", "0" ,romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
		 }
         if ( ((myindex + 1) % 4) == 2)
		 {
	     fprintf(rfile2,"%s %d\n", "0" ,romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
         }
         if ( ((myindex + 1) % 4) == 3)
		 {
	     fprintf(rfile3,"%s %d\n", "0" ,romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
         }
       }
      }
	 }
	 endoffile = getline(file1,thisline);
	 number_fields=split_line(thisline);

	}

  fclose(file1);
  fclose(rfile0);
  fclose(rfile1);
  fclose(rfile2);
  fclose(rfile3);
  fclose(subfile);
  fclose(viamaskfile);
  fclose(maskfile);

} // end getoptical8_call

int main( int argc, char **argv)
{

	getoptical8_call( argv[1]);
}

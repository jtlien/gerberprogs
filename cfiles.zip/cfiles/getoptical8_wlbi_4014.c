#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"
#include "makepan.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

void setvars_14x14();

void getoptical8_wlbi_4014_call_out( char *file1str, char *outfilestr)
{

FILE *subfile, *file1, *maskfile, *viamaskfile;
FILE *outfile;

int myindex;
char thisline[200];

int kk;
char name[120][120];
char subfilestr[120];
int number_fields;
int romanYcoord[10];
int YCOORDS[10];
char rfile0str[120];
char rfile1str[120];
char rfile2str[120];
char rfile3str[120];

char fname[120];
char rname[120][40];
int endoffile;
char maskfilestr[120];
char viamaskfilestr[120];
int wroter[4];

FILE *rnamefiles[4];    // correspond to rname[0..3]

     wroter[0]=FALSE;
	 wroter[1]=FALSE;
	 wroter[2]=FALSE;
	 wroter[3]=FALSE;

     // Xright = 1543050
     // Xleft =  -1 * Xright

      YCOORDS[1] = (int) (mask_y_1 * 10000 );   // 222250;
      YCOORDS[2] = (int) (mask_y_2 * 10000 );   // 95250;
      YCOORDS[3] = (int) (mask_y_3 * 10000 );   // -31750
      YCOORDS[0] = (int) (mask_y_0 * 10000 );   // -158750

      romanYcoord[1] = (int) (roman_y_1 * 10000 );   // 190500;
      romanYcoord[2] = (int) (roman_y_2 * 10000 );  // 63500;
      romanYcoord[3] = (int) (roman_y_3 * 10000 );  // -63500;
      romanYcoord[0] = (int) (roman_y_0 * 10000 );  // -190500

     strncpy(rname[0],"roman4",30);   
     strncpy(rname[1],"roman1",30);
     strncpy(rname[2],"roman2",30);
     strncpy(rname[3],"roman3",30);



// for mask,mask2,substrate,substrate2 below the left and right side marks are in the
// gerber file.  For the roman numbers (rname) left and right are placed separately

  file1= fopen( file1str,"r");
  if (file1 == NULL)
  {
	  printf("In getoptical8_wlbi_4014, unable to open the input file = %s\n", file1str);
	  exit(-1);
  }

  outfile= fopen( outfilestr,"w");
  if (outfile == NULL)
  {
	  printf("In getoptical8_wlbi_4014, unable to open the output file = %s\n", outfilestr);
	  exit(-1);
  }

  endoffile = getline(file1,thisline);
  number_fields=split_line(thisline);

  while(endoffile==FALSE)
  {  
      split(str_array[1],name[0],name[1],".");
     
	  for(kk=0; kk < (signed int) strlen(name[1]); kk += 1)
	  {
		  name[1][kk] = toupper(name[1][kk]);
	  }
      if( ( strcmp(str_array[3],"NA") != 0 ) && (strcmp(str_array[2],"PS") != 0)
		  && ( strcmp(name[1],"NA") != 0 ))
	  {
        myindex = abs( atoi(str_array[3] ));
	 
        strncpy(fname,name[0],30);
		strncpy(subfilestr,"substrate.",30);
		strncat(subfilestr,fname,60);

		strncpy(maskfilestr,"mask.",30);
		strncat(maskfilestr,fname,60);

        strncpy(viamaskfilestr,"viamask.",30);
		strncat(viamaskfilestr,fname,60);

	    strncpy(rfile0str,rname[0],120);
		strncat(rfile0str,".",5);
		strncat(rfile0str,fname,60);

		rnamefiles[0] = fopen(rfile0str,"w");
        if (rnamefiles[0] == NULL)
		{
			printf("In getoptical8_wlbi_4014, unable to open the output file = %s \n",rfile0str);
			exit(-1);
		}


		strncpy(rfile1str,rname[1],120);
		strncat(rfile1str,".",5);
		strncat(rfile1str,fname,60);
		rnamefiles[1] = fopen(rfile1str,"w");
        if (rnamefiles[1] == NULL)
		{
			printf("In getoptical8_wlbi_4014, unable to open the output file = %s \n",rfile1str);
			exit(-1);
		}
        strncpy(rfile2str,rname[2],120);
		strncat(rfile2str,".",5);
		strncat(rfile2str,fname,60);
		rnamefiles[2] = fopen(rfile2str,"w");
        if (rnamefiles[2] == NULL)
		{
			printf("In getoptical8_wlbi_4014, unable to open the output file = %s \n",rfile2str);
			exit(-1);
		}
		strncpy(rfile3str,rname[3],120);
		strncat(rfile3str,".",5);
		strncat(rfile3str,fname,60);
		rnamefiles[3]= fopen(rfile3str,"w");
        if (rnamefiles[3]== NULL)
		{
			printf("In getoptical8_wlbi_4014, unable to open the output file = %s \n",rfile3str);
			exit(-1);
		}
		wroter[0]=FALSE;
	    wroter[1]=FALSE;
	    wroter[2]=FALSE;
	    wroter[3]=FALSE;

        if( (myindex) >  0 )
		{
		  maskfile=fopen(maskfilestr,"w");
          if (maskfile == NULL)
		  {
			printf("In getoptical8, unable to open the output file = %s \n", maskfilestr);
			exit(-1);
		  }
	      fprintf(maskfile,"%s %d\n", "0", YCOORDS[myindex%4]);  // > ("mask." fname)
          fclose(maskfile);

	     if ( (myindex % 4) == 0 )
		 {
	      fprintf(outfile,"%s %d\n", fname, 4);
          }
	     else{
	      fprintf(outfile,"%s %d\n", fname, myindex%4);
         }

	    if((strcmp(str_array[2],"BLINDIN")== 0) || (strcmp(str_array[2],"BLINDOUT")== 0))
		{
          viamaskfile=fopen(viamaskfilestr,"w");
          if (viamaskfile == NULL)
		   {
			printf("In getoptical8, unable to open the output file = %s \n",viamaskfilestr);
			exit(-1);
		   }

	      fprintf(viamaskfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]);  // > ("viamask." fname)
	      fprintf(rnamefiles[(myindex+1)%4],"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
	
		   wroter[(myindex+1)%4]=TRUE;
		  fclose(viamaskfile);
		}

	   if( strcmp(str_array[2],"METAL" )== 0)
	   {
		 subfile=fopen(subfilestr,"w");
		 if (subfile == NULL)
		 {
			 printf("Unable to open the output file = %s \n",subfilestr);
			 exit(-1);
		 }
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]); // > ("substrate." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+2)%4]); //> ("substrate." fname)
         fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+3)%4]); //> ("substrate." fname)

	     fprintf(rnamefiles[(myindex+1)%4],"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
	     fprintf(rnamefiles[(myindex+2)%4],"%s %d\n", "0" ,romanYcoord[(myindex+2)%4]); //> (rname[(myindex+2)%4]"."fname)
		 fprintf(rnamefiles[(myindex+3)%4],"%s %d\n", "0" ,romanYcoord[(myindex+3)%4]); //> (rname[(myindex+2)%4]"."fname)
		 wroter[(myindex+1)%4]=TRUE;
		 wroter[(myindex+2)%4]=TRUE;
		 wroter[(myindex+3)%4]=TRUE;

		 fclose(subfile);
	   }

	 if( strcmp(str_array[2],"TESTIN") ==0)
	   {
		 subfile=fopen(subfilestr,"w");
		 if (subfile == NULL)
		 {
			 printf("Unable to open the output file = %s \n",subfilestr);
			 exit(-1);
		 }
	     fprintf(maskfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]); // > ("mask." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+2)%4]); // > ("substrate." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+3)%4]); // > ("substrate." fname)
	
	     // fprintf(rnamefiles[(myindex+1)%4],"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rnamefiles[(myindex+2)%4],"%s %d\n", "0",romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
	      fprintf(rnamefiles[(myindex+3)%4],"%s %d\n", "0",romanYcoord[(myindex+3)%4]); // > (rname[(myindex+3)%4]"."fname)
		  wroter[(myindex+1)%4]=FALSE;
		  wroter[(myindex+2)%4]=TRUE;
		  wroter[(myindex+3)%4]=TRUE;
		 
		 fclose(subfile);
       }

	 if(( strcmp(str_array[2],"TSM") == 0) || (strcmp(str_array[2],"BSM") == 0 ))
	   {

		 subfile=fopen(subfilestr,"w");
		 if (subfile == NULL)
		 {
			 printf("Unable to open the output file = %s \n",subfilestr);
			 exit(-1);
		 }
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]);

	     fprintf(rnamefiles[(myindex+1)%4],"%s %d\n", "0" ,romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
         wroter[(myindex+1)%4]=TRUE;

         
		fclose(subfile);

	   }  // TSM
	 }
   }
	 endoffile = getline(file1,thisline);
	 number_fields=split_line(thisline);

	 // printf("linein = %s \n",thisline);
    
	if (wroter[0] == FALSE)
	{
	//	printf("unlink %s \n",rfile0str);
		fclose(rnamefiles[0]);
		unlink(rfile0str);
	}
	else
	{
	  fclose(rnamefiles[0]);
	}

    if (wroter[1] == FALSE)
	{
	//	printf("unlink %s \n",rfile1str);
		fclose(rnamefiles[1]);
		unlink(rfile1str);
	}
	else
	{
		fclose(rnamefiles[1]);
	}

	if (wroter[2] == FALSE)
	{
		// printf("unlink %s \n",rfile2str);
        fclose(rnamefiles[2]);
		unlink(rfile2str);
	}
	else
	{
 	fclose(rnamefiles[2]);
	}

    if (wroter[3] == FALSE)
	{
		// printf("unlink %s \n",rfile3str);
		fclose(rnamefiles[3]);
		unlink(rfile3str);
	}
	else
	{
 	fclose(rnamefiles[3]);
	}


    
  }  // while endoffile

  fclose(file1);
  
  fclose(subfile);
  fclose(outfile);


} // end getoptical8_call_out


void getoptical8_wlbi_4014_call( char *file1str)
{

FILE *subfile, *file1, *maskfile, *viamaskfile;
int myindex;
char thisline[200];

int kk;
char name[120][120];
char subfilestr[120];
int number_fields;
int romanYcoord[10];
int YCOORDS[10];
char rfile0str[120];
char rfile1str[120];
char rfile2str[120];
char rfile3str[120];

char fname[120];
char rname[120][40];
int endoffile;
char maskfilestr[120];
char viamaskfilestr[120];
int wroter[4];

FILE *rnamefiles[4];    // correspond to rname[0..3]

     wroter[0]=FALSE;
	 wroter[1]=FALSE;
	 wroter[2]=FALSE;
	 wroter[3]=FALSE;

     // Xright = 1543050
     // Xleft =  -1 * Xright

      YCOORDS[1] = (int) (mask_y_1 * 10000);   // 222250;
      YCOORDS[2] = (int) (mask_y_2 * 10000);   // 95250;
      YCOORDS[3] = (int) (mask_y_3 * 10000);   // -31750
      YCOORDS[0] = (int) (mask_y_0 * 10000);   // -158750

      romanYcoord[1] = (int) (roman_y_1 * 10000 );   // 190500;
      romanYcoord[2] = (int) (roman_y_2 * 10000 );  // 63500;
      romanYcoord[3] = (int) (roman_y_3 * 10000 );  // -63500;
      romanYcoord[0] = (int) (roman_y_0 * 10000 );  // -190500
      

     strncpy(rname[0],"roman4",30);
     strncpy(rname[1],"roman1",30);
     strncpy(rname[2],"roman2",30);
     strncpy(rname[3],"roman3",30);



// for mask,mask2,substrate,substrate2 below the left and right side marks are in the
// gerber file.  For the roman numbers (rname) left and right are placed separately

  file1= fopen( file1str,"r");
  if (file1 == NULL)
  {
	  printf("In getoptical8, unable to open the input file = %s\n", file1str);
	  exit(-1);
  }


  endoffile = getline(file1,thisline);
  number_fields=split_line(thisline);

  while(endoffile==FALSE)
  {  
      split(str_array[1],name[0],name[1],".");
     
	  for(kk=0; kk < (signed int) strlen(name[1]); kk += 1)
	  {
		  name[1][kk] = toupper(name[1][kk]);
	  }
      if( ( strcmp(str_array[3],"NA") != 0 ) && (strcmp(str_array[2],"PS") != 0)
		  && ( strcmp(name[1],"NA") != 0 ))
	  {
        myindex = abs( atoi(str_array[3] ));
	 
        strncpy(fname,name[0],30);
		strncpy(subfilestr,"substrate.",30);
		strncat(subfilestr,fname,60);

		strncpy(maskfilestr,"mask.",30);
		strncat(maskfilestr,fname,60);

        strncpy(viamaskfilestr,"viamask.",30);
		strncat(viamaskfilestr,fname,60);

	    strncpy(rfile0str,rname[0],120);
		strncat(rfile0str,".",5);
		strncat(rfile0str,fname,60);

		rnamefiles[0] = fopen(rfile0str,"w");
        if (rnamefiles[0] == NULL)
		{
			printf("In getoptical8_wlbi_4014, unable to open the output file = %s \n",rfile0str);
			exit(-1);
		}


		strncpy(rfile1str,rname[1],120);
		strncat(rfile1str,".",5);
		strncat(rfile1str,fname,60);
		rnamefiles[1] = fopen(rfile1str,"w");
        if (rnamefiles[1] == NULL)
		{
			printf("In getoptical8_wlbi_4014, unable to open the output file = %s \n",rfile1str);
			exit(-1);
		}
        strncpy(rfile2str,rname[2],120);
		strncat(rfile2str,".",5);
		strncat(rfile2str,fname,60);
		rnamefiles[2] = fopen(rfile2str,"w");
        if (rnamefiles[2] == NULL)
		{
			printf("In getoptical8_wlbi_4014, unable to open the output file = %s \n",rfile2str);
			exit(-1);
		}
		strncpy(rfile3str,rname[3],120);
		strncat(rfile3str,".",5);
		strncat(rfile3str,fname,60);
		rnamefiles[3]= fopen(rfile3str,"w");
        if (rnamefiles[3]== NULL)
		{
			printf("In getoptical8_wlbi_4014, unable to open the output file = %s \n",rfile3str);
			exit(-1);
		}
		wroter[0]=FALSE;
	    wroter[1]=FALSE;
	    wroter[2]=FALSE;
	    wroter[3]=FALSE;

        if( (myindex) >  0 )
		{
		  maskfile=fopen(maskfilestr,"w");
          if (maskfile == NULL)
		  {
			printf("In getoptical8_wlbi_4014, unable to open the output file = %s \n", maskfilestr);
			exit(-1);
		  }
	      fprintf(maskfile,"%s %d\n", "0", YCOORDS[myindex%4]);  // > ("mask." fname)
          fclose(maskfile);

	     if ( (myindex % 4) == 0 )
		 {
	      printf("%s %d\n", fname, 4);
          }
	     else{
	      printf("%s %d\n", fname, myindex%4);
         }

	    if((strcmp(str_array[2],"BLINDIN")== 0) || (strcmp(str_array[2],"BLINDOUT")== 0))
		{
          viamaskfile=fopen(viamaskfilestr,"w");
          if (viamaskfile == NULL)
		   {
			printf("In getoptical8, unable to open the output file = %s \n",viamaskfilestr);
			exit(-1);
		   }

	      fprintf(viamaskfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]);  // > ("viamask." fname)
	      fprintf(rnamefiles[(myindex+1)%4],"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
	
		   wroter[(myindex+1)%4]=TRUE;
		  fclose(viamaskfile);
		}
	   if( strcmp(str_array[2],"METAL" )== 0)
	   {
		 subfile=fopen(subfilestr,"w");
		 if (subfile == NULL)
		 {
			 printf("Unable to open the output file = %s \n",subfilestr);
			 exit(-1);
		 }
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]); // > ("substrate." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+2)%4]); //> ("substrate." fname)
         fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+3)%4]); //> ("substrate." fname)

	     fprintf(rnamefiles[(myindex+1)%4],"%s %d\n", "0",romanYcoord[(myindex+1)%4]); //> (rname[(myindex+1)%4]"."fname)
	     fprintf(rnamefiles[(myindex+2)%4],"%s %d\n", "0" ,romanYcoord[(myindex+2)%4]); //> (rname[(myindex+2)%4]"."fname)
		 fprintf(rnamefiles[(myindex+3)%4],"%s %d\n", "0" ,romanYcoord[(myindex+3)%4]); //> (rname[(myindex+2)%4]"."fname)
		 wroter[(myindex+1)%4]=TRUE;
		 wroter[(myindex+2)%4]=TRUE;
		 wroter[(myindex+3)%4]=TRUE;

		 fclose(subfile);
	   }

	 if( strcmp(str_array[2],"TESTIN") ==0)
	   {
		 subfile=fopen(subfilestr,"w");
		 if (subfile == NULL)
		 {
			 printf("Unable to open the output file = %s \n",subfilestr);
			 exit(-1);
		 }
	     fprintf(maskfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]); // > ("mask." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+2)%4]); // > ("substrate." fname)
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+3)%4]); // > ("substrate." fname)
	
	     // fprintf(rnamefiles[(myindex+1)%4],"%s %d\n", "0",romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
	      fprintf(rnamefiles[(myindex+2)%4],"%s %d\n", "0",romanYcoord[(myindex+2)%4]); // > (rname[(myindex+2)%4]"."fname)
	      fprintf(rnamefiles[(myindex+3)%4],"%s %d\n", "0",romanYcoord[(myindex+3)%4]); // > (rname[(myindex+3)%4]"."fname)
		  wroter[(myindex+1)%4]=FALSE;
		  wroter[(myindex+2)%4]=TRUE;
		  wroter[(myindex+3)%4]=TRUE;
		 
		 fclose(subfile);
       }

	  
	 if(( strcmp(str_array[2],"TSM") == 0) || (strcmp(str_array[2],"BSM") == 0 ))
	   {

		 subfile=fopen(subfilestr,"w");
		 if (subfile == NULL)
		 {
			 printf("Unable to open the output file = %s \n",subfilestr);
			 exit(-1);
		 }
	     fprintf(subfile,"%s %d\n", "0",YCOORDS[(myindex+1)%4]);

	     fprintf(rnamefiles[(myindex+1)%4],"%s %d\n", "0" ,romanYcoord[(myindex+1)%4]); // > (rname[(myindex+1)%4]"."fname)
         wroter[(myindex+1)%4]=TRUE;

         
		fclose(subfile);

	   }  // TSM
	 }
   }
	 endoffile = getline(file1,thisline);
	 number_fields=split_line(thisline);

	 // printf("linein = %s \n",thisline);
    
	if (wroter[0] == FALSE)
	{
	//	printf("unlink %s \n",rfile0str);
		fclose(rnamefiles[0]);
		unlink(rfile0str);
	}
	else
	{
	  fclose(rnamefiles[0]);
	}

    if (wroter[1] == FALSE)
	{
	//	printf("unlink %s \n",rfile1str);
		fclose(rnamefiles[1]);
		unlink(rfile1str);
	}
	else
	{
		fclose(rnamefiles[1]);
	}

	if (wroter[2] == FALSE)
	{
		// printf("unlink %s \n",rfile2str);
        fclose(rnamefiles[2]);
		unlink(rfile2str);
	}
	else
	{
 	fclose(rnamefiles[2]);
	}

    if (wroter[3] == FALSE)
	{
		// printf("unlink %s \n",rfile3str);
		fclose(rnamefiles[3]);
		unlink(rfile3str);
	}
	else
	{
 	fclose(rnamefiles[3]);
	}


    
  }  // while endoffile

  fclose(file1);
  
  fclose(subfile);
  

} // end getoptical8_call


/*
int main( int argc, char **argv)
{
  if (argc != 2 )
  {
    printf("In getoptical8_wlbi_4014, wrong number of arguments \n");
	printf("Usage: getoptical8_wlbi_4014 infile \n");
	exit(-1);
   }
  else
  {
	setvars_14x14();
	getoptical8_wlbi_4014_call( argv[1]);
   }
}
  
*/




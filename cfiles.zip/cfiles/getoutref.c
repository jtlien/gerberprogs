#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

char outcodes[20000][30];
char oldcodes[20000][30];
int outcode_count;
int oldcode_count;

int find_in_oldcodes( int inval)
{
char instr[100];
int ii;

 sprintf(instr,"%d",inval);

 ii=0;
 while(ii < oldcode_count)
	{
	 if (strcmp(oldcodes[ii],instr)== 0 )
	 {
		 return(TRUE);
	 }
   ii += 1;
 }
  return(FALSE);

}  // find_in_oldcodes

void add_to_oldcodes( char *instr)
{
int ii;

 ii = 0;
 while(ii < oldcode_count)
	{
	 if (strcmp(oldcodes[ii], instr) == 0 )
	 {
		 return;    // already added, 
	 }
	ii += 1;
 }

 if(oldcode_count < 20000)
	{
     
     strncpy( oldcodes[oldcode_count],instr,30);
	 oldcode_count += 1;
 }
 else
	{
	 printf("Array size exceeded for oldcodes \n");
	}

 
 
}

void add_to_outcodes( char *instr)
{
int ii;

 ii = 0;
 while(ii < outcode_count)
	{
	 if (strcmp(outcodes[ii], instr) == 0 )
	 {
		 return;    // already added, 
	 }
	ii += 1;
 }

 // printf("adding to outcodes ii=%d instr=%s \n",ii, instr);

 if ( outcode_count < 20000)
	{
    strncpy( outcodes[outcode_count],instr,30);
	// printf("adding to outcodes ii=%d instr=%s \n",ii, instr);
    outcode_count += 1;
	}
 else
	{
	 printf("Array sized exceed for outcodes \n");
 }

}
	 

void getoutref_call(char *file1str, char *infilestr )
{
int endoffile;
char thisline[300];
FILE *file1;
FILE *infile;
int flag;
int cnt;
int nf;
char old[300];
char newone[300];
int i;


    oldcode_count=0;
	outcode_count=0;

    file1=fopen(file1str,"r");
	if (file1==NULL)
	{
		printf("Unable to open the input file = %s \n", file1str);
		exit(-1);
	}

    infile=fopen(infilestr,"r");
	if (infile==NULL)
	{
		printf("Unable to open the input file = %s \n", infilestr);
		exit(-1);
	}


    endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

    while( endoffile==FALSE)  // read the outcodes
	{
	 //outcodes[$1] = $1

	 add_to_outcodes( str_array[0]);

	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

    }

   fclose(file1);
  // printf(" outcode_count = %d \n",outcode_count);

   endoffile=getline(infile,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)   //  read old codes
   {
    //oldcodes[$1] = $1

	add_to_oldcodes(str_array[0]);

	endoffile=getline(infile,thisline);
    nf=split_line(thisline);
   }

   fclose(infile);

 //  printf(" oldcode_count = %d \n",oldcode_count);
 
    cnt = 999;
	flag=0;
    printf( "OLD   NEW\n");
	i=0;
    while( i < outcode_count )
	{
      while( flag == 0 &&  cnt  > 10)
	  {
 	   if ( !( find_in_oldcodes(cnt) ))
	   {
	  // old = ("D"i)
	  // sprintf(old,"D%d",i);

	   strncpy(old,"D",5);
	   strncat(old,outcodes[i],30);

	   sprintf(newone,"D%d",cnt);
	  
	   printf("%s      %s \n",old,newone);
	   flag = 1 ;
       }
	  cnt--;
      }        // end while flag==0
      flag = 0;

	  i+=1;
    }
    if( cnt <= 10 )
	{ 
	printf("FATAL ERROR: NOT ABLE to find free aperture for outline file\n"); // | "cat 1>&2"
	exit(1);
    }

}  // end getoutref_call


void getoutref_call_out(char *file1str, char *infilestr, char *outfilestr)
{
int endoffile;
char thisline[300];
FILE *file1;
FILE *infile;
FILE *outfile;

int flag;
int cnt;
int nf;
char old[300];
char newone[300];
int i;


    oldcode_count=0;
	outcode_count=0;

    file1=fopen(file1str,"r");
	if (file1==NULL)
	{
		printf("Unable to open the input file = %s \n", file1str);
		exit(-1);
	}

    infile=fopen(infilestr,"r");
	if (infile==NULL)
	{
		printf("Unable to open the input file = %s \n", infilestr);
		exit(-1);
	}

    outfile=fopen(outfilestr,"w");
	if (outfile==NULL)
	{
		printf("Unable to open the output file = %s \n", outfilestr);
		exit(-1);
	}


    endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

    while( endoffile==FALSE)  // read the outcodes
	{
	 //outcodes[$1] = $1

	 add_to_outcodes( str_array[0]);

	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);

    }

   fclose(file1);
   printf(" outcode_count = %d \n",outcode_count);

   endoffile=getline(infile,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)   //  read old codes
   {
    //oldcodes[$1] = $1

	add_to_oldcodes(str_array[0]);

	endoffile=getline(infile,thisline);
    nf=split_line(thisline);
   }

   fclose(infile);

   printf(" oldcode_count = %d \n",oldcode_count);
 
    cnt = 999;
    fprintf(outfile, "OLD   NEW\n");
	i=0;
    while( i < outcode_count )
	{
      while( flag == 0 &&  cnt  > 10)
	  {
 	   if ( !( find_in_oldcodes(cnt) ))
	   {
	  // old = ("D"i)
	   //sprintf(old,"D%d",i);
		strncpy(old,"D",5);
		strncat(old,outcodes[i],30);

	   sprintf(newone,"D%d",cnt);
	  
	   fprintf(outfile,"%s      %s \n",old,newone);
	   flag = 1 ;
       }
	  cnt--;
      }        // end while flag==0
      flag = 0;

	  i+=1;
    }

	fclose(outfile);

    if( cnt <= 10 )
	{ 
	printf("FATAL ERROR: NOT ABLE to find free aperture for outline file\n"); // | "cat 1>&2"
	exit(1);
    }

}  // end getoutref_call_out

/*
int main( int argc, char **argv)
{

	if (argc != 3)
	{
		printf("In getoutref, wrong number of arguments \n");
		printf("Usage: getoutref outcodefile oldcodefile \n");
		exit(-1);
	}
	else
	{
		getoutref_call( argv[1], argv[2]);
	}


}  // end main

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAXVERTICAL  50000    // may be way too big
#define MAXHORIZONTAL 50000

#define MAXPANELX  1524000    // may have to make these parameters 
#define MAXPANELY  1524000    // at some point to handle different panel sizes
#define XEVENOFFSET 150000
#define YEVENOFFSET 150000
#define MAXYSIZE    600000

struct vertstuff
{
	int xval;
	int yval;
} vertical_array[MAXVERTICAL];

struct horizstuff
{
	int xval;
	int yval;
} horizontal_array[MAXHORIZONTAL];

char str_array[120][120];


char thisline[200];

int cnt;
int KERF;
int PCMLEN;
int PCM;
double MINSIZE;
double MAXSIZE;
double PANELSIZE;
double dist;
double powval;
int Xcol;
int Yrow;
int tmp1;
int xsize;
int ysize;
int Xstart;
int Ystart;
int Xcnt;
int Ycnt;
int TEST;
double a[20];

int Xvalid[10000];
int Yvalid[10000];
int thisxval;
int thisyval;
int endoffile;
int Xnum;
int Ynum;
int Xold;
int XBASE;
int YBASE;
int Xmax;
int Ymax;
int mult;
int i;
int nf;
int horizontal_count;
int vertical_count;
FILE *file1,*file4,*file2;
FILE *pcmrowfile;
FILE *outfile;

void add_to_horizontal( int xin, int yin)
{
	if ( horizontal_count < MAXHORIZONTAL)
	{
		horizontal_array[horizontal_count].xval=xin;
		horizontal_array[horizontal_count].yval=yin;
		horizontal_count++;
	}
	else
	{
		printf("Horizontal array size exceeded in getpcmkerf11\n");
	}
}

void add_to_vertical( int xin, int yin)
{
	if ( vertical_count < MAXVERTICAL)
	{
		vertical_array[vertical_count].xval=xin;
		vertical_array[vertical_count].yval=yin;
		vertical_count++;
	}
	else
	{
		printf("Vertical array size exceeded in getpcmkerf11\n");
	}
}

// first attempt at pcm placement
//******************# need to ADD size checking *****************
// R indicates HORIZONTAL placement

void outcoords23( int x , int y )
{
int yspot;
int num;
int stop;
int myZ;
int xspot;
int offset;
int putxplus;
int putyplus;
int puty1;
int puty2;
int putx1;
int putx2;
int tmpsize;
int xnew;
int ynew;
int tmp;

   yspot = (int) (y + (ysize/2) + PCM + KERF/2) ;
   if( (yspot <= MAXPANELY) && ( yspot >= -MAXPANELY))
   {
      putyplus = (int)( y + (ysize/2) + KERF/2);
      if( (xsize  >= MINSIZE ) && (xsize  <= MAXSIZE))
	  {
	   add_to_horizontal(x,putyplus); // =1;
      } 
      else if( xsize  > MAXSIZE )
	  {
	   tmpsize = xsize - TEST;
	   num = ( tmpsize/PCMLEN);
	   stop = num/2;
	   if ( num % 2 == 0)
	   {
	    offset = XEVENOFFSET;
	   }
	   else
	   {
	   offset = 0;
       }
	  for ( myZ = 0 ; myZ < stop ; myZ++)
	  {
	    putx1 = (int) (x + dist*myZ +offset);
        putx2 = (int) (x - dist*myZ -offset);
	    add_to_horizontal(putx1,putyplus ); // =1;
	    add_to_horizontal(putx2,putyplus ); // =1;
       }
      }	  
     else 
	 {
	  if( (Xcol != 1) && (((Xvalid[Xcol] == 1) && 
		    (Yvalid[Yrow] ==1)) ||  ((Xvalid[Xcol] == 1)&& (Yrow == Ymax))) ) 
	  {
	    tmp =  (Xnum/2);
	    xnew = x - tmp * xsize - tmp * KERF;
	    if ( Xnum % 2 == 0)
		{
	       xnew = xnew + (xsize/2) + KERF/2;
         }
	    add_to_horizontal(xnew,putyplus); // =1;
	    if( (Xvalid[Xcol] == 1)&& (Yrow == Ymax))
                 fprintf(pcmrowfile,  "Xoutside YES \n"); //  > "pcmrowcol2"
      }
    }

   }

   xspot = (int) (x + (xsize/2) + PCM  + KERF/2); 
   if( (xspot <= MAXPANELX) && ( xspot  >= -MAXPANELX)) 
   {
      putxplus = (int) ( x + (xsize/2) + KERF/2);
      if( (ysize   >= MINSIZE ) && (ysize   <= MAXSIZE))
	  {
	   add_to_vertical(putxplus, y); // = 1;
      }
      else if( ysize  > MAXSIZE )
	  {
	   tmpsize = ysize - TEST;
	   num = (int) ( tmpsize/PCMLEN);
	   stop = num/2;
	   if ( num % 2 == 0)
	   {
	    offset = YEVENOFFSET;
        }
	   else
	   {
	    offset = 0;
       }
	  for( myZ = 0 ; myZ < stop ; myZ++)
	  {
         puty1 = (int) (y + dist*myZ +offset);
	     puty2 = (int) (y - dist*myZ -offset);
	     add_to_vertical(putxplus ,puty1 );  //  =1;
         add_to_vertical(putxplus ,puty2 ); // =1;
      }
     }	  
    else 
	{
	 if( (Yrow != 1) && (((Xvalid[Xcol] == 1 ) && 
		 (Yvalid[Yrow] ==1 ))  || ((Yvalid[Yrow] ==1 )&& ( Xcol == Xmax))) )
	 {
	    tmp =  (Ynum/2);
	    ynew = y - tmp * ysize - tmp * KERF;
	    if ( Ynum % 2 == 0)
		{
	       ynew = ynew + (ysize/2) + KERF/2;
        }
	    add_to_vertical(putxplus, ynew); // = 1;
	    if((Yvalid[Yrow] ==1 )&& ( Xcol == Xmax)) 
                 fprintf(pcmrowfile,  "Youtside YES \n"); //  > "pcmrowcol2"
     }
    }
  }

  Yrow++;
}

// set up the vertical array
// formal parameters x, y
//   function of xsize, ysize, dist= 30x10^4,PCM=1x10^4, KERF, TEST=2x10^4, PCMLEN=30x10^4
//               
//               Ycol runs thru 1..#of lines in file4, Xvalid
//               Ynum is number of PCMS fit in Y direction
//               xsize and ysize are found the offval file read in (file1)

void outcoords1( int x , int y )
{
int xspot;
int num;
int stop;
int tmp;
int putxminus;
int tmpsize;
int offset;
int myZ;
int puty1;
int puty2;
int ynew;

   xspot = (int) ( x - (xsize/2) - PCM - KERF/2);
   if( (xspot <= MAXPANELX) &&  (xspot >= -MAXPANELX) ) 
   {
      putxminus = (int) ( x - (xsize/2) - KERF/2);
      if( (ysize  >= MINSIZE) && (ysize  <= MAXSIZE))
	  {
	   add_to_vertical(putxminus, y); //  = 1;
      }
      else if( ysize  > MAXYSIZE)
	  {
	   tmpsize = ysize - TEST;
	   num = (int) ( tmpsize/PCMLEN);
	   stop = num/2;
	   if ( num % 2 == 0)
	   {
	    offset = YEVENOFFSET;
       }
	   else
	   {
	   offset = 0;
       }
	  for( myZ = 0 ; myZ < stop ; myZ++)
	  {
         puty1 = (int) (y + dist*myZ +offset);
	     puty2 = (int) (y - dist*myZ -offset);
	     add_to_vertical(putxminus ,puty1); //  ] =1;
         add_to_vertical(putxminus ,puty2 ); //  ] =1;
         }
      }
      else 
	  {
	   if( Yvalid[Yrow] == 1  && Yrow != 1)
	   {
	    tmp = (Ynum/2);
	    ynew = y - tmp * ysize - tmp * KERF;
	    if ( Ynum % 2 == 0)
		{
	       ynew = ynew + (ysize/2) + KERF/2;
        }
	    add_to_vertical(putxminus, ynew); // = 1;
       }
     }
  }
}

// sets up the horizontal
// formal parameters x, y
//   function of xsize, ysize, dist= 30x10^4,PCM=1x10^4, KERF, TEST=2x10^4, PCMLEN=30x10^4
//               Xcol runs thru 1..#of lines in file4, Xvalid
//               Xnum is number of PCMS fit in X direction
//               xsize and ysize are found the offval file read in (file1)
void outcoords4( int x , int y )
{
int yspot;
int putyminus;
int tmpsize;
int tmp;
int num;
int offset;
int stop;
int myZ;
int xnew;
int putx1;
int putx2;

   yspot = y - (ysize/2) - PCM - KERF/2;

   if((yspot  <= MAXPANELY ) && ( yspot >= -MAXPANELY )) 
   {
      putyminus = (int) ( y - (ysize/2) - KERF/2);
      if( (xsize  >= MINSIZE ) && (xsize  <= MAXSIZE))
	  {
         add_to_horizontal(x,putyminus); // =1;
      }
      else if( xsize  > MAXSIZE )
	  {
	   tmpsize = xsize - TEST;
	   num = (int) ( tmpsize/PCMLEN);
	   stop = num/2;
	   if ( num % 2 == 0)
	   {
	    offset = XEVENOFFSET;
       }
	   else
	   {
	    offset = 0;
       }
	   for ( myZ = 0 ; myZ < stop ; myZ++)
	   {
	    putx1 = (int) ( x + dist*myZ +offset);
        putx2 = (int) ( x - dist*myZ -offset);
	    add_to_horizontal(putx1,putyminus); //  ]=1;
	    add_to_horizontal(putx2,putyminus ); // =1;
       }
      }
     else         // ysize smaller than min
	 {
	   if( (Xvalid[Xcol] == 1)  && (Xcol != 1) )
	   { 
	    tmp =  (Xnum/2);
	    xnew = x - tmp * xsize - tmp * KERF;
	    if ( Xnum % 2 == 0)
		{
	       xnew = xnew + (xsize/2) + KERF/2;
        }
	    add_to_horizontal(xnew,putyminus); // =1;
       }
     }
   }
}

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line


//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

void getpcmkerf11_call_out( char *file1str, char *file2str, char *kerfstr, char *file4str,
						   char *outfilestr)

{
	   KERF=atoi(kerfstr);
       mult=0;

	   // printf("kerf = %d \n",KERF);

	   horizontal_count=0;
	   vertical_count=0;

       cnt = 0;
       MINSIZE = 32;
      // PANELSIZE =  304.8;
       PCM = 1;
       PCMLEN = 30;
       TEST = 2;
       MAXSIZE = 62;
       dist = 30;

	   file1=fopen(file1str,"r");
	   if (file1 == NULL)
	   {
		   printf("In getpcmkerf11, unable to open the input file = %s \n", file1str);
		   exit(-1);
	   }
       // file1 is offval file with xmin,xmax,ymin,ymax

       file2=fopen(file2str,"r");  // file2 has xmax ymax, generated by getcoords3
	                               // the xmax = numparts in x dir
	                                //  the ymax = numparts in y dir
	   if (file2 == NULL)
	   {
		   printf("In getpcmkerf11, unable to open the input file = %s \n", file2str);
		   exit(-1);
	   }

       file4=fopen(file4str,"r");  // file4 has part coordinant information
	   if (file4 == NULL)
	   {
		   printf("In getpcmkerf11, unable to open the input file = %s \n", file4str);
		   exit(-1);
	   }

       pcmrowfile=fopen("pcmrowcol2","w");  // pcm row and column coordinants
	   if (pcmrowfile == NULL)
	   {
		   printf("In getpcmkerf11, unable to open the output file = pcmrowcol2 \n");
		   exit(-1);
	   }

       outfile=fopen(outfilestr,"w");  // output file
	   if (outfile == NULL)
	   {
		   printf("In getpcmkerf11, unable to open the output file = %s\n",outfilestr);
		   exit(-1);
	   }

       endoffile=getline(file1,thisline);
	   nf=split_line(thisline);
       while ( endoffile == FALSE)
	   {
	     a[cnt] = atof(str_array[0]); // $1;
	     cnt++;
		 endoffile=getline(file1,thisline);
		 nf=split_line(thisline);
        } 
       xsize = (int) (a[1] - a[0]);
       ysize = (int) (a[3] - a[2]);

	  // printf("xsize,ysize = %d %d \n",xsize,ysize);

       fclose(file1);

      // getline <  file2
	   endoffile=getline(file2,thisline);
	   nf=split_line(thisline);
       Xmax = atoi(str_array[0]); /// $1;

       endoffile=getline(file2,thisline);
	   nf=split_line(thisline);
       // getline <  file2
       Ymax = atoi(str_array[0]); // $1;

	   fclose(file2);

  //  print xsize | "cat 1>&2"
 //   print ysize | "cat 1>&2"
	// mult is a passed in parameter if not defined then set to 4
	if( mult  <= 0)
	{
	     mult = 4;
	}

	powval = pow(10,mult);

//	PANELSIZE = PANELSIZE * powval;
// KERF is passed in parameter if not set will be 0
	KERF = KERF * (int) powval;
	PCM = PCM * (int) powval;
	PCMLEN =  PCMLEN * (int) powval;
	MINSIZE  = MINSIZE * powval;
	TEST  = TEST * (int) powval;
	dist  = dist * powval;
	MAXSIZE  = MAXSIZE * powval;

	Xnum = (int)(MINSIZE / xsize);

	if (Xnum * xsize + (Xnum-1)* KERF < MINSIZE)
	{
	   Xnum++;
    }

	Ynum = (int) (MINSIZE / ysize);
	if (Ynum * ysize + (Ynum-1)* KERF < MINSIZE)
	{
	   Ynum++;
    }

    Xstart = 0;
    Ystart = 0;
    if( Xmax%Xnum == 2 || Xmax%Xnum == 3)
	 Xstart  = 1;
    if( Ymax%Ynum == 2 || Ymax%Ynum == 3 )
	 Ystart = 1;
     // initialize all  rows and columns to zero
    for( tmp1 = 1 ; tmp1 <= Xmax ; tmp1++)
          Xvalid[tmp1] = 0;
	 
    for( tmp1 = 1 ; tmp1 <= Ymax ; tmp1++)
          Yvalid[tmp1] = 0;

      // set appropriate rows and cols to 1
    for(tmp1 = Xstart; tmp1 <= Xmax; tmp1 += Xnum)
	    Xvalid[tmp1] = 1;
    for(tmp1 = Ystart; tmp1 <= Ymax ; tmp1 += Ynum)
	    Yvalid[tmp1] = 1;
      // output rows and cols to pcmrowcol2
      //  for use by gettestcoords
    for( tmp1 = 1 ; tmp1 <= Xmax ; tmp1++)
         fprintf(pcmrowfile,"X %d    %d  \n",tmp1,Xvalid[tmp1]); //  > "pcmrowcol2"
	 
    for( tmp1 = 1 ; tmp1 <= Ymax ; tmp1++)
          fprintf(pcmrowfile,"Y  %d   %d \n",tmp1,Yvalid[tmp1]); // > "pcmrowcol2"

//      print  "***Xnum = " Xnum "  Ynum " Ynum  " minsize " MINSIZE | "cat 1>&2"
	Xcnt = 1;
	Ycnt = 1;
//	print  "***KERF = " KERF  | "cat 1>&2"

 // XOFFSET = xsize/2 + KERF/2;
  //YOFFSET = ysize/2 + KERF/2;

  endoffile=getline(file4,thisline);  // get first part coor.
  nf=split_line(thisline);

  thisxval=atoi(str_array[0]);
  thisyval=atoi(str_array[1]);

  XBASE = thisxval; // $1
  YBASE = thisyval; // $2
  Xold = XBASE;
 // Yold = YBASE;
  Xcol =1;
  Yrow =1;

  outcoords1(thisxval, thisyval);
  outcoords23(thisxval,thisyval); // $1,$2)
  outcoords4(thisxval,thisyval); // $1,$2)


  while(endoffile==FALSE)
  {
	 thisxval=atoi(str_array[0]);
	 thisyval=atoi(str_array[1]);

     if ( Xold != thisxval ) // $1)
	 {
       Xcol++;
       Xold = thisxval; // $1;
     }
     if ( thisyval == YBASE)
	 {
	 Yrow  = 1;
     }
     if( thisxval  == XBASE)
	 { 
         outcoords1(thisxval,thisyval); // $1,$2);
     }
     if( thisyval  == YBASE)
	 {
        outcoords4(thisxval,thisyval); // $1,$2)
     }

     outcoords23(thisxval,thisyval); // $1,$2)

	 endoffile=getline(file4,thisline);
	 nf=split_line(thisline);

  }
  fclose(file4);


   i=0;
   while( i < horizontal_count )                 // in horizontal )
   {
      // split( i,val[0],val[1],SUBSEP);
      fprintf(outfile,"%d %d R\n",horizontal_array[i].xval,horizontal_array[i].yval); //
	  i++;
   }

   i=0;
   while( i <  vertical_count)
   {
      // split( i,val[0],val[1],SUBSEP);
      fprintf(outfile,"%d %d\n",vertical_array[i].xval, vertical_array[i].yval); //// 2
	  i++;
   }

   fclose(pcmrowfile);
   fclose(outfile);

}  // end getpcmkerf11_call_out

void getpcmkerf11_call( char *file1str, char *file2str, char *kerfstr, char *file4str)

{
	   KERF=atoi(kerfstr);
       mult=0;

	   horizontal_count=0;
	   vertical_count=0;

       cnt = 0;
       MINSIZE = 32;
      // PANELSIZE =  304.8;
       PCM = 1;
       PCMLEN = 30;
       TEST = 2;
       MAXSIZE = 62;
       dist = 30;

	   file1=fopen(file1str,"r");    // offval file
	   if (file1 == NULL)
	   {
		   printf("In getpcmkerf11, unable to open the input file = %s \n", file1str);
		   exit(-1);
	   }
       // file1 is offval file with xmin,xmax,ymin,ymax

       file2=fopen(file2str,"r");  // file2 has xmax ymax
	   if (file2 == NULL)
	   {
		   printf("In getpcmkerf11, unable to open the input file = %s \n", file2str);
		   exit(-1);
	   }

       file4=fopen(file4str,"r");  // file4 has part coordinant information
	   if (file4 == NULL)
	   {
		   printf("In getpcmkerf11, unable to open the input file = %s \n", file4str);
		   exit(-1);
	   }

       pcmrowfile=fopen("pcmrowcol2","w");  // file4 has part coordinant information
	   if (pcmrowfile == NULL)
	   {
		   printf("In getpcmkerf11, unable to open the output file = pcmrowcol2 \n");
		   exit(-1);
	   }

       endoffile=getline(file1,thisline);
	   nf=split_line(thisline);
       while ( endoffile == FALSE)
	   {
	     a[cnt] = atof(str_array[0]); // $1;
	     cnt++;
		 endoffile=getline(file1,thisline);
		 nf=split_line(thisline);
        } 
       xsize = (int) (a[1] - a[0]);
       ysize = (int) (a[3] - a[2]);
       fclose(file1);

      // getline <  file2
	   endoffile=getline(file2,thisline);
	   nf=split_line(thisline);
       Xmax = atoi(str_array[0]); /// $1;

       endoffile=getline(file2,thisline);
	   nf=split_line(thisline);
       // getline <  file2
       Ymax = atoi(str_array[0]); // $1;

	   fclose(file2);

  //  print xsize | "cat 1>&2"
 //   print ysize | "cat 1>&2"
	// mult is a passed in parameter if not defined then set to 4
	if( mult  <= 0)
	{
	     mult = 4;
	}

	powval = pow(10,mult);

//	PANELSIZE = PANELSIZE * powval;
// KERF is passed in parameter if not set will be 0
	KERF = KERF * (int) powval;
	PCM = PCM * (int) powval;
	PCMLEN =  PCMLEN * (int) powval;
	MINSIZE  = MINSIZE * powval;
	TEST  = TEST * (int) powval;
	dist  = dist * powval;
	MAXSIZE  = MAXSIZE * powval;

	Xnum = (int)(MINSIZE / xsize);

	if (Xnum * xsize + (Xnum-1)* KERF < MINSIZE)
	{
	   Xnum++;
    }

	Ynum = (int) (MINSIZE / ysize);
	if (Ynum * ysize + (Ynum-1)* KERF < MINSIZE)
	{
	   Ynum++;
    }

    Xstart = 0;
    Ystart = 0;
    if( Xmax%Xnum == 2 || Xmax%Xnum == 3)
	 Xstart  = 1;
    if( Ymax%Ynum == 2 || Ymax%Ynum == 3 )
	 Ystart = 1;
     // initialize all  rows and columns to zero
    for( tmp1 = 1 ; tmp1 <= Xmax ; tmp1++)
          Xvalid[tmp1] = 0;
	 
    for( tmp1 = 1 ; tmp1 <= Ymax ; tmp1++)
          Yvalid[tmp1] = 0;

      // set appropriate rows and cols to 1
    for(tmp1 = Xstart; tmp1 <= Xmax; tmp1 += Xnum)
	    Xvalid[tmp1] = 1;
    for(tmp1 = Ystart; tmp1 <= Ymax ; tmp1 += Ynum)
	    Yvalid[tmp1] = 1;
      // output rows and cols to pcmrowcol2
      //  for use by gettestcoords
    for( tmp1 = 1 ; tmp1 <= Xmax ; tmp1++)
         fprintf(pcmrowfile,"X %d    %d  \n",tmp1,Xvalid[tmp1]); //  > "pcmrowcol2"
	 
    for( tmp1 = 1 ; tmp1 <= Ymax ; tmp1++)
          fprintf(pcmrowfile,"Y  %d   %d \n",tmp1,Yvalid[tmp1]); // > "pcmrowcol2"

//      print  "***Xnum = " Xnum "  Ynum " Ynum  " minsize " MINSIZE | "cat 1>&2"
	Xcnt = 1;
	Ycnt = 1;
//	print  "***KERF = " KERF  | "cat 1>&2"

    //XOFFSET = xsize/2 + KERF/2;
    //YOFFSET = ysize/2 + KERF/2;

  endoffile=getline(file4,thisline);  // get first part coor.
  nf=split_line(thisline);

  thisxval=atoi(str_array[0]);
  thisyval=atoi(str_array[1]);

  XBASE = thisxval; // $1
  YBASE = thisyval; // $2
  Xold = XBASE;
 // Yold = YBASE;
  Xcol =1;
  Yrow =1;

  outcoords1(thisxval, thisyval);
  outcoords23(thisxval,thisyval); // $1,$2)
  outcoords4(thisxval,thisyval); // $1,$2)


  while(endoffile==FALSE)
  {
	 thisxval=atoi(str_array[0]);
	 thisyval=atoi(str_array[1]);

     if ( Xold != thisxval ) // $1)
	 {
       Xcol++;
       Xold = thisxval; // $1;
     }
     if ( thisyval == YBASE)
	 {
	 Yrow  = 1;
     }
     if( thisxval  == XBASE)
	 { 
         outcoords1(thisxval,thisyval); // $1,$2);
     }
     if( thisyval  == YBASE)
	 {
        outcoords4(thisxval,thisyval); // $1,$2)
     }

     outcoords23(thisxval,thisyval); // $1,$2)

	 endoffile=getline(file4,thisline);
	 nf=split_line(thisline);

  }
  fclose(file4);


  // printf("vertical count = %d horizontal count = %d \n",vertical_count,
	  //     horizontal_count);

   i=0;
   while( i < horizontal_count )                 // in horizontal )
   {
      // split( i,val[0],val[1],SUBSEP);
      printf("%d %d R\n",horizontal_array[i].xval,horizontal_array[i].yval); //
	  i++;
   }

   i=0;
   while( i <  vertical_count)
   {
      // split( i,val[0],val[1],SUBSEP);
      printf("%d %d\n",vertical_array[i].xval, vertical_array[i].yval); //// 2
	  i++;
   }

   fclose(pcmrowfile);

}  // end getpcmkerf11_call

int main( int argc, char **argv)
{

   getpcmkerf11_call( argv[1], argv[2], argv[3],argv[4]);

} // end main
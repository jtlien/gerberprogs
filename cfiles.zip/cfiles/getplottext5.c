
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
//#include <winnt.h>

#include <time.h>
#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1


struct datearstuff
{
	char date_str[40];
	char fname_str[120];
} date_array[1000];

int datearray_cnt;


//
// check to see if the array of dates/filenames
//
int in_datearray( char *infname_str)
{
int ii;
int fname_found;

 ii = 0;
 fname_found=FALSE;
 while( (ii < datearray_cnt) && (fname_found == FALSE))
 {
	 if ( strcmp(infname_str,date_array[ii].fname_str) == 0)
	 {
		 fname_found=TRUE;
	 }

	ii +=1;
 }

 
 return(fname_found);

}  // in_datearray

//
// Add to array of dates/fnames
//
void add_to_datearray( char *infname_str,char *indate_str)
{
int ii;
int fname_found;

 ii = 0;
 fname_found=FALSE;
 while( (ii < datearray_cnt) && (fname_found == FALSE))
 {
	 if ( strcmp(infname_str,date_array[ii].fname_str) == 0)
	 {
		 fname_found=TRUE;
		 strncpy(date_array[ii].date_str,indate_str,40);
	 }

	ii +=1;
 }

 if (fname_found == FALSE)
	{
	  strncpy(date_array[datearray_cnt].date_str,indate_str,40);
	  strncpy(date_array[datearray_cnt].fname_str,infname_str,120);

	  if (datearray_cnt < 1000)
	  {
	   datearray_cnt += 1;
	  }
	  else
	  {
		  printf("datearray overflow \n");
	  }
 }

}  // add_to_datearray

//
// Add to array of dates/fnames
//
void get_from_datearray( char *infname_str, char *outdate_str)
{
int ii;
int fname_found;

 ii = 0;
 fname_found=FALSE;
 while( (ii < datearray_cnt) && (fname_found == FALSE))
 {
	 if ( strcmp(infname_str,date_array[ii].fname_str) == 0)
	 {
		 fname_found=TRUE;
		 strncpy(outdate_str,date_array[ii].date_str,40);
	 }

	ii +=1;
 }

 if (fname_found == FALSE)
 {
	  
	 printf("Error in get_from_datearray \n");
	 strncpy(outdate_str,"",10);

 }

}  // get_from_datearray

//
//  split the time string and put the results in time_array
//
int split_time( char *tline)
{
int ii;
char tstr[200];
char *token;


 ii = 0;

 strncpy( tstr, tline,200);

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( time_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_time


void split_3( char *instr, char *outstr1, char *outstr2,char *outstr3, char *srchstr)
{

int ii,kk;

  ii=0;
  kk = 0;

 while((instr[ii] != srchstr[0]) && ( ii < (int) strlen(instr)) && ( ii < 120) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != srchstr[0]) && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;

  ii += 1;
  outstr3[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr3[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr3[kk]= 0;


}  // end split3

// calling syntax



int getplottext5_call(  char *brd, char *tail, char *cust, char *controlfilestr)
{
char thisline[200];
char thisline2[300];
char fname[300];
char fnameplustail[120];

char lname[120][120];
char mycust[120];
char temp_str[300];

char *mytimestr;

FILE *file1;
FILE *finfofile;
FILE *namefile;
FILE *makelogfile;


long filesize;
int cnt;
int status;
int nf;
char tmpcust[120][120];

int endoffile;
int endoffile2;

int brdrev;
double X1;
double Y1;
double Y2;
double Y3;
double Y4;
double Y5;
double Y6;
double Y7;
double Y8;
double Y9;
double Y10;
double Y11;
double Y12;
int flag;
int layercnt;
int maxcnt;
int actcnt;
char dsg[300];
char year[120];
char date[300];
char myname[120][120];
char myname_tu[120][120];
char myname1[200];

char tempstr[200];

char name[300];
char layercnt_str[120];
char tstr[120];
char filename[300];
char fdate[300];
char mydesc[200];
int debug;
int kk;

  debug=0;
  datearray_cnt = 0;
  layercnt=0;

  brdrev = -1;
  X1 = 7.62;
  Y1 = 137;
  Y2 = Y1 - 4;
  Y3 = Y2 - 10;
  Y4 = Y3 - 4;
  Y5 = Y4 - 4;
  Y6 = Y5 - 4;
  Y7 = Y6 - 10;
  Y8 = Y7 - 4;
  Y9 = 13;
  Y10 = Y9-4;
  Y11 = Y9 +17;
  Y12 = Y11 - 4;

  // parse header

  file1= fopen( controlfilestr,"r");
  if (file1 == NULL)
  {
	  printf("In getplottext5, unable to open the input file = %s \n", controlfilestr);
	  exit(-1);
  }

  endoffile = getline(file1,thisline);
  nf=split_line(thisline);

  while( nf < 3)
  {
	//printf("Line in(1)= %s \n",thisline);

    if( strcmp(str_array[0],"BRDREV") == 0 )
	 {
		
	  brdrev=atoi(str_array[1]);
	  if (debug) { printf("brdrev = %d \n",brdrev); }

	}
    endoffile=getline(file1,thisline);
	nf=split_line(thisline);


  }

 

  // date piped into getline "date" |getline 
  // $2 is month $3 is day $6 is year

  mytimestr=malloc(200);
  mytimestr=gettime_str();

  //split_time(mytimestr);

  //date =  ($2 "-" $3 "-" $6)
  strncpy(date,daystr,120);
  strncat(date,"-",4);
  strncat(date,monthstr,120);
  strncat(date,"-",4);
  strncat(date,yearstr,120);

  strncpy(year,yearstr,120);
  // year = $6

  finfofile=fopen("finfo","r");
  
  if (finfofile==NULL)
  {
	  printf("In getplottext5, unable to open the input file = finfo \n");
	  exit(-1);
  }
  endoffile2=getline(finfofile,thisline2);
  nf=split_line(thisline2);

  while( endoffile2 == FALSE)
  {
	    //printf("Line in(2)= %s \n",thisline2);
		if (strcmp( str_array[3],"Domain") == 0 )   // ls like in FSU on Windows
		{
          split_3(str_array[9],lname[0],lname[1],lname[2],"/");
		  if( strstr(str_array[8],":") != NULL )
		  {
		   strncpy(fdate,str_array[6],40);
		   strcat(fdate,"-");
		   strncat(fdate,str_array[7],40);
		   strcat(fdate,"-");
		   strcat(fdate,year);
		  }
          else 
		  {
	     // fdate = ($6"-"$7"-"$8)
           strncpy(fdate,str_array[6],40);
		   strcat(fdate,"-");
		   strncat(fdate,str_array[7],40);
		   strcat(fdate,"-");
		   strncat(fdate,str_array[8],40);
		  }
       }
       else    // hp unix style ls   column 8 is the filename
	   {
          split_3(str_array[8],lname[0],lname[1],lname[2],"/");
		  if( strstr(str_array[7],":") != NULL )
		  {
		   strncpy(fdate,str_array[5],40);
		   strcat(fdate,"-");
		   strncat(fdate,str_array[6],40);
		   strcat(fdate,"-");
		   strcat(fdate,year);
		  }
          else 
		  {
	     // fdate = ($6"-"$7"-"$8)
           strncpy(fdate,str_array[5],40);
		   strcat(fdate,"-");
		   strncat(fdate,str_array[6],40);
		   strcat(fdate,"-");
		   strncat(fdate,str_array[7],40);
		  }

		}

	  // printf("lname 1,2,3 = %s %s %s \n",lname[0],lname[1],lname[2]);

       add_to_datearray(lname[2],fdate);

	endoffile2=getline(finfofile,thisline2);
	nf=split_line(thisline2);

 }

 fclose(finfofile);
 

 if (debug) { printf("closed finfofile \n"); }

//printf("after close finfofile brdrev = %d \n",brdrev);

 endoffile=getline(file1,thisline);  // skip past header
 nf=split_line(thisline);

 maxcnt=0;
 actcnt=0;

 while(endoffile==FALSE)
 {
	 if (debug) { printf("Line in(3)= %s ",thisline); }

    split(str_array[1],myname[0],myname[1],".");

	myname[1][120]='\0';

    cv_toupper( myname[1],myname_tu[1]);

    if( (strcmp(str_array[2],"PS")!= 0) &&
		(strcmp(str_array[2],"OUTLINE")!= 0) &&
		(strcmp(str_array[2],"CUTOUT") != 0 ) &&
		(strcmp(myname_tu[1],"NA")!=0))
	{
       maxcnt++;
       //fname =(myname[1] "." tail)
	   strncpy(fname,myname[0],120);
	   strcat(fname,".");
	   strcat(fname,tail);
	   
       if (debug) { printf ("fname = %s  in getplottext5 \n", fname ); }

       if ( in_datearray(fname))
	   {
	    actcnt++;
       }
       else
	   {
	    printf("WARNING: FILE NOT FOUND- %s  \n",fname);
       }
    }
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

 }

  
 fclose(file1);

 flag=0;

 if( strcmp(cust,"1") == 0 )
 {
	 makelogfile=fopen("makelog","r");
	 if (makelogfile==NULL)
	 {
		 printf("In getplottext5, unable to open the makelog file for reading \n");
		 exit(-1);
	 }
	 endoffile=getline(makelogfile,thisline);
	 nf=split_line(thisline);

     while( (flag != 2) && ( endoffile==FALSE))
	 {
		 if (debug) { printf("Reading makelogfile , line = %s \n", thisline); }

	  if(strstr(thisline,"Customer") != NULL)
	  { 
	     split(thisline,tmpcust[0],tmpcust[1],":");
	     strncpy(mycust,tmpcust[1],120);
	     flag++;
          }
	  if(strstr(thisline,"Description") != NULL)
		{
	     awk_substr(thisline,13,strlen(thisline),mydesc);
		 for(kk=0; kk < (int) strlen( mydesc); kk += 1)
		 {
			 if (mydesc[kk]== '\n')
			 {
				 mydesc[kk] = '\0';
			 }
		 }
	     flag++;
        }
	 endoffile=getline(makelogfile,thisline);
	 nf=split_line(thisline);

     } 
	fclose(makelogfile);
  }

  // "whoami" | getline
  get_whoami(dsg);

  // dsg = $1

  cnt = 1;
  layercnt=1;


  file1=fopen(controlfilestr,"r");
  if (file1 == NULL)
  {
	  printf("Unable to re-open input file =%s for reading \n",controlfilestr);
	  exit(-1);
  }
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {

	  if (debug) { printf("Line in (4) = %s ", thisline); }

     split(str_array[1],myname[0],myname[1],".");

	 cv_toupper(myname[1],myname_tu[1]);


     if((nf > 2) && (strcmp(str_array[0],"NAME") != 0 ) && 
		            (strcmp(str_array[2],"OUTLINE") != 0) &&
					(strcmp(str_array[2],"CUTOUT") != 0 ) &&
					(strcmp(str_array[2],"PS")!=0) &&
					(strcmp(myname_tu[1],"NA") != 0 ))
	 {
       strncpy(fname,myname[0],120);

//	myname1 = (fname "." tail)
      strncpy(myname1,fname,120);
	  strcat(myname1,".");
	  strncat(myname1,tail,40);

	  if (debug) { printf("fname=%s myname1 = %s \n", fname, myname1); }

//	filename = (fname "." tail) 

      strncpy(filename,fname,120);
      strcat(filename,".");
	  strncat(filename,tail,40);

      if( strcmp(tail,"art") == 0)
	  {
	     // filename = ("pre-bias/"filename)
		
		 strncpy(tstr,"pre-bias/",120);
		 strcat(tstr,filename);
		 strncpy(filename,tstr,120);
	  }

    else if ( (strcmp(str_array[2],"BURIED") == 0) ||
		      (strcmp(str_array[2],"THRU") == 0))
	 { 
	    
         strncpy(tstr,"aoi/",120);
		 strcat(tstr,filename);
		 strncpy(filename,tstr,120);
	
	}  
    else
	{  
         strncpy(tstr,"mfg/",120);
		 strcat(tstr,filename);

		 strncpy(filename,tstr,120);	
   } 

  // command = ("ls -l " fname "." tail)


	if (debug) { printf("filename = %s \n",filename); }

   strncpy(fnameplustail,fname,120);
   strncat(fnameplustail,".",10);
   strncat(fnameplustail,tail,120);

   if (debug)
   {
   printf("About to call in_datearray , myname1 = %s \n",myname1);
   }

   if( in_datearray(myname1)) 
   {
          //name = (layercnt"."fname".pwin")

	   sprintf(layercnt_str,"%d",layercnt);

	   if (debug) { printf("layercnt_str = %s \n",layercnt_str); }

      strncpy(name,layercnt_str,40);
	  strncat(name,"_",10);
	  strncat(name,fname,120);
	  strncat(name,".pwin",10);

	  if (debug) { printf("name = %s \n",name); }
	  layercnt+=1;

	  namefile=fopen(name,"w");
	  
	  if (namefile==NULL)
	  {
		  printf("In getplottext5, unable to open the output file = %s \n",name);
		  exit(-1);
	  }

	  // printf("%d %s\n",layercnt,layercnt)

      fprintf(namefile, "4\n"); //  default multiplier =4 (will fix later)

	  // print board name and designer
	  if( brdrev == -1)
	  {

		awk_substr(brd,1,12,temp_str);
       fprintf(namefile,"%4.2f %d %s \n",X1,(int)Y1,temp_str);
	   if (debug)
	   {
	     printf("Printed the board rev = %d \n",brd);
	   }
      }
	  else
	  {
		  
		  awk_substr(brd,1,12,temp_str);
        fprintf(namefile,"%4.2f %d %s REV %d\n",X1,(int)Y1,temp_str,brdrev);
      }

      awk_substr(dsg,1,9,temp_str);
      fprintf(namefile,"%4.2f %d DESIGNER %s \n",X1,(int)Y2,temp_str); // dsgnr

	  if (debug) { printf("Printed the designer string = %s \n",dsg); }

	  // print file info
	      awk_substr(str_array[0],1,12,temp_str);
          fprintf(namefile,"%4.2f %d %s REV %s\n",X1,(int)Y3,temp_str,str_array[6]); 
		  if (debug)
		  {
		   printf("printed the rev string = %s \n", str_array[6] ); // layer &rev
		  }

          awk_substr(filename,1,18,temp_str);
          fprintf(namefile,"%4.2f %d %s \n",X1,(int)Y4,temp_str);     // filename
		  if (debug)
		  {
		  printf("Printed the filename = %s \n",temp_str);
		  }

          get_from_datearray(myname1,tempstr);

		  if (debug)
		  {
		  printf("myname1 = %s returned from get_from_datearray =%s \n",myname1,tempstr);
		  }

          fprintf(namefile,"%4.2f %d %s \n",X1,(int)Y5,tempstr);      // filedate
		  if (debug)
		  {
		  printf("Printed the filedate = %s \n", myname1);
		  }


	  // command |getline
	 // filesize = atoi(str_array[4]);   // gotten from ls -l 

		  filesize=GetTheFileSize( fnameplustail );
         
		  if (debug)
		  {
		  printf("filesize = %d file = %s \n",(int)filesize,fnameplustail);
		  }

          fprintf(namefile,"%4.2f %d FILESIZE %d \n",X1,(int)Y6,(int)filesize);  // size

	  if( (atoi(cust) == 1 ) && (strcmp(mycust,"0") != 0))
	  {
		       awk_substr(mycust,1,18,temp_str);
               fprintf(namefile,"%4.2f %d %s \n",X1,(int)Y7,temp_str); // customer
      }
	  
	  if( (atoi(cust) == 1) && (strcmp(mydesc,"0") != 0))
	  {
		       awk_substr(mydesc,1,18,temp_str);
               fprintf(namefile,"%4.2f %d %s \n",X1,(int)Y8,temp_str);  // cust desc.
      }
      fprintf(namefile,"%4.2f %d @ 3M, %s\n",X1,(int)Y11,year);
      fprintf(namefile,"%4.2f %d SHEET %d OF %d \n",X1,(int)Y9,cnt,actcnt);
      fprintf(namefile,"%4.2f %d %s \n",X1,(int)Y10,date);    // plot date
	  fclose(namefile);
      cnt++;
   }   // if in_datearray
  }
  
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  }

  fclose(file1);

  if (actcnt != maxcnt)
  {
     printf("WARNING:\n\t%d FILE(S) NOT PRINTED \n",maxcnt-actcnt);
     status = 1;
  }
  else 
  {
     printf("%d FILES PRINTED \n",maxcnt); 
     status = 0;
  }

  return(status);

} // END


int getplottext5_call_wp ( char *path, char *brd, char *tail, char *cust, char *controlfilestr)
{
int retval;

	retval=getplottext5_call( brd, tail, cust, controlfilestr);
	return(retval);
}

/*
int main( int argc, char **argv)
{
int retval;

	if (argc != 5)
	{
		printf("Wrong number of arguments for getplottext5 \n");
		printf("Usage: getplottext5  brdname tailstr customer controlfile\n");
		exit(-1);
	}
	else
	{
		retval=getplottext5_call( argv[1], argv[2], argv[3], argv[4]);
		exit(retval);
	}

}  // end main

  */

 
 


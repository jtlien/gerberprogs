#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


#define MAXARRAY 10000

char x[MAXARRAY][40];
char y[MAXARRAY][40];

// getpunchcoords reads in the partcoords file ( created by getcoords3 and
//             getpcmkerf11) 
//           It will use the first line of partcoords as the base for x and y
//           It will output to the output file all the coordinants that match either this
//              X base or this Y base
//           The X's that match are put out first 
//           then the Y's that match in the case of flag=THIEV

//           For the case of flag=PUNCH, only the X coordinants are put out

void getpunchcoords_call( char *multstr, char *flagstr, char *file1str)
 {
int xcnt;
int ycnt;
char XBASE[120];
char YBASE[120];
char thisline[200];
int endoffile;
int nf;
FILE *file1;
double YHIGH;
double YLOW;
int i;
int multval;

   multval=atoi(multstr);

   if (multval <= 0 )
   {
	   multval=4;
   }

   YHIGH = 157.48 * pow(10.0,multval);

   YLOW = YHIGH * -1;

   file1  = fopen(file1str, "r");

   if (file1 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",file1str);
	  exit(-1);
   }

    endoffile=getline(file1,thisline);
    nf=split_line(thisline);

    // getline   get first part coor.
    strncpy(XBASE,str_array[0],120);
    strncpy(YBASE,str_array[1],120); 
    xcnt = 0;
    ycnt = 0;
    strncpy(x[xcnt],XBASE,120);  //
    strncpy(y[ycnt],YBASE,120);   //
    xcnt++;
    ycnt++;

    // end of BEGIN

    endoffile=getline(file1,thisline);
    nf=split_line(thisline);

    while(endoffile==FALSE)
    {
      if(strcmp(str_array[0],XBASE) == 0)
	{
	  if (ycnt < MAXARRAY)
	    {
	     strncpy(y[ycnt],str_array[1],40);
	     ycnt++;
            }
          else
	    {
              printf("array size exceeded in getpunchcoords \n");
              exit(-1);
            }
      }
      if( strcmp(str_array[1],YBASE)== 0 )
	  {
	   if (xcnt < MAXARRAY)
	    {
	     strncpy(x[xcnt],str_array[0],40); 
	     xcnt++;
            }
       else
            {
              printf("array size exceeded in getpunchcoords \n");
              exit(-1);
            }
       }
      endoffile=getline(file1,thisline);
      nf=split_line(thisline);
    }
   fclose(file1);

 if ( strcmp(flagstr,"THIEV")==0 )
 {
   for( i = 0; i < xcnt ; i++)
   {
       printf("X %s\n", x[i]);
   }

   for( i = 0 ; i < ycnt  ; i++)
   {
       printf("Y %s\n",y[i]);
   }
 }
 else if ( strcmp(flagstr,"PUNCH" )==0)
 {
   for( i = 0; i < xcnt ; i++)
   {
       printf("%s %0.0f\n", x[i], YHIGH);
       printf("%s %0.0f\n", x[i], YLOW);
   }
 }
   
 }  // end getpunchcoords_call

void getpunchcoords_call_out( char *multstr, char *flagstr, char *file1str, char *outfilestr)
 {
int xcnt;
int ycnt;
char XBASE[120];
char YBASE[120];
char thisline[200];
int endoffile;
int nf;
FILE *file1;
FILE *outfile;
double YHIGH;
double YLOW;
int i;
int multval;

   multval=atoi(multstr);

   if (multval <= 0 )
   {
	   multval=4;
   }

   YHIGH = 157.48 * pow(10.0,multval);

   YLOW = YHIGH * -1;

   file1  = fopen(file1str, "r");

   if (file1 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",file1str);
	  exit(-1);
   }
   outfile = fopen(outfilestr, "w");

   if (outfile == NULL)
   {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
   }

    endoffile=getline(file1,thisline);
    nf=split_line(thisline);

    // getline   get first part coor.
    strncpy(XBASE,str_array[0],120);
    strncpy(YBASE,str_array[1],120); 
    xcnt = 0;
    ycnt = 0;
    strncpy(x[xcnt],XBASE,120);  //
    strncpy(y[ycnt],YBASE,120);   //
    xcnt++;
    ycnt++;

    // end of BEGIN

    endoffile=getline(file1,thisline);
    nf=split_line(thisline);

    while(endoffile==FALSE)
    {
      if(strcmp(str_array[0],XBASE) == 0)
	{
	  if (ycnt < MAXARRAY)
	    {
	     strncpy(y[ycnt],str_array[1],40);
	     ycnt++;
            }
          else
	    {
              printf("array size exceeded in getpunchcoords \n");
              exit(-1);
            }
      }
      if( strcmp(str_array[1],YBASE)== 0 )
	  {
	   if (xcnt < MAXARRAY)
	    {
	     strncpy(x[xcnt],str_array[0],40); 
	     xcnt++;
            }
       else
            {
              printf("array size exceeded in getpunchcoords \n");
              exit(-1);
            }
       }
      endoffile=getline(file1,thisline);
      nf=split_line(thisline);
    }
   fclose(file1);

 if ( strcmp(flagstr,"THIEV")==0 )
 {
   for( i = 0; i < xcnt ; i++)
   {
       fprintf(outfile,"X %s\n", x[i]);
   }

   for( i = 0 ; i < ycnt  ; i++)
   {
       fprintf(outfile,"Y %s\n",y[i]);
   }
 }
 else if ( strcmp(flagstr,"PUNCH" )==0)
 {
   for( i = 0; i < xcnt ; i++)
   {
       fprintf(outfile,"%s %0.0f\n", x[i], YHIGH);
       fprintf(outfile,"%s %0.0f\n", x[i], YLOW);
   }
 }
   
 }  // end getpunchcoords_call_out


int main( int argc, char **argv)
{

  if (argc != 4 )
  {
    printf("In getpunchcoords, wrong number of arguments \n");
	printf("Usage: getpunchcoords mult [PUNCH|THIEV] infile \n");
	exit(-1);
   }
  else
  {
  getpunchcoords_call( argv[1], argv[2], argv[3]);
  }
}  

  




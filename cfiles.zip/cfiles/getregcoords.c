#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


double TESTSIZE;

char str_array[120][120];
struct coordstuff
{
	int ok;
	double X;
	double Y;
}  coords[100000];

int arrayindex;
int Xvalid[5000];
int Yvalid[5000];


int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line


//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

int isvalid( double myX , double myY, int okval)
{
double myY1;
int result;

    result = 0;
    if( myX >= 0)
	{
       myX = myX + TESTSIZE/2;
    }
    else
	{
       myX = myX - TESTSIZE/2; 
    }

    if( myY  >= 0)
	{
       myY  = myY + TESTSIZE/2;
       myY1 = myY - TESTSIZE/2;
    }
    else
	{
       myY  = myY - TESTSIZE/2;
       myY1 = myY + TESTSIZE/2;
    }
    if( (myX >= -1544000 )&& (myX <= 1544000) && 
		(myY >= -1544000) && ( myY  <= 1544000) && (okval == 1))
	{
       result =1;
    }

    // prevent test mark placement in alignment mark area

    if( (myX  < -1525000 || myX > 1525000) && (myY1  < 250000 && myY1  > -250000)) 
	{
       result = 0;
    }
   return(result );
}

int getregcoords_call_out(char *file1str, char *file2str, char *file3str, char *kerfstr,
					  char *file4str, char *outfilestr)
{


double PANELSIZE;
double KERF;
double XOFFSET;
double YOFFSET;
int arrayindex;
double xsize;
double ysize;
double a[100];
int i;
int z;
int cnt;
int Xcol;
int Yrow;
double XBASE;
double YBASE;
int Xmax;
int Ymax;
double Xold;
int mult;
int Xoutside;
int Youtside;

int nf;
int endoffile;
char thisline[200];
FILE *file1,*file2,*file3,*file4;
FILE *outfile;


	   KERF=atof(kerfstr);

	   mult = -1;  // how does this get set????

       cnt = 0;

	   file1= fopen(file1str,"r");
	   if (file1 == NULL)
	   {
		   printf("In getregcoords, unable to open the input file = \n",file1str);
		   exit(-1);
	   }

       outfile= fopen(outfilestr,"w");
	   if (outfile == NULL)
	   {
		   printf("In getregcoords_call_out, unable to open the output file = %s\n",outfilestr);
		   exit(-1);
	   }

	   endoffile=getline(file1,thisline);
	   nf=split_line(thisline);

       while (endoffile==FALSE)
	   {
	    a[cnt] = atof(str_array[0]); // $1;
	    cnt++;
	    endoffile=getline(file1,thisline);
	    nf=split_line(thisline);
        } 

	   fclose(file1);

       xsize = (a[1] - a[0]);
       ysize = (a[3] - a[2]);
        // print "xsize " xsize "   ysize " ysize | "cat 1>&2"

       Xoutside = 0;
       Youtside = 0;

       file3= fopen(file3str,"r");
	   if (file3 == NULL)
	   {
		   printf("In getregcoords, unable to open the input file = %s \n", file3str);
		   exit(-1);
	   }

       // getline <  file3
	   endoffile=getline(file3,thisline);
	   nf=split_line(thisline);

       Xmax = atoi(str_array[0]);  // $1
      //  getline <  file3

       endoffile=getline(file3,thisline);
	   nf=split_line(thisline);

	   fclose(file3);

       Ymax = atoi(str_array[0]);  // $1

       for( z =1 ; z <= Xmax ; z++)
	   {
	     Xvalid[z] = -1;
       }

       for( z =1 ; z <= Xmax ; z++)
	   {
	     Yvalid[z] = -1;
       }

       file2=fopen(file2str,"r");
	   if (file2 == NULL)
	   {
		   printf("In getregcoords, unable to open the input file = %s \n",file2str);
		   exit(-1);
	   }

	   endoffile=getline(file2,thisline);
	   nf=split_line(thisline);

       while (endoffile==FALSE)
	   {
		 arrayindex=atoi(str_array[1]);

		 if ((arrayindex < 0 ) || ( arrayindex > 5000))
		 {
			 printf("In getregcoords, Xvalid and Yvalid array bounds exceeded \n");
			 exit(-1);
		 }
	     if( (strcmp(str_array[0],"X") == 0 ) && (strcmp(str_array[2],"1") == 0 ))
		 {
	     Xvalid[arrayindex] = 1;
		 }
	     else if ( (strcmp(str_array[0],"X") == 0 ) && (strcmp(str_array[2],"0") == 0 ))
		 {
	     Xvalid[arrayindex] = 0;
		 }

	     if( (strcmp(str_array[0],"Y") == 0 ) && (strcmp(str_array[2],"1") == 0 ))
		 {
	     Yvalid[arrayindex] = 1;
           }
	     else if ( (strcmp(str_array[0],"Y") == 0 ) && (strcmp(str_array[2],"0") == 0 ))
		 {
	     Yvalid[arrayindex] = 0;
           }

         if(( strstr(str_array[0],"Xoutside") != NULL) && (strcmp(str_array[1],"YES") == 0 ))
		 {
	     Xoutside = 1;
		 }

         if(( strstr(str_array[0],"Youtside") != NULL) && (strcmp(str_array[1],"YES") == 0 ))
		 {
	     Youtside = 1;
		 }

		 endoffile=getline(file2,thisline);
		 nf=split_line(thisline);

       } 

	  fclose(file2);

//for( z = 0 ; z <= Xmax ; z++)
 //    printf( "%d  %d %d\n",z,Xvalid[z], Yvalid[z]) | "cat 1>&2"
   // mult is a passed in parameter if not defined then set to 4

   if( mult <= 0)
   {
       mult = 4;
   }

 //  printf( "%d %d\n",Xoutside,Youtside) | "cat 1>&2"

   PANELSIZE = 308.8 * pow(10,mult);

   // KERF is passed in parameter if not set will be 0

   KERF = KERF * pow(10,mult);

//  print "*** Test cooords KERF = " KERF | "cat 1>&2"

   TESTSIZE = 4  * pow(10,mult );

   XOFFSET = (xsize/2) + (KERF/2) ;
   YOFFSET = (ysize/2) + (KERF/2);
  cnt = 1;
  // X = 0;
  // Y = 1;

  file4= fopen(file4str,"r");
	   if (file4 == NULL)
	   {
		   printf("In getregcoords, unable to open the input file = %s \n",file4str);
		   exit(-1);
	   }

  endoffile= getline(file4,thisline);
  nf=split_line(thisline);

  XBASE = atof(str_array[0]);  // $1
  YBASE = atof(str_array[1]); // $2
  Xold = XBASE;

  Xcol = 1;
  Yrow = 1;
  // please note use of postfix increment operator (++  i.e. cnt++)
  // this increment the cnt AFTER the value has been stored
  
  coords[cnt].ok =  (Yvalid[Yrow] == 1 || Youtside == 0 || (Yrow == Ymax && Yvalid[Yrow] != -1));
  coords[cnt].X = atof(str_array[0])-XOFFSET; // $1 - XOFFSET;
  coords[cnt++].Y = atof(str_array[1]) + YOFFSET; // $2 + YOFFSET;

  coords[cnt].ok = ( (Xvalid[Xcol] == 1 && Yvalid[Yrow] == 1) || 
	  (xsize >= 320000 && ysize >=320000 && Xvalid[Xcol] == 0 && Yvalid[Yrow] == 0));
  coords[cnt].X =  atof(str_array[0]) + XOFFSET; // $1 + XOFFSET;
  coords[cnt++].Y = atof(str_array[1]) + YOFFSET;  //  $2 + YOFFSET;

  coords[cnt].ok =  (Xvalid[Xcol] == 1 || Xoutside == 0 || (Xcol == Xmax&& Xvalid[Xcol] != -1));
  coords[cnt].X =  atof(str_array[0]) + XOFFSET; // $1 + XOFFSET;
  coords[cnt++].Y = atof(str_array[1]) - YOFFSET; // $2 - YOFFSET;

  coords[cnt].ok = ( Xvalid[Xcol] != -1 && Yvalid[Yrow] != -1 );
  coords[cnt].X =  atof(str_array[0]) - XOFFSET; // $1 - XOFFSET;
  coords[cnt++].Y   =  atof(str_array[1])-YOFFSET; // $2 - YOFFSET;

  Yrow++;

  endoffile=getline(file4,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {
      if ( Xold != atof(str_array[0]) )  // $1)
	  {
           Xcol++;
           Xold = atof(str_array[0]); // $1;
      }
      if ( atof(str_array[1]) == YBASE) // $2 == YBASE)
	  {
	     Yrow  = 1;
      }
     
     //if( Xcol < 3 )
     //  printf( "%d %d %d %d %d\n",cnt,Xcol,Yrow,Xvalid[Xcol], Yvalid[Yrow]) | "cat 1>&2"
     if( (Xcol == Xmax && Yvalid[Yrow] == 1 ) || ( Yrow == Ymax && Xvalid[Xcol] == 1))
	 {
	 coords[cnt].ok = 1;
     }
     else if ( (Xcol == Xmax && Yvalid[Yrow] == 0 ) || ( Yrow == Ymax && Xvalid[Xcol] == 0)){
	 coords[cnt].ok = 0;
     }
     else
	 {
       coords[cnt].ok = ( (Xvalid[Xcol] == 1 && Yvalid[Yrow] == 1) );
	   if( xsize >= 320000 && ysize >=320000 && (Xvalid[Xcol] == 0 && Yvalid[Yrow] == 0))
	   {
	    coords[cnt].ok = 1;
       }
	 } 
     if( (Yrow == Ymax && Xoutside == 0) || (Xcol == Xmax && Youtside == 0) ||
			       (Xcol == Xmax && Yrow == Ymax && Xvalid[Xcol] != -1 && Yvalid[Yrow] != -1))
	 {
	  coords[cnt].ok = 1;
	 }

     coords[cnt].X = atof(str_array[0]) + XOFFSET; // $1 + XOFFSET;
     coords[cnt++].Y = atof(str_array[1] ) + YOFFSET; // $2 + YOFFSET;

     if( atof(str_array[0]) == XBASE)   // $1 == XBASE)
	 {
	 coords[cnt].ok =  (Yvalid[Yrow] == 1 || Youtside == 0 || (Yrow == Ymax && Yvalid[Yrow] != -1));
     coords[cnt].X =  atof(str_array[0]) - XOFFSET; // $1 - XOFFSET;
	 coords[cnt++].Y = atof(str_array[1]) - YOFFSET; // $2 + YOFFSET;
     }
     if( atof(str_array[1]) == YBASE)  // $2 == YBASE)
	 {
	 coords[cnt].ok =  (Xvalid[Xcol] == 1 || Xoutside == 0 || (Xcol == Xmax&& Xvalid[Xcol] != -1));
     coords[cnt].X =  atof(str_array[0]) + XOFFSET; // $1 + XOFFSET;
	 coords[cnt++].Y = atof(str_array[1] ) - YOFFSET; // $2 - YOFFSET;
     }

     Yrow++;
	endoffile=getline(file4,thisline);
	nf=split_line(thisline);
  }
  fclose(file4);

   for( i = 1; i <= cnt ; i++ )
   {
     // if( i < 30)
     // printf( "%d %d\n",i,coords[i].ok) | "cat 1>&2"
      if( isvalid( coords[i].X , coords[i].Y, coords[i].ok))
	  { 
          fprintf(outfile,"%f %f\n", coords[i].X, coords[i].Y);
      }
   }

   fclose(outfile);

   return(0);

}  // end getregcoords_call_ouy

int getregcoords_call(char *file1str, char *file2str, char *file3str, char *kerfstr,
					  char *file4str)
{


double PANELSIZE;
double KERF;
double XOFFSET;
double YOFFSET;
int arrayindex;
double xsize;
double ysize;
double a[100];
int i;
int z;
int cnt;
int Xcol;
int Yrow;
double XBASE;
double YBASE;
int Xmax;
int Ymax;
double Xold;
int mult;
int Xoutside;
int Youtside;

int nf;
int endoffile;
char thisline[200];
FILE *file1,*file2,*file3,*file4;


	   KERF=atof(kerfstr);

	   mult = -1;  // how does this get set????

       cnt = 0;

	   file1= fopen(file1str,"r");
	   if (file1 == NULL)
	   {
		   printf("In getregcoords, unable to open the input file = %s \n",file1str);
		   exit(-1);
	   }

	   endoffile=getline(file1,thisline);
	   nf=split_line(thisline);

       while (endoffile==FALSE)
	   {
	    a[cnt] = atof(str_array[0]); // $1;
	    cnt++;
	    endoffile=getline(file1,thisline);
	    nf=split_line(thisline);
        } 

	   fclose(file1);

       xsize = (a[1] - a[0]);
       ysize = (a[3] - a[2]);
        // print "xsize " xsize "   ysize " ysize | "cat 1>&2"

       Xoutside = 0;
       Youtside = 0;

       file3= fopen(file3str,"r");
	   if (file3 == NULL)
	   {
		   printf("In getregcoords, unable to open the input file = %s \n", file3str);
		   exit(-1);
	   }

       // getline <  file3
	   endoffile=getline(file3,thisline);
	   nf=split_line(thisline);

       Xmax = atoi(str_array[0]);  // $1
      //  getline <  file3

       endoffile=getline(file3,thisline);
	   nf=split_line(thisline);

	   fclose(file3);

       Ymax = atoi(str_array[0]);  // $1

       for( z =1 ; z <= Xmax ; z++)
	   {
	     Xvalid[z] = -1;
       }

       for( z =1 ; z <= Xmax ; z++)
	   {
	     Yvalid[z] = -1;
       }

       file2=fopen(file2str,"r");
	   if (file2 == NULL)
	   {
		   printf("In getregcoords, unable to open the input file = %s \n",file2str);
		   exit(-1);
	   }

	   endoffile=getline(file2,thisline);
	   nf=split_line(thisline);

       while (endoffile==FALSE)
	   {
		 arrayindex=atoi(str_array[1]);

		 if ((arrayindex < 0 ) || ( arrayindex > 5000))
		 {
			 printf("In getregcoords, Xvalid and Yvalid array bounds exceeded \n");
			 exit(-1);
		 }
	     if( (strcmp(str_array[0],"X") == 0 ) && (strcmp(str_array[2],"1") == 0 ))
		 {
	     Xvalid[arrayindex] = 1;
		 }
	     else if ( (strcmp(str_array[0],"X") == 0 ) && (strcmp(str_array[2],"0") == 0 ))
		 {
	     Xvalid[arrayindex] = 0;
		 }

	     if( (strcmp(str_array[0],"Y") == 0 ) && (strcmp(str_array[2],"1") == 0 ))
		 {
	     Yvalid[arrayindex] = 1;
           }
	     else if ( (strcmp(str_array[0],"Y") == 0 ) && (strcmp(str_array[2],"0") == 0 ))
		 {
	     Yvalid[arrayindex] = 0;
           }

         if(( strstr(str_array[0],"Xoutside") != NULL) && (strcmp(str_array[1],"YES") == 0 ))
		 {
	     Xoutside = 1;
		 }

         if(( strstr(str_array[0],"Youtside") != NULL) && (strcmp(str_array[1],"YES") == 0 ))
		 {
	     Youtside = 1;
		 }

		 endoffile=getline(file2,thisline);
		 nf=split_line(thisline);

       } 

	  fclose(file2);

//for( z = 0 ; z <= Xmax ; z++)
 //    printf( "%d  %d %d\n",z,Xvalid[z], Yvalid[z]) | "cat 1>&2"
   // mult is a passed in parameter if not defined then set to 4

   if( mult <= 0)
   {
       mult = 4;
   }

 //  printf( "%d %d\n",Xoutside,Youtside) | "cat 1>&2"

   PANELSIZE = 308.8 * pow(10,mult);

   // KERF is passed in parameter if not set will be 0

   KERF = KERF * pow(10,mult);

//  print "*** Test cooords KERF = " KERF | "cat 1>&2"

   TESTSIZE = 4  * pow(10,mult );

   XOFFSET = (xsize/2) + (KERF/2) ;
   YOFFSET = (ysize/2) + (KERF/2);
  cnt = 1;
  // X = 0;
  // Y = 1;

  file4= fopen(file4str,"r");
	   if (file4 == NULL)
	   {
		   printf("In getregcoords, unable to open the input file = %s \n",file4str);
		   exit(-1);
	   }

  endoffile= getline(file4,thisline);
  nf=split_line(thisline);

  XBASE = atof(str_array[0]);  // $1
  YBASE = atof(str_array[1]); // $2
  Xold = XBASE;

  Xcol = 1;
  Yrow = 1;
  // please note use of postfix increment operator (++  i.e. cnt++)
  // this increment the cnt AFTER the value has been stored
  
  coords[cnt].ok =  (Yvalid[Yrow] == 1 || Youtside == 0 || (Yrow == Ymax && Yvalid[Yrow] != -1));
  coords[cnt].X = atof(str_array[0])-XOFFSET; // $1 - XOFFSET;
  coords[cnt++].Y = atof(str_array[1]) + YOFFSET; // $2 + YOFFSET;

  coords[cnt].ok = ( (Xvalid[Xcol] == 1 && Yvalid[Yrow] == 1) || 
	  (xsize >= 320000 && ysize >=320000 && Xvalid[Xcol] == 0 && Yvalid[Yrow] == 0));
  coords[cnt].X =  atof(str_array[0]) + XOFFSET; // $1 + XOFFSET;
  coords[cnt++].Y = atof(str_array[1]) + YOFFSET;  //  $2 + YOFFSET;

  coords[cnt].ok =  (Xvalid[Xcol] == 1 || Xoutside == 0 || (Xcol == Xmax&& Xvalid[Xcol] != -1));
  coords[cnt].X =  atof(str_array[0]) + XOFFSET; // $1 + XOFFSET;
  coords[cnt++].Y = atof(str_array[1]) - YOFFSET; // $2 - YOFFSET;

  coords[cnt].ok = ( Xvalid[Xcol] != -1 && Yvalid[Yrow] != -1 );
  coords[cnt].X =  atof(str_array[0]) - XOFFSET; // $1 - XOFFSET;
  coords[cnt++].Y   =  atof(str_array[1])-YOFFSET; // $2 - YOFFSET;

  Yrow++;

  endoffile=getline(file4,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {
      if ( Xold != atof(str_array[0]) )  // $1)
	  {
           Xcol++;
           Xold = atof(str_array[0]); // $1;
      }
      if ( atof(str_array[1]) == YBASE) // $2 == YBASE)
	  {
	     Yrow  = 1;
      }
     
     //if( Xcol < 3 )
     //  printf( "%d %d %d %d %d\n",cnt,Xcol,Yrow,Xvalid[Xcol], Yvalid[Yrow]) | "cat 1>&2"
     if( (Xcol == Xmax && Yvalid[Yrow] == 1 ) || ( Yrow == Ymax && Xvalid[Xcol] == 1))
	 {
	 coords[cnt].ok = 1;
     }
     else if ( (Xcol == Xmax && Yvalid[Yrow] == 0 ) || ( Yrow == Ymax && Xvalid[Xcol] == 0)){
	 coords[cnt].ok = 0;
     }
     else
	 {
       coords[cnt].ok = ( (Xvalid[Xcol] == 1 && Yvalid[Yrow] == 1) );
	   if( xsize >= 320000 && ysize >=320000 && (Xvalid[Xcol] == 0 && Yvalid[Yrow] == 0))
	   {
	    coords[cnt].ok = 1;
       }
	 } 
     if( (Yrow == Ymax && Xoutside == 0) || (Xcol == Xmax && Youtside == 0) ||
			       (Xcol == Xmax && Yrow == Ymax && Xvalid[Xcol] != -1 && Yvalid[Yrow] != -1))
	 {
	  coords[cnt].ok = 1;
	 }

     coords[cnt].X = atof(str_array[0]) + XOFFSET; // $1 + XOFFSET;
     coords[cnt++].Y = atof(str_array[1] ) + YOFFSET; // $2 + YOFFSET;

     if( atof(str_array[0]) == XBASE)   // $1 == XBASE)
	 {
	 coords[cnt].ok =  (Yvalid[Yrow] == 1 || Youtside == 0 || (Yrow == Ymax && Yvalid[Yrow] != -1));
     coords[cnt].X =  atof(str_array[0]) - XOFFSET; // $1 - XOFFSET;
	 coords[cnt++].Y = atof(str_array[1]) - YOFFSET; // $2 + YOFFSET;
     }
     if( atof(str_array[1]) == YBASE)  // $2 == YBASE)
	 {
	 coords[cnt].ok =  (Xvalid[Xcol] == 1 || Xoutside == 0 || (Xcol == Xmax&& Xvalid[Xcol] != -1));
     coords[cnt].X =  atof(str_array[0]) + XOFFSET; // $1 + XOFFSET;
	 coords[cnt++].Y = atof(str_array[1] ) - YOFFSET; // $2 - YOFFSET;
     }

     Yrow++;
	endoffile=getline(file4,thisline);
	nf=split_line(thisline);
  }
  fclose(file4);

   for( i = 1; i <= cnt ; i++ )
   {
     // if( i < 30)
     // printf( "%d %d\n",i,coords[i].ok) | "cat 1>&2"
      if( isvalid( coords[i].X , coords[i].Y, coords[i].ok))
	  { 
          printf("%d %d\n", coords[i].X, coords[i].Y);
      }
   }

   return(0);

}  // end getregcoords_call

int main( int argc, char **argv)

{


   getregcoords_call( argv[1],argv[2],argv[3],argv[4],argv[5]);


}  // end main
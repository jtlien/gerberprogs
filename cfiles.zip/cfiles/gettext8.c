#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <winnt.h>
#include <time.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//
//  split the time string and put the results in time_array
//
int split_time( char *tline)
{
int ii;
char tstr[200];
char *token;


 ii = 0;

 strncpy( tstr, tline,200);

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
	
      strncpy( time_array[ii], token, 120);
    // printf("i=%d timeval=%s \n",ii,time_array[ii]);
      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_time





int gettext8_call( char *brd, char *lang, char *rev, char *pnl, char *infilestr)
{
int brdrev;
double X1;
double X2;
double Y1;
double Y2;
double Y3;
int endoffile;
char bcname[120];
char fname[120];
char myname[10][120];
char *mytimestr;
int nf;
char brdrevstr[200];
char name[200];
int kk;
char polarity[200];
char myname1_up[200];
char thisline[200];
char date[200];

FILE *revtxtfile;
FILE *barcodefile;
FILE *namefile;
FILE *file1;
int debug;

  debug=0;

  brdrev = -1;
  X1 = -92.71;
  X2 = 48.29;
  Y1 = -162.875;
  Y2 = -166.375;
  Y3 = -169.875;

  // parse header
  file1 = fopen(infilestr,"r");
  if (file1 == NULL)
  {
	  printf("In gettext8, unable to open the input file = %s \n",infilestr);
	  exit(-1);
  }

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  barcodefile = fopen("barcode.in","w");
  if (barcodefile == NULL)
  {
	  printf("In gettext8, unable to open the barcode.in output file \n");
	  exit(-1);
  }

  while(( nf < 3) && ( endoffile == FALSE))
  {
     if( strcmp(str_array[0],"BRDREV" ) == 0 ) // $1 == "BRDREV")
	 {
	  strncpy(brdrevstr,str_array[1],120); //  = $2
    }
    endoffile=getline(file1,thisline);
	nf=split_line(thisline);
  }


  // "date" |getline 
  //date =  ($2 "-" $3 "-" $6)
  // $2 is month $3 is day $6 is year

  mytimestr=malloc(200);
  mytimestr=gettime_str();

  split_time(mytimestr);

  //date =  ($2 "-" $3 "-" $6)
  strncpy(date,time_array[1],120);
  strcat(date,"-");
  strcat(date,time_array[2]);
  strcat(date,"-");
  strcat(date,time_array[4]);

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  while(endoffile == FALSE)
  {
   split(str_array[1],myname[0],myname[1],".");

   if (debug) { printf("gettext8 str %s %s %s %s %s %s\n",str_array[0],str_array[1],str_array[2],
	   str_array[3],str_array[4],str_array[5]); }


   strncpy(fname,myname[0],120);

  // ******** Handle panel border text ***************************
   strncpy(myname1_up,myname[1],120);
   for(kk=0; kk< (signed int) strlen(myname1_up);kk += 1)
   {
	  myname1_up[kk]=toupper(myname1_up[kk]);
   }

   for(kk=0; kk< ( signed int) strlen(str_array[5]);kk += 1)
   {
	  str_array[5][kk]=toupper(str_array[5][kk]);
   }

   if( (strcmp(str_array[5],"NA") != 0 ) && (strcmp(str_array[2],"PS")!= 0)  && 
	  (strcmp(myname1_up,"NA") != 0 ))
   {
     //name = (fname".win")
	  strncpy(name,fname,120);
	  strncat(name,".win",10);
	  namefile=fopen(name,"w");
	  printf("Opening win file = %s.win \n",fname);
      if (namefile==NULL)
	  {
		  printf("In gettext8, unable to open the output file = %s \n",name);
		  exit(-1);
	  }
     fprintf(namefile, "4 \n"); //  > name  // default multiplier =4 (will fix later)
     if( brdrev == -1)
	 {
         fprintf(namefile,"%0.3f %0.3f BRD PN %s\n",X1,Y1,brd); // > name
     }
     else
	 {
        fprintf(namefile,"%0.3f %0.3f BRD PN %s-%s\n",X1,Y1,brd,brdrevstr); // > name
     }
     fprintf(namefile,"%0.3f %0.3f LAYER %s-%s\n",X1,Y2,str_array[0],str_array[6]); // > name
    
     fprintf(namefile,"%0.3f %0.3f SCALE \n",X1,Y3); // > name

     if( brdrev == -1)
	 {
         fprintf(namefile,"%0.3f %0.3f BRD PN %s\n",X2,Y1,brd); // > name
     }
     else
	 {
         fprintf(namefile,"%0.3f %0.3f BRD PN %s-%s\n",X2,Y1,brd,brdrevstr); // > name
     }
     fprintf(namefile,"%0.3f %0.3f %s PNL %s\n",X2,Y2,date,pnl); // > name
     fprintf(namefile,"%0.3f %0.3f SW REV %s %s \n",X2,Y3,lang,rev); // > name
  }
  
  // ******************* Generate barcode strings ************

  awk_substr(str_array[0],1,5,bcname);

 

  if(( strcmp(str_array[5],"NA") != 0 )  && (strcmp(str_array[2],"PS") !=0)
	   && (strcmp(myname1_up,"NA" ) != 0 ))
  {
        strncpy(polarity,"POS",10);

        if( strstr(str_array[2],"BLIND") != NULL) //$3 ~ /BLIND/)
		{
           strncpy(polarity,"NEG",10);
        }
        if( brdrev == -1)
		{
            fprintf(barcodefile,"%s %s *AWA-%s-%s-%s*\n",
				         polarity,fname,brd,bcname,str_array[6]); // > "barcode.in" 
        }
        else
		{
            fprintf(barcodefile,"%s %s *AWA-%s-%s-%s-%s*\n",
				polarity,fname,brd,brdrev,bcname,str_array[6]); // > "barcode.in" 
        }
  }
  fclose(namefile);
  
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
  }

 fclose(file1);
 fclose(barcodefile);

   revtxtfile=fopen("rev.txt","w");

   fprintf(revtxtfile,"PNL %s\nSW %s\n",pnl,rev); // > "rev.txt"

   fclose(revtxtfile);

   return(0);
}

/*

int main( int argc, char **argv)
{

        if (argc == 6 )
        {

         gettext8_call( argv[1], argv[2], argv[3], argv[4], argv[5]);
        }
        else
        {
          printf("Wrong number of arguments for gettext8, argument count = %d \n",argc);
          printf("Usage: gettext8 brdname language rev pnl controlfile \n");
            exit(-1);
        }

} 
*/


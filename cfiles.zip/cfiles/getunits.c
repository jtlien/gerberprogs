#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void getunits_call_out( char *infilestr, char *outfilestr)
{
int endoffile;
char thisline[300];
int nf;
FILE *file1;
FILE *outfile;

file1=fopen(infilestr,"r");

if (file1==NULL)
{
	printf("In getunits, unable to open the input file = %s \n",infilestr);
	exit(-1);
}

outfile=fopen(outfilestr,"w");

if (outfile==NULL)
{
	printf("In getunits, unable to open the output file = %s \n",outfilestr);
	exit(-1);
}

endoffile=getline(file1,thisline);
nf=split_line(thisline);

while(endoffile==FALSE)
{
   if (( strstr(thisline,"APTUNIT") != NULL) ||
	  ( strstr(thisline,"aptunit") != NULL) )   //$0 ~/APTUNIT/ || $0 ~/aptunit/)
   {
      fprintf(outfile,"UNITS are in square %s \n",str_array[1]); //  $2 
   }

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

}

fclose(outfile);
fclose(file1);

}  // end getunits_call_out

void getunits_return( char *infilestr, char *unitstr)
{
int endoffile;
char thisline[300];
int nf;
FILE *file1;

file1=fopen(infilestr,"r");

if (file1==NULL)
{
	printf("In getunits, unable to open the input file = %s \n",infilestr);
	exit(-1);
}


endoffile=getline(file1,thisline);
nf=split_line(thisline);

while(endoffile==FALSE)
{
   if (( strstr(thisline,"APTUNIT") != NULL) ||
	  ( strstr(thisline,"aptunit") != NULL) )   //$0 ~/APTUNIT/ || $0 ~/aptunit/)
   {
     // fprintf(outfile,"UNITS are in square %s \n",str_array[1]); //  $2 
	   strncpy( unitstr, str_array[1],30);

   }

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

}

fclose(file1);

}  // end getunits_return


void getunits_call( char *infilestr)
{
int endoffile;
char thisline[300];
int nf;
FILE *file1;

file1=fopen(infilestr,"r");

if (file1==NULL)
{
	printf("In getunits, unable to open the input file = %s \n",infilestr);
	exit(-1);
}

endoffile=getline(file1,thisline);
nf=split_line(thisline);

while(endoffile==FALSE)
{
   if (( strstr(thisline,"APTUNIT") != NULL) ||
	  ( strstr(thisline,"aptunit") != NULL) )   //$0 ~/APTUNIT/ || $0 ~/aptunit/)
   {
      printf("UNITS are in square %s \n",str_array[1]); //  $2 
   }

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

}

fclose(file1);

}  // end getunits_out

int main( int argc, char **argv)
{

	if ( argc != 2)
	{
		printf("In getunits, wrong number of arguments \n");
		printf("Usage: getunits infile \n");
		exit(-1);
	}
	else
	{
		getunits_call( argv[1]);
	}

} // end main
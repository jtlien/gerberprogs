#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//
//  Check that file has s records
//

//  Reads a file and looks for records
//   that have s! or S!  at the beginning will return 0
//   otherwise return 1


int has_s_record_call( char *infilestr)
{
char tempstr[120];
char units[120];
int result;
char file_sep[10];
int kk;
char thisline[120];
FILE *file1;
int endoffile;
int number_fields;

    result=1;

    file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	}

    strncpy(file_sep,"!",3);

    endoffile = getline(file1, thisline);
	number_fields = split_line_seps( thisline, file_sep);

    while( endoffile == FALSE)
	{
	  units[0] = 0;
	  strncpy(tempstr,str_array[0],120);

	  for(kk=0; kk < (signed int) strlen(tempstr); kk += 1)
	  {
		  if (islower( str_array[0][kk]))
		  {
			str_array[0][kk]=toupper(str_array[0][kk]);
		  }
	  }
      if(strcmp(str_array[0],"S") == 0)
	  {
	   result = 0;
	   return( result);
	  }

     
	 endoffile = getline(file1, thisline);
	 number_fields = split_line_seps( thisline, file_sep);

	}  // end while

   fclose(file1);

   return( result);

} // end has_s_record_call


int main( int argc, char **argv)
{
int retcode;

	if (argc != 2)
	{
		printf("In has_s_record, wrong number of arguments \n");
		printf("Usage: has_s_record infile \n");
	}
	else
	{
		retcode=has_s_record_call( argv[1]);
		if (retcode == 0 )
		{
			printf("File has S records \n");
		}
		else
		{
			printf("File has no S records \n");
		}
		//printf("retcode=%d",retcode);
		exit(retcode);
	}

}  // end main

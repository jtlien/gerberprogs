#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  IGItoDat.awk  rev 1.0  2/28/96
//  written by Ted Ammann
//
//  This program converts The IGI test file to a xx.dat file
//  so gerber files can be generated.
//  The input file is ASSUMED TO BE IN MILS.
//  This Program converts those mils to inches. 

//  The output is meant to be redirected using UNIX >   

//  The output of this program is 
//     x         y     netnumber   layer     
//  0.0000     0.7090     1          L

//  The begin section strips off the first 9 dummy lines
//  and then assigns  layer value based on the file name

void igitodat_call_out(  char *infilestr, char *outfilestr)
{

char thisline[200];
int number_fields;
FILE *file1;
FILE *outfile;
char commandstr[200];
double factor;
int endoffile;
int i;
char layer[120];

    strncpy(commandstr,infilestr,120);

    file1  = fopen(infilestr, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	 }

     outfile  = fopen(outfilestr, "w");

     if (outfile == NULL)
	 {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
	 }

     factor = 1000;  // conversion factor

     // strip off nine dummy lines

     for( i = 0 ; i < 9 ;i++)
	 {
	   endoffile = getline(file1,thisline);

     }

     endoffile = getline(file1,thisline);

     // determine layer type
     if(( strstr(commandstr,"BOT") != NULL) ||
		  ( strstr(commandstr,"bot") != NULL))
	 {
	  strncpy(layer,"L",3);
     }
     else
	 {
	  strncpy(layer,"U",3);
     }

  // START OF MAIN LOOP

   endoffile = getline(file1,thisline);
   number_fields = split_line(thisline);

   while( endoffile == FALSE)
   {
  // Input file has a last line that conatins -1. We don't want to
  // do anything with that line.
  // Simply output the proper columns in the desired format 
    if(strstr(str_array[0],"-1") == NULL)
	{
     fprintf(outfile,"%10.4f %10.4f %5d %3s\n",
		 atof(str_array[1])/factor ,
		 atof(str_array[2])/factor,
		 atoi(str_array[3]),layer);
	}
   endoffile = getline(file1,thisline);
   number_fields = split_line(thisline);

  }
fclose(file1);
fclose(outfile);
}

void igitodat_call(  char *infilestr)
{

char thisline[200];
int number_fields;
char commandstr[200];
FILE *file1;
double factor;
int endoffile;
int i;
char layer[120];


    strncpy(commandstr,infilestr,120);
    file1  = fopen(infilestr, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	 }

     factor = 1000;  // conversion factor

     // strip off nine dummy lines

     for( i = 0 ; i < 9 ;i++)
	 {
	   endoffile = getline(file1,thisline);

     }

     endoffile = getline(file1,thisline);

     // determine layer type
     if(( strstr(commandstr,"BOT") != NULL) ||
		  ( strstr(commandstr,"bot") != NULL))
	 {
	  strncpy(layer,"L",3);
     }
     else
	 {
	  strncpy(layer,"U",3);
     }

  // START OF MAIN LOOP

   endoffile = getline(file1,thisline);
   number_fields = split_line(thisline);

   while( endoffile == FALSE)
   {
  // Input file has a last line that conatins -1. We don't want to
  // do anything with that line.
  // Simply output the proper columns in the desired format 
    if(strstr(str_array[0],"-1") == NULL)
	{
     printf("%10.4f %10.4f %5d %3s\n",
		 atof(str_array[1])/factor ,
		 atof(str_array[2])/factor,
		 atoi(str_array[3]),layer);
	}
   endoffile = getline(file1,thisline);
   number_fields = split_line(thisline);

  }
fclose(file1);
}

int main( int argc, char **argv )
{

	if (argc != 2)
	{
		printf("In igitodat, wrong number of arguments \n");
		printf("Usage: igitodat infile \n");
		printf("If infile contains BOT or bot, the layer is L \n");
		printf("Otherwise it is U \n");
		exit(-1);
	}
	else
	{  
		 igitodat_call( argv[1]);
	}

}  // end main

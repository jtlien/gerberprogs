
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

char str_array[120][120];

#include "utilprogs.h"


// Rev 1
// Title: InctoAbs (Incremental data to Absolute )
// written by Ted Ammann  1/2/97
//
// calling syntax:
//      InctoAbs  infile > outfile

// Converts gerber data the is in incremental coordinates to
// absolute coordinates by simply adding the last X and Y coordinate
// to the current coordinate.

// Revision history
//  Rev1  released on 1/2/97

//************************************************
// set  xoffset and yoffset to default value of 0
//*************************************************


int inctoabs_call( char *infilestr)
{
FILE *file1;

int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];

double xval;
double yval;

char X[120];
char Y[120];
int val;
double xoffset;
double yoffset;
char thisline[200];

  xoffset = 0.0;
  yoffset = 0.0;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
    {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
    }

  
//**************START OF MAIN *********************************
// handles data depending on if the line has  X & Y data,
// X data only, Y data only , or no X,Y data.
//********************************************************************

 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL))     // G54 preceeds aperture
   {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       xval=atof(X);
       yval=atof(Y);
       xval = xval + xoffset;
       yval = yval + yoffset;
       xoffset = xval;   // set x and y offset to current position
       yoffset = yval;
       printf("X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
  }
  // if line has only X data modify it
   else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {
      split(thisline,b[0],b[1],"X");
      split(thisline,d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
      xval=atof(X);
      xval = xval + xoffset;
      xoffset = xval;    // adjust xoffset
      printf("X%0.0fD%s\n", xval,d[1]);
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
      split(thisline,c[0],c[1],"Y");
      split(thisline,d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
   
      yval=atof(Y);
      yval = yval + yoffset;
      yoffset = yval;   //adjust yoffset
      printf("Y%0.0fD%s\n", yval,d[1]);
  }
  //   line has no X or Y data so just output it
 else
  {
    printf("%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }
 fclose(file1);

 return(0);

} // end intoabs_call

int inctoabs_call_out( char *infilestr, char *outfilestr)
{
FILE *file1;
FILE *file2;

int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];

double xval;
double yval;

char X[120];
char Y[120];
int val;
double xoffset;
double yoffset;
char thisline[200];

  xoffset = 0.0;
  yoffset = 0.0;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
    {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
    }

  file2 = fopen(outfilestr, "w");

  if (file2 == NULL)
    {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
    }
//**************START OF MAIN *********************************
// handles data depending on if the line has  X & Y data,
// X data only, Y data only , or no X,Y data.
//********************************************************************

 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL))     // G54 preceeds aperture
   {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       xval=atof(X);
       yval=atof(Y);
       xval = xval + xoffset;
       yval = yval + yoffset;
       xoffset = xval;   // set x and y offset to current position
       yoffset = yval;
       fprintf(file2,"X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
  }
  // if line has only X data modify it
   else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {
      split(thisline,b[0],b[1],"X");
      split(thisline,d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
      xval=atof(X);
      xval = xval + xoffset;
      xoffset = xval;    // adjust xoffset
      fprintf(file2,"X%0.0fD%s\n", xval,d[1]);
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
      split(thisline,c[0],c[1],"Y");
      split(thisline,d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
   
      yval=atof(Y);
      yval = yval + yoffset;
      yoffset = yval;   //adjust yoffset
      fprintf(file2,"Y%0.0fD%s\n", yval,d[1]);
  }
  //   line has no X or Y data so just output it
 else
  {
    fprintf(file2,"%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }
 fclose(file1);
 fclose(file2);
 return(0);

} // end intoabs_call

int main( int argc, char **argv)
{
int retval;

	if (argc != 2)
	{
		printf("In inctoabs, wrong number of arguments \n");
		printf("Usage:  inctoabs gbrfile \n");
		exit(-1);
	}
	else
	{
		retval=inctoabs_call( argv[1]);
		
	}

}  // end main

}
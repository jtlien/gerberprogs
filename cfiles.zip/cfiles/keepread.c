#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Reads in a .keep file 
//            1..n  records of 
//               %ADDXXXR,widthXheight*%
//                 followed by G54DXXX*
//                 followed by 1..m records of X..Y...D03*
//           
//   Results outs of X... Y....width height 
//
#define MAX_SHAPES 20000

#define TRUE 1
#define FALSE 0

#define LINELEN  120
 char D[LINELEN];  
 char X[LINELEN];
 char Y[LINELEN];
 double current_rect_x;
 double current_rect_y;
 int curr_rect_x;
 int curr_rect_y;

 int current_is_circle;
 int current_is_rect;

 struct shapearray
 {
	 int xloc;
	 int yloc;
	 int xwidth;
	 int yheight;
	 int radius;
	 int is_rectangle;
	 int is_circle;
     int ur_x;
	 int ur_y;
	 int ll_x;
	 int ll_y;
 } shape_array[MAX_SHAPES];

 int shape_count;

void set_rectarray( int inx , int iny, int width, int height, int isrect)
{
	 shape_array[shape_count].xloc = inx;
	 shape_array[shape_count].yloc = iny;
	 shape_array[shape_count].xwidth= width;
     shape_array[shape_count].yheight = height;

	 if ( isrect)
	 {
		 shape_array[shape_count].is_circle = FALSE;
		 shape_array[shape_count].is_rectangle=TRUE;
	 }	
	 if ( isrect==FALSE) // circle
	 {
		 shape_array[shape_count].is_circle = TRUE;
		 shape_array[shape_count].is_rectangle= FALSE;
		 shape_array[shape_count].radius = width;
	 }

	 shape_array[shape_count].ur_x = inx + (width/2 );
	 shape_array[shape_count].ur_y = iny + (height/2);

     shape_array[shape_count].ll_x = inx - (width/2);
	 shape_array[shape_count].ll_y = iny - (height/2);

}  // end sec_rectarray

void getstring( char *val, char *myval)
{
  val++; // Skip past D or Y or X

  if ( *val == '-')
  {
	val++;
	*myval = '-';
	myval++;
    while( isdigit(*val) )
	{
     *myval = *val ;
     val++;
     myval++;
	}
  }
  else
  {
    while( isdigit(*val) )
	{
     *myval = *val ;
     val++;
     myval++;
	}
  }
  *myval = '\0';
}

ProcessString(char thestring[])
{
     char* placeX;
     char* placeY;
     char* placeD; 

     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) )
	 {
         getstring(placeX,X);
	     getstring(placeY,Y);
		 if ( placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
		  curr_rect_x= (int) (10000 * current_rect_x);
		  curr_rect_y= (int) (10000 * current_rect_y);
          if ( current_is_rect)
		  {
	        printf("%d %d R %d %d \n",atoi(X),atoi(Y) , curr_rect_x, curr_rect_y);
		  }
		  if ( current_is_circle)
		  {
	        printf("%d %d C %d %d \n",atoi(X),atoi(Y) , curr_rect_x, curr_rect_y);
		  }
         set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);

     }
     else if (  strchr(thestring,'X') != NULL )  
	 {
         getstring(placeX,X);
		 if (placeD != NULL)
		 {
	      getstring(placeD,D);
		 }
		curr_rect_x= (int) (10000 * current_rect_x);
		curr_rect_y= (int) (10000 * current_rect_y);
		if (current_is_rect)
		{
	      printf("%d %d R %d %d \n", atoi(X), atoi(Y) ,curr_rect_x, curr_rect_y );
		}
		if (current_is_circle)
		{
	      printf("%d %d C %d %d \n", atoi(X), atoi(Y) ,curr_rect_x, curr_rect_y );
		}
        set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);
     }
     else if (  strchr(thestring,'Y') != NULL ) 
	 {
	   getstring(placeY,Y);
	   if ( placeD != NULL)
	   {
	    getstring(placeD,D);
	   }
	   curr_rect_x= (int) (10000 * current_rect_x);
	   curr_rect_y= (int) (10000 * current_rect_y);
	   if (current_is_rect)
	   {
	     printf("%d %d R %d %d ",atoi(X), atoi(Y), curr_rect_x, curr_rect_y );
	   }
	   if (current_is_rect)
	   {
	     printf("%d %d C %d %d ",atoi(X), atoi(Y), curr_rect_x, curr_rect_y );
	   }
      set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);
     }
     else if ( strchr(thestring , 'M') == NULL)
	 {
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

ProcessStringOut(char thestring[], FILE *outfile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char X[LINELEN];
     char Y[LINELEN];
     
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) )
	 {
         getstring(placeX,X);
	     getstring(placeY,Y);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 } 
		 
		 curr_rect_x= (int) (10000 * current_rect_x);
		 curr_rect_y= (int) (10000 * current_rect_y);

		 if (current_is_rect)
		 {
	       fprintf(outfile,"%d %d R %d %d \n",atoi(X),atoi(Y) , curr_rect_x, curr_rect_y);
		 }	
		 if (current_is_circle)
		 {
	       fprintf(outfile,"%d %d C %d %d \n",atoi(X),atoi(Y) , curr_rect_x, curr_rect_y);
		 }

        set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);
     }
     else if( strchr(thestring,'X') != NULL ) 
	 {
         getstring(placeX,X);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
		 curr_rect_x= (int) (10000 * current_rect_x);
		 curr_rect_y= (int) (10000 * current_rect_y);

		 if (current_is_rect)
		 {
	      fprintf(outfile,"%d %d R %d %d \n",atoi(X),atoi(Y) , curr_rect_x, curr_rect_y);
		 } 
		 if (current_is_circle)
		 {
	      fprintf(outfile,"%d %d C %d %d \n",atoi(X),atoi(Y) , curr_rect_x, curr_rect_y);
		 }
	   set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);  
     }
     else if ( strchr(thestring,'Y') != NULL ) 
	 {
	   getstring(placeY,Y);
	   if ( placeD != NULL)
	   {
	     getstring(placeD,D);
	   }
	   curr_rect_x= (int) (10000 * current_rect_x);
	   curr_rect_y= (int) (10000 * current_rect_y);

	   if ( current_is_rect)
	   {
	     fprintf(outfile,"%d %d R %d %d \n",atoi(X),atoi(Y) , curr_rect_x, curr_rect_y);
	   }
	   if ( current_is_circle )
	   {
	     fprintf(outfile,"%d %d C %d %d \n",atoi(X),atoi(Y) , curr_rect_x, curr_rect_y);
	   }
	   set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);
     }
     else if ( strchr(thestring , 'M') == NULL)
	 {
       fprintf(outfile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

ProcessStringNoOut(char thestring[])
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char X[LINELEN];
     char Y[LINELEN];
     
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) )
	 {
         getstring(placeX,X);
	     getstring(placeY,Y);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 } 
		 
		 curr_rect_x= (int) (10000 * current_rect_x);
		 curr_rect_y= (int) (10000 * current_rect_y);

        set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);
     }
     else if( strchr(thestring,'X') != NULL ) 
	 {
         getstring(placeX,X);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
		 curr_rect_x= (int) (10000 * current_rect_x);
		 curr_rect_y= (int) (10000 * current_rect_y);

	   set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);  
     }
     else if ( strchr(thestring,'Y') != NULL ) 
	 {
	   getstring(placeY,Y);
	   if ( placeD != NULL)
	   {
	     getstring(placeD,D);
	   }
	   curr_rect_x= (int) (10000 * current_rect_x);
	   curr_rect_y= (int) (10000 * current_rect_y);

	   set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);
     }
     else if ( strchr(thestring , 'M') == NULL)
	 {
       
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

void get_digits( char *instr, int index, char *outstr)
{
int jj;
int kk;


     jj = index;
	 kk=0;
	while(( isdigit(instr[jj] ) || instr[jj]== '.' )  && ( kk < 120) )
	{
		*outstr = instr[jj];
		outstr++;
		jj += 1;
		kk += 1;
	}

    *outstr = '\0';


} // end get_digits

void keepread_call_out(char *fname, char *outfilestr)
{
FILE *thisfile;
FILE *outfile;
int debug;
char oneline[300];
char xvalstr[300];
char yvalstr[300];
int jj;



   debug=0;
   D[0] = '\n';

   current_is_circle = FALSE;
   current_is_rect = FALSE;

   shape_count = 0;

   if ( debug) { printf("In keepread_call_out, fname = %s outfilestr = %s \n",fname,
	   outfilestr); }

   thisfile =  fopen( fname,"r");
   if ( thisfile == NULL)
   {
	   printf("In keepread_call_out, unable to open the input file = %s \n",fname);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"w");
   if ( outfile == NULL)
   {
	   printf("In keepread_call_out, unable to open the output file file = %s \n",outfilestr);
	   exit(-1);
   }

   if ((thisfile != NULL) && (outfile != NULL)) {
       while( fgets(oneline, LINELEN, thisfile) != NULL)
	   {
		  // printf("Linein = %s \n",oneline);
		  if (( oneline[0] == 'X') || ( oneline[0] == 'Y') )
		  {
            ProcessStringOut(oneline,  outfile);
		  }
		  if (oneline[0] == '%')
		  {
			  if ( ( oneline[1] == 'A') && ( oneline[2] == 'D')  &&  // %ADD
				   ( oneline[3] == 'D') && (oneline[4] == '3'))
			  {
				  if ((oneline[7] == 'R') && (oneline[8]=',')) // Rectangle
				  {
					  jj=9;
					  get_digits( oneline,jj,xvalstr);
                      current_is_circle = FALSE;
					  current_is_rect = TRUE;

					//  printf("Rect xvalstr = %s \n",xvalstr);
					  jj = jj + strlen( xvalstr);

					  if ((oneline[jj] == 'X')  || (oneline[jj] == 'x') )
					  {
						  jj += 1;
						  get_digits( oneline,jj, yvalstr);

						  current_rect_x= atof( xvalstr);
						  current_rect_y= atof( yvalstr);
					  }
					  else
					  {
						  if (oneline[jj] == '*') // square
						  {
							  current_rect_x=atof(xvalstr);
							  current_rect_y=current_rect_x; 
						  }
					  }

				  }  // Rectangle or square 
				  
				  if ((oneline[7] == 'C') && (oneline[8]=',')) // Circle or donut
				  {
					  jj=9;
					  current_is_circle =TRUE;
					  current_is_rect = FALSE;
					  get_digits( oneline,jj,xvalstr);
					
					  jj = jj + strlen( xvalstr);

					  if ((oneline[jj] == 'X')  || (oneline[jj] == 'x') )
					  {
						  jj += 1;
						  get_digits( oneline,jj, yvalstr);

						  current_rect_x= atof( xvalstr);
						  current_rect_y= atof( yvalstr);
					  }
					  else
					  {
						  if (oneline[jj] == '*') // square
						  {
							  current_rect_x=atof(xvalstr);
							  current_rect_y=current_rect_x; 
						  }
					  }

				  }  // Rectangle or square

			  }  // Flash 

		  }  // %

		  if (oneline[0] == 'G')   // G code
		  {

		  }


       } // fgets ok
   }
   fclose(thisfile);
   fclose(outfile);

}

// like keepread, but doesn't output a file
//
void keepread_call_no_out(char *fname, char *outfilestr)
{
FILE *thisfile;
int debug;
char oneline[300];
char xvalstr[300];
char yvalstr[300];
int jj;



   debug=0;
   D[0] = '\n';

   current_is_circle = FALSE;
   current_is_rect = FALSE;

   shape_count = 0;

   if ( debug) { printf("In keepread_call_out, fname = %s outfilestr = %s \n",fname,
	   outfilestr); }

   thisfile =  fopen( fname,"r");
   if ( thisfile == NULL)
   {
	   printf("In keepread_call_out, unable to open the input file = %s \n",fname);
	   exit(-1);
   }

 
   if ((thisfile != NULL) ) {
       while( fgets(oneline, LINELEN, thisfile) != NULL)
	   {
		  // printf("Linein = %s \n",oneline);
		  if (( oneline[0] == 'X') || ( oneline[0] == 'Y') )
		  {
            ProcessStringNoOut(oneline);
		  }
		  if (oneline[0] == '%')
		  {
			  if ( ( oneline[1] == 'A') && ( oneline[2] == 'D')  &&  // %ADD
				   ( oneline[3] == 'D') && (oneline[4] == '3'))
			  {
				  if ((oneline[7] == 'R') && (oneline[8]=',')) // Rectangle
				  {
					  jj=9;
					  get_digits( oneline,jj,xvalstr);
                      current_is_circle = FALSE;
					  current_is_rect = TRUE;

					//  printf("Rect xvalstr = %s \n",xvalstr);
					  jj = jj + strlen( xvalstr);

					  if ((oneline[jj] == 'X')  || (oneline[jj] == 'x') )
					  {
						  jj += 1;
						  get_digits( oneline,jj, yvalstr);

						  current_rect_x= atof( xvalstr);
						  current_rect_y= atof( yvalstr);
					  }
					  else
					  {
						  if (oneline[jj] == '*') // square
						  {
							  current_rect_x=atof(xvalstr);
							  current_rect_y=current_rect_x; 
						  }
					  }

				  }  // Rectangle or square 
				  
				  if ((oneline[7] == 'C') && (oneline[8]=',')) // Circle or donut
				  {
					  jj=9;
					  current_is_circle =TRUE;
					  current_is_rect = FALSE;
					  get_digits( oneline,jj,xvalstr);
					
					  jj = jj + strlen( xvalstr);

					  if ((oneline[jj] == 'X')  || (oneline[jj] == 'x') )
					  {
						  jj += 1;
						  get_digits( oneline,jj, yvalstr);

						  current_rect_x= atof( xvalstr);
						  current_rect_y= atof( yvalstr);
					  }
					  else
					  {
						  if (oneline[jj] == '*') // square
						  {
							  current_rect_x=atof(xvalstr);
							  current_rect_y=current_rect_x; 
						  }
					  }

				  }  // Rectangle or square

			  }  // Flash 

		  }  // %

		  if (oneline[0] == 'G')   // G code
		  {

		  }


       } // fgets ok
   }
   fclose(thisfile);
   

} // keepout_call_no_out

int main( int argc, char **argv)
{
	if (argc != 3)
	{
		printf("In keepread, wrong number of arguments \n");
        printf("Usage  keepread infile outfile \n");
		exit(-1);
	}
	else
	{
	    keepread_call_out( argv[1], argv[2] );
	}

}  // end main




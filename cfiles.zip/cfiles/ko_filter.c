#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"
#define MAX_FLASHES  400000
#define MAX_RECTS 1000

struct rectstuff
{
	int xloc;
	int yloc;
	int height;
	int width;
	int radius;
	int is_rectangle;
	int is_circle;
	int ur_x;
	int ur_y;
	int ll_x;
	int ll_y;
} rect_array[MAX_RECTS];

struct flashstuff
{
	int xval;
	int yval;
}   flash_array[MAX_FLASHES];

// this routine will return true of the given x y coordinant is inside the
//  given shape

int is_in_rectangle( int inx, int iny, struct rectstuff rect)
{

	if ((inx < rect.ll_x ) || ( inx > rect.ur_x ))
	{ 
		return(FALSE);
	}
	if ((iny < rect.ll_y ) || ( iny > rect.ur_y ))
	{
		return(FALSE);
	}
	
	return(TRUE);
}

// make a bigger rectangle from a smaller
//

void aug_rectangle( int radius, struct rectstuff *inrect, struct rectstuff *outrect)
{

	outrect->ll_x = inrect->ll_x - radius;
	outrect->ll_y = inrect->ll_y - radius;

	outrect->ur_x = inrect->ur_x + radius;
	outrect->ur_y = inrect->ur_y + radius;

	outrect->width = outrect->width + radius * 2;
	outrect->height = outrect->height + radius * 2;

}

// filters a list of flashes in flash_list against a list of rectangles in rect_list
//   if the 

void ko_filter_call(  char *flash_file_str, 
					  char *rect_file_str, char *out_file_str)
{

FILE *flashfile;
FILE *rectfile;
FILE *outfile;
int endoffile;
int nf;
char thisline[300];
char digitx_str[300];
char digity_str[300];
int flash_count;
int newx;
int newy;
int ii,kk;
int rectx;
int recty;
int rectwidth;
int rectheight;

int rect_count;
int exclude;
char gstr[300];

 newx=-1;
 newy=-1;

 flashfile = fopen(flash_file_str,"r");
 if (flashfile==NULL)
 {
	 printf("Unable to open the input flash file = %s \n", flash_file_str);
	 exit(-1);
 }

  endoffile=getline(flashfile,thisline);
  flash_count = 0;
  while(endoffile==FALSE)
  {

    if (thisline[0] != 'G')
	{
		if (thisline[0] == 'X')
		{
	      ii = 1;
		  kk=0;
		  if ( thisline[ii] == '-')  // handle minus sign
		  {
			  digitx_str[0] = '-';
			  ii += 1;
              kk = 1;
		  }
		  while(( isdigit( thisline[ii] )) && ( ii < 30))
		  {
			  digitx_str[kk] = thisline[ii];
			  kk += 1;
			  ii += 1;
		  }
          digitx_str[kk]= '\0';

		  if (thisline[ii] != 'D')
		  {
			  if ( thisline[ii] == 'Y')
			  {
				  kk = 0;
				  ii += 1;
                  if ( thisline[ii] == '-')  // handle minus sign
				  {
			        digity_str[0] = '-';
			        ii += 1;
                     kk = 1;
				  }
				  while(( isdigit( thisline[ii])) && ( kk < 30))
				  {
					  digity_str[kk] = thisline[ii];
					  kk += 1;
					  ii += 1;
				  }
				 digity_str[kk]= thisline[ii];
			  
			    newx= atoi(digitx_str);
		  	    newy= atoi(digity_str);

				//printf("Adding to flash_array, newx = %d newy = %d flash_count = %d \n",
					 //          newx, newy, flash_count);

			    flash_array[flash_count].xval= newx;
			    flash_array[flash_count].yval= newy;
			    if (flash_count < MAX_FLASHES)
				{
			    	flash_count += 1;
				}
			    else
				{
				  printf("Number of flashes exceeds %d \n",MAX_FLASHES);
			      exit(-1);
				}
			  }    // Y
		    else
			{
			 // no y

			 newx = atoi(digitx_str);
			 //printf("Adding to flash_array 2, newx = %d newy = %d flash_count = %d \n",
					 //          newx, newy, flash_count);

			 flash_array[flash_count].xval=newx;
			 flash_array[flash_count].yval=newy;
			 if (flash_count < MAX_FLASHES)
			 {
				flash_count += 1;
			 }
			 else
			 {
				printf("Number of flashes exceeds %d \n",MAX_FLASHES);
			    exit(-1);
			 }
			}    
		  }    // no D
		}
       else   // Doesn't begin with X
	   {
		   if (thisline[0] == 'Y')
		   {
			ii = 1;
			kk=0; 
			if ( thisline[ii] == '-')  // handle minus sign
			{
			  digity_str[0] = '-';
			  ii += 1;
              kk = 1;
			}
			while(( isdigit( thisline[ii] )) && ( ii < 30) )
			{
				digity_str[kk] = thisline[ii];
				kk += 1;
				ii +=1;
			}
			digity_str[kk]= '\0';
			newy=atoi(digity_str);
			//printf("Adding to flash_array 3, newx = %d newy = %d flash_count = %d \n",
				//	           newx, newy, flash_count);

			flash_array[flash_count].xval=newx;
			flash_array[flash_count].yval=newy;
            if (flash_count < MAX_FLASHES)
			{
				flash_count += 1;
			}
			else
			{
				printf("Number of flashes exceeds %d \n",MAX_FLASHES);
			    exit(-1);
			}
		   }   // Y
	   }

	 }  // doesn't begin with G
	else
	{           // Begins with G

     strncpy(gstr, thisline, 120);

	}
	endoffile=getline(flashfile,thisline);
  }
  fclose(flashfile);

 printf("Done reading flash file , flash_count = %d \n",flash_count);

 rectfile=fopen(rect_file_str,"r");

 if (rectfile==NULL)
	{
	 printf("Unable to open the input rectangle file = %s \n",rect_file_str);
	 exit(-1);
	}

 outfile = fopen(out_file_str,"w");
 if (outfile == NULL)
	{
	 printf("Unable to open the output file = %s \n",out_file_str);
	 exit(-1);
	}

 endoffile=getline(rectfile,thisline);

 nf=split_line(thisline);

 rect_count=0;

 while( endoffile == FALSE)
	{

	 rectx = atoi( str_array[0]);
	 recty = atoi( str_array[1]);

	 rectwidth = atoi( str_array[2]);
	 rectheight = atoi( str_array[3]);


	 rect_array[rect_count].height=rectheight;
	 rect_array[rect_count].width=rectwidth;
	 rect_array[rect_count].ur_x = rectx + ( rectwidth / 2);
	 rect_array[rect_count].ur_y = recty + ( rectheight / 2);
	 rect_array[rect_count].ll_x = rectx - ( rectwidth / 2);
	 rect_array[rect_count].ll_y = recty - ( rectheight / 2);
	 rect_array[rect_count].xloc = rectx;
	 rect_array[rect_count].yloc = recty;

	 if (rect_count < MAX_RECTS)
	 {
	  rect_count +=1;
	 }
	 else
	 {
		 printf("Maximum number of rectangles exceeded \n");
		 exit(-1);
	 }

     endoffile=getline(rectfile,thisline);
	 nf=split_line(thisline);
	}
 fclose(rectfile);

 printf("Done reading the rectangles files rect_count = %d \n", rect_count);


 fprintf(outfile,"%s",gstr);

 for(ii =0; ii < flash_count; ii += 1)
 {

	 exclude = FALSE;

	 kk =0;

	 while(( kk < rect_count) && ( exclude == FALSE))
	 {
		 exclude = is_in_rectangle( flash_array[ii].xval, flash_array[ii].yval,
	     
			                       rect_array[kk] );
		 kk += 1;
	 }
	
	 if (( kk == rect_count ) && ( exclude == FALSE))
	 {
		// fprintf(outfile,"ii = %d X%dY%dD03*\n",ii, flash_array[ii].xval, flash_array[ii].yval);
           fprintf(outfile,"X%dY%dD03*\n",flash_array[ii].xval, flash_array[ii].yval);
	 }
 }

 fclose(outfile);

} // end ko_filter_call

int main(int argc, char **argv)
{


if( argc != 4 )   // check to see if correct number of params
{
  printf("ko_filter, incorrect number of arguments\n");
  printf( "USAGE: ko_filter flashfile rectfile outfile\n");
  
}
else
{
  ko_filter_call( argv[1], argv[2], argv[3]);
  
}

} // end main

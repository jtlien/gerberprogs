#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

#define MAX_FLASHES  400000
#define MAX_SHAPES 1000

// reads in a file that begins with a G54Dxxx
//      followed by 1..n line of X..Y...Dxxx
//      determines which of the dcodes are inside the list of exclusion boxes
//      specified in file2
//      file2 is    
//           xloc yloc [C | R] height width
//           
//           on each line

//       for example
//            1000 2000 R 100 200 excludes a rectangle at 1000 2000 with height 100 width 200
//            2000 3000 C 100 200 excludes a circle at 2000 3000 with radius 100
//

struct shapestuff
{
	int xloc;
	int yloc;
	int height;
	int width;
	int radius;
	int is_rectangle;
	int is_circle;
	int ur_x;
	int ur_y;
	int ll_x;
	int ll_y;
} shape_array[MAX_SHAPES];

int distance( int inx, int iny, int ptx, int pty )
{
	double x1;
	double y1;
	double x2;
	double y2;
    double sum_squares;
	int root;

	x1 = inx;
	y1 = iny;

	x2 = ptx;
	y2 = pty;


	sum_squares = (( x1 - x2) * ( x1 - x2)) + (( y1 - y2) * (y1 - y2));

	root = (int) sqrt( sum_squares);

	return(root);
}

struct flashstuff
{
	int xval;
	int yval;
}   flash_array[MAX_FLASHES];

// this routine will return true of the given x y coordinant is inside the
//  given shape

int is_in_shape( int inx, int iny, struct shapestuff shp)
{
int dist;

	if (shp.is_rectangle==TRUE)
	{
	 if ((inx < shp.ll_x ) || ( inx > shp.ur_x ))
	 { 
		return(FALSE);
	 }
	 if ((iny < shp.ll_y ) || ( iny > shp.ur_y ))
	 {
		return(FALSE);
	 }
	 return(TRUE);
	}

	if (shp.is_circle == TRUE)
	{
	 dist = distance( inx, iny, shp.xloc, shp.yloc);

	 // printf("dist = %d shp.radius = %d \n",dist, shp.radius);

	 if (dist > shp.radius )
	 { 
		return(FALSE);
	 }
	 
	 return(TRUE);
	}

	//printf("Shape is neither \n");

  return(TRUE);

}  // is_in_shape


// filters a list of flashes in flash_list against a list of rectangles in rect_list
//   if the 

void ko_filter_call(  char *flash_file_str, 
					  char *shape_file_str, char *out_file_str)
{

FILE *flashfile;
FILE *shapefile;
FILE *outfile;
int endoffile;
int nf;
char thisline[300];
char digitx_str[300];
char digity_str[300];
int flash_count;
int newx;
int newy;
int ii,kk;
int rectx;
int recty;
int rectwidth;
int rectheight;

int shape_count;
int exclude;
int circle_radius;
char gstr[300];



 newx=-1;
 newy=-1;

 flashfile = fopen(flash_file_str,"r");
 if (flashfile==NULL)
 {
	 printf("Unable to open the input flash file = %s \n", flash_file_str);
	 exit(-1);
 }

  strncpy(gstr,"G54D524*\n",40);  // default for now in case one is not provided...
                                   // this is flash for thieving dot

  endoffile=getline(flashfile,thisline);
  flash_count = 0;
  while(endoffile==FALSE)
  {

    if (thisline[0] != 'G')
	{
		if (thisline[0] == 'X')
		{
	      ii = 1;
		  kk=0;
		  if ( thisline[ii] == '-')  // handle minus sign
		  {
			  digitx_str[0] = '-';
			  ii += 1;
              kk = 1;
		  }
		  while(( isdigit( thisline[ii] )) && ( ii < 30))
		  {
			  digitx_str[kk] = thisline[ii];
			  kk += 1;
			  ii += 1;
		  }
          digitx_str[kk]= '\0';

		  if (thisline[ii] != 'D')
		  {
			  if ( thisline[ii] == 'Y')
			  {
				  kk = 0;
				  ii += 1;
                  if ( thisline[ii] == '-')  // handle minus sign
				  {
			        digity_str[0] = '-';
			        ii += 1;
                     kk = 1;
				  }
				  while(( isdigit( thisline[ii])) && ( kk < 30))
				  {
					  digity_str[kk] = thisline[ii];
					  kk += 1;
					  ii += 1;
				  }
				 digity_str[kk]= thisline[ii];
			  
			    newx= atoi(digitx_str);
		  	    newy= atoi(digity_str);

				//printf("Adding to flash_array, newx = %d newy = %d flash_count = %d \n",
					 //          newx, newy, flash_count);

			    flash_array[flash_count].xval= newx;
			    flash_array[flash_count].yval= newy;
			    if (flash_count < MAX_FLASHES)
				{
			    	flash_count += 1;
				}
			    else
				{
				  printf("Number of flashes exceeds %d \n",MAX_FLASHES);
			      exit(-1);
				}
			  }    // Y
		    else
			{
			 // no y

			 newx = atoi(digitx_str);
			 //printf("Adding to flash_array 2, newx = %d newy = %d flash_count = %d \n",
					 //          newx, newy, flash_count);

			 flash_array[flash_count].xval=newx;
			 flash_array[flash_count].yval=newy;
			 if (flash_count < MAX_FLASHES)
			 {
				flash_count += 1;
			 }
			 else
			 {
				printf("Number of flashes exceeds %d \n",MAX_FLASHES);
			    exit(-1);
			 }
			}    
		  }    // no D
		}
       else   // Doesn't begin with X
	   {
		   if (thisline[0] == 'Y')
		   {
			ii = 1;
			kk=0; 
			if ( thisline[ii] == '-')  // handle minus sign
			{
			  digity_str[0] = '-';
			  ii += 1;
              kk = 1;
			}
			while(( isdigit( thisline[ii] )) && ( ii < 30) )
			{
				digity_str[kk] = thisline[ii];
				kk += 1;
				ii +=1;
			}
			digity_str[kk]= '\0';
			newy=atoi(digity_str);
			//printf("Adding to flash_array 3, newx = %d newy = %d flash_count = %d \n",
				//	           newx, newy, flash_count);

			flash_array[flash_count].xval=newx;
			flash_array[flash_count].yval=newy;
            if (flash_count < MAX_FLASHES)
			{
				flash_count += 1;
			}
			else
			{
				printf("Number of flashes exceeds %d \n",MAX_FLASHES);
			    exit(-1);
			}
		   }   // Y
	   }

	 }  // doesn't begin with G
	else
	{           // Begins with G

     strncpy(gstr, thisline, 120);

	}
	endoffile=getline(flashfile,thisline);
  }
  fclose(flashfile);

 printf("Done reading flash file , flash_count = %d \n",flash_count);

 shapefile=fopen(shape_file_str,"r");

 if (shapefile==NULL)
	{
	 printf("Unable to open the input shapes file = %s \n",shape_file_str);
	 exit(-1);
	}

 outfile = fopen(out_file_str,"w");
 if (outfile == NULL)
	{
	 printf("Unable to open the output file = %s \n",out_file_str);
	 exit(-1);
	}

 endoffile=getline(shapefile,thisline);

 nf=split_line(thisline);

 shape_count=0;

 while( endoffile == FALSE)
	{

	 // printf("str_array char = %c \n",str_array[2][0] );

	 if (str_array[2][0] == 'R')
	 {
	  rectx = atoi( str_array[0]);
	  recty = atoi( str_array[1]);

	  rectwidth = atoi( str_array[3]);
	  rectheight = atoi( str_array[4]);


	  shape_array[shape_count].height=rectheight;
	  shape_array[shape_count].width=rectwidth;
	  shape_array[shape_count].ur_x = rectx + ( rectwidth / 2);
	  shape_array[shape_count].ur_y = recty + ( rectheight / 2);
	  shape_array[shape_count].ll_x = rectx - ( rectwidth / 2);
	  shape_array[shape_count].ll_y = recty - ( rectheight / 2);
	  shape_array[shape_count].xloc = rectx;
	  shape_array[shape_count].yloc = recty;

	  shape_array[shape_count].is_rectangle=TRUE;
	  shape_array[shape_count].is_circle=FALSE;
	  if (shape_count < MAX_SHAPES)
	  {
	   shape_count +=1;
	  }
	  else
	  {
		 printf("Maximum number of shapes exceeded \n");
		 exit(-1);
	  }
	 }

   if (str_array[2][0] == 'C')
	 {
	  rectx = atoi( str_array[0]);
	  recty = atoi( str_array[1]);

	  circle_radius = atoi( str_array[3]);
	  rectheight = atoi( str_array[4]);


	  shape_array[shape_count].radius=circle_radius;
	  
	  shape_array[shape_count].ur_x = -1;
	  shape_array[shape_count].ur_y = -1;
	  shape_array[shape_count].ll_x = -1;
	  shape_array[shape_count].ll_y = -1;
	  shape_array[shape_count].xloc = rectx;
	  shape_array[shape_count].yloc = recty;

	  shape_array[shape_count].is_rectangle=FALSE;
	  shape_array[shape_count].is_circle=TRUE;

	  if (shape_count < MAX_SHAPES)
	  {
	   shape_count +=1;
	  }
	  else
	  {
		 printf("Maximum number of shapes exceeded \n");
		 exit(-1);
	  }
	 }
    endoffile=getline(shapefile,thisline);
	nf=split_line(thisline);
 }
  fclose(shapefile);

 printf("Done reading the shape files shape_count = %d \n", shape_count);


 fprintf(outfile,"%s",gstr);

 for(ii =0; ii < flash_count; ii += 1)
 {

	 exclude = FALSE;

	 // printf("i = %d \n", ii );
	 kk =0;

	 while(( kk < shape_count) && ( exclude == FALSE))
	 {
		 exclude = is_in_shape( flash_array[ii].xval, flash_array[ii].yval,
	     
			                       shape_array[kk] );
		 // printf("kk = %d exclude = %d \n", kk , exclude);

		 kk += 1;
	 }
	
	 if (( kk == shape_count ) && ( exclude == FALSE))
	 {
		// fprintf(outfile,"ii = %d X%dY%dD03*\n",ii, flash_array[ii].xval, flash_array[ii].yval);
           fprintf(outfile,"X%dY%dD03*\n",flash_array[ii].xval, flash_array[ii].yval);
	 }
 }

 fclose(outfile);

} // end ko_filter_call

int main(int argc, char **argv)
{


if( argc != 4 )   // check to see if correct number of params
{
  printf("ko_filter2, incorrect number of arguments\n");
  printf( "USAGE: ko_filter2 flashfile rectfile outfile\n");
  
}
else
{
  ko_filter_call( argv[1], argv[2], argv[3]);
  
}

} // end main

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

#define MAX_FLASHES  400000
#define MAX_SHAPES 1000
#define LINELEN 300

// reads in a file that begins with a G54Dxxx
//      followed by 1..n line of X..Y...Dxxx
//      determines which of the dcodes are inside the list of exclusion boxes
//      specified in file2
//      file2 is    
//           xloc yloc [C | R] height width
//           
//           on each line

//       for example
//            1000 2000 R 100 200 excludes a rectangle at 1000 2000 with height 100 width 200
//            2000 3000 C 100 200 excludes a circle at 2000 3000 with radius 100
//

struct shapestuff
{
	int xloc;
	int yloc;
	int height;
	int width;
	int radius;
	int is_rectangle;
	int is_circle;
	int ur_x;
	int ur_y;
	int ll_x;
	int ll_y;
} shape_array[MAX_SHAPES];

 char D[LINELEN];  
 char X[LINELEN];
 char Y[LINELEN];
 double current_rect_x;
 double current_rect_y;
 int curr_rect_x;
 int curr_rect_y;

 int current_is_circle;
 int current_is_rect;

 int shape_count;

void set_rectarray( int inx , int iny, int width, int height, int isrect)
{
	 shape_array[shape_count].xloc = inx;
	 shape_array[shape_count].yloc = iny;
	 shape_array[shape_count].width= width;
     shape_array[shape_count].height = height;

	 if ( isrect)
	 {
		 shape_array[shape_count].is_circle = FALSE;
		 shape_array[shape_count].is_rectangle=TRUE;
	 }	
	 if ( isrect==FALSE) // circle
	 {
		 shape_array[shape_count].is_circle = TRUE;
		 shape_array[shape_count].is_rectangle= FALSE;
		 shape_array[shape_count].radius = width;
	 }

	 shape_array[shape_count].ur_x = inx + (width/2 );
	 shape_array[shape_count].ur_y = iny + (height/2);

     shape_array[shape_count].ll_x = inx - (width/2);
	 shape_array[shape_count].ll_y = iny - (height/2);

}  // end sec_rectarray

void getstring( char *val, char *myval)
{
  val++; // Skip past D or Y or X

  if ( *val == '-')
  {
	val++;
	*myval = '-';
	myval++;
    while( isdigit(*val) )
	{
     *myval = *val ;
     val++;
     myval++;
	}
  }
  else
  {
    while( isdigit(*val) )
	{
     *myval = *val ;
     val++;
     myval++;
	}
  }
  *myval = '\0';
}



ProcessStringNoOut(char thestring[])
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char X[LINELEN];
     char Y[LINELEN];
     
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
     placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) )
	 {
         getstring(placeX,X);
	     getstring(placeY,Y);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 } 
		 
		 curr_rect_x= (int) (10000 * current_rect_x);
		 curr_rect_y= (int) (10000 * current_rect_y);

        set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);
     }
     else if( strchr(thestring,'X') != NULL ) 
	 {
         getstring(placeX,X);
		 if (placeD != NULL)
		 {
	       getstring(placeD,D);
		 }
		 curr_rect_x= (int) (10000 * current_rect_x);
		 curr_rect_y= (int) (10000 * current_rect_y);

	   set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);  
     }
     else if ( strchr(thestring,'Y') != NULL ) 
	 {
	   getstring(placeY,Y);
	   if ( placeD != NULL)
	   {
	     getstring(placeD,D);
	   }
	   curr_rect_x= (int) (10000 * current_rect_x);
	   curr_rect_y= (int) (10000 * current_rect_y);

	   set_rectarray( atoi(X),atoi(Y) , curr_rect_x, curr_rect_y, current_is_rect);
     }
     else if ( strchr(thestring , 'M') == NULL)
	 {
       
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

void get_digits( char *instr, int index, char *outstr)
{
int jj;
int kk;


     jj = index;
	 kk=0;
	while(( isdigit(instr[jj] ) || instr[jj]== '.' )  && ( kk < 120) )
	{
		*outstr = instr[jj];
		outstr++;
		jj += 1;
		kk += 1;
	}

    *outstr = '\0';


} // end get_digits

int distance( int inx, int iny, int ptx, int pty )
{
	double x1;
	double y1;
	double x2;
	double y2;
    double sum_squares;
	int root;

	x1 = inx;
	y1 = iny;

	x2 = ptx;
	y2 = pty;


	sum_squares = (( x1 - x2) * ( x1 - x2)) + (( y1 - y2) * (y1 - y2));

	root = (int) sqrt( sum_squares);

	return(root);
}

// like keepread, but doesn't output a file
//
void keepread_call_no_out(char *fname)
{
FILE *thisfile;
int debug;
char oneline[300];
char xvalstr[300];
char yvalstr[300];
int jj;



   debug=0;
   D[0] = '\n';

   current_is_circle = FALSE;
   current_is_rect = FALSE;

   shape_count = 0;

   thisfile =  fopen( fname,"r");
   if ( thisfile == NULL)
   {
	   printf("In keepread_call_out, unable to open the input file = %s \n",fname);
	   exit(-1);
   }

 
   if ((thisfile != NULL) ) {
       while( fgets(oneline, LINELEN, thisfile) != NULL)
	   {
		  // printf("Linein = %s \n",oneline);
		  if (( oneline[0] == 'X') || ( oneline[0] == 'Y') )
		  {
            ProcessStringNoOut(oneline);
		  }
		  if (oneline[0] == '%')
		  {
			  if ( ( oneline[1] == 'A') && ( oneline[2] == 'D')  &&  // %ADD
				   ( oneline[3] == 'D') && (oneline[4] == '3'))
			  {
				  if ((oneline[7] == 'R') && (oneline[8]=',')) // Rectangle
				  {
					  jj=9;
					  get_digits( oneline,jj,xvalstr);
                      current_is_circle = FALSE;
					  current_is_rect = TRUE;

					//  printf("Rect xvalstr = %s \n",xvalstr);
					  jj = jj + strlen( xvalstr);

					  if ((oneline[jj] == 'X')  || (oneline[jj] == 'x') )
					  {
						  jj += 1;
						  get_digits( oneline,jj, yvalstr);

						  current_rect_x= atof( xvalstr);
						  current_rect_y= atof( yvalstr);
					  }
					  else
					  {
						  if (oneline[jj] == '*') // square
						  {
							  current_rect_x=atof(xvalstr);
							  current_rect_y=current_rect_x; 
						  }
					  }

				  }  // Rectangle or square 
				  
				  if ((oneline[7] == 'C') && (oneline[8]=',')) // Circle or donut
				  {
					  jj=9;
					  current_is_circle =TRUE;
					  current_is_rect = FALSE;
					  get_digits( oneline,jj,xvalstr);
					
					  jj = jj + strlen( xvalstr);

					  if ((oneline[jj] == 'X')  || (oneline[jj] == 'x') )
					  {
						  jj += 1;
						  get_digits( oneline,jj, yvalstr);

						  current_rect_x= atof( xvalstr);
						  current_rect_y= atof( yvalstr);
					  }
					  else
					  {
						  if (oneline[jj] == '*') // square
						  {
							  current_rect_x=atof(xvalstr);
							  current_rect_y=current_rect_x; 
						  }
					  }

				  }  // Rectangle or square

			  }  // Flash 

		  }  // %

		  if (oneline[0] == 'G')   // G code
		  {

		  }


       } // fgets ok
   }
   fclose(thisfile);
   

} // keepout_call_no_out

struct flashstuff
{
	int xval;
	int yval;
}   flash_array[MAX_FLASHES];

// this routine will return true of the given x y coordinant is inside the
//  given shape

int is_in_shape( int inx, int iny, struct shapestuff shp)
{
int dist;

	if (shp.is_rectangle==TRUE)
	{
	 if ((inx < shp.ll_x ) || ( inx > shp.ur_x ))
	 { 
		return(FALSE);
	 }
	 if ((iny < shp.ll_y ) || ( iny > shp.ur_y ))
	 {
		return(FALSE);
	 }
	 return(TRUE);
	}

	if (shp.is_circle == TRUE)
	{
	 dist = distance( inx, iny, shp.xloc, shp.yloc);

	 // printf("dist = %d shp.radius = %d \n",dist, shp.radius);

	 if (dist > shp.radius )
	 { 
		return(FALSE);
	 }
	 
	 return(TRUE);
	}

	//printf("Shape is neither \n");

  return(TRUE);

}  // is_in_shape


// filters a list of flashes in flash_list against a list of rectangles in rect_list
//   if the 

void ko_filter_call(  char *flash_file_str, 
					  char *shape_file_str, char *out_file_str)
{

FILE *flashfile;
FILE *shapefile;
FILE *outfile;
int endoffile;
char thisline[300];
char digitx_str[300];
char digity_str[300];
int flash_count;
int newx;
int newy;
int ii,kk;

int exclude;
char gstr[300];



 newx=-1;
 newy=-1;

 flashfile = fopen(flash_file_str,"r");
 if (flashfile==NULL)
 {
	 printf("Unable to open the input flash file = %s \n", flash_file_str);
	 exit(-1);
 }

  endoffile=getline(flashfile,thisline);
  flash_count = 0;
  while(endoffile==FALSE)
  {

    if (thisline[0] != 'G')
	{
		if (thisline[0] == 'X')
		{
	      ii = 1;
		  kk=0;
		  if ( thisline[ii] == '-')  // handle minus sign
		  {
			  digitx_str[0] = '-';
			  ii += 1;
              kk = 1;
		  }
		  while(( isdigit( thisline[ii] )) && ( ii < 30))
		  {
			  digitx_str[kk] = thisline[ii];
			  kk += 1;
			  ii += 1;
		  }
          digitx_str[kk]= '\0';

		  if (thisline[ii] != 'D')
		  {
			  if ( thisline[ii] == 'Y')
			  {
				  kk = 0;
				  ii += 1;
                  if ( thisline[ii] == '-')  // handle minus sign
				  {
			        digity_str[0] = '-';
			        ii += 1;
                     kk = 1;
				  }
				  while(( isdigit( thisline[ii])) && ( kk < 30))
				  {
					  digity_str[kk] = thisline[ii];
					  kk += 1;
					  ii += 1;
				  }
				 digity_str[kk]= thisline[ii];
			  
			    newx= atoi(digitx_str);
		  	    newy= atoi(digity_str);

				//printf("Adding to flash_array, newx = %d newy = %d flash_count = %d \n",
					 //          newx, newy, flash_count);

			    flash_array[flash_count].xval= newx;
			    flash_array[flash_count].yval= newy;
			    if (flash_count < MAX_FLASHES)
				{
			    	flash_count += 1;
				}
			    else
				{
				  printf("Number of flashes exceeds %d \n",MAX_FLASHES);
			      exit(-1);
				}
			  }    // Y
		    else
			{
			 // no y

			 newx = atoi(digitx_str);
			 //printf("Adding to flash_array 2, newx = %d newy = %d flash_count = %d \n",
					 //          newx, newy, flash_count);

			 flash_array[flash_count].xval=newx;
			 flash_array[flash_count].yval=newy;
			 if (flash_count < MAX_FLASHES)
			 {
				flash_count += 1;
			 }
			 else
			 {
				printf("Number of flashes exceeds %d \n",MAX_FLASHES);
			    exit(-1);
			 }
			}    
		  }    // no D
		}
       else   // Doesn't begin with X
	   {
		   if (thisline[0] == 'Y')
		   {
			ii = 1;
			kk=0; 
			if ( thisline[ii] == '-')  // handle minus sign
			{
			  digity_str[0] = '-';
			  ii += 1;
              kk = 1;
			}
			while(( isdigit( thisline[ii] )) && ( ii < 30) )
			{
				digity_str[kk] = thisline[ii];
				kk += 1;
				ii +=1;
			}
			digity_str[kk]= '\0';
			newy=atoi(digity_str);
			//printf("Adding to flash_array 3, newx = %d newy = %d flash_count = %d \n",
				//	           newx, newy, flash_count);

			flash_array[flash_count].xval=newx;
			flash_array[flash_count].yval=newy;
            if (flash_count < MAX_FLASHES)
			{
				flash_count += 1;
			}
			else
			{
				printf("Number of flashes exceeds %d \n",MAX_FLASHES);
			    exit(-1);
			}
		   }   // Y
	   }

	 }  // doesn't begin with G
	else
	{           // Begins with G

     strncpy(gstr, thisline, 120);

	}
	endoffile=getline(flashfile,thisline);
  }
  fclose(flashfile);

 printf("Done reading flash file , flash_count = %d \n",flash_count);

 shapefile=fopen(shape_file_str,"r");

 

 keepread_call_no_out( shape_file_str);

 
 printf("Done reading the shape files shape_count = %d \n", shape_count);

 outfile=fopen(out_file_str,"w");

 if (outfile == NULL)
 {
	 printf("Unalbe to open the output file = %s \n",out_file_str);
	 exit(-1);
 }

 fprintf(outfile,"%s",gstr);

 for(ii =0; ii < flash_count; ii += 1)
 {

	 exclude = FALSE;

	 // printf("i = %d \n", ii );
	 kk =0;

	 while(( kk < shape_count) && ( exclude == FALSE))
	 {
		 exclude = is_in_shape( flash_array[ii].xval, flash_array[ii].yval,
	     
			                       shape_array[kk] );
		 // printf("kk = %d exclude = %d \n", kk , exclude);

		 kk += 1;
	 }
	
	 if (( kk == shape_count ) && ( exclude == FALSE))
	 {
		// fprintf(outfile,"ii = %d X%dY%dD03*\n",ii, flash_array[ii].xval, flash_array[ii].yval);
           fprintf(outfile,"X%dY%dD03*\n",flash_array[ii].xval, flash_array[ii].yval);
	 }
 }

 fclose(outfile);

} // end ko_filter_call

int main(int argc, char **argv)
{


if( argc != 4 )   // check to see if correct number of params
{
  printf("ko_filter2, incorrect number of arguments\n");
  printf( "USAGE: ko_filter2 flashfile rectfile outfile\n");
  
}
else
{
  ko_filter_call( argv[1], argv[2], argv[3]);
  
}

} // end main

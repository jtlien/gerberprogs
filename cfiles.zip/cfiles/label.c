#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0

int mirrorx;
int mirrory;
int count;
int nangle;
int ntext;
int ndontuse;

double pitch;
double nx;
double ny;
double nxx;
double nyy;

int left;
int right;
double xmx;
double ymx;
int found;
int t;


FILE *file1,*logfile;

double pitch;
double llx;
double lly;
double x;
double y;

char letter[40];
char str1[120];
char str2[120];
char str3[120];
char str4[120];

char text[120][120];
double xoffset;
double yoffset;
double txt_offset;


double dx;
double dy;
int indx;
int indy;


int i;
int j;

// Modified by bac 12-15-97 to get mirroring to work
// Modified by bac 12-23-97 to work for large arrays (>40)
// Creates Allegro script that generates text labels for BGA array
// Requires an input file with nx	ny	nxx	nyy
// where nx and ny are the outer pin counts and nxx and nyy are the 
// counts of the depopulated area, and redirection to script file
// Add or delete lines at end of array to specify all the letters.
// mirrorx=0 puts lowest letter or number on the left, 1 reverses
// mirrory=0 puts lowest letter or number on the bottom, 1 reverses



void mkstr( char inchar1, char inchar2, char *instr)
{

if ( inchar1 != ' ')
{
instr[0] = inchar1;
instr[1] = inchar2;
instr[2] = NULLCHAR;
}
else
{
instr[0] = inchar2;
instr[1] = NULLCHAR;
}


} // end mkstr

int main( int argc, char **argv)
{
  letter[0] =' ';
  letter[1] ='A';
  letter[2] ='B';
  letter[3] ='C';
  letter[4] ='D';
  letter[5] ='E';
  letter[6] ='F';
  letter[7] ='G';
  letter[8] ='H';
  letter[9] ='J';
  letter[10]='K';
  letter[11]='L';
  letter[12]='M';
  letter[13]='N';
  letter[14]='P';
  letter[15]='R';
  letter[16]='T';
  letter[17]='U';
  letter[18]='V';
  letter[19]='W';
  letter[20]='Y';


// Modify this line to change pitch

  pitch = 1.27;
  txt_offset = 2.0 *pitch;

// Modify mirroring if necessary

  mirrorx=0;
  mirrory=0;


  count = 0;
  nangle = 0;
  ntext = 0;

  // logfile = fopen("label.log", "w");

  // if (logfile == NULL)
  // {
//	  printf("Error: Unable to open the log file = label.log\n");
//	  exit(-1);
 // }

  file1  = fopen(argv[1], "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",argv[1]);
	  exit(-1);
  }

  while ( fscanf( file1, "%s %s %s %s \n",str1,str2,str3,str4) == 4)

  {
    nx = atof(str1);
    ny = atof(str2);

    nxx = atof(str3);
    nyy = atof(str4);

  }

  fclose(file1);

  printf("version 2.0\n");
  printf("setwindow pcb\n");
  printf("define text\n");
  printf("setwindow form.textblock\n");
  printf("FORM textblock 4 width %8.4f\n", pitch/5.0);
  printf("FORM textblock 4 height %8.4f\n", pitch/3.0);
  printf("FORM textblock 4 line_spacing %8.4f\n", pitch/5.0);
  printf("FORM textblock 4 character_spacing %8.4f\n", pitch/10.0);
  printf("FORM textblock done\n");

  printf("setwindow pcb\n");
  printf("add text\n");
  printf("setwindow form.mini\n");
  printf("FORM mini class PART GEOMETRY\n");
  printf("FORM mini subclass DISPLAY_BOTTOM\n");
  printf("FORM mini mirror NO\n");
  printf("FORM mini angle 0.0000\n");
  printf("FORM mini text_block 4\n");
  printf("FORM mini text_justification Center\n");
  printf("setwindow pcb\n");
  
// build label array

  for (left = 0; left <= 2; left++) {
    for (right = 1; right <= 20; right++) {
      ntext += 1;
      mkstr(letter[left],letter[right], text[ntext]);
    }
  }

  dx  = (nx-nxx)/2.0;
  dy  = (ny-nyy)/2.0;

  xmx = nx - dx;
  ymx = ny - dy;

  llx = ((1 - nx)/2.0)*pitch;
  lly = ((1 - ny)/2.0)*pitch;

  xoffset = mirrorx*(nx + 1);
  yoffset = mirrory*(ny + 1);

  // Place alpha in X direction and numbers in Y
  // To change this, reverse the commented out lines.

  for (i = 1; i <= nx; i++) {
    x = llx + (i - 1)*pitch;
    indx = (int) (xoffset + i*(1.0 - 2.0*mirrorx));

    printf("pick %8.4f %8.4f\n", x, lly - txt_offset);
// First printf puts text in X direction, second one puts numbers
    printf("text %s\n", text[indx]);
    // printf("text %d\n", indx);
  }    

  for (j = 1; j <= ny; j++) {
    y = lly + (j - 1)*pitch;
    indy = (int) (yoffset + j*(1.0 - 2.0*mirrory));

    printf("pick %8.4f %8.4f\n", llx - txt_offset, y-pitch/6.0);
//  First printf puts text in Y direction, second one puts numbers
    // printf("text %s\n", text[indy]);
    printf("text %d\n", indy);
  }    
  printf("done\n");

} // end main

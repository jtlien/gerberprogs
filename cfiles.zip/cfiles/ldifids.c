#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"
#include "makepan.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

void out_numbers( int xval, int yval)
{
printf("G54D610*\n");
printf("X%dY%d%s\n",xval-18100,yval+122500,"D02*");  // 7
printf("X%dY%d%s\n",xval-13900,yval+122500,"D01*");
printf("X%dY%d%s\n",xval-16900,yval+117500,"D01*");

printf("X%dY%d%s\n",xval-15583,yval+82500,"D02*");   // 6
printf("X%dY%d%s\n",xval-16417,yval+82500,"D01*");
printf("X%dY%d%s\n",xval-18084,yval+80833,"D01*");
printf("X%dY%d%s\n",xval-18084,yval+78334,"D01*");
printf("X%dY%d%s\n",xval-17251,yval+77500,"D01*");
printf("X%dY%d%s\n",xval-15519,yval+77500,"D01*");
printf("X%dY%d%s\n",xval-14686,yval+78334,"D01*");
printf("X%dY%d%s\n",xval-14686,yval+79167,"D01*");
printf("X%dY%d%s\n",xval-15519,yval+80000,"D01*");
printf("X%dY%d%s\n",xval-18084,yval+80000,"D01*");

printf("X%dY%d%s\n",xval-14400,yval+42500,"D02*");   // 5
printf("X%dY%d%s\n",xval-17600,yval+42500,"D01*");
printf("X%dY%d%s\n",xval-17600,yval+40900,"D01*");
printf("X%dY%d%s\n",xval-15200,yval+40900,"D01*");
printf("X%dY%d%s\n",xval-14250,yval+39950,"D01*");
printf("X%dY%d%s\n",xval-14250,yval+38750,"D01*");
printf("X%dY%d%s\n",xval-15200,yval+37500,"D01*");
printf("X%dY%d%s\n",xval-16500,yval+37500,"D01*");
printf("X%dY%d%s\n",xval-17450,yval+38450,"D01*");

printf("X%dY%d%s\n",xval-18500,yval-900,"D02*");    // 4
printf("X%dY%d%s\n",xval-15100,yval-900,"D01*");
printf("X%dY%d%s\n",xval-18500,yval-900,"D02*");
printf("X%dY%d%s\n",xval-16000,yval+2500,"D01*");
printf("X%dY%d%s\n",xval-16000,yval+2500,"D02*");
printf("X%dY%d%s\n",xval-16000,yval-2500,"D01*");


printf("X%dY%d%s\n",xval-17667,yval-38333,"D02*");    //3
printf("X%dY%d%s\n",xval-16833,yval-37500,"D01*");
printf("X%dY%d%s\n",xval-15167,yval-37500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval-38333,"D01*");
printf("X%dY%d%s\n",xval-14333,yval-39167,"D01*");
printf("X%dY%d%s\n",xval-15167,yval-40000,"D01*");
printf("X%dY%d%s\n",xval-16000,yval-40000,"D01*");
printf("X%dY%d%s\n",xval-17667,yval-41667,"D02*");
printf("X%dY%d%s\n",xval-16833,yval-42500,"D01*");
printf("X%dY%d%s\n",xval-15167,yval-42500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval-41667,"D01*");
printf("X%dY%d%s\n",xval-14333,yval-40833,"D01*");
printf("X%dY%d%s\n",xval-15167,yval-40000,"D01*");
printf("X%dY%d%s\n",xval-16000,yval-40000,"D01*");

printf("X%dY%d%s\n",xval-17667,yval-78333,"D02*");     //2
printf("X%dY%d%s\n",xval-16833,yval-77500,"D01*");
printf("X%dY%d%s\n",xval-15167,yval-77500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval-78333,"D01*");
printf("X%dY%d%s\n",xval-14333,yval-79167,"D01*");
printf("X%dY%d%s\n",xval-15167,yval-80000,"D01*");
printf("X%dY%d%s\n",xval-16833,yval-80000,"D01*");
printf("X%dY%d%s\n",xval-17667,yval-80833,"D01*");
printf("X%dY%d%s\n",xval-17667,yval-82500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval-82500,"D01*");
printf("X%dY%d%s\n",xval-17667,yval-78333,"D02*");
printf("X%dY%d%s\n",xval-16833,yval-77500,"D01*");
printf("X%dY%d%s\n",xval-15167,yval-77500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval-78333,"D01*");
printf("X%dY%d%s\n",xval-14333,yval-79167,"D01*");
printf("X%dY%d%s\n",xval-15167,yval-80000,"D01*");
printf("X%dY%d%s\n",xval-16833,yval-80000,"D01*");
printf("X%dY%d%s\n",xval-17667,yval-80833,"D01*");
printf("X%dY%d%s\n",xval-17667,yval-82500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval-82500,"D01*");

printf("X%dY%d%s\n",xval-16000,yval-117500,"D02*"); //  1
printf("X%dY%d%s\n",xval-16000,yval-122500,"D01*");
printf("X%dY%d%s\n",xval-16800,yval-122500,"D02*");
printf("X%dY%d%s\n",xval-15200,yval-122500,"D01*");
printf("X%dY%d%s\n",xval-16900,yval-119400,"D02*");
printf("X%dY%d%s\n",xval-16000,yval-117500,"D01*");
printf("X%dY%d%s\n",xval-16000,yval-117500,"D02*");
printf("X%dY%d%s\n",xval-16000,yval-122500,"D01*");
printf("X%dY%d%s\n",xval-16800,yval-122500,"D02*");
printf("X%dY%d%s\n",xval-15200,yval-122500,"D01*");
printf("X%dY%d%s\n",xval-16900,yval-119400,"D02*");
printf("X%dY%d%s\n",xval-16000,yval-117500,"D01*");

}  // end out_numbers

void out_numbers_out( int xval, int yval, FILE *outfile)
{
fprintf(outfile,"G54D610*\n");
fprintf(outfile,"X%dY%d%s\n",xval-18100,yval+122500,"D02*");  // 7
fprintf(outfile,"X%dY%d%s\n",xval-13900,yval+122500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16900,yval+117500,"D01*");

fprintf(outfile,"X%dY%d%s\n",xval-15583,yval+82500,"D02*");   // 6
fprintf(outfile,"X%dY%d%s\n",xval-16417,yval+82500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-18084,yval+80833,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-18084,yval+78334,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17251,yval+77500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15519,yval+77500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14686,yval+78334,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14686,yval+79167,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15519,yval+80000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-18084,yval+80000,"D01*");

fprintf(outfile,"X%dY%d%s\n",xval-14400,yval+42500,"D02*");   // 5
fprintf(outfile,"X%dY%d%s\n",xval-17600,yval+42500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17600,yval+40900,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15200,yval+40900,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14250,yval+39950,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14250,yval+38750,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15200,yval+37500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16500,yval+37500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17450,yval+38450,"D01*");

fprintf(outfile,"X%dY%d%s\n",xval-18500,yval-900,"D02*");    // 4
fprintf(outfile,"X%dY%d%s\n",xval-15100,yval-900,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-18500,yval-900,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+2500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+2500,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval-2500,"D01*");


fprintf(outfile,"X%dY%d%s\n",xval-17667,yval-38333,"D02*");    //3
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval-37500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval-37500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval-38333,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval-39167,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval-40000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval-40000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval-41667,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval-42500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval-42500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval-41667,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval-40833,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval-40000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval-40000,"D01*");

fprintf(outfile,"X%dY%d%s\n",xval-17667,yval-78333,"D02*");     //2
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval-77500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval-77500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval-78333,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval-79167,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval-80000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval-80000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval-80833,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval-82500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval-82500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval-78333,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval-77500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval-77500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval-78333,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval-79167,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval-80000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval-80000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval-80833,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval-82500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval-82500,"D01*");

fprintf(outfile,"X%dY%d%s\n",xval-16000,yval-117500,"D02*"); //  1
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval-122500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16800,yval-122500,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-15200,yval-122500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16900,yval-119400,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval-117500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval-117500,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval-122500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16800,yval-122500,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-15200,yval-122500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16900,yval-119400,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval-117500,"D01*");

}  // end out_numbers

void out_numbers_flip( int xval, int yval)
{
printf("G54D610*\n");

printf("X%dY%d%s\n",xval-16000,yval+122500,"D02*"); //  1
printf("X%dY%d%s\n",xval-16000,yval+117500,"D01*");
printf("X%dY%d%s\n",xval-16800,yval+117500,"D02*");
printf("X%dY%d%s\n",xval-15200,yval+117500,"D01*");
printf("X%dY%d%s\n",xval-16900,yval+121600,"D02*");
printf("X%dY%d%s\n",xval-16000,yval+122500,"D01*");
printf("X%dY%d%s\n",xval-16000,yval+122500,"D02*");
printf("X%dY%d%s\n",xval-16000,yval+117500,"D01*");
printf("X%dY%d%s\n",xval-16800,yval+117500,"D02*");
printf("X%dY%d%s\n",xval-15200,yval+117500,"D01*");
printf("X%dY%d%s\n",xval-16900,yval+121600,"D02*");
printf("X%dY%d%s\n",xval-16000,yval+122500,"D01*");


printf("X%dY%d%s\n",xval-17667,yval+81666,"D02*");   // 2
printf("X%dY%d%s\n",xval-16833,yval+82500,"D01*");
printf("X%dY%d%s\n",xval-15167,yval+82500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval+81666,"D01*");
printf("X%dY%d%s\n",xval-14333,yval+80833,"D01*");
printf("X%dY%d%s\n",xval-15167,yval+80000,"D01*");
printf("X%dY%d%s\n",xval-16833,yval+80000,"D01*");
printf("X%dY%d%s\n",xval-17667,yval+79166,"D01*");
printf("X%dY%d%s\n",xval-17667,yval+77500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval+77500,"D01*");
printf("X%dY%d%s\n",xval-17667,yval+81667,"D02*");
printf("X%dY%d%s\n",xval-16833,yval+82500,"D01*");
printf("X%dY%d%s\n",xval-15167,yval+82500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval+81667,"D01*");
printf("X%dY%d%s\n",xval-14333,yval+80833,"D01*");
printf("X%dY%d%s\n",xval-15167,yval+80000,"D01*");
printf("X%dY%d%s\n",xval-16833,yval+80000,"D01*");
printf("X%dY%d%s\n",xval-17667,yval+79167,"D01*");
printf("X%dY%d%s\n",xval-17667,yval+77500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval+77500,"D01*");


printf("X%dY%d%s\n",xval-17667,yval+41666,"D02*");   // 3
printf("X%dY%d%s\n",xval-16833,yval+42500,"D01*");
printf("X%dY%d%s\n",xval-15167,yval+42500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval+41666,"D01*");
printf("X%dY%d%s\n",xval-14333,yval+40833,"D01*");
printf("X%dY%d%s\n",xval-15167,yval+40000,"D01*");
printf("X%dY%d%s\n",xval-16000,yval+40000,"D01*");
printf("X%dY%d%s\n",xval-17667,yval+38333,"D02*");
printf("X%dY%d%s\n",xval-16833,yval+37500,"D01*");
printf("X%dY%d%s\n",xval-15167,yval+37500,"D01*");
printf("X%dY%d%s\n",xval-14333,yval+38333,"D01*");
printf("X%dY%d%s\n",xval-14333,yval+39167,"D01*");
printf("X%dY%d%s\n",xval-15167,yval+40000,"D01*");
printf("X%dY%d%s\n",xval-16000,yval+40000,"D01*");


printf("X%dY%d%s\n",xval-18500,yval-900,"D02*");   // 4
printf("X%dY%d%s\n",xval-15100,yval-900,"D01*");
printf("X%dY%d%s\n",xval-18500,yval-900,"D02*");
printf("X%dY%d%s\n",xval-16000,yval+2500,"D01*");
printf("X%dY%d%s\n",xval-16000,yval+2500,"D02*");
printf("X%dY%d%s\n",xval-16000,yval-2500,"D01*");

printf("X%dY%d%s\n",xval-14400,yval-37500,"D02*");   // 5
printf("X%dY%d%s\n",xval-17600,yval-37500,"D01*");
printf("X%dY%d%s\n",xval-17600,yval-39100,"D01*");
printf("X%dY%d%s\n",xval-15200,yval-39100,"D01*");
printf("X%dY%d%s\n",xval-14250,yval-40050,"D01*");
printf("X%dY%d%s\n",xval-14250,yval-41250,"D01*");
printf("X%dY%d%s\n",xval-15200,yval-42500,"D01*");
printf("X%dY%d%s\n",xval-16500,yval-42500,"D01*");
printf("X%dY%d%s\n",xval-17450,yval-41550,"D01*");


printf("X%dY%d%s\n",xval-15583,yval-77500,"D02*");  // 6
printf("X%dY%d%s\n",xval-16417,yval-77500,"D01*");
printf("X%dY%d%s\n",xval-18084,yval-79167,"D01*");
printf("X%dY%d%s\n",xval-18084,yval-81666,"D01*");
printf("X%dY%d%s\n",xval-17251,yval-82500,"D01*");
printf("X%dY%d%s\n",xval-15519,yval-82500,"D01*");
printf("X%dY%d%s\n",xval-14686,yval-81666,"D01*");
printf("X%dY%d%s\n",xval-14686,yval-80933,"D01*");
printf("X%dY%d%s\n",xval-15519,yval-80000,"D01*");
printf("X%dY%d%s\n",xval-18084,yval-80000,"D01*");


printf("X%dY%d%s\n",xval-18100,yval-117500,"D02*");  // 7
printf("X%dY%d%s\n",xval-13900,yval-117500,"D01*");
printf("X%dY%d%s\n",xval-16900,yval-122500,"D01*");


}  // end out_numbers_flip

void out_numbers_flip_out( int xval, int yval, FILE *outfile)
{
fprintf(outfile,"G54D610*\n");

fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+122500,"D02*"); //  1
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+117500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16800,yval+117500,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-15200,yval+117500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16900,yval+121600,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+122500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+122500,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+117500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16800,yval+117500,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-15200,yval+117500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16900,yval+121600,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+122500,"D01*");


fprintf(outfile,"X%dY%d%s\n",xval-17667,yval+81666,"D02*");   // 2
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval+82500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval+82500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval+81666,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval+80833,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval+80000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval+80000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval+79166,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval+77500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval+77500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval+81667,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval+82500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval+82500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval+81667,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval+80833,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval+80000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval+80000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval+79167,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval+77500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval+77500,"D01*");


fprintf(outfile,"X%dY%d%s\n",xval-17667,yval+41666,"D02*");   // 3
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval+42500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval+42500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval+41666,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval+40833,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval+40000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+40000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17667,yval+38333,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16833,yval+37500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval+37500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval+38333,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14333,yval+39167,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15167,yval+40000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+40000,"D01*");


fprintf(outfile,"X%dY%d%s\n",xval-18500,yval-900,"D02*");   // 4
fprintf(outfile,"X%dY%d%s\n",xval-15100,yval-900,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-18500,yval-900,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+2500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval+2500,"D02*");
fprintf(outfile,"X%dY%d%s\n",xval-16000,yval-2500,"D01*");

fprintf(outfile,"X%dY%d%s\n",xval-14400,yval-37500,"D02*");   // 5
fprintf(outfile,"X%dY%d%s\n",xval-17600,yval-37500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17600,yval-39100,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15200,yval-39100,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14250,yval-40050,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14250,yval-41250,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15200,yval-42500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16500,yval-42500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17450,yval-41550,"D01*");


fprintf(outfile,"X%dY%d%s\n",xval-15583,yval-77500,"D02*");  // 6
fprintf(outfile,"X%dY%d%s\n",xval-16417,yval-77500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-18084,yval-79167,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-18084,yval-81666,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-17251,yval-82500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15519,yval-82500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14686,yval-81666,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-14686,yval-80933,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-15519,yval-80000,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-18084,yval-80000,"D01*");


fprintf(outfile,"X%dY%d%s\n",xval-18100,yval-117500,"D02*");  // 7
fprintf(outfile,"X%dY%d%s\n",xval-13900,yval-117500,"D01*");
fprintf(outfile,"X%dY%d%s\n",xval-16900,yval-122500,"D01*");


}  // end out_numbers_flip_out

void ldifids_call_out(int current_layer,char *outfilestr)
{
double ur_x;
double ul_x;
double ll_x;
double lr_x;

double ur_y;
double lr_y;
double ll_y;
double ul_y;

double fidxloc;
double fidyloc;

FILE *outfile;

double thisy;
int i,j;
char percenchar;

percenchar='%';

// fidxloc = 1554000;   // 14x18 for now
// fidyloc = 1838000;

fidxloc = ldi_fid_x_loc * 10000 ;   // from setvars_aaXbb.c
fidyloc = ldi_fid_y_loc * 10000 ;

ur_x =  fidxloc;
lr_x =  fidxloc;
ll_x = -fidxloc;
ul_x = -fidxloc;

ur_y =  fidyloc;
lr_y = -fidyloc;
ll_y = -fidyloc;
ul_y =  fidyloc;

outfile=fopen(outfilestr,"w");
if (outfile==NULL)
{
	printf("In ldifids, unable to open the output file = %s \n",outfilestr);
	exit(-1);
}

// print upper right rectangle

fprintf(outfile,"%cLPD*%c\n",percenchar,percenchar);

fprintf(outfile,"G54D735*\n");
fprintf(outfile,"X%dY%dD03*\n",(int)ur_x,(int)ur_y);

// do upper right fid

fprintf(outfile,"%cLPC*%c\n",percenchar,percenchar);

out_numbers_flip_out( (int) ur_x + 32000, (int) ur_y, outfile);

for (i=1; i < 8; i += 1)
{

  thisy = 12.0 - ( i -1) * 4.0;  // 12, 8, 4, 0, -4, -8 ,-12

  thisy = thisy * 10000;
  j=0;

  if ( current_layer == i )
   {

     fprintf(outfile, "G54D732*\n");   // AMMACRO1
     
     fprintf(outfile, "X%dY%dD03*\n",(int) ur_x, (int) (ur_y + thisy));
      
	 fprintf(outfile, "G54D733*\n");   // AMMACRO2
     
     fprintf(outfile, "X%dY%dD03*\n",(int) ur_x, (int) (ur_y + thisy));
     
  }
  else
  {
     fprintf(outfile, "G54D731*\n");   // C1.20
     
     fprintf(outfile, "X%dY%dD03*\n", (int) ur_x, (int) (ur_y + thisy));

	 fprintf(outfile, "G54D730*\n");   // C.8

     fprintf(outfile, "X%dY%dD03*\n", (int) ur_x, (int) (ur_y + thisy));

   //  fprintf(outfile, "G54D544*\n");   // D544, C.3
     
   //  fprintf(outfile, "X%dY%dD03*\n", (int) ur_x, (int) (ur_y + thisy));
     
  }

}  

fprintf(outfile,"%cLPD*%c\n",percenchar,percenchar);

for (i=1; i < 8; i += 1)
{

  thisy = 12.0 - ( i -1) * 4.0;  // 12, 8, 4, 0, -4, -8 ,-12

  thisy = thisy * 10000;
  j=0;

   if ( i != current_layer)
   {
     fprintf(outfile, "G54D730*\n");   // C.8

     fprintf(outfile, "X%dY%dD03*\n", (int) ur_x, (int) (ur_y + thisy));
   }
   else
   {
     fprintf(outfile, "G54D733*\n");   // C 1.3 X .7
     
     fprintf(outfile, "X%dY%dD03*\n",(int) ur_x, (int) (ur_y + thisy));
   }

}

// fprintf(outfile,"%cLPD*%c\n",percenchar,percenchar);

fprintf(outfile,"G54D735*\n");
fprintf(outfile,"X%dY%dD03*\n",(int)lr_x,(int)lr_y);


fprintf(outfile,"%cLPC*%c\n",percenchar,percenchar);
out_numbers_out( (int) lr_x + 32000, (int) lr_y, outfile);

// do lower right fid

for (i=1; i < 8; i += 1)
{

  thisy = -12.0 + ( i -1) * 4.0;  // -12, -8, -4, 0, 4, 8 ,12

  thisy = thisy * 10000;
  j=0;

  if ( current_layer == i )
   {

     fprintf(outfile, "G54D732*\n");   // AMMACRO1
     
     fprintf(outfile, "X%dY%dD03*\n", (int) lr_x, (int) (lr_y + thisy));
     
  }
  else
  {
     fprintf(outfile, "G54D731*\n");   // C1.20
     
     fprintf(outfile, "X%dY%dD03*\n", (int) lr_x, (int) (lr_y + thisy) );

    // fprintf(outfile, "G54D544*\n");   // D544, C.3
     
    // fprintf(outfile, "X%dY%dD03*\n", (int) lr_x, (int) (lr_y + thisy));
     
  }

}  

fprintf(outfile,"%cLPD*%c\n",percenchar,percenchar);

for (i=1; i < 8; i += 1)
{

  thisy = -12.0 + ( i -1) * 4.0;  // -12, -8, -4, 0, 4, 8, 12

  thisy = thisy * 10000;
  j=0;

   if ( i != current_layer)
   {
     fprintf(outfile, "G54D730*\n");   // C.8

     fprintf(outfile, "X%dY%dD03*\n", (int) lr_x, (int) (lr_y + thisy) );
   }
   else
   {
     fprintf(outfile, "G54D733*\n");   // C 1.3 X .7
     
     fprintf(outfile, "X%dY%dD03*\n", (int) lr_x, (int) (lr_y + thisy));
   }

}

// fprintf(outfile,"%cLPD*%c\n",percenchar,percenchar);

fprintf(outfile,"G54D735*\n");
fprintf(outfile,"X%dY%dD03*\n",(int)ul_x,(int)ul_y);

fprintf(outfile,"%cLPC*%c\n",percenchar,percenchar);
out_numbers_flip_out( (int) ul_x, (int) ul_y, outfile);

// do ul fid

for (i=1; i < 8; i += 1)
{

  thisy = 12.0 - ( i -1) * 4.0;  // 12, -8, -4, 0, 4, 8 ,12

  thisy = thisy * 10000;
  

  if ( current_layer == i )
   {

     fprintf(outfile,"G54D732*\n");   // AMMACRO1
     
     fprintf(outfile, "X%dY%dD03*\n", (int) ul_x, (int) (ul_y + thisy));
    
     
  }
  else
  {
     fprintf(outfile, "G54D731*\n");   // C1.20
     
     fprintf(outfile, "X%dY%dD03*\n", (int) ul_x , (int) (ul_y + thisy));


   //  fprintf(outfile, "G54D544*\n");   // D544, C.3
     
    // fprintf(outfile, "X%dY%dD03*\n", (int) ul_x, (int)  (ul_y + thisy));
     
  }


}  

fprintf(outfile,"%cLPD*%c\n",percenchar,percenchar);

for (i=1; i < 8; i += 1)
{

  thisy = 12.0 - ( i -1) * 4.0;  // 12, 8, 4, 0, -4, -8, -12

  thisy = thisy * 10000;
  j=0;

   if ( i != current_layer)
   {
     fprintf(outfile, "G54D730*\n");   // C.8

     fprintf(outfile, "X%dY%dD03*\n", (int) ul_x, (int) (ul_y + thisy));
   }
   else
   {
     fprintf(outfile, "G54D733*\n");   // 1.3 X .7
     
     fprintf(outfile, "X%dY%dD03*\n", (int) ul_x, (int) (ul_y + thisy) );

   }

}

// fprintf(outfile,"%cLPD*%c\n",percenchar,percenchar);

fprintf(outfile,"G54D735*\n");
fprintf(outfile,"X%dY%dD03*\n",(int)ll_x,(int)ll_y);


fprintf(outfile,"%cLPC*%c\n",percenchar,percenchar);
out_numbers_out( (int) ll_x, (int) ll_y, outfile);


// do lower left fid

for (i=1; i < 8; i += 1)
{

  thisy = -12.0 + ( i -1) * 4.0;  // -12, -8, -4, 0, 4, 8 ,12

  thisy = thisy * 10000;
  j=0;

  if ( current_layer == i )
   {

     fprintf(outfile, "G54D732*\n");   // AMMACRO1
     
     fprintf(outfile, "X%dY%dD03*\n", (int) ll_x, (int) (ll_y + thisy));
     
  }
  else
  {
     fprintf(outfile, "G54D731*\n");   // C1.20

     fprintf(outfile, "X%dY%dD03*\n", (int) ll_x, (int) (ll_y + thisy));
     
    // fprintf(outfile, "G54D544*\n");   // D544, C.3
     
    // fprintf(outfile, "X%dY%dD03*\n", (int) ll_x, (int) (ll_y + thisy));
     
  }

}  

fprintf(outfile,"%cLPD*%c\n",percenchar,percenchar);

for (i=1; i < 8; i += 1)
{

  thisy = -12.0 + ( i -1) * 4.0;  // -12, -8, -4, 0, 4, 8, 12

  thisy = thisy * 10000;
  j=0;

   if ( i != current_layer)
   {
     fprintf(outfile, "G54D730*\n");   // C.8
     fprintf(outfile, "X%dY%dD03*\n", (int) ll_x, (int) (ll_y + thisy) );

   }
  else
  {
     fprintf(outfile, "G54D733*\n");   // C1.3X.7
     
     fprintf(outfile, "X%dY%dD03*\n", (int) ll_x, (int) (ll_y + thisy));
  }

}

fclose(outfile);

}  // end ldifids_out

void ldifids_call(int current_layer)
{
double ur_x;
double ul_x;
double ll_x;
double lr_x;

double ur_y;
double lr_y;
double ll_y;
double ul_y;

double fidxloc;
double fidyloc;

double thisy;
int i,j;
char percenchar;

percenchar='%';

// fidxloc = 1554000;   // 14x18 for now
// fidyloc = 1838000;

//fidxloc = ldi_fid_x_loc * 10000;   // from setvars_aaXbb.c
//fidyloc = ldi_fid_y_loc * 10000;

fidxloc = 1554000;   // 14x18 for now
fidyloc = 1838000;

ur_x =  fidxloc;
lr_x =  fidxloc;
ll_x = -fidxloc;
ul_x = -fidxloc;

ur_y =  fidyloc;
lr_y = -fidyloc;
ll_y = -fidyloc;
ul_y =  fidyloc;


// print upper right rectangle

printf("%cLPD*%c\n",percenchar,percenchar);

printf("G54D735*\n");
printf("X%dY%dD03*\n",(int)ur_x,(int)ur_y);

// do upper right fid

printf("%cLPC*%c\n",percenchar,percenchar);

out_numbers_flip( (int) ur_x + 32000, (int) ur_y);

for (i=1; i < 8; i += 1)
{

  thisy = 12.0 - ( i -1) * 4.0;  // 12, 8, 4, 0, -4, -8 ,-12

  thisy = thisy * 10000;
  j=0;

  if ( current_layer == i )
   {

     printf( "G54D732*\n");   // AMMACRO1
     
     printf( "X%dY%dD03*\n",(int) ur_x, (int) (ur_y + thisy));
      
	 printf( "G54D733*\n");   // AMMACRO2
     
     printf( "X%dY%dD03*\n",(int) ur_x, (int) (ur_y + thisy));
     
  }
  else
  {
     printf( "G54D731*\n");   // C1.20
     
     printf( "X%dY%dD03*\n", (int) ur_x, (int) (ur_y + thisy));

	 printf( "G54D730*\n");   // C.8

     printf( "X%dY%dD03*\n", (int) ur_x, (int) (ur_y + thisy));

   //  printf( "G54D544*\n");   // D544, C.3
     
   //  printf( "X%dY%dD03*\n", (int) ur_x, (int) (ur_y + thisy));
     
  }

}  

printf("%cLPD*%c\n",percenchar,percenchar);

for (i=1; i < 8; i += 1)
{

  thisy = 12.0 - ( i -1) * 4.0;  // 12, 8, 4, 0, -4, -8 ,-12

  thisy = thisy * 10000;
  j=0;

   if ( i != current_layer)
   {
     printf( "G54D730*\n");   // C.8

     printf( "X%dY%dD03*\n", (int) ur_x, (int) (ur_y + thisy));
   }
   else
   {
     printf( "G54D733*\n");   // C 1.3 X .7
     
     printf( "X%dY%dD03*\n",(int) ur_x, (int) (ur_y + thisy));
   }

}

// printf("%cLPD*%c\n",percenchar,percenchar);

printf("G54D735*\n");
printf("X%dY%dD03*\n",(int)lr_x,(int)lr_y);


printf("%cLPC*%c\n",percenchar,percenchar);
out_numbers( (int) lr_x + 32000, (int) lr_y);

// do lower right fid

for (i=1; i < 8; i += 1)
{

  thisy = -12.0 + ( i -1) * 4.0;  // -12, -8, -4, 0, 4, 8 ,12

  thisy = thisy * 10000;
  j=0;

  if ( current_layer == i )
   {

     printf( "G54D732*\n");   // AMMACRO1
     
     printf( "X%dY%dD03*\n", (int) lr_x, (int) (lr_y + thisy));
     
  }
  else
  {
     printf( "G54D731*\n");   // C1.20
     
     printf( "X%dY%dD03*\n", (int) lr_x, (int) (lr_y + thisy) );

    // printf( "G54D544*\n");   // D544, C.3
     
    // printf( "X%dY%dD03*\n", (int) lr_x, (int) (lr_y + thisy));
     
  }

}  

printf("%cLPD*%c\n",percenchar,percenchar);

for (i=1; i < 8; i += 1)
{

  thisy = -12.0 + ( i -1) * 4.0;  // -12, -8, -4, 0, 4, 8, 12

  thisy = thisy * 10000;
  j=0;

   if ( i != current_layer)
   {
     printf( "G54D730*\n");   // C.8

     printf( "X%dY%dD03*\n", (int) lr_x, (int) (lr_y + thisy) );
   }
   else
   {
     printf( "G54D733*\n");   // C 1.3 X .7
     
     printf( "X%dY%dD03*\n", (int) lr_x, (int) (lr_y + thisy));
   }

}

// printf("%cLPD*%c\n",percenchar,percenchar);

printf("G54D735*\n");
printf("X%dY%dD03*\n",(int)ul_x,(int)ul_y);

printf("%cLPC*%c\n",percenchar,percenchar);
out_numbers_flip( (int) ul_x, (int) ul_y);

// do ul fid

for (i=1; i < 8; i += 1)
{

  thisy = 12.0 - ( i -1) * 4.0;  // 12, -8, -4, 0, 4, 8 ,12

  thisy = thisy * 10000;
  

  if ( current_layer == i )
   {

     printf("G54D732*\n");   // AMMACRO1
     
     printf( "X%dY%dD03*\n", (int) ul_x, (int) (ul_y + thisy));
    
     
  }
  else
  {
     printf( "G54D731*\n");   // C1.20
     
     printf( "X%dY%dD03*\n", (int) ul_x , (int) (ul_y + thisy));


   //  printf( "G54D544*\n");   // D544, C.3
     
    // printf( "X%dY%dD03*\n", (int) ul_x, (int)  (ul_y + thisy));
     
  }


}  

printf("%cLPD*%c\n",percenchar,percenchar);

for (i=1; i < 8; i += 1)
{

  thisy = 12.0 - ( i -1) * 4.0;  // 12, 8, 4, 0, -4, -8, -12

  thisy = thisy * 10000;
  j=0;

   if ( i != current_layer)
   {
     printf( "G54D730*\n");   // C.8

     printf( "X%dY%dD03*\n", (int) ul_x, (int) (ul_y + thisy));
   }
   else
   {
     printf( "G54D733*\n");   // 1.3 X .7
     
     printf( "X%dY%dD03*\n", (int) ul_x, (int) (ul_y + thisy) );

   }

}

// printf("%cLPD*%c\n",percenchar,percenchar);

printf("G54D735*\n");
printf("X%dY%dD03*\n",(int)ll_x,(int)ll_y);


printf("%cLPC*%c\n",percenchar,percenchar);
out_numbers( (int) ll_x, (int) ll_y);


// do lower left fid

for (i=1; i < 8; i += 1)
{

  thisy = -12.0 + ( i -1) * 4.0;  // -12, -8, -4, 0, 4, 8 ,12

  thisy = thisy * 10000;
  j=0;

  if ( current_layer == i )
   {

     printf( "G54D732*\n");   // AMMACRO1
     
     printf( "X%dY%dD03*\n", (int) ll_x, (int) (ll_y + thisy));
     
  }
  else
  {
     printf( "G54D731*\n");   // C1.20

     printf( "X%dY%dD03*\n", (int) ll_x, (int) (ll_y + thisy));
     
    // printf( "G54D544*\n");   // D544, C.3
     
    // printf( "X%dY%dD03*\n", (int) ll_x, (int) (ll_y + thisy));
     
  }

}  

printf("%cLPD*%c\n",percenchar,percenchar);

for (i=1; i < 8; i += 1)
{

  thisy = -12.0 + ( i -1) * 4.0;  // -12, -8, -4, 0, 4, 8, 12

  thisy = thisy * 10000;
  j=0;

   if ( i != current_layer)
   {
     printf( "G54D730*\n");   // C.8
     printf( "X%dY%dD03*\n", (int) ll_x, (int) (ll_y + thisy) );

   }
  else
  {
     printf( "G54D733*\n");   // C1.3X.7
     
     printf( "X%dY%dD03*\n", (int) ll_x, (int) (ll_y + thisy));
  }

}


}  // end ldifids



/*
int main( int argc, char **argv)
{

  if (argc != 2)
  {
	  printf("In ldifids, wrong number of arguments \n");
	  printf("Usage  ldifids layernum \n");
	  exit(-1);
  }
  else
  {
	  ldifids_call( atoi( argv[1]) );
  }

}  // end main

*/



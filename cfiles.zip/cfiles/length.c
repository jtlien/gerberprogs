#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  length.awk  rev 1.0  7/28/95
//  written by Ted Ammann
//
//  This program is meant to work on the Allegro .ecl file that has 
//  been processed by the strip.awk script.

//  The results from length.awk are meant to be redirected (UNIX ">") to
//  another file for further processing

//  The output of this program is a two column file with the first column being
//  the netname and the second being the lentgh.
//  
//  Sample Output
//              D01I01   2.60450
//              D01I02   3.48600
//              D01I03   3.12750



void length_call_out( char *infilestr, char *outfilestr)
{

char name[200];
int number_fields;
int endoffile;
char thisline[300];
FILE *file1;
FILE *outfile;

   file1=fopen(infilestr,"r");

   if (file1 == NULL)
   {
	   printf("In length_call, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"w");

   if (outfile == NULL)
   {
	   printf("In length_call, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   number_fields = split_line(thisline);

  while(endoffile==FALSE)
  {
   //If the current line has only one field then that is the netname so save it.
    if (number_fields == 1) 
    { 
     strncpy(name,str_array[0],120);
	 
    }

  // If the Current line contains the word "TOTAL" the 4th field is the length
  // so output the name and length
   if ( strstr(thisline,"TOTAL") != NULL)   // $0 ~ /TOTAL/
   {
    fprintf(outfile,"%20s%10s\n", name,str_array[3]);
   }

   endoffile=getline(file1,thisline);
   number_fields = split_line(thisline);
  }

  fclose(file1);
  fclose(outfile);

}  // end length_call_out

void length_call( char *infilestr)
{

char name[200];
int number_fields;
int endoffile;
char thisline[300];
FILE *file1;


   file1=fopen(infilestr,"r");
   if (file1 == NULL)
   {
	   printf("In length_call, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   number_fields = split_line(thisline);

  while(endoffile==FALSE)
  {
   //If the current line has only one field then that is the netname so save it.
    if (number_fields == 1) 
    { 
     strncpy(name,str_array[0],120);
	 
    }

  // If the Current line contains the word "TOTAL" the 4th field is the length
  // so output the name and length
   if ( strstr(thisline,"TOTAL") != NULL)   // $0 ~ /TOTAL/
   {
    printf("%20s%10s\n", name,str_array[3]);
   }

   endoffile=getline(file1,thisline);
   number_fields = split_line(thisline);
  }

  fclose(file1);

}  // end length_call

/*
int main( int argc, char **argv)
{
	if (argc != 2)
	{
     printf("In length, wrong number of arguments \n");
	 printf("Usage: length fname \n");
	 exit(-1);
	}
	else
	{
		length_call(argv[1]);
	}

} // end main

  */

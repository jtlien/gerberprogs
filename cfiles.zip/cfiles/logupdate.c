#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAXDCODE 900

#include "utilprogs.h"

int pn_validate_call(char *pnstr);
void makeoffset_call();

//! /bin/ksh

// logupdate

// Update the makelog file to use the most current syntax and content
// Amount of user input depends on age of original file.
// Some numerical data must be re-entered
// Runs makeoffset at the end to guarantee new offset file
// This program must track makestruct!
// bac
// Sept 8, 1998

// Version 0.93
// Leave 9-layer stuff in here to support old designs. Add warning message.
// March 3, 1999

// Version 0.94
// Structures created with makestruct earlier than 0.93 must be re-built.
// Includes the code for pre-93 updates, but exits before reaching it.
// Prompt only for tab, append it to all necessary names including top-level dir
// Add a choice prompt for makeoffset. Make copy of existing offsets file.
// Delete old reports with old name, remind user to re-run review_prep.
// May 17, 1999
// Version 0.94a
// Changed to cleanly exit for non-8-digit part numbers.
// May 18, 1999

void mv_file( char *frfilestr,char *tofilestr)
{
	cp_file(frfilestr,tofilestr);
	rm_file(frfilestr);
}


void logupdate_call()
{
int n;

char artfin[300];
char bgapitch[300];
char blindvias[300];
char bodyx[300];
char bodyy[300];
char c4pitch[300];
char chipx[300];
char chipy[300];
char conntype[300];
char cust[300];
char descrip[300];
char invc[300];
char llc[300];
char mors[300];
char parttype[300];
char rulestr[300];
char xrunstr[300];
char stiffx[300];
char stiffy[300];
char tab[300];
char thruvias[300];
char viapitch[300];
int result1;
int result4;
char teststr1[300];
char teststr2[300];
char teststr3[300];
char toprint[300];
char viatype[40];
char basename[300];
char localname[300];      
char logname[100];  
char username[100];
char userdate[100];
char outline[120][120];
FILE *uselogfile;
FILE *templogfile;
FILE *lognamefile;

char MSVER[300];
char USELOG[300];
char MSVERLINE[300];
char PROGNAME[100];
char MSPATH[300];
char brdnum[300];
char vintage[300];
char release_stat[300];
char pwdstr[300];
char junkstr[300];
int grepret;
char line1[300];
char line8[300];
char fromfilestr[300];
char tofilestr[300];
char linev[300];
char REV[40];
char stacktype[300];
char trule[300];
int namelen;
char line9[300];
char viadescrip[300];
int numlines;

strncpy(REV,"0.94",20);
strncpy(PROGNAME,"logupdate",40);

strncpy(release_stat,"1",4); //  change to 1 when released !!!!!!!!!!

// Code and data location variables
if ( strcmp(release_stat,"0" )==0 )
{
  // LIBPATH="/users/bac/library"
  // PROGPATH="/users/bac/library/flowscripts"
   strncpy(MSPATH,"/users/bac/library/flowscripts/ms2.5",120);
   strncpy(USELOG,"/users/bac/library/usage_log",90);
}
else
{
  // LIBPATH="/usr/local/library"
  // PROGPATH="/usr/local/bin"
	if (WINDOWS)
	{
      strncpy(MSPATH,"m:\\design\\software\\mmm\\mkstr.rbw",120);
	}
	else
	{
		strncpy(MSPATH,"/usr/local/bin/makestruct",80);
	}

	if ( WINDOWS)
	{
		strncpy(USELOG,"m:\\design\\software\\mmm\\usage",40);
	}
	else
    {
      strncpy(USELOG,"/usr/local/bin/scripts/usage/makestructlog",90);
	}
}

n=1;

// Acquire version of released makestruct
//MSVERLINE=$(grep 'REV=' $MSPATH)
if (WINDOWS)
{
	strncpy(MSVERLINE,"REV=0.94",40);
}
else
{
	sgrep(MSPATH,"REV=",30);
	strncpy(MSVERLINE,grep_array[0],40);
}

split(MSVERLINE,junkstr,MSVER,"="); // =${MSVERLINE##*=}

getwd(pwdstr);

get_full_path_end(pwdstr,basename);    // =${PWD##*\/}
//localname=${PWD##*\/}.mcm
strncpy(localname,basename,120);
strncat(localname,".mcm",10);

strncpy(logname,"report/makelog",40);
get_whoami(username);             // =$(whoami)
get_date(userdate);          // =$(date)

// Check for presence of necessary files

//for needfile in $localname $logname 

   if ( ! file_exists(localname) )
   {
      printf( "%s does not exist. Be sure you are in the part directory.\n",
		  localname);
      exit(-1);
   }
   if ( ! file_exists(logname) )
   {
      printf( "%s does not exist. Be sure you are in the part directory.\n",
		  logname);
      exit(-1);
   }

// Check vintage of makelog file
//linev=$(grep "version" $logname)

   grepret = sgrep(logname,"version",30);
   if (grepret == 0 )
   {
	   strncpy(linev,grep_array[0],40);
   }
   else
   {
	   strncpy(linev,"",10);
   }
   
//vintage=${linev##*:}
split(linev,junkstr,vintage,":");

printf( "Newest makestruct -- %s\n",MSVER);
printf( "makelog created by - %s\n",vintage);

if ( strcmp(vintage,MSVER ) == 0 )
{
   printf( "No update needed. Goodbye!\n");
   exit(1);
}

// Log usage

uselogfile= fopen(USELOG,"a");
if (uselogfile == NULL)
{
	printf("Unable to append to log file = %s \n",USELOG);
}
else
{
  fprintf(uselogfile,"%15s ", PROGNAME);  // |awk '{printf("%-15s",$1)}'>>$USELOG
  fprintf(uselogfile,"%s     %s     %s     %s\n",REV,basename,username,userdate); // >> $USELOG
  fclose(uselogfile);
}

// if version 0.91 not much is needed.
// if older than 0.91, re-create the file.

// Keep up to 3 old copies of makelog file
strncpy(teststr1,logname,120);
strncat(teststr1,".old",10);

strncpy(teststr2,logname,120);
strncat(teststr2,"-1.old",10);

strncpy(teststr3,logname,120);
strncat(teststr3,"-2.old",10);

if ( file_exists( teststr1 ) )
{
   if ( file_exists( teststr2 ) )
   {
      cp_file( teststr2 ,teststr3);
   }
   cp_file( teststr1, teststr2); // $logname.old $logname.old,1
}
cp_file( logname, teststr1);         // logname.old


// If created with version 0.93, update the version and append the tab
// to the part number.
if ( strcmp(vintage,"0.93") == 0 )
{
   // Make basic changes to version 
	templogfile = fopen("templog","w");
	if (templogfile == NULL)
	{
		printf("Unable to open the templog file for writing\n");
		exit(-1);
	}

   fprintf(templogfile, "Structure updated %s by %s \n", userdate,username); //>templog

   fclose(templogfile);
   ssed("report/makelog","version:0.93","version:0.94","templog1"); // >>templog1

   cat_files("templog","templog1","templog2");
   cp_file("templog2","templog");

   
   // Determine if legal partnumber used
   namelen=strlen(basename);                 //${#basename}
   result4=pn_validate_call( basename ); // >/dev/null
  // result4=$?
   if ((namelen == 8) && ( result4 == 3))	// valid 8-digit number
   {
      while ( result1 != 3 )            
      {
         printf( "Enter 2-digit tab for board number %s-\n",basename);
         gets( tab );
         //brdnum=$basename"-"$tab
		 strncpy(brdnum,basename,120);
		 strncat(brdnum,"-",4);
		 strncat(brdnum,tab,10);

         result1=pn_validate_call(brdnum ); // >/dev/null
         //result1=$?
	     if ( result1 != 3 )
		 {
	       printf( "Enter two numbers!\n");
		 }
      }
      printf( "New Board number is %s\n",brdnum);
   }
   else 
   {
	   if (( namelen == 11) && ( result4 == 3))
	   {
        printf( "Part number %s is valid. Verify that all file names use this number!\n",
		    basename);
        mv_file( "templog", "report/makelog");
        exit(0);
	   }
       else
	   {
        printf( "Part number %s is not a valid old or new number.\n",basename);
        printf( "Re-run makestruct to set up the structure correctly.\n");
        exit(0);
	   }
   }

   // Now update the board part number everywhere it occurs
   strncpy(fromfilestr,"control/",30);     // control/$basename.ctl
   strncat(fromfilestr,brdnum,120);
   strncat(fromfilestr,".ctl",10);

   strncpy(tofilestr,"control/",15);  // control/$brdnum.ctl
   strncat(tofilestr,brdnum,40);
   strncat(tofilestr,".ctl",15);

   mv_file(fromfilestr,tofilestr);

  // mv control/$basename.ctl control/$brdnum.ctl

   strncpy(fromfilestr,basename,120); // $basename.mcm
   strncat(fromfilestr,".mcm",10);
   
   strncpy(tofilestr,brdnum,120); // $brdnum.mcm
   strncat(tofilestr,".mcm",10);

   mv_file(fromfilestr,tofilestr);

 //  mv $basename.mcm $brdnum.mcm

   strncpy(fromfilestr,"aper/",10);   // aper/$basename.apt
   strncat(fromfilestr,basename,50);
   strncat(fromfilestr,".apt",10);

   strncpy(tofilestr,"aper/",10);   // aper/$brdnum.apt
   strncat(fromfilestr,brdnum,50);
   strncat(fromfilestr,".apt",10);

   mv_file(fromfilestr,tofilestr);

   //mv aper/$basename.apt aper/$brdnum.apt 2>/dev/null

   strncpy(fromfilestr,"aper/",10);   // aper/$basename.prt
   strncat(fromfilestr,basename,50);
   strncat(fromfilestr,".prt",10);

   strncpy(tofilestr,"aper/",10);   // aper/$brdnum.prt
   strncat(fromfilestr,brdnum,50);
   strncat(fromfilestr,".prt",10);

  mv_file(fromfilestr,tofilestr);

 //  mv aper/$basename.prt aper/$brdnum.prt 2>/dev/null

   strncpy(fromfilestr,"area/analysis",30);   // area/analysis/$basename.area
   strncat(fromfilestr,basename,50);
   strncat(fromfilestr,".area",10);

   strncpy(tofilestr,"area/analysis",10);   // area/analysis/$brdnum.area
   strncat(fromfilestr,brdnum,50);
   strncat(fromfilestr,".area",10);

   mv_file(fromfilestr,tofilestr);

  // mv area/analysis/$basename.area area/analysis/$brdnum.area 2>/dev/null
   ssed( "pn.txt",basename,brdnum,"pn.tmp");
   ssed("templog", basename,brdnum ,"report/makelog");
   mv_file( "pn.tmp", "pn.txt");
   change_dir("..");
   mv_file( basename, brdnum );
   change_dir("brdnum");
   rm_file("templog");
}
else
{
   printf( "Your structure is too old for this tool to update!\n");
   printf( "Please re-run makestruct to set it up correctly.\n");
   exit(0);
}

   // Check for presence of each type of line in old file and use if present

   grepret =sgrep( logname,"Structure",30); //  $logname > /dev/null
   if (grepret >0)
   {
      strncpy(outline[1],"Structure updated ",50);
	  strncat(outline[1],userdate, 80);
	  strncat(outline[1]," by ",10);
	  strncat(outline[1],username,120);
   }
   else
   {
      //outline[1]=$(grep "Structure" $logname)
	   strncpy(outline[1], grep_array[0],120);
      strncpy(outline[2],"Structure updated ",30);
	  strncat(outline[2],userdate,60);
	  strncat(outline[2]," by ",10);
	  strncat(outline[2],username,40);
   }

   strncpy(outline[3],"Script version:",40);
   strncat(outline[3],MSVER,120);


   // Get part info from old makelog
   grepret=sgrep(logname, "Part Type", 30); // $logname > /dev/null
   if (grepret >0)
   {
      // Get part type
      while ( (strcmp(parttype,"scm") !=0 ) &&  (strcmp(parttype,"wlbi" ) != 0 ))   //2> /dev/null
      {
         printf( "Enter part type (scm,wlbi): \n");
         gets( parttype );
      }
     // outline[4]="Part Type:"$parttype
	  strncpy(outline[4],"Part Type:",30);
	  strncat(outline[4],parttype,120);

   }
   else
   {
      //line1=$(grep "Part Type" $logname)
	   sgrep(logname,"Part Type",30);
	   strncpy(line1,grep_array[0],120);
      split(line1,junkstr,parttype,":");            // parttype=${line1##*:}
      strncpy(outline[4],line1,120);

   }

   grepret=sgrep(logname, "Part Number", 30); //> /dev/null
   if (grepret >0)
   {
      // get part number 
      strncpy(outline[5],"Part Number:",120);
   }
   else
   {
      //outline[5]=$(grep "Part Number" $logname)
	   strncpy(outline[5],grep_array[0],120);
   }

   grepret=sgrep(logname, "Customer", 30);     // $logname > /dev/null

   if ( grepret >0)
   {
      // Get Customer name
      printf( "Enter customer name followed by ENTER: \n");
      gets( cust );
      strncpy(outline[6],"Customer:",30);
	  strncat(outline[6],cust,120);
   }
   else
   {
      //outline[6]=$(grep "Customer" $logname)
	   strncpy(outline[6],grep_array[0],120);

   }

   grepret = sgrep(logname, "Description", 30); //  > /dev/null
   if (grepret >0)
   {
      // Get description
      printf( "Enter brief description followed by ENTER: \n");
      gets( descrip );
      strncpy(outline[7],"Description:",40);
	  strncat(outline[7],descrip,120);
   }
   else
   {
     // outline[7]=$(grep "Description" $logname)
	   strncpy(outline[7],grep_array[0],30);
   }

   if ( strcmp(parttype,"scm" )== 0 )
   {
      // Get chip connection info
      grepret = sgrep(logname, "Die Connection" ,30); // $logname > /dev/null 
      if (grepret >0)
      {
         while( (strcmp(conntype,"y") != 0 ) && (strcmp(conntype,"n") != 0 ) )
         {
            printf( "Will this be a wirebond part? (y/n) \n");
            gets( conntype );
         }
         if ( strcmp(conntype,"y" ) == 0 )
         {
            strncpy(outline[9],"Die Connection:wirebond",50);
		 }
         else
		 {
            strncpy(outline[9],"Die Connection:C4",50);
         }
	  }
      else
	  {
         //outline[9]=$(grep "Die Connection" $logname)
		  strncpy(outline[9],grep_array[0],120);

      }
   

      grepret=sgrep(logname, "Layers" , 30); // > /dev/null
      if (grepret >0)
      {
         // Get layer count
         strncpy(llc,"0",4);
         if ( strcmp(conntype,"y")  ==0)     // wirebond case
         {
            while ( (atoi(llc) != 3 ) &&  (atoi(llc) != 5) && ( atoi(llc) != 7 )  )
            {
               printf( "Enter 3 for 3-layer, 5 for 5-layer 7 for 7-layer: \n");
               gets( llc );
            }
		 }
         else         // flipchip case
		 {
            while( (atoi(llc) != 3 ) &&  (atoi(llc) != 5) && ( atoi(llc) != 7 ) 
				                      && ( atoi(llc) != 9 ) )
			{
	         printf( "Enter 3 for 3-layer, 5 for 5-layer 7 for 7-layer or 9 for 9-layer: \n");
	         gets( llc );
			}
	        if ( atoi(llc) == 9 )
			{
	         printf( "FYI: no new 9-layer designs permitted after 11/13/98.\n");
			}
         }
	  }
      else	// layer count present in file
	  {
         // get rid of = and replace with :
         //line8=$(grep "Layers" $logname)
         grepret =sgrep(logname, "Layers" , 30); // $logname|grep "=" > /dev/null
         if (grepret > 0)
         {
			sgrep(logname,"Layers",30);
			strncpy(line8,grep_array[0],120);

           split(line8,junkstr,llc,":");      //  llc=${line8##*:}
		 }
         else
		 {
            split(line8,junkstr,llc,"=");     // llc=${line8##*=}
         }
      }

      strncpy(outline[8],"Layers:",30);
	  strncat(outline[8],llc,10);

      
      // Deal with stack-ups and via combinations for various layer counts

      // Handle 2 versions for 5-layer
      if ( atoi(llc) == 5 )
      {
         strncpy(mors,"0",10);
         while( (strcmp(mors,"m") != 0 ) && (strcmp(mors,"s") != 0 ))
         {
            printf( "5-layer: Enter m for microstrip or s for stripline: \n");
            gets( mors );
         }
         if ( strcmp(mors,"m" )   == 0 )     // 5-layer microstrip
         {
            strncpy(stacktype,"microstrip",20);
            strncpy(thruvias,"y",10);

            while( (strcmp(blindvias,"y") != 0 ) && ( strcmp(blindvias,"n" ) != 0 ))
            {
               printf( "Will you be using blind vias? (y/n) \n");
               gets( blindvias );
            }
		 }
         else      // 5-layer stripline
		 {
            strncpy(stacktype,"stripline",30);
            while (( strcmp(thruvias,"y") != 0 ) && ( strcmp( thruvias,"n") != 0 ))	
            {
               printf( "Will you be using through vias? (y/n) \n");
               gets( thruvias );
            }
            if ( strcmp(thruvias,"y" ) == 0 )
            {
               while (( strcmp(blindvias,"y") != 0 ) && ( strcmp(blindvias,"n") != 0 ))  
               {
                  printf( "will you also be using blind vias? (y/n) \n" );
                  gets( blindvias );
               }
            }
         }

      // Handle 2 versions for 7-layer
	  }
      else if ( atoi(llc) == 7 )
      {
         strncpy(invc,"0",5);

         while( ( strcmp(invc,"i") != 0 ) && ( strcmp( invc,"n") != 0 ))
         {
            printf( "7-layer: Enter i for inverted stackup or n for traditional stackup: \n");
            gets( invc );
         }
         if ( strcmp(invc,"i" )==0)
         {
            strncpy(stacktype,"inverted",40);
            strncpy(thruvias,"n",10);
            strncpy(blindvias,"y",10);
		 }
         else
		 {
            strncpy(stacktype,"standard",40);
            while ( (strcmp(thruvias,"y") != 0 ) && (strcmp( thruvias,"n") != 0 ))
            {
               printf( "Will you be using through vias? (y/n) \n");
               gets( thruvias );
            }
            if ( strcmp(thruvias,"y" ) == 0 )
            {
               while( (strcmp(blindvias,"y") != 0 ) && (strcmp(blindvias,"n") != 0 ))
               {
                  printf( "will you also be using blind vias? (y/n) \n");
                  gets( blindvias );
               }
            }
         }        // end inverted stackup handling
	  }
      else  //3-layer or 9-layer case
	  {
         strncpy(stacktype,"standard",30);

         if ( atoi(llc) == 3 )
         {
            strncpy(thruvias,"y",4);

            while( (strcmp(blindvias,"y") !=0 ) && ( strcmp(blindvias,"n") != 0 )) 
            {
               printf( "3-layer: Will you be using blind vias? (y/n) \n" );
               gets( blindvias );
            }
		 }
         else
		 {
            while ( ( strcmp( thruvias,"y") != 0 ) && ( strcmp(thruvias,"n") != 0 ))
			
            {
               printf( "9-layer: Will you be using through vias? (y/n) \n");
               gets( thruvias );
            }
            if ( strcmp(thruvias,"y" ) == 0 )
            {
               while (( strcmp(blindvias,"y") != 0 ) && (strcmp(blindvias,"n") != 0 ))
               {
                  printf( "Will you also be using blind vias? (y/n) \n");
                  gets( blindvias );
               }
            }
         }
      }	// end layer count-dependent inputs

      // Determine via type combination from inputs
      if ( strcmp(thruvias,"y")== 0 )
      {
         if ( strcmp(blindvias,"y" )== 0 )
         {
            strncpy(viatype,"BT",4);
            strncpy(viadescrip,"Blind-Through",40);
		 }
         else
		 {
            strncpy(viatype,"TO",4);
            strncpy(viadescrip,"Through-only",40);
         }
	  }
      else
	  {
         strncpy(viatype,"BBB",10);
         strncpy(viadescrip,"Blind-Buried-Blind",40);
      }

      
      strncpy(outline[10],"Stack-up:",30);
	  strncat(outline[10],stacktype,120);

      strncpy(outline[11],"Via combination:",40);
	  strncat(outline[11],viadescrip,120);
  
      
      grepret=sgrep(logname, "Rule Set", 30); // $logname > /dev/null
      if (grepret >0)
      {
         // Get rule set
         while ( (strcmp(rulestr,"9602") != 0 ) &&
			     (strcmp(rulestr,"9604") != 0 ) && 
				 (strcmp(rulestr,"9702") != 0 ) && 
				 (strcmp(rulestr,"9704") != 0 ) &&
				 (strcmp(rulestr,"tdf") != 0 )) 
         {
            printf( "Enter rule set name (9602,9604,9702,9704,tdf): \n");
            gets( rulestr );
         }
         if ( strcmp(rulestr,"9704" ) == 0 )
         {
	      printf( "FYI: no new 9704 designs permitted after 11/13/98.\n");
         }
         //typeset -u rule
		 cv_toupper( rulestr,trule);
         strncpy(rulestr,trule,120);

         strncpy(outline[14],"Rule Set:",40);
		 strncat(outline[14],rulestr,30);
	  }
      else
	  {
         //line9=$(grep "Rule Set" $logname)
		  strncpy(line9,grep_array[0],120);

         strncpy(outline[14],line9,120);
      }
      
      
      // Get feature pitch numbers
      strncpy(c4pitch,"-1",10);

      while ( (atoi(c4pitch) <  0 ) || (atoi(c4pitch) > 99 ) ) //This syntax produces errors!!
      {
         printf( "Enter the minimum C4 or wirebond pad pitch, in mm: \n");
         gets( c4pitch );
      }

      strncpy(bgapitch,"-1",30);

      while ( (atoi(bgapitch) <  0 ) || ( atoi(bgapitch) > 99 ) )  
      {
         printf( "Enter the minimum BGA pitch, in mm: \n");
         gets( bgapitch );
      }

      strncpy(viapitch,"-1",30);

      while ( (atoi(viapitch) < 0 ) || ( atoi(viapitch) > 99 ))  
      {
         printf( "Enter the minimum via pitch, in mm: \n");
         gets( viapitch );
      }

      strncpy(outline[12],"Via Pitch:",30);
	  strncat(outline[12],viapitch, 120);

      strncpy(outline[15],"Pad Pitch:",40);
	  strncat(outline[15],c4pitch,120);

      strncpy(outline[16],"BGA Pitch:",40);
	  strncat(outline[16],bgapitch,120);

      // Get part sizes, validating inputs as numbers in range

      strncpy(bodyx,"-1",10);
      strncpy(bodyy,"-1",10);
      strncpy(chipx,"-1",10);
      strncpy(chipy,"-1",10);
      strncpy(stiffx,"-1",10);
      strncpy(stiffy,"-1",10);

      while ( (atoi(chipx) <  1) || ( atoi(chipx) > 299 ) )
      {
         printf( "Enter width (x) of chip, in mm: \n");
         gets( chipx );
      }
      while( (atoi(chipy) < 1 ) || (atoi(chipy) >  299) )
      {
         printf( "Enter height (y) of chip, in mm: \n");
         gets( chipy );
      }
      while ( (atoi(stiffx ) <  atoi(chipx)) || (atoi(stiffx) > 299) ) 
      {
         printf( "Enter width (x) of stiffener opening, in mm: \n");
         gets( stiffx );
      }
      while ( (atoi(stiffy) < atoi(chipy))  ||   ( atoi(stiffy) > 299 ) ) 
      {
         printf( "Enter height (y) of stiffener opening, in mm: \n");
         gets( stiffy );
      }
      while ( (atoi(bodyx) < atoi(stiffx) ) || (  atoi(bodyx) > 299 ) )  
      {
         printf( "Enter width (x) of part, in mm:  \n");
         gets( bodyx );
      }
      while ( (atoi(bodyy) < atoi( stiffy)) || ( atoi(bodyy) > 299 ))  
      {
         printf( "Enter height (y) of part, in mm: \n");
         gets( bodyy );
      }
	
      strncpy(outline[17],"Body Size:",30);
	  strncat(outline[17],bodyx,40);
	  strncat(outline[17],"X",4);
	  strncat(outline[17],bodyy,40);

      strncpy(outline[18],"Die Size:",30);
	  strncat(outline[18],chipx,40);
	  strncat(outline[18],"X",4);
	  strncat(outline[18],chipy,40);

      strncpy(outline[19],"Stiff Opening:",40);
	  strncat(outline[19],stiffx,40);
	  strncat(outline[19],"X",4);
	  strncat(outline[19],stiffy,40);

      numlines=19;
   }
   else    //WLBI only
   {
      strncpy(outline[10],"Stack-up:standard",40);
      strncpy(outline[11],"Via combination:Blind-Buried-Blind",50);
      strncpy(outline[14],"Rule Set:9602",40);
   
      // layer count
      grepret=sgrep(logname, "Layers" ,30);  // $logname > /dev/null
      if (grepret >0)
      {
         // Get layer count
         strncpy(llc,"0",10);

         while ( (atoi(llc) != 5) && ( atoi(llc) != 7 )) 
         {
            printf( "Enter 5 for 5-layer or 7 for 7-layer: \n");
            gets( llc );
         }
	  }
      else      // layer count present in file
	  {
         // get rid of = and replace with :
        // line8=$(grep "Layers" $logname)
         grepret = sgrep(logname, "Layers", 30);    // $logname|grep "=" > /dev/null
         if (grepret >0)
         {
			
            strncpy(llc,"",10);     // =${line8##*:}
		 }
         else
		 {
			 if (strstr(grep_array[0],"=") != NULL)
			 {
               split(grep_array[0],junkstr,llc,"=");  // =${line8##*=}
			 }
			 else
			 {
				 split(grep_array[0],junkstr,llc,":");
			 }

         }
      }

      strncpy(outline[8],"Layers:",30);
	  strncat(outline[8],llc,120);


      strncpy(viapitch,"-1",10);

      while ( (atoi(viapitch) < 0 )  || ( atoi(viapitch) > 99 )) 
      {
         printf( "Enter the minimum via pitch, in mm: \n");
         gets( viapitch );
      }

      strncpy(outline[12],"Via Pitch:",40);
	  strncat(outline[12],viapitch,120);

      numlines=14;
   
   }	// end of part-type dependent options


   // Determine need for bias
   strncpy(outline[13],"Design Type:finished",50);

   while ( (strcmp(artfin,"f") != 0 ) && ( strcmp(artfin,"a" ) != 0 ) )
   {
      printf( "Enter a for artwork sizes or f for finished sizes: \n");
      gets( artfin );
   }
   if ( strcmp(artfin,"a" ) == 0 )
   {
      strncpy(outline[13],"Design Type:artwork",50);
   }


   //----------------------------------------------------------------
   // Create new log file
   printf( "Writing log file...\n");
   // Print all the lines

   lognamefile=fopen(logname,"a");
   if (lognamefile==NULL)
   {
	   printf("In logupdate, unable to open for append the file = %s \n",logname);
	   exit(-1);
   }
   n=0;
   while (n <= numlines )
   {
      strncpy(toprint,outline[n],120);

      if (strlen( toprint) > 0 )        // skip null lines
      {
         fprintf(lognamefile,"%s\n", toprint); //  | tee -a $logname
      }
     n = n + 1;
   }
  fclose(lognamefile);
   
///}	// pre 0.93

// Give user the option of generating or re-generating OFFSETS

strncpy(xrunstr,"",10);

while ( (strcmp(xrunstr,"y") != 0)  &&  (strcmp( xrunstr,"n" ) != 0 ))
{
   printf( "Do you want to generate / overwrite OFFSETS? (y/n)\n ");
   gets( xrunstr );
}
if ( strcmp(xrunstr,"y")==0 )
{
   printf( "Saving offsets file as OFFSETS.OLD\n");
   cp_file( "report/OFFSETS", "report/OFFSETS.OLD");  //  2>/dev/null
   printf( "Generating new offsets file\n");
   makeoffset_call(); 
}

// Delete old reports instead of re-naming them
system( " rm -f report/basename.*");
printf( "Extracted reports deleted. Re-run review_prep to make new ones.\n");
printf( "All Done!\n");

}

int main( int argc, char **argv)
{

	if ( argc != 2)
	{
		printf("In logupdate, wrong number of arguments \n");
		printf("Usage: logupdate pn \n");
		exit(-1);
	}
	else
	{
		logupdate_call( argv[1]);
	}

}  // end main
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define WINDOWS 1
#include "utilprogs.h"

//PROGNAME=${0##*/}

// Create the used.txt file needed by 3Q99 tools
// Does not check for valid directory name - only looks
// for a pn.txt file.

// bac, 8/27/99

// Rev 0.2 
// 1/17/03  
// bac
// Modify stiffener and lid searches to recognize any tab or no tab in RDB
//   so search works with un-tabbed folder names
// Add revision number and echo it when program is run
// Handle extra line(s) at end of file

void make_usedfile_call( )
{
char RDB[300];
char REV[200];
char brd_used[100];
char stif_used[100];
char ad_used[100];
char st_used[100];
char lid_used[100];
char chkdirstr[300];
char stiffener[100];
char stifname[100];
char stifext[100];
char adhesive[100];
char assy[200];
char lid[100];
char lidname[100];
char lidext[100];
char board[100];
char stencil[100];
char thisline[300];
int nf;
int endoffile;
FILE *file1;
FILE *usedtxtfile;
int leng;
int numfields;
int keywordfound;


if (WINDOWS)
{
	strncpy(dirsep,"\\",4);
}
else
{
	strncpy(dirsep,"/",4);
}

rm_file("used.txt");


strncpy(REV,"0.2",10);

if (WINDOWS)
{
strncpy(RDB,"R:\\",10);      // rdb2/active
}
else
{
	strncpy(RDB,"rdb2",20);
}

strncat(RDB,dirsep,10);
strncat(RDB,"active",20);     //    /rdb2/active

strncpy(brd_used,"new",10);
strncpy(stif_used,"new",10);
strncpy(ad_used,"new",10);
strncpy(st_used,"new",10);
strncpy(lid_used,"new",10);

printf("Running make_usedfile version %s \n",REV);

// Parse pn.txt and search RDB for presence of files.....
//dos2ux pn.txt>tmp0

file1=fopen("pn.txt","r");
if (file1 == NULL)
{
	printf("In make_usedfile, unable to open the pn.txt file \n");
	exit(-1);
}
usedtxtfile=fopen("used.txt","w");
if (usedtxtfile==NULL)
{
	printf("In make_usedfile, unable to open the used.txt file for output \n");
	exit(-1);
}

endoffile=getline(file1,thisline);
nf=split_line(thisline);

while(endoffile==FALSE)   //  read xline
{
	// leng=${#xline} //

	leng=strlen(thisline);

   if(leng < 3)
   {
      // Handle extra line at end of file
      //print "Empty line encountered"
      continue;
   }
   else
   {
      //set $xline
      numfields=nf;
      if (numfields != 2)
      {
         printf("Too many fields in pn.txt file.\n");
         printf("Can't process %s",thisline );
         exit(-1);
	  }
      else
	  {
		  keywordfound=FALSE;
         
          if( strcmp(str_array[0],"Assembly") == 0 )
		  {
			   keywordfound=TRUE;
			   strncpy(assy,str_array[1],120);   

			   strncpy(chkdirstr,RDB,120);      // RDB/assembly/$assy
			   strncat(chkdirstr,dirsep,10);
			   strncat(chkdirstr,"assembly",20);
			   strncat(chkdirstr,dirsep,10);
			   strncat(chkdirstr,assy,120);

			   // printf("assembly checkstr = %s \n",chkdirstr);

               if ( dir_exists( chkdirstr) )   // -d $RDB/assembly/$assy 
               {
                  printf("Assembly %s already in RDB! \n",assy);
                  printf("Cannot re-use assembly numbers.\n");
			   }
	       fprintf(usedtxtfile,"Assembly\t%s\tnew \n",assy); // >used.txt;;
		  }
          if (strcmp(str_array[0],"Board") == 0 )
		  {
			keywordfound=TRUE;
			strncpy(board,str_array[1],120); //  =$2

            strncpy(chkdirstr,RDB,120);      // RDB/board/$board
			strncat(chkdirstr,dirsep,10);
			strncat(chkdirstr,"board",20);
			strncat(chkdirstr,dirsep,10);
			strncat(chkdirstr,board,120);

	       if ( dir_exists( chkdirstr) )   // -d $RDB/board/$board 
		   {
                  printf("Board %s is used!\n",board);
                  strncpy(brd_used,"used",40);
		   }
	       fprintf(usedtxtfile, "Board\t\t%s\t%s \n", board,
			                brd_used); // >> used.txt;;
		  }
          if (strcmp(str_array[0],"Stencil") == 0 ) 
		  {
		    keywordfound=TRUE;
		    strncpy(stencil,str_array[1],120);  // =$2

            strncpy(chkdirstr,RDB,120);      // RDB/stencil/$stencil
			strncat(chkdirstr,dirsep,10);
			strncat(chkdirstr,"stencil",20);
			strncat(chkdirstr,dirsep,10);
			strncat(chkdirstr,stencil,100);


	       if( dir_exists(chkdirstr) )        //  -d $RDB/stencil/$stencil 
		   {
                  printf("Stencil %s is used!\n",stencil);
                  strncpy(st_used,"used",10);
		   }
            fprintf(usedtxtfile,"Stencil  \t%s\t%s \n",stencil,
				               st_used);  // >> used.txt;;
		  }

          if (strcmp(str_array[0],"Stiffener") == 0 )
		  {
			keywordfound=TRUE;
			strncpy(stiffener,str_array[1],120);   // =$2

           // stifname=${stiffener%%-*}

			split(stiffener,stifname,stifext,"-");

            strncpy(chkdirstr,RDB,120);      // RDB/stiffener/$stifname
			strncat(chkdirstr,dirsep,10);
			strncat(chkdirstr,"stiffener",20);
			strncat(chkdirstr,dirsep,10);
			strncat(chkdirstr,stifname,100);


	       if( dir_exists( chkdirstr) )   // -d $RDB/stiffener/$stifname 
		   {
                  printf("Stiffener %s is used!\n",stiffener);
                  strncpy(stif_used,"used",10);
		   }
            fprintf(usedtxtfile,"Stiffener\t%s\t%s \n",
				       stiffener, stif_used); // >> used.txt;;
		  }
          if (strcmp(str_array[0],"Adhesive") == 0 )
		  {
			keywordfound=TRUE;
			strncpy(adhesive,str_array[1],120); // $2

            strncpy(chkdirstr,RDB,120);      // RDB/adhesive/$adhesive
			strncat(chkdirstr,dirsep,10);
			strncat(chkdirstr,"adhesive",20);
			strncat(chkdirstr,dirsep,10);
			strncat(chkdirstr,adhesive,100);


               if ( dir_exists( chkdirstr) )    // -d $RDB/adhesive/$adhesive 
               {
                  printf("Adhesive %s is used! \n",adhesive);
                  strncpy(ad_used,"used",10);
               }
            fprintf(usedtxtfile,"Adhesive\t%s\t%s \n", adhesive, ad_used); //>> used.txt;;
		  }
          if (strcmp(str_array[0],"Lid") == 0 )
		  {
			keywordfound=TRUE;
			strncpy(lid,str_array[1],120); // =$2

              // lidname=${lid%%-*}
			split(lid,lidname,lidext,"-");

            strncpy(chkdirstr,RDB,120);      // RDB/lid/$lidname
			strncat(chkdirstr,dirsep,10);
			strncat(chkdirstr,"lid",20);
			strncat(chkdirstr,dirsep,10);
			strncat(chkdirstr,lid,120);

	       //print $lidname  $lid_used
	       if ( dir_exists( chkdirstr) )     // -d $RDB/lid/$lidname 
		   {
                  printf("Lid %s is used!\n",lid);
                  strncpy(lid_used,"used",10);
		   }
	      fprintf(usedtxtfile,"Lid     \t%s\t%s \n", lid,lid_used); // >> used.txt;;
		  }
          if ( keywordfound == FALSE)
		  {
			printf( "pn.txt: Can't process %s - unrecognized keyword \n", thisline);
               exit(-1);
		  }

	  }   // numfields = 2;
   }

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

}      // endoffile

fclose(file1);
fclose(usedtxtfile);

// rm -f tmp0

printf("used.txt file created.\n");


} // end make_usedfile_call

/*
int main( int argc, char **argv)
{

if(argc != 1)
{
   printf( "make_usedfile: No command line arguments.\n");
   printf("Usage: make_usedfile \n");
   exit(-1);
}

if( ! (file_exists("pn.txt") ) )             // -a pn.txt 
{
   printf("pn.txt does not exist.\n");
   exit(-1);
}
else
{
	make_usedfile_call();
}

}  // end main

*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAXLINES 100000




int array_count;

int array_index;
int names_index;



void makearray_call( double beginx, double beginy, double spacing, int xcount, int ycount)
{

int ii,jj;
double outx;
double outy;

  ii=0;
  jj=0;

  while(ii < xcount)
  {
	  jj=0;
	  while(jj < ycount)
	  {
		  outx = beginx + spacing * (ii );
		  outy = beginy + spacing * (jj );

		  outx = 10000 * outx;
		  outy = 10000 * outy;

		  printf("X%0.0fY%0.0fD03*\n",outx, outy);

		  jj += 1;
	  }
   ii += 1;
  }
	   
    
} // end makearray_call


int main( int argc, char **argv)
{
double xxval;
double yyval;
double sspace;

	if (argc != 6)
	{
		printf("In makearray, wrong number of arguments \n");
		printf("Usage: makearray xbegin ybegin spacing xnum ynum \n");
		exit(-1);
	}
    else
	{
		xxval=atof(argv[1]);
		yyval=atof(argv[2]);
		sspace=atof(argv[3]);
		makearray_call(xxval,yyval,sspace, atoi(argv[4]), atoi(argv[5]) );
	}


}


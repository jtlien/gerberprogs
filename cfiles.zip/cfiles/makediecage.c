#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0



int makediecage_call ( double in_diex, double in_diey)
{
double diex;
double diey;
double dx;
double dy;
double odx;
double ody;
double offset;


  diex   = in_diex;
  diey   = in_diey;
  offset =  2.000;

  printf("version 13.0\n");
  printf("setwindow pcb\n");
  printf("add ufshape\n");
  printf("setwindow form.mini\n");
  printf("FORM mini class SUBSTRATE GEOMETRY\n");
  printf("FORM mini subclass CONSTRAINT_AREA\n");
  printf("FORM mini lock_mode Arc\n");
  printf("FORM mini lock_direction Off\n");
  printf("setwindow pcb\n");

  dx = diex/2.0;
  dy = diey/2.0;
  odx = dx + offset;
  ody = dy + offset;

  printf("pick %8.4f %8.4f\n",  -1*dx,  -1*ody);
  printf("pick %8.4f %8.4f\n",  +1*dx,  -1*ody);
  printf("pick %8.4f %8.4f\n", +1*odx,   -1*dy);
  printf("pick %8.4f %8.4f\n", +1*odx,   +1*dy);
  printf("pick %8.4f %8.4f\n",  +1*dx,  +1*ody);
  printf("pick %8.4f %8.4f\n",  -1*dx,  +1*ody);
  printf("pick %8.4f %8.4f\n", -1*odx,   +1*dy);
  printf("pick %8.4f %8.4f\n", -1*odx,   -1*dy);
  printf("done\n");

  printf("\ncns\n");
  printf("property edit -shape\n");
  printf("pick %8.4f %8.4f\n", -1*dx, -1*ody);
  printf("setwindow form.editprop1\n");
  printf("FORM editprop1 properties NET_PHYSICAL_TYPE\n");
  printf("FORM editprop1 properties NET_SPACING_TYPE\n");
  printf("setwindow form.editprop2\n");
  printf("FORM editprop2 net_physical_type ele_prop_value die_cage\n");
  printf("FORM editprop2 net_spacing_type ele_prop_value die_cage\n");
  printf("setwindow form.editprop1\n");
  printf("FORM editprop1 done\n");
  printf("setwindow pcb\n");
  printf("done\n");
  printf("setwindow form.cns\n");
  printf("FORM cns done\n");
  return( 0 );


}  // end makediecage

int main ( int argc, char **argv)
{
int retcode;

    if (argc != 3)
	{
		printf("In makediecage, wrong number of arguments \n");
		printf("Usage: makediecage  diex diey \n");
		printf("diex and diey are floating point \n");
		exit(-1);
	}
   else
   {
	retcode = makediecage_call( atof( argv[1]), atof( argv[2]));
	return(retcode);
   }

} // end main
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


// makehdr 
// Program to create the header information for various text files like 
// summary, history and cd.txt
//    gathers information from report/makelog ,plus date and username and
//    puts the result in proto.hdr file


// version 1.0 released to users on 1/27/03
// version 1.1 released to users on 2/24/03
//  changes LIBPATH to /swtools/remote/library/templates/common/text

int monthstr_toint( char *monthstr)
{
char tempstr[200];

cv_tolower( monthstr, tempstr);
if (strstr(tempstr,"jan") != NULL)
{
	return(1);
}
if (strstr(tempstr,"feb") != NULL)
{
	return(2);
}
if (strstr(tempstr,"mar") != NULL)
{
	return(3);
}
if (strstr(tempstr,"apr") != NULL)
{
	return(4);
}
if (strstr(tempstr,"may") != NULL)
{
	return(5);
}
if (strstr(tempstr,"jun") != NULL)
{
	return(6);
}
if (strstr(tempstr,"jul") != NULL)
{
	return(7);
}
if (strstr(tempstr,"aug") != NULL)
{
	return(8);
}
if (strstr(tempstr,"sep") != NULL)
{
	return(9);
}
if (strstr(tempstr,"oct") != NULL)
{
	return(10);
}
if (strstr(tempstr,"nov") != NULL)
{
	return(11);
}
if (strstr(tempstr,"dec") != NULL)
{
	return(12);
}
return(-1);

}  // end monthstr_toint


int makehdr_call()
{
int status;
char PARTNUMBER[200];
char description[200];
char beginstr[200];
char end_user[300];
char customer[300];
char date_str[300];
FILE *outfile;
int num;
char *username;
char userdate[300];
int monthval;
int debug;

status=0;


debug = 0;

if (  file_exists( "report/makelog") )     //-r report/makelog )
{
   rm_file("proto.hdr"); //  -rf proto.hdr
   //dos2ux report/makelog > tmpmakelog

   strncpy(PARTNUMBER,"",10);
   strncpy(description,"",10);
   strncpy(customer,"",10);

   num=sgrep("report/makelog","Part Number",100);
   split(grep_array[0],beginstr,PARTNUMBER,":");

  // PARTNUMBER=`grep "Part Number" tmpmakelog | cut -d: -f2`  // extracts part number

   if (debug) { printf("In makehdr, PARTNUMBER = %s \n",PARTNUMBER); }

   num=sgrep("report/makelog","Description",100);
   split(grep_array[0],beginstr,description,":");

   //description=`grep "Description" tmpmakelog | cut -d: -f2`

   if (debug) { printf("In makehdr, description = %s \n",description); }

   num=sgrep("report/makelog","Customer",100);
   split(grep_array[0],beginstr,customer,":");

   if (debug) { printf("In makehdr, customer = %s \n",customer); }

   //customer=`grep "Customer" tmpmakelog | cut -d: -f2`

   num=sgrep("report/makelog","End User",100);
   split(grep_array[0],beginstr,end_user,":");

    if (debug) { printf("In makehdr, end_user = %s \n",end_user); }

   //end_user=`grep "End User" tmpmakelog | cut -d: -f2`

   username=getenv("LOTUSUSERNAME");   // more like what is on Unix boxes

   if (username==NULL)
   {
	   username=getenv("USERNAME");    // gets funny 3m name
   }

   // username=$(whoami)

	get_date( date_str);

	monthval=monthstr_toint( monthstr);

	sprintf(userdate,"%02d/%s/%c%c",monthval,daystr,yearstr[2],yearstr[3]);

  // userdate=`date +%m-%d-%y`
  // sed s/xxxxx/"$PARTNUMBER"/ $LIBPATH/header.txt | sed s/uuu/"$username"/|
  // sed s/zzzzz/"$customer"/|sed s/ddddd/"$description"/ |
   // sed s/mmmmm/"$userdate"/ | sed s/wwwww/"$end_user"/ >proto.hdr
   //rm -rf tmpmakelog

   outfile=fopen("proto.hdr","w");
   if (outfile==NULL)
   {
	   printf("In makehdr, unable to open the proto.hdr for writing \n");
	   exit(-1);
   }
   fprintf(outfile,"======================================================================\n");
   fprintf(outfile,"P/N           %s\n",PARTNUMBER);
   fprintf(outfile,"Date          %s\n",userdate);
   fprintf(outfile,"Customer      %s\n",customer);
   fprintf(outfile,"Enduser       %s\n",end_user);
   fprintf(outfile,"Description   %s\n",description);
   fprintf(outfile,"Designer      %s\n",username);
   fprintf(outfile,"======================================================================\n");
   status=0;

   fclose(outfile);

}
else
{
     printf("FATAL ERROR: report/makelog does not exist or is not readable\n");
    status=1;
}
return(status);

} // end  makehdr_call

/*
int main( int argc, char **argv)
{
int retval;

	if (argc != 1)
	{
		printf("In makehdr, wrong number of arguments \n");
		printf("Usage: makehdr \n");
		exit(-1);
	}
	else
	{
		retval= makehdr_call( );
	}

 exit(retval);

}  

  */


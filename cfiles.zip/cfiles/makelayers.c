#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define MAXLINES 200

//progname=${0##*/}

// makelayers

// Creates content of layers file based on contents of control file
// Places today's date and the running user in the file

// Version 0.8
// Stop using usage log
// Update default path names
// Generalize for alternative stack-ups
//   Use contents of column 4 to determine what is artwork and what is not
//   For non-artwork, separate vias from mechs using BURIED and THRU
// Re-code, using gawk only for print formatting 
// bac 12/13/04


#include "utilprogs.h"

char progname[300];

void makelayers_call()
{
int release_stat;
char username[300];
char basename[300];
char ctlname[300];
char REV[100];
int endoffile;
int numfields;
char timestamp[300];
char thistime[300];
//char LIBPATH[300];
//char PROGPATH[300];
int ii;
char pwdstr[200];
FILE *unsortfile;
FILE *newfile;
FILE *controlfile;

char viainfo[20][MAXLINES];
char mechinfo[20][MAXLINES];
char artinfo[20][MAXLINES];
char blindinfo[20][MAXLINES];
char thisline[300];

int vialines;
int mechlines;
int artlines;
int blindlines;
int nf;
int debug;


  debug = 0;

  if (WINDOWS)
  {
	  strncpy(dirsep,"\\",10);
  }
  else
  {
	  strncpy(dirsep,"/",10);
  }


//  strncpy(progname,argv[0],100);

  strncpy(REV,"0.80",10); // REV=0.80

// ######## Change this section before release  ##################################
  release_stat=1;	// change to 1 when released !!!!!!!!!!

//  General variables
 
// Determine where you are

  //basename=${PWD##*\/}
  getwd(pwdstr);

  get_full_path_end(pwdstr,basename);

  if (debug) { printf("basename =%s \n",basename); }


//ctlname="control/$basename.ctl"
 strncpy(ctlname,"control",30);
 strncat(ctlname,dirsep,10);
 strncat(ctlname,basename,120);
 strncat(ctlname,".ctl",30);

 if (debug) { printf("ctlname = %s \n",ctlname); }

 get_whoami(username); // =$(whoami)

// Check for necessary files and exit if all are not found

   if ( ! (file_exists( ctlname) ) ) // ! -a $needfile )
   {
      printf("In makelayers, %s does not exist.\n",ctlname);
      exit(1);
   }


// First create work files 

 // rm_file("artlist"); // -f artlist
 // rm_file("mechlist"); // rm -f mechlist 
 // rm_file("vialist"); 
 // rm_file("blindvialist");


 controlfile=fopen(ctlname,"r");
 if (controlfile == NULL)
	{
	 printf("Unable to open the input file = %s \n",ctlname);
	 exit(-1);
	}

 endoffile=getline(controlfile,thisline);
 numfields=split_line(thisline);

 artlines=0;
 vialines=0;
 mechlines=0;
 blindlines=0;

 while(endoffile==FALSE) // read control_line
 {
   //set $control_line
   // numfields=split_line(thisline); // $#

	 if (debug) { printf("Control file line = %s  nf = %d \n",thisline,numfields); }

   if ( numfields == 8 )
   {
      if ( (strcmp(str_array[3],"NA") != 0 ) && 
		   (strcmp(str_array[3],"MFG") != 0 )) // $4 != "NA" && $4 != "MFG" ]]
	  {
	   
		strncpy(artinfo[artlines],thisline,200);
		if (artlines < MAXLINES)
		{
		  artlines+=1;
		}
		else
		{
			printf("Number of art lines in control file exceeds %d \n",MAXLINES);
			exit(-1);
		}
      }
      if ( strcmp(str_array[3],"NA") == 0 )  // $4 = "NA" ]]
      {
	   if ((strcmp(str_array[2],"BURIED")==0) ||
		   (strcmp(str_array[2],"THRU") == 0))  // $3 = "BURIED" || $3 = "THRU" )
	   {
		strncpy(viainfo[vialines],thisline,200);
		if (vialines < MAXLINES)
		{
		  vialines+=1;
		}
		else
		{
			printf("Number of via lines in control file exceeds %d \n",MAXLINES);
			exit(-1);
		}
	   }
	   else
	   {
        strncpy(mechinfo[mechlines],thisline,200);
		 if (mechlines < MAXLINES)
		 {
		  mechlines+=1;
		 }
		 else
		 {
			printf("Number of mech lines in control file exceeds %d \n",MAXLINES);
			exit(-1);
		 }
	   }	   
	  }  // NA
   }          // Number of fields == 8

  if (strstr("BLIND",thisline) != NULL)    // same as grep would do
  {
	  strncpy(blindinfo[blindlines],thisline,200);
	  if (blindlines < MAXLINES)
		{
		  blindlines+=1;
		}
		else
		{
			printf("Number of blind lines in control file exceeds %d \n",MAXLINES);
			exit(-1);
		}
  }
  endoffile=getline(controlfile,thisline);
  numfields=split_line(thisline); // $#
}
fclose(controlfile);

// done < $ctlname

// grep 'BLIND' $ctlname >> blindvialist 2>/dev/null
// grep_file_append("BLIND",ctlname,"blindvialist");

newfile=fopen("newfile","w");
if (newfile == NULL)
{
	printf("Unable to open the file 'newfile' for writing \n");
	exit(-1);
}

fprintf(newfile,"artwork\n"); // > newfile
//gawk '{printf ("  %s\t%s\tmmmmm\tuuu\n",$1,$7)}' artlist >> newfile

ii=0;
while(ii < artlines )
{
	nf=split_line( artinfo[ii]);
	fprintf(newfile,"  %s\t%s\tmmmmm\tuuu\n",str_array[0],str_array[6]);
    ii +=1;
}
fprintf(newfile, "\nlaser\n");
fclose(newfile);

// form list of laser layers
  rm_file("unsort");
   
//gawk '{printf ("  %span\t%s\tmmmmm\tuuu\n",$1,$7) ;
//printf ("  %sscm\t%s\tmmmmm\tuuu\n",$1,$7)}' blindvialist >> unsort
unsortfile = fopen("unsort","w");

if (unsortfile == NULL)
{
	printf("Unable to open the unsort file for writing \n");
	exit(-1);
}

ii=0;
while( ii < blindlines )
{
	nf=split_line( blindinfo[ii]);
	fprintf(unsortfile,"  %span\t%s\tmmmmm\tuuu\n",str_array[0],str_array[6]);
	fprintf(unsortfile,"  %sscm\t%s\tmmmmm\tuuu\n",str_array[0],str_array[6]); 
	ii += 1;
}
// gawk '{printf ("  %spanC\t%s\tmmmmm\tuuu\n",$1,$7) ; 
// printf ("  %spanN\t%s\tmmmmm\tuuu\n",$1,$7) ; 
// printf ("  %sscmC\t%s\tmmmmm\tuuu\n",$1,$7) ;
//  printf (""  %sscmC\t%s\tmmmmm\tuuu\n",$1,$7) ;

ii=0;
while(ii < vialines)
{
	split_line(viainfo[ii] );
	fprintf(unsortfile,"  %spanC\t%s\tmmmmm\tuuu\n",str_array[0],str_array[6]);
	fprintf(unsortfile,"  %spanN\t%s\tmmmmm\tuuu\n",str_array[0],str_array[6]); 
	fprintf(unsortfile,"  %sscmC\t%s\tmmmmm\tuuu\n",str_array[0],str_array[6]);
	fprintf(unsortfile,"  %sscmC\t%s\tmmmmm\tuuu\n",str_array[0],str_array[6]); 
	ii += 1;
}
fclose(unsortfile);

system("sort unsort  >>newfile"); //  >> newfile

newfile=fopen("newfile","a"); // open for apend

if (newfile == NULL)
{
	printf("Unable to open the file 'newfile' for apend \n");
	exit(-1);
}

// form list of mechanical layers
fprintf(newfile,"\nmechanical\n"); // >> newfile
//gawk '{printf ("  %s\t%s\tmmmmm\tuuu\n",$1,$7)}' mechlist >> newfile
ii=0;
while(ii < mechlines)
{
	 split_line(mechinfo[ii]);
	 fprintf(newfile,"  %s\t%s\tmmmmm\tuuu\n",str_array[0],str_array[6]); 
	 ii += 1;
}

fclose(newfile);

// clean up
 gettime_str(thistime);

 sprintf(timestamp,"%s-%s-%s",monthstr,daystr,yearstr); //=`date +%m-%d-%y`
//sed s/mmmmm/"$timestamp"/ newfile | sed s/uuu/"$username"/ > layers.txt
ssed("newfile","mmmmm",timestamp,"newfile1");
ssed("newfile1","uuu",username,"layers.txt");
rm_file("newfile");
rm_file("newfile1");

rm_file("unsort"); 
// rm_file("artlist");
// rm_file("mechlist");
// rm_file("vialist"); 
// rm_file("blindvialist");

printf("layers.txt file created.\n");


}  // end makelayers

int main(int argc, char **argv)
{
    strncpy(progname,argv[0],100);
	if (argc != 1)
	{
		printf("Error in makelayers, wrong number of arguments \n");
		printf("Usage: makelayers \n");
		exit(-1);
	}
	else
	{
		makelayers_call();
	}
}

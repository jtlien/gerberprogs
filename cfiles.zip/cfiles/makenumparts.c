
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define MAXCOUNT 10000

int xcnt;
int ycnt;

char xnum[MAXCOUNT][50];
char ynum[MAXCOUNT][50];

// read in the x,y file for all the parts, xcnt will be the the
//    count of uniq x locations 
//     ycnt will be the count of uniq y locations


int find_in_ynum( char *instr)
{
int ii;

ii =0;

 while(ii < ycnt)
 {
	// printf("comparing %s to %s ii=%d\n",ynum[ii],instr,ii);

	 if(strcmp(ynum[ii],instr)==0)
	 {
		 return(TRUE);
	 }
   ii += 1;
 }
 return(FALSE);
}


int find_in_xnum( char *instr)
{
int ii;

ii =0;

 while(ii < xcnt)
 {
	 //printf("comparing %s to %s ii=%d\n",xnum[ii],instr,ii);

	 if(strcmp(xnum[ii],instr)==0)
	 {
		 return(TRUE);
	 }
   ii += 1;
 }
 return(FALSE);
}

void makenumparts_call_out( char *infilestr, char *outfilestr)
{
int endoffile;
FILE *file1;
FILE *outfile;

char thisline[300];
int nf;
int xfound;
int yfound;

 file1=fopen(infilestr,"r");
 if (file1 == NULL)
 {
	 printf("In makenumparts, unable to open the input file = %s \n", infilestr);
	 exit(-1);
 }

 outfile=fopen(outfilestr,"w");
 if (outfile == NULL)
 {
	 printf("In makenumparts, unable to open the output file = %s \n", outfilestr);
	 exit(-1);
 }
 xcnt=0;
 ycnt=0;

 endoffile=getline(file1,thisline);
 nf=split_line(thisline);

 while(endoffile==FALSE)
 {
    // xnum[$1] = $1

	xfound=find_in_xnum(str_array[0]);
	if (xfound==FALSE)
	{
		if (xcnt < MAXCOUNT)
		{
			//printf("Adding to xnum, %s \n",str_array[0]);

			strncpy(xnum[xcnt],str_array[0],40);
			xcnt +=1;
		}
		else
		{
			printf("Array size for xnum exceeded \n");
		}
	}

	yfound=find_in_ynum(str_array[1]);
	if (yfound==FALSE)
	{
		if (ycnt < MAXCOUNT)
		{
			//printf("Adding to ynum, %s \n",str_array[1]);

			strncpy(ynum[ycnt],str_array[1],40);
			ycnt +=1;
		}
		else
		{
			printf("Array size for ynum exceeded \n");
		}
	}

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

 }

 fclose(file1);


  fprintf(outfile,"%d\n", xcnt );
  fprintf(outfile,"%d\n", ycnt );

  fclose(outfile);

}   // makenumparts_call_out

void makenumparts_call( char *infilestr)
{
int endoffile;
FILE *file1;
char thisline[300];
int nf;
int xfound;
int yfound;

 file1=fopen(infilestr,"r");
 if (file1 == NULL)
 {
	 printf("In makenumparts, unable to open the input file = %s \n", infilestr);
	 exit(-1);
 }

 xcnt=0;
 ycnt=0;

 endoffile=getline(file1,thisline);
 nf=split_line(thisline);
 while(endoffile==FALSE)
 {
    // xnum[$1] = $1

	xfound=find_in_xnum(str_array[0]);
	if (xfound==FALSE)
	{
		if (xcnt < MAXCOUNT)
		{
			//printf("Adding to xnum, %s \n",str_array[0]);

			strncpy(xnum[xcnt],str_array[0],40);
			xcnt +=1;
		}
		else
		{
			printf("Array size for xnum exceeded \n");
		}
	}

	yfound=find_in_ynum(str_array[1]);
	if (yfound==FALSE)
	{
		if (ycnt < MAXCOUNT)
		{
			//printf("Adding to ynum, %s \n",str_array[1]);

			strncpy(ynum[ycnt],str_array[1],40);
			ycnt +=1;
		}
		else
		{
			printf("Array size for ynum exceeded \n");
		}
	}

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

 }

 fclose(file1);


  printf("%d\n", xcnt );
  printf("%d\n", ycnt );
}

int main( int argc, char **argv)
{

	if ( argc != 2)
	{
		printf("In makenumparts, wrong number of arguments \n");
		printf("Usage: makenumparts infile \n");
		exit(-1);
	}
	else
	{
		makenumparts_call( argv[1]);
	}

}  // end main

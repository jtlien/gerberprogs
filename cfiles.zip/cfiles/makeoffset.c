
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define WINDOWS 1

#include "utilprogs.h"

// makeoffset
// takes offsets.txt file and creates a space-delimited file read-able by the 
// GWK creator script
// Output format: layername offset : description
// Input format: TAB-delimited text file from Excel
// Version 0.1
// Feb 23, 1998
// bac

// Version 0.2
// Use a variable for test data path and real data path
// bac, April 30, 1998

// Version 0.3
// Check for makestruct version in makelog. If not the latest, exit.
// Include offset tolerances in output file.
// Use new offsets for layers 3 & 4 on 7-layer inverted
// NOTE - offsets.txt file content and format changed.!!!!!!!!!!!!!!!!!!!!!!!
// bac, Sept 8, 1998

// Version 0.4
// update for makestruct0.93: support inner-layer WLBI signal offsets
// March 28, 1999

// Version 0.5
// Improve error message if offsets not created.
// Add usage log entry
// May 14, 1999

// Version 0.6
// January 28, 2003
// Change path names
// remove usage log entry
// Remove check & exit for missing APD file
// Translate makelog from DOS for use in program
// Re-map rule set names
// Use fine-line "Process" entry in makelog
// New approach: use separate files for stack-up types. One for wirebond,
//   one for inverted, and one for standard. They are set up for 7-layer
//   so lines are deleted and re-named for smaller stackups. They have
//   regular and fine-line columns. In this version, the rule set and 
//   fine-line selection is used to select columns. 
// Drop support of WLBI for now - don't know future of product
// Append success message to makelog (instead of makestruct doing so)
//   only if message not already present
// Consistent use of return value when offsets file is not created for
//   any reason: 1 is for missing file, 2 is for missing data in file,
//   3 is for WLBI

// cp the file, changing all tabs to ':'  I hate tabs...

void cp_down( char *infilestr, char *outfilestr)
{
FILE *infile;
FILE *outfile;
int eofval;
char thisline[300];
char newline[300];
int ii;

 infile=fopen(infilestr,"r");
 if (infile==NULL)
 {
	 printf("Unable to open the input file = %s \n",infilestr);
	 exit(-1);
 }

 outfile=fopen(outfilestr,"w");
 if (outfile==NULL)
 {
	 printf("Unable to open the output file = %s \n",outfilestr);
	 exit(-1);
 }

 eofval=getlinet( infile,thisline);

 for(ii=0; ii < (int) strlen(thisline); ii += 1)
 {
	 if (thisline[ii] == '\t' )
	 {
		 newline[ii] = ':';
	 }
	 else
	 {
		 newline[ii]=thisline[ii];
	 }
 }
 newline[ii] = thisline[ii];

 while(eofval==FALSE)
 {
	 fprintf(outfile,"%s",newline);
	 eofval=getlinet(infile,thisline);

     for(ii=0; ii < (int) strlen(thisline); ii += 1)
	 {
	  if (thisline[ii] == '\t' )
	  {
		 newline[ii] = ':';
	  }
	  else
	  {
		 newline[ii]=thisline[ii];
	  }
     }
	 newline[ii]=thisline[ii];
 }

fclose(infile);
fclose(outfile);
}

void grep_filter1( char *infilename, char *outfilename)
{
int endfile;
FILE *infile;
FILE *outfile;
char aline[300];
char *tptr;

 infile=fopen(infilename,"r");
 if (infile==NULL)
 {
	 printf("Unable to open the input file = %s \n",infilename);
	 exit(-1);
 }

 outfile=fopen(outfilename,"w");
 if (outfile==NULL)
 {
	 printf("Unable to open the output file = %s \n",outfilename);
	 exit(-1);
 }

 outfile=fopen(outfilename,"w");

 endfile=getline(infile,aline);

 while(endfile==FALSE)
 {
	 if (( strstr(aline,"L02") == NULL) && (strstr(aline,"L03")==NULL) &&
		( strstr(aline,"L04") == NULL) && (strstr(aline,"L05")==NULL))
	 {
       tptr = strstr( aline,"L06");
	   if (tptr != NULL)
	   {
		   tptr++;
		   tptr++;
		   *tptr='2';
	   }
       tptr = strstr( aline,"v56");
	   if (tptr != NULL)
	   {
		   tptr++;
		   *tptr='2';
		   tptr++;
		   *tptr='C';
	   }
	   tptr = strstr( aline,"v12");
	   if (tptr != NULL)
	   {
		   tptr++;
		   tptr++;
		   *tptr='C';
	   }
	 }
	 fprintf(outfile,"%s",aline);
	 endfile=getline(infile,aline);

 }

 fclose(infile);
 fclose(outfile);

}

void grep_filter2( char *infilename, char *outfilename)
{
int endfile;
FILE *infile;
FILE *outfile;
char aline[300];
char *tptr;

 infile=fopen(infilename,"r");
 if (infile==NULL)
 {
	 printf("Unable to open the input file = %s \n",infilename);
	 exit(-1);
 }

 outfile=fopen(outfilename,"w");
 if (outfile==NULL)
 {
	 printf("Unable to open the output file = %s \n",outfilename);
	 exit(-1);
 }

 outfile=fopen(outfilename,"w");

 endfile=getline(infile,aline);

 while(endfile==FALSE)
 {
	 if (( strstr(aline,"L04") == NULL) && (strstr(aline,"L03")==NULL) )
	 {
       tptr = strstr( aline,"L06");
	   if (tptr != NULL)
	   {
		   tptr++;
		   tptr++;
		   *tptr='4';
	   }
	   tptr = strstr( aline,"L05");
	   if (tptr != NULL)
	   {
		   tptr++;
		   tptr++;
		   *tptr='3';
	   }
       tptr = strstr( aline,"v56");
	   if (tptr != NULL)
	   {
		   tptr++;
		   *tptr='3';
		   tptr++;
		   *tptr='4';
		   
	   }
	  
	 }
	 fprintf(outfile,"%s",aline);
	 endfile=getline(infile,aline);

 }

 fclose(infile);
 fclose(outfile);

}


void grep_filter3( char *infilename, char *outfilename)
{
int endfile;
FILE *infile;
FILE *outfile;
char aline[300];
char *tptr;

 infile=fopen(infilename,"r");
 if (infile==NULL)
 {
	 printf("Unable to open the input file = %s \n",infilename);
	 exit(-1);
 }

 outfile=fopen(outfilename,"w");
 if (outfile==NULL)
 {
	 printf("Unable to open the output file = %s \n",outfilename);
	 exit(-1);
 }

 outfile=fopen(outfilename,"w");

 endfile=getline(infile,aline);

 while(endfile==FALSE)
 {
	 if (( strstr(aline,"L05") == NULL) && (strstr(aline,"L02")==NULL) )
	 {
       tptr = strstr( aline,"L03");
	   if (tptr != NULL)
	   {
		   tptr++;
		   tptr++;
		   *tptr='2';
	   }
	   tptr = strstr( aline,"L04");
	   if (tptr != NULL)
	   {
		   tptr++;
		   tptr++;
		   *tptr='3';
	   }
	   tptr = strstr( aline,"L06");
	   if (tptr != NULL)
	   {
		   tptr++;
		   tptr++;
		   *tptr='4';
	   }
       tptr = strstr( aline,"v56");
	   if (tptr != NULL)
	   {
		   tptr++;
		   *tptr='3';
		   tptr++;
		   *tptr='4';
		   
	   }
	  
	 }
	 fprintf(outfile,"%s",aline);
	 endfile=getline(infile,aline);

 }

 fclose(infile);
 fclose(outfile);

}

void makeoffset_call( )
{

char REV[300];
char release_stat[30];
char MSVERLINE[300];
char TEMPATH[300];
char MSVER[300];
char MSPATH[300];
char linev[300];
char username[300];
char vintage[300];
char ruleset[300];
char newruleset[300];
char layercountstr[300];
int layercount;
int alreadythere;
char junkstr[100];
char localname[300];
char parttype[300];
char stacktype[300];
char conntype[300];
char proctype[300];
char line1[300];
char line2[300];
char line3[300];
char line4[300];
char line5[300];
char line6[300];
char line7[300];
int nf;
int endoffile;
char thisline[300];
int grepret;
char pwdstr[300];
FILE *workfile;
FILE *workfileout;
FILE *makelogfile;
int linecount;

char basename[300];
char viacom[300];
char off_file[300];
char chkfilestr[300];
char IFS[300];
int debug;


 debug = 0;

strncpy(REV,"0.60",10);

strncpy(release_stat,"1",10);	// change to 1 when released !!!!!!!!!!	

// Path names for test and real

if ( atoi(release_stat) == 0 ) // just testing
{
   if (WINDOWS)
   {
    strncpy(TEMPATH,"m:/design/software/library/templates/common/offsets",120);
    strncpy(MSPATH,"m:/design/software/mmm/mkstr.rbw",120);
   }
   else
   {
    strncpy(TEMPATH,"/home/bac/library/templates/common/offsets",120);
    strncpy(MSPATH,"/home/bac/library/flowscripts/ms2.5",120);
   }
}
else  // release_stat == 1
{
   if (WINDOWS)
   { 
	 strncpy(TEMPATH,"m:/design/software/mmm/library/templates/common/offsets",120);
    strncpy(MSPATH,"m:/design/software/mmm/mkstr.rbw",120);
   }
   else
   {
	 strncpy(TEMPATH,"/swtools/remote/library/templates/common/offsets",120);
    strncpy(MSPATH,"/swtools/remote/bin/makestruct",120);
   
   }
}

// Acquire version of released makestruct
if (debug) { printf("MSPATH = %s \n",MSPATH); }

grepret=sgrep(MSPATH,"REV=",30);    // MSVERLINE=$(grep 'REV=' $MSPATH)
strncpy(MSVERLINE,"xx",10);

if (grepret == 0 )
{
	strncpy(MSVERLINE,grep_array[0],120);
	if (debug) { printf("MSVERLINE = %s \n",MSVERLINE); }
}
else
{
	printf("REV string not found in %s \n", MSPATH);
	exit(-1);
}

//MSVER=${MSVERLINE##*=}

split(MSVERLINE,junkstr,MSVER,"=");

if (debug) { printf("MSVER = %s \n",MSVER); }

//echo "makeoffset thinks the rev is "$MSVER
//localname=${PWD##*\/}.mcm
getwd(pwdstr);

get_full_path_end( pwdstr,basename);
strncpy(localname,basename,120);

// Check for existence of makelog
if( ! file_exists( "report/makelog" ) )
{
   printf("report/makelog does not exist\n");
   printf( "OFFSETS file NOT created.\n");
   exit(1);
}

// Check vintage of makelog file
//dos2ux report/makelog > templog

cp_file("report/makelog","templog");


//linev=$(grep "version" templog)
grepret=sgrep("templog","version",30);
if (grepret == 0 )
{
	strncpy(linev,grep_array[0],120);
	if (debug) { printf("linev = %s \n", linev); }
}
else
{
	printf("Unable to find the version in report/makelog \n");
	exit(-1);
}

//vintage=${linev##*:}
split(linev,junkstr,vintage,":");

if (debug) { printf("vintage = %s \n",vintage); }

//echo "makeoffset found this vintage: "$vintage
if( strcmp( vintage,MSVER ) != 0 )
{
   // print "makelog is out of date. Run logupdate to fix it."
   printf( "makelog is out of date. Consult BAC \n");
   printf("OFFSETS file NOT created.\n");
   exit(2);
}


//username=$(whoami)
get_whoami( username);

// userdate=$(date)
// basename=${PWD##*\/}
 
getwd(pwdstr);

get_full_path_end( pwdstr,basename);

//PROGNAME=${0##*/}

// Log usage
// echo $PROGNAME|awk '{printf("%-15s",$1)}'>>$USELOG
// echo "$REV     $basename     $username     $userdate" >> $USELOG

system("rm -f tmp?");

rm_file("report/OFFSETS");

rm_file("work4");

// Get part info from makelog
//dos2ux report/makelog > templog

cp_file("report/makelog","templog");

grepret=sgrep("templog","Part Type",30);
if (grepret==0)
{
	strncpy(line1,grep_array[0],120);
	split(line1,junkstr,parttype,":");
}
else
{
	printf("Unable to find the 'Part Type' string in report/makelog \n");
	exit(-1);
}

//line1=$(grep "Part Type" templog)
//parttype=${line1##*:}

grepret=sgrep("templog","Stack",30);
if (grepret==0)
{
	strncpy(line2,grep_array[0],120);
	split(line2,junkstr,stacktype,":");
}
else
{
	printf("Unable to find the 'Stack' string in report/makelog \n");
	exit(-1);
}

//line2=$(grep "Stack" templog)
//stacktype=${line2##*:}

strncpy(newruleset,"",10);

grepret=sgrep("templog","Rule",30);
if (grepret==0)
{
	strncpy(line3,grep_array[0],120);
	
	printf("line3 = %s \n",line3);
	split(line3,junkstr,newruleset,":");
}
else
{
	printf("Unable to find the 'Rule' string in report/makelog \n");
	exit(-1);
}

//line3=$(grep "Rule" templog)
//newruleset=${line3##*:}

grepret=sgrep("templog","Layers",30);
if (grepret==0)
{
	strncpy(line4,grep_array[0],120);
	split(line4,junkstr,layercountstr,":");
}
else
{
	printf("Unable to find the 'Layers' string in report/makelog \n");
	exit(-1);
}
//line4=$(grep "Layers" templog)
//layercountstr=${line4##*:}

layercount=atoi(layercountstr);

grepret=sgrep("templog","Via comb",30);
if (grepret==0)
{
	strncpy(line5,grep_array[0],120);
	split(line5,junkstr,viacom,":");
}
else
{
	printf("Unable to find the 'Via comb' string in report/makelog \n");
	exit(-1);
}

//line5=$(grep "Via comb" templog)
//viacom=${line5##*:}


// Re-map rule set names 
if ( strcmp(newruleset,"250" ) == 0 )
{
   strncpy(ruleset,"9602",10);
}
else if ( strcmp(newruleset,"225" ) == 0 )
{
   strncpy(ruleset,"9604",10);
}
else if ( strcmp(newruleset,"200" ) == 0 )
{
   strncpy(ruleset,"9702",10);
}
else if ( strcmp(newruleset,"TDF") == 0 )
{
   strncpy(ruleset,"9702",10);
}
else if ( strcmp(newruleset,"WLBI" )== 0 )
{
   strncpy(ruleset,"WLBI",10);
}
else
{
   printf( "Cannot determine rule set from makelog! \n");
   printf("Rule set from makelog = %s \n",newruleset);
   printf( "OFFSETS file NOT created.\n");
   printf( "Exiting!\n");
   exit( 2);
}

if ( strcmp(parttype,"wlbi" )== 0 )
{
   // Punt on WLBI for now
   printf("Inferno part - OFFSETS file NOT created.\n");
   exit(3);
}
else	// SCM
{
   // Get makelog data specific to scm
    grepret=sgrep("templog","Connection",30);
    if (grepret==0)
	{
	 strncpy(line6,grep_array[0],120);
	 split(line6,junkstr,conntype,":");
	}
    else
	{
	printf("Unable to find the 'Connection' string in report/makelog \n");
	exit(-1);
	}


  // line6=$(grep "Connection" templog)
   //conntype=${line6##*:}
	strncpy(proctype,"",10);
    grepret=sgrep("templog","Process",30);
    if (grepret==0)
	{
	 strncpy(line7,grep_array[0],120);
	 split(line7,junkstr,proctype,":");
	}
    else
	{
	printf("Unable to find the 'Process' string in report/makelog \n");
	}
   //line7=$(grep "Process" templog)
   //proctype=${line7##*:}

   // Determine which offset file to use
   if ( (strcmp(stacktype,"standard")==0) || (strcmp(stacktype,"microstrip")==0)
	              || (strcmp(stacktype,"stripline")==0) ) 
   {
      if ( strcmp(conntype,"wirebond" ) == 0 )
      {
         strncpy(off_file,"wb-standard.txt",40);
	  }
      else
	  {
         strncpy(off_file,"flip-standard.txt",40);
      }
   }
  else
  {
     if (strcmp(stacktype,"inverted") == 0 )
	 {
      strncpy(off_file,"flip-inverted.txt",40);
	 }
     else
	  {
      printf("Stackup type %s not recognized.\n",stacktype);
      printf("OFFSETS file NOT created.\n");
      exit(2);
	  }
  }

   // Check for existence of offset source file & create working copy

   strncpy(chkfilestr,TEMPATH,120);
   strncat(chkfilestr,"/",10);
   strncat(chkfilestr,off_file,120);

   if (debug) { printf("Getting the offsets from %s \n", chkfilestr); }

   if (debug) { printf("Layercount = %d \n",layercount); }

   if( file_exists( chkfilestr) )        //       -a $TEMPATH/$off_file 
   {
      //dos2ux $TEMPATH/$off_file > workfile
	   cp_down( chkfilestr,"workfile");
   }
   else
   {
      printf("Can't find source file %s/%s \n",TEMPATH,off_file);
      printf("OFFSETS file NOT created.\n");
      exit(1);
   }

   // Eliminate irrelevant SCM data based on via combination
   if ( strcmp(viacom,"Through-only" ) == 0 )
   {
      system("grep -v Blind workfile > work2");
   }
   else
   {
      cp_file( "workfile", "work2");
   }

   // Re-number SCM layers based on stack-up
   if (layercount == 3)
   {
      //grep -v L02 work2|grep -v L03|grep -v L04|grep -v L05|sed s/L06/L02/|sed s/v56/v2C/|
	//	  sed s/v12/v1C/ > work3
	   grep_filter1("work2","work3");

   }
   if (layercount == 5)
   {
      if ( strcmp(stacktype,"stripline" )==0)
      {
        // grep -v L03 work2|grep -v L04|sed s/L06/L04/|sed s/L05/L03/|sed s/v56/v34/ > work3
		  grep_filter2("work2","work3");
	  }
      else
	  {
         //grep -v L05 work2|grep -v L02|sed s/L03/L02/|sed s/L04/L03/|sed s/L06/L04/|
		//	 sed s/v56/v34/ > work3
		  grep_filter3("work2","work3");
      }
   }
   if (layercount ==7 )   // 7-layer
   {
      cp_file("work2", "work3");
   }
}

// Re-arrange contents of each line to place important data first, followed by descriptions
// Sequence is layer name, offset, tolerance, description

strncpy(IFS,":",30);

linecount=1;

workfile = fopen("work3","r");
if (workfile == NULL)
{
	printf("In makeoffset, unable to open the file %s for reading \n", "work3");
	exit(-1);
}

workfileout = fopen("work4","a");
if (workfileout == NULL)
{
	printf("In makeoffset, unable to open the file %s for writing \n", "work4");
	exit(-1);
}

endoffile=getline(workfile,thisline);

nf=split_line_seps(thisline,IFS);

while(endoffile==FALSE)         //read workline
{
   //set $workline
   if (linecount > 2)
   {
      // print "Rule Set is "$newruleset", Process is "$proctype
      if ( (strcmp(newruleset,"200") == 0 ) || (strcmp(proctype,"Fine-line") == 0 )) 
      {
         fprintf(workfileout,"%s %s %s : %s \n",str_array[0],str_array[4],str_array[5],str_array[1]);

			                    // $1 $5 $6" : "$2 >> work4
	          // print "Right columns used"
	  }
      else
	  {
         fprintf(workfileout,"%s %s %s : %s \n",str_array[0],str_array[2],str_array[3],str_array[1]);
		           //$1 $3 $4" : "$2 >> work4
	 // print "Left columns used"
      }
   }
  linecount = linecount + 1;

  endoffile=getline(workfile,thisline);

  if (debug) { printf("This line = %s \n",thisline);}

  nf =split_line_seps(thisline,IFS);

  if (debug) { printf(" str_array[0] = %s \n",str_array[0]); }
  if (debug) { printf(" str_array[1] = %s \n",str_array[1]); }
  if (debug) { printf(" str_array[2] = %s \n",str_array[2]); }
  if (debug) { printf(" str_array[3] = %s \n",str_array[3]); }
  if (debug) { printf(" str_array[4] = %s \n",str_array[4]); }
  if (debug) { printf(" str_array[5] = %s \n",str_array[5]); }

}

fclose(workfile);
fclose(workfileout);


// done < work3

cp_file( "work4", "report/OFFSETS");
rm_file("work4");

system("chmod 755 report/OFFSETS");

// Clean up

alreadythere = sgrep("templog","OFFSETS",30);  //  templog > /dev/null

makelogfile=fopen("report/makelog","a");

if ( alreadythere != 0)
 {
	 makelogfile=fopen("report/makelog","a");
     if (makelogfile == NULL)
	 {
	  printf("In makeoffset, unable to append to report/makelog file \n");
	 }
	 else
	 {
      fprintf(makelogfile, "OFFSETS file created.\n");   //>> report/makelog
	  fclose(makelogfile);
	 }
}
else
{
   printf( "OFFSETS file created.\n");
}

//cat report/OFFSETS
rm_file("workfile");
rm_file("work1");
rm_file("work2");
rm_file("work3");
rm_file("templog");


}  //

/*
int main( int argc, char **argv)
{

	if (argc != 1)
	{
		printf("Error in makeoffset, makeoffset takes no arguments \n");
		printf("Usage: makeoffset \n");
		exit(-1);

	}
	else
	{
		makeoffset_call();
	}

} // main

  */



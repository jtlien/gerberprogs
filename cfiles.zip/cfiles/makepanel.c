#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1


// makepanel


// Version 0.93  
// Adds checking for return value from Xvia
// Removes checking for pcm control files (Handled in Xpan)
// Mar 23, 2000   (tsa)

// Check presence of makelog


// char scan_array[1000][120];
// char grep_array[100][300];
// char time_array[10][100];

char REV[120];
char aptname[300];
char outline[300];
char ctlname[300];
char artname[300];
char *userdate;
char username[300];
char corename[300];
char basename[300];
char xname[300];
char PROGPATH[300];
char LIBPATH[300];
char PANPATH[300];
char USELOG[300];
char vianame[300];
char timestamp[300];
char testmode[300];

char ptype[300];
char parttype[300];
char checkfilestr[300];
char progname[300];
char newname[300];
// char monthstr[30];
// char daystr[30];
// char yearstr[30];

int parttypecount;
int xpancode;
int xviacode;
int stiffthere;
int stenthere;
int text_count;
int artcount;
int cutoutthere;
int i;
int release_stat;
int kk;
char tfile[300];
FILE *uselogfile;
FILE *tmpxfile;
int viafilecount;
char *pwdstr;


#include "utilprogs.c"

int main( int argc, char **argv)
{

  strncpy(progname,argv[0],120);

  if ( WINDOWS)
  {
 	strncpy(dirsep,"\\",3);
  }
  else
  {
	strncpy(dirsep,"/",3);
  }

  if ( !(file_exists("makelog" ))  )
  {
   printf("makelog file missing! Exiting...");
   exit(1);
  }

// Parse makelog 

  dos2ux( "makelog","plog");

// partline=get_part_type( "plog"); //$(grep 'Part Type' plog)
  parttypecount=sgrep("plog","Part Type",100); // get_part_type("plog"); // ${partline##*:}

  split(grep_array[0],ptype,parttype,":");   // part after : is parttype

  if ( strcmp(parttype,"wlbi") == 0  )
  {
   printf("WLBI part \n");
   // pcmname="control/pcm.man"
  }
  else
  {
   printf( "SCM part\n");
   // pcmname="control/pcm.txt" 
  }

  // basename=${PWD##*\/}
  getwd(pwdstr);
  get_full_path_end(pwdstr,basename);

//localname=${PWD##*\/}.mcm
// aptname="aper/$basename.prt"
  strncpy(aptname,"aper",20);
  strncat(aptname,dirsep,10);
  strncat(aptname,basename,120);
  strncat(aptname,".ptr",10);

// ctlname="control/$basename.ctl"
  strncpy(ctlname,"control",20);
  strncat(ctlname,dirsep,10);
  strncat(ctlname,basename,120);
  strncat(ctlname,".ctl",10);

//artname="artwork/outline.art"
  strncpy(artname,"artwork",20);
  strncat(artname,dirsep,10);
  strncat(artname,"outline.art",30);


// corename="artwork/core.art"
  //vianame="artwork/v??.art"
  strncpy(vianame,"artwork",30);
  strncat(vianame,dirsep,10);
  strncat(vianame,"v27.art",30);  // kludge


  // xname="274x/*.art"
  strncpy(xname,"274x",10);


//outline="274x/outline.art"
  strncpy(outline,"274x",20);
  strncat(outline,dirsep,10);
  strncat(outline,"outline.art",30);

  strncpy(REV,"0.93",20);

 get_whoami(username); // =$(whoami);
//userdate=$(date)

 userdate=gettime_str();


// ####### Change this section before release  ##################################
// testmode="yes"	#allows test to skip slow steps

  strncpy(testmode,"no",20);

  release_stat=1;	// change to 1 when released !!!!!!!!!!

// General variables
  if ( release_stat == 0 )
  {
   strncpy(LIBPATH,"/users/bac/library",120);

   strncpy(PROGPATH,"/users/bac/library/flowscripts",120);
   strncpy(PANPATH,"/usr/local/bin/PANEL/SCRIPTS",120);
   strncpy(USELOG,"/users/bac/library/usage_log",120);
  }
  else
  {
   strncpy(LIBPATH,"/usr/local/library",120);
   strncpy(PROGPATH,"/usr/local/bin",120);

   strncpy(PANPATH,"/usr/local/bin/PANEL/SCRIPTS",120);
   strncpy(USELOG,"/usr/local/bin/scripts/usage/makepanlog",120);
  }


// Check for necessary files and exit if all are not found
//for needfile in $aptname $ctlname $artname $corename $vianame $xname $outline
//{
   if ( ! (file_exists( aptname) ) )
   {
      printf("In makepanel, file %s does not exist.\n",aptname);
      exit(1);
   }

  if ( ! (file_exists( ctlname) ) )
   {
      printf("In makepanel, file %s does not exist.\n",ctlname);
      exit(1);
   }

  if ( ! (file_exists( artname) ) )
   {
      printf("In makepanel, file %s does not exist.\n",artname);
      exit(1);
   }

  if ( ! (file_exists( corename) ) )
   {
      printf("In makepanel, file %s does not exist.\n",corename);
      exit(1);
   }
   artcount= scandir_matchext(vianame,0,".art");

   i=0;
   viafilecount=0;
   while( i < artcount)
   {
	   if (( scan_array[i][0]=='v') || ( scan_array[i][0] == 'V'))
	   {
		   viafilecount += 1;
	   }
   }
   if ( viafilecount == 0 )
   {
      printf("In makepanel, file %s%sv??.art does not exist.\n",vianame,dirsep);
      exit(1);
   }

  artcount= scandir_matchext(xname,0,".art");
  
  if ( artcount == 0  )
   {
      printf("In makepanel, file %s%s*.art does not exist.\n",xname,dirsep);
      exit(1);
   }

  if ( ! (file_exists( outline) ) )
   {
      printf("In makepanel, file %s does not exist.\n",outline);
      exit(1);
   }

fprintf(uselogfile,"%s \n",progname);
fprintf(uselogfile,"%s      %s      %s      %s\n",
		 REV,basename ,username,userdate); //  >> $USELOG

printf("Running makepanel version %s INTERIM \n",REV);


//  Check for presence of components specified in control file
stiffthere=sgrep(ctlname, "stiff.art", 100); // ' $ctlname > /dev/null
// stiffthere=$?
if (stiffthere == 0) 
{
   strncpy(checkfilestr,"artwork",30);
   strncat(checkfilestr,dirsep,5);
   strncat(checkfilestr,"stiff.art",30);

   if ( ! (file_exists(checkfilestr) ) )
   {
      printf( "artwork%sstiff.art file missing. Xpan will fail!\n",dirsep);
      exit(1);
   }
   strncpy(checkfilestr,"274x",30);
   strncat(checkfilestr,dirsep,5);
   strncat(checkfilestr,"stiff.art",30);

   if ( ! (file_exists(checkfilestr)) )     // -a 274x/stiff.art )
   {
      printf("274x%sstiff.art file missing. Xpan will fail!\n",dirsep); // 
      exit(1);
   }
}

stenthere=sgrep(ctlname, "stencil.art", 100 ); //$ctlname > /dev/null
// stenthere=$?
if (stenthere == 0)
{
   strncpy(checkfilestr,"274x",30);
   strncat(checkfilestr,dirsep,10);
   strncat(checkfilestr,"stencil.art",20);

   if ( ! (file_exists(checkfilestr) ) )
   {
      printf("274x%sstencil.art file missing. Xpan will fail!\n",dirsep);
      exit(1);
   }
}

cutoutthere=sgrep(ctlname, "cutout.art", 100); // $ctlname > /dev/null
// cutoutthere=$?

if (cutoutthere == 0)
{
   strncpy(checkfilestr,"artwork",30);
   strncat(checkfilestr,dirsep,5);
   strncat(checkfilestr,"cutout.art",20);

   if ( ! (file_exists( checkfilestr )))
   {
      printf("artwork%scutout.art file missing. Xpan will fail!\n",dirsep);
      exit(1);
   }
}



  if ( strcmp(testmode,"yes") != 0 )
  {
   printf("***** Running Xpan.\n");

   //$PANPATH/Xpan $basename > Xpanlog
   xpancode=xpan_call( basename,"Xpanlog");
  // xpancode=$?
   if (xpancode != 0)
   {
      printf("ERROR! xpan failure=%d. Look at Xpanlog. Exiting!\n",xpancode);
      exit(-1);
   }

   printf("***** Xpan complete.\n" );
   printf("Starting Xvia.\n");
   //$PANPATH/Xvia $basename > Xvialog
   xviacode=xvia_call(basename,"Xvialog");

   //xviacode=$?
   if (xviacode != 0)
   {
      printf( "ERROR! Xvia failure. Look at Xvialog. Exiting!\n");
      exit(-1);
   }

   printf("***** xvia complete.\n");
   
   printf("Starting Xmech.\n");
  // $PANPATH/Xmech $basename > Xmechlog
// execl("xmech",basname,"xmechlog");

   xmech_call(basename,"xmechlog");

   printf("***** xmech complete.\n");
   printf("Modifying text files...\n");
  }
 else
 {
   printf("Skipping actual run of X tools to save time.....\n");
 }


//$PROGPATH/makelayers
  makelayers();

// Change text file names to all lowercase
//textlist=$(ls *.txt 2>/dev/null)
  text_count=scandir_matchext(".",0,".txt");

  i=0;
  while(i < text_count) // tfile in $textlist
  {
   if ( file_exists( scan_array[i]) ) // -f $tfile )
   {
	  strncpy(tfile,scan_array[i],120);

      strncpy(newname,tfile,120);

      //typeset -l newname
	  for(kk=0;kk< (signed int) strlen(newname);kk+=1)
	  {
		  newname[kk]=tolower(newname[kk]);
	  }
      if ( strcmp(tfile,newname )!=0)
      {
         mv_a_file(tfile,newname);
      }
   }
  }

// Append history file 
  if ( file_exists("history.txt") )     // -a history.txt )
  {
   // dos2ux("history.txt","tmp0"); |sed s/ppp/"$USER"/ >tmp0

	ssed("history.txt","ppp","$USER","tmp0");  //sed equivalent

	strncpy(monthstr,time_array[1],30);
    strncpy(daystr,time_array[2],30);
	strncpy(yearstr,time_array[4],30);

   sprintf(timestamp,"date %s/%s/%s,",monthstr,daystr,yearstr);

   tmpxfile=fopen("tmp0","a");

   fprintf(tmpxfile,"%s   0            %s n/a   Panelized \n",timestamp,
                                         basename);          // >>tmp0
   fclose(tmpxfile);

   mv_a_file("tmp0", "history.txt");
  }

// Translate text files
//textlist=$(ls *.txt 2>/dev/null)
  text_count=scandir_matchext(".",0,".txt");
  i=0;

  while(i < text_count) // tfile in $textlist
  {
   if ( file_exists(scan_array[i]) ) // -f $tfile )
   {
      ux2dos(scan_array[i],"tmp0"); // $tfile > tmp0
      //mv tmp0 $tfile
	  copy_one_file("tmp0",scan_array[i]);
   }
  }

rm_file("plog");

printf("***** Finished!\n");
//echo "The text files are updated and ready to print."

}

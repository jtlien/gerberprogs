#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAXLINES 100000




int array_count;

int array_index;
int names_index;



void makesquare_call( double centerx, double centery, double sidewidth, int dcode)
{

double topleftx;
double toplefty;
double bottomleftx;
double bottomlefty;
double toprightx;
double toprighty;
double bottomrightx;
double bottomrighty;


  centerx = 10000 * centerx;
  centery = 10000 * centery;

  topleftx= centerx - ( 5000 * sidewidth);
  toprightx = centerx + ( 5000 * sidewidth);
  bottomleftx = topleftx;
  bottomrightx = toprightx;

  toplefty = centery + ( 5000 * sidewidth);
  bottomlefty = centery - (5000 * sidewidth);
  toprighty = toplefty;
  bottomrighty = bottomlefty;

  printf("G54D%d*\n",dcode);

  printf("X%0.0fY%0.0fD02*\n",topleftx,toplefty);
  printf("X%0.0fY%0.0fD01*\n",toprightx, toprighty);
	   
  printf("X%0.0fY%0.0fD01*\n",bottomrightx,bottomrighty);
  printf("X%0.0fY%0.0fD01*\n",bottomleftx, bottomlefty);

  printf("X%0.0fY%0.0fD01*\n",topleftx,toprighty);
 
} // end makearray_call


int main( int argc, char **argv)
{
double xxval;
double yyval;
double sidewidth;


	if (argc != 5)
	{
		printf("In makesquare, wrong number of arguments \n");
		printf("Usage: number  xcenter ycenter sidewidth gcode \n");
		exit(-1);
	}
    else
	{
		xxval=atof(argv[1]);
		yyval=atof(argv[2]);
		sidewidth=atof(argv[3]);
		makesquare_call(xxval,yyval,sidewidth, atoi(argv[4]) );
	}


}


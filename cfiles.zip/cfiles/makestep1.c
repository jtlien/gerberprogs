#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


char str_array[120][120];
char a1array[10000][120];
int a1array_index;

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline
int mindiff( int *myarray, int cnt )
{
int i;
int value;

   value = myarray[0];
   for( i = 1 ; i < cnt ; i+= 1)
   {
      if( myarray[i] < value )
	  {
         value = myarray[i];
      }
   }
   return( value);

}

// may have to be redone using hashes
//
void add_to_a1array( char *instr)
{
 if (a1array_index < 10000)
	{
    strncpy(a1array[a1array_index],instr,120);
	a1array_index += 1;

	}

} // add_to_a1array 

int is_in_a1array( char *instr)
{
int ii;
int is_found;

  ii = 0;
  is_found=FALSE;

  while( ( ii < a1array_index) && ( is_found == FALSE))
  {
	  if (strcmp( a1array[ii],instr) == 0 )
	  {
		  is_found=TRUE;
		  return(TRUE);
	  }
	ii += 1;
  }

  return(is_found);

}

void makestep1_call( char *multstr, char *file1str, char *file2str)
{

FILE *file1;
FILE *file2;
FILE *singfile;
FILE *stepfile;
FILE *numpartfile;

char addstr[200];
double indist;
double inmyx;
double inmyy;
double inXstep;
double inYstep;
double myxsize;
double myysize;
double inxsize;
double inysize;
double MMtoIN;
double mymult;
int mult;
int multiplier;
int i;
int xmin;
int xcnt;
int ycnt;
int xbase;
int ybase;
int xdiff[100000];
int ydiff[100000];
int tmparray[100000];
double dist;
double myx;
double myy;
double xstep;
double ystep;
int xsize;
int ysize;
int nf;
char thisline[200];
char myindex[200];

int xnum[10000];
int ynum[10000];
int xnumcnt;
int ynumcnt;
int tmpcnt;
int tmp;
int endoffile;
int FIRST;

   FIRST = 0;
// mult is a passed in variable if not provide then default of 4 

   mult = atoi(multstr);

   if ( mult  >  0 )
   {
     multiplier = mult;
   }
   else
   {
     multiplier = 4;
   }
 
   MMtoIN  = 25.4;

  file1=fopen(file1str,"r");

  if (file1 == NULL)
  {
	  printf("Unable to open the input file = %s \n",file1str);
  }

 file2=fopen(file2str,"r");

  if (file2 == NULL)
  {
	  printf("Unable to open the input file = %s \n",file2str);
  }

   mymult = pow(10,multiplier);
    
   //getline < file1

  endoffile=getline(file1,thisline);   // read from the partsize file 
                                       // to get size info
  nf=split_line(thisline);

   xsize = atoi(str_array[0]); //$1
   ysize = atoi(str_array[1]); // $2

  fclose(file1);

  endoffile=getline(file2,thisline);
  nf=split_line(thisline);

  xnumcnt= 0;
  ynumcnt= 0;

  while(endoffile == FALSE)
  {
   if ( xnumcnt < 10000)
   { 
	   xnum[xnumcnt] = atoi(str_array[0]); //$1
	   xnumcnt += 1;
   }
   if (ynumcnt < 10000 )
   {
     ynum[ynumcnt] = atoi(str_array[1]); // $2
	 ynumcnt += 1;
   }

   strncpy(addstr,str_array[0],60);
   strncat(addstr,",",4);
   strncat(addstr,str_array[1],60);

   add_to_a1array( addstr); //        [$1,$2] = 1;

   if ( FIRST == 0)
   {
       xbase = atoi(str_array[0]); // $1
       ybase = atoi(str_array[1]); // $2
       FIRST = 1;
   }
   endoffile=getline(file2,thisline);
   nf=split_line(thisline);
  }

  fclose(file2);

   xcnt = 0;
   xmin =xbase;
   i=0;
   while (i < xnumcnt)
   {
     if( xnum[i] != xbase)
	 {
        xdiff[xcnt] = abs(xnum[i] - xbase);
     }
     else
	 {
        xdiff[xcnt] = 1000000000;
     }
     if( xnum[i] < xmin)
	 {
        xmin =  xnum[i];    // xmin is x coord. of part at A1
     }
     xcnt++;
	 i++;
   }
   if( xcnt == 1 )
   {
      xstep = 0;
   }
   else 
   {
      xstep = mindiff(xdiff,xcnt)/mymult;
   }

   ycnt = 0;
   i=0;
   while(i < ynumcnt)
   {
     if( ynum[i] != ybase)
	 {
        ydiff[ycnt] = abs(ynum[i] - ybase);
     }
     else 
	 {
        ydiff[ycnt] = 1000000000;
     }
     ycnt++;
	 i++;
   }

   if( ycnt == 1 )
   {
      ystep = 0;
   }
   else
   {
      ystep = mindiff(ydiff,ycnt)/mymult;
   }

// 
//  The following two for loops find the Y coord of part at A1
//

   tmpcnt = 0;
   i=0;
   while( i < ynumcnt )
   {
     // myindex = (xmin SUBSEP ynum[i])
	  sprintf(myindex,"%d,%d",xmin,ynum[i]);
      printf("%s\n", myindex);
      if(is_in_a1array(myindex) )
	  {
	   tmparray[tmpcnt] = ynum[i];
	   tmpcnt++;
      }
	 i++;
   }

   tmp = tmparray[0];
   for( i = 1; i < tmpcnt; i++ )
   {
      printf( "tmp %d tmparray %d \n",tmp,tmparray[i]);
      if( tmparray[i]   > tmp )
	  {
	   tmp =  tmparray[i];
      }
  }
   
   myx = xmin / mymult;
   myy = tmp  / mymult;
   stepfile=fopen("step.txt","w");
   numpartfile=fopen("numparts","w");

   fprintf(stepfile,"Xstep = %.5f Ystep = %.5f\nXnum  = %-8s Ynum  = %-5s\n",
	    xstep,ystep,xcnt,ycnt);  // > "step.txt"
   fprintf(stepfile,"Lower Left\n X = %.5f  Y = %.5f\n",xbase/mymult,ybase/mymult); //  > "step.txt"
   fprintf(numpartfile,"%s\n%s\n",xcnt,ycnt); // > "numparts"
   dist = fabs( -177.8 * mymult - xmin)/mymult;
   indist = dist/MMtoIN;
   inmyx  = myx/MMtoIN;
   inmyy  = myy/MMtoIN;
   inXstep = xstep/MMtoIN;
   inYstep = ystep/MMtoIN;
   myxsize = xsize/mymult;
   myysize = ysize/mymult;
   inxsize = myxsize/MMtoIN;
   inysize = myysize/MMtoIN;
   singfile=fopen("singulate.txt","w");

   fprintf(singfile,"Partsize (X x Y) %9.5f x %.5f (%.5f x %7.5f)\n",myxsize,myysize,inxsize,inysize); //>"singulate.txt"
   fprintf(singfile,"Arraysize: Xnum = %s  Ynum = %s\n",xcnt,ycnt); //>"singulate.txt"
   fprintf(singfile,"A1  X = %10.5f (%.5f)     Y = %9.5f (%.5f)\n",myx,inmyx,myy,inmyy); //>"singulate.txt"
   fprintf(singfile,"Xstep = %10.5f (%.5f)  Ystep = %9.5f (%.5f)\n",xstep,inXstep,ystep,inYstep); //>"singulate.txt"
   fprintf(singfile,"X Dist. to target %9.5f (%.5f)",dist,indist); // > "singulate.txt"

    fclose(singfile);
	fclose(stepfile);
	fclose(numpartfile);

}

int main( int argc, char **argv)
{
	makestep1_call( argv[1],argv[2],argv[3]);
}


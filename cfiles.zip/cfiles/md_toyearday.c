#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAXLINES 100000


void monthday_toyearday( char *month, char *day, char *dayofyear)
{
int addval;
int dayval;
int ii;

    dayval=atoi(day);

	for(ii=0;ii< strlen(month); ii += 1)
	{
		month[ii]=tolower(month[ii]);
	}

	if (strstr(month,"jan")!=NULL)
	{
		addval=0;
	}
    if (strstr(month,"feb")!=NULL)
	{
		addval=29;
	}
    if (strstr(month,"mar")!=NULL)
	{
		addval=59;
	}
    if (strstr(month,"apr")!=NULL)
	{
		addval=90;
	}
	if (strstr(month,"may")!=NULL)
	{
		addval=120;
	}
    if (strstr(month,"jun")!=NULL)
	{
		addval=151;
	}
    if (strstr(month,"jul")!=NULL)
	{
		addval=181;
	}
    if (strstr(month,"aug")!=NULL)
	{
		addval=212;
	}

   if (strstr(month,"sep")!=NULL)
	{
		addval=242;
	}
    if (strstr(month,"oct")!=NULL)
	{
		addval=273;
	}
    if (strstr(month,"nov")!=NULL)
	{
		addval=303;
	}
    if (strstr(month,"dec")!=NULL)
	{
		addval=333;
	}

  return(addval+dayval);
}


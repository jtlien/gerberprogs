#! /usr/local/bin/gawk -f

double coord_x;
double coord_y;

int split_line_seps( char *tline, char *file_sep)
{
int ii;
char tstr[200];
char *token;

 ii = 0;

 strncpy( tstr, tline,200);

 token = strtok( tstr,file_sep);

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL,file_sep);

	}

 // for (jj=0; jj <ii ; jj += 1)
 //{
 //	 printf("str_array[%d] = %s \n",jj,str_array[jj]);
 //}

 return(ii);

} // end split_line_seps

int main( int argc, char **argv)
{
   FS = "!"
   endoffile = getline(file1,thisline);

   endoffile = getline(file1,thisline);

   cnt = 3;
   while(getline < file1)
   {
     pads1_x[$5,$6] = $7;
     pads1_y[$5,$6] = $8
     pads2_x[$7,$8] = $5
     pads2_y[$7,$8] = $6
     flag[$5,$6] = cnt;
     flag[$7,$8] = cnt;
     cnt++
   }
   fprintf(stderr," cnt = %d", cnt - 3); 
   FS = " "
   endoffile = getline(file2, thisline);
   printf("%s",thisline);

  while(endoffile == FALSE)
  {
   if( strcmp(str_array[3],"Z") == 0 )
   {
     myindex = ( $1 SUBSEP $2)
     if( myindex in pads1_x )
	 {
        coord_x = pads1_x[myindex];
        coord_y = pads1_y[myindex];
        flag[myindex] = -999
        layer = "U"
     }
     else if ( myindex in pads2_x )
	 {
        coord_x = pads2_x[myindex];
        coord_y = pads2_y[myindex]; 
        flag[myindex] = -999;
        strncpy(layer,"U",4);
     }
     else
	 {
        coord_x = -99999;
        coord_y = 99999;
        strncpy(layer,"ZZ",4);
     }
     printf("%10.4f %10.4f %5d",coord_x,coord_y,$3);
     printf(" %3s %5s %5s",layer,$5,$6);
     printf("%20s %10.4f\n",$7,$8)
   }
   else
   {
     printf("%s",thisline);
   }

   endoffile = getline(file2, thisline);
   number_fields = split_line_fs(thisline,file_sep);

  }

   for( i in flag )
   {
     if(flag[i] != -999){
       bad[flag[i]]+= 1;
     }
   } 
   for( i in bad)
   {
     if (bad[i] > 1){
       fprintf(stderr, "ERROR  LINE #%d",i); 
     }
   }

}  // end main

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <process.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

struct pad1stuff
{
	char findstr[100];
	int linenumber;
    char xstr[40];
	char ystr[40];
}  pads1_array[5000];

int array1cnt;

struct pad2stuff
{
	char findstr[100];
	int linenumber;
    char xstr[40];
	char ystr[40];
}  pads2_array[5000];

int array2cnt;

struct viastuff
{
	char findstr[100];
	int linenumber;
    char netname[120];
}  via_array[5000];

int arrayvcnt;

// merge3.awk released to users on 10/24/02
// now handles data from micron designs.
// If part is um design the script splits all input numbers at the decimal point.
// It does this before any numbers are compared

void add_to_pads1( char *firststr, char *secondstr, char *xstr, char *ystr, int linenum)
{
	if ( array1cnt < 5000 )
	{
		strncpy(pads1_array[array1cnt].findstr,firststr,80);
		strncat(pads1_array[array1cnt].findstr,":",10);
		strncat(pads1_array[array1cnt].findstr,secondstr,80);
		strncpy(pads1_array[array1cnt].xstr,xstr,40);
		strncpy(pads1_array[array1cnt].ystr,ystr,40);
	    array1cnt += 1;
	}
    else
	{
		printf("In add_to_pads1, array size exceeded \n");
	}

} 

void add_to_pads2( char *firststr, char *secondstr, char *xstr, char *ystr, int linenum)
{
	if ( array2cnt < 5000 )
	{
		strncpy(pads2_array[array2cnt].findstr,firststr,80);
		strncat(pads2_array[array2cnt].findstr,":",10);
		strncat(pads2_array[array2cnt].findstr,secondstr,80);
		strncpy(pads2_array[array2cnt].xstr,xstr,40);
		strncpy(pads2_array[array2cnt].ystr,ystr,40);
	    array2cnt += 1;
	}
    else
	{
		printf("In add_to_pads2, array size exceeded \n");
	}

} 

void add_to_via_coords( char *firststr, char *secondstr, char *netname)
{
	if ( arrayvcnt < 5000 )
	{
		strncpy(via_array[arrayvcnt].findstr,firststr,80);
		strncat(via_array[arrayvcnt].findstr,":",10);
		strncat(via_array[arrayvcnt].findstr,secondstr,80);
		strncpy(via_array[arrayvcnt].netname,netname,80);
	    arrayvcnt += 1;
	}
    else
	{
		printf("In add_to_via_coords, array size exceeded \n");
	}

} 

int via_array_index( char *infindstr )
{
int ii;
 ii = 0;
 while(( ii < 5000 ) && ( ii < arrayvcnt) )
 {
	 if (strcmp(via_array[ii].findstr,infindstr) == 0 )
	 {
		 return(ii);
	 }
	 ii += 1;
 }
 return(-1);
}


int pads2_index( char *infindstr )
{
int ii;
 ii = 0;
 while(( ii < 5000 ) && ( ii < array2cnt) )
 {
	 if (strcmp(pads2_array[ii].findstr,infindstr) == 0 )
	 {
		 return(ii);
	 }
	 ii += 1;
 }
 return(-1);
}

int pads1_index( char *infindstr )
{
int ii;
 ii = 0;
 while(( ii < 5000 ) && ( ii < array1cnt) )
 {
	 if (strcmp(pads1_array[ii].findstr,infindstr) == 0 )
	 {
		 return(ii);
	 }
	 ii += 1;
 }
 return(-1);
}

int found_in_via_coords( char *infindstr )
{
int ii;
 ii = 0;
 while(( ii < 5000 ) && ( ii < arrayvcnt) )
 {
	 if (strcmp(via_array[ii].findstr,infindstr) == 0 )
	 {
		 return(TRUE);
	 }
	 ii += 1;
 }
 return(FALSE);
}


int found_in_pads2( char *infindstr )
{
int ii;
 ii = 0;
 while(( ii < 5000 ) && ( ii < array2cnt) )
 {
	 if (strcmp(pads2_array[ii].findstr,infindstr) == 0 )
	 {
		 return(TRUE);
	 }
	 ii += 1;
 }
 return(FALSE);
}

int found_in_pads1( char *infindstr )
{
int ii;
 ii = 0;
 while(( ii < 5000 ) && ( ii < array1cnt) )
 {
	 if (strcmp(pads1_array[ii].findstr,infindstr) == 0 )
	 {
		 return(TRUE);
	 }
	 ii += 1;
 }
 return(FALSE);
}


int merge3_call_out( int unitval, char *infile1str, char *infile2str, char *infile3str,
					char *outfilestr)
{
int cnt;
int result;
char tmp1[10][200];
char tmp2[10][200];
char tmp3[10][200];

char tmp5[10][200];
char tmp6[10][200];
char tmp7[10][200];
char tmp8[10][200];
char layer[40];
char thisline[300];
char p1x[200];
char p1y[200];
char p2x[200];
char p2y[200];
char coord_x1[200];
char coord_y1[200];
char coord_x[200];
char coord_y[200];
char myindex[300];
char c_index[300];
int i;
int array1index;
int array2index;
int arrayvindex;

int bad[1000];
int badcnt;

int endoffile;
int nf;
int units;

FILE *file1,*file2,*file3;
FILE *outfile;

   //FS = "!"

   badcnt=0;
   array1cnt=0;
   array2cnt=0;
   arrayvcnt=0;

   units = unitval;

   file1 = fopen(infile1str,"r");
   if (file1 == NULL)
   {
	   printf("In merge3_call, unable to open the input file = %s \n",infile1str);
	   exit(-1);

   }

   outfile = fopen(outfilestr,"w");
   if (outfile == NULL)
   {
	   printf("In merge3_call, unable to open the output file = %s \n",outfilestr);
	   exit(-1);

   }
  // getline < file1
   endoffile=getline(file1,thisline);

   // getline < file1
   endoffile=getline(file1,thisline);

   cnt = 3;
   // file1 (wbdata.txt)is the extracted data for the clines that go 
   // from the die pads to the bond fingers 

   endoffile=getline(file1,thisline);
   nf=split_line_seps(thisline,"!");

   while(endoffile==FALSE)
   {
     strncpy(p1x,str_array[6],120); //  = $7
     strncpy(p1y,str_array[7],120); //  = $8
     strncpy(p2x,str_array[4],120); //  = $5
     strncpy(p2y,str_array[5],120);  // = $6

     // adjust the input coordinate if processing um designs

     if(units == 1)
	 {
        split(str_array[4],tmp5[0],tmp5[1],".");
        strncpy(str_array[4],tmp5[0],120); // $5 = tmp5[1] 
        split(str_array[5],tmp6[0],tmp6[1],".");
        strncpy(str_array[5],tmp6[0],120);  // $6 = tmp6[1] 
        split(str_array[6],tmp7[0],tmp7[1],".");
        strncpy(str_array[6],tmp7[0],120);  // $7 = tmp7[1] 
        split(str_array[7],tmp8[0],tmp8[1],".");
        strncpy(str_array[7],tmp8[0],120);   // $8 = tmp8[1] 
     }

     //pads1_x[$5,$6] = p1x
     //pads1_y[$5,$6] = p1y
     //pads2_x[$7,$8] = p2x
     //pads2_y[$7,$8] = p2y
     //flag[$5,$6] = cnt
     //flag[$7,$8] = cnt

	   add_to_pads1(str_array[4],str_array[5],p1x,p1y,cnt);
	   add_to_pads2(str_array[6],str_array[7],p2x,p2y,cnt);

     cnt++;

	 endoffile=getline(file1,thisline);
	 nf=split_line_seps(thisline,"!");
   }
   fclose(file1);

   if (cnt == 3)
   {
      fprintf(stderr,"FATAL ERROR(5): Unable to extract cline information from design file\n"); // | "cat 1>&2"
      result = 5;
      return(result);
   }
      
   fprintf(stderr,"bondfinger count = %d \n", cnt - 3 );   // | "cat 1>&2"

 //  FS = " "

   file2=fopen(infile2str,"r");
   if (file2==NULL)
   {
	   printf("In merge3_call, unable to open the input file = %s \n",infile2str);
	   exit(-1);
   }

   endoffile=getline(file2,thisline);
   nf=split_line(thisline);

   //file2 (vias_info2.txt) is the extract via data
   while( endoffile==FALSE)
   {
     if(units == 1)
	 {
        split(str_array[1],tmp2[0],tmp2[1],".");
        strncpy(str_array[1],tmp2[0],120);        // $2 = tmp2[1] 
        split(str_array[2],tmp3[0],tmp3[1],".");
        strncpy(str_array[2],tmp3[0],120);        // $3 = tmp3[1] 
     }
     //via_coords[$2,$3] = $1
	 add_to_via_coords(str_array[1],str_array[2],str_array[0]);


	 endoffile=getline(file2,thisline);
	 nf=split_line(thisline);
   }

   fclose(file2);

   file3=fopen(infile3str,"r");
   if (file3 == NULL)
   {
	   printf("In merge3_call, unable to open the input file = %s \n",infile3str);
	   exit(-1);
   }

   endoffile=getline(file3,thisline);

   fprintf(outfile,"%s",thisline); // $0
   result = 0; 

   endoffile=getline(file3,thisline);
   nf=split_line(thisline);

  while(endoffile==FALSE)
  {
   if( strcmp(str_array[3],"Z") == 0 )             //$4 == "Z")
   {
     if(units == 1 )
	 {
        split(str_array[0],tmp1[0],tmp1[1],".");
        strncpy(str_array[0],tmp1[0],120);  // $1 = tmp1[1] 
        split(str_array[1],tmp2[0],tmp2[1],".");
        strncpy(str_array[1],tmp2[0],120);  //$2 = tmp2[1] 
     }
     // myindex = ( $1 SUBSEP $2)
	 strncpy(myindex,str_array[0],120);
	 strncat(myindex,":",10);
	 strncat(myindex,str_array[1],120);

     if( found_in_pads1(myindex) )
	 {
		array1index= pads1_index(myindex);

        strncpy(coord_x,pads1_array[array1index].xstr,40);
        strncpy(coord_y,pads1_array[array1index].ystr,40);

        if(units == 1 )
		{
           split(coord_x,tmp1[0],tmp1[1],".");
           strncpy(coord_x1,tmp1[0],120);

           split(coord_y,tmp2[0],tmp2[1],".");
           strncpy(coord_y1,tmp2[0],120);
        }
        else
		{
           strncpy(coord_x1,coord_x,40);
           strncpy(coord_y1,coord_y,40); 
        } 
       // c_index = ( coord_x1 SUBSEP coord_y1)

		strncpy(c_index,coord_x1,40);
		strncat(c_index,":",10);
		strncat(c_index,coord_y1,40);

        if( !(found_in_via_coords(c_index)))
		{
          fprintf(stderr, "FATAL ERROR(1): end of cline doesn't match via location for"); // | "cat 1>&2"
          fprintf(stderr, "\t %s\n",thisline); //  $0  | "cat 1>&2"
          result = 1;
        }
        else  // found
		{
		 arrayvindex= via_array_index(c_index);

		 if ( strcmp(via_array[arrayvindex].netname,str_array[6]) != 0)
		 {
          fprintf(stderr,"FATAL ERROR(2): net name %s doesn't match net name for",
			      via_array[arrayvindex].netname ); // | "cat 1>&2"
          fprintf(stderr, "\t %s\n",thisline);   //  $0  | "cat 1>&2"
          result = 2;
         }   
         else
		 {   
           // flag[myindex] = -999
		    pads1_array[array1index].linenumber=-999;

           // layer = "U"
		   strncpy(layer,"U",10);

         }
		}
     }
     else if ( found_in_pads2(myindex) )
	 {
		array2index=pads2_index(myindex);

       // coord_x = pads2_x[myindex] 
		strncpy(coord_x,pads2_array[array2index].xstr,40);

        strncpy(coord_y,pads2_array[array2index].ystr,40); //  = pads2_y[myindex] 
        if(units == 1 )
		{
           split(coord_x,tmp1[0],tmp1[1],".");
           strncpy(coord_x1,tmp1[1],120);
           split(coord_y,tmp2[0],tmp2[1],".");
           strncpy(coord_y1,tmp2[1],120);
        }
        else
		{
           //coord_x1 = coord_x
			strncpy(coord_x1,coord_x,40);
           //coord_y1 = coord_y 
			strncpy(coord_y1,coord_y,40);

        } 
        //c_index = ( coord_x1 SUBSEP coord_y1)
		strncpy(c_index,coord_x1,40);
		strncat(c_index,":",10);
		strncat(c_index,coord_y1,40);

        if( !(found_in_via_coords(c_index)))
		{
          fprintf(stderr, "FATAL ERROR(3): end of Cline doesn't match via location for"); // | "cat 1>&2"
          fprintf(stderr, "\t %s\n",thisline); //  $0 | "cat 1>&2"
          result = 3;
        }
        else 
		{
		 arrayvindex= via_array_index( c_index);

		 if ( strcmp(via_array[arrayvindex].netname,str_array[6]) != 0 ) //via_coords[c_index] != $7)
		 {
          fprintf(stderr, "FATAL ERROR(4): net name %s doesn't match net name for",
			    via_array[arrayvindex].netname ); // | "cat 1>&2"
          fprintf(stderr, "\t %s\n",thisline); // $0 | "cat 1>&2"
          result = 4;
         }   
         else
		 {   
           //flag[myindex] = -999;
		   pads2_array[array2index].linenumber=-999;
           strncpy(layer,"U",10);      // = "U"
         }
		}
     }
     else
	 {
        strncpy(layer,"ZZ",10); //  = "ZZ"
     }
     fprintf(outfile,"%10.4f %10.4f %5d",atof(coord_x),atof(coord_y),atoi(str_array[2]));     // $3)
     fprintf(outfile," %3s %5s %5s",layer,str_array[4],str_array[5]);  // $5,$6)
     fprintf(outfile,"%20s %10.4f\n",str_array[6],atof(str_array[7]));  // $7,$8)
   }
   else
   {
     fprintf(outfile,"%s",thisline); // $0
   }
   endoffile=getline(file3,thisline);
   nf=split_line(thisline);
  }

  fclose(file3);

   i=0;
   while( i < array1cnt )
   {
     if(pads1_array[i].linenumber != -999)
	 {
       bad[badcnt]= pads1_array[i].linenumber;  // flag[i]]++
	   if (badcnt < 1000)
	   {
		   badcnt +=1;
	   }
	   else
	   {
		   printf("More than 1000 bad via lines \n");
	   }
     }
	 i += 1;
   }  
   i=0;
   while( i < array2cnt )
   {
     if(pads2_array[i].linenumber != -999)
	 {
       bad[badcnt]= pads2_array[i].linenumber;  // flag[i]]++
	   if (badcnt < 1000)
	   {
		   badcnt +=1;
	   }
	   else
	   {
		   printf("More than 1000 bad via lines \n");
	   }

     }
	 i += 1;
   } 
   i=0;
   while( i < badcnt)
   {
     if (bad[i] > 1)
	 {
       fprintf(stderr, "ERROR  LINE // %d\n", i ); //   | "cat 1>&2" 
     }
   }
  return( result );
}


int merge3_call( int unitval, char *infile1str, char *infile2str, char *infile3str)
{
int cnt;
int result;
char tmp1[10][200];
char tmp2[10][200];
char tmp3[10][200];

char tmp5[10][200];
char tmp6[10][200];
char tmp7[10][200];
char tmp8[10][200];
char layer[40];
char thisline[300];
char p1x[200];
char p1y[200];
char p2x[200];
char p2y[200];
char coord_x1[200];
char coord_y1[200];
char coord_x[200];
char coord_y[200];
char myindex[300];
char c_index[300];
int i;
int array1index;
int array2index;
int arrayvindex;

int bad[1000];
int badcnt;

int endoffile;
int nf;
int units;

FILE *file1,*file2,*file3;

   //FS = "!"

   badcnt=0;
   array1cnt=0;
   array2cnt=0;
   arrayvcnt=0;

   units = unitval;

   file1 = fopen(infile1str,"r");
   if (file1 == NULL)
   {
	   printf("In merge3_call, unable to open the input file = %s \n",infile1str);
	   exit(-1);

   }

  // getline < file1
   endoffile=getline(file1,thisline);

   // getline < file1
   endoffile=getline(file1,thisline);

   cnt = 3;
   // file1 (wbdata.txt)is the extracted data for the clines that go 
   // from the die pads to the bond fingers 

   endoffile=getline(file1,thisline);
   nf=split_line_seps(thisline,"!");

   while(endoffile==FALSE)
   {
     strncpy(p1x,str_array[6],120); //  = $7
     strncpy(p1y,str_array[7],120); //  = $8
     strncpy(p2x,str_array[4],120); //  = $5
     strncpy(p2y,str_array[5],120);  // = $6

     // adjust the input coordinate if processing um designs

     if(units == 1)
	 {
        split(str_array[4],tmp5[0],tmp5[1],".");
        strncpy(str_array[4],tmp5[0],120); // $5 = tmp5[1] 
        split(str_array[5],tmp6[0],tmp6[1],".");
        strncpy(str_array[5],tmp6[0],120);  // $6 = tmp6[1] 
        split(str_array[6],tmp7[0],tmp7[1],".");
        strncpy(str_array[6],tmp7[0],120);  // $7 = tmp7[1] 
        split(str_array[7],tmp8[0],tmp8[1],".");
        strncpy(str_array[7],tmp8[0],120);   // $8 = tmp8[1] 
     }

     //pads1_x[$5,$6] = p1x
     //pads1_y[$5,$6] = p1y
     //pads2_x[$7,$8] = p2x
     //pads2_y[$7,$8] = p2y
     //flag[$5,$6] = cnt
     //flag[$7,$8] = cnt

	   add_to_pads1(str_array[4],str_array[5],p1x,p1y,cnt);
	   add_to_pads2(str_array[6],str_array[7],p2x,p2y,cnt);

     cnt++;

	 endoffile=getline(file1,thisline);
	 nf=split_line_seps(thisline,"!");
   }
   fclose(file1);

   if (cnt == 3)
   {
      fprintf(stderr,"FATAL ERROR(5): Unable to extract cline information from design file\n"); // | "cat 1>&2"
      result = 5;
      return(result);
   }
      
   fprintf(stderr,"bondfinger count = %d \n", cnt - 3 );   // | "cat 1>&2"

 //  FS = " "

   file2=fopen(infile2str,"r");
   if (file2==NULL)
   {
	   printf("In merge3_call, unable to open the input file = %s \n",infile2str);
	   exit(-1);
   }

   endoffile=getline(file2,thisline);
   nf=split_line(thisline);

   //file2 (vias_info2.txt) is the extract via data
   while( endoffile==FALSE)
   {
     if(units == 1)
	 {
        split(str_array[1],tmp2[0],tmp2[1],".");
        strncpy(str_array[1],tmp2[0],120);        // $2 = tmp2[1] 
        split(str_array[2],tmp3[0],tmp3[1],".");
        strncpy(str_array[2],tmp3[0],120);        // $3 = tmp3[1] 
     }
     //via_coords[$2,$3] = $1
	 add_to_via_coords(str_array[1],str_array[2],str_array[0]);


	 endoffile=getline(file2,thisline);
	 nf=split_line(thisline);
   }

   fclose(file2);

   file3=fopen(infile3str,"r");
   if (file3 == NULL)
   {
	   printf("In merge3_call, unable to open the input file = %s \n",infile3str);
	   exit(-1);
   }

   endoffile=getline(file3,thisline);

   printf("%s",thisline); // $0
   result = 0; 

   endoffile=getline(file3,thisline);
   nf=split_line(thisline);

  while(endoffile==FALSE)
  {
   if( strcmp(str_array[3],"Z") == 0 )             //$4 == "Z")
   {
     if(units == 1 )
	 {
        split(str_array[0],tmp1[0],tmp1[1],".");
        strncpy(str_array[0],tmp1[0],120);  // $1 = tmp1[1] 
        split(str_array[1],tmp2[0],tmp2[1],".");
        strncpy(str_array[1],tmp2[0],120);  //$2 = tmp2[1] 
     }
     // myindex = ( $1 SUBSEP $2)
	 strncpy(myindex,str_array[0],120);
	 strncat(myindex,":",10);
	 strncat(myindex,str_array[1],120);

     if( found_in_pads1(myindex) )
	 {
		array1index= pads1_index(myindex);

        strncpy(coord_x,pads1_array[array1index].xstr,40);
        strncpy(coord_y,pads1_array[array1index].ystr,40);

        if(units == 1 )
		{
           split(coord_x,tmp1[0],tmp1[1],".");
           strncpy(coord_x1,tmp1[0],120);

           split(coord_y,tmp2[0],tmp2[1],".");
           strncpy(coord_y1,tmp2[0],120);
        }
        else
		{
           strncpy(coord_x1,coord_x,40);
           strncpy(coord_y1,coord_y,40); 
        } 
       // c_index = ( coord_x1 SUBSEP coord_y1)

		strncpy(c_index,coord_x1,40);
		strncat(c_index,":",10);
		strncat(c_index,coord_y1,40);

        if( !(found_in_via_coords(c_index)))
		{
          fprintf(stderr, "FATAL ERROR(1): end of cline doesn't match via location for"); // | "cat 1>&2"
          fprintf(stderr, "\t %s\n",thisline); //  $0  | "cat 1>&2"
          result = 1;
        }
        else  // found
		{
		 arrayvindex= via_array_index(c_index);

		 if ( strcmp(via_array[arrayvindex].netname,str_array[6]) != 0)
		 {
          printf("FATAL ERROR(2): net name %s doesn't match net name for",
			      via_array[arrayvindex].netname ); // | "cat 1>&2"
          fprintf(stderr, "\t %s\n",thisline);   //  $0  | "cat 1>&2"
          result = 2;
         }   
         else
		 {   
           // flag[myindex] = -999
		    pads1_array[array1index].linenumber=-999;

           // layer = "U"
		   strncpy(layer,"U",10);

         }
		}
     }
     else if ( found_in_pads2(myindex) )
	 {
		array2index=pads2_index(myindex);

       // coord_x = pads2_x[myindex] 
		strncpy(coord_x,pads2_array[array2index].xstr,40);

        strncpy(coord_y,pads2_array[array2index].ystr,40); //  = pads2_y[myindex] 
        if(units == 1 )
		{
           split(coord_x,tmp1[0],tmp1[1],".");
           strncpy(coord_x1,tmp1[1],120);
           split(coord_y,tmp2[0],tmp2[1],".");
           strncpy(coord_y1,tmp2[1],120);
        }
        else
		{
           //coord_x1 = coord_x
			strncpy(coord_x1,coord_x,40);
           //coord_y1 = coord_y 
			strncpy(coord_y1,coord_y,40);

        } 
        //c_index = ( coord_x1 SUBSEP coord_y1)
		strncpy(c_index,coord_x1,40);
		strncat(c_index,":",10);
		strncat(c_index,coord_y1,40);

        if( !(found_in_via_coords(c_index)))
		{
          fprintf(stderr, "FATAL ERROR(3): end of Cline doesn't match via location for"); // | "cat 1>&2"
          fprintf(stderr, "\t %s\n",thisline); //  $0 | "cat 1>&2"
          result = 3;
        }
        else 
		{
		 arrayvindex= via_array_index( c_index);

		 if ( strcmp(via_array[arrayvindex].netname,str_array[6]) != 0 ) //via_coords[c_index] != $7)
		 {
          fprintf(stderr, "FATAL ERROR(4): net name %s doesn't match net name for",
			    via_array[arrayvindex].netname ); // | "cat 1>&2"
          fprintf(stderr, "\t %s\n",thisline); // $0 | "cat 1>&2"
          result = 4;
         }   
         else
		 {   
           //flag[myindex] = -999;
		   pads2_array[array2index].linenumber=-999;
           strncpy(layer,"U",10);      // = "U"
         }
		}
     }
     else
	 {
        strncpy(layer,"ZZ",10); //  = "ZZ"
     }
     printf("%10.4f %10.4f %5d",atof(coord_x),atof(coord_y),atoi(str_array[2]));     // $3)
     printf(" %3s %5s %5s",layer,str_array[4],str_array[5]);  // $5,$6)
     printf("%20s %10.4f\n",str_array[6],atof(str_array[7]));  // $7,$8)
   }
   else
   {
     printf("%s",thisline); // $0
   }
   endoffile=getline(file3,thisline);
   nf=split_line(thisline);
  }

  fclose(file3);

   i=0;
   while( i < array1cnt )
   {
     if(pads1_array[i].linenumber != -999)
	 {
       bad[badcnt]= pads1_array[i].linenumber;  // flag[i]]++
	   if (badcnt < 1000)
	   {
		   badcnt +=1;
	   }
	   else
	   {
		   printf("More than 1000 bad via lines \n");
	   }
     }
	 i += 1;
   }  
   i=0;
   while( i < array2cnt )
   {
     if(pads2_array[i].linenumber != -999)
	 {
       bad[badcnt]= pads2_array[i].linenumber;  // flag[i]]++
	   if (badcnt < 1000)
	   {
		   badcnt +=1;
	   }
	   else
	   {
		   printf("More than 1000 bad via lines \n");
	   }

     }
	 i += 1;
   } 
   i=0;
   while( i < badcnt)
   {
     if (bad[i] > 1)
	 {
       fprintf(stderr, "ERROR  LINE // %d\n", i ); //   | "cat 1>&2" 
     }
   }
  return( result );
}

int main( int argc, char **argv)
{
int retcode;
  
	if (argc != 5)
	 {
		 printf("In merge3, wrong number of arguments \n");
		 printf("Usage: merge3 units fname1 fname2 fname3 \n");
		 exit(-1);
	 }
	 else
	 {
       retcode=merge3_call(atoi(argv[1]), argv[2], argv[3], argv[4]);
	 }

}   // end main
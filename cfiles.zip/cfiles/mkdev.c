#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// Create device file from text file
// only pin name and total line count is needed
//  usage :  mkpin project infile
//


void mkdev_call_out( char *projectstr, char *infile1str, char *outfilestr)
{
int npins;
int number_fields;
int endoffile;
int i;
char thisline[200];
char pinname[120][1000];
char project[120];

FILE *file1;
FILE *outfile;


  npins = 0;
  strncpy( project,projectstr, 120);

  file1  = fopen(infile1str, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
  }

  outfile = fopen(outfilestr, "w");

  if (outfile == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",outfilestr);
	  exit(-1);
  }

  endoffile = getline( file1, thisline);
  number_fields = split_line( thisline);

  while( endoffile == FALSE)
  {
    if (number_fields > 2)
	{
      npins = npins + 1;
      strncpy(pinname[npins],str_array[0],120);
	}
	endoffile = getline( file1, thisline);
    number_fields = split_line( thisline);

  }

  fclose(file1);

  fprintf(outfile,"package %s\n", project);
  fprintf(outfile,"class ic\n");
  fprintf(outfile,"pincount %d\n\n", npins);

  for (i = 1; i <= npins; i++) 
  {
    if (i == 1)
      fprintf(outfile,"pinorder %s %s,\n", project, pinname[i]);
    else if (i == npins)
      fprintf(outfile,"         %s\n\n", pinname[i]);
    else
      fprintf(outfile,"         %s,\n", pinname[i]);
  } 
  for (i = 1; i <= npins; i++) 
  {
    if (i == 1)
      fprintf(outfile,"pinuse %s IN,\n", project);
    else if (i == npins)
      fprintf(outfile,"         IN\n\n");
    else
      fprintf(outfile,"         IN,\n");
  }   
  for (i = 1; i <= npins; i++) 
  {
    if (i == 1)
      fprintf(outfile,"function sig %s %s,\n", project, pinname[i]);
    else if (i == npins)
      fprintf(outfile,"         %s\n\n", pinname[i]);
    else
      fprintf(outfile,"         %s,\n", pinname[i]);
  } 
  fprintf(outfile,"end\n");

  fclose(outfile);
}  // end mkdev_call_out



void mkdev_call( char *projectstr, char *infile1str)
{
int npins;
int number_fields;
int endoffile;
int i;
char thisline[200];
char pinname[120][1000];
char project[120];

FILE *file1;

  npins = 0;

  strncpy( project,projectstr, 120);

  file1  = fopen(infile1str, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
  }

  endoffile = getline( file1, thisline);
  number_fields = split_line( thisline);

  while( endoffile == FALSE)
  {
    if (number_fields > 2)
	{
      npins = npins + 1;
      strncpy(pinname[npins],str_array[0],120);
	}
	endoffile = getline( file1, thisline);
    number_fields = split_line( thisline);

  }

  fclose(file1);

  printf("package %s\n", project);
  printf("class ic\n");
  printf("pincount %d\n\n", npins);

  for (i = 1; i <= npins; i++) 
  {
    if (i == 1)
      printf("pinorder %s %s,\n", project, pinname[i]);
    else if (i == npins)
      printf("         %s\n\n", pinname[i]);
    else
      printf("         %s,\n", pinname[i]);
  } 
  for (i = 1; i <= npins; i++) 
  {
    if (i == 1)
      printf("pinuse %s IN,\n", project);
    else if (i == npins)
      printf("         IN\n\n");
    else
      printf("         IN,\n");
  }   
  for (i = 1; i <= npins; i++) 
  {
    if (i == 1)
      printf("function sig %s %s,\n", project, pinname[i]);
    else if (i == npins)
      printf("         %s\n\n", pinname[i]);
    else
      printf("         %s,\n", pinname[i]);
  } 
  printf("end\n");

}  // end mkdev_call

/*
int main( int argc, char **argv)
{

  if ( argc < 2)
  {
	  printf("usage: mkdev project infile \n");
	  exit(-1);
  }
  else
  {
	mkdev_call( argv[1], argv[2]);
  }


} // end main

  
*/


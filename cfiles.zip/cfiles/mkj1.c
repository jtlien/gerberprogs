#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0

// Creates 5-column text file for input to mksym
// JEDEC symbol, square array
// Requires an input file with nx        ny      nxx     nyy
// where nx and ny are the outer pin counts and nxx and nyy are the
// counts of the depopulated area
// Add or delete lines at end of array to specify all the letters.
// Effect of mirror variables:
// mirrorx mirrory A1 position
//    1       1    lower left
//   -1       1    lower right
//    1      -1    upper left
//   -1      -1    upper right


void mkstr( char inchar1, char inchar2, char *instr)
{

if ( inchar1 != ' ')
{
instr[0] = inchar1;
instr[1] = inchar2;
instr[2] = NULLCHAR;
}
else
{
instr[0] = inchar2;
instr[1] = NULLCHAR;
}


} // end mkstr

void mkj1_call (char *infilestr, char *pitchstr )
{
int mirrorx;
int mirrory;
int count;
int nangle;
int ntext;
int ndontuse;

double pitch;
double nx;
double ny;
double nxx;
double nyy;

int left;
int right;
double xmx;
double ymx;
int found;
int t;
FILE *file1,*logfile;
double llx;
double lly;
double x;
double y;

char letter[40];
char str1[120];
char str2[120];
char str3[120];
char str4[120];
char text[120][120];
char dontuse[120][120];
char istr[30];
char pin[120];
double dx;
double dy;
int i;
int j;	


  mirrorx = 1;
  mirrory = 1;
  letter[0] =' ';
  letter[1] ='a';
  letter[2] ='b';
  letter[3] ='c';
  letter[4] ='d';
  letter[5] ='e';
  letter[6] ='f';
  letter[7] ='g';
  letter[8] ='h';
  letter[9] ='j';
  letter[10]='k';
  letter[11]='l';
  letter[12]='m';
  letter[13]='n';
  letter[14]='p';
  letter[15]='r';
  letter[16]='t';
  letter[17]='u';
  letter[18]='v';
  letter[19]='w';
  letter[20]='y';

// Change this number to the number of dontuse pins

  ndontuse = 0;

// Append this list as appropriate
  //dontuse[1] = "a1"

  count = 0;
  nangle = 0;
  ntext = 0;

  logfile = fopen("mkj1.log", "w");

  if (logfile == NULL)
  {
	  printf("Error: Unable to open the log file = mkj1.log\n");
	  exit(-1);
  }

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

// Modify this line to change pitch *******************

  
 // pitch = 1.00;
  pitch=atof(pitchstr);


    while ( fscanf( file1,"%s %s %s %s \n",str1,str2,str3,str4) == 4)
	{
     nx = atof(str1);
     ny = atof(str2);

     nxx = atof(str3);
     nyy = atof(str4);
    }

  // printf("nx ny nxx nyy = %d %d %d %d \n", nx, ny, nxx, nyy );

  fclose( file1);

// modified for large package to go to b


  for (left = 0; left <= 2; left++) {
    for (right = 1; right <= 20; right++) {
      ntext += 1;
      mkstr(letter[left],letter[right],text[ntext]);
	  // printf("text %d = %s \n", ntext, text[ntext]);
    }
  }

  dx  = (nx-nxx)/2.0;
  dy  = (ny-nyy)/2.0;

  xmx = nx - dx;
  ymx = ny - dy;

  llx = ((1.0 - nx)/2.0)*pitch;
  lly = ((1.0 - ny)/2.0)*pitch;

  for (i = 1; i <= nx; i++) {
    for (j = 1; j <= ny; j++) {
  
      x = llx + (i - 1)*pitch;
      y = lly + (j - 1)*pitch;
      strncpy(pin,text[j],4);
	 
	  sprintf(istr,"%d",i);

	  strcat(pin,istr);

      if ((i > dx) && (i <= xmx) && (j > dy) && (j <= ymx)) 
	  {
        fprintf(logfile,"[IGNORED: %s\n", pin); 
      }
      else 
	  {
        found = 0;
        for (t = 1; t <= ndontuse; t++)
		{
          if (strcmp(pin,dontuse[t]) == 0)
		  {
            found = 1;
		  }
        }

    // first statement puts letters on Y, numbers on X
	    if (found == 0)
          // printf("%s%d %8.4f %8.4f 0.0000 bga\n", text[j], i, x*mirrorx, y*mirrory);
          printf("%s%d %8.4f %8.4f 0.0000 bga\n", text[i], j, x*mirrorx, y*mirrory);

      } 

    } // all i
  } // j

  fclose( logfile);

}  // end mkj1_call


int main(int argc, char **argv)
{
	if (argc != 3)
	{
		printf("In mkj1, wrong number of arguments \n");
        printf("Usage: mkj1 infile pitch \n");
		exit(-1);
	}
	else
	{
		mkj1_call( argv[1], argv[2]);
	}

}  // end main
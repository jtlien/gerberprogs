#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// create pin placement script from a text file
// input format:
// pin x y [angle [padname]]



void mkpin_call_out( char *infilestr, char *outfilestr)
{

double oldangle;
double iangle;
double newangle;
int number_fields;
char thisline[300];
int endoffile;
FILE *file1;
FILE *outfile;


  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  outfile = fopen(outfilestr, "w");

  if (outfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
  }

  fprintf(outfile,"#mkpin: rev 1.0 (May 15, 1996)\n");
  fprintf(outfile,"version 6.1\n");
  fprintf(outfile,"setwindow pcb\n");
  fprintf(outfile,"add pin\n");
  oldangle = 0.0;

  endoffile = getline(file1, thisline);
  number_fields = split_line( thisline);

  while( endoffile == FALSE)
  {
    if (number_fields > 2) 
	{
    fprintf (outfile,"\nsetwindow form.mini\n");

     if (number_fields == 5)
      fprintf(outfile,"FORM mini padname %s\n", str_array[4]);
     else
	 {
      fprintf(outfile,"FORM mini padname XXpadname\n");
      fprintf(outfile,"FORM mini offsetx 0.0\n");
      fprintf(outfile,"FORM mini offsety 0.0\n");
      fprintf(outfile,"FORM mini next_pin_number %s\n", str_array[0]);
      fprintf(outfile,"setwindow pcb\n");
	 }
     if (number_fields >= 4)
	 {
      newangle = atof(str_array[3]);
      iangle = newangle-oldangle;
      oldangle = newangle;
      fprintf(outfile,"rotate\n");
      fprintf(outfile,"iangle %12.4f\n", iangle);
     }
    fprintf(outfile,"%s%12.4f %12.4f\n", "pick", atof( str_array[1] ) , atof( str_array[2]) );


	}

    endoffile = getline(file1, thisline);
	number_fields = split_line( thisline);

  }

  printf("done\n");
  fclose(file1);
  fclose(outfile);

} // end mkpin_call_out


void mkpin_call( char *infilestr)
{

double oldangle;
double iangle;
double newangle;
int number_fields;
char thisline[300];
int endoffile;
FILE *file1;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  printf ("#mkpin: rev 1.0 (May 15, 1996)\n");
  printf ("version 6.1\n");
  printf ("setwindow pcb\n");
  printf ("add pin\n");
  oldangle = 0.0;

  endoffile = getline(file1, thisline);
  number_fields = split_line( thisline);

  while( endoffile == FALSE)
  {
    if (number_fields > 2) 
	{
    printf ("\nsetwindow form.mini\n");

     if (number_fields == 5)
      printf ("FORM mini padname %s\n", str_array[4]);
     else
	 {
      printf("FORM mini padname XXpadname\n");
      printf("FORM mini offsetx 0.0\n");
      printf("FORM mini offsety 0.0\n");
      printf("FORM mini next_pin_number %s\n", str_array[0]);
      printf("setwindow pcb\n");
	 }
     if (number_fields >= 4)
	 {
      newangle = atof(str_array[3]);
      iangle = newangle-oldangle;
      oldangle = newangle;
      printf("rotate\n");
      printf("iangle %12.4f\n", iangle);
     }
    printf("%s%12.4f %12.4f\n", "pick", atof( str_array[1] ) , atof( str_array[2]) );

	}
	endoffile = getline(file1, thisline);
	number_fields = split_line( thisline);
  }

  printf("done\n");
  fclose(file1);

} // end mkpin_call

/*
int main( int argc, char **argv)
{

  if (argc != 2)
  {
    printf("Error in mkpin, wrong number of arguments \n");
	printf("Usage: mkpin infile1 \n");
	exit(-1);
  }
  else
  {
	  mkpin_call( argv[1]);
  }

} // end main
*/



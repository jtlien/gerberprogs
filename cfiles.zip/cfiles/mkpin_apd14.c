#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// create pin placement script from a text file
// input format:
// pin x y [angle [padname]]



void mkpin_apd14_call_out( char *infilestr, char *outfilestr)
{

double oldangle;
int number_fields;
char thisline[300];
int endoffile;
FILE *file1;
FILE *outfile;


  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  outfile = fopen(outfilestr, "w");

  if (outfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
  }

  fprintf(outfile,"#mkpin_apd14: rev 1.0  (2/25/03)\n");
  fprintf(outfile,"version 14.2\n");
  fprintf(outfile,"setwindow pcb\n");
  fprintf(outfile,"trapsize 69\n");
  fprintf(outfile,"add pin\n");
  
  oldangle = 0.0;

  endoffile = getline(file1, thisline);
  number_fields = split_line( thisline);

  while( endoffile == FALSE)
  {
   fprintf(outfile,"setwindow form.mini\n");
   fprintf(outfile,"FORM mini rotate_pin %0.4f\n", atof(str_array[3]) );
   fprintf(outfile,"next\n");
   fprintf(outfile,"setwindow form.mini\n");
   fprintf(outfile,"FORM mini pad_name %s\n", str_array[4]);
   fprintf(outfile,"FORM mini next_pin_number %s\n", str_array[0]);
   fprintf(outfile,"setwindow pcb\n");
   fprintf(outfile,"pick grid %s %s\n",str_array[1],str_array[2]);
   fprintf(outfile,"setwindow pcb\n");

    endoffile = getline(file1, thisline);
	number_fields = split_line( thisline);

  }

  printf("done\n");
  fclose(file1);
  fclose(outfile);

} // end mkpin_apd14_call_out


void mkpin_apd14_call( char *infilestr)
{

double oldangle;
int number_fields;
char thisline[300];
int endoffile;
FILE *file1;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  printf("#mkpin_apd14: rev 1.0  (2/25/03)\n");
  printf("version 14.2\n");
  printf("setwindow pcb\n");
  printf("trapsize 69\n");
  printf("add pin\n");
  
  oldangle = 0.0;

  endoffile = getline(file1, thisline);
  number_fields = split_line( thisline);

  while( endoffile == FALSE)
  {
   printf("setwindow form.mini\n");
   printf("FORM mini rotate_pin %0.4f\n", atof(str_array[3]) );
   printf("next\n");
   printf("setwindow form.mini\n");
   printf("FORM mini pad_name %s\n", str_array[4]);
   printf("FORM mini next_pin_number %s\n", str_array[0]);
   printf ("setwindow pcb\n");
   printf ("pick grid %s %s\n",str_array[1],str_array[2]);
   printf ("setwindow pcb\n");

	endoffile = getline(file1, thisline);
	number_fields = split_line( thisline);
  }

  printf("done\n");
  fclose(file1);

} // end mkpin_apd14_call

/*
int main( int argc, char **argv)
{

  if (argc != 2)
  {
    printf("Error in mkpin_apd14, wrong number of arguments \n");
	printf("Usage: mkpin_apd14 infile1 \n");
	exit(-1);
  }
  else
  {
	  mkpin_apd14_call( argv[1]);
  }

} // end main

  */

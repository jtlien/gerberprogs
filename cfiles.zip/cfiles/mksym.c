#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// Wrapper for creating pin scripts and device files

void mkpin_call_out( char *infilestr, char *outfilestr);
void mkdev_call_out( char *projectstr, char *infilestr, char *outfilestr);


void mksym_call( char *instr)
{
char fromfilestr[300];
char tofilestr[300];

if (WINDOWS)
{
	strncpy(dirsep,"\\",5);
}
else
{
	strncpy(dirsep,"/",5);
}



strncpy(fromfilestr,instr,120);  // $1.txt
strncat(fromfilestr,".txt",10);

strncpy(tofilestr,instr,120);   // $1.scr
strncat(tofilestr,".scr",10);

mkpin_call_out( fromfilestr,tofilestr); //           $1.txt >$1.scr

strncpy(tofilestr,instr,120);   // $1.dev
strncat(tofilestr,".dev",10);

mkdev_call_out( instr, fromfilestr, tofilestr); //
                                           // mkdev.awk -v project=$1 $1.txt >$1.dev

strncpy(fromfilestr,instr,120);   // $1.dev
strncat(fromfilestr,".dev",10);

strncpy(tofilestr,"devices",120);   // devices/$1.txt
strncat(tofilestr,dirsep,10);
strncat(tofilestr,instr,120);
strncat(tofilestr,".txt",10);

cp_file(fromfilestr,tofilestr);
// cp $1.dev ../devices/$1.txt


}    // end mksym


int main( int argc, char **argv)
{


    if (argc != 2)
	{
		printf("In mksym, wrong number of arguments \n");
		printf("Usage: mksym partnumber \n");
		exit(-1);
	}
	else
	{
		mksym_call( argv[1]);
	}

}  // end main

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  usage :  mod_dat  mult xin yin fname
//                        mult = power of 10
//                        fname = file names to read


void mod_dat_call( char *mult_str, char *xin_str, char *yin_str,
				   char *infilestr)
{
int mult;
double mymult;
double my_x;
double my_y;
double xin;
double yin;
double t1;
double t2;
int t3;
int endoffile;
int num_fields;
FILE *file1;
char thisline[200];

	
  mult = atoi( mult_str);
  xin = atof( xin_str);
  yin = atof( yin_str);

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  mymult = pow(10,mult);

  my_x = xin/mymult;
  my_y = yin/mymult;

  endoffile = getline( file1, thisline);

  printf("%s",thisline); 

  endoffile = getline( file1, thisline);
  num_fields = split_line(thisline);

  while ( endoffile == FALSE)
  {
   t1 = atof(str_array[0]) + my_x;
   t2 = atof(str_array[1]) + my_y;
   t3 = atoi(str_array[2]);
   printf("%10.4f %10.4f %5d",t1,t2,t3);
   printf(" %3s %5s %5s",str_array[3],str_array[4],str_array[5]);
   printf("%20s %10.4f\n",str_array[6],atof(str_array[7]));

   endoffile = getline( file1, thisline);
   num_fields = split_line(thisline);

  }
 fclose(file1);

}

void mod_dat_call_out( char *mult_str, char *xin_str, char *yin_str,
				   char *infilestr, char *outfilestr)
{
int mult;
double mymult;
double my_x;
double my_y;
double xin;
double yin;
double t1;
double t2;
int t3;
int endoffile;
int num_fields;
FILE *file1;
FILE *outfile;
char thisline[200];

	
  mult = atoi( mult_str);
  xin = atof( xin_str);
  yin = atof( yin_str);

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  outfile  = fopen(outfilestr, "w");

  if (outfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
  }

  mymult = pow(10,mult);

  my_x = xin/mymult;
  my_y = yin/mymult;

  endoffile = getline( file1, thisline);

  fprintf(outfile,"%s",thisline); 

  endoffile = getline( file1, thisline);
  num_fields = split_line(thisline);

  while ( endoffile == FALSE)
  {
   t1 = atof(str_array[0]) + my_x;
   t2 = atof(str_array[1]) + my_y;
   t3 = atoi(str_array[2]);
   fprintf(outfile,"%10.4f %10.4f %5d",t1,t2,t3);
   fprintf(outfile," %3s %5s %5s",str_array[3],str_array[4],str_array[5]);
   fprintf(outfile,"%20s %10.4f\n",str_array[6],atof(str_array[7]));

   endoffile = getline( file1, thisline);
   num_fields = split_line(thisline);

  }
 fclose(file1);

}


int main( int argc, char **argv)
{

	if ( argc != 5)
	{
		printf("In mod_dat, wrong number of arguments \n");
		printf("Usage:  mod_dat mult xin yin infile \n");
		exit(-1);
	}
	else
	{
		mod_dat_call( argv[1], argv[2], argv[3], argv[4] );
	}

} // end main


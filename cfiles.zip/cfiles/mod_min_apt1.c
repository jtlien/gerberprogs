#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//
// mod_min_apt1   REL PCM min_apt_file inputfile outputfile
//
//    PCM is (#layer_num)layer
//    min_apt_file is a list of layers + relief values
//
//    produces an output file from the input file that updates the relief
//     value for each entry that has XXXRELIEF
char str_array[120][120];

struct reliefstuff
{
 char layerstr[60];
 double reliefval;
}  relief_array[1000];

int relief_count;


int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

// add an entry to the relief table
//
void add_to_relief( char *instr, double inval)
{

 if (relief_count < 1000 )
 {
	 strncpy(relief_array[relief_count].layerstr,instr,60);
	 relief_array[relief_count].reliefval=inval;
	 relief_count+=1;
 }
}  // add_to_relief

double find_in_relief( char *instr)
{
int ii;
int relief_found;

 relief_found=FALSE;
 ii=0;
 while((ii < relief_count) && ( relief_found == FALSE))
 {
	 if (strcmp(instr,relief_array[ii].layerstr) == 0 )
	 {
		 relief_found=TRUE;
		 return(relief_array[ii].reliefval);
	 }

   ii+=1;
 }
 printf("Unable to find in relief table = %s \n",instr);

 return(0.0);

}  // find in relief

void mod_min_apt1_call( char *relstr, char *pcmstr, char *minaptfile, char *infilestr,
				   char *outfilestr)
{
FILE *minaptf;
FILE *infile;
FILE *outfile;
int nf;
int endoffile;
char thline[200];

    relief_count = 0;

	minaptf = fopen(minaptfile,"r");
	if (minaptf == NULL)
	{
		printf("Unable to open the mod_min_apt1 input file = %s \n", minaptfile);
		exit(-1);
	}


	outfile = fopen(outfilestr,"w");
	if (outfile == NULL)
	{
		printf("Unable to open the mod_min_apt1 output file = %s \n", outfilestr);
		exit(-1);
	}

	endoffile = getline(minaptf,thline);
	nf=split_line(thline);

    while( endoffile==FALSE)
	{
        add_to_relief(str_array[0],atof(str_array[1])); 
    
       endoffile = getline(minaptf,thline);
	   nf=split_line(thline);
    }
    fclose(minaptf);

    infile = fopen(infilestr,"r");
	if (infile == NULL)
	{
		printf("Unable to open the mod_min_apt1 input file = %s \n", infilestr);
		exit(-1);
	}

    endoffile = getline(infile,thline);
	nf=split_line(thline);


   while(endoffile==FALSE)
   {
     if(strcmp(pcmstr,"7layer")== 0 )
	 {
         if(strcmp(str_array[1],"CORERELIEF")== 0 )
		 {
            fprintf(outfile,"%s %s %s %s %.3f %.3f\n",str_array[0],str_array[1],str_array[2],
				        str_array[3],find_in_relief("CORE"),find_in_relief("CORE"));
         }
         else if(strcmp(str_array[1],"L03RELIEF")== 0)
		 {
            fprintf(outfile,"%s %s %s %s %.3f %.3f\n",str_array[0],str_array[1],str_array[2],
				str_array[3],atof(str_array[4]),find_in_relief("L03"));
         }
         else if(strcmp(str_array[1],"L04RELIEF")==0)
		 {
            fprintf(outfile,"%s %s %s %s %.3f %.3f\n",str_array[0],str_array[1],str_array[2],
				str_array[3],atof(str_array[4]),find_in_relief("L04"));
         }
         else
		 {
            fprintf(outfile,"%s",thline);
         }
     }
     if(strcmp(pcmstr,"5layer") == 0)
	 {
         if(strcmp(str_array[1],"CORERELIEF")== 0)
		 {
            fprintf(outfile,"%s %s %s %s %.3f %.3f\n",str_array[0],str_array[1],str_array[2],
				str_array[3],find_in_relief("CORE"),find_in_relief("CORE"));
         }
         else
		 {
            fprintf(outfile,"%s",thline);
         }
     }
    endoffile = getline(infile,thline);
	nf=split_line(thline);

   }  // end while

    fclose(infile);
	fclose(outfile);

} 

int main( int argc, char **argv)
{

 if ( argc > 5)
	{
     mod_min_apt1_call( argv[1], argv[2], argv[3], argv[4],
				   argv[5]);
 }
 else
 {
	 printf("mod_min_apt1:  Wrong number of arguments \n");
 }


} // 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0



// Revision 1 released to users 11/15/02 - tsa

// Modifies extracted file- changes Apd TOP,SURFACE,BOTTOM and BASE to 
// layer name in .ctl file



// read the ctl file and
// 
//

void mod_top_bot2_call_out( char *infilestr, char *infile2str, char *outfilestr)
{
int tfound;
int bfound;
char thisline[300];
char mytop[300];
char mytsolder[300];
char mybsolder[300];
char mybot[300];
int endoffile;
FILE *file1;
FILE *file2;
FILE *outfile;
int nf;
char tmp[300];

     tfound = 0;
     bfound = 0;
     // file1 is .ctl file

	 file1=fopen(infilestr,"r");
	 if (file1 == NULL)
	 {
		 printf("In mod_top_bot2, unable to open the input file = %s \n", infilestr);
		 exit(-1);
	 }

     file2=fopen(infile2str,"r");
	 if (file2 == NULL)
	 {
		 printf("In mod_top_bot2, unable to open the input file = %s \n", infile2str);
		 exit(-1);
	 }

     outfile=fopen(outfilestr,"w");
	 if (outfile == NULL)
	 {
		 printf("In mod_top_bot2, unable to open the output file = %s \n", outfilestr);
		 exit(-1);
	 }

	 mytsolder[0]='\0';
	 mybsolder[0]='\0';

     mytop[0]='\0';
	 mybot[0]='\0';

      endoffile=getline(file1,thisline);
	  nf=split_line(thisline);

     while( endoffile==FALSE)
	 {
		if (nf > 2)
		{
        cv_toupper(str_array[2],tmp);

        if ( strcmp(tmp,"TSP")==0)
		{
           cv_toupper(str_array[0],mytop);
           tfound = 1;
        }
        if((strcmp(tmp,"TSM") == 0 ) && (tfound == 0) )
		{
           cv_toupper(str_array[0],mytop);
        }
        if ( strcmp(tmp,"BSP")==0)
		{
           cv_toupper(str_array[0],mybot);
           bfound = 1;
        }
        if( (strcmp(tmp,"BSM") == 0 ) && (bfound == 0))
		{
           cv_toupper(str_array[0],mybot);
        }
        if( strcmp(tmp,"TSOLDER")==0)
		{
          cv_toupper(str_array[0],mytsolder);
        }
        if( strcmp(tmp,"BSOLDER")==0)
		{
         cv_toupper(str_array[0],mybsolder);
        }
		}

	  endoffile=getline(file1,thisline);
	  nf=split_line(thisline);

    }

   fclose(file1);

   endoffile=getline(file2,thisline);
   while(endoffile==FALSE)
   {
     gsubs("SOLDERMASK_BOTTOM", mybsolder,thisline);
     gsubs("SOLDERMASK_TOP", mytsolder,thisline);
     gsubs("PASTEMASK_TOP", "STENCIL",thisline);
     gsubs("SURFACE", mytop,thisline);
     gsubs("TOP",mytop,thisline);
     gsubs("BASE",mybot,thisline);
     gsubs("BOTTOM",mybot,thisline);

     fprintf(outfile,"%s",thisline);


	 endoffile=getline(file2,thisline);
   }
   fclose(file2);

   fclose(outfile);

}  // end mod_top_bot2_call_out

void mod_top_bot2_call( char *infilestr, char *infile2str)
{
int tfound;
int bfound;
char thisline[300];
char mytop[300];
char mytsolder[300];
char mybsolder[300];
char mybot[300];
int endoffile;
FILE *file1;
FILE *file2;
int nf;
char tmp[300];

     tfound = 0;
     bfound = 0;
     // file1 is .ctl file

	 file1=fopen(infilestr,"r");
	 if (file1 == NULL)
	 {
		 printf("In mod_top_bot2, unable to open the input file = %s \n", infilestr);
		 exit(-1);
	 }

     file2=fopen(infile2str,"r");
	 if (file2 == NULL)
	 {
		 printf("In mod_top_bot2, unable to open the input file = %s \n", infile2str);
		 exit(-1);
	 }

	 mytsolder[0]='\0';
	 mybsolder[0]='\0';

     mytop[0]='\0';
	 mybot[0]='\0';

      endoffile=getline(file1,thisline);
	  nf=split_line(thisline);

     while( endoffile==FALSE)
	 {
		 //printf("Reading control file line = %s \n",thisline);

		if ( nf > 2 )
		{
        cv_toupper(str_array[2],tmp);

        if ( strcmp(tmp,"TSP")==0)
		{
           cv_toupper(str_array[0],mytop);
           tfound = 1;
        }
        if((strcmp(tmp,"TSM") == 0 ) && (tfound == 0) )
		{
           cv_toupper(str_array[0],mytop);
        }
        if ( strcmp(tmp,"BSP")==0)
		{
           cv_toupper(str_array[0],mybot);
           bfound = 1;
        }
        if( (strcmp(tmp,"BSM") == 0 ) && (bfound == 0))
		{
           cv_toupper(str_array[0],mybot);
        }
        if( strcmp(tmp,"TSOLDER")==0)
		{
          cv_toupper(str_array[0],mytsolder);
        }
        if( strcmp(tmp,"BSOLDER")==0)
		{
         cv_toupper(str_array[0],mybsolder);
        }
		}
	  endoffile=getline(file1,thisline);
	  nf=split_line(thisline);

    }

   fclose(file1);

   endoffile=getline(file2,thisline);
   while(endoffile==FALSE)
   {
	 // printf("file2, thisline = %s \n", thisline);

     gsubs("SOLDERMASK_BOTTOM", mybsolder,thisline);
     gsubs("SOLDERMASK_TOP", mytsolder,thisline);
     gsubs("PASTEMASK_TOP", "STENCIL",thisline);
     gsubs("SURFACE", mytop,thisline);
     gsubs("TOP",mytop,thisline);
     gsubs("BASE",mybot,thisline);
     gsubs("BOTTOM",mybot,thisline);

     printf("%s",thisline);


	 endoffile=getline(file2,thisline);
   }
   fclose(file2);

}  // end mod_top_bot2_call

/*
int main( int argc, char **argv)
{
  if (argc == 3)
  {
	mod_top_bot2_call( argv[1],argv[2]);
  }
  else
  {
	  printf("USAGE:   mod_top_bot2 ctlfile extractfile \n");
	  exit(-1);
  }
}

  */




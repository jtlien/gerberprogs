#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  usage :  mod_dat  mult xin yin fname
//                        mult = power of 10
//                        fname = file names to read

void mod_unused_dat_call_out(char *multstr, char *xinstr, char *yinstr,
						 char *infilestr, char *outfilestr) 
{
int mult;
double mymult;
double my_x;
double my_y;
double xin;
double yin;
double t1;
double t2;
int endoffile;
int num_fields;
FILE *file1;
FILE *outfile;
int s1;
char thisline[200];
double multd;

    mult = atoi( multstr);
	xin = atof( xinstr);
	yin = atof( yinstr);

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  } 
  outfile = fopen(outfilestr, "w");

  if (outfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
  }


  multd = (double) mult;

  mymult = pow(10,multd);

  my_x = xin/mymult;
  my_y = yin/mymult;

  
  endoffile = getline( file1, thisline);
  num_fields = split_line(thisline);

  while ( endoffile == FALSE)
  {
   t1 = atof(str_array[1]) + my_x;
   t2 = atof(str_array[2]) + my_y;
   
   s1 = atoi( str_array[0]);

   fprintf(outfile,"%d %10.4f %10.4f ", s1,t1,t2);
   fprintf(outfile," %3s %5s %15s",str_array[3],str_array[4],str_array[5]);
   fprintf(outfile,"%20s\n",str_array[6]);

   endoffile = getline( file1, thisline);
   num_fields = split_line(thisline);

  }
 fclose(file1);

 fclose(outfile);

} // mod_unused_dat_call_out


void mod_unused_dat_call(char *multstr, char *xinstr, char *yinstr,
						 char *infilestr) 
{
int mult;
double mymult;
double my_x;
double my_y;
double xin;
double yin;
double t1;
double t2;
int endoffile;
int num_fields;
FILE *file1;
int s1;
char thisline[200];
double multd;
	

    mult = atoi( multstr);

	xin = atof( xinstr);

	yin = atof( yinstr);

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  multd = (double) mult;

  mymult = pow(10.0,multd);

  my_x = xin/mymult;
  my_y = yin/mymult;

  
  endoffile = getline( file1, thisline);
  num_fields = split_line(thisline);

  while ( endoffile == FALSE)
  {
   t1 = atof(str_array[1]) + my_x;
   // printf("my_x=%10.10f t1 = %f mymult=%10.10f\n", my_x, t1,mymult);

   t2 = atof(str_array[2]) + my_y;  
   s1 = atoi( str_array[0]);

   printf("%d %10.4f %10.4f ", s1,t1,t2);
   printf(" %3s %5s %15s",str_array[3],str_array[4],str_array[5]);
   printf("%20s\n",str_array[6]);

   endoffile = getline( file1, thisline);
   num_fields = split_line(thisline);

  }
 fclose(file1);

} // mod_unused_dat_call


int main(int argc, char **argv)
{

if (argc < 5)
	{
	    printf("In mod_unused_dat, wrong number of arguments\n");
		printf("Usage: mod_unused_dat mult xin yin fname \n");
		exit(-1);
	}
else
{
	mod_unused_dat_call( argv[1], argv[2], argv[3], argv[4]);

} 

} // end main
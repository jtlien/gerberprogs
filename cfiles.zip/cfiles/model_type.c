#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// This script determines the type of package and number
// of layers then calls RLGC_MODEL script
// 01/07/99 wlee
//
// Revision History
// 01/07/99 - rev 1 - initial release

void do_execs( char *basefilestr, char *commandstr, char *partnum)
{
char systemstr[300];

  strncpy(systemstr,basefilestr,120);
  strncat(systemstr,"xnet_only",30);
  system(systemstr);

  strncpy(systemstr,basefilestr,120);
  strncat(systemstr,commandstr,60);
  strncat(systemstr," ",4);
  strncat(systemstr,partnum,40);

  system(systemstr);
}

void model_type_call(  )
{
char makelogfile[300];
char PART[40];
char LAYERS[40];
char PARTNUMBER[300];
char TYPE[300];
int typefound;
char mcmfilestr[300];
char basestr[300];
char beginstr[200];

strncpy(basestr,"/swtools/remote/bin/net_files/",80);

strncpy(makelogfile,"report/makelog",40);

if ( ! (file_exists ( makelogfile ) ) )
{
	printf("report/makelog does not exist \n");
	exit(-1);
}

//PARTNUMBER=`grep "Part Number" report/makelog | cut -d: -f2`  // extracts part number
sgrep(makelogfile,"Part Number",100);
split(grep_array[0],beginstr,PARTNUMBER,":");
//PART=`grep "Part Type" report/makelog | cut -d: -f2`
sgrep(makelogfile,"Part Type",100);
split(grep_array[0],beginstr,PART,":");
//LAYERS=`grep "Layers" report/makelog | cut -d: -f2`
sgrep(makelogfile,"Layers",100);
split(grep_array[0],beginstr,LAYERS,":");

//TYPE=$PART$LAYERS
strncpy(TYPE,PART,120);
strncat(TYPE,LAYERS,120);

printf("PARTNUMBER = %s \n",PARTNUMBER);
printf("TYPE = %s \n",TYPE);
printf("LAYERS = %s \n",LAYERS);
printf("PART=%s\n",PART);

printf("\n");

strncpy(mcmfilestr,PARTNUMBER,120);
strncat(mcmfilestr,".mcm",10);

if( file_exists( mcmfilestr) )  //  -a $PARTNUMBER.mcm ]
{
   typefound=FALSE;

  if(strcmp( TYPE,"scm3") == 0 )
  {
	printf("3 layer scm design\n");
	typefound=TRUE;
	//swtools/remote/bin/net_files/Xnet_only
	do_execs( basestr,"xtract_rlgc_3lyr",PARTNUMBER );
  }

  if( strcmp( TYPE,"scm5") == 0 ) 
  {
	typefound=TRUE;
	printf("5 layer scm design\n");
	//swtools/remote/bin/net_files/Xnet_only
	//swtools/remote/bin/net_files/Xtract_RLCG_5lyr $PARTNUMBER
	do_execs( basestr,"xtract_rlgc_5lyr",PARTNUMBER );
  }

  if( strcmp(TYPE,"scm7" ) == 0 )
  {
	  typefound=TRUE;
	 printf("7 layer scm design\n");
	//swtools/remote/bin/net_files/Xnet_only
	//swtools/remote/bin/net_files/Xtract_RLCG_7lyr $PARTNUMBER
    do_execs( basestr,"xtract_rlgc_7lyr",PARTNUMBER );
  }

 if( strcmp( TYPE, "wlbi5" ) == 0 )
 {
	 typefound=TRUE;
	 printf("5 layer wlbi design\n");
	 //swtools/remote/bin/net_files/Xnet_only
	//swtools/remote/bin/net_files/Xtract_RLCG_5lyr $PARTNUMBER
     do_execs( basestr,"xtract_rlgc_5lyr",PARTNUMBER );
 }

 if( strcmp(TYPE,"wlbi7") == 0 )  
 {
	typefound=TRUE;
	printf("7 layer wlbi design\n");
	//swtools/remote/bin/net_files/Xnet_only
	//swtools/remote/bin/net_files/Xtract_RLCG_wlbi7lyr $PARTNUMBER
    do_execs( basestr,"xtract_rlgc_7lyr",PARTNUMBER );
 }

 if ( typefound == FALSE)
 {
  printf("type %s is not found.\n",TYPE);
 }
}
else
  {
	printf("%s.mcm is not found.\n",PARTNUMBER);
	exit(1);
  }


}  // end model_type

int main( int argc, char **argv)
{

	if (argc != 1)
	{
		printf("Wrong number of arguments to model_type\n");
		printf("Usage:  model_type \n");
		exit(-1);
	}
	else
	{
		model_type_call( );
	}

}  // end main
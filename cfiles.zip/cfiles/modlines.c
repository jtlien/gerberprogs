#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//
//  This program is used to fix up the gerber output so that it has 
//      a * at the end of every line.   Also changes the M00 at the
//      end of the file to M02.
//


int ii;
char thisline[240];
FILE *file1;
FILE *file2;

int endoffile;
char holdline[200];
char holdline2[200];
char tempstr[200];
int remain;
int divis;
int linecnt;

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,240,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

int main( int argc, char  **argv)
{


	if (argc != 4)
	{
		printf("Usage: modlines rem div \n");
	    printf("   example: modlines 1 2     will get all odd lines\n");
		printf("            modlines 0 2     will get all even lines\n");
		exit(-1);
	}

    file1  = fopen(argv[1], "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",argv[1]);
	  exit(-1);
	}

	remain =atoi(argv[2]);

	divis=atoi(argv[3]);

   // printf("remain = %d divis = %d \n",remain,divis);

	if (remain > (divis -1))
	{
		printf("rem value (argument 2) must be less than div (argument 3 ) \n");
		exit(-1);
	}

	linecnt=0;

    endoffile = getline(file1, thisline);

    while( endoffile == FALSE)
	{
	  
	 
	 if ((linecnt % divis)==remain)
	 {
		 printf("%s",thisline);
	 }

	 endoffile = getline(file1, thisline);
	 linecnt += 1;

    }

	
   fclose(file1);


} // end main

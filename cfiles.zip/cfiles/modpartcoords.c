
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0



void modpartcoords_call( char *xinstr, char *yinstr, char *infilestr)
{
FILE *file1;
int Xin;
int Yin;
int Xmlt;
int Ymlt;
double X;
double Y;
double xval;
double yval;
int endoffile;
char thisline[300];
int nf;

      Xin=atoi(xinstr);
	  Yin=atoi(yinstr);

     Xmlt = Xin - 4;
     Ymlt = Yin - 4;
     //X = 10 ** Xmlt;
	  X=pow(10.0, Xmlt);
	  Y=pow(10.0, Ymlt);

    // Y = 10 ** Ymlt;

	  file1=fopen( infilestr,"r");
	  if (file1==NULL)
	  {
		  printf("In modpartcoords, unable to open the input file \n",infilestr);
		  exit(-1);
	  }
      endoffile=getline(file1,thisline);
	  nf=split_line(thisline);

      while(endoffile==FALSE)
	  {
		xval=atof(str_array[0]) * X;
		yval=atof(str_array[1]) * Y;

        printf("%0.0f %0.0f\n", xval, yval);

		endoffile=getline(file1,thisline);
		nf=split_line(thisline);

	  }

	  fclose(file1);

}   // end modpartcoords_call

void modpartcoords_call_out( char *xinstr, char *yinstr, char *infilestr,
							 char *outfilestr)
{
FILE *file1;
FILE *outfile;
int Xin;
int Yin;
int Xmlt;
int Ymlt;
double X;
double Y;
double xval;
double yval;
int endoffile;
char thisline[300];
int nf;

      Xin=atoi(xinstr);
	  Yin=atoi(yinstr);

     Xmlt = Xin - 4;
     Ymlt = Yin - 4;
     //X = 10 ** Xmlt;
	  X=pow(10.0, Xmlt);
	  Y=pow(10.0, Ymlt);

    // Y = 10 ** Ymlt;

	  file1=fopen( infilestr,"r");
	  if (file1==NULL)
	  {
		  printf("In modpartcoords, unable to open the input file \n",infilestr);
		  exit(-1);
	  }
	  
	  outfile=fopen( outfilestr,"w");
	  if (outfile==NULL)
	  {
		  printf("In modpartcoords, unable to open the output file \n",outfilestr);
		  exit(-1);
	  }
      endoffile=getline(file1,thisline);
	  nf=split_line(thisline);

      while(endoffile==FALSE)
	  {
		xval=atof(str_array[0]) * X;
		yval=atof(str_array[1]) * Y;

        fprintf(outfile,"%0.0f %0.0f\n", xval, yval);

		endoffile=getline(file1,thisline);
		nf=split_line(thisline);

	  }

	  fclose(file1);
	  fclose(outfile);

}   // end modpartcoords_call_out

int main( int argc, char **argv)
{

	if( argc != 4)
	{
		printf("In modpartcoords, wrong number of arguments \n");
		printf("Usage: modpartcoords xin yin infile \n");
		exit(-1);
	}
	else
	{
		modpartcoords_call( argv[1], argv[2], argv[3]);
	}

}  // end main
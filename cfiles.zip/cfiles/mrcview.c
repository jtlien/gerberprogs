#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#define BOW_SML 0.125
#define BOW_LRG 0.25

// mrcview.awk tsa
// Version 1.0 released to user on 10/08/02

typedef struct errorstuff
{
 double val1;
 double val2;
} errovals;

struct errorstuff mrc_airgap[100000];
struct errorstuff mrc_edge[100000];
struct errorstuff mrc_acidtrap[100000];
struct errorstuff mrc_reg[100000];
struct errorstuff mrc_void[100000];
struct errorstuff mrc_unterm[100000];
struct errorstuff mrc_sm[100000];
struct errorstuff mrc_others[100000];
struct errorstuff mrc_drill[100000];

struct laystuff
{
	char layername[50];
	int count;
} layers[ 100];

int layercount;

// get the error count for this layer
//
int get_count( char *inlayer)
{
int jj;

 while(jj < layercount)
 {
	 if (strcmp(inlayer,layers[jj].layername)==0 )
	 {
		 return(layers[jj].count);
	 }
	jj+=1;
 }

 return(0);

} // get_count

//***************************************************************
// function out_bowtie
// outputs a bowtie centered at the passed in x,y coordinates
// fmult variables adjust for micron designs
// output is to file fname
//***************************************************************

int in_lyr_switch( char *inlayer)
{
     if (strcmp(inlayer,"mrc_airgap") == 0 )
	 {
		 return(TRUE);
	 }
	 if (strcmp(inlayer,"mrc_edge") == 0 )
	 {
		 return(TRUE);
	 }
	 if (strcmp(inlayer,"mrc_acidtrap") == 0 )
	 {
		 return(TRUE);
	 }
	 if (strcmp(inlayer,"mrc_reg") == 0 )
	 {
		 return(TRUE);
	 }
	 if (strcmp(inlayer,"mrc_drill") == 0 )
	 {
		 return(TRUE);
	 }
	 if (strcmp(inlayer,"mrc_unterm") == 0 )
	 {
		 return(TRUE);
	 } 
	 if (strcmp(inlayer,"mrc_void") == 0 )
	 {
		 return(TRUE);
	 }
	 if (strcmp(inlayer,"mrc_sm") == 0 )
	 {
		 return(TRUE);
	 }
	 if (strcmp(inlayer,"mrc_others") == 0 )
	 {
		 return(TRUE);
	 }
    if (strcmp(inlayer,"all") == 0 )
	 {
		 return(TRUE);
	 }

	return(FALSE);
}  

void out_bowtie(double x, double y, double fmult, FILE *fname)
				  
{
      fprintf(fname,"\npick %.5f %.5f\n",x * fmult,y * fmult); // > fname
      fprintf(fname,"ipick  %.5f %.5f\n", BOW_SML * fmult,BOW_SML * fmult); // > fname
      fprintf(fname,"ipicky %.5f\n", BOW_LRG * -1 * fmult);   // > fname
      fprintf(fname,"ipick   %.5f %.5f\n", BOW_LRG * -1 * fmult, BOW_LRG  *fmult); // > fname
      fprintf(fname,"ipicky  %.5f\n",BOW_LRG * -1 *fmult); //  > fname
      fprintf(fname,"ipick  %.5f %.5f\n", BOW_SML*fmult, BOW_SML *fmult); // > fname
      fprintf(fname,"next\n\n"); // > fname
}

//***************************************************************
// function out_header
// outputs header information
//***************************************************************
void out_header(FILE *fname, char  *inlayer)
{
int i;
char thislayer[200];
char tmplyr[200];

    fprintf(fname,"version 13.6\n"); // > fname
    fprintf(fname,"setwindow pcb\n"); // > fname
    fprintf(fname,"define subclass\n"); // > fname
    fprintf(fname,"setwindow form.subclass\n"); // > fname
    fprintf(fname,"FORM subclass substrate_geometry pick\n"); // > fname
    fprintf(fname,"setwindow form.subclass_nonetch\n"); // > fname
	i=0;
    while( i < layercount)          // i in layers)
	{
	   
       cv_toupper(inlayer,tmplyr);
	   strncpy(thislayer, layers[i].layername,40);

       if ((strcmp(tmplyr,"ALL")==0) || (strcmp(tmplyr,thislayer)==0 ) ) // 
	   {
          fprintf(fname,"FORM subclass_nonetch name %s\n",thislayer); // > fname
       }
	  i += 1;
    }
    fprintf(fname, "setwindow form.subclass"); // > fname
    fprintf(fname, "FORM subclass done\n"); // > fname
    fprintf(fname, "setwindow pcb\n"); // > fname
}

//********************************************************************
// function select_apd_lyr
// outputs the apd commands to select the desired layer(lyr_name)
// output goes to the file fname
//********************************************************************
void  select_apd_lyr(char *lyr_name,FILE *fname)
{
    fprintf(fname, "add line\n"); // > fname
    fprintf(fname, "setwindow form.mini\n"); // > fname
    fprintf(fname, "FORM mini class SUBSTRATE GEOMETRY\n"); // > fname
    fprintf(fname, "FORM mini subclass %s\n",lyr_name); // > fname
    fprintf(fname, "FORM mini lock_direction Off\n"); // > fname
    fprintf(fname, "setwindow pcb\n"); //  > fname
}
 
//********************************************************************
// function output_errs
// outputs errors for the given type to the given file
//********************************************************************
void  output_errors(struct errorstuff *myarray, int mycnt,double mymult, FILE *fname)
{			
int j;

   for(j = 1; j <= mycnt; j++)
   {
      //x_index = (j SUBSEP 1);
      //y_index = (j SUBSEP 2);
      out_bowtie(myarray[j].val1,myarray[j].val2,mymult,fname);     
   }
}

//********************************************************************
// function apd_lyr_on
// turns on the apd layers that have errors on them
//********************************************************************
void   apd_lyr_on(FILE *fname, char *inlayer)
{
int j;
char thislayer[200];
char tmplyr[200];

     fprintf(fname, "setwindow pcb\n"); // > fname
     fprintf(fname, "color\n");  // > fname
     fprintf(fname, "setwindow form.cvf_main\n"); // > fname
     fprintf(fname, "FORM cvf_main color3 2 \n"); //  > fname

	 j=0;
     while( j < layercount)        // in layers) 
	 {
       cv_toupper(inlayer,tmplyr);
	   strncpy(thislayer,layers[j].layername,50);

       if ((strcmp(tmplyr,"ALL")==0) || (strcmp(tmplyr,thislayer)==0) ) //  == j)
	   {
        fprintf(fname,"FORM cvf_main substrate_geometry/%s/color 3\n",thislayer); // > fname
        fprintf(fname,"FORM cvf_main substrate_geometry/%s/visible YES\n",thislayer); // > fname
       }
	   j+=1;
     }
     fprintf(fname, "FORM cvf_main ok\n"); // > fname

}
//********************************************************************
// Begin section 
// sets up global constants and initializes variables to initial state
// removes header information from input file
//********************************************************************
void mrcview_call( char *infilestr, char *inlyr)
{

int NF;
int airgap_cnt;
int edge_cnt;
int acidtrap_cnt;
int reg_cnt;
int drill_cnt;
int unterm_cnt;
int  void_cnt;
int sm_cnt;
int others_cnt;
int has_errors;

double x1spot;
double x2spot;
double y1spot;
double y2spot;
int endoffile;
FILE *file1;
FILE *mm_namefile;
FILE *um_namefile;
char thisline[300];
char lyr[300];
char tmp[300];
int nf;
double MM_MULT;
double UM_MULT;
char thislay[300];
char mm_name[300];
char um_name[300];
char tmplyr_index[300];
char tmpname[10][300];
char FILENAME[300];
int result;
int kk;
int i;

    //constants to decribe the bowtie mrc marker
    
    MM_MULT = 1;
    UM_MULT = 1000;

    //varibles to keep count of each error type.
    airgap_cnt = 1;
    edge_cnt = 1;
    acidtrap_cnt = 1;
    reg_cnt = 1;
    drill_cnt = 1;
    unterm_cnt = 1;
    void_cnt = 1;
    sm_cnt = 1;
    others_cnt = 1;
    has_errors = 0;

    result = 0;

    if ( strcmp(inlyr,"")==0 )
	{
        strncpy(lyr,"all",10);
    }
    else
	{
		strncpy(lyr,inlyr,120);
        for(kk=0; kk < ( signed int) strlen(lyr); kk += 1)
		{
			lyr[kk]=tolower(lyr[kk]);
		}

    }

    // initialize counters to 0
    //layers["MRC_AIRGAP"] = 0
	strncpy(layers[0].layername,"MRC_AIRGAP",20);
	strncpy(layers[1].layername,"MRC_EDGE",20);
	strncpy(layers[2].layername,"MRC_ACIDTRAP",30);
	strncpy(layers[3].layername,"MRC_REG",30);
	strncpy(layers[4].layername,"MRC_DRILL",30);
    strncpy(layers[5].layername,"MRC_UNTERM",30);
    strncpy(layers[6].layername,"MRC_VOID",30);
    strncpy(layers[7].layername,"MRC_SM",30);
	strncpy(layers[8].layername,"MRC_OTHERS",30);

	layercount=9;

    if(!( in_lyr_switch( lyr)) )
	{
      result = 1;
      printf("Error: invalid mrc layer type\n"); //  | "cat 1>&2"
      exit(-1);
    } 
    // remove the header information from the cam mrc file

	file1=fopen(infilestr,"r");

	if ( file1==NULL)
	{
		printf("In mrcview, unable to open the input file = %s for reading \n",infilestr);
		exit(-1);
	}

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    cv_toupper(str_array[5],tmp);   // $6
    endoffile = FALSE;
    while( (strcmp(tmp,"MAGNITUDE")!=0) && (endoffile==FALSE ))
	{
        endoffile = getline(file1,thisline);
        cv_toupper(str_array[5],tmp);
    }

    if ( endoffile )
	{
      result = 1;
      printf( "Error: input file is corrupt,no MAGNITUDE found in column 6 \n");
      exit(-1);
    }

//************************************************************************
//main section 
// classifes errors according to type
//************************************************************************


  endoffile=getline(file1,thisline);
   NF=split_line(thisline);


  while( endoffile==FALSE)
  {
    x1spot = NF - 3;
    x2spot = NF - 1;
    y1spot = NF - 2;
    y2spot = NF;

   if( NF > 4)
   {
    if( (strstr(thisline,"Pad->Pad") != NULL) || 
		(strstr(thisline,"Pad->Trace")!=NULL) || 
		(strstr(thisline,"Trace->Trace")!=NULL) || 
		(strstr(thisline,"Min Feature")!=NULL) || 
		(strstr(thisline,"Plane->Plane")!=NULL) )
	{
         layers[0].count = airgap_cnt;   // MRC_AIRGAP
         mrc_airgap[airgap_cnt].val1 = (x1spot + x2spot) /2;
         mrc_airgap[airgap_cnt].val2 = (y1spot + y2spot) /2;
         airgap_cnt++;
         has_errors = 1;
    }
    else if( (strstr(thisline,"Pad->Edge")!=NULL) || 
		     (strstr(thisline,"Trace->Edge")!=NULL) )
	{ 
         layers[1].count = edge_cnt;                     // MRC_EDGE
         mrc_edge[edge_cnt].val1 = (x1spot + x2spot) /2;
         mrc_edge[edge_cnt].val2 = (y1spot + y2spot) /2;
         edge_cnt++;
         has_errors = 1;
    }
    else if( strstr(thisline,"Acid Trap" )!=NULL )
	{ 
         layers[2].count = acidtrap_cnt;    // MRC_ACIDTRAP
         mrc_acidtrap[acidtrap_cnt].val1 = (x1spot + x2spot) /2;
         mrc_acidtrap[acidtrap_cnt].val2 = (y1spot + y2spot) /2;
         acidtrap_cnt++;
         has_errors = 1;
    }
    else if( strstr(thisline,"Registration" )!= NULL)
	{ 
         layers[3].count = reg_cnt;                 // MRC_REG
         mrc_reg[reg_cnt].val1 = (x1spot + x2spot) /2;
         mrc_reg[reg_cnt].val2 = (y1spot + y2spot) /2;
         reg_cnt++;
         has_errors = 1;
    }
    else if( (strstr(thisline,"Annular Ring")!=NULL) || 
		     (strstr(thisline,"Drill Overlap")!=NULL) || 
			 (strstr(thisline,"Drill->Drill")!=NULL) || 
			 (strstr(thisline,"Drill->Pad")!=NULL) || 
			 (strstr(thisline,"Drill->Edge")!=NULL) || 
			 (strstr(thisline,"Drill->Trace")!=NULL)) 
	{ 
         layers[4].count = drill_cnt;       // MRC_DRILL
         mrc_drill[drill_cnt].val1 = (x1spot + x2spot) /2;
         mrc_drill[drill_cnt].val2 = (y1spot + y2spot) /2;
         drill_cnt++;
         has_errors = 1;
    }
    else if( strstr(thisline,"Unterm Trace")!= NULL)
	{
         layers[5].count = unterm_cnt;   // MRC_UNTERM
         mrc_unterm[unterm_cnt].val1 = (x1spot + x2spot) /2;
         mrc_unterm[unterm_cnt].val2 = (y1spot + y2spot) /2 ;
         unterm_cnt++;
         has_errors = 1;
    }
    else if( strstr(thisline,"Void!")!= 0 )
	{
         layers[6].count = void_cnt;     // MRC_VOID
         mrc_void[void_cnt].val1 = (x1spot + x2spot) /2;
         mrc_void[void_cnt].val2 = (y1spot + y2spot) /2;
         void_cnt++;
         has_errors = 1;
    }
    else if( (strstr(thisline,"Mask Web")!=NULL) || 
		     (strstr(thisline,"Mask->Circuit")!=NULL)) 
	{
         layers[7].count = sm_cnt;            // MRC_SM
         mrc_sm[sm_cnt].val1 = (x1spot + x2spot) /2;
         mrc_sm[sm_cnt].val2 = (y1spot + y2spot) /2 ;
         sm_cnt++;
         has_errors = 1;
    }
    else
	{
        layers[8].count = others_cnt;                  // MRC_OTHERS
        mrc_others[others_cnt].val1 = (x1spot + x2spot) /2;
        mrc_others[others_cnt].val1 = (y1spot + y2spot) /2;
        others_cnt++;
        has_errors = 1;
    }
   }

   endoffile=getline(file1,thisline);
   NF=split_line(thisline);

  }

  fclose(file1);


    cv_toupper(lyr,tmplyr_index);   
    if( (has_errors == 1 && result == 0 && (strcmp(lyr,"all")==0) ) || 
		    ( get_count(tmplyr_index) > 0))
	{
        split(FILENAME,tmpname[0],tmpname[1],".");
       // mm_name = (tmpname[1] "_mm.scr") 
        strncpy(mm_name,tmpname[0],120);
		strncat(mm_name,"_mm.scr",30);
        mm_namefile=fopen(mm_name,"w");

       // um_name = (tmpname[1] "_um.scr") 
		strncpy(um_name,tmpname[0],120);
		strncat(um_name,"_um.scr",30);
		um_namefile=fopen(um_name,"w");

        out_header(mm_namefile,lyr);
        out_header(um_namefile,lyr);
		for(kk=0; kk < (signed int ) strlen( lyr); kk += 1)
		{
          lyr[kk] = tolower(lyr[kk]);
		}
		i=0;
        while( i < layercount ){
		    strncpy(thislay,layers[i].layername,120);

           if( ( strcmp(thislay,"MRC_AIRGAP")==0) && ((strcmp(lyr,"all")==0) || 
			                       (strcmp(lyr,"mrc_airgap") ==0 ) ) ){
              select_apd_lyr(thislay, mm_namefile);
              select_apd_lyr(thislay, um_namefile);
              output_errors(mrc_airgap,layers[i].count,MM_MULT,mm_namefile);
              output_errors(mrc_airgap,layers[i].count,UM_MULT,um_namefile);
           }
           else if( (strcmp(thislay,"MRC_EDGE")==0) && ((strcmp(lyr,"all")==0)  || 
			                            (strcmp(lyr,"mrc_edge")==0 ))) {
              select_apd_lyr(thislay, mm_namefile);
              select_apd_lyr(thislay, um_namefile);
              output_errors(mrc_edge,layers[i].count,MM_MULT,mm_namefile);
              output_errors(mrc_edge,layers[i].count,UM_MULT,um_namefile);
           }
           else if ( (strcmp(thislay,"MRC_ACIDTRAP")==0) && ((strcmp(lyr,"all")==0) ||
			                               (strcmp(lyr,"mrc_acidtrap") == 0)) ) {
              select_apd_lyr(thislay, mm_namefile);
              select_apd_lyr(thislay, um_namefile);
              output_errors(mrc_acidtrap,layers[i].count,MM_MULT,mm_namefile);
              output_errors(mrc_acidtrap,layers[i].count,UM_MULT,um_namefile);
           }
           else if ( (strcmp(thislay,"MRC_REG")==0) &&  ((strcmp(lyr,"all")==0) || 
			                           (strcmp(lyr,"mrc_reg")==0) ) ) {
              select_apd_lyr(thislay, mm_namefile);
              select_apd_lyr(thislay, um_namefile);
              output_errors(mrc_reg,layers[i].count,MM_MULT,mm_namefile);
              output_errors(mrc_reg,layers[i].count,UM_MULT,um_namefile);
           }
           else if ( (strcmp(thislay,"MRC_DRILL")==0) && ((strcmp(lyr,"all")==0) || 
			                            (strcmp(lyr,"mrc_drill") == 0) ) ) {
              select_apd_lyr(thislay, mm_namefile);
              select_apd_lyr(thislay, um_namefile);
              output_errors(mrc_drill,layers[i].count,MM_MULT,mm_namefile);
              output_errors(mrc_drill,layers[i].count,UM_MULT,um_namefile);
           }
           else if ( (strcmp(thislay,"MRC_UNTERM")==0)  && ((strcmp(lyr,"all")==0) || 
			                              (strcmp(lyr,"mrc_unterm")==0) ) ) {
              select_apd_lyr(thislay, mm_namefile);
              select_apd_lyr(thislay, um_namefile);
              output_errors(mrc_unterm,layers[i].count,MM_MULT,mm_namefile);
              output_errors(mrc_unterm,layers[i].count,UM_MULT,um_namefile);
           }
           else if ( (strcmp(thislay,"MRC_VOID")==0) && ((strcmp(lyr,"all")==0) || 
			                           (strcmp(lyr,"mrc_void")==0) ) ) {
              select_apd_lyr(thislay, mm_namefile);
              select_apd_lyr(thislay, um_namefile);
              output_errors(mrc_void,layers[i].count,MM_MULT,mm_namefile);
              output_errors(mrc_void,layers[i].count,UM_MULT,um_namefile);
           }
           else if ( (strcmp(thislay,"MRC_SM")==0)  && ((strcmp(lyr,"all")==0) ||
			                          (strcmp(lyr,"mrc_sm")==0) ) ){
              select_apd_lyr(thislay, mm_namefile);
              select_apd_lyr(thislay, um_namefile);
              output_errors(mrc_sm,layers[i].count,MM_MULT,mm_namefile);
              output_errors(mrc_sm,layers[i].count,UM_MULT,um_namefile);
           }
           else if ( (strcmp(thislay,"MRC_OTHERS")==0) && ((strcmp(lyr,"all")==0) || 
			                             (strcmp(lyr,"mrc_others")==0) )) {
              select_apd_lyr(thislay, mm_namefile);
              select_apd_lyr(thislay, um_namefile);
              output_errors(mrc_others,layers[i].count,MM_MULT,mm_namefile);
              output_errors(mrc_others,layers[i].count,UM_MULT,um_namefile);
           }
		  i+=1;
         }
         fprintf(mm_namefile, "done\n"); // > mm_name
         fprintf(um_namefile, "done\n"); //  > um_name
         apd_lyr_on( mm_namefile,lyr);
         apd_lyr_on( um_namefile,lyr);
    }
	fclose(mm_namefile);
	fclose(um_namefile);

    if( result == 0 ) 
	{
        printf( "%-13s %10s\n","MRC TYPE","COUNT");
		i=0;
        while( i < layercount )
		{
		
            printf( "%-13s %8d\n",layers[i].layername,layers[i].count);
		  i += 1;
        }
    }
    exit(result);

}

/*
int main( int argc, char **argv)
{

	if (( argc != 2)  &&  (argc != 3) )
	{
		printf("In mrcview, wrong number of arguments \n");
		printf("Usage: mrcview infile   or   mrcview infile layer \n");
		exit(-1);
	}
	else
	{
		if (argc == 2)
		{
			mrcview_call( argv[1], "");
		}
		if (argc == 3)
		{
            mrcview_call( argv[1], argv[2]);
		}
	}

}  // end main

  */

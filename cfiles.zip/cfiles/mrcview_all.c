#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// mrcview_all tsa
// version 1.0 released 10/09/02

void mrcview_call( char *txtfile, char *layerswitchstr);

void mrcview_all_call( char *layerswitchstr)
{
int i;
int txtfilecount;
char thistxtfile[300];
int argcnt;
char basename[300];
char extstr[300];
char commandstr[300];

if (strcmp(layerswitchstr,"")==0)
{
	argcnt=1;
}
else
{
	argcnt=2;
}

if (argcnt== 1)
{
	 i=0;
	txtfilecount=scandir_matchext( ".",0,".txt");
    while( i < txtfilecount)        //  i in p*.txt
    {
	   strncpy(thistxtfile,scan_array[i],120);
	   split(thistxtfile,basename,extstr,".");
	   
	   strncpy(commandstr,"rm -f ",20);
	   strncat(commandstr,basename,120);
	   strncat(commandstr,"*.scr",10);
	    system(commandstr);
       printf("mrcview %s \n", thistxtfile);
       mrcview_call(thistxtfile,"");
	  i += 1;
    }
}
else if ( argcnt == 2 )
{
	txtfilecount=scandir_matchext( ".",0,".txt");
	i=0;
    while( i < txtfilecount)     //  i in p*.txt
    {
	   strncpy(thistxtfile,scan_array[i],120);
       split(thistxtfile,basename,extstr,".");
	
	   strncpy(commandstr,"rm -f ",20);
	   strncat(commandstr,basename,120);
	   strncat(commandstr,"*.scr",10);
	    system(commandstr);
       printf( "mrcview %s %s \n",thistxtfile,layerswitchstr);
       mrcview_call( thistxtfile,layerswitchstr); // $i $1
		i += 1;
    }
}

}  // end mrcview_all_call

int main( int argc, char **argv)
{
char progname[300];
char USAGE1[300];
char USAGE2[300];
char EXAMPLE1[300];
char EXAMPLE2[300];

//strncpy(progname,argv[0],120);

strncpy(USAGE1,"usage: mrcview_all ",80);

strncpy(USAGE2,"usage: mrcview_all layer_switch",80);

strncpy(EXAMPLE1,"\tex:  mrcview_all ",80);

strncpy(EXAMPLE2,"\tex:  mrcview_all mrc_airgap",80);

 if (( argc==1) || (argc==2) )
 {
	 if (argc == 1)
	 {
		 mrcview_all_call( "");
	 }
	 if (argc == 2)
	 {
		 mrcview_all_call( argv[1]);
	 }

 }
 else
 {
   printf( "ERROR: incorrect number of parameters in mrcview_all\n");
   printf("%s\n%s\n%s\n%s\n", USAGE1,EXAMPLE1,USAGE2,EXAMPLE2);
 }

} // end main


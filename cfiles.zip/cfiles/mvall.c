#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

void mvall_call( char *inext, char *outext)
{
int i;
int numfiles;
char name[300];
char thisext[300];
char fromfilestr[300];
char tofilestr[300];

  numfiles=scandir_matchext(".",0,inext);

  i=0;
  while( i < numfiles)   //  i in $tmp
  { 
     //name=${i%*$1}
	 split(scan_array[i],name,thisext,".");

     printf("Moving %s%s to %s%s\n",name,inext,name,outext);
	 strncpy( fromfilestr, name,120);
	 strncat(fromfilestr,inext,120);

	 strncpy(tofilestr,name,120);
	 strncat(tofilestr,outext,120);

	 cp_file( fromfilestr, tofilestr);
	 rm_file( fromfilestr);

     //mv $name$1  $name$2
	i +=1;
  }
}


int main( int argc, char **argv)
{
char USAGE[300];
char WHERE[300];
char EXAMPLE[300];

 strncpy(USAGE,"usage: mvall .from .to",100);
 strncpy(WHERE,"\tfrom/to are filename extensions (NEED dot)",120);

 strncpy(EXAMPLE,"\tex:  mvall .gbr .bkp (moves *.gbr to *.bkp)",120);

 if(argc != 3)
 {
   printf("In mvall, incorrect number of arguments\n");
   printf("%s\n%s\n%s\n",USAGE,WHERE,EXAMPLE);
   exit(-1);

 }
 else
 {
  mvall_call( argv[1], argv[2]);
 }

}  // end main
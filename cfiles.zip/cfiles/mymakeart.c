#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

 // cleanup core layer (274x only)


// function prototypes

int coreclean_call_out(char *infile, char *outfile);
int chkcenter_call( char *infile);
void off274x_call_out(char *infile ,char *xoff,char *yoff, char *outfile); 
int add00_call_out( char *thisart , char *tofilestr);

void mvall_byext( char *fromext, char *toext)
{
int kk;
int fromcount;
char thisfrom[300];
char name[300];
char ext[30];

    fromcount= scandir_matchext(".",0,fromext);

	kk=0;
	while(kk < fromcount)
	{
		strncpy(thisfrom, scan_array[kk],120);
		split(thisfrom,name,ext,".");
		strncat(name,toext,10);
		cp_file( thisfrom, name);
		rm_file(name);
	  kk += 1;
	}

} // mvall_byext

void mymakeart_call( )
{
int coreres;
int cenres;
char name[300];
char thisart[300];
char tofilestr[300];
char fromfilestr[300];
int i;
FILE *offvalfile;
char thisline[300];
int nf;
int endoffile;
int address;
int artcount;
char xoff[300];
char yoff[300];
char extstr[100];

 printf( "RUNNING coreclean \n");

 coreres= coreclean_call_out("core.art", "core.tmp");
// coreres=$?

 if ( coreres == 0 )
 {
    printf("core layer has been stripped\n ");
	cp_file("core.tmp","core.art");
	rm_file("core.tmp");
   // mv core.tmp core.art
 }
 else if ( coreres == 1 )
	{
    printf ("core layer OK as is\n");
    rm_file( "core.tmp");
	}
 else
 {
    printf("FATAL ERROR: don't know how to process core layer\n");
    printf("PROGRAM HALTED\n");
    exit(99);
 }

 // centerparts if needed (274x only)

 cenres=chkcenter_call( "outline.art");

// cenres=$?
 if( cenres == 0 )
 {
    printf("part is centered \n");
 }
 else
 {
    printf(" part is NOT centered \n");

	offvalfile=fopen("offval1","r");
	if (offvalfile==NULL)
	{
		printf("Unable to open the offval1 file for reading \n");
		exit(-1);
	}
	endoffile=getline(offvalfile,thisline);
	nf=split_line(thisline);

	if (nf > 1)
	{
		strncpy(xoff,str_array[0],40);
		strncpy(yoff,str_array[1],40);
	}
	else
	{
		printf("Format error in offval1 file \n");
		exit(-1);
	}
	fclose(offvalfile);

    //read xoff yoff < offval1

	artcount= scandir_matchext(".",0,".art");
	i=0;
    while(i < artcount)    // for i in *.art
    {
	  strncpy(thisart,scan_array[i],120);
	  split(thisart,name,extstr,".");
     // name=${i%.art}
      printf( "RUNNING off274x %s %s %s > %s.cen \n", thisart, xoff,yoff,name);

	  strncpy(tofilestr,name,120);   //$name.cen
	  strncat(tofilestr,".cen",10);

      off274x_call_out(thisart,xoff,yoff, tofilestr); // $i $xoff $yoff > $name.cen
	  i+=1;
    }
    mvall_byext( ".cen", ".art");
 }

 // add X0Y0D02 to all .art files (274x only)
 printf( "adding X0Y0D02 to all layers\n");

 artcount=scandir_matchext(".",0,".art");

 i=0;
 while(i < artcount)     // i in *.art
 {
   strncpy(thisart,scan_array[i],120);
   split(thisart,name,extstr,".");

   strncpy(tofilestr,name,120);  // $name.tmp
   strncat(tofilestr,".tmp",10);

   // name=${i%.art}
   address= add00_call_out( thisart , tofilestr);
   // address=$?
   if( address == 0 )
   {
	   strncpy(fromfilestr,name,120);  // $name.tmp
	   strncat(fromfilestr,".tmp",10);

	   strncpy(tofilestr,name,120);   // $name.art
	   strncat(tofilestr,".art",10);

	   cp_file(fromfilestr,tofilestr);
	   rm_file(fromfilestr);

     //mv $name.tmp $name.art
   }
   else
   {
     printf("unable to insert X0Y0D02* into %s correctly\n", thisart);
     exit(98);
   }
   i += 1;
 }

 rm_file( "offval1");

 }  // end mymakeart


int main( int argc, char **argv)
{
//int retcode;

	 if (argc != 1)
	 {
		 printf("mymakeart takes no arguments \n");
		 exit(-1);
	 }
	 else
	 {
		 mymakeart_call();
	 }

} // end main

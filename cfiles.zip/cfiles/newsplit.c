
#include <stdio.h>
#include <string.h>
#include <process.h>
#include <stdlib.h>
#include <ctype.h>


#define NULLCHAR 0
#define MAX_ABREV_TABLE 8
#define TRUE 1
#define FALSE 0

extern int _access( char *instr, int mode);


struct layerinfo
{
  char mmm_layer_name[120];
  char source_str[40];          // 
  char short_layer_name[10];    // ie 1a 2a etc
  char abrev_name[20];      // SM, NPD, BVIA etc
  char layer_name[100];   // long name for abrev_name
  int buried_via_begin;   // only valid for BVIA
  int buried_via_end;
} layer_table[100];

// table of layer abreviations and layer names
//   these abreviations are the last column of the 
//    the Layer Summary section of the .det report of the PAR tool
//
struct layerdesc
{
	char layer_abrev[20];
	char layer_name[120];
} layer_desc[100] = {{ "BVIA","Buried / Blind Via"},
{"SIG","Signal"},{"NPD","Non-plated Drill"},{"SM","Solder Mask"},
{"DRL","Drill"},{"PLN","Copper Plane"},{"DOC",""},{"OTL",""}};

//  This is a list of the section headers of the .det file
//    to search for when splitting the .det file
//
struct compstuff
{
 char compstr[120];
 char subdirstr[40];
 char filetypestr[10];
 int skiplines;
}  comp_array[100] = {{"Layer Summary","",".lsu",2},
                     {"Surface Mount Devices","",".smd",2},
{"Surface Mount Pads","",".smp",2},
{"Drilling","",".drl",2},
{"1a Signal","det",".l1a",2},
{"2a Signal","det",".l2a",2},
{"3d Buried / Blind Via","det",".l3d",2},
{"8a Signal","det",".l8a",2},
{"zzzz","",".zzz",2}};

int head_count = 7;    // only look at Layer Summary and SM
                        // for first pass thru file


char rlines[5000][120];

char token_array[40][140];

int retcode;

int start_index[5000];
int i,j,k,l,m,n;

int head_num;
int debug;
int debug_test;     // using mfc debugger

char openstr[120];
char newstr[120];


FILE *infile, *outfile ;


char dirstr[120];
char filetypestr[20];
char outfilestr[140];

char basefilestr[120];
int lines_in;

char thisline[120];

// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return ( 1);
 }
}

// tokenize a line delimited by spaces
//   return number of tokens

int bust_line(char *instring)
{
int token_count;
char * pch;
char thisstring[140];


token_count = 0;

strncpy(thisstring,instring,120);
thisstring[strlen(instring)-1]=';';


//printf ("Splitting string \"%s\" in tokens:\n",thisstring);

pch = strtok (thisstring," ");

while (pch != NULL)
  {
    // printf ("next token = %s\n",pch);
    if ( token_count < 40 )
	{
		strncpy( token_array[token_count], pch, 120);
        pch = strtok (NULL, " ;");
		if ( token_array[token_count][0] != ' ')
		{
	    token_count += 1;
		}
	}
    else
	{
		printf("Too many tokens on line = %s \n", instring );
	}
}
  return token_count;
}

// remove all trailing and preceeding spaces from a line
//
void trim_line( char *thisline, char *newstr)
{
int ll;
int nn;

ll = 0;                     // make sure the info from thisline
		                            // 
 while( ( ll < strlen(thisline)) && ( thisline[ll] == ' '))
 {
			 ll += 1;               // skip any preceeding blanks
 }
 nn=0;
 while(  ll < strlen(thisline))
 { 
  newstr[nn] = thisline[ll];   // get the rest of the line
  ll += 1;
  nn += 1;
 }

 newstr[nn] = 0;
 if ( nn > 0 ) { nn = nn-1; }

 while((newstr[nn] == ' ') && ( nn > 0 ))  // go backwards from end
 {
			nn-= 1;
 }
 newstr[nn+1] = 0;

} // end trim_line

//
// find the given abreviation in the list of abreviations vs names
//
int find_in_table( char *abrev_in_str )
{
int abrev_found;
int kk;

 abrev_found = FALSE;

 kk = 0;
 while ( ( kk< MAX_ABREV_TABLE) && ( abrev_found == FALSE))
 {
	// printf("Comparing %s to %s \n",abrev_in_str,
		 //                layer_table[kk].abrev_name);

	 if ( strcmp( abrev_in_str, layer_desc[kk].layer_abrev) == 0)
	 {
		 abrev_found = TRUE;
		 return(kk);
	 }
	kk += 1;
 }

 if (( kk == MAX_ABREV_TABLE ) && (abrev_found == FALSE))
	{
	 printf("Error: Could not find abreviation = %s in table \n",
		  abrev_in_str);
 }
 return(-1);

}


//
// make a sub directory
//
void mkdir ( char *infilestr)
{
char commandstr[120];

strncpy( commandstr,"mkdir ",30);
strcat( commandstr,infilestr);

system( commandstr);
}

int main ( int argc, char **argv)

{

// set debug flag

  debug = 0;
    
 if (argc < 2)
 {
	 printf("Usage: splitgen fname \n");
	 exit(-1);
 }

 debug_test = 0;

 if ( debug_test == 0 )    // if not debugging using mfc
 { 
	 strncpy( openstr,argv[1],120); 
 }
 else
 {
 strncpy( openstr,"aio.det",20);   // for mfc debug
 }

 infile = fopen( openstr ,"r");
 
 if ( infile == NULL)
 {
	 printf("Error: Unable to open the input file %s \n", openstr);
	 exit(-1);

 }

 strncpy( basefilestr, openstr, 120);

 k = 0;
 while( ( k < strlen(basefilestr) ) && ( basefilestr[k] != '.' ))
	{
	  k += 1;
	}
 basefilestr[k] = NULLCHAR;


// do the main split here

 k = 0;               // first, find the number of headers

 while(( k < 100 ) && ((comp_array[k].compstr[0] != 'z') 
	            |   ( comp_array[k].compstr[1] != 'z') 
				|   ( comp_array[k].compstr[2] != 'z')) )
	{
	  k += 1;
	}
  
  head_count = k;

  if (debug)
  {
    for ( k = 0; k < head_count; k += 1)
	{
	  printf("compare string = %s k = %d dir = %s \n",
      comp_array[k].compstr,k, comp_array[k].subdirstr);
	}
  }

 for (i = 0; i < 5000; i += 1)
   {
    start_index[i] = 0;
   }
    
 
 infile = fopen( openstr,"r");

 k = 0;
 while( ( k < strlen(basefilestr) ) && ( basefilestr[k] != '.' ))
	{
	  k += 1;
	}
 basefilestr[k] = NULLCHAR;

 if ( infile == NULL)
   {
      printf("Cannot open the input file = %s \n", openstr);
   }

 lines_in = 0;

 while ( getline(infile, thisline) == 0)
    {
	  // printf("Line in = %s \n", thisline);
	   thisline[strlen(thisline)-1] = 0;      // turn CR to NULL

      for ( k = 0; k < head_count; k += 1)
        {
		 trim_line( thisline, newstr);

		 // printf("Comparing [%s] to [%s] \n", newstr, comp_array[k].compstr);

         if (strstr(newstr, comp_array[k].compstr) != NULL)   // a header found
            {
			 if (strlen(newstr) == strlen(comp_array[k].compstr))
			 {
             start_index[lines_in] = k + 1;
			 }
			 // printf("Setting start_index at %d to %d \n", lines_in,k+1);
            }
         }
      strncpy( rlines[lines_in], thisline, 120);
	  // printf("rline = %s \n", rlines[lines_in]);

      lines_in += 1;
	  // printf("lines_in = %d \n", lines_in);
    }

  fclose(infile);

  i = 0;
  // printf("lines in = %d \n", lines_in);

  while( i < lines_in)
    {
      if (start_index[i] > 0 )
        {
          head_num = start_index[i] -1;
          strncpy( dirstr,comp_array[head_num].subdirstr,120);
          strncpy( filetypestr,comp_array[head_num].filetypestr,20);
          i += 1;
          if (strstr(rlines[i],"----") != NULL)  // dash underline
           {
            if (strlen( dirstr) > 0 )
              {
			   retcode = _access( dirstr,0);
			   if (retcode == -1)   // if there isn't one already
			   {
                mkdir( dirstr);   // make a sub dir, if it doesn't exist already
			   }
               strncpy( outfilestr,dirstr,120);
               strcat(outfilestr,"\\");
			   strcat(outfilestr,basefilestr);
		//	   strcat(outfilestr,".");
               strcat(outfilestr,filetypestr);

               }
             else
               {
                strncpy( outfilestr,basefilestr,120);
                strcat( outfilestr, filetypestr);
                }

             outfile = fopen(  outfilestr,"w"); // open the new file
			 if ( i > 0)
			 {
             fprintf(outfile,"%s\n",rlines[i-1]);
			 }
             while(( start_index[i] == 0 ) && ( i < lines_in))
              {
                 fprintf(outfile,"%s\n",rlines[i]);
                 i += 1;
               }
              fclose( outfile);
              i = i -1;
             }
           }
      i += 1;
    }
          
           
}  // end main
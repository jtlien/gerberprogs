#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAXLINES 100000

#include "utilprogs.h"

//  number.awk  rev 1.0  7/28/95
//  written by Ted Ammann
//
//  This program is meant to work on the following temporary files
//     .dist   .dist is the output of length.awk 
//     .pins   .pins is the output of pins_via.awk

//  To view these temp. files modify the create_probe script
//  by commenting out the line that deletes the temp files.
//  ( change it back when done)  ;^)

//  This program combines the information in the two above files as well
//  as adds unique net numbers to each net.

//  The results from pins_via.awk are meant to be redirected (UNIX ">") to 
//  the .dat file which is the finished output probe file for test.

//  The output of this program is a multi-column file with the following format
//    x-coord    y-coord  net//  Layer  ref.des.  pin //   netname    Lentgh (opt.)
//                                                                  (ECL only)
//  Sample Output
//   -4.0006    -5.7730    21    U       U2       B7       D01I01     2.6045
//   -4.2507    -5.7730    21    U       U2       B6       D01I01     2.6045
//   -3.7506    -5.7730    22    U       U2       B8       D01I02     3.4860
//   -3.8756    -5.9890    22    U       U2       A6       D01I02     3.4860


// file1 below is a command line parameter specifing the name of the file
// that contains the net length information for each net ( for us the temporary
// file .dist)

// The BEGIN section of the this program creates an array (a) whose subsripts
// are the net name and the elements contain the line length of that net.
// It also  initializes the variable netnum to 1 


int array_count;

int array_index;
int names_index;


struct namestuff
{
	char net_name[100];
	int netnum;

} mynames[MAXLINES];


struct diststuff
{
	char net_name[100];
	char len_str[40];

} dist_array[MAXLINES];


int find_in_dist( char *instr, int count)
{
int ii;
int is_found;

 ii = 0;

 is_found = FALSE;

 while(( ii < count) && ( is_found == FALSE))
 {
  if (strcmp( dist_array[ii].net_name, instr) == 0 )
  {
	  is_found = TRUE;
	  return(ii);
  }
 ii += 1;
 }

 return(-1);

} // end find_in_dist


void number_call_out( char *infile1str, char *infile2str, char *outfilestr)
{
int netnum;
int endoffile;
FILE *file1;
FILE *file2;
FILE *outfile;
char thisline[200];
int number_fields;
int array_count;
char name[120];	  


      netnum = 1;  // net numbers start at 1
       
     file1  = fopen(infile1str, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
	 }

        // get the net names and line lengths for the .dist file

     endoffile = getline(file1,thisline);
     number_fields = split_line(thisline);

	 array_count = 0;
     while (endoffile == FALSE)
	 {
		  
	   if ( array_count < MAXLINES)
		  {
           strncpy(dist_array[array_count].len_str,str_array[1],40);
		   strncpy(dist_array[array_count].net_name,str_array[0],100);
		  }
	   else
		  {
			printf("Number of pins exceeds limit = %d \n", MAXLINES);
			exit(-1);
		  }

        endoffile = getline(file1,thisline);
		number_fields = split_line(thisline);
	    array_count += 1;
       }

	fclose(file1);

 
	// Now read the second file, the .pins file
    // process the first line so that name has a value for the first 
    // if statement in MAIN 

    file2 = fopen(infile2str, "r");

    if (file2 == NULL)
	   {
	    printf("Error: Unable to open input file = %s \n",infile2str);
	    exit(-1);
	   }

    outfile = fopen(outfilestr, "w");

    if (outfile == NULL)
	   {
	    printf("Error: Unable to open output file = %s \n",outfilestr);
	    exit(-1);
	   }

    endoffile = getline(file2,thisline);
    number_fields = split_line(thisline);

    strncpy(name, str_array[5], 120);

    array_index = find_in_dist( str_array[5], array_count);  // find netname in dist array
 
    if( array_index != -1 ) 
		{    
		   fprintf(outfile,"%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),netnum);
           fprintf(outfile," %3s %5s %5s",str_array[2],str_array[3],str_array[4]);
           fprintf(outfile,"%20s %10.4f\n",str_array[5],atof(dist_array[array_index].len_str));
        }
    else 
		{
           fprintf(outfile,"%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),netnum);
           fprintf(outfile," %3s %5s %5s",str_array[2],str_array[3],str_array[4]);
           fprintf(outfile,"%20s\n",str_array[5]);
        }


//********** START OF MAIN LOOP***********************

  endoffile = getline(file2,thisline);
  number_fields = split_line(thisline);

  while(endoffile == FALSE)
  {
  // if the name in column 6 is different than the current name update 
  // name and netnum
  // 

   if( strcmp(name,str_array[5] ) != 0  )  // check if not already there
   {
	  strncpy(name,str_array[5],120);

      netnum++;
   }

  // the statement "if( $6 in a )" is basically asking if the net is an ECL
  // net?  If it is then output the data with the correct line length ( a[$6]
  // below ).  If it is not an ECL net then no line length is output.
  // It is recommended to the reader that he/she reads the AWK man pages 
  // for further info on the "in" statement. It is asking if $6 is a subsript
  // in the array a ( not if $6 is an element of array a ( A BIG DIFFERENCE)).
  
   // array_index = BinarySearch( a ,str_array[5],array_count);

   array_index = find_in_dist( str_array[5],array_count);  // find netname in dist array

   if (array_index != -1)    // an ECL net
   {
      
       fprintf(outfile,"%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),
		    netnum);
	  
       fprintf(outfile," %3s %5s %5s",str_array[2],str_array[3],str_array[4]);
       fprintf(outfile,"%20s %10.4f\n",str_array[5],atof(dist_array[array_index].len_str));
    }
    else  // non ECL net
    {
      
       fprintf(outfile,"%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),
		   netnum);
	   
       fprintf(outfile," %3s %5s %5s",str_array[2],str_array[3],str_array[4]);
       fprintf(outfile,"%20s\n",str_array[5]);
	}
  
  endoffile = getline(file2,thisline);
  number_fields = split_line(thisline);

 }

 fclose(file2);
 fclose(outfile);

} // end number_call_out

void number_call( char *infile1str, char *infile2str)
{
int netnum;
int endoffile;
FILE *file1;
FILE *file2;
char thisline[200];
int number_fields;
int array_count;
char name[120];	  

	   
      netnum = 1;  // net numbers start at 1
       
     file1  = fopen(infile1str, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
	 }

        // get the net names and line lengths for the .dist file

     endoffile = getline(file1,thisline);
     number_fields = split_line(thisline);

	 array_count = 0;
     while (endoffile == FALSE)
	 {
		  
	   if ( array_count < MAXLINES)
		  {
           strncpy(dist_array[array_count].len_str,str_array[1],40);
		   strncpy(dist_array[array_count].net_name,str_array[0],100);

		  }
	   else
		  {
			printf("Number of pins exceeds limit = %d \n", MAXLINES);
			exit(-1);
		  }

          endoffile = getline(file1,thisline);
		  number_fields = split_line(thisline);
		  array_count += 1;
       }

	fclose(file1);

 
	// Now read the second file, the .pins file
    // process the first line so that name has a value for the first 
    // if statement in MAIN 

    file2 = fopen(infile2str, "r");

    if (file2 == NULL)
	   {
	    printf("Error: Unable to open input file = %s \n",infile2str);
	    exit(-1);
	   }

    endoffile = getline(file2,thisline);
    number_fields = split_line(thisline);

    strncpy(name, str_array[5], 120);

    array_index = find_in_dist( str_array[5], array_count);  // find netname in dist array
 
    if( array_index != -1 ) 
		{    
		   printf("%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),netnum);
           printf(" %3s %5s %5s",str_array[2],str_array[3],str_array[4]);
           printf("%20s %10.4f\n",str_array[5],atof(dist_array[array_index].len_str));
        }
    else 
		{
           printf("%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),netnum);
           printf(" %3s %5s %5s",str_array[2],str_array[3],str_array[4]);
           printf("%20s\n",str_array[5]);
        }


//********** START OF MAIN LOOP***********************

  endoffile = getline(file2,thisline);
  number_fields = split_line(thisline);

  while(endoffile == FALSE)
  {
  // if the name in column 6 is different than the current name update 
  // name and netnum
  //


   if(  strcmp(name,str_array[5]) != 0 )  // check if not already there
   {
     
	  strncpy(name,str_array[5],120);

      netnum++;
   }

  // the statement "if( $6 in a )" is basically asking if the net is an ECL
  // net?  If it is then output the data with the correct line length ( a[$6]
  // below ).  If it is not an ECL net then no line length is output.
  // It is recommended to the reader that he/she reads the AWK man pages 
  // for further info on the "in" statement. It is asking if $6 is a subsript
  // in the array a ( not if $6 is an element of array a ( A BIG DIFFERENCE)).
  
   // array_index = BinarySearch( a ,str_array[5],array_count);

   array_index = find_in_dist( str_array[5],array_count);  // find netname in dist array

   // names_index = find_in_mynames( str_array[5],netnum);

   if (array_index != -1)    // an ECL net
   {
       
       printf("%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),
		    netnum);
	   
       printf(" %3s %5s %5s",str_array[2],str_array[3],str_array[4]);
       printf("%20s %10.4f\n",str_array[5],atof(dist_array[array_index].len_str));
    }
    else  // non ECL net
    {
      
       printf("%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),
		  netnum);
       
       printf(" %3s %5s %5s",str_array[2],str_array[3],str_array[4]);
       printf("%20s\n",str_array[5]);
	}
  
  endoffile = getline(file2,thisline);
  number_fields = split_line(thisline);

 }

 fclose(file2);

} // end number_call

/*
int main( int argc, char **argv)
{

	if (argc != 3)
	{
		printf("In number, wrong number of arguments \n");
		printf("Usage: number  fname1 fname2 \n");
		exit(-1);
	}
    else
	{
		number_call(argv[1],argv[2]);
	}


}
*/

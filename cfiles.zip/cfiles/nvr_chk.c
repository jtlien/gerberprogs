#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  nvr_chk.awk  rev 1.0  7/28/95
//  written by Ted Ammann
//
//  This program is meant to work on the Allegro .tech report file.

//  The output of this program is a summary of all the NEVER_CHECK lines 
//  in the .tech file. The output from this program is meant to be redirected
//  (UNIX ">") to a file which is the finished output report file for
//  the design.

// SAMPLE OUTPUT
//           (physicalOpFlags
//                (physicalLayerGroup "L01"
//                    (maxBlindBuriedViaStaggerDistance NEVER_CHECK)
//                    (maxNumberOfCrossings NEVER_CHECK)
//                    (minDistanceBetweenCrossings NEVER_CHECK)
//                    (minEndSegmentLength NEVER_CHECK)
//                    (maxBondingWireLength NEVER_CHECK)
//                    (minBondingWireLength NEVER_CHECK)

// The BEGIN section simply assigns a 1 to the variable VALUE.
// VALUE is used as a boolean where a 0 (zero) is FALSE and any non-zero
// value is a TRUE

void nvr_chk_call_out( char *infilestr , char *outfilestr)
 {
int endoffile;
char thisline[200];
char aline[200];
FILE *file1;
FILE *outfile;

int VALUE;

  VALUE = 1;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  outfile  = fopen(outfilestr, "w");

  if (outfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
  }

//*********** START OF MAIN ******************************************
// The descriptions below assume the reader understands the .tech file
//********************************************************************

  endoffile = getline( file1, thisline);

  while( endoffile == FALSE)

  {
  // The following if statement acts as a switch for two of the if statements
  // below.  THe are two main sections in the .tech file the first section has 
  // the "NEVER/ALWAYS CHECK info and the second has the physical/spacing data
  // Once we get past the first section we no longer want to output lines 
  // that contain the words physical or spacing.

  if (strstr(thisline,"physicalSetName" ) != NULL)
       VALUE = 0;

  // If VALUE is TRUE (i.e. we have not gone past the first section)
  // Simply output any lines that contain "physical" or "NEVER" or "spacing"

  if (( VALUE ) && ( (strstr(thisline,"physical")!= NULL) 
	      || (strstr(thisline,"NEVER") != NULL) || 
		     (strstr(thisline,"spacing") != NULL ) ) )

     fprintf(outfile,"%s",thisline);
  
  // special case we want the line that contains electricalSetName

  if( strstr(thisline,"electricalSetName") != NULL)
     fprintf(outfile,"%s",thisline);


  // after the physical/spacing data section there is a small section
  // that contains info on the electricalSet we want the NEVER_CHECK
  // lines from that section.
  // However, that info is contained on two lines the first line contain
  // the rule name and the next line tells whether it was checked or not.
  // In order to output the name the complete input line is assigned to
  // to a variable called aline ( any line that doesn't contain the word NEVER
  // is considered to be a rule name.
  // The else portion of the if is only valid after the "switch" if above
  // (i.e VALUE has been set to 0.
  // effectively - This if/else  statement takes effect after physical/spacing
  // data section. The out come of this if/else is that for every line that
  // contains the word NEVER that line and the line directly above are output
  // to the report file. (Follow That ??)

  if(  strstr(thisline,"NEVER" ) == NULL)
  { 
       strncpy( aline, thisline, 100);
  }
  else if(( !VALUE ) && (strstr(thisline,"NEVER") != NULL))
  {
      fprintf(outfile,"%s",aline);
      fprintf(outfile,"%s",thisline);
  }   

  endoffile = getline(file1, thisline);

 } // end of main while loop

 fclose(file1);
 fclose(outfile);

} // end of nvr_chk_call


void nvr_chk_call( char *infilestr )
 {
int endoffile;
char thisline[200];
char aline[200];
FILE *file1;

int VALUE;

  VALUE = 1;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

//*********** START OF MAIN ******************************************
// The descriptions below assume the reader understands the .tech file
//********************************************************************

  endoffile = getline( file1, thisline);

  while( endoffile == FALSE)

  {
  // The following if statement acts as a switch for two of the if statements
  // below.  THe are two main sections in the .tech file the first section has 
  // the "NEVER/ALWAYS CHECK info and the second has the physical/spacing data
  // Once we get past the first section we no longer want to output lines 
  // that contain the words physical or spacing.

  if (strstr(thisline,"physicalSetName" ) != NULL)
       VALUE = 0;

  // If VALUE is TRUE (i.e. we have not gone past the first section)
  // Simply output any lines that contain "physical" or "NEVER" or "spacing"

  if (( VALUE ) && ( (strstr(thisline,"physical")!= NULL) 
	      || (strstr(thisline,"NEVER") != NULL) || 
		     (strstr(thisline,"spacing") != NULL ) ) )

     printf("%s",thisline);
  
  // special case we want the line that contains electricalSetName

  if( strstr(thisline,"electricalSetName") != NULL)
     printf("%s",thisline);


  // after the physical/spacing data section there is a small section
  // that contains info on the electricalSet we want the NEVER_CHECK
  // lines from that section.
  // However, that info is contained on two lines the first line contain
  // the rule name and the next line tells whether it was checked or not.
  // In order to output the name the complete input line is assigned to
  // to a variable called aline ( any line that doesn't contain the word NEVER
  // is considered to be a rule name.
  // The else portion of the if is only valid after the "switch" if above
  // (i.e VALUE has been set to 0.
  // effectively - This if/else  statement takes effect after physical/spacing
  // data section. The out come of this if/else is that for every line that
  // contains the word NEVER that line and the line directly above are output
  // to the report file. (Follow That ??)

  if(  strstr(thisline,"NEVER" ) == NULL)
  { 
       strncpy( aline, thisline, 100);
  }
  else if(( !VALUE ) && (strstr(thisline,"NEVER") != NULL))
  {
      printf("%s",aline);
      printf("%s",thisline);
  }   

  endoffile = getline(file1, thisline);

 } // end of main while loop

  fclose(file1);

} // end of nvr_chk_call

/*
int main(int argc, char **argv)
{


	if (argc != 2)
	{
       printf("Error: nvr_chk wrong number of arguments \n");
	   printf("Usage: nvr_chk infile1 \n");
	   exit(-1);
	}
	else
	{
		nvr_chk_call( argv[1]);
	}

}  // end main

  */
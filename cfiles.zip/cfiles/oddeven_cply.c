#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"



int oddeven_cply_call( char *infname)
{

int min;
int max;
char name[20];
char outname[120];
int i;
char thisline[200];
int nf;
int endoffile;
int compval;
// char istr[120];
// char hash_outstr[120];
FILE *file1;
char out[10][120];
int debug;
char tstr[120];
char save_array[1000][120];
int tval;

  debug=0;
  for(i=0; i < 1000; i += 1)
  {
	  save_array[i][0]= '\0';
  }
	
  file1  = fopen(infname, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infname);
	  exit(-1);
	}

  min = 999;
  max = -999;

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {
	if (nf > 4)
	{
		if(debug) { printf("In oddeven, strings = %s %s %s \n",str_array[0],
			str_array[1],str_array[2],str_array[3],str_array[4]); }


        if((strcmp(str_array[2],"TSM")== 0) ||
        (strcmp(str_array[2],"TSP")== 0) ||
		(strcmp(str_array[2],"BSM")== 0) || 
        (strcmp(str_array[2],"BSP")== 0) || 
		(strcmp(str_array[2],"METAL")==0) ||
		(strcmp(str_array[2],"CPLY1")==0) ||
        (strcmp(str_array[2],"POLY")==0) ||
		(strcmp(str_array[2],"TESTIN")==0))
		{

		tval=atoi(str_array[3]);
		sprintf(tstr,"%d",tval);

        // add_to_hash(str_array[3],str_array[1]);   // array[$4] = $2;

		if (tval < 0 )
		{
			tval += 500;
		}
		if (debug) { printf("saveing to hash at %d , %s \n",tval,str_array[1]); }

		strncpy(save_array[tval],str_array[1],120);

	    compval=atoi(str_array[3]);

	    if( compval < min)
	      min = compval;
        if( compval > max )
	      max = compval;
     }
	}
	endoffile=getline(file1,thisline);
	nf=split_line(thisline);

  }
  fclose(file1);

  strncpy(name,"odd.y",10);


   for( i = min ; i <= max; i++)
   {
	if (i < 0 )
	{
		tval=i+500;
	}
	else
	{
		tval=i;
	}
    if( strlen( save_array[tval] ) > 0  )
	 {
	   split(save_array[tval],out[0],out[1],".");
	   strncpy(outname,out[0],80);
	   strcat(outname,".y");

	  // command = ("cp " name " " outname)
	  // system(command);

	   if (debug) { printf("In oddeven, copy %s to %s i=%d \n",name,outname,i); }
	   cp_file(name,outname);

       if( strcmp(name,"odd.y") == 0)
	   {
	    strncpy(name,"even.y",20);
	   }
       else
	   {
	    strncpy(name,"odd.y",20);
	   }
	}
    else
	{
		// printf("In oddeven, hash error i=%d\n",i);
	}
   }

  return(0);

}  // end oddeven_cply_call

int main( int argc, char **argv)
{

  if ( argc != 2)
  {
	  printf("In oddeven_cply, wrong number of arguments \n");
	  printf("Usage: oddeven_cply layersfile \n");
	  exit(-1);
  }
  else
  {
    oddeven_cply_call(argv[1]);
  }


}  // end main

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINELEN  81

void getstring( char*  val, char* myval)
{
  
  val++;
  *myval= *val; 
  val++;
  myval++;
  while( isdigit(*val) ){
     *myval = *val ;
     val++;
     myval++;
  }
  *myval = '\0';
}
void getbefore(const char* mystring, char*  myval, char mychar){
  while( *mystring != mychar ){
     *myval = *mystring ;
     mystring++;
     myval++;
  }
  *myval = '\0';
}

ProcessString(char thestring[], int  Xval, int Yval)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
    
     char X[LINELEN];
     char Y[LINELEN];
     char D[LINELEN];
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
	 placeD = strchr( thestring,  'D');      // added this because placeD wasn't inited

    // placeD = strchr( thestring, 'D');
     if( (placeX != NULL) && (placeY != NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring(placeX,X);
	 getstring(placeY,Y);
	// getafter(thestring,REST,'Y');
	printf( "%s",FIRST);
	printf("X%dY%dD%s*\n",atoi(X)+  Xval,atoi(Y)+ Yval ,D );
     }
     else if (   placeX != NULL )
	 {
         getstring(placeX,X);
	     getstring(placeD,D);
	     printf("X%dD%s*\n",atoi(X)+  Xval ,D );
     }
     else if (  placeY != NULL ){
	 getstring(placeY,Y);
	 getstring(placeD,D);
	printf("Y%dD%s*\n",atoi(Y)+  Yval,D );
     }
     else {                         // if ( strchr(thestring , 'M') == NULL){
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

 FILE*  INFILE;

void off274x_call(char *infilestr, char *xvalstr, char *yvalstr)
{
   int Xvalue;
   int Yvalue;
char line[LINELEN];

   Xvalue = atoi( xvalstr);
   Yvalue = atoi( yvalstr);
   
   INFILE =  fopen( infilestr ,"r");
   if (INFILE != NULL){
       while( fgets(line, LINELEN, INFILE) != NULL)
	   {
          ProcessString(line, Xvalue, Yvalue );
       } 
   }
}


int main( int argc, char **argv)
{
    if (argc != 4)
	{
	 printf("In off274x, wrong number of arguments \n");
	 printf("Usage: off274x infile xval yval \n");
	 exit(-1);
	}
	else
	{
	off274x_call( argv[1], argv[2], argv[3]);
	}

} 


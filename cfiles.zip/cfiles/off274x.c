#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINELEN  81

void getstring274( val , myval)
char*  val; char*  myval;
{
  val++;
  *myval= *val; 
  val++;
  myval++;
  while( isdigit(*val) ){
     *myval = *val ;
     val++;
     myval++;
  }
  *myval = '\0';
}

void getbefore( mystring, myval , mychar)
char* mystring; char* myval ; char mychar;
{
  while( *mystring != mychar ){
     *myval = *mystring ;
     mystring++;
     myval++;
  }
  *myval = '\0';
}

void getrest( instring,  outstring,  mychar)
char*  instring; char*  outstring; char mychar;
{
  while( *instring != mychar ){
     instring++;
  }
  instring++;
  while( isdigit(*instring) || *instring == '-' ){
    instring++;
  }

  while( *instring != '\0' ){
       *outstring = *instring ;
       outstring++;
       instring++;
  }
  *outstring = '\0';
}

void ProcessString274(char *thestring, int Xval, int Yval)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];
    
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 printf("%sX%dY%d%s",FIRST,atoi(X)+  Xval,atoi(Y)+ Yval, REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	printf("%sX%d%s",FIRST,atoi(X)+  Xval ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	printf("%sY%d%s",FIRST,atoi(Y)+  Yval,REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

void ProcessStringOut274(char *thestring,int  Xval, int  Yval, FILE *ofile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];

     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 fprintf(ofile,"%sX%dY%d%s",FIRST,atoi(X)+  Xval,atoi(Y)+ Yval, REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	fprintf(ofile,"%sX%d%s",FIRST,atoi(X)+  Xval ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	fprintf(ofile,"%sY%d%s",FIRST,atoi(Y)+  Yval,REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       fprintf(ofile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

void off274x_call_out( char *infilestr, char *xvalstr, char *yvalstr, 
					  char *outfilestr)
{
FILE*  INFILE;
FILE* outfile;
char *getres;

   int Xvalue;
   int Yvalue;

   char line[LINELEN];
   Xvalue = atoi( xvalstr);
   Yvalue = atoi( yvalstr);

   outfile =  fopen( outfilestr,"w");
   if (outfile==NULL)
   {
	   printf("In off274x, unable to open the output file = %s \n", outfilestr);
	   exit(-1);
   }

   INFILE =  fopen( infilestr,"r");
   if (INFILE != NULL)
   {
       getres=fgets(line, LINELEN, INFILE) ; 
       while( getres != NULL)
	   { 
		  
          ProcessStringOut274(line, Xvalue, Yvalue, outfile);
		  getres=fgets(line, LINELEN, INFILE) ; 
       } 
   }
   else
   {
	   printf("In off274x, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }
   fclose(INFILE);
   fclose(outfile);

}  // off274x_call_out

void off274x_call( char *infilestr, char *xvalstr, char *yvalstr)
					
{
FILE*  INFILE;
char *getres;

   int Xvalue;
   int Yvalue;

   char line[LINELEN];
   Xvalue = atoi( xvalstr);
   Yvalue = atoi( yvalstr);

   INFILE =  fopen( infilestr,"r");
   if (INFILE != NULL)
   {
       getres= fgets(line, LINELEN, INFILE) ; 
       while( getres != NULL){
          ProcessString274(line, Xvalue, Yvalue );
		  getres= fgets(line, LINELEN, INFILE) ; 
       } 
   }
   else
   {
	   printf("In off274x, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }
   fclose(INFILE);

}

int main( int argc, char **argv)
{
    if (argc != 4)
	{
	 printf("In off274x, wrong number of arguments \n");
	 printf("Usage: off274x infile xval yval \n");
	 exit(-1);
	}
	else
	{
	off274x_call( argv[1], argv[2], argv[3]);
	}

} 


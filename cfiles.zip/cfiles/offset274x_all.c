#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include "dirent.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


#include "utilprogs.h"

//
//  This program is used to fix up the gerber output so that it has 
//      a * at the end of every line.   Also changes the M00 at the
//      end of the file to M02.
//



char fromfilestr[300];
char tofilestr[300];



int file_count;
int i;

char newfname[300];


void off274x_call_out(char *infilestr, char *xvalstr, char *yvalstr, char *outfilestr);


// first parameter is a directory
//   find all the files in the directory that end with .gbr
//   and run addstar on them and put the results into .gbrf

int main( int argc, char **argv)
{

int debug;

    debug = 0;

 
	if (argc ==3)
	{

	 file_count = scandir_matchext(".",0,".gbx");  // get all .gbx files

	 // printf("file count = %d \n", file_count);

	 for(i=0; i < file_count; i += 1)
	 {
	  

	   replace_ext( scan_array[i], newfname,".fgbx");

	   if (debug)
	   {
	   printf("Scan array = %s newfname = %s \n",scan_array[i], newfname);
	   }

	   strncpy(fromfilestr,scan_array[i],120);

	   if (debug)
	   {
	   printf("fromfilestr = %s \n",fromfilestr);
	   }


      // printf("test i = %d \n",i);

	   
       strncpy(tofilestr,newfname,120);

	   strncpy(fromfilestr,scan_array[i],120);

	   if (debug)
	   {
       printf("newfname = %s scan_array[i] = %s fromfilestr = %s tofilestr = %s \n",
		   newfname, scan_array[i], fromfilestr, tofilestr);
	   }

       off274x_call_out( fromfilestr, argv[1], argv[2], tofilestr);  // update the original

	 }


	} 
   else
   {
	   printf("Wrong number of arguments to off274x_all \n");
	   printf("Usage: off274x_all xoff yoff \n");
	   printf(" will run off274x on all .gbx files and put them in .fgbx files \n");
   }

}

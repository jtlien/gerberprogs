#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void openup_call()
{
char pwdstr[300];
char localname[300];
char basename[300];
char chmodstr[300];

// Change permissions on files and directories needed for MRC and mechanical
// open up from owner-only to group, read or write depends on directory

// Version 0.1
// bac 4-26-98

// Version 0,2
// Update for new structure
// bac 5-1-98

// Version 0.3
// Traverse directories
// bac 8-31-98

// Version 0.4
// Correct problems with existing file permissions
// bac 9-9-98

getwd(pwdstr);
//basename=${PWD##*\/}
get_full_path_end(pwdstr,basename);

strncpy(localname,basename,120);
strncat(localname,".mcm",10);

//localname=${PWD##*\/}.mcm

if ( ! file_exists( localname ) )   // -a
{
   printf(" %s  does not exist. Change to a part directory.\n",localname);
   exit(-1);
}
else
{
 if (WINDOWS)
 {
   // Enable directory access and overwrite
   chmod_file( 755 , "pre-bias");
   chmod_file( 755 , "raw mech\\src");
   chmod_file( 755 , "report");
   chmod_file( 755 , "control"); 
   chmod_file( 755 , "aper");
   chmod_file( 775 , "mech");
   chmod_file( 775 , "test");
   chmod_file( 775 , "cam");
   chmod_file( 775 , "274x");
   chmod_file( 775 , "laser");
   chmod_file( 775 , "drill"); 
   chmod_file( 775 , "mech\\*");
   chmod_file( 775 , "test\\*"); 
   chmod_file( 775 , "cam\\*");
   chmod_file( 775 , "274x\\*"); 
   chmod_file( 775 , "mech\\*\\*"); 
   chmod_file( 775 , "cam\\*\\*");
   chmod_file( 775 , "mech\\*\\*\\*");
   chmod_file( 775 , "cam\\*\\*\\*");
   
   // Files - readable
   chmod_file( 640, "aper\\*"); 
   chmod_file( 640, "mech\\src\\*");
   chmod_file( 640, "control\\*");
   chmod_file( 640, "test\\*");
   chmod_file( 640, "pre-bias\\*"); 
   strncpy(chmodstr,"report",30);
   strncat(chmodstr,dirsep,10);
   strncat(chmodstr,basename,120);

   chmod_file( 640, chmodstr );
   chmod_file( 640, "report\\makelog");
   chmod_file( 640, "report\\OFFSETS");

   printf("Permissions changed.\n");
 }
 else
 {
   // Enable directory access and overwrite
   chmod_file( 755 , "pre-bias");
   chmod_file( 755 , "raw mech/src");
   chmod_file( 755 , "report");
   chmod_file( 755 , "control"); 
   chmod_file( 755 , "aper");
   chmod_file( 775 , "mech");
   chmod_file( 775 , "test");
   chmod_file( 775 , "cam");
   chmod_file( 775 , "274x");
   chmod_file( 775 , "laser");
   chmod_file( 775 , "drill"); 
   chmod_file( 775 , "mech/*");
   chmod_file( 775 , "test/*"); 
   chmod_file( 775 , "cam/*");
   chmod_file( 775 , "274x/*"); 
   chmod_file( 775 , "mech/*/*"); 
   chmod_file( 775 , "cam/*/*");
   chmod_file( 775 , "mech/*/*/*");
   chmod_file( 775 , "cam/*/*/*");
   
   // Files - readable
   chmod_file( 640, "aper/*"); 
   chmod_file( 640, "mech/src/*");
   chmod_file( 640, "control/*");
   chmod_file( 640, "test/*");
   chmod_file( 640, "pre-bias/*"); 
   strncpy(chmodstr,"report",30);
   strncat(chmodstr,dirsep,10);
   strncat(chmodstr,basename,120);

   chmod_file( 640, chmodstr );
   chmod_file( 640, "report/makelog");
   chmod_file( 640, "report/OFFSETS");

   printf("Permissions changed.\n");
 }
}

}  // end openup_call

int main(int argc, char **argv)
{
  
	 openup_call( );

}  // end main


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>

int find_in_pad_type( char *instr)
{
int found;

 found=FALSE;

 if (strcmp(instr,"CIRCLE")==0)
 {
	found=TRUE;
 }
 if (strcmp(instr,"SQUARE") == 0)
 {
	 found=TRUE;
 }
 if (strcmp(instr,"OBLONG") == 0)
 {
	 found=TRUE;
 }
 if (strcmp(instr,"RECTANGLE") == 0)
 {
	 found = TRUE;
 }
 if (strcmp(instr,"SHAPE")==0)
 {
	 found = TRUE;
 }
 return(found);

}

   
int find_vnum( char *instr)
{
int found;

 found=FALSE;

 if (strstr(instr,"V0") != NULL)
 {
	found=TRUE;
 }
 if (strstr(instr,"V1") != NULL)
 {
	 found=TRUE;
 }
 if (strstr(instr,"V2") != NULL)
 {
	found=TRUE;
 }
 if (strstr(instr,"V3") != NULL)
 {
	 found=TRUE;
 }
 if (strstr(instr,"V4") != NULL)
 {
	found=TRUE;
 }
 if (strstr(instr,"V5") != NULL)
 {
	 found=TRUE;
 }
 if (strstr(instr,"V6") != NULL)
 {
	found=TRUE;
 }
 if (strstr(instr,"V7") != NULL)
 {
	 found=TRUE;
 }
 if (strstr(instr,"V8") != NULL)
 {
	found=TRUE;
 }
 if (strstr(instr,"V9") != NULL)
 {
	 found=TRUE;
 }
 
 return(found);

}
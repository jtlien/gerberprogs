

int find_in_pad_type( char *instr);
int find_vnum( char *instr);

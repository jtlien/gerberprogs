
#include <stdio.h>
#include <string.h>
#include <process.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_STR_ARRAY 200
#define NULLCHAR 0
#define MAX_ABREV_TABLE 9
#define TRUE 1
#define FALSE 0

// external function call

extern int _access( char *instr, int mode);

//
// all the smp info, surface mount pads
//
struct smp_stuff
{
 double length;
 double width;
 char layer[120];   // side
 char shape[120];
 int center_drilled;
 int offset_drilled;
 int  count;
} smp_array[200];
//
// all the drill info, 
//
struct drill_stuff
{
 double hole_size;
 int  count;
 char hole_type[20];   // side
 char layer[20];
 char plating_str[40];

} drill_array[200];

//
// all the smd info, surface mount devices
//
struct smd_stuff
{
 int number_of_devices;
 int number_of_sides;
 double width;
 double height;
 int  pins;
 double pad_width;
 double pad_height;
 char side_str[20];
 double pitch;
} smd_array[200];

// all the spacing info
//
struct spacing_stuff
{
 char type_str[60];
 double MinMfg;
 double Cust;
 double DesMfg;
 double Typ;
 char typ_char;
 char cls_str[20];
 int  viol_count;
} spacing_array[200];

// all the nonplated drill hole info
//
struct nonplatedDth_stuff
{
 char type_str[60];
 double MinMfg;
 double Cust;
 double DesMfg;
 double Typ;
 char typ_char;
 char cls_str[20];
 int  viol_count;
} nonplatedDth_array[200];

// all the width info
//
struct width_stuff
{
 char type_str[60];
 double MinMfg;
 double Cust;
 double DesMfg;
 double Typ;
 char typ_char;
 char cls_str[20];
 int  viol_count;
} width_array[200];

// all the registration info
//
struct reg_stuff
{
 char layer_name_str[10];
 int layer_nums[2];
 char layer_short_str[10];
 char pad_shape_str[20];
 char rule_str[20];
 double width;
 double length;
 char xchar;
} regis_array[200];

//
//  layer information
//
struct layerinfo
{
  char mmm_layer_name[120];
  char source_str[40];          // 
  char short_layer_name[10];    // ie 1a 2a etc
  char abrev_name[20];      // SM, NPD, BVIA etc
  char layer_name[100];   // long name for abrev_name
  int buried_via_begin;   // only valid for BVIA
  int buried_via_end;
} layer_table[100];

// table of layer abreviations and layer names
//   these abreviations are the last column of the 
//    the Layer Summary section of the .det report of the PAR tool
//
struct layerdesc
{
	char layer_abrev[20];
	char layer_name[120];
} layer_desc[100] = {{ "BVIA","Buried / Blind Via"},
{"SIG","Signal"},{"NPD","Non-plated Drill"},{"SM","Solder Mask"},
{"DRL","Drill"},{"PLN","Copper Plane"},{"DOC",""},{"OTL",""},{"CNET",""}};

//  This is a list of the section headers of the .det file
//    to search for when splitting the .det file
//
struct compstuff
{
 char compstr[120];
 char subdirstr[40];
 char filetypestr[10];
 int skiplines;
}  comp_array[100] = {{"Layer Summary","","_lsu.txt",2},
                     {"Surface Mount Devices","","_smd.txt",2},
{"Surface Mount Pads","","_smp.txt",2},
{"Drilling","","_drl.txt",2},
{"1a Signal","det","_l1a.txt",2},
{"2a Signal","det","_l2a.txt",2},
{"3d Buried / Blind Via","det","_l3d.txt",2},
{"8a Signal","det","_ll8a",2},
{"zzzz","",".zzz",2}};

int head_count = 4;    // only look at Layer Summary and SM
                        // for first pass thru file

struct compstuff icomp_array[20] = {{"Layer Summary","","_lsu.txt",2},
                     {"Surface Mount Devices","","_smd.txt",2},
{"Surface Mount Pads","","_smp.txt",2},
{"zzzz","",".zzz",2}};

int endoffile;
int mcd_found;

char rlines[5000][120];
char token_array[40][140];
int retcode;
int start_index[5000];
int i,j,k,l,m,n;
int head_num;
int debug;
int debug_test;     // using mfc debugger
char openstr[120];
char newstr[120];
char lsu_file_str[120];    // layer summary file
char this_file_str[120];
char dirstr[120];
char filetypestr[20];
char outfilestr[140];
char basefilestr[120];
int lines_in;
char thisline[120];
char str_array[200][200];

char current_layer[120];
char current_viol_num[120];
char current_viol_type[120];


FILE *tfile,*file1;



int split_line_seps( char *tline, char *file_sep)
{
int ii;
char tstr[200];
char *token;

 ii = 0;

 strncpy( tstr, tline,200);

 token = strtok( tstr,file_sep);

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL,file_sep);

	}


 return(ii);

} // end split_line_seps

typedef struct col_len_stuff
{
	int col;
	int len;
} col_len_type;

int smp_bust[20] = { 0, 7, 18, 28, 37, 49, 57 , 62, 68, 90, -1 };

col_len_type width_bust[20] = { {0,27}, 
{28,6},
{35,6},
{42,6},
{49,7},
{57,3},
{61,12}, 
{74,-1}};

col_len_type smd_bust[20] = { {0,6}, 
{8,6},
{15,9},
{25,9},
{36,6},
{42,9},
{52,9},
{61,9},
{72,6}, 
{79,-1}};

col_len_type regis_bust[20] = { {0,3}, 
{5,3},
{10,2},
{13,5},
{29,7},
{37,6},
{45,6}, 
{52,-1}};

col_len_type drill_bust[20] = { {0,8}, 
{8,9},
{17,12},
{29,12},
{41,23},
{65,-1}};

FILE *infile, *outfile, *lsufile;

// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return ( 1);
 }
}

//
//  check for a blank line
//
int is_blank_line( char *instr)
{
int kk;

kk = 0;
while((instr[kk] == ' ') && ( kk < strlen(instr)))
{
  kk += 1;
}
if ((instr[kk] == '\n') || ( kk == (strlen(instr) -1) ))
{
     // printf("A blank line FOUND\n");
	return(1);
}
else
{
	return(0);
}
}

// tokenize a line delimited by spaces
//   return number of tokens

int bust_line(char *instring)
{
int token_count;
char * pch;
char thisstring[140];


token_count = 0;

strncpy(thisstring,instring,120);
thisstring[strlen(instring)-1]=';';


//printf ("Splitting string \"%s\" in tokens:\n",thisstring);

pch = strtok (thisstring," ");

while (pch != NULL)
  {
    // printf ("next token = %s\n",pch);
    if ( token_count < 40 )
	{
		strncpy( token_array[token_count], pch, 120);
        pch = strtok (NULL, " ;");
		if ( token_array[token_count][0] != ' ')
		{
	    token_count += 1;
		}
	}
    else
	{
		printf("Too many tokens on line = %s \n", instring );
	}
}
  return token_count;
}

//
//  str_len_bust ( char *instr, col_len_type cols_len[], int col_count )
//         given a string and a list of columns + length pairs
//         break the string into substrings
//         strings are put in the array str_array
//           returns the number of strings

int str_length_bust( char *instr, col_len_type cols_len[], int col_count)
{
int ii;
int jj;
int kk;
int debug;
 
 debug = 0;

 ii = 0;

 if (debug)
	{
	  printf("in str_length_bust -- instr = %s \n", instr);
	}

 while(( ii < col_count) && ( ii < MAX_STR_ARRAY))
 {
   jj = cols_len[ii].col;
   // printf("ii = %d columns = %d length = %d \n",ii, cols_len[ii].col, cols_len[ii].len);
   kk = 0;
   while(( jj < cols_len[ii+1].col) && ( kk < cols_len[ii].len)
	                 && ( kk < 200) && (instr[jj] != '\n'))
   {

	str_array[ii][kk] = instr[jj];
	// printf("ii = %d kk = %d char = %c \n", ii,kk,instr[jj]);
	jj += 1;
	kk += 1;
   }
   str_array[ii][kk] = 0;    // terminate string

   if (debug) {
	   printf("str_array of %d = %s \n", ii, str_array[ii]); }

   if ( kk > cols_len[ii].len)
   {
	   printf("Badly formed set of columns and lengths , kk = %d len = %d ii=%d\n",
		   kk, cols_len[ii].len,ii);
	   exit(-1);
   }

   ii += 1;
 }

 return(ii);

}     // str_col_bust

//
//  str_col_bust ( char *instr, int cols[], int col_count )
//         given a string and a list of columns,
//         break the string into substrings
//         strings are put in the array str_array
//           returns the number of strings

int str_col_bust( char *instr, int cols[], int col_count)
{
int ii;
int jj;
int kk;
int prev_end;

 ii = 0;
 prev_end = cols[0];


 while(( ii < col_count) && ( ii < MAX_STR_ARRAY))
 {
   jj = prev_end;
   kk = 0;
   // printf("cols = %d \n", cols[ii]);
   while(( jj < cols[ii+1]) && ( jj < 200) && (instr[jj] != '\n'))
   {

	str_array[ii][kk] = instr[jj];
	jj += 1;
	kk += 1;
   }
   str_array[ii][kk] = 0;    // terminate string

   prev_end = jj;
   ii += 1;
 }
 return(ii);

}     // str_col_bust

// remove all trailing and preceeding spaces from a line
//
void trim_str( char *thisline, char *newstr)
{
int ll;
int nn;

ll = 0;                     // make sure the info from thisline
		                            // 
 while( ( ll < strlen(thisline)) && ( thisline[ll] == ' '))
 {
			 ll += 1;               // skip any preceeding blanks
 }
 nn=0;
 while(  ll < strlen(thisline))
 { 
  newstr[nn] = thisline[ll];   // get the rest of the line
  ll += 1;
  nn += 1;
 }

 newstr[nn] = 0;
 if ( nn > 0 ) { nn = nn-1; }

 while((newstr[nn] == ' ') && ( nn > 0 ))  // go backwards from end
 {
			nn-= 1;
 }
 newstr[nn+1] = 0;

} // end trim_str

//
// find the given abreviation in the list of abreviations vs names
//
int find_in_table( char *abrev_in_str )
{
int abrev_found;
int kk;

 abrev_found = FALSE;

 kk = 0;
 while ( ( kk< MAX_ABREV_TABLE) && ( abrev_found == FALSE))
 {
	// printf("Comparing %s to %s \n",abrev_in_str,
		 //                layer_table[kk].abrev_name);

	 if ( strcmp( abrev_in_str, layer_desc[kk].layer_abrev) == 0)
	 {
		 abrev_found = TRUE;
		 return(kk);
	 }
	kk += 1;
 }

 if (( kk == MAX_ABREV_TABLE ) && (abrev_found == FALSE))
	{
	 printf("Error: Could not find abreviation = %s in table \n",
		  abrev_in_str);
 }
 return(-1);

}
//
//   Read a non-plated drill /tooling homl anular ring file
//
void do_nonplatedDth_file(char *nonplatedDth_file_str)
{
int debug;
FILE *nonplatedDthfile;
char newline[200];
char temp_str[200];
int retval;
int ii;
int kk;
int ll;
int xx,ww;
int count_val;
int blank_line_found;
int num_strs;
int num_nonplateds;

debug = 0;

nonplatedDthfile = fopen( nonplatedDth_file_str,"r");

 if ( nonplatedDthfile == NULL)
	{
	  printf("Error: Unable to open the non-plated DTH violation file = %s \n",
		   nonplatedDth_file_str);
	   exit(-1);
	}

 // skip first 5 lines

 for ( ii = 0; ii < 5; ii += 1)
 {
   retval = getline(nonplatedDthfile, newline);

 }

 blank_line_found = FALSE;

 ll = 0;
 while(( getline( nonplatedDthfile, newline) == 0) && 
	              ( blank_line_found == FALSE))
	{
     blank_line_found = is_blank_line( newline); 
	 if ( blank_line_found == FALSE)
     {
	   if (strstr(newline,"---------") == NULL)
	   {
        num_strs = str_length_bust( newline, width_bust, 7 );  // bust
	                                   // based on columns and width

	    for ( kk = 0; kk < num_strs; kk += 1)
		{
		 // printf("non-platedDTH line = %d field %d = %s \n",ii,
			//         kk, str_array[kk] );


		 trim_str( str_array[kk], temp_str);     // trim off blanks
		 // printf(" kk = %d before = %s after = %s? \n",kk, str_array[kk],
			  //              temp_str);


		 strncpy( str_array[kk], temp_str,200);
		}

        count_val = atoi( str_array[6] );

	    if ( ll < 200)
		{
         nonplatedDth_array[ll].viol_count = count_val;

		  if (strlen( str_array[0] ) > 0)
		  {
			  strncpy( nonplatedDth_array[ll].type_str,str_array[0],60);
		  }

		  if (strlen( str_array[1] ) > 0)
		  {
		  nonplatedDth_array[ll].MinMfg = atof( str_array[1]);
		  }
		  else
		  { 
		  nonplatedDth_array[ll].MinMfg = 0.0;
		  }

          if (strlen( str_array[2] ) > 0)
		  {
		  nonplatedDth_array[ll].Cust = atof( str_array[2]);
		  }
		  else
		  { 
		  nonplatedDth_array[ll].Cust = 0.0;
		  }

         if (strlen( str_array[3] ) > 0)
		  {
		  nonplatedDth_array[ll].DesMfg = atof( str_array[3]);
		  }
		  else
		  { 
		  nonplatedDth_array[ll].DesMfg = 0.0;
		  }
		  if (strlen(str_array[4] ) > 0 )
		  {
		    xx = 0;   // get just the floating part of string
			// printf("strarray_4 = %s \n", str_array[4]);

		    for( ww=1; ww < strlen(str_array[4]); ww += 1)
			{
			  temp_str[xx] = str_array[4][ww];
			  xx += 1;
			}
		    temp_str[xx] = 0;

		    nonplatedDth_array[ll].Typ = atof( temp_str);
		    nonplatedDth_array[ll].typ_char = str_array[4][0];

		  }
		  else
		  { 
			  nonplatedDth_array[ll].Typ = 0.0;
		      nonplatedDth_array[ll].typ_char = ' ';
		  }

		  strncpy(nonplatedDth_array[ll].cls_str,str_array[5],5); 
		   
		}
       ll += 1;
	   }
	 }
	 
	}

 num_nonplateds = ll;

 printf("non-plated Drill hole file lines = %d for %s \n", ll, nonplatedDth_file_str);

 fclose(nonplatedDthfile);

 if (debug)
 {
   for (ii = 0; ii < num_nonplateds; ii += 1)
	{
      printf("%s %f %f %f %c %f %s %d \n", 
		  nonplatedDth_array[ii].type_str,
		  nonplatedDth_array[ii].MinMfg,
		  nonplatedDth_array[ii].Cust,
		  nonplatedDth_array[ii].DesMfg,
		  nonplatedDth_array[ii].typ_char,
		  nonplatedDth_array[ii].Typ,
		  nonplatedDth_array[ii].cls_str,
		  nonplatedDth_array[ii].viol_count);

	}
 }
}  // do_nonplatedDth_file

//
//   Read a width file
//
void do_width_file(char *width_file_str)
{
int debug;
FILE *widthfile;
char newline[200];
char temp_str[200];
int retval;
int ii;
int kk;
int ll;
int xx,ww;
int count_val;
int blank_line_found;
int num_strs;
int num_widths;

debug = 1;

widthfile = fopen( width_file_str,"r");

 if ( widthfile == NULL)
	{
	  printf("Error: Unable to open the Width violation file = %s \n",
		   width_file_str);
	   exit(-1);
	}

 // skip first 5 lines

 for ( ii = 0; ii < 5; ii += 1)
 {
   retval = getline(widthfile, newline);

 }

 blank_line_found = FALSE;

 ll = 0;
 while(( getline( widthfile, newline) == 0) && 
	              ( blank_line_found == FALSE))
	{
     blank_line_found = is_blank_line( newline); 
	 if ( blank_line_found == FALSE)
     {
	   if (strstr(newline,"---------") == NULL)
	   {
        num_strs = str_length_bust( newline, width_bust, 7 );  // bust
	                                   // based on columns and width

	    for ( kk = 0; kk < num_strs; kk += 1)
		{
		 // printf("widthfile line = %d field %d = %s \n",ii,
			//         kk, str_array[kk] );


		 trim_str( str_array[kk], temp_str);     // trim off blanks
		 // printf(" kk = %d before = %s after = %s? \n",kk, str_array[kk],
			  //              temp_str);


		 strncpy( str_array[kk], temp_str,200);
		}

        count_val = atoi( str_array[6] );

	    if ( ll < 200)
		{
          width_array[ll].viol_count = count_val;
		  if (strlen( str_array[0] ) > 0)
		  {
			  strncpy( width_array[ll].type_str,str_array[0],60);
		  }

		  if (strlen( str_array[1] ) > 0)
		  {
		  width_array[ll].MinMfg = atof( str_array[1]);
		  }
		  else
		  { 
		  width_array[ll].MinMfg = 0.0;
		  }

          if (strlen( str_array[2] ) > 0)
		  {
		  width_array[ll].Cust = atof( str_array[2]);
		  }
		  else
		  { 
		  width_array[ll].Cust = 0.0;
		  }

         if (strlen( str_array[3] ) > 0)
		  {
		  width_array[ll].DesMfg = atof( str_array[3]);
		  }
		  else
		  { 
		  width_array[ll].DesMfg = 0.0;
		  }
		  if (strlen(str_array[4] ) > 0 )
		  {
		    xx = 0;   // get just the floating part of string
			// printf("strarray_4 = %s \n", str_array[4]);

		    for( ww=1; ww < strlen(str_array[4]); ww += 1)
			{
			  temp_str[xx] = str_array[4][ww];
			  xx += 1;
			}
		    temp_str[xx] = 0;

		    width_array[ll].Typ = atof( temp_str);
		    width_array[ll].typ_char = str_array[4][0];

		  }
		  else
		  { 
			  width_array[ll].Typ = 0.0;
		      width_array[ll].typ_char = ' ';
		  }

		  strncpy(width_array[ll].cls_str,str_array[5],5); 
		  
		}
       ll += 1;
	   }
	 }
	 
	}

 num_widths = ll;

 printf("width file lines = %d for %s \n", ll, width_file_str);

 fclose(widthfile);

 if (debug)
 {
   for (ii = 0; ii < num_widths; ii += 1)
	{
      printf("%s %f %f %f %c %f %s %d \n", 
		  width_array[ii].type_str,
		  width_array[ii].MinMfg,
		  width_array[ii].Cust,
		  width_array[ii].DesMfg,
		  width_array[ii].typ_char,
		  width_array[ii].Typ,
		  width_array[ii].cls_str,
		  width_array[ii].viol_count);

	}
 }
}  // do_width_file

//
//   Read a width violation report file
//
void do_spacing_file(char *spacing_file_str)
{
int debug;
FILE *spacingfile;
char newline[200];
char temp_str[200];
int retval;
int ii;
int kk;
int ll;
int xx,ww;
int blank_line_found;
int num_strs;
int num_spacings;
char prev_type_str[120];


debug = 1;

strncpy( prev_type_str,"zzzz",120);

spacingfile = fopen( spacing_file_str,"r");

 if ( spacingfile == NULL)
	{
	  printf("Error: Unable to open the Spacing violation file = %s \n",
		   spacing_file_str);
	   exit(-1);
	}

 // skip first 6 lines

 for ( ii = 0; ii < 6; ii += 1)
 {
   retval = getline(spacingfile, newline);

 }

 blank_line_found = FALSE;

 ll = 0;
 while(( getline( spacingfile, newline) == 0) && 
	              ( blank_line_found == FALSE))
	{
     blank_line_found = is_blank_line( newline); 
	 if ( blank_line_found == FALSE)
     {
	   if (strstr(newline,"---------") == NULL)
	   {
        num_strs = str_length_bust( newline, width_bust, 7 );  // bust
	                                   // based on columns and width

	    for ( kk = 0; kk < num_strs; kk += 1)
		{
		  printf("spacingfile line = %d, field %d = %s \n",ll,
			        kk, str_array[kk] );


		 trim_str( str_array[kk], temp_str);     // trim off blanks
		 // printf(" kk = %d before = %s after = %s? \n",kk, str_array[kk],
			  //              temp_str);


		 strncpy( str_array[kk], temp_str,200);
		}


	    if ( ll < 200)
		{
          // spacing_array[ll].viol_count = count_val;
		  if (strlen( str_array[0] ) > 0)
		  {
			  strncpy( spacing_array[ll].type_str,str_array[0],60);
			  strncpy( prev_type_str, str_array[0],60);
		  }
		  else
		  {
			  strncpy( spacing_array[ll].type_str, prev_type_str, 60);
		  }

		  if (strlen( str_array[1] ) > 0)
		  {
		  width_array[ll].MinMfg = atof( str_array[1]);
		  }
		  else
		  { 
		  spacing_array[ll].MinMfg = 0.0;
		  }

          if (strlen( str_array[2] ) > 0)
		  {
		  spacing_array[ll].Cust = atof( str_array[2]);
		  }
		  else
		  { 
		  width_array[ll].Cust = 0.0;
		  }

         if (strlen( str_array[3] ) > 0)
		  {
		  width_array[ll].DesMfg = atof( str_array[3]);
		  }
		  else
		  { 
		  width_array[ll].DesMfg = 0.0;
		  }
		  if (strlen(str_array[4] ) > 0 )
		  {
		    xx = 0;   // get just the floating part of string

			if ( str_array[4][0] != '.')
			{
		      for( ww=1; ww < strlen(str_array[4]); ww += 1)
			  {
			   temp_str[xx] = str_array[4][ww];
			   xx += 1;
			  }
		     temp_str[xx] = 0;

		     spacing_array[ll].Typ = atof( temp_str);
		     spacing_array[ll].typ_char = str_array[4][0];
			}
		   else
		   {
			   spacing_array[ll].typ_char = ' ';
		   }

		  }
		  else
		  { 
			  spacing_array[ll].Typ = 0.0;
		      spacing_array[ll].typ_char = ' ';
		  }

		  strncpy(spacing_array[ll].cls_str,str_array[5],5); 
		  
		}
       ll += 1;
	   }
	 }
	 
 }

 num_spacings = ll;

 printf("spacing file lines = %d for %s \n", ll, spacing_file_str);

 fclose(spacingfile);

 if (debug)
 {
   for (ii = 0; ii < num_spacings; ii += 1)
	{
      printf("%s %f %f %f %c %f %s %d \n", 
		  spacing_array[ii].type_str,
		  spacing_array[ii].MinMfg,
		  spacing_array[ii].Cust,
		  spacing_array[ii].DesMfg,
		  spacing_array[ii].typ_char,
		  spacing_array[ii].Typ,
		  spacing_array[ii].cls_str,
		  spacing_array[ii].viol_count);

	}
 }
}  // do_spacing_file


//
//   Read a registration violation report file
//
void do_regis_file(char *regis_file_str)
{
int debug;
FILE *regisfile;
char newline[200];
char temp_str[200];
int retval;
int ii;
int kk;
int ll;
int blank_line_found;
int num_strs;
int num_widths;

debug = 1;

regisfile = fopen( regis_file_str,"r");

 if ( regisfile == NULL)
	{
	  printf("Error: Unable to open the registration violation file = %s \n",
		   regis_file_str);
	   exit(-1);
	}

 // skip first 7 lines

 for ( ii = 0; ii < 7; ii += 1)
 {
   retval = getline(regisfile, newline);

 }

 blank_line_found = FALSE;

 ll = 0;
 while(( getline( regisfile, newline) == 0) && 
	              ( blank_line_found == FALSE))
	{
     blank_line_found = is_blank_line( newline); 

	  
	 if ( blank_line_found == FALSE)
	 {
	  if (strstr(newline,"---------") == NULL)
	  {
        num_strs = str_length_bust( newline, regis_bust, 7 );  // bust
	                                   // based on columns and width

	    for ( kk = 0; kk < num_strs; kk += 1)
		{
		 // printf("regisfile line = %d field %d = %s \n",ii,
			//         kk, str_array[kk] );


		   trim_str( str_array[kk], temp_str);     // trim off blanks
		 // printf(" kk = %d before = %s after = %s? \n",kk, str_array[kk],
			  //              temp_str);


		  strncpy( str_array[kk], temp_str,200);
		}

	    if ( ll < 200)
		{
		  
		  strncpy(regis_array[ll].layer_name_str, str_array[0],10);
          strncpy(regis_array[ll].layer_short_str, str_array[2],10);

		  if (strlen(str_array[3] ) > 0 )
		  {
		   strncpy(regis_array[ll].rule_str,str_array[3],20);
		  }
		  else
		  { 
			  printf("Missing rule  \n");
		  }
        
		  if (strlen(str_array[4] ) > 0 )
		  {
		    		
		    strncpy(regis_array[ll].pad_shape_str,str_array[4],20);
		  }
		  else
		  { 
			  printf("Missing pad shape \n");
		  }
        
		  if (strlen(str_array[5] ) > 0 )
		  {
		    		
		    regis_array[ll].length = atof(str_array[5]);
		  }
		  else
		  { 
			  regis_array[ll].length= 0.0;
		  }

         if (strlen(str_array[6] ) > 0 )
		  {
		    		
		    regis_array[ll].width= atof(str_array[6]);
		  }
		  else
		  { 
			  regis_array[ll].width= 0.0;
		  }
		 regis_array[ll].xchar = newline[43];

		}
	  ll += 1;
	  }
	 }

	}

 num_widths = ll;

 printf("regis file lines = %d for %s \n", ll, regis_file_str);

 fclose(regisfile);

 if (debug)
 {
   for (ii = 0; ii < num_widths; ii += 1)
	{
      printf("%s %s  %s %s %f %c %f \n", 
		  regis_array[ii].layer_name_str,
		  regis_array[ii].layer_short_str,
		  regis_array[ii].rule_str,
		  regis_array[ii].pad_shape_str,
		  regis_array[ii].length,
		  regis_array[ii].xchar,
		  regis_array[ii].width);

	}
 }
} // do_regis_file

//
//  read the Surface Mount pad file
//

void do_smp_file(char *smp_file_str)
{
int debug;
FILE *smpfile;
char newline[200];
char temp_str[200];
int retval;
int ii;
int kk;
int ll;
int count_val;
int blank_line_found;
int num_strs;
int num_pads;

debug = 0;

smpfile = fopen( smp_file_str,"r");

 if ( smpfile == NULL)
	{
	  printf("Error: Unable to open the Surface mount pad file = %s \n",
		   smp_file_str);
	   exit(-1);
	}

 // skip first 6 lines

 for ( ii = 0; ii < 6; ii += 1)
 {
   retval = getline(smpfile, newline);

 }

 blank_line_found = FALSE;

 ll = 0;
 while(( getline( smpfile, newline) == 0) && 
	              ( blank_line_found == FALSE))
	{
     blank_line_found = is_blank_line( newline); 
     
	 if ( blank_line_found == FALSE)
	 {
       num_strs = str_col_bust( newline, smp_bust, 8 );

	   for ( kk = 0; kk < num_strs; kk += 1)
	   {
		 // printf("smpfile line = %d field %d = %s \n",ii,
			  //       kk, str_array[kk] );


		 trim_str( str_array[kk], temp_str);     // trim off blanks
		 // printf(" kk = %d before = %s after = %s? \n",kk, str_array[kk],
			  //              temp_str);


		 strncpy( str_array[kk], temp_str,200);
	   }

       count_val = atoi( str_array[0] );

	   if ( ll < 200)
	   {
          smp_array[ll].count = count_val;
		  smp_array[ll].length = atof( str_array[1]);
		  smp_array[ll].width = atof( str_array[2]);
		  strncpy(smp_array[ll].shape,str_array[3],20);
		  strncpy(smp_array[ll].layer, str_array[7],20);

		  if ( strstr( str_array[4],"YES") != NULL)
		  {
			  smp_array[ll].center_drilled = TRUE;
		  }
		  else
		  {
			  smp_array[ll].center_drilled = FALSE;
		  }
		  if ( strstr( str_array[5],"YES") != NULL)
		  {
			  smp_array[ll].offset_drilled = TRUE;
		  }
		  else
		  {
			  smp_array[ll].offset_drilled = FALSE;
		  }
		ll += 1;
	   }
	 
	 }
     ii += 1;
	}

 num_pads = ll;

 printf("smp file lines = %d for %s \n", ll, smp_file_str);

 fclose(smpfile);

 if (debug)
 {
   for (ii = 0; ii < num_pads; ii += 1)
	{
      printf("%d %f %f %s %s \n", smp_array[ii].count,
		  smp_array[ii].length, smp_array[ii].width,
		  smp_array[ii].shape, smp_array[ii].layer);

	}
 }

} // do_smp_file

//
//  read the Drill file
//

void do_drill_file(char *drill_file_str)
{
int debug;
FILE *drillfile;
char newline[200];
char temp_str[200];
int retval;
int ii;
int kk;
int ll;
int blank_line_found;
int total_line_found;
int dash_line_found;
char current_layer[40];
char current_hole_type[40];

int num_strs;
int num_holes;

debug = 0;

drillfile = fopen( drill_file_str,"r");

 if ( drillfile == NULL)
	{
	  printf("Error: Unable to open the drill file = %s \n",
		   drill_file_str);
	   exit(-1);
	}

 // skip first 3 lines

 for ( ii = 0; ii < 3; ii += 1)
 {
   retval = getline(drillfile, newline);

 }

 total_line_found = FALSE;

 ll = 0;
 strncpy( current_hole_type,"",5);
 strncpy( current_layer,"",5);

 while(( getline( drillfile, newline) == 0) && 
	              ( total_line_found == FALSE))
	{
     blank_line_found = is_blank_line( newline); 
     
	 total_line_found = FALSE;

	 if (strstr( newline,"Total") != NULL)
	 {
	  total_line_found = TRUE;
	 }

     dash_line_found = FALSE;

	 if (strstr( newline,"----") != NULL)
	 {
	  dash_line_found = TRUE;
	 }


	 if (( blank_line_found == FALSE) && ( dash_line_found == FALSE) &&
		                  ( total_line_found == FALSE))
	 {

       num_strs = str_length_bust( newline, drill_bust, 5);

	   for ( kk = 0; kk < num_strs; kk += 1)
	   {
		   if (debug) { printf("drillfile line = %d field %d = %s \n",ii,
			   kk, str_array[kk] );}


		 trim_str( str_array[kk], temp_str);     // trim off blanks


		 strncpy( str_array[kk], temp_str,200);
	   }


	   if ( ll < 200)
	   {
		  if (strstr(str_array[2],"Size") != NULL )  // new hole type header
		  {
			strncpy(current_hole_type, str_array[1],20);
			strncpy(current_layer,str_array[0],20);
            
		  }
		  else
		  {

           drill_array[ll].count = atoi(str_array[3]);
		   drill_array[ll].hole_size = atof( str_array[2]);
		   
		   strncpy(drill_array[ll].hole_type,current_hole_type,20);
		   strncpy(drill_array[ll].layer, current_layer,20);
           strncpy(drill_array[ll].plating_str,str_array[4],40); 

		   if (debug)
		   {
			   printf("ll = %d count = %d size=%f type = %s layer = %s plating = %s\n",
				            ll, drill_array[ll].count,
							drill_array[ll].hole_size,
							drill_array[ll].hole_type,
							drill_array[ll].layer,
							drill_array[ll].plating_str);
		   }

		  ll += 1;
		  }
	   }
	 
	 }
     ii += 1;
	}

 num_holes = ll;

 printf("drill file lines = %d for %s \n", ll, drill_file_str);

 fclose(drillfile);

 

} // do_drill_file

//
//  read the Surface Mount Device 
//

void do_smd_file(char *smd_file_str)
{
int debug;
FILE *smdfile;
char newline[200];
char temp_str[200];
int retval;
int ii;
int kk;
int ll;
int blank_line_found;
int num_strs;
int num_smds;


debug = 0;

smdfile = fopen( smd_file_str,"r");

 if ( smdfile == NULL)
	{
	  printf("Error: Unable to open the Surface mount pad file = %s \n",
		   smd_file_str);
	   exit(-1);
	}

 // skip first 6 lines

 for ( ii = 0; ii < 6; ii += 1)
 {
   retval = getline(smdfile, newline);

 }

 blank_line_found = FALSE;

 ll = 0;
 while(( getline( smdfile, newline) == 0) && 
	              ( blank_line_found == FALSE))
	{
     blank_line_found = is_blank_line( newline);

	 if ( blank_line_found == FALSE)
	 {

       num_strs = str_length_bust( newline, smd_bust, 9);

	   for ( kk = 0; kk < num_strs; kk += 1)
	   {
		 //printf("smdfile line = %d field %d = %s \n",ii,
		//	     kk, str_array[kk] );


		 trim_str( str_array[kk], temp_str);     // trim off blanks
		 // printf(" kk = %d before = %s after = %s? \n",kk, str_array[kk],
			  //              temp_str);

		 strncpy( str_array[kk], temp_str,200);
	   }


	   if ( ll < 200)
	   {
          smd_array[ll].number_of_devices = atoi(str_array[0]);
		  smd_array[ll].number_of_sides = atoi( str_array[1]);
		  smd_array[ll].width = atof( str_array[2]);
          smd_array[ll].height = atof( str_array[3]);
          smd_array[ll].pins = atoi( str_array[4]);
		  smd_array[ll].pad_width = atof(str_array[5]);
		  smd_array[ll].pad_height = atof( str_array[6]);
		  smd_array[ll].pitch = atof( str_array[7]);
          strncpy( smd_array[ll].side_str,str_array[8],10);
		  	
	   }
      ll += 1;
	 }
	}

 num_smds = ll;

 printf("smd file lines = %d for %s \n", ll, smd_file_str);

 fclose(smdfile);

 if (debug)
 {
   for (ii = 0; ii < num_smds; ii += 1)
	{
      printf("%d %d %f %f %d %f %f %f %s \n", 
		  smd_array[ii].number_of_devices,
		  smd_array[ii].number_of_sides,
		  smd_array[ii].width, smd_array[ii].height,
		  smd_array[ii].pins,
		  smd_array[ii].pad_width,smd_array[ii].pad_height,
		  smd_array[ii].pitch, smd_array[ii].side_str);

	}
 }

} // do_smd_file

// read in the Layer Summary file
//
void do_lsu_file()
{
char thisline[120];
int layer_count;
int full_name_index;
int kk;
int ll;
int mm;
int nn;
char mmstr[10];
char nnstr[10];
int mm_val;
int nn_val;
int debug;
char t3_str[20];

debug = 0;

lsufile = fopen( lsu_file_str,"r");

 if ( lsufile == NULL)
	{
	  printf("Error: Unable to open the layer summary file = %s \n",
		   lsu_file_str);
	   exit(-1);
	}

 layer_count = 0;

 while( getline( lsufile, thisline) == 0)
	{
      
	  if (bust_line( thisline) == 4)
	  {
        // printf("4Tokens = %s %s %s %s \n", token_array[0],
		//	 token_array[1],token_array[2], token_array[3]);
		strncpy( layer_table[layer_count].mmm_layer_name,
			                 token_array[0],120);
		strncpy( layer_table[layer_count].source_str,
			token_array[1],20);
        strncpy( layer_table[layer_count].short_layer_name,
			                 token_array[2],10);
		strncpy( layer_table[layer_count].abrev_name,
			token_array[3],20);
		strncpy( t3_str, token_array[3],10);  // Shorten if BVIA(...)

        layer_table[layer_count].buried_via_begin = 0;
	    layer_table[layer_count].buried_via_end = 0;
        t3_str[4] = 0;
         //printf("t3_str = %s \n", t3_str);

		if ( strcmp( t3_str,"BVIA") == 0)
		{
			// will be BVGA(n-m) in token_array[3]
            
			mm = 5;
			nn=0;
			while(( isdigit( token_array[3][mm])) && (nn < 3))
			{
				mmstr[nn] = token_array[3][mm];
				mm += 1;
				nn += 1;
			}
            mmstr[nn] = 0;
			// printf("mmstr = %s \n",mmstr);
			mm_val = atoi(mmstr);
			mm += 1;
			nn = 0;
            while(( isdigit( token_array[3][mm])) && (nn < 3))
			{
				nnstr[nn] = token_array[3][mm];
				mm += 1;
				nn += 1;
			}
			nnstr[nn]= 0;
			nn_val = atoi(nnstr);
			// printf("nnstr = %s \n",nnstr);

			layer_table[layer_count].buried_via_begin = mm_val;
			layer_table[layer_count].buried_via_end = nn_val;
			
		}

		full_name_index = find_in_table( t3_str );
        
		if ( full_name_index > -1)
		{ 
			if (debug)
			{
			 printf("layer for %s is %s , %s\n", t3_str, 
				       layer_desc[full_name_index].layer_name,
					    token_array[2]);
			}
		}
		if (( full_name_index > -1) && ( full_name_index < 100))
		{
			strncpy( layer_table[layer_count].layer_name,
				   layer_desc[full_name_index].layer_name,120);
		}
		else
		{
			strncpy(layer_table[layer_count].layer_name,"",5);
		}

		layer_count += 1;
	  }

	  // update the comp array

	ll=4;
	for(kk = 0; kk < layer_count; kk += 1)
	{
	  if ( strlen( layer_table[kk].layer_name) > 0 )
	  {
	    strncpy( comp_array[ll].compstr, layer_table[kk].short_layer_name,10);
	    strcat( comp_array[ll].compstr," ");
	    strcat( comp_array[ll].compstr,layer_table[kk].layer_name);
		// printf("kk = %d comp_array val = %s \n", kk,comp_array[kk].compstr);
		strncpy( comp_array[ll].subdirstr,"det",10);
		comp_array[ll].skiplines=2;
        strncpy( comp_array[ll].filetypestr,"l",5);
		strcat( comp_array[ll].filetypestr,layer_table[kk].short_layer_name);
	    ll += 1;
	  }
	}

	strncpy( comp_array[ll].compstr,"zzzz",10);
	strncpy( comp_array[ll].filetypestr,"",4);
	strncpy( comp_array[ll].subdirstr,"",4);

	comp_array[ll].skiplines = 2;
	strncpy( comp_array[ll].subdirstr,"",4);

 }

 printf("%d layers found in the Layer Summary \n", layer_count);
 fclose(lsufile);

} // do_lsu_file

//
//  get at information 
//         either (width) at X,Y or
//                        at X,Y
//
void get_loc_ats()
{
char *tptr;
int ii;
char widthstr[20];
double widthval;
char xstr[20];
char ystr[20];
double xval;
double yval;
int has_at;
int debug;

 debug = 0;
 has_at=TRUE;

 if (debug) { printf("In get_loc_ats - line = %s \n",thisline); }

 while((has_at == TRUE) && ( endoffile == FALSE))
 {
	widthstr[0] ='0';
	widthstr[1] = 0;

	if (strstr(thisline,"(" ) != NULL)
	{
       tptr = strstr(thisline,"(");
	   tptr++;
	   ii = 0;
	   while((*tptr != ')') && ( ii < 20))
	   {
		   widthstr[ii] = *tptr;
		   ii += 1;
		   tptr++;
	   }
	   widthstr[ii]=0;
	   // printf("In get_loc_ats widthstr = %s \n",widthstr);
	   widthval=atof(widthstr);
	}


    tptr = strstr(thisline,"at");
	if (tptr != NULL)
	{
 	 tptr++;
	 tptr++;
	 tptr++;   // skip past blank

     ii = 0;
   	 while((*tptr != ',') && ( ii < 20))
	 {
	   xstr[ii] = *tptr;
	   ii += 1;
	   tptr++;
	 }
  	 xstr[ii] = 0;

	 ii = 0;
	 while((*tptr != ' ') && ( ii < 20) && (*tptr != '\n'))
	 {
	  ystr[ii] = *tptr;
	  ii += 1;
	  tptr++;
	 }
     ystr[ii] = 0;


     xval = atof(xstr);
	 yval = atof(ystr);
    }
	else
	{
		printf("expected ats lines \n");
		xstr[0] = 0;
		ystr[0] = 0;

	}

	endoffile = getline(file1,thisline);

	// printf("In get ats - new line = %s \n",thisline);
	printf("violation = %s layer = %s xstr = %s ystr = %s width=%s \n",
		current_viol_num,current_layer,xstr,ystr,
		widthstr);

	if (strstr(thisline,"at") == NULL)
	{
		has_at = FALSE;
	}
	  
 }  // while has_at == TRUE

}

// check to see if the line has the MCD stuff on it
//
int check_mcd()
{

//	printf("In check_mcd - thisline=%s \n",thisline);

	if (strstr(thisline,"MCD") != NULL)
	{
	  return(1);

	}
	else
	{
	  return(0);
	}

}  // end check_mcd

//
//  get the loc file layer information
//
void do_loc_layer()
{
char *tptr;
char layer_str[120];
int ii;
int debug;

 debug = 0;

  
 if (debug) { printf("In do loc layer - line = %s \n",thisline); }

 tptr=thisline;

 while(( *tptr == ' ' ) || (*tptr == '\t'))
	{
      *tptr++;
	}
  ii=0;
  while(( *tptr != '\n' ) && ( ii < 120))
	{
	  layer_str[ii] = *tptr;
      *tptr++;
	  ii += 1;
	}
   layer_str[ii] = 0;

   if (debug) { printf("In get loc layer - layer = %s \n", layer_str); }

 strncpy(current_layer,layer_str,120);

 getline(file1,thisline);   // skip the _____ line
}

//
//  Get the MCD=X,Y,Z  where X,Yand Z are floating numbers
//
void get_loc_mcd()
{
char xstr[20];
char ystr[20];
char zstr[20];
double zval;
double xval;
double yval;
int ii;
char *tptr;

    tptr=strstr(thisline,"MCD");
	if (tptr != NULL)
	{
	 tptr++;
	 tptr++;
	 tptr++;
	 tptr++;   // skip past =

	 ii = 0;
	 while((*tptr != ',') && ( ii < 20))
	 {
	   xstr[ii] = *tptr;
	   ii += 1;
	   tptr++;
	 }
	 xstr[ii] = 0;

	 tptr++;

 	 ii = 0;
	 while((*tptr != ',') && ( ii < 20))
	 {
	   ystr[ii] = *tptr;
	   ii += 1;
	   tptr++;
	 }
	 ystr[ii] = 0;
     tptr++;

     ii = 0;
	 while((*tptr != '\n') && (*tptr != ' ') && ( ii < 20))
	 {
	  zstr[ii] = *tptr;
	  ii += 1;
	  tptr++;
	 }
	zstr[ii] = 0;

    xval = atof(xstr);
	yval = atof(ystr);
	zval = atof(zstr);

	// printf("MCD xstr = %s ystr=%s zstr=%s \n",xstr,ystr,zstr);

	}

}  // end get_violation_mcd

//
//    violation
//         number    violation str:  ( f1-f2 )  MCD=X,Y,Z
//
void get_loc_violation()
{

char *tptr;
int ii;
char viol_num_str[20];
int viol_num;
char viol_type_str[120];
int has_mcd;
int debug;
     
      debug = 0;

	  if (debug) { printf("In get loc violation - line = %s \n", thisline); }

     tptr=thisline;

	 // get_violation_number();

	 while((( *tptr == ' ') || (*tptr == '\t')) &&
		               (*tptr != '\n')) // skip blanks and tabs
	 {
		 tptr++;
	 }
	ii = 0;

    while( isdigit(*tptr) && (ii < 20)) // skip blanks and tabs
	 {
		viol_num_str[ii] = *tptr;
		tptr++;
        ii += 1;
	 }
	viol_num_str[ii] = 0;
	viol_num = atoi(viol_num_str);

    while(( *tptr==' ') || (*tptr=='\n')) // skip blanks and tabs
	 {
		 tptr++;
	 }

	// get_violation_str();

	ii = 0;
    while(( *tptr!=':') && (ii<60)) // skip blanks and tabs
	 {
		  viol_type_str[ii]=*tptr;
		 tptr++;
		 ii += 1;
	 }
    viol_type_str[ii] = 0;

	
//	get_violation_range();

	has_mcd = check_mcd();

	if (debug) { printf("Has mcd = %d \n", has_mcd); }
	mcd_found = FALSE;

	if (has_mcd)
	{
		get_loc_mcd();
		mcd_found = TRUE;
	}

   if (debug)
   {
   printf("viol_num_str = %s viol_type_str = %s \n", viol_num_str, viol_type_str);
   }

   strncpy( current_viol_num,viol_num_str,20);
   strncpy( current_viol_type, viol_type_str,120);

   endoffile=getline(file1,thisline);

}


// 
//   a location file will have
//          Layer
//            _________ line
//               Violation
//               maybe MCD=x,y,z
//               at X,Y  1..n  or (w) at X,Y 1..n
//               Violation
//               maybe MCD=x,y,z
//               at X,Y  1..n  or (w) at X,Y 1..n
//                ...
//               Violation
//               maybe MCD=x,y,z
//               at X,Y  1..n  or (w) at X,Y 1..n  
//                blank line

void do_loc_info(  )
{
int blank_line_found;
int debug;


  debug = 0;

  if (debug)
  {
  printf("In do_loc_info  line = %s \n", thisline);
  }


  while( endoffile == FALSE)
  {
   do_loc_layer( );
   getline(file1,thisline);   // skip past ____ line

   blank_line_found=FALSE;

   while(( endoffile == FALSE) && ( blank_line_found == FALSE))
	 {
	  mcd_found = FALSE;
	  // getline(file1,thisline);   // skip past ____ line
	  get_loc_violation( );

	  if (mcd_found == FALSE)
	  {
	    get_loc_mcd();
		mcd_found = TRUE;
	  }
	  get_loc_ats();
	  blank_line_found=is_blank_line(thisline);
	 }

   endoffile = getline(file1,thisline);
  }

}  // do_loc_info

void do_loc2_file( char *infile_str)
{
  int largest_found;
  
  largest_found = FALSE;

  file1 = fopen(infile_str,"r");

  if (file1 == NULL)
    {
      printf("Unable to open the .loc file = %s \n",infile_str);
      exit(-1);
    }


  getline(file1, thisline);
  while(( endoffile == FALSE) && ( largest_found == FALSE))
    {
      if (strstr(thisline,"Largest hole") != NULL)
        {
          largest_found = TRUE;
        }

      getline(file1,thisline);

    }

  if (largest_found)
    {
	  getline(file1,thisline);
	  while( is_blank_line(thisline))
	  {
		  getline(file1,thisline);
	  }
      do_loc_info();
    }
  else
    {
      printf("Unable to find string = Largest Hole in .loc file \n");
      exit(-1);
    }

} // end do_loc2_file

//
//parse a .loc file
//
int do_loc_file( char *infile_str)
{
FILE *locfile;
 int endoffile;
 char thisline[200];
 int blank_line_found;
 char newxstr[100];
 char newystr[100];
 int short_line_found;            // line indicating shorts

 locfile = fopen(infile_str,"r");
 if (locfile == NULL)
   {
     printf("Return: Unable to open the .loc file = %s \n", infile_str);
     return(-1);
   }


  endoffile = getline(locfile,thisline);

  while( endoffile == FALSE)
    {
      if (strstr(thisline,"Component Side Excess and Deficits") != NULL)
	{
	  endoffile = getline(locfile,thisline);   // skip all dash line
	  endoffile = getline(locfile,thisline);  // skip count line
     endoffile = getline(locfile,thisline);  // 

	  blank_line_found = FALSE;

      while((blank_line_found == FALSE) && (endoffile == FALSE))
	    {
             split_line_seps(thisline,",");
             trim_str(str_array[0],newxstr);
			 trim_str(str_array[1],newystr);

             endoffile = getline(locfile,thisline);
             blank_line_found = is_blank_line(thisline);
        }
	  }

      if (strstr(thisline,"Component Side Opens and Shorts") != NULL)
	  {
      endoffile = getline(locfile,thisline);   // skip all dash line
      endoffile = getline(locfile,thisline);  // skip count line
      endoffile = getline(locfile,thisline);  // skip open count line
	  endoffile = getline(locfile,thisline);
      short_line_found = FALSE;
      blank_line_found = FALSE;

      while((short_line_found == FALSE) && (endoffile == FALSE)
		             && (blank_line_found == FALSE))
	    {
             split_line_seps(thisline,",");

             trim_str(str_array[0],newxstr);    // parse the location of the error
			 trim_str(str_array[1],newystr);

             endoffile = getline(locfile,thisline);
             blank_line_found = is_blank_line(thisline);
			 short_line_found = FALSE;
			 if (strstr(thisline,"short") != NULL) {

				 short_line_found = TRUE; }

        }
	  }
      endoffile = getline(locfile,thisline);

    }

  fclose(locfile);
  return(0);

} //

//
// make a sub directory
//
void mkdir ( char *infilestr)
{
char commandstr[120];

strncpy( commandstr,"mkdir ",30);
strcat( commandstr,infilestr);

system( commandstr);
}

int main ( int argc, char **argv)

{

// set debug flag

  debug = 0;

// do the beginning split here

 k = 0;               // first, find the number of headers

 while(( k < 100 ) && ((icomp_array[k].compstr[0] != 'z') 
	            |   ( icomp_array[k].compstr[1] != 'z') 
				|   ( icomp_array[k].compstr[2] != 'z')) )
	{
	  k += 1;
	}
 
  head_count = k;


 for (i = 0; i < 5000; i += 1)
   {
    start_index[i] = 0;
   }
    
 if (argc < 2)
 {
	 printf("Usage: splitgen fname \n");
	 exit(-1);
 }

 debug_test = 1;

 if ( debug_test == 0 )    // if not debugging using mfc
 { 
	 strncpy( openstr,argv[1],120); 
 }
 else
 {
 strncpy( openstr,"Ptero.det",20);   // for mfc debug
 }

 infile = fopen( openstr ,"r");
 
 if ( infile == NULL)
 {
	 printf("Error: Unable to open the input file %s \n", openstr);
	 exit(-1);

 }

 strncpy( basefilestr, openstr, 120);

 k = 0;
 while( ( k < strlen(basefilestr) ) && ( basefilestr[k] != '.' ))
	{
	  k += 1;
	}
 basefilestr[k] = NULLCHAR;

 
 lines_in = 0;

 while ( getline(infile, thisline) == 0)
    {
	  // printf("Line in = %s \n", thisline);
	  if (strlen(thisline) > 0)
	  {
	  thisline[strlen(thisline)-1] = 0;
	  }
	  trim_str( thisline, newstr);

      for ( k = 0; k < head_count; k += 1)
        {
         if (strstr(newstr, icomp_array[k].compstr) != NULL)   // a header found
            {
			 if ( strlen( newstr) == strlen(icomp_array[k].compstr))
			 {
             start_index[lines_in] = k + 1;
			 }
			 // printf("Setting start_index at %d to %d \n", lines_in,k+1);
            }
         }
      strncpy( rlines[lines_in], thisline, 120);
	  // printf("rline = %s \n", rlines[lines_in]);

      lines_in += 1;
	  // printf("lines_in = %d \n", lines_in);
    }

  fclose(infile);

  i = 0;
  printf("lines in = %d \n", lines_in);

  while( i < lines_in)
    {
      if (start_index[i] > 0 )
        {
          head_num = start_index[i] -1;
          strncpy( dirstr,icomp_array[head_num].subdirstr,120);
          strncpy( filetypestr,icomp_array[head_num].filetypestr,20);
          i += 1;
          if (strstr(rlines[i],"----") != NULL)  // dash underline
           {
            if (strlen( dirstr) > 0 )
              {
			   retcode = _access( dirstr,0);   // check to see if dir exists
               if (retcode == -1)
			   {
				   mkdir( dirstr);   // make a sub dir, if it doesn't exist already
			   }
               strncpy( outfilestr,dirstr,120);
               strcat(outfilestr,"\\");
			   strcat(outfilestr,basefilestr);
			   strcat(outfilestr,".");
               strcat(outfilestr,filetypestr);

               }
             else
               {
                strncpy( outfilestr,basefilestr,120);
                strcat( outfilestr, filetypestr);
                }

             outfile = fopen(  outfilestr,"w");     // open the new file

			 if ( i > 0) { fprintf(outfile,"%s\n",rlines[i-1]); }

             while(( start_index[i] == 0 ) && ( i < lines_in))
              {
                 fprintf(outfile,"%s\n",rlines[i]);
                 i += 1;
               }
              fclose( outfile);
              i = i -1;
             }
           }
      i += 1;
    }

//  now read in the  basefilename.lsu file ( Layer Summary )

 strncpy( lsu_file_str, basefilestr, 120);
 strcat( lsu_file_str, "_lsu.txt");

 do_lsu_file();
 

// do the main split here

 k = 0;               // first, find the number of headers

 while(( k < 100 ) && ((comp_array[k].compstr[0] != 'z') 
	            |   ( comp_array[k].compstr[1] != 'z') 
				|   ( comp_array[k].compstr[2] != 'z')) )
	{
	  k += 1;
	}
  
  head_count = k;

  if (debug)
  {
    for ( k = 0; k < head_count; k += 1)
	{
	  printf("compare string = %s k = %d dir = %s \n",
      comp_array[k].compstr,k, comp_array[k].subdirstr);
	}
  }

 for (i = 0; i < 5000; i += 1)
   {
    start_index[i] = 0;
   }
    
 
 infile = fopen( openstr,"r");

 k = 0;
 while( ( k < strlen(basefilestr) ) && ( basefilestr[k] != '.' ))
	{
	  k += 1;
	}
 basefilestr[k] = NULLCHAR;

 if ( infile == NULL)
   {
      printf("Cannot open the input file = %s \n", openstr);
   }

 lines_in = 0;

 while ( getline(infile, thisline) == 0)
    {
	  // printf("Line in = %s \n", thisline);
	   thisline[strlen(thisline)-1] = 0;      // turn CR to NULL

      for ( k = 0; k < head_count; k += 1)
        {
		 trim_str( thisline, newstr);

		 //printf("Comparing [%s] to [%s] \n", newstr, comp_array[k].compstr);

         if (strstr(newstr, comp_array[k].compstr) != NULL)   // a header found
            {
			 if (strlen(newstr) == strlen(comp_array[k].compstr))
			 {
             start_index[lines_in] = k + 1;
			 }
			 // printf("Setting start_index at %d to %d \n", lines_in,k+1);
            }
         }
      strncpy( rlines[lines_in], thisline, 120);
	  // printf("rline = %s \n", rlines[lines_in]);

      lines_in += 1;
	  // printf("lines_in = %d \n", lines_in);
    }

  fclose(infile);

  i = 0;
  // printf("lines in = %d \n", lines_in);

  while( i < lines_in)
    {
      if (start_index[i] > 0 )
        {
          head_num = start_index[i] -1;
          strncpy( dirstr,comp_array[head_num].subdirstr,120);
          strncpy( filetypestr,comp_array[head_num].filetypestr,20);
          i += 1;
          if (strstr(rlines[i],"----") != NULL)  // dash underline
           {
            if (strlen( dirstr) > 0 )
              {
			   retcode = _access( dirstr,0);
			   if (retcode == -1)   // if there isn't one already
			   {
                mkdir( dirstr);   // make a sub dir, if it doesn't exist already
			   }
               strncpy( outfilestr,dirstr,120);
               strcat(outfilestr,"\\");
			   strcat(outfilestr,basefilestr);
			   strcat(outfilestr,".");
               strcat(outfilestr,filetypestr);

               }
             else
               {
                strncpy( outfilestr,basefilestr,120);
                strcat( outfilestr, filetypestr);
                }

             outfile = fopen(  outfilestr,"w"); // open the new file
			 if ( i > 0)
			 {
             fprintf(outfile,"%s\n",rlines[i-1]);
			 }
             while(( start_index[i] == 0 ) && ( i < lines_in))
              {
                 fprintf(outfile,"%s\n",rlines[i]);
                 i += 1;
               }
              fclose( outfile);
              i = i -1;
             }
           }
      i += 1;
    }
          
  // read and process ths smp   ( surface mount pad file )

   strncpy(this_file_str, basefilestr,120);
   strcat(this_file_str,"_smp.txt");
   tfile = fopen(this_file_str,"r");

   if ( tfile != NULL)
   {
      fclose(tfile);
      printf("Processing the %s file (smp) \n", this_file_str);
      do_smp_file(this_file_str);
   }
   
// do_width_file
 
    strncpy(this_file_str, basefilestr,120);
    strcat(this_file_str,"_wdt.txt");
    tfile = fopen(this_file_str,"r");

    if ( tfile != NULL)
   {
      fclose(tfile);
      printf("Processing the %s file (width) \n", this_file_str);
      do_width_file(this_file_str);
   }

  // do_rgs_file

   strncpy(this_file_str, basefilestr,120);
   strcat(this_file_str,"_rgs.txt");
  tfile = fopen(this_file_str,"r");

  if ( tfile != NULL)
   {
      fclose(tfile);
      printf("Processing the %s file (rgs) \n", this_file_str);
//      do_rgs_file(this_file_str);
   }

  // do_smd_file(this_file_str);

   strncpy(this_file_str, basefilestr,120);
   strcat(this_file_str,"_smd.txt");
   tfile = fopen(this_file_str,"r");

   if ( tfile != NULL)
   {
      fclose(tfile);
      printf("Processing the %s file (smd) \n", this_file_str);
      do_smd_file(this_file_str);
   }

    // do_spacing_file(this_file_str);

    strncpy(this_file_str, basefilestr,120);
	strcat(this_file_str,"_spc.txt");
    tfile = fopen(this_file_str,"r");
   
   if ( tfile  != NULL)
   {
      fclose(tfile);
      printf("Processing the %s file (spacing) \n", this_file_str);
      do_spacing_file(this_file_str);
   }

 // do_drill_file(this_file_str);

    strncpy(this_file_str, basefilestr,120);
	strcat(this_file_str,"_drl.txt");
    tfile = fopen(this_file_str,"r");
   
   if ( tfile  != NULL)
   {
      fclose(tfile);
      printf("Processing the %s file (drill) \n", this_file_str);
      do_drill_file(this_file_str);
   }


   
 // do_loc_file(this_file_str);

    strncpy(this_file_str, basefilestr,120);
	strcat(this_file_str,".loc");
    tfile = fopen(this_file_str,"r");
   
   if ( tfile  != NULL)
   {
      fclose(tfile);
      printf("Processing the %s file (loc) \n", this_file_str);
      do_loc2_file(this_file_str);
   }

               
  
}  // end main

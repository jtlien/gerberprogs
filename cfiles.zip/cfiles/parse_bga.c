#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include <math.h>


#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// parse_bga.awk
//
// parses the extracted data file for bga and soldermask openings.
//
// Revision History
// 02/06/03 -initial release 

void parse_bga_call_out( char *mytype, double smoffset, double bgaoffset, 
						char *infilestr, char *outfilestr)
{

int endoffile;
int nf;
int mult;
int res;
double pad;
double sm;
double diff;
double ar;
char thisline[200];
char array0up[200];
char units[300];
FILE *file1;
FILE *outfile;


   // FS = "!"

  file1=fopen( infilestr,"r");
  if (file1 == NULL)
  {
	  printf("In parse_bga, unable to open the input file for reading = %s \n",infilestr);
	  exit(-1);
  }

  outfile=fopen( outfilestr,"w");
  if (outfile == NULL)
  {
	  printf("In parse_bga, unable to open the outfile file for reading = %s \n",outfilestr);
	  exit(-1);
  }


  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");

 while(endoffile == FALSE)
 {
  cv_toupper(str_array[0],array0up);

  if(strcmp( array0up,"J") == 0 )
  {
      cv_toupper(str_array[8],units);

      if (strcmp(units,"MILLIMETERS") == 0 )
	  {
         mult = 1000;
         res = 0;
      }
      else if ( strcmp(units,"MICRONS") == 0 )
	  {
         mult = 1;
         res = 0;
      }
      else 
	  {
         res = 1;
      }
  }

  if ( strcmp(mytype,"wb") == 0 )
  {
   if ((strcmp(str_array[1],"L01")==0) && (strcmp(str_array[2],"BGA")==0) ) 
	  {
        pad =  atof(str_array[5] ) * mult;
      }
   else if ((strcmp(str_array[1],"S0")==0) && (strcmp(str_array[2],"BGA")==0) )
	  {
        sm =   atof(str_array[5]) * mult;
      }
  }    
  else 
  {
   if (((strcmp(str_array[1],"BOTTOM") == 0 ) || (strcmp(str_array[1],"BASE")==0)) && 
		  (strcmp(str_array[2],"BGA")==0 ) )
	  {
        pad =  atof(str_array[5]) * mult;
      }
   else if ((strcmp(str_array[1],"S59") == 0 ) && 
		       (strcmp(str_array[2],"BGA") == 0 ) )
	  {
        sm =   atof(str_array[5])  * mult;
      }
  }
  
  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");

 }

  fclose(file1);

   pad = pad - bgaoffset ;
   sm = sm + smoffset;
   diff = fabs(sm-pad);
   ar = diff/2;
   fprintf(outfile,"%.0f %.0f %.0f %.0f\n",pad,sm,diff,ar);

   fclose(outfile);

}   // parse_bga_call_out


void parse_bga_call( char *mytype, double smoffset, double bgaoffset, char *infilestr)
{

int endoffile;
int nf;
int mult;
int res;
double pad;
double sm;
double diff;
double ar;
char thisline[200];
char array0up[200];
char units[300];
FILE *file1;


   // FS = "!"

  file1=fopen( infilestr,"r");
  if (file1 == NULL)
  {
	  printf("In parse_bga, unable to open the input file for reading = %s \n",infilestr);
	  exit(-1);
  }

  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");

 while(endoffile == FALSE)
 {
  cv_toupper(str_array[0],array0up);

  if(strcmp( array0up,"J") == 0 )
  {
      cv_toupper(str_array[8],units);

      if (strcmp(units,"MILLIMETERS") == 0 )
	  {
         mult = 1000;
         res = 0;
      }
      else if ( strcmp(units,"MICRONS") == 0 )
	  {
         mult = 1;
         res = 0;
      }
      else 
	  {
         res = 1;
      }
  }

  if ( strcmp(mytype,"wb") == 0 )
  {
   if ((strcmp(str_array[1],"L01")==0) && (strcmp(str_array[2],"BGA")==0) ) 
	  {
        pad =  atof(str_array[5] ) * mult;
      }
   else if ((strcmp(str_array[1],"S0")==0) && (strcmp(str_array[2],"BGA")==0) )
	  {
        sm =   atof(str_array[5]) * mult;
      }
  }    
  else 
  {
   if (((strcmp(str_array[1],"BOTTOM") == 0 ) || (strcmp(str_array[1],"BASE")==0)) && 
		  (strcmp(str_array[2],"BGA")==0 ) )
	  {
        pad =  atof(str_array[5]) * mult;
      }
   else if ((strcmp(str_array[1],"S59") == 0 ) && 
		       (strcmp(str_array[2],"BGA") == 0 ) )
	  {
        sm =   atof(str_array[5])  * mult;
      }
  }
  
  endoffile=getline(file1,thisline);
  nf=split_line_seps(thisline,"!");

 }

  fclose(file1);

   pad = pad - bgaoffset ;
   sm = sm + smoffset;
   diff = fabs(sm-pad);
   ar = diff/2;
   printf("%.0f %.0f %.0f %.0f\n",pad,sm,diff,ar);

}   // parse_bga_call


/*
int main( int argc, char **argv)
{

	if (argc != 5)
	{

       printf("In parse_bga, wrong number of arguments \n");
	   printf("Usage: parse_bga mytype smoffset bgaoffset infile \n");
	   exit(-1);

	}
	else
	{
		parse_bga_call( argv[1], atof(argv[2]), atof(argv[3]), argv[4]);
	}

}   // end main

  */

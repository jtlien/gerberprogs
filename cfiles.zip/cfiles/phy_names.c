#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  phy_names.awk  rev 1.0  7/31/95
//  written by Ted Ammann
//
//  This program is meant to work on the Allegro .tech report file
//  The output of this program are the rule names associated with
//  the physical rule check data in the .tech file. The reader is encouraged to
//  to look at the .tech file.
//
//  The output of this file is meant to be redirected ( UNIX ">") to
//  another file for further processing.
//  That further processing is done by the physical.awk program.

// The begin section of this program simply moves down the input file (.tech)
// until it finds the line containing physicalSetName. This takes us past the
// ALWAYS_CHECK/NEVER_CHECK portion of the .tech file and gets us to "data"
// portion of the file.

void phy_names_call_out( char *infile1str, char *outfilestr)
{

char parenstr[10];

FILE *file1;
FILE *outfile;
int kk,ll;
int endoffile;
char tempstr[120];
char thisline[200];
int number_fields;

     file1  = fopen(infile1str, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
	 }

     outfile  = fopen(outfilestr, "w");

     if (outfile == NULL)
	 {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
	 }

    endoffile = getline(file1,thisline);  
    number_fields = split_line(thisline);

    while( strstr(thisline,"physicalSetName") == NULL)
	  {                                //strip off all lines down to
         endoffile = getline(file1,thisline);    // physicalSetName
		 number_fields = split_line(thisline);
	  }



//********* Start Of Main ***************
//  The Main section of this program simply outputs the first 20 chars. of the
//  physical rule name on the current line.
//****************************************

   endoffile = getline(file1,thisline);    
   number_fields = split_line(thisline);

  while( endoffile == FALSE)
  {
   if( strstr(thisline,"physicalLayerGroup") != NULL)
   {  // The names we want start after the
                                      // containing spacingLayerGroup

    endoffile = getline(file1,thisline);
	number_fields = split_line(thisline);

	parenstr[0] = ')';
	parenstr[1] = 0;

    while (strstr(thisline,parenstr ) == NULL)
	{             // The Right Paren. ")" is the delimiter
                                     // for this section.

		 kk = 0;
		 for(ll=1; ll<21; ll += 1)
		 {
			 tempstr[kk] = str_array[0][ll];
			 kk += 1;
		 }
		 tempstr[kk] = 0;

         //printf("%s\n", substr($1,2,20)) // output the name
		 fprintf(outfile,"%s\n",tempstr);
         endoffile = getline(file1,thisline);  // get the next line.
		 number_fields = split_line(thisline);
    }

   fclose(file1);

   fclose(outfile);

   exit(0);  // exit the program -- we only need the names from the first
          // physical group (i.e. the names in any following physical groups
          // are assumed to be the same as the first group).

   }  // end of IF

   endoffile = getline(file1,thisline);
   number_fields = split_line(thisline);

  }

  fclose(file1);

}// end of phy_names_call_out


void phy_names_call( char *infile1str)
{

char parenstr[10];

FILE *file1;
int kk,ll;
int endoffile;
char tempstr[120];
char thisline[200];
int number_fields;

     file1  = fopen(infile1str, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
	 }

    endoffile = getline(file1,thisline);  
    number_fields = split_line(thisline);

    while( strstr(thisline,"physicalSetName") == NULL)
	  {                                //strip off all lines down to
         endoffile = getline(file1,thisline);    // physicalSetName
		 number_fields = split_line(thisline);
	  }



//********* Start Of Main ***************
//  The Main section of this program simply outputs the first 20 chars. of the
//  physical rule name on the current line.
//****************************************

   endoffile = getline(file1,thisline);    
   number_fields = split_line(thisline);

  while( endoffile == FALSE)
  {
   if( strstr(thisline,"physicalLayerGroup") != NULL)
   {  // The names we want start after the
                                      // containing spacingLayerGroup

    endoffile = getline(file1,thisline);
	number_fields = split_line(thisline);

	parenstr[0] = ')';
	parenstr[1] = 0;

    while (strstr(thisline,parenstr ) == NULL)
	{             // The Right Paren. ")" is the delimiter
                                     // for this section.

		 kk = 0;
		 for(ll=1; ll<21; ll += 1)
		 {
			 tempstr[kk] = str_array[0][ll];
			 kk += 1;
		 }
		 tempstr[kk] = 0;

         //printf("%s\n", substr($1,2,20)) // output the name
		 printf("%s\n",tempstr);
         endoffile = getline(file1,thisline);  // get the next line.
		 number_fields = split_line(thisline);
    }

   fclose(file1);

   exit(0);  // exit the program -- we only need the names from the first
          // physical group (i.e. the names in any following physical groups
          // are assumed to be the same as the first group).

   }  // end of IF

   endoffile = getline(file1,thisline);
   number_fields = split_line(thisline);

  }

  fclose(file1);

}// end of phy_names_call

/*
int main( int argc, char **argv)
{


	if (argc != 2)
	{
		printf("In phy_names, wrong number of arguments \n");
        printf("Usage: phy_names infile1 \n");
		exit(-1);
	}
   else
   {
	   phy_names_call( argv[1]);
   }


} // end main

  */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  pins_via.awk  rev 1.0  7/28/95
//  written by Ted Ammann
//
//  This program is meant to work on the following temporary files 
//     ??.tmp2   The .tmp2 is the output of strip.awk on the .spn file 
//     vias      vias is the output of via_info.awk on the .pad file
//               and Linfo file
//  To view these temp. files modify the create_probe script 
//  by commenting out the line that deletes the temp files.
//  ( change it back when done)  ;^)

//  The results from pins_via.awk are meant to be sorted  ( sort +5 -db )
//  and then redirected (UNIX ">") another file for further processing.
//  The sort above sorts by netname.

//  The output of this program is a multi-column file with the following format 
//    x-coord    y-coord   Layer   ref.des.  pin //     netname

//  Sample Output
//   -0.5000   -13.5000      L        U1      C16       CP01
//   -1.5002    -5.7730      U        U2      B17       CP01
//   -4.3757    -5.5570      U        U2      C5        CP02


// file1 below is a command line parameter specifing the name of the file
// that contains the layer information for each via type ( for us the temporary
// file called vias)


// The BEGIN section of the this program creates an array (a) whose subsripts
// are the via type name and the elements contain the via layer info.
// It also  initializes the variable uncnt to 1 ( this variable is used to give
// UNUSED nets a unique netname




struct astuff
{
	char layer[40];
	char layerabrev[40];   // not big enough?
} a[10000];

int aindex;


void find_in_astuff( char *instr, char *resstr)
{
int ii;

 ii =0;
 //printf("Look for %s \n",instr);

 while( ii < aindex)
 {
	 if ( strcmp( a[ii].layer, instr) == 0 )
	 {
       strncpy(resstr,a[ii].layerabrev,30);
	   //printf("Found in astuff = %s in = %s \n",resstr, instr);
	   return;
	 }
  ii += 1;
 }
 strncpy(resstr,"",10);
 return;
}

void pins_via_call_out( char *infile1str, char *infile2str, char *outfilestr)
{
int uncnt;
char thisline[200];
char name[200];
char ref_des[200];
char uncnt_str[120];
char layerabrevstr[300];
int endoffile;
FILE *file1;
FILE *file2;
FILE *outfile;
int number_fields;




     file1  = fopen(infile1str, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
	 }

     file2  = fopen(infile2str, "r");

     if (file2 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile2str);
	  exit(-1);
	 }

     outfile  = fopen(outfilestr, "w");

     if (outfile == NULL)
	 {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
	 }

     endoffile = getline(file1,thisline);
     number_fields = split_line(thisline);
	 aindex=0;
     while (endoffile==FALSE)
	 {
		   
		   if (( aindex > 100000) || ( aindex < 0))
		   {
			   printf("Pin number out of range = %d \n", aindex);
			   exit(-1);
		   }
		   else
		   {
            strncpy(a[aindex].layer,str_array[0],30);
			strncpy(a[aindex].layerabrev,str_array[1],30);
			aindex+=1;
		   }

           endoffile = getline(file1,thisline);
           number_fields = split_line(thisline);
     }

	 fclose(file1);

     uncnt = 1;



//******* Start of MAIN LOOP *************
//
//  The main purpose of this program is to combine information in the .tmp2
//  file with the information in the vias file
//**************************************

  endoffile = getline(file2,thisline);
   number_fields = split_line(thisline);

  while(endoffile == FALSE)
  {
   if (strstr(thisline,"unused") != NULL)
   {  // if the netname is "unused" do this special processing
                       // else do the normal processing
     strncpy(name,"UNUSED",20);
	 sprintf(uncnt_str,"%d",uncnt); // string cat 
	                                // (i.e. name = UNUSED1 if uncnt = 1)
	 strcat(name,uncnt_str);

     uncnt++;                // update uncnt

     if(number_fields > 5)
	 {    // data is output based on number of fields on current line
       strncpy(ref_des,str_array[0],120);  // ref_des is updated only when NF > 5
            // a[$5] below is the layer info based on via type (same for a[$2])

	   find_in_astuff( str_array[4],layerabrevstr);
	  
       fprintf(outfile,"%10.4f %10.4f %3s %5s %5s %20s\n",
		   atof(str_array[5]),atof(str_array[6])
		   ,layerabrevstr,ref_des,str_array[3],name);
	   
     }
   else  // less than 5 fields
	 {
	   find_in_astuff( str_array[1], layerabrevstr);
	   
        fprintf(outfile,"%10.4f %10.4f %3s %5s %5s %20s\n",
		   atof(str_array[2]),atof(str_array[3]),layerabrevstr,ref_des,
		   str_array[0],name);
	   
     }
   }
  else   // not unused
	{
     if(number_fields > 5)
	 { 
	   find_in_astuff( str_array[4],layerabrevstr);
	  
        strncpy(name,str_array[7],120);  // name is the current netname
        strncpy(ref_des,str_array[0],120);  // ref_des is updated only when NF > 5
        fprintf(outfile,"%10.4f %10.4f %3s %5s %5s %20s\n",
		   atof(str_array[5]),atof(str_array[6]),layerabrevstr,ref_des,
		   str_array[3],name);
	  
     }
    else 
	 {
	   find_in_astuff( str_array[1], layerabrevstr);
	   
        strncpy(name,str_array[4],120);   // name is the current netname
        fprintf(outfile,"%10.4f %10.4f %3s %5s %5s %20s\n",
		   atof(str_array[2]),atof(str_array[3]),layerabrevstr,ref_des,
		   str_array[0],name);
	  
     }
  }
  endoffile = getline(file2,thisline);
  number_fields = split_line(thisline);
 }
 fclose(file2);
 fclose(outfile);

} // end pins_via_call_out


void pins_via_call( char *infile1str, char *infile2str)
{
int uncnt;
char thisline[200];
char name[200];
char ref_des[200];
char uncnt_str[120];
char layerabrevstr[300];

int endoffile;
FILE *file1;
FILE *file2;
int number_fields;


	
     file1  = fopen(infile1str, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
	 }

     file2  = fopen(infile2str, "r");

     if (file2 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile2str);
	  exit(-1);
	 }

     endoffile = getline(file1,thisline);
     number_fields = split_line(thisline);
	 aindex=0;
     while (endoffile==FALSE)
	 {
		   
		   if (( aindex > 100000) || ( aindex < 0))
		   {
			   printf("Pin number out of range = %d \n", aindex);
			   exit(-1);
		   }
		   else
		   {
            strncpy(a[aindex].layer,str_array[0],30);
			strncpy(a[aindex].layerabrev,str_array[1],30);
			aindex+=1;

		   }

           endoffile = getline(file1,thisline);
           number_fields = split_line(thisline);
     }

	 fclose(file1);

     uncnt = 1;



//******* Start of MAIN LOOP *************
//
//  The main purpose of this program is to combine information in the .tmp2
//  file with the information in the vias file
//**************************************

  endoffile = getline(file2,thisline);
   number_fields = split_line(thisline);

  while(endoffile == FALSE)
  {
   if (strstr(thisline,"unused") != NULL)
   {  // if the netname is "unused" do this special processing
                       // else do the normal processing
     strncpy(name,"UNUSED",20);
	 sprintf(uncnt_str,"%d",uncnt); // string cat 
	                                // (i.e. name = UNUSED1 if uncnt = 1)
	 strcat(name,uncnt_str);

     uncnt++;                // update uncnt

     if(number_fields > 5)
	 {    // data is output based on number of fields on current line
       strncpy(ref_des,str_array[0],120);  // ref_des is updated only when NF > 5
            // a[$5] below is the layer info based on via type (same for a[$2])

	   find_in_astuff( str_array[4],layerabrevstr);
	   
       printf("%10.4f %10.4f %3s %5s %5s %20s\n",
		   atof(str_array[5]),atof(str_array[6])
		   ,layerabrevstr,ref_des,str_array[3],name);
	   
     }
   else  // less than 5 fields
	 {
	   find_in_astuff( str_array[1],layerabrevstr);
	   
        printf("%10.4f %10.4f %3s %5s %5s %20s\n",
		   atof(str_array[2]),atof(str_array[3]),layerabrevstr,ref_des,
		   str_array[0],name);
	   
     }
   }
  else   // not unused
	{
     if(number_fields > 5)
	 { 
	   find_in_astuff( str_array[4],layerabrevstr);
	   
        strncpy(name,str_array[7],120);  // name is the current netname
        strncpy(ref_des,str_array[0],120);  // ref_des is updated only when NF > 5
        printf("%10.4f %10.4f %3s %5s %5s %20s\n",
		   atof(str_array[5]),atof(str_array[6]),layerabrevstr,ref_des,
		   str_array[3],name);
	   
     }
    else 
	 {
	   find_in_astuff( str_array[1],layerabrevstr);
	   
        strncpy(name,str_array[4],120);   // name is the current netname
        printf("%10.4f %10.4f %3s %5s %5s %20s\n",
		   atof(str_array[2]),atof(str_array[3]),layerabrevstr,ref_des,
		   str_array[0],name);
	   
     }
  }
  endoffile = getline(file2,thisline);
  number_fields = split_line(thisline);
 }
 fclose(file2);

} // end pins_via_call

/*
int main( int argc, char **argv)
{

	if (argc != 3)
	{
		printf("In pins_via, wrong number of arguments \n");
		printf("Usage: pins_via  fname1 fname2 \n");
		exit(-1);
	}
    else
	{
		pins_via_call(argv[1],argv[2]);
	}


}

*/



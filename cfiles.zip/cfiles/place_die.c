#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//
// AWK script for creating WLBI die placement script for APD
// version 0.1
// Created by dah sometime in 1997
//
// History:
// 10/06/98 - wlee - added header comments

int first;
char date_now[200];
char str_array[120][120];
int number_fields;
FILE *file1;
char thisline[200];
int k;
int endoffile;
char *mytimestr;

//
// windows version of time
//
char *gettime_str( )
{
long *epochtime;
char *timestr;

 epochtime=malloc(sizeof(long));

 *epochtime=time(0); // since 1970


 timestr = ctime(epochtime);
 // printf("timestr = %s",timestr);

 return(timestr);

} // end gettime_str


int split_line( char *tline)
{
int ii;
char tstr[200];


char *token;

 ii = 0;

 strncpy( tstr, tline,200);

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 // for (jj=0; jj <ii ; jj += 1)
 //{
 //	 printf("str_array[%d] = %s \n",jj,str_array[jj]);
 //}

 return(ii);

} // end split_line

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

int main( int argc, char **argv)
 {

	mytimestr=malloc(200);

	mytimestr=gettime_str();

	// printf("Time = %s \n",mytimestr);

   file1  = fopen(argv[1], "r");

   if (file1 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",argv[1]);
	  exit(-1);
   }

 // if ("date" | getline date_now) < 0) {
 //   print "Can't get system date" > "/dev/stderr"
  //    strncpy(date_now,"some totally undefined time in history",120);
 // }

  printf("# script generated from [place_die.awk]\n");
  for (k = 1; k < argc; k++)
    printf("# input: [%s]\n", argv[k]);

  strncpy(date_now,mytimestr,120);

  printf("# %s\n", date_now);
  printf("version 11.6\n");
  printf("setwindow pcb\n");
  printf("\nplace refdes\n");

  first = 1;

  endoffile=getline(file1,thisline);
  number_fields = split_line(thisline);
  while( endoffile == FALSE)
   {
    if (number_fields == 3)
     {
      if (first == 0)
        printf("next\n\n");
      else
        first = 0;
      printf("fillin %s\n", str_array[0]);
      printf("pick %8.4f %8.4f\n", atof(str_array[1])/1000,
                       atof(str_array[2])/1000);
    }
    endoffile=getline(file1,thisline);
    number_fields = split_line(thisline);
   }

  fclose(file1);
  printf("done\n");

 } // end main

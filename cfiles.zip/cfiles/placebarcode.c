#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

char fname_str[120];
char dcode[120];
FILE *fnamefile;
double X;
double Y;
double wide;
double mult1;
double narrow;
double Istep;
char str_array[120][120];

struct bcodestuff
{
  char bstr[120];
  char charstr[4];
} barcode_array[120];
  

int letter_in_barcode( char inlet)
{
int foundone;

int ii;

foundone = FALSE;
ii =0;

while ((ii < 44) && (foundone == FALSE))
{
  if (barcode_array[ii].charstr[0] == inlet)
  {
	  return(TRUE);
	  foundone=TRUE;
  }

  ii += 1;
}
return(FALSE);

}  // letter_in_barcode

void get_barcode_str( char inlet, char *result_str)
{
int foundone;

int ii;

foundone = FALSE;
ii =0;

 while ((ii < 44) && (foundone == FALSE))
 {
  if (barcode_array[ii].charstr[0] == inlet)
  {
	  strncpy(result_str,barcode_array[ii].bstr,20);
	  foundone=TRUE;
  }

  ii += 1;
 }

 if (foundone == FALSE)
 {
  printf("Error: char = %c not found in barcode array \n",inlet);

 } 

}  // letter_in_barcode

void  printbar(char letter)
{
char barcode_str[120];
int j;
int debug;

   debug=1;
   get_barcode_str( letter, barcode_str);
   for(j = 1; j<= 9; j++){
    
      if((j % 2) != 0){  // if odd then a bar
         if(barcode_str[j-1] == 'n')
		 {
            X += narrow/2.0;
            strncpy(dcode,"D686",20);
			if (debug) { printf("X,Y mult1 = %f, %f %f \n", X, Y , mult1); }

            fprintf(fnamefile,"G54%s*\nX%0.0fY%0.0fD03*\n",dcode,X*mult1,Y*mult1); 
            X +=  narrow/2.0;
         }
         else
		 {
            strncpy(dcode,"D687",20);
            X += wide/2.0;
            if (debug) { printf("X,Y mult1 = %f, %f %f \n", X, Y , mult1); }
            fprintf(fnamefile,"G54%s*\nX%0.0fY%0.0fD03*\n",dcode,X*mult1,Y*mult1);
            X += wide/2.0; 
         }
      }
      else
	  {            // f even then a space
         if( barcode_str[j-1] == 'n')
		 {
             X += narrow;
         }
         else{
             X += wide;
         }
      }  
   }
}    // printbar

void  parsetextbc(char *mystring)
{
int len;
char letter;
int i;

  len = strlen(mystring);
  for( i = 0 ; i < len; i++)
  {
      letter = toupper( mystring[i]);
      if( letter_in_barcode(letter))
	  {
          printbar(letter);
          X += Istep;
      }
      else
	  {
         printf("FATAL ERROR\n");
         exit(99);
      }
  }
}

void printneg(char letter)
{
char barcode_str[120];
int j;
int debug;

   debug=1;

   get_barcode_str( letter, barcode_str);
   for(j = 1; j<= 9; j++){
       // 
      if((j % 2) == 0){  // if odd then a bar
         if( barcode_str[j-1] == 'n'){
            X += narrow/2.0;
            strncpy(dcode,"D686",20);
			if (debug) { printf("X,Y mult1 = %f, %f %f \n", X, Y , mult1); }
            fprintf(fnamefile,"G54%s*\nX%0.0fY%0.0fD03*\n",dcode,X*mult1,Y*mult1);
            X +=  narrow/2.0;
         }
         else{
            strncpy(dcode,"D687",20);
            X += wide/2.0;
            if (debug) { printf("X,Y mult1 = %f, %f %f \n", X, Y , mult1); }
            fprintf(fnamefile,"G54%s*\nX%0.0fY%0.0fD03*\n",dcode,X*mult1,Y*mult1);
            X += wide/2.0; 
         }
      }
      else
	  {            // if even then a space
         if( barcode_str[j-1] == 'n')
		 {
             X += narrow;
         }
         else
		 {
             X += wide;
         }
      }  
   }
}

void parseneg(char *mystring)
{
int len;
char letter;
int i;

  len = strlen(mystring);
  fprintf(fnamefile,"G54D688*\nX%0.0fY%0.0fD03*\n",X*mult1,Y*mult1);
  X += 1.27;
  for( i = 0 ; i < len; i++)
  {
    letter = toupper( mystring[i]);
    if( letter_in_barcode(letter))
	{
	 printneg(letter);
	 X += Istep/2.0;
	 fprintf(fnamefile,"G54D689*\nX%0.0fY%0.0fD03*\n",X*mult1,Y*mult1);
	 X += Istep/2.0;
    }
    else
	{
	printf("FATAL ERROR\n");
	exit(99);
    }
  }
  X += 1.27 -Istep;

  fprintf(fnamefile,"G54D688*\nX%0.0fY%0.0fD03*\n",X*mult1,Y*mult1);
}

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line



//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

void placebarcode_call( char *file1str)
{
  
double tmp;
double bclen;
double clen;
int tlen;
double tlend;
int endoffile;
char thisline[120];
int number_fields;
int kk;
char arg1str[300];
FILE *file1;
int mult;
int numc;

    mult=0;

   file1  = fopen(file1str, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",file1str);
	  exit(-1);
	 }
     strncpy(barcode_array[0].bstr, "nnnwwnwnn",20);
     strncpy(barcode_array[1].bstr, "wnnwnnnnw",20);
     strncpy(barcode_array[2].bstr, "nnwwnnnnw",20);
     strncpy(barcode_array[3].bstr, "wnwwnnnnn",20);
     strncpy(barcode_array[4].bstr, "nnnwwnnnw",20);
     strncpy(barcode_array[5].bstr, "wnnwwnnnn",20);
     strncpy(barcode_array[6].bstr, "nnwwwnnnn",20);
     strncpy(barcode_array[7].bstr, "nnnwnnwnw",20);
     strncpy(barcode_array[8].bstr, "wnnwnnwnn",20);
     strncpy(barcode_array[9].bstr, "nnwwnnwnn",20);
     strncpy(barcode_array[10].bstr, "wnnnnwnnw",20);
     strncpy(barcode_array[11].bstr, "nnwnnwnnw",20);
     strncpy(barcode_array[12].bstr, "wnwnnwnnn",20);
     strncpy(barcode_array[13].bstr, "nnnnwwnnw",20);
     strncpy(barcode_array[14].bstr, "wnnnwwnnn",20);
     strncpy(barcode_array[15].bstr, "nnwnwwnnn",20);
     strncpy(barcode_array[16].bstr, "nnnnnwwnw",20);
     strncpy(barcode_array[17].bstr, "wnnnnwwnn",20);
     strncpy(barcode_array[18].bstr, "nnwnnwwnn",20);
     strncpy(barcode_array[19].bstr, "nnnnwwwnn",20);
     strncpy(barcode_array[20].bstr, "wnnnnnnww",20);
     strncpy(barcode_array[21].bstr, "nnwnnnnww",20);
     strncpy(barcode_array[22].bstr, "wnwnnnnwn",20);
     strncpy(barcode_array[23].bstr, "nnnnwnnww",20);
     strncpy(barcode_array[24].bstr, "wnnnwnnwn",20);
     strncpy(barcode_array[25].bstr, "nnwnwnnwn",20);
     strncpy(barcode_array[26].bstr, "nnnnnnwww",20);
     strncpy(barcode_array[27].bstr, "wnnnnnwwn",20);
     strncpy(barcode_array[28].bstr, "nnwnnnwwn",20);
     strncpy(barcode_array[29].bstr, "nnnnwnwwn",20);
     strncpy(barcode_array[30].bstr, "wwnnnnnnw",20);
     strncpy(barcode_array[31].bstr, "nwwnnnnnw",20);
     strncpy(barcode_array[32].bstr, "wwwnnnnnn",20);
     strncpy(barcode_array[33].bstr, "nwnnwnnnw",20);
     strncpy(barcode_array[34].bstr, "wwnnwnnnn",20);
     strncpy(barcode_array[35].bstr, "nwwnwnnnn",20);
     strncpy(barcode_array[36].bstr, "nwnnnnwnw",20);
     strncpy(barcode_array[37].bstr, "wwnnnnwnn",20);
     strncpy(barcode_array[38].bstr, "nwwnnnwnn",20);
     strncpy(barcode_array[39].bstr, "nwnnwnwnn",20);
     strncpy(barcode_array[40].bstr, "nwnwnwnnn",20);
     strncpy(barcode_array[41].bstr, "nwnwnnnwn",20);
     strncpy(barcode_array[42].bstr, "nwnnnwnwn",20);
     strncpy(barcode_array[43].bstr, "nnnwnwnwn",20);

     strncpy(barcode_array[0].charstr,"0",4);
     strncpy(barcode_array[1].charstr,"1",4);
     strncpy(barcode_array[2].charstr,"2",4);
     strncpy(barcode_array[3].charstr,"3",4);
     strncpy(barcode_array[4].charstr,"4",4);
     strncpy(barcode_array[5].charstr,"5",4);
     strncpy(barcode_array[6].charstr,"6",4);
     strncpy(barcode_array[7].charstr,"7",4);
     strncpy(barcode_array[8].charstr,"8",4);
     strncpy(barcode_array[9].charstr,"9",4);
     strncpy(barcode_array[10].charstr,"A",4);
     strncpy(barcode_array[11].charstr,"B",4);
     strncpy(barcode_array[12].charstr,"C",4);
     strncpy(barcode_array[13].charstr,"D",4);
     strncpy(barcode_array[14].charstr,"E",4);
     strncpy(barcode_array[15].charstr,"F",4);
     strncpy(barcode_array[16].charstr,"G",4);
     strncpy(barcode_array[17].charstr,"H",4);
     strncpy(barcode_array[18].charstr,"I",4);
     strncpy(barcode_array[19].charstr,"J",4);
     strncpy(barcode_array[20].charstr,"K",4);
     strncpy(barcode_array[21].charstr,"L",4);
     strncpy(barcode_array[22].charstr,"M",4);
     strncpy(barcode_array[23].charstr,"N",4);
     strncpy(barcode_array[24].charstr,"O",4);
     strncpy(barcode_array[25].charstr,"P",4);
     strncpy(barcode_array[26].charstr,"Q",4);
     strncpy(barcode_array[27].charstr,"R",4);
     strncpy(barcode_array[28].charstr,"S",4);
     strncpy(barcode_array[29].charstr,"T",4);
     strncpy(barcode_array[30].charstr,"U",4);
     strncpy(barcode_array[31].charstr,"V",4);
     strncpy(barcode_array[32].charstr,"W",4);
     strncpy(barcode_array[33].charstr,"X",4);
     strncpy(barcode_array[34].charstr,"Y",4);
     strncpy(barcode_array[35].charstr,"Z",4);
     strncpy(barcode_array[36].charstr,"-",4);
     strncpy(barcode_array[37].charstr,".",4);
     strncpy(barcode_array[38].charstr,"_",4);
     strncpy(barcode_array[39].charstr,"*",4);
     strncpy(barcode_array[40].charstr,"$",4);
     strncpy(barcode_array[41].charstr,"/",4);
     strncpy(barcode_array[42].charstr,"+",4);
     strncpy(barcode_array[43].charstr,"%",4);

     X=0.0;
     Y=0.0;
     wide = .508;
     narrow = .254;
     Istep = .381;

     if( mult == 0 )
	 {
         mult = 4;
     }

     mult1 = pow(10,mult);

    endoffile=getline(file1,thisline);
	number_fields=split_line(thisline);

    while(endoffile==FALSE)
	{

     Y = -161.29;
     // numc = length($3)
      numc = strlen(str_array[2]);

      clen = 3.0 * wide + 6.0 * narrow;
       bclen = numc * clen + (numc-1) * Istep;
      // print $2 "   " bclen "   " numc |"cat 1>&2"
      tmp = bclen/2.0;
     // split(tmp,x,".")   is this rounding?
     // X = ("-" x[1] "." substr(x[2],1,1))

	  tlen = (int) floor( tmp * 10.0);
	  tlend = tlen/10.0;

      // X= - bclen;
	  X = - tlend;

      X += 0;
      strncpy(fname_str,str_array[1],120);
      strncat(fname_str,".bc",5);


      fnamefile = fopen(fname_str, "w");

      if (fnamefile == NULL)
	  {
	   printf("Error: Unable to open the output file = %s \n",fname_str);
	   exit(-1);
	  }

	  strncpy(arg1str,str_array[0],100);

	  for(kk=0; kk < (signed int) strlen(arg1str); kk += 1)
	  {
		arg1str[kk]=toupper(arg1str[kk]);
	  }
      if( strstr(arg1str,"POS") != NULL)
	  {
       parsetextbc(str_array[2]);
	  }
      else 
	  {
        X -= 1.27;
        parseneg(str_array[2]);
	  }

    fclose(fnamefile);

	endoffile=getline(file1,thisline);
	number_fields=split_line(thisline);

 }

 fclose(file1);

} // placebarcode_call

int main( int argc, char **argv)
{

	placebarcode_call( argv[1]);

}
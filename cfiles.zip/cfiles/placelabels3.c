#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>


#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

char str_array[120][120];
int nf;

struct alphastuff
{
	char gchar;
	char glines[40][40];
} alpha[44];

char glines[40][40];
char letter;
char thisline[120];

int xsize;
int ysize;
int tmp1;

double X1;
double X2;
double Y1;

double XLOW;
double YLOW;
double XHIGH;
double YHIGH;
double YBADLOW;
double YBADHIGH;
double YBADLOW;
double YBADHIGH;
double XOFF;
double DOUBLEVAL;
int xval;
int yval;
int XVal;
int YVal;

int xcnt;
int ycnt;
int endoffile;


FILE *file1,*file2;
FILE *outfile;

int Xfile;
int Yfile;


void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk,ll;

  ii=0;
  kk = 0;

  ll = strlen(instr);

  if ( ll > 0)          // remove possible end of line from end of string
  {
	  if (instr[ll-1] == 10)
	  {
		  instr[ll-1] = 0;
	  }
  }

 while((instr[ii] != srchstr[0]) && ( ii < strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;


}  // end split

//
// perform awk compatible awk_index, counts from 1 at the leftmost
//
int awk_index( char *instr, char *inchr)
{
int kk,ll,mm;
char tstr[120];

	if (strstr(instr, inchr) == NULL)    // not found at all in string, return 0
	{
		return(0);
	}
	else    // the inchr string is a substring
	{
		kk = 0;
		while( kk < strlen( instr))
		{
          ll = 0;
		  mm = kk;
		  while( mm < strlen( instr))
		  {
			tstr[ll] = instr[mm];
			mm += 1;
			ll += 1;
		  }
		  tstr[ll] = 0;
		  if (strstr( tstr,inchr) == NULL)  // no longer found as substring
		  {
			return(kk);
		  }
		 kk += 1;
		}
	}

  return(0);

 
} // awk compatible index


// perform awk compatible substr, except the 4th parameter is the
//   result string
//
void awk_substr( char *instr, int sbegin, int slength, char *resultstr)
{

char tstr[120];
int kk;
int ll;

     if ( sbegin > 0)
	 {
		 sbegin = sbegin-1;
	 }
     kk = sbegin;
     ll = 0;
	 while ( ( kk < strlen(instr) && ( ll < slength)) )
	 {
		 tstr[ll] = instr[kk];
		 kk += 1;
		 ll  += 1;
	 }
	 tstr[ll]=0;

	 strncpy( resultstr,tstr,slength+2);

}   // awk substr

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline


void init_alpha_glines( )
{

strncpy(alpha[0].glines[0],"G54D548*",40);
strncpy(alpha[0].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[0].glines[2],"Y-3750D01*",40);
strncpy(alpha[0].glines[3],"X0Y11250D01*",40);
strncpy(alpha[0].glines[4],"X7500Y-3750D01*",40);
strncpy(alpha[0].glines[5],"Y-11250D01*",40);
strncpy(alpha[0].glines[6],"X-7500Y-3750D02*",40);
strncpy(alpha[0].glines[7],"X7500D01*",40);
strncpy(alpha[0].glines[8],"M02*",40);
strncpy(alpha[0].glines[9],"",4);

strncpy(alpha[1].glines[0],"G54D548*",40);
strncpy(alpha[1].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[1].glines[2],"X3750D01*",40);
strncpy(alpha[1].glines[3],"X7500Y-7500D01*",40);
strncpy(alpha[1].glines[4],"Y-3750D01*",40);
strncpy(alpha[1].glines[5],"X3750Y0D01*",40);
strncpy(alpha[1].glines[6],"X-3750D01*",40);
strncpy(alpha[1].glines[7],"X3750D02*",40);
strncpy(alpha[1].glines[8],"X7500Y3750D01*",40);
strncpy(alpha[1].glines[9],"Y7500D01*",40);
strncpy(alpha[1].glines[10],"X3750Y11250D01*",40);
strncpy(alpha[1].glines[11],"X-7500D01*",40);
strncpy(alpha[1].glines[12],"X-3750D02*",40);
strncpy(alpha[1].glines[13],"Y-11250D01*",40);
strncpy(alpha[1].glines[14],"M02*",40);
strncpy(alpha[1].glines[15],"",4);

strncpy(alpha[2].glines[0],"G54D548*",40);
strncpy(alpha[2].glines[1],"X7500Y-7500D02*",40);
strncpy(alpha[2].glines[2],"X3750Y-11250D01*",40);
strncpy(alpha[2].glines[3],"X-3750D01*",40);
strncpy(alpha[2].glines[4],"X-7500Y-7500D01*",40);
strncpy(alpha[2].glines[5],"Y7500D01*",40);
strncpy(alpha[2].glines[6],"X-3750Y11250D01*",40);
strncpy(alpha[2].glines[7],"X3750D01*",40);
strncpy(alpha[2].glines[8],"X7500Y7500D01*",40);
strncpy(alpha[2].glines[9],"M02*",40);
strncpy(alpha[2].glines[10],"",4);

strncpy(alpha[3].glines[0],"G54D548*",40);
strncpy(alpha[3].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[3].glines[2],"X3750D01*",40);
strncpy(alpha[3].glines[3],"X7500Y-7500D01*",40);
strncpy(alpha[3].glines[4],"Y7500D01*",40);
strncpy(alpha[3].glines[5],"X3750Y11250D01*",40);
strncpy(alpha[3].glines[6],"X-7500D01*",40);
strncpy(alpha[3].glines[7],"X-3750D02*",40);
strncpy(alpha[3].glines[8],"Y-11250D01*",40);
strncpy(alpha[3].glines[9],"M02*",40);
strncpy(alpha[3].glines[10],"",4);

strncpy(alpha[4].glines[0],"G54D548*",40);
strncpy(alpha[4].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[4].glines[2],"Y11250D01*",40);
strncpy(alpha[4].glines[3],"X7500D01*",40);
strncpy(alpha[4].glines[4],"X-7500Y0D02*",40);
strncpy(alpha[4].glines[5],"X0D01*",40);
strncpy(alpha[4].glines[6],"X-7500Y-11250D02*",40);
strncpy(alpha[4].glines[7],"X7500D01*",40);
strncpy(alpha[4].glines[8],"M02*",40);
strncpy(alpha[4].glines[9],"",4);

strncpy(alpha[5].glines[0],"G54D548*",40);
strncpy(alpha[5].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[5].glines[2],"Y11250D01*",40);
strncpy(alpha[5].glines[3],"X7500D01*",40);
strncpy(alpha[5].glines[4],"X-7500Y0D02*",40);
strncpy(alpha[5].glines[5],"X0D01*",40);
strncpy(alpha[5].glines[6],"M02*",40);
strncpy(alpha[5].glines[7],"",4);

strncpy(alpha[6].glines[0],"G54D548*",40);
strncpy(alpha[6].glines[1],"X3750Y0D02*",40);
strncpy(alpha[6].glines[2],"X7500D01*",40);
strncpy(alpha[6].glines[3],"Y-11250D01*",40);
strncpy(alpha[6].glines[4],"X-3750D01*",40);
strncpy(alpha[6].glines[5],"X-7500Y-7500D01*",40);
strncpy(alpha[6].glines[6],"Y7500D01*",40);
strncpy(alpha[6].glines[7],"X-3750Y11250D01*",40);
strncpy(alpha[6].glines[8],"X7500D01*",40);
strncpy(alpha[6].glines[9],"M02*",40);
strncpy(alpha[6].glines[10],"",4);


strncpy(alpha[7].glines[0],"G54D548*",40);
strncpy(alpha[7].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[7].glines[2],"Y11250D01*",40);
strncpy(alpha[7].glines[3],"Y0D02*",40);
strncpy(alpha[7].glines[4],"X7500D01*",40);
strncpy(alpha[7].glines[5],"Y11250D02*",40);
strncpy(alpha[7].glines[6],"Y-11250D01*",40);
strncpy(alpha[7].glines[7],"M02*",40);
strncpy(alpha[7].glines[8],"",4);

strncpy(alpha[8].glines[0],"G54D548*",40);
strncpy(alpha[8].glines[1],"X-3750Y11250D02*",40);
strncpy(alpha[8].glines[2],"X3750D01*",40);
strncpy(alpha[8].glines[3],"X0D02*",40);
strncpy(alpha[8].glines[4],"Y-11250D01*",40);
strncpy(alpha[8].glines[5],"X-3750D02*",40);
strncpy(alpha[8].glines[6],"X3750D01*",40);
strncpy(alpha[8].glines[7],"M02*",40);
strncpy(alpha[8].glines[8],"",4);

strncpy(alpha[9].glines[0],"G54D548*",40);
strncpy(alpha[9].glines[1],"X-7500Y-7500D02*",40);
strncpy(alpha[9].glines[2],"X-3750Y-11250D01*",40);
strncpy(alpha[9].glines[3],"X3750D01*",40);
strncpy(alpha[9].glines[4],"X7500Y-7500D01*",40);
strncpy(alpha[9].glines[5],"Y11250D01*",40);
strncpy(alpha[9].glines[6],"M02*",40);
strncpy(alpha[9].glines[7],"",4);

strncpy(alpha[10].glines[0],"G54D548*",40);
strncpy(alpha[10].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[10].glines[2],"Y11250D01*",40);
strncpy(alpha[10].glines[3],"X7500D02*",40);
strncpy(alpha[10].glines[4],"X-3750Y0D01*",40);
strncpy(alpha[10].glines[5],"X-7500D01*",40);
strncpy(alpha[10].glines[6],"X-3750D02*",40);
strncpy(alpha[10].glines[7],"X7500Y-11250D01*",40);
strncpy(alpha[10].glines[8],"M02*",40);
strncpy(alpha[10].glines[9],"",4);

strncpy(alpha[11].glines[0],"G54D548*",40);
strncpy(alpha[11].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[11].glines[2],"Y-11250D01*",40);
strncpy(alpha[11].glines[3],"X7500D01*",40);
strncpy(alpha[11].glines[4],"M02*",40);
strncpy(alpha[11].glines[5],"",4);

strncpy(alpha[12].glines[0],"G54D548*",40);
strncpy(alpha[12].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[12].glines[2],"Y11250D01*",40);
strncpy(alpha[12].glines[3],"X0Y-3750D01*",40);
strncpy(alpha[12].glines[4],"X7500Y11250D01*",40);
strncpy(alpha[12].glines[5],"Y-11250D01*",40);
strncpy(alpha[12].glines[6],"M02*",40);
strncpy(alpha[12].glines[7],"",4);

strncpy(alpha[13].glines[0],"G54D548*",40);
strncpy(alpha[13].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[13].glines[2],"Y11250D01*",40);
strncpy(alpha[13].glines[3],"X7500Y-11250D01*",40);
strncpy(alpha[13].glines[4],"Y11250D01*",40);
strncpy(alpha[13].glines[5],"M02*",40);
strncpy(alpha[13].glines[6],"",4);

strncpy(alpha[14].glines[0],"G54D548*",40);
strncpy(alpha[14].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[14].glines[2],"Y11250D01*",40);
strncpy(alpha[14].glines[3],"X7500D01*",40);
strncpy(alpha[14].glines[4],"Y-11250D01*",40);
strncpy(alpha[14].glines[5],"X-7500D01*",40);
strncpy(alpha[14].glines[6],"M02*",40);
strncpy(alpha[14].glines[7],"",4);

strncpy(alpha[15].glines[0],"G54D548*",40);
strncpy(alpha[15].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[15].glines[2],"Y11250D01*",40);
strncpy(alpha[15].glines[3],"X3750D01*",40);
strncpy(alpha[15].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[15].glines[5],"Y3750D01*",40);
strncpy(alpha[15].glines[6],"X3750Y0D01*",40);
strncpy(alpha[15].glines[7],"X-7500D01*",40);
strncpy(alpha[15].glines[8],"M02*",40);
strncpy(alpha[15].glines[9],"",4);

strncpy(alpha[16].glines[0],"G54D548*",40);
strncpy(alpha[16].glines[1],"X0Y-3750D02*",40);
strncpy(alpha[16].glines[2],"X3750Y-7500D01*",40);
strncpy(alpha[16].glines[3],"X0Y-11250D01*",40);
strncpy(alpha[16].glines[4],"X-3750D01*",40);
strncpy(alpha[16].glines[5],"X-7500Y-7500D01*",40);
strncpy(alpha[16].glines[6],"Y7500D01*",40);
strncpy(alpha[16].glines[7],"X-3750Y11250D01*",40);
strncpy(alpha[16].glines[8],"X3750D01*",40);
strncpy(alpha[16].glines[9],"X7500Y7500D01*",40);
strncpy(alpha[16].glines[10],"Y-3750D01*",40);
strncpy(alpha[16].glines[11],"X3750Y-7500D01*",40);
strncpy(alpha[16].glines[12],"X7500Y-11250D01*",40);
strncpy(alpha[16].glines[13],"M02*",40);
strncpy(alpha[16].glines[14],"",4);

strncpy(alpha[17].glines[0],"G54D548*",40);
strncpy(alpha[17].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[17].glines[2],"Y11250D01*",40);
strncpy(alpha[17].glines[3],"X3750D01*",40);
strncpy(alpha[17].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[17].glines[5],"Y3750D01*",40);
strncpy(alpha[17].glines[6],"X3750Y0D01*",40);
strncpy(alpha[17].glines[7],"X-7500D01*",40);
strncpy(alpha[17].glines[8],"X-3750D02*",40);
strncpy(alpha[17].glines[9],"X7500Y-11250D01*",40);
strncpy(alpha[17].glines[10],"M02*",40);
strncpy(alpha[17].glines[11],"",4);

strncpy(alpha[18].glines[0],"G54D548*",40);
strncpy(alpha[18].glines[1],"X-7500Y-7500D02*",40);
strncpy(alpha[18].glines[2],"X-3750Y-11250D01*",40);
strncpy(alpha[18].glines[3],"X3750D01*",40);
strncpy(alpha[18].glines[4],"X7500Y-7500D01*",40);
strncpy(alpha[18].glines[5],"X-7500Y7500D01*",40);
strncpy(alpha[18].glines[6],"X-3750Y11250D01*",40);
strncpy(alpha[18].glines[7],"X3750D01*",40);
strncpy(alpha[18].glines[8],"X7500Y7500D01*",40);
strncpy(alpha[18].glines[9],"M02*",40);
strncpy(alpha[18].glines[10],"",4);

strncpy(alpha[19].glines[0],"G54D548*",40);
strncpy(alpha[19].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[19].glines[2],"X7500D01*",40);
strncpy(alpha[19].glines[3],"X0D02*",40);
strncpy(alpha[19].glines[4],"Y-11250D01*",40);
strncpy(alpha[19].glines[5],"M02*",40);
strncpy(alpha[19].glines[6],"",4);

strncpy(alpha[20].glines[0],"G54D548*",40);
strncpy(alpha[20].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[20].glines[2],"Y-7500D01*",40);
strncpy(alpha[20].glines[3],"X-3750Y-11250D01*",40);
strncpy(alpha[20].glines[4],"X3750D01*",40);
strncpy(alpha[20].glines[5],"X7500Y-7500D01*",40);
strncpy(alpha[20].glines[6],"Y11250D01*",40);
strncpy(alpha[20].glines[7],"M02*",40);
strncpy(alpha[20].glines[8],"",4);

strncpy(alpha[21].glines[0],"G54D548*",40);
strncpy(alpha[21].glines[1],"X-6150Y11250D02*",40);
strncpy(alpha[21].glines[2],"X975Y-11250D01*",40);
strncpy(alpha[21].glines[3],"X8475Y11250D01*",40);
strncpy(alpha[21].glines[4],"M02*",40);
strncpy(alpha[21].glines[5],"",4);

strncpy(alpha[22].glines[0],"G54D548*",40);
strncpy(alpha[22].glines[1],"X-6150Y11250D02*",40);
strncpy(alpha[22].glines[2],"X-1275Y-11250D01*",40);
strncpy(alpha[22].glines[3],"X975Y0D01*",40);
strncpy(alpha[22].glines[4],"X3600Y-11250D01*",40);
strncpy(alpha[22].glines[5],"X8475Y11250D01*",40);
strncpy(alpha[22].glines[6],"M02*",40);
strncpy(alpha[23].glines[7],"",4);

strncpy(alpha[23].glines[0],"G54D548*",40);
strncpy(alpha[23].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[23].glines[2],"X7500Y11250D01*",40);
strncpy(alpha[23].glines[3],"X-7500D02*",40);
strncpy(alpha[23].glines[4],"X7500Y-11250D01*",40);
strncpy(alpha[23].glines[5],"M02*",40);
strncpy(alpha[23].glines[6],"",4);

strncpy(alpha[24].glines[0],"G54D548*",40);
strncpy(alpha[24].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[24].glines[2],"X0Y0D01*",40);
strncpy(alpha[24].glines[3],"Y-11250D01*",40);
strncpy(alpha[24].glines[4],"Y0D02*",40);
strncpy(alpha[24].glines[5],"X7500Y11250D01*",40);
strncpy(alpha[24].glines[6],"M02*",40);
strncpy(alpha[25].glines[7],"",4);

strncpy(alpha[25].glines[0],"G54D548*",40);
strncpy(alpha[25].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[25].glines[2],"X7500D01*",40);
strncpy(alpha[25].glines[3],"X-7500Y-11250D01*",40);
strncpy(alpha[25].glines[4],"X7500D01*",40);
strncpy(alpha[25].glines[5],"M02*",40);
strncpy(alpha[25].glines[6],"",4);

strncpy(alpha[26].glines[0],"G54D548*",40);
strncpy(alpha[26].glines[1],"X-1875Y-11250D02*",40);
strncpy(alpha[26].glines[2],"X-5625Y-7500D01*",40);
strncpy(alpha[26].glines[3],"Y7500D01*",40);
strncpy(alpha[26].glines[4],"X-1875Y11250D01*",40);
strncpy(alpha[26].glines[5],"X1875D01*",40);
strncpy(alpha[26].glines[6],"X5625Y7500D01*",40);
strncpy(alpha[26].glines[7],"Y-7500D01*",40);
strncpy(alpha[26].glines[8],"X1875Y-11250D01*",40);
strncpy(alpha[26].glines[9],"X-1875D01*",40);
strncpy(alpha[26].glines[10],"X-5625Y-7500D02*",40);
strncpy(alpha[26].glines[11],"X5625Y7500D01*",40);
strncpy(alpha[26].glines[12],"M02*",40);
strncpy(alpha[26].glines[13],"",4);

strncpy(alpha[27].glines[0],"G54D548*",40);
strncpy(alpha[27].glines[1],"X-3750Y7500D02*",40);
strncpy(alpha[27].glines[2],"X0Y11250D01*",40);
strncpy(alpha[27].glines[3],"Y-11250D01*",40);
strncpy(alpha[27].glines[4],"X-3750D02*",40);
strncpy(alpha[27].glines[5],"X3750D01*",40);
strncpy(alpha[27].glines[6],"M02*",40);
strncpy(alpha[27].glines[7],"",4);

strncpy(alpha[28].glines[0],"G54D548*",40);
strncpy(alpha[28].glines[1],"X-7500Y7500D02*",40);
strncpy(alpha[28].glines[2],"X-3750Y11250D01*",40);
strncpy(alpha[28].glines[3],"X3750D01*",40);
strncpy(alpha[28].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[28].glines[5],"Y3750D01*",40);
strncpy(alpha[28].glines[6],"X3750Y0D01*",40);
strncpy(alpha[28].glines[7],"X-3750D01*",40);
strncpy(alpha[28].glines[8],"X-7500Y-3750D01*",40);
strncpy(alpha[28].glines[9],"Y-11250D01*",40);
strncpy(alpha[28].glines[10],"X7500D01*",40);
strncpy(alpha[28].glines[11],"M02*",40);
strncpy(alpha[28].glines[12],"",4);

strncpy(alpha[29].glines[0],"G54D548*",40);
strncpy(alpha[29].glines[1],"X-7500Y7500D02*",40);
strncpy(alpha[29].glines[2],"X-3750Y11250D01*",40);
strncpy(alpha[29].glines[3],"X3750D01*",40);
strncpy(alpha[29].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[29].glines[5],"Y3750D01*",40);
strncpy(alpha[29].glines[6],"X3750Y0D01*",40);
strncpy(alpha[29].glines[7],"X0D01*",40);
strncpy(alpha[29].glines[8],"X3750D02*",40);
strncpy(alpha[29].glines[9],"X7500Y-3750D01*",40);
strncpy(alpha[29].glines[10],"Y-7500D01*",40);
strncpy(alpha[29].glines[11],"X3750Y-11250D01*",40);
strncpy(alpha[29].glines[12],"X-3750D01*",40);
strncpy(alpha[29].glines[13],"X-7500Y-7500D01*",40);
strncpy(alpha[29].glines[14],"M02*",40);
strncpy(alpha[29].glines[15],"",4);

strncpy(alpha[30].glines[0],"G54D548*",40);
strncpy(alpha[30].glines[1],"X7500Y-3750D02*",40);
strncpy(alpha[30].glines[2],"X-7500D01*",40);
strncpy(alpha[30].glines[3],"X3750Y11250D01*",40);
strncpy(alpha[30].glines[4],"Y-11250D01*",40);
strncpy(alpha[30].glines[5],"M02*",40);
strncpy(alpha[30].glines[6],"",4);

strncpy(alpha[31].glines[0],"G54D548*",40);
strncpy(alpha[31].glines[1],"X-7500Y-7500D02*",40);
strncpy(alpha[31].glines[2],"X-3750Y-11250D01*",40);
strncpy(alpha[31].glines[3],"X3750D01*",40);
strncpy(alpha[31].glines[4],"X7500Y-7500D01*",40);
strncpy(alpha[31].glines[5],"Y0D01*",40);
strncpy(alpha[31].glines[6],"X3750Y3750D01*",40);
strncpy(alpha[31].glines[7],"X-7500D01*",40);
strncpy(alpha[31].glines[8],"Y11250D01*",40);
strncpy(alpha[31].glines[9],"X7500D01*",40);
strncpy(alpha[31].glines[10],"M02*",40);
strncpy(alpha[31].glines[11],"",4);

strncpy(alpha[32].glines[0],"G54D548*",40);
strncpy(alpha[32].glines[1],"X-7500Y0D02*",40);
strncpy(alpha[32].glines[2],"X3750D01*",40);
strncpy(alpha[32].glines[3],"X7500Y-3750D01*",40);
strncpy(alpha[32].glines[4],"Y-7500D01*",40);
strncpy(alpha[32].glines[5],"X3750Y-11250D01*",40);
strncpy(alpha[32].glines[6],"X-3750D01*",40);
strncpy(alpha[32].glines[7],"X-7500Y-7500D01*",40);
strncpy(alpha[32].glines[8],"Y3750D01*",40);
strncpy(alpha[32].glines[9],"X0Y11250D01*",40);
strncpy(alpha[32].glines[10],"X3750D01*",40);
strncpy(alpha[32].glines[11],"M02*",40);
strncpy(alpha[32].glines[12],"",4);

strncpy(alpha[33].glines[0],"G54D548*",40);
strncpy(alpha[33].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[33].glines[2],"X7500D01*",40);
strncpy(alpha[33].glines[3],"X-3750Y-11250D01*",40);
strncpy(alpha[33].glines[4],"M02*",40);
strncpy(alpha[33].glines[5],"",4);

strncpy(alpha[34].glines[0],"G54D548*",40);
strncpy(alpha[34].glines[1],"X-3750Y-11250D02*",40);
strncpy(alpha[34].glines[2],"X-7500Y-7500D01*",40);
strncpy(alpha[34].glines[3],"Y-3750D01*",40);
strncpy(alpha[34].glines[4],"X-3750Y0D01*",40);
strncpy(alpha[34].glines[5],"X3750D01*",40);
strncpy(alpha[34].glines[6],"X7500Y3750D01*",40);
strncpy(alpha[34].glines[7],"Y7500D01*",40);
strncpy(alpha[34].glines[8],"X3750Y11250D01*",40);
strncpy(alpha[34].glines[9],"X-3750D01*",40);
strncpy(alpha[34].glines[10],"X-7500Y7500D01*",40);
strncpy(alpha[34].glines[11],"Y3750D01*",40);
strncpy(alpha[34].glines[12],"X-3750Y0D01*",40);
strncpy(alpha[34].glines[13],"X3750D02*",40);
strncpy(alpha[34].glines[14],"X7500Y-3750D01*",40);
strncpy(alpha[34].glines[15],"Y-7500D01*",40);
strncpy(alpha[34].glines[16],"X3750Y-11250D01*",40);
strncpy(alpha[34].glines[17],"X-3750D01*",40);
strncpy(alpha[34].glines[18],"M02*",40);
strncpy(alpha[34].glines[19],"",4);

strncpy(alpha[35].glines[0],"G54D548*",40);
strncpy(alpha[35].glines[1],"X-3750Y-11250D02*",40);
strncpy(alpha[35].glines[2],"X0D01*",40);
strncpy(alpha[35].glines[3],"X7500Y-3750D01*",40);
strncpy(alpha[35].glines[4],"Y7500D01*",40);
strncpy(alpha[35].glines[5],"X3750Y11250D01*",40);
strncpy(alpha[35].glines[6],"X-3750D01*",40);
strncpy(alpha[35].glines[7],"X-7500Y7500D01*",40);
strncpy(alpha[35].glines[8],"Y3750D01*",40);
strncpy(alpha[35].glines[9],"X-3750Y0D01*",40);
strncpy(alpha[35].glines[10],"X7500D01*",40);
strncpy(alpha[35].glines[11],"M02*",40);
strncpy(alpha[35].glines[12],"",4);

strncpy(alpha[36].glines[0],"G54D548*",40);       // amphersand
strncpy(alpha[36].glines[1],"X7500Y-3750D02*",40);
strncpy(alpha[36].glines[2],"X0Y-11250D01*",40);
strncpy(alpha[36].glines[3],"X-3750D01*",40);
strncpy(alpha[36].glines[4],"X-7500Y-7500D01*",40);
strncpy(alpha[36].glines[5],"Y-3750D01*",40);
strncpy(alpha[36].glines[6],"X0Y3750D01*",40);
strncpy(alpha[36].glines[7],"Y7500D01*",40);
strncpy(alpha[36].glines[8],"X-3750Y11250D01*",40);
strncpy(alpha[36].glines[9],"X-7500Y7500D01*",40);
strncpy(alpha[36].glines[10],"Y3750D01*",40);
strncpy(alpha[36].glines[11],"X7500Y-11250D01*",40);
strncpy(alpha[36].glines[12],"M02*",40);
strncpy(alpha[36].glines[13],"",4);

strncpy(alpha[37].glines[0],"G54D548*",40);         // bslash
strncpy(alpha[37].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[37].glines[2],"X7500Y-11250D01*",40);
strncpy(alpha[37].glines[3],"M02*",40);
strncpy(alpha[37].glines[4],"",4);

strncpy(alpha[38].glines[0],"G54D548*",40);           // comma
strncpy(alpha[38].glines[1],"X0Y-7500D02*",40);
strncpy(alpha[38].glines[2],"Y-11250D01*",40);
strncpy(alpha[38].glines[3],"X-3750Y-15000D01*",40);
strncpy(alpha[38].glines[4],"M02*",40);
strncpy(alpha[38].glines[5],"",4);

strncpy(alpha[39].glines[0],"G54D548*",40);       // copyright
strncpy(alpha[39].glines[1],"X4167Y-4167D02*",40);
strncpy(alpha[39].glines[2],"X2083Y-6250D01*",40);
strncpy(alpha[39].glines[3],"X-2083D01*",40);
strncpy(alpha[39].glines[4],"X-4167Y-4167D01*",40);
strncpy(alpha[39].glines[5],"Y4167D01*",40);
strncpy(alpha[39].glines[6],"X-2083Y6250D01*",40);
strncpy(alpha[39].glines[7],"X2083D01*",40);
strncpy(alpha[39].glines[8],"X4167Y4167D01*",40);
strncpy(alpha[39].glines[9],"G54D645*",40);
strncpy(alpha[39].glines[10],"X0Y0D03*",40);
strncpy(alpha[39].glines[11],"M02*",40);
strncpy(alpha[39].glines[12],"",4);

strncpy(alpha[40].glines[0],"G54D548*",40);         // dash
strncpy(alpha[40].glines[1],"X-7500Y0D02*",40);
strncpy(alpha[40].glines[2],"X7500D01*",40);
strncpy(alpha[40].glines[3],"M02*",40);
strncpy(alpha[40].glines[4],"",4);

strncpy(alpha[41].glines[0],"G54D548*",40);         // dot
strncpy(alpha[41].glines[1],"X3750Y-11250D02*",40);
strncpy(alpha[41].glines[2],"Y-6250D01*",40);
strncpy(alpha[41].glines[3],"M02*",40);
strncpy(alpha[41].glines[4],"",4);

strncpy(alpha[42].glines[0],"G54D548*",40);            // forward slash
strncpy(alpha[42].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[42].glines[2],"X7500Y11250D01*",40);
strncpy(alpha[42].glines[3],"M02*",40);    
strncpy(alpha[42].glines[4],"",4);      

}  // end init_alpha_glines


void placestandard( double x, double y)
{
int ii;
char a[10][40];
char b[10][40];
char c[10][40];
char d[10][40];
int val;
char X[40];
char Y[40];
double xval;
double yval;
int xint;
int yint;


  // printf("In placestandard\n");

   ii = 0;

  while ( strlen(glines[ii]) > 0){
    if (( strstr(glines[ii],"X") != NULL) && ( strstr(glines[ii],"Y")!= NULL)
		 && ( strstr(glines[ii],"G54") == NULL))
	{
       split(glines[ii],a[0],a[1],"Y");
       split(glines[ii],d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y);
	   xval=atof(X);
	   yval=atof(Y);
       xval=xval + x;
       yval=yval + y;
	   xint=(int)(xval);
	   yint=(int)(yval);
       printf("G01X%dY%dD%s\n",xint,yint,d[1]);
    }
    else if( (strstr(glines[ii],"Y") == NULL) && (strstr(glines[ii],"X") != NULL))
	{
      split(glines[ii],b[0],b[1],"X");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
	  xval=atof(X);
	  xval=xval+x;
	  xint=(int) (xval);
      printf("G01X%dD%s\n", xint,d[1]);
    }
    else if(( strstr(glines[ii],"Y") != NULL) && (strstr(glines[ii],"X") == NULL))
	{
      split(glines[ii],c[0],c[1],"Y");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4, Y);
	  yval=atof(Y);
	  yval=yval+y;
	  yint=(int ) (yval);
      printf("G01Y%dD%s\n",yint,d[1]);
    }
    else if( strstr(glines[ii],"M0")==NULL)
	{
      printf("%s\n",glines[ii]); 
    }
	ii += 1;
  }
  
}

void placestandard_out( double x, double y)
{
int ii;
char a[10][40];
char b[10][40];
char c[10][40];
char d[10][40];
int val;
char X[40];
char Y[40];
double xval;
double yval;
int xint;
int yint;


  // printf("In placestandard_out\n");

   ii = 0;

  while ( strlen(glines[ii]) > 0){
    if (( strstr(glines[ii],"X") != NULL) && ( strstr(glines[ii],"Y")!= NULL)
		 && ( strstr(glines[ii],"G54") == NULL))
	{
       split(glines[ii],a[0],a[1],"Y");
       split(glines[ii],d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y);
	   xval=atof(X);
	   yval=atof(Y);
       xval=xval + x;
       yval=yval + y;
	   xint=(int)(xval);
	   yint=(int)(yval);
       fprintf(outfile,"G01X%dY%dD%s\n",xint,yint,d[1]);
    }
    else if( (strstr(glines[ii],"Y") == NULL) && (strstr(glines[ii],"X") != NULL))
	{
      split(glines[ii],b[0],b[1],"X");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
	  xval=atof(X);
	  xval=xval+x;
	  xint=(int) (xval);
      fprintf(outfile,"G01X%dD%s\n", xint,d[1]);
    }
    else if(( strstr(glines[ii],"Y") != NULL) && (strstr(glines[ii],"X") == NULL))
	{
      split(glines[ii],c[0],c[1],"Y");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4, Y);
	  yval=atof(Y);
	  yval=yval+y;
	  yint=(int ) (yval);
      fprintf(outfile,"G01Y%dD%s\n",yint,d[1]);
    }
    else if( strstr(glines[ii],"M0")==NULL)
	{
      fprintf(outfile,"%s\n",glines[ii]); 
    }
	ii += 1;
  }
  
}

void copy_glines( int arrayindex)
{
int j;
          
  j= 0;
  while( strlen(alpha[arrayindex].glines[j]) > 0 )
  {
		strncpy(glines[j],alpha[arrayindex].glines[j],40);
        j += 1;

  }

} // end copy_glines


void placelabel3_call_out( char *partsizefilestr, char *labelfilestr, char *outfilestr)
{
	init_alpha_glines();

    //  getline < file2
	file2= fopen( partsizefilestr,"r");
	if (file2==NULL)
	{
	  printf("In placelabels3, unable to open the input file = %s \n", partsizefilestr);
	  exit(-1);
	}

	file1= fopen( labelfilestr,"r");
	if (file1==NULL)
	{
	  printf("In placelabels3, unable to open the input file = %s \n", labelfilestr);
	  exit(-1);
	}

    outfile= fopen( outfilestr,"w");
	if (outfile==NULL)
	{
	  printf("In placelabels3, unable to open the outputfile file = %s \n", outfilestr);
	  exit(-1);
	}

     endoffile=getline(file2,thisline);  // read the partsize file
	nf=split_line(thisline);

     // print file2 "  " $0 | "cat 1>&2"
     xsize = atoi(str_array[0]);
     ysize = atoi(str_array[1]);

	 fclose(file2);

     // print "LABELS "xsize "   " ysize | "cat 1>&2"

     XLOW = -153.5;
     XHIGH = 153.5;
     YLOW = -153.73;
     YHIGH = 153.73;
     YBADLOW = -260000;
     YBADHIGH = 260000;
     XOFF = 19.22;
     DOUBLEVAL = 25.4;
    
    
    Xfile = 0;
    Yfile = 1;


	endoffile=getline(file1,thisline);
	nf=split_line(thisline);

	while(endoffile==FALSE)

	{
      // handle letters
     if( strcmp(str_array[0],"X") == 0 )
	  {
//	 print filename
	   XVal = atoi(str_array[1]);
	   if ( xsize  < 50000)
	   {
         xcnt++;
	     // filename = (path "/vnarrow.gbr");
		 
	     if (xcnt % 10 == 0)
		 {
	        //  filename = (path "/vwide.gbr");
         } 
		    
         // placestandard( XVal, YLOW * (pow(10,4),ofile);
         // placestandard( XVal , YHIGH * pow(10,4),ofile);
              
	   }
	   else
	   {
	    if (Xfile <= 25)
		{
	      // filename = (path "/" alpha[Xfile] ".gbr")
			   copy_glines( Xfile);
              placestandard_out( XVal, YLOW * pow(10,4));
              placestandard_out( XVal , YHIGH * pow(10,4));
	    }
	    else
		{
	       //filename = (path "/" alpha[Xfile - 26* int(Xfile/26)] ".gbr")
			   copy_glines( Xfile % 26);

	       // filename1 = (path "/" alpha[int(Xfile/26 - 1)] ".gbr")
               placestandard_out( XVal + 1.1* pow(10,4), YLOW * pow(10,4));
			   copy_glines( (Xfile/26)-1);
               placestandard_out( XVal - 1.1 * pow(10,4), YLOW * pow(10,4));
               copy_glines( Xfile % 26);
               placestandard_out( XVal +1.1 * pow(10,4) , YHIGH * pow(10,4));
               copy_glines( (Xfile/26)-1);
               placestandard_out( XVal -1.1 * pow(10,4) , YHIGH * pow(10,4));
         } 
        Xfile++;
	   }
	 } 
      // handle numbers
    if( strcmp(str_array[0],"Y") == 0 )
	 {

	    YVal = atoi(str_array[1]);
	    if( (YVal > YBADLOW)  && (YVal < YBADHIGH) )
		{
	      X1 = XLOW - XOFF;
	      X2 = XHIGH + XOFF;
		}
	    else
		{
	      X1 = XLOW;
	      X2 = XHIGH;
		}

	   if ( ysize < 50000)
	   {
         ycnt++;
	    // filename = (path "/hnarrow.gbr")
	     if (ycnt % 10 == 0)
		 {
	       //   filename = (path "/hwide.gbr")
         } 
         // placestandard( X1 * pow(10,4), YVal);
         // placestandard( X2 * pow(10,4), YVal);
	   }
	  else
	  {
	    if( Yfile <= 9)
		{
	           //filename = (path "/" Yfile ".gbr");
			   copy_glines( Yfile + 26);
               placestandard_out( X1 * pow(10,4), YVal);
               placestandard_out( X2 * pow(10,4), YVal);
		}
        else
		 { 
               //tmp1 = int(Yfile/10);
              // filename = (path "/" Yfile- 10 *  tmp1 ".gbr");
			   copy_glines( (Yfile % 10)+26);
	          // filename1 = (path "/" tmp1  ".gbr");
               copy_glines( (Yfile / 10)+26);
	           placestandard_out( X1 * pow(10,4) , YVal + 1.5* pow(10,4) );
               copy_glines( (Yfile % 10)+26);
	           placestandard_out(  X1 * pow(10,4) , YVal - 1.5* pow(10,4) );
               copy_glines( (Yfile / 10)+26);
               placestandard_out(  X2 * pow(10,4) , YVal + 1.5* pow(10,4) );
               copy_glines( (Yfile % 10)+26);
               placestandard_out(  X2 * pow(10,4), YVal - 1.5* pow(10,4));
         }
       Yfile++;
      }
	}
    endoffile=getline(file1,thisline);
	nf=split_line(thisline);
   }
   fclose(file1);
   fclose(outfile);
}

void placelabel3_call( char *partsizefilestr, char *labelfilestr)
{
	init_alpha_glines();

    //  getline < file2
	file2= fopen( partsizefilestr,"r");
	if (file2==NULL)
	{
	  printf("In placelabels3, unable to open the input file = %s \n", partsizefilestr);
	  exit(-1);
	}
	file1= fopen( labelfilestr,"r");
	if (file1==NULL)
	{
	  printf("In placelabels3, unable to open the input file = %s \n", labelfilestr);
	  exit(-1);
	}

     endoffile=getline(file2,thisline);  // read the partsize file
	nf=split_line(thisline);

     // print file2 "  " $0 | "cat 1>&2"
     xsize = atoi(str_array[0]);
     ysize = atoi(str_array[1]);

	 fclose(file2);

     // print "LABELS "xsize "   " ysize | "cat 1>&2"

     XLOW = -153.5;
     XHIGH = 153.5;
     YLOW = -153.73;
     YHIGH = 153.73;
     YBADLOW = -260000;
     YBADHIGH = 260000;
     XOFF = 19.22;
     DOUBLEVAL = 25.4;
    
    
    Xfile = 0;
    Yfile = 1;


	endoffile=getline(file1,thisline);
	nf=split_line(thisline);

	while(endoffile==FALSE)

	{
      // handle letters
     if( strcmp(str_array[0],"X") == 0 )
	  {
//	 print filename
	   XVal = atoi(str_array[1]);
	   if ( xsize  < 50000)
	   {
         xcnt++;
	     // filename = (path "/vnarrow.gbr");
		 
	     if (xcnt % 10 == 0)
		 {
	        //  filename = (path "/vwide.gbr");
         } 
		    
         // placestandard( XVal, YLOW * (pow(10,4),ofile);
         // placestandard( XVal , YHIGH * pow(10,4),ofile);
              
	   }
	   else
	   {
	    if (Xfile <= 25)
		{
	      // filename = (path "/" alpha[Xfile] ".gbr")
			   copy_glines( Xfile);
              placestandard( XVal, YLOW * pow(10,4));
              placestandard( XVal , YHIGH * pow(10,4));
	    }
	    else
		{
	       //filename = (path "/" alpha[Xfile - 26* int(Xfile/26)] ".gbr")
			   copy_glines( Xfile % 26);

	       // filename1 = (path "/" alpha[int(Xfile/26 - 1)] ".gbr")
               placestandard( XVal + 1.1* pow(10,4), YLOW * pow(10,4));
			   copy_glines( (Xfile/26)-1);
               placestandard( XVal - 1.1 * pow(10,4), YLOW * pow(10,4));
               copy_glines( Xfile % 26);
               placestandard( XVal +1.1 * pow(10,4) , YHIGH * pow(10,4));
               copy_glines( (Xfile/26)-1);
               placestandard( XVal -1.1 * pow(10,4) , YHIGH * pow(10,4));
         } 
        Xfile++;
	   }
	 } 
      // handle numbers
    if( strcmp(str_array[0],"Y") == 0 )
	 {

	    YVal = atoi(str_array[1]);
	    if( (YVal > YBADLOW)  && (YVal < YBADHIGH) )
		{
	      X1 = XLOW - XOFF;
	      X2 = XHIGH + XOFF;
		}
	    else
		{
	      X1 = XLOW;
	      X2 = XHIGH;
		}

	   if ( ysize < 50000)
	   {
         ycnt++;
	    // filename = (path "/hnarrow.gbr")
	     if (ycnt % 10 == 0)
		 {
	       //   filename = (path "/hwide.gbr")
         } 
         // placestandard( X1 * pow(10,4), YVal);
         // placestandard( X2 * pow(10,4), YVal);
	   }
	  else
	  {
	    if( Yfile <= 9)
		{
	           //filename = (path "/" Yfile ".gbr");
			   copy_glines( Yfile + 26);
               placestandard( X1 * pow(10,4), YVal);
               placestandard( X2 * pow(10,4), YVal);
		}
        else
		 { 
               //tmp1 = int(Yfile/10);
              // filename = (path "/" Yfile- 10 *  tmp1 ".gbr");
			   copy_glines( (Yfile % 10)+26);
	          // filename1 = (path "/" tmp1  ".gbr");
               copy_glines( (Yfile / 10)+26);
	           placestandard( X1 * pow(10,4) , YVal + 1.5* pow(10,4) );
               copy_glines( (Yfile % 10)+26);
	           placestandard(  X1 * pow(10,4) , YVal - 1.5* pow(10,4) );
               copy_glines( (Yfile / 10)+26);
               placestandard(  X2 * pow(10,4) , YVal + 1.5* pow(10,4) );
               copy_glines( (Yfile % 10)+26);
               placestandard(  X2 * pow(10,4), YVal - 1.5* pow(10,4));
         }
       Yfile++;
      }
	}
    endoffile=getline(file1,thisline);
	nf=split_line(thisline);
   }
   fclose(file1);
}

int main( int argc, char **argv)
{

	placelabel3_call( argv[1], argv[2]);

} // endmain

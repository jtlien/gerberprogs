#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

FILE *outfile;
FILE *infile;
FILE *pcmdatafile;
char pathstr[200];
char dirsep[10];


char outfilestr[120];
int nf;
int endoffile;
char thisline[200];
char str_array[120][120];


void placepcmman_call( char *inpathstr, char *infilestr)
{

FILE *outfile;
FILE *infile;
FILE *pcmdatafile;
char pathstr[200];
char dirsep[10];


char outfilestr[120];
int nf;
int endoffile;
char thisline[200];


 if ( WINDOWS)
 {
	 strncpy(dirsep,"\\",4);
 }
 else
 {
	 strncpy(dirsep,"/",4);
 }

 strncpy(pathstr,inpathstr,120);

 infile = fopen(infilestr,"r");
 if (infile == NULL)
 {
	 printf("In placepcmman, unable to open the input file %s for read \n",infilestr);
	 exit(-1);
 }

 pcmdatafile = fopen("pcmdata","w");
 if( pcmdatafile==NULL)
 {
	 printf("in placepcmman, Unable to open the pcmdata file for writing \n");
	 exit(-1);
 }

endoffile = getline(infile,thisline);
 nf=split_line(thisline);
 while(endoffile == FALSE)
 {
   // file = ($1 ".pcm")
   strncpy(outfilestr,str_array[0],120);  // $1.pcm
   strncat(outfilestr,".pcm",5);
   outfile = fopen(outfilestr,"a");
   if (outfile==NULL)
   {
      printf("In placepcmman, unable to open the output file = %s for append \n",
		   outfilestr);
	  exit(-1);
   }
   fprintf(outfile,"%s   %s\n",str_array[1],str_array[2] ); 
                                 //  $2 "  " $3 > file
   
   fclose(outfile);
   fprintf(pcmdatafile,"%12s%12s %s%s%s \n",
	   str_array[1],str_array[2],pathstr,dirsep,str_array[0]); // $2, $3, path,$1); // > "pcmdata"

 endoffile=getline(infile,thisline);
 nf=split_line(thisline);

 }
   //fclose(outfile);
   fclose(pcmdatafile);
   fclose(infile);
}

/*

int main( int argc, char **argv)
{

	if (argc != 3)
	{
		printf("In placepcmman, wrong number of arguments \n");
		printf("Usage: placepcmman pathstr infile \n");
		exit(-1);
	}
	else
	{
	placepcmman_call( argv[1], argv[2]);
    }

} 

*/



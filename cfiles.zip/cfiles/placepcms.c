
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

char horizontal[1000][120];
char vertical[1000][120];


void placepcms_call_out(char *file1str, char *pathstr, char *file3str, char *outfilestr)
{
char thisline[200];
char tstr[240];
char fstr[240];
int vcnt;
int hcnt;
int hplace;
int vplace;
int endoffile;
int nf;
char source[200];
FILE *file1,*ofile;
FILE *outfile;

	 if (WINDOWS)
	 {
		 strncpy(dirsep,"\\",4);
	 }
	 else
	 {
		 strncpy(dirsep,"/",4);
	 }

    //  file1 is pcm.txt ( user created file listing of desired pcms )
    // getline < file1

    strncpy(source,pathstr,120);   // second argument is  source = path

    file1  = fopen(file1str, "r");   // file1 is argument 1

      if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",file1str);
	   exit(-1);
	  }

     outfile  = fopen(outfilestr, "w");   // output file, pcmdata file

      if (outfile == NULL)
	  {
	   printf("Error: Unable to open output file = %s \n",outfilestr);
	   exit(-1);
	  }
    vcnt = 1;
    hcnt = 1;

    endoffile=getline(file1,thisline);   // file1 is pcm.txt
    nf=split_line(thisline);

    while(endoffile==FALSE)
     {
       if((strstr(str_array[1],"H") != NULL ) ||
          (strstr(str_array[1],"h") != NULL))
         {
	    strncpy(horizontal[hcnt],str_array[0],120); 
	    hcnt++;
        }

       if((strstr(str_array[1],"V") != NULL) || 
          (strstr(str_array[1],"v") != NULL ))
	 {
	    strncpy(vertical[vcnt],str_array[0],120); 
	    vcnt++;
       }

       endoffile=getline(file1,thisline);
       nf=split_line(thisline); 
    }

   fclose(file1);

   hcnt--;
   vcnt--;
   hplace = 1;
   vplace = 1;

   file1  = fopen(file3str, "r");   // file1 is argument 3

   if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",file3str);
	   exit(-1);
	  }

   endoffile = getline(file1,thisline);   // read in pcmcoords
   nf=split_line(thisline);

  while(endoffile==FALSE)
   {
    if(strstr(thisline,"R")!= NULL)
    {
      strncpy(tstr,source,120);
      strncat(tstr,dirsep,4);
      strcat(tstr,horizontal[hplace]);

      fprintf(outfile,"%s %s %s\n", str_array[0],str_array[1],tstr);
	  strncpy(fstr,horizontal[hplace],120);
	  strcat(fstr,".pcm");
	  ofile=fopen(fstr,"a");

	  if (ofile != NULL)
	  {
      fprintf(ofile,"%s %s \n",str_array[0],str_array[1]);  //  > (horizontal[hplace] ".pcm")
	  fclose(ofile);
	  }
	  else
	  {
	  printf("Cannot open for apend %s \n",fstr);
	  exit(-1);
	  }

     hplace++;
     if( hplace > hcnt )
	 {
       hplace = 1;
      }
     }
    else   // no 'R'
     {

      strncpy(tstr,source,120);
      strncat(tstr,dirsep,4);
      strcat(tstr,vertical[vplace]);

      fprintf(outfile,"%s %s %s\n",str_array[0],str_array[1],tstr);

      strncpy(fstr,vertical[vplace],120);
	  strncat(fstr,".pcm",10);
	  ofile=fopen(fstr,"a");
      if (ofile != NULL)
	  {
       fprintf(ofile,"%s %s \n",str_array[0],str_array[1]); // > (vertical[vplace] ".pcm")
       fclose(ofile);
	  }
	  else
	  {
		  printf("Cannot open for apend %s \n",fstr);
		  exit(-1);

	  }

     vplace++;
     if( vplace  > vcnt){
       vplace = 1;
     }
    }

    endoffile=getline(file1,thisline);
    nf=split_line(thisline);
   }
  fclose(file1);
  fclose(outfile);

}  // end placepcms_call_out


void placepcms_call(char *file1str, char *pathstr, char *file3str)
{
char thisline[200];
char tstr[240];
char fstr[240];
int vcnt;
int hcnt;
int hplace;
int vplace;
int endoffile;
int nf;
char source[200];
FILE *file1,*ofile;

	 if (WINDOWS)
	 {
		 strncpy(dirsep,"\\",4);
	 }
	 else
	 {
		 strncpy(dirsep,"/",4);
	 }

    //  file1 is pcm.txt ( user created file listing of desired pcms )
    // getline < file1

    strncpy(source,pathstr,120);   // second argument is  source = path

    file1  = fopen(file1str, "r");   // file1 is argument 1

      if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",file1str);
	   exit(-1);
	  }

    vcnt = 1;
    hcnt = 1;

    endoffile=getline(file1,thisline);
    nf=split_line(thisline);

    while(endoffile==FALSE)
     {
       if((strstr(str_array[1],"H") != NULL ) ||
          (strstr(str_array[1],"h") != NULL))
         {
	    strncpy(horizontal[hcnt],str_array[0],120); 
	    hcnt++;
        }

       if((strstr(str_array[1],"V") != NULL) || 
          (strstr(str_array[1],"v") != NULL ))
	 {
	    strncpy(vertical[vcnt],str_array[0],120); 
	    vcnt++;
       }

       endoffile=getline(file1,thisline);
       nf=split_line(thisline); 
    }

   fclose(file1);

   hcnt--;
   vcnt--;
   hplace = 1;
   vplace = 1;

   file1  = fopen(file3str, "r");   // file1 is argument 3

   if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",file3str);
	   exit(-1);
	  }

   endoffile = getline(file1,thisline);
   nf=split_line(thisline);

  while(endoffile==FALSE)
   {
    if(strstr(thisline,"R")!= NULL )
    {
      strncpy(tstr,source,120);
      strncat(tstr,dirsep,4);
      strcat(tstr,horizontal[hplace]);

      printf("%s %s %s\n", str_array[0],str_array[1],tstr);
	  strncpy(fstr,horizontal[hplace],120);
	  strcat(fstr,".pcm");
	  ofile=fopen(fstr,"a");

	  if (ofile != NULL)
	  {
      fprintf(ofile,"%s %s \n",str_array[0],str_array[1]);  //  > (horizontal[hplace] ".pcm")
	  fclose(ofile);
	  }
	  else
	  {
	  printf("Cannot open for apend %s \n",fstr);
	  exit(-1);
	  }

     hplace++;
     if( hplace > hcnt )
	 {
       hplace = 1;
      }
     }
    else 
     {

      strncpy(tstr,source,120);
      strncat(tstr,dirsep,4);
      strcat(tstr,vertical[vplace]);

      printf("%s %s %s\n",str_array[0],str_array[1],tstr);

      strncpy(fstr,vertical[vplace],120);
	  strncat(fstr,".pcm",10);
	  ofile=fopen(fstr,"a");
      if (ofile != NULL)
	  {
       fprintf(ofile,"%s %s \n",str_array[0],str_array[1]); // > (vertical[vplace] ".pcm")
       fclose(ofile);
	  }
	  else
	  {
		  printf("Cannot open for apend %s \n",fstr);
		  exit(-1);

	  }

     vplace++;
     if( vplace  > vcnt){
       vplace = 1;
     }
    }

    endoffile=getline(file1,thisline);
    nf=split_line(thisline);
   }
  fclose(file1);

}  // end placepcms_call

/*
int main( int argc, char **argv)

{
    if (argc != 4)
     {
	  printf("In placepcms, wrong number of arguments \n");
	  printf("Usage: placepcms pcmtxtfile path pcmcoordsfile \n");
	  exit(-1);
	  }
	else
	 {
        placepcms_call( argv[1], argv[2], argv[3]);
      }

} //
*/

 




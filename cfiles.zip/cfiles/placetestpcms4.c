#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

double Xarray[100000];
double Yarray[100000];
int delete_array[100000];

struct delstuff
{
 double xval;
 double yval;
} delarray[1000];

int delcount;

int cnt;

// of all the horizontal ( with R ) coordinants in pcmcoords
//  find the ones that are closest to the 7 given coordincants and
//  put those in platecap.pcm, and remove them from the pcmcoords info
//  that is output

int in_dellist( double xval, double yval)
{
int ii;

 ii = 0;
 while(ii < delcount)
 {
	 if(( delarray[ii].xval == xval) && ( delarray[ii].yval==yval))
	 {
		 return(TRUE);
	 }
  ii += 1;
 }
 return(FALSE);
}

double dist( double x1, double y1, double x2, double y2)
{
double dx;
double dy;
double d;

   dx = (x2-x1)*(x2-x1);
   dy = (y2-y1)*(y2-y1);
   d  = sqrt(dx+dy);
   return(d);
}

// find the location in the array Xarray, Yarray
// that is closest to X1 and Y1

int mindist(double X1, double Y1)
{
int loc;
double lowest;
int j;
double di;

   lowest =  100000000;
   loc = -1;
   for(j = 0 ; j < cnt ; j++)
   {
      if ( delete_array[j] == 0 )  // not deleted  
	  {
         di = dist(X1,Y1,Xarray[j],Yarray[j]);
         if( di< lowest )
		 {
	      lowest = di;
	      loc = j;
         }
      }
   }
   // printf("lowest is %s at location %s\n",lowest,loc)| "cat 1>&2"
   return(loc);

}
    	 
void placetestpcms4_call_out(char *pathstr, char *file1str, char *outfilestr)
{
double Xpos[10];
double Ypos[10];
int z;
int a;
int i;
int MAX;
int endoffile;
int nf;
FILE *file1;
FILE *outfile;
FILE *platefile;
FILE *pcmdatafile;

char dirsep[10];
char thisline[200];

char path[120];
int myloc;

    if (WINDOWS)
	{
		strncpy(dirsep,"\\",4);
	}
	else
	{
		strncpy(dirsep,"/",4);
	}

   strncpy(path,pathstr,120);

   Xpos[0] = 0;
   Xpos[1] = -1524000;
   Xpos[2] = -1524000;
   Xpos[3] =  -900000;
   Xpos[4] =   900000;
   Xpos[5] =  1524000;
   Xpos[6] =  1524000;


   Ypos[0] = 0;
   Ypos[1] =  1524000;
   Ypos[2] =    -5000;
   Ypos[3] = -1524000;
   Ypos[4] =  1524000;
   Ypos[5] =     5000;
   Ypos[6] = -1524000;

   for(i=0; i < 100000; i += 1)
   {
	   delete_array[i] = 0;
	   Xarray[i]=0;
	   Yarray[i]=0;
   }

   MAX   = 7;
   cnt = 0;

   file1 = fopen(file1str,"r");
   if (file1 == NULL)
   {
	   printf("In placetestpcms4, unable to open the input file = %s \n",file1str);
	   exit(-1);
   } 
   outfile = fopen(outfilestr,"w");
   if (outfile== NULL)
   {
	   printf("In placetestpcms4, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile == FALSE)
   {
     if( strstr(thisline,"R") != NULL) // $0 ~ /R/)
	 {
		if (cnt < 100000)
		{
         Xarray[cnt] = atof(str_array[0]); // $1
         Yarray[cnt] = atof(str_array[1]); // $2 
		 delete_array[cnt] = 0;
         cnt++;
		}
		else
		{
			printf("Xarray,Yarray count exceeds 100000 \n");
			exit(-1);
		}
     }
     else 
	 {
	  fprintf(outfile,"%s",thisline); // $0
     }

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
   }

   fclose(file1);

   platefile=fopen("platecap.pcm","w");
   pcmdatafile=fopen("pcmdata","w");

   if (platefile == NULL)
   {
	   printf("In placetestpcms4, unable to open the output file = placecap.pcm \n");
	   exit(-1);
   }
  if (pcmdatafile == NULL)
   {
	   printf("In placetestpcms4, unable to open the output file = pcmdata \n");
	   exit(-1);
   }
   delcount=0;

   for(a = 0 ; a < MAX ; a++)
   {
      myloc = mindist(Xpos[a],Ypos[a]);
	  
      if (myloc != -1)   // found a minimum
	  {
         fprintf(platefile, "%0.0f %0.0f\n", Xarray[myloc] ,Yarray[myloc]); //   > "platecap.pcm"
         fprintf(pcmdatafile,"%0.0f %0.0f %s%splatecap\n",Xarray[myloc],Yarray[myloc], path,dirsep); //  > "pcmdata"
         delete_array[myloc] =1 ;//  Xarray[myloc]
         delete_array[myloc] =1;  //Yarray[myloc]
		 delarray[delcount].xval=Xarray[myloc];
		 delarray[delcount].yval=Yarray[myloc];
		 if (delcount < 1000)
		 {
			 delcount += 1;
		 }
      }
      // printf("myloc %s\n",myloc); //  | "cat 1>&2"
   }

  
  for( z=0; z < cnt; z+= 1) //  in Xarray)
   {
     
	if (! in_dellist( Xarray[z],Yarray[z]) )
		 {
	       fprintf(outfile,"%0.0f %0.0f R\n", Xarray[z],Yarray[z]);
			   
	
		}
      
   }
  
   fclose(platefile);
   fclose(pcmdatafile);
   fclose(outfile);

} // end placetestpcms4_call_out


	 
void placetestpcms4_call(char *pathstr, char *file1str)
{
double Xpos[10];
double Ypos[10];
int z;
int a;
int i;
int MAX;
int endoffile;
int nf;
FILE *file1;
FILE *platefile;
FILE *pcmdatafile;

char dirsep[10];
char thisline[200];

char path[120];
int myloc;

    if (WINDOWS)
	{
		strncpy(dirsep,"\\",4);
	}
	else
	{
		strncpy(dirsep,"/",4);
	}

   strncpy(path,pathstr,120);

   Xpos[0] = 0;
   Xpos[1] = -1524000;
   Xpos[2] = -1524000;
   Xpos[3] =  -900000;
   Xpos[4] =   900000;
   Xpos[5] =  1524000;
   Xpos[6] =  1524000;


   Ypos[0] = 0;
   Ypos[1] =  1524000;
   Ypos[2] =    -5000;
   Ypos[3] = -1524000;
   Ypos[4] =  1524000;
   Ypos[5] =     5000;
   Ypos[6] = -1524000;

   for(i=0; i < 100000; i += 1)
   {
	   delete_array[i] = 0;
	   Xarray[i]=0;
	   Yarray[i]=0;
   }

   MAX   = 7;
   cnt = 0;

   file1 = fopen(file1str,"r");
   if (file1 == NULL)
   {
	   printf("In placetestpcms4, unable to open the input file = %s \n",file1str);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile == FALSE)
   {
     if( strstr(thisline,"R") != NULL) // $0 ~ /R/)
	 {
		if (cnt < 100000)
		{
         Xarray[cnt] = atof(str_array[0]); // $1
         Yarray[cnt] = atof(str_array[1]); // $2 
		 delete_array[cnt] = 0;
         cnt++;
		}
		else
		{
			printf("Xarray,Yarray count exceeds 100000 \n");
			exit(-1);
		}
     }
     else 
	 {
	  printf("%s",thisline); // $0
     }

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
   }

   fclose(file1);

   platefile=fopen("platecap.pcm","w");
   pcmdatafile=fopen("pcmdata","w");

   if (platefile == NULL)
   {
	   printf("In placetestpcms4, unable to open the output file = placecap.pcm \n");
	   exit(-1);
   }
  if (pcmdatafile == NULL)
   {
	   printf("In placetestpcms4, unable to open the output file = pcmdata \n");
	   exit(-1);
   }
   delcount=0;

   for(a = 0 ; a < MAX ; a++)
   {
      myloc = mindist(Xpos[a],Ypos[a]);
	  
      if (myloc != -1)   // found a minimum
	  {
         fprintf(platefile, "%0.0f %0.0f\n", Xarray[myloc] ,Yarray[myloc]); //   > "platecap.pcm"
         fprintf(pcmdatafile,"%0.0f %0.0f %s%splatecap\n",Xarray[myloc],Yarray[myloc], path,dirsep); //  > "pcmdata"
         delete_array[myloc] =1 ;//  Xarray[myloc]
         delete_array[myloc] =1;  //Yarray[myloc]
		 delarray[delcount].xval=Xarray[myloc];
		 delarray[delcount].yval=Yarray[myloc];
		 if (delcount < 1000)
		 {
			 delcount += 1;
		 }
      }
      // printf("myloc %s\n",myloc); //  | "cat 1>&2"
   }

  
  for( z=0; z < cnt; z+= 1) //  in Xarray)
   {
     
	if (! in_dellist( Xarray[z],Yarray[z]) )
		 {
	       printf( "%0.0f %0.0f R\n", Xarray[z],Yarray[z]);
			   
	
		}
      
   }
  
   fclose(platefile);
   fclose(pcmdatafile);

} // end placetestpcms4_call

/*
int main( int argc, char **argv)
{

    if (argc != 3)
	 {
	  printf("In placetestpcms4, wrong number of arguments \n");
	  printf("Usage: placetestpcms4 master_pcm_path pcm_coords_file\n");
	  exit(-1);
	 }
    else
	{
	placetestpcms4_call( argv[1], argv[2]);
	}
} 

*/






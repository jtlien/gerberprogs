#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

//! /usr/local/bin/gawk -f

char str_array[120][120];

double Xarray[100000];
double Yarray[100000];
int delete_array[100000];
int cnt;


int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

double dist( double x1, double y1, double x2, double y2)
{
double dx;
double dy;
double d;

   dx = (x2-x1)*(x2-x1);
   dy = (y2-y1)*(y2-y1);
   d  = sqrt(dx+dy);
   return(d);
}

// find the location in the array Xarray, Yarray
// that is closest to X1 and Y1

int mindist(double X1, double Y1)
{
int loc;
double lowest;
int j;
double di;

   lowest =  100000000;
   loc = -1;
   for(j = 0 ; j < cnt ; j++)
   {
      if ( delete_array[j] == 0 )  // not deleted  
	  {
         di = dist(X1,Y1,Xarray[j],Yarray[j]);
         if( di< lowest )
		 {
	      lowest = di;
	      loc = j;
         }
      }
   }
   // printf("lowest is %s at location %s\n",lowest,loc)| "cat 1>&2"
   return(loc);

}
    
void placetestpcms4s_call_out(char *pathstr, char *file1str, char *outfilestr)
{
double Xpos[10];
double Ypos[10];
int z;
int a;
int MAX;
int endoffile;
int nf;
FILE *file1;
FILE *outfile;
FILE *platefile;
FILE *pcmdatafile;

char dirsep[10];
char thisline[200];

char path[120];
int myloc;

    if (WINDOWS)
	{
		strncpy(dirsep,"\\",4);
	}
	else
	{
		strncpy(dirsep,"/",4);
	}

   strncpy(path,pathstr,120);

   Xpos[0] = 0;             //  center of ACTIVE AREA
   Xpos[1] = -1524000;      //  upper left corner of ACTIVE AREA
   Xpos[2] = -1524000;      //  near middle of left edge
   Xpos[3] =  -900000;      //  near left bottom
   Xpos[4] =   900000;      //  near right top
   Xpos[5] =  1524000;      //  right edge near center
   Xpos[6] =  1524000;      //  right lower corner


   Ypos[0] = 0;
   Ypos[1] =  1524000;
   Ypos[2] =    -5000;
   Ypos[3] = -1524000;
   Ypos[4] =  1524000;
   Ypos[5] =     5000;
   Ypos[6] = -1524000;

   MAX   = 7;
   cnt = 0;

   file1 = fopen(file1str,"r");
   if (file1 == NULL)
   {
	   printf("In placetestpcms4, unable to open the input file = %s \n",file1str);
	   exit(-1);
   }

   outfile = fopen(outfilestr,"w");
   if (outfile == NULL)
   {
	   printf("In placetestpcms4, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile == FALSE)
   {
     if( strstr(thisline,"R") != NULL) // $0 ~ /R/)
	 {
		if (cnt < 100000)
		{
         Xarray[cnt] = atof(str_array[0]); // $1
         Yarray[cnt] = atof(str_array[1]); // $2 
		 delete_array[cnt] = 0;
         cnt++;
		}
		else
		{
			printf("Xarray,Yarray count exceeds 100000 \n");
			exit(-1);
		}
     }
     else 
	 {
	  fprintf(outfile,"%s",thisline); // $0
     }

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
   }

   fclose(file1);

   platefile=fopen("platecap.pcm","w");
   pcmdatafile=fopen("pcmdata","w");

   for(a = 0 ; a < MAX ; a++)
   {
      myloc = mindist(Xpos[a],Ypos[a]);
	  
      if (myloc != -1)
	  {
         fprintf(platefile, "%0.0f %0.0f\n", Xarray[myloc] ,Yarray[myloc]); //   > "platecap.pcm"
         fprintf(pcmdatafile,"%0.0f %0.0f %s%splatecap\n",Xarray[myloc],Yarray[myloc], path,dirsep); //  > "pcmdata"
         delete_array[myloc] =1 ;//  Xarray[myloc]
         delete_array[myloc] =1;  //Yarray[myloc]
      }
      // printf("myloc %s\n",myloc); //  | "cat 1>&2"
   }

   for( z=0; z < cnt; z+= 1) //  in Xarray)
   {
      if (delete_array[z] == 0 )
	  {
	   fprintf(outfile, "%0.0f %0.0f R\n", Xarray[z],Yarray[z]);
      }
   }
   fclose(platefile);
   fclose(pcmdatafile);
   fclose(outfile);

} // end placetestpcms4_call_out

    
void placetestpcms4s_call(char *pathstr, char *file1str)
{
double Xpos[10];
double Ypos[10];
int z;
int a;
int MAX;
int endoffile;
int nf;
FILE *file1;
FILE *platefile;
FILE *pcmdatafile;

char dirsep[10];
char thisline[200];

char path[120];
int myloc;

    if (WINDOWS)
	{
		strncpy(dirsep,"\\",4);
	}
	else
	{
		strncpy(dirsep,"/",4);
	}

   strncpy(path,pathstr,120);

   Xpos[0] = 0;             //  center of ACTIVE AREA
   Xpos[1] = -1524000;      //  upper left corner of ACTIVE AREA
   Xpos[2] = -1524000;      //  near middle of left edge
   Xpos[3] =  -900000;      //  near left bottom
   Xpos[4] =   900000;      //  near right top
   Xpos[5] =  1524000;      //  right edge near center
   Xpos[6] =  1524000;      //  right lower cornerXpos[0] = 0;
   Xpos[7] =        0;      //  center of top
   Xpos[8] =        0;      //  center of bottom

   Ypos[0] = 0;
   Ypos[1] =  1524000;
   Ypos[2] =    -5000;
   Ypos[3] = -1524000;
   Ypos[4] =  1524000;
   Ypos[5] =     5000;
   Ypos[6] = -1524000;
   Ypos[7] =  1524000;    
   Ypos[8] = -1524000;      

   MAX   = 9;
   cnt = 0;

   file1 = fopen(file1str,"r");
   if (file1 == NULL)
   {
	   printf("In placetestpcms4, unable to open the input file = %s \n",file1str);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile == FALSE)
   {
     if( strstr(thisline,"R") != NULL) // $0 ~ /R/)
	 {
		if (cnt < 100000)
		{
         Xarray[cnt] = atof(str_array[0]); // $1
         Yarray[cnt] = atof(str_array[1]); // $2 
		 delete_array[cnt] = 0;
         cnt++;
		}
		else
		{
			printf("Xarray,Yarray count exceeds 100000 \n");
			exit(-1);
		}
     }
     else 
	 {
	  printf("%s",thisline); // $0
     }

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
   }

   fclose(file1);

   platefile=fopen("platecap.pcm","w");
   pcmdatafile=fopen("pcmdata","w");

   for(a = 0 ; a < MAX ; a++)
   {
      myloc = mindist(Xpos[a],Ypos[a]);
	  
      if (myloc != -1)   // found a minimum
	  {
         fprintf(platefile, "%0.0f %0.0f\n", Xarray[myloc] ,Yarray[myloc]); //   > "platecap.pcm"
         fprintf(pcmdatafile,"%0.0f %0.0f %s%splatecap\n",Xarray[myloc],Yarray[myloc], path,dirsep); //  > "pcmdata"
         delete_array[myloc] =1 ;//  Xarray[myloc]
         delete_array[myloc] =1;  //Yarray[myloc]
      }
      // printf("myloc %s\n",myloc); //  | "cat 1>&2"
   }

   for( z=0; z < cnt; z+= 1) //  in Xarray)
   {
      if (delete_array[z] == 0 )
	  {
	   printf( "%0.0f %0.0f R\n", Xarray[z],Yarray[z]);
      }
   }
   fclose(platefile);
   fclose(pcmdatafile);

} // end placetestpcms4_call

int main( int argc, char **argv)
{

	placetestpcms4s_call( argv[1], argv[2]);

}

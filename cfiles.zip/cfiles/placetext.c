#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

double mult;

void init_alpha_char()
{
	alpha[0].gchar = 'A';
	alpha[1].gchar = 'B';
	alpha[2].gchar = 'C';
	alpha[3].gchar = 'D';
	alpha[4].gchar = 'E';
	alpha[5].gchar = 'F';
    alpha[6].gchar = 'G';
    alpha[7].gchar = 'H'; 
    alpha[8].gchar = 'I';
    alpha[9].gchar = 'J';
    alpha[10].gchar ='K';
    alpha[11].gchar ='L'; 
    alpha[12].gchar ='M';
    alpha[13].gchar ='N';
    alpha[14].gchar ='O';
    alpha[15].gchar ='P'; 
    alpha[16].gchar ='Q';
    alpha[17].gchar ='R'; 
    alpha[18].gchar ='S'; 
    alpha[19].gchar ='T';
    alpha[20].gchar ='U';
    alpha[21].gchar ='V';
	alpha[22].gchar ='W';
	alpha[23].gchar ='X';
	alpha[24].gchar ='Y';
    alpha[25].gchar ='Z';
    alpha[26].gchar ='0';
    alpha[27].gchar ='1';
    alpha[28].gchar ='2'; 
    alpha[29].gchar ='3';
    alpha[30].gchar ='4';
    alpha[31].gchar ='5';
    alpha[32].gchar ='6';
    alpha[33].gchar ='7';
    alpha[34].gchar ='8';
    alpha[35].gchar ='9';
    alpha[36].gchar ='&';
    alpha[37].gchar ='\\';
    alpha[38].gchar =',';
    alpha[39].gchar ='@';
    alpha[40].gchar ='.';
    alpha[41].gchar ='-';
    alpha[42].gchar ='/';

}  // end init_alpha_char


void parsetext( double myX, double myY, char *instring)
{
int len;
int i;
 int arrayindex;
int j;
char letter;

  len = strlen(instring);
  for( i = 0 ; i < len; i++)
   {
      letter = toupper( instring[i]);

	  // printf("Letter= %c , %d \n",letter,letter);
      arrayindex = -1;
      if( isalpha(letter))
      {
	arrayindex = letter - 'A';
      }
      if( isdigit(letter) )
       {
	 arrayindex = 26 + letter - '0';
      }
      if (letter == '&' )  // ampersand
       {
         arrayindex=36;
       }
      if (letter == '\\')  // backslash
       {
         arrayindex=37;
       }
      if (letter == ',' )   // comma
       {
         arrayindex=38;
       }
      if (letter == '@' )  // copyright
       {
         arrayindex=39;
       }
      if ( letter == '-')   //dash 
      {
  	     arrayindex=40;
      }
      if (letter == '.' )  //dot
       {
         arrayindex=41;
       }
      if (letter == '/' )  // forward slash
       {
         arrayindex=42;
       }
      if ( arrayindex > -1)
      {
        if (arrayindex < 43)
		{
		  for(j=0; j < 40; j += 1)
		  {
			  strncpy(glines[j],"",4);
		  }
          j= 0;
	      while( strlen(alpha[arrayindex].glines[j]) > 0 )
          {
		        strncpy(glines[j],alpha[arrayindex].glines[j],40);
                j += 1;
		  }
            placestandard( myX, myY);  // uses glines
			myX= myX + 2.54 * mult;
        }
        else
		{
            printf("Internal error \n");
		}
      }
     else
      {
	printf("letter not in printable set = %c  =%d \n",letter,letter);
      }
        
  }

}  // end parsetext

void parsetext_file( double myX, double myY, char *instring, FILE *ofile)
{
int len;
int i;
 int arrayindex;
int j;
char letter;

  len = strlen(instring);
  for( i = 0 ; i < len; i++)
   {
      letter = toupper( instring[i]);

	  // printf("Letter= %c , %d \n",letter,letter);
      arrayindex = -1;
      if( isalpha(letter))
      {
	arrayindex = letter - 'A';
      }
      if( isdigit(letter) )
       {
	 arrayindex = 26 + letter - '0';
      }
      if (letter == '&' )  // ampersand
       {
         arrayindex=36;
       }
      if (letter == '\\')  // backslash
       {
         arrayindex=37;
       }
      if (letter == ',' )   // comma
       {
         arrayindex=38;
       }
      if (letter == '@' )  // copyright
       {
         arrayindex=39;
       }
      if ( letter == '-')   //dash 
      {
  	     arrayindex=40;
      }
      if (letter == '.' )  //dot
       {
         arrayindex=41;
       }
      if (letter == '/' )  // forward slash
       {
         arrayindex=42;
       }
      if ( arrayindex > -1)
      {
        if (arrayindex < 43)
		{
		  for(j=0; j < 40; j += 1)
		  {
			  strncpy(glines[j],"",4);
		  }
          j= 0;
	      while( strlen(alpha[arrayindex].glines[j]) > 0 )
          {
		        strncpy(glines[j],alpha[arrayindex].glines[j],40);
                j += 1;
		  }
            placestandard_out( myX, myY, ofile);  // uses glines
			myX= myX + 2.54 * mult;
        }
        else
		{
            printf("Internal error \n");
		}
      }
     else
      {
	printf("letter not in printable set = %c  =%d \n",letter,letter);
      }
        
  }

}  // end parsetext_file

int placetext_call_out( char *infilestr, char *outfilestr)
{
FILE *infile;
FILE *outfile;
int endoffile;
int nf;
double xtemp;
double ytemp;
double X1;
int tmp;
int count;
int loopcnt;
char thisline[120];

    infile=fopen(infilestr,"r");

	if (infile == NULL)
	{
		printf("In placetext, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

    outfile=fopen(outfilestr,"w");

	if (outfile == NULL)
	{
		printf("In placetext, unable to open the output file = %s \n",outfilestr);
		exit(-1);
	}

	init_alpha_glines();

	// printf("Init complete \n");

    

	endoffile = getline(infile,thisline);
	nf=split_line(thisline);

    mult =  pow(10,atoi(str_array[0])); 
 

    endoffile = getline(infile,thisline);
    nf = split_line(thisline);

    while(endoffile==FALSE)
     {
	   // printf("nf=%d\n",nf);
      if( nf == 3)
	  {
	   xtemp=atof(str_array[0]);
       ytemp=atof(str_array[1]);
       parsetext_file(xtemp * mult, ytemp * mult, str_array[2], outfile);
       }
      else 
       {
       xtemp = atof(str_array[0]);
       ytemp = atof(str_array[1]);

       X1 = xtemp * mult;
       count = nf;    // NF is change by function placestandard
       // strncpy(thisword,thisline,120);
	   
       parsetext_file(xtemp * mult, ytemp * mult, str_array[2],outfile);
      // $0 = word
       for( loopcnt = 4 ; loopcnt <= count; loopcnt++)
	   {
            tmp = loopcnt - 1;
	        X1 +=   (strlen(str_array[tmp-1]) + 1)*(2.54 * mult);
            parsetext_file(X1, ytemp * mult, str_array[loopcnt-1],outfile);
          // $0 = word
         }
      }
    endoffile=getline(infile,thisline);
    nf=split_line(thisline);
     }

    fclose(infile);

    fclose(outfile);
    return(0);

}  // placetext_call

int placetext_call( char *infilestr)
{
FILE *infile;
int endoffile;
int nf;
double xtemp;
double ytemp;
double X1;
int tmp;
int count;
int loopcnt;
char thisline[120];

    infile=fopen(infilestr,"r");

	if (infile == NULL)
	{
		printf("In placetext, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

    
	init_alpha_glines();

	// printf("Init complete \n");

    

	endoffile = getline(infile,thisline);
	nf=split_line(thisline);

    mult =  pow(10,atoi(str_array[0])); 
 

    endoffile = getline(infile,thisline);
    nf = split_line(thisline);

    while(endoffile==FALSE)
     {
	   // printf("nf=%d\n",nf);
      if( nf == 3)
	  {
	   xtemp=atof(str_array[0]);
       ytemp=atof(str_array[1]);
       parsetext(xtemp * mult, ytemp * mult, str_array[2]);
       }
      else 
       {
       xtemp = atof(str_array[0]);
       ytemp = atof(str_array[1]);

       X1 = xtemp * mult;
       count = nf;    // NF is change by function placestandard
       // strncpy(thisword,thisline,120);
	   
       parsetext(xtemp * mult, ytemp * mult, str_array[2]);
      // $0 = word
       for( loopcnt = 4 ; loopcnt <= count; loopcnt++)
	   {
            tmp = loopcnt - 1;
	        X1 +=   (strlen(str_array[tmp-1]) + 1)*(2.54 * mult);
            parsetext(X1, ytemp * mult, str_array[loopcnt-1]);
          // $0 = word
         }
      }
    endoffile=getline(infile,thisline);
    nf=split_line(thisline);
     }

    fclose(infile);

    return(0);

}  // placetext_call


/*
int main( int argc, char **argv)
{

  if ( argc != 2)
   {
     printf("In placetext, wrong number of arguments \n");
	 printf("Usage: placetext infile  \n");
	 exit(-1);
    }
  else
    {
	placetext_call( argv[1]);
	}

}  
*/


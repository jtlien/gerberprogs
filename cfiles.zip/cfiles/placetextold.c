#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>


#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


struct alphastuff
{
	char gchar;
	char glines[40][40];
} alpha[44];

double xtemp;
double ytemp;
double X1;
int tt;
int tmp;
int count;
int loopcnt;
char glines[40][40];
char thisline[120];
double mult;

char str_array[120][120];

void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk,ll;

  ii=0;
  kk = 0;

  ll = strlen(instr);

  if ( ll > 0)          // remove possible end of line from end of string
  {
	  if (instr[ll-1] == 10)
	  {
		  instr[ll-1] = 0;
	  }
  }

 while((instr[ii] != srchstr[0]) && ( ii < strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;


}  // end split

//
// perform awk compatible awk_index, counts from 1 at the leftmost
//
int awk_index( char *instr, char *inchr)
{
int kk,ll,mm;
char tstr[120];

	if (strstr(instr, inchr) == NULL)    // not found at all in string, return 0
	{
		return(0);
	}
	else    // the inchr string is a substring
	{
		kk = 0;
		while( kk < strlen( instr))
		{
          ll = 0;
		  mm = kk;
		  while( mm < strlen( instr))
		  {
			tstr[ll] = instr[mm];
			mm += 1;
			ll += 1;
		  }
		  tstr[ll] = 0;
		  if (strstr( tstr,inchr) == NULL)  // no longer found as substring
		  {
			return(kk);
		  }
		 kk += 1;
		}
	}

  return(0);

 
} // awk compatible index


// perform awk compatible substr, except the 4th parameter is the
//   result string
//
void awk_substr( char *instr, int sbegin, int slength, char *resultstr)
{

char tstr[120];
int kk;
int ll;

     if ( sbegin > 0)
	 {
		 sbegin = sbegin-1;
	 }
     kk = sbegin;
     ll = 0;
	 while ( ( kk < strlen(instr) && ( ll < slength)) )
	 {
		 tstr[ll] = instr[kk];
		 kk += 1;
		 ll  += 1;
	 }
	 tstr[ll]=0;

	 strncpy( resultstr,tstr,slength+2);

}   // awk substr

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline


void init_alpha_glines( )
{

strncpy(alpha[0].glines[0],"G54D548*",40);
strncpy(alpha[0].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[0].glines[2],"Y-3750D01*",40);
strncpy(alpha[0].glines[3],"X0Y11250D01*",40);
strncpy(alpha[0].glines[4],"X7500Y-3750D01*",40);
strncpy(alpha[0].glines[5],"Y-11250D01*",40);
strncpy(alpha[0].glines[6],"X-7500Y-3750D02*",40);
strncpy(alpha[0].glines[7],"X7500D01*",40);
strncpy(alpha[0].glines[8],"M02*",40);
strncpy(alpha[0].glines[9],"",4);

strncpy(alpha[1].glines[0],"G54D548*",40);
strncpy(alpha[1].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[1].glines[2],"X3750D01*",40);
strncpy(alpha[1].glines[3],"X7500Y-7500D01*",40);
strncpy(alpha[1].glines[4],"Y-3750D01*",40);
strncpy(alpha[1].glines[5],"X3750Y0D01*",40);
strncpy(alpha[1].glines[6],"X-3750D01*",40);
strncpy(alpha[1].glines[7],"X3750D02*",40);
strncpy(alpha[1].glines[8],"X7500Y3750D01*",40);
strncpy(alpha[1].glines[9],"Y7500D01*",40);
strncpy(alpha[1].glines[10],"X3750Y11250D01*",40);
strncpy(alpha[1].glines[11],"X-7500D01*",40);
strncpy(alpha[1].glines[12],"X-3750D02*",40);
strncpy(alpha[1].glines[13],"Y-11250D01*",40);
strncpy(alpha[1].glines[14],"M02*",40);
strncpy(alpha[1].glines[15],"",4);

strncpy(alpha[2].glines[0],"G54D548*",40);
strncpy(alpha[2].glines[1],"X7500Y-7500D02*",40);
strncpy(alpha[2].glines[2],"X3750Y-11250D01*",40);
strncpy(alpha[2].glines[3],"X-3750D01*",40);
strncpy(alpha[2].glines[4],"X-7500Y-7500D01*",40);
strncpy(alpha[2].glines[5],"Y7500D01*",40);
strncpy(alpha[2].glines[6],"X-3750Y11250D01*",40);
strncpy(alpha[2].glines[7],"X3750D01*",40);
strncpy(alpha[2].glines[8],"X7500Y7500D01*",40);
strncpy(alpha[2].glines[9],"M02*",40);
strncpy(alpha[2].glines[10],"",4);

strncpy(alpha[3].glines[0],"G54D548*",40);
strncpy(alpha[3].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[3].glines[2],"X3750D01*",40);
strncpy(alpha[3].glines[3],"X7500Y-7500D01*",40);
strncpy(alpha[3].glines[4],"Y7500D01*",40);
strncpy(alpha[3].glines[5],"X3750Y11250D01*",40);
strncpy(alpha[3].glines[6],"X-7500D01*",40);
strncpy(alpha[3].glines[7],"X-3750D02*",40);
strncpy(alpha[3].glines[8],"Y-11250D01*",40);
strncpy(alpha[3].glines[9],"M02*",40);
strncpy(alpha[3].glines[10],"",4);

strncpy(alpha[4].glines[0],"G54D548*",40);
strncpy(alpha[4].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[4].glines[2],"Y11250D01*",40);
strncpy(alpha[4].glines[3],"X7500D01*",40);
strncpy(alpha[4].glines[4],"X-7500Y0D02*",40);
strncpy(alpha[4].glines[5],"X0D01*",40);
strncpy(alpha[4].glines[6],"X-7500Y-11250D02*",40);
strncpy(alpha[4].glines[7],"X7500D01*",40);
strncpy(alpha[4].glines[8],"M02*",40);
strncpy(alpha[4].glines[9],"",4);

strncpy(alpha[5].glines[0],"G54D548*",40);
strncpy(alpha[5].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[5].glines[2],"Y11250D01*",40);
strncpy(alpha[5].glines[3],"X7500D01*",40);
strncpy(alpha[5].glines[4],"X-7500Y0D02*",40);
strncpy(alpha[5].glines[5],"X0D01*",40);
strncpy(alpha[5].glines[6],"M02*",40);
strncpy(alpha[5].glines[7],"",4);

strncpy(alpha[6].glines[0],"G54D548*",40);
strncpy(alpha[6].glines[1],"X3750Y0D02*",40);
strncpy(alpha[6].glines[2],"X7500D01*",40);
strncpy(alpha[6].glines[3],"Y-11250D01*",40);
strncpy(alpha[6].glines[4],"X-3750D01*",40);
strncpy(alpha[6].glines[5],"X-7500Y-7500D01*",40);
strncpy(alpha[6].glines[6],"Y7500D01*",40);
strncpy(alpha[6].glines[7],"X-3750Y11250D01*",40);
strncpy(alpha[6].glines[8],"X7500D01*",40);
strncpy(alpha[6].glines[9],"M02*",40);
strncpy(alpha[6].glines[10],"",4);


strncpy(alpha[7].glines[0],"G54D548*",40);
strncpy(alpha[7].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[7].glines[2],"Y11250D01*",40);
strncpy(alpha[7].glines[3],"Y0D02*",40);
strncpy(alpha[7].glines[4],"X7500D01*",40);
strncpy(alpha[7].glines[5],"Y11250D02*",40);
strncpy(alpha[7].glines[6],"Y-11250D01*",40);
strncpy(alpha[7].glines[7],"M02*",40);
strncpy(alpha[7].glines[8],"",4);

strncpy(alpha[8].glines[0],"G54D548*",40);
strncpy(alpha[8].glines[1],"X-3750Y11250D02*",40);
strncpy(alpha[8].glines[2],"X3750D01*",40);
strncpy(alpha[8].glines[3],"X0D02*",40);
strncpy(alpha[8].glines[4],"Y-11250D01*",40);
strncpy(alpha[8].glines[5],"X-3750D02*",40);
strncpy(alpha[8].glines[6],"X3750D01*",40);
strncpy(alpha[8].glines[7],"M02*",40);
strncpy(alpha[8].glines[8],"",4);

strncpy(alpha[9].glines[0],"G54D548*",40);
strncpy(alpha[9].glines[1],"X-7500Y-7500D02*",40);
strncpy(alpha[9].glines[2],"X-3750Y-11250D01*",40);
strncpy(alpha[9].glines[3],"X3750D01*",40);
strncpy(alpha[9].glines[4],"X7500Y-7500D01*",40);
strncpy(alpha[9].glines[5],"Y11250D01*",40);
strncpy(alpha[9].glines[6],"M02*",40);
strncpy(alpha[9].glines[7],"",4);

strncpy(alpha[10].glines[0],"G54D548*",40);
strncpy(alpha[10].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[10].glines[2],"Y11250D01*",40);
strncpy(alpha[10].glines[3],"X7500D02*",40);
strncpy(alpha[10].glines[4],"X-3750Y0D01*",40);
strncpy(alpha[10].glines[5],"X-7500D01*",40);
strncpy(alpha[10].glines[6],"X-3750D02*",40);
strncpy(alpha[10].glines[7],"X7500Y-11250D01*",40);
strncpy(alpha[10].glines[8],"M02*",40);
strncpy(alpha[10].glines[9],"",4);

strncpy(alpha[11].glines[0],"G54D548*",40);
strncpy(alpha[11].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[11].glines[2],"Y-11250D01*",40);
strncpy(alpha[11].glines[3],"X7500D01*",40);
strncpy(alpha[11].glines[4],"M02*",40);
strncpy(alpha[11].glines[5],"",4);

strncpy(alpha[12].glines[0],"G54D548*",40);
strncpy(alpha[12].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[12].glines[2],"Y11250D01*",40);
strncpy(alpha[12].glines[3],"X0Y-3750D01*",40);
strncpy(alpha[12].glines[4],"X7500Y11250D01*",40);
strncpy(alpha[12].glines[5],"Y-11250D01*",40);
strncpy(alpha[12].glines[6],"M02*",40);
strncpy(alpha[12].glines[7],"",4);

strncpy(alpha[13].glines[0],"G54D548*",40);
strncpy(alpha[13].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[13].glines[2],"Y11250D01*",40);
strncpy(alpha[13].glines[3],"X7500Y-11250D01*",40);
strncpy(alpha[13].glines[4],"Y11250D01*",40);
strncpy(alpha[13].glines[5],"M02*",40);
strncpy(alpha[13].glines[6],"",4);

strncpy(alpha[14].glines[0],"G54D548*",40);
strncpy(alpha[14].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[14].glines[2],"Y11250D01*",40);
strncpy(alpha[14].glines[3],"X7500D01*",40);
strncpy(alpha[14].glines[4],"Y-11250D01*",40);
strncpy(alpha[14].glines[5],"X-7500D01*",40);
strncpy(alpha[14].glines[6],"M02*",40);
strncpy(alpha[14].glines[7],"",4);

strncpy(alpha[15].glines[0],"G54D548*",40);
strncpy(alpha[15].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[15].glines[2],"Y11250D01*",40);
strncpy(alpha[15].glines[3],"X3750D01*",40);
strncpy(alpha[15].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[15].glines[5],"Y3750D01*",40);
strncpy(alpha[15].glines[6],"X3750Y0D01*",40);
strncpy(alpha[15].glines[7],"X-7500D01*",40);
strncpy(alpha[15].glines[8],"M02*",40);
strncpy(alpha[15].glines[9],"",4);

strncpy(alpha[16].glines[0],"G54D548*",40);
strncpy(alpha[16].glines[1],"X0Y-3750D02*",40);
strncpy(alpha[16].glines[2],"X3750Y-7500D01*",40);
strncpy(alpha[16].glines[3],"X0Y-11250D01*",40);
strncpy(alpha[16].glines[4],"X-3750D01*",40);
strncpy(alpha[16].glines[5],"X-7500Y-7500D01*",40);
strncpy(alpha[16].glines[6],"Y7500D01*",40);
strncpy(alpha[16].glines[7],"X-3750Y11250D01*",40);
strncpy(alpha[16].glines[8],"X3750D01*",40);
strncpy(alpha[16].glines[9],"X7500Y7500D01*",40);
strncpy(alpha[16].glines[10],"Y-3750D01*",40);
strncpy(alpha[16].glines[11],"X3750Y-7500D01*",40);
strncpy(alpha[16].glines[12],"X7500Y-11250D01*",40);
strncpy(alpha[16].glines[13],"M02*",40);
strncpy(alpha[16].glines[14],"",4);

strncpy(alpha[17].glines[0],"G54D548*",40);
strncpy(alpha[17].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[17].glines[2],"Y11250D01*",40);
strncpy(alpha[17].glines[3],"X3750D01*",40);
strncpy(alpha[17].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[17].glines[5],"Y3750D01*",40);
strncpy(alpha[17].glines[6],"X3750Y0D01*",40);
strncpy(alpha[17].glines[7],"X-7500D01*",40);
strncpy(alpha[17].glines[8],"X-3750D02*",40);
strncpy(alpha[17].glines[9],"X7500Y-11250D01*",40);
strncpy(alpha[17].glines[10],"M02*",40);
strncpy(alpha[17].glines[11],"",4);

strncpy(alpha[18].glines[0],"G54D548*",40);
strncpy(alpha[18].glines[1],"X-7500Y-7500D02*",40);
strncpy(alpha[18].glines[2],"X-3750Y-11250D01*",40);
strncpy(alpha[18].glines[3],"X3750D01*",40);
strncpy(alpha[18].glines[4],"X7500Y-7500D01*",40);
strncpy(alpha[18].glines[5],"X-7500Y7500D01*",40);
strncpy(alpha[18].glines[6],"X-3750Y11250D01*",40);
strncpy(alpha[18].glines[7],"X3750D01*",40);
strncpy(alpha[18].glines[8],"X7500Y7500D01*",40);
strncpy(alpha[18].glines[9],"M02*",40);
strncpy(alpha[18].glines[10],"",4);

strncpy(alpha[19].glines[0],"G54D548*",40);
strncpy(alpha[19].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[19].glines[2],"X7500D01*",40);
strncpy(alpha[19].glines[3],"X0D02*",40);
strncpy(alpha[19].glines[4],"Y-11250D01*",40);
strncpy(alpha[19].glines[5],"M02*",40);
strncpy(alpha[19].glines[6],"",4);

strncpy(alpha[20].glines[0],"G54D548*",40);
strncpy(alpha[20].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[20].glines[2],"Y-7500D01*",40);
strncpy(alpha[20].glines[3],"X-3750Y-11250D01*",40);
strncpy(alpha[20].glines[4],"X3750D01*",40);
strncpy(alpha[20].glines[5],"X7500Y-7500D01*",40);
strncpy(alpha[20].glines[6],"Y11250D01*",40);
strncpy(alpha[20].glines[7],"M02*",40);
strncpy(alpha[20].glines[8],"",4);

strncpy(alpha[21].glines[0],"G54D548*",40);
strncpy(alpha[21].glines[1],"X-6150Y11250D02*",40);
strncpy(alpha[21].glines[2],"X975Y-11250D01*",40);
strncpy(alpha[21].glines[3],"X8475Y11250D01*",40);
strncpy(alpha[21].glines[4],"M02*",40);
strncpy(alpha[21].glines[5],"",4);

strncpy(alpha[22].glines[0],"G54D548*",40);
strncpy(alpha[22].glines[1],"X-6150Y11250D02*",40);
strncpy(alpha[22].glines[2],"X-1275Y-11250D01*",40);
strncpy(alpha[22].glines[3],"X975Y0D01*",40);
strncpy(alpha[22].glines[4],"X3600Y-11250D01*",40);
strncpy(alpha[22].glines[5],"X8475Y11250D01*",40);
strncpy(alpha[22].glines[6],"M02*",40);
strncpy(alpha[23].glines[7],"",4);

strncpy(alpha[23].glines[0],"G54D548*",40);
strncpy(alpha[23].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[23].glines[2],"X7500Y11250D01*",40);
strncpy(alpha[23].glines[3],"X-7500D02*",40);
strncpy(alpha[23].glines[4],"X7500Y-11250D01*",40);
strncpy(alpha[23].glines[5],"M02*",40);
strncpy(alpha[23].glines[6],"",4);

strncpy(alpha[24].glines[0],"G54D548*",40);
strncpy(alpha[24].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[24].glines[2],"X0Y0D01*",40);
strncpy(alpha[24].glines[3],"Y-11250D01*",40);
strncpy(alpha[24].glines[4],"Y0D02*",40);
strncpy(alpha[24].glines[5],"X7500Y11250D01*",40);
strncpy(alpha[24].glines[6],"M02*",40);
strncpy(alpha[25].glines[7],"",4);

strncpy(alpha[25].glines[0],"G54D548*",40);
strncpy(alpha[25].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[25].glines[2],"X7500D01*",40);
strncpy(alpha[25].glines[3],"X-7500Y-11250D01*",40);
strncpy(alpha[25].glines[4],"X7500D01*",40);
strncpy(alpha[25].glines[5],"M02*",40);
strncpy(alpha[25].glines[6],"",4);

strncpy(alpha[26].glines[0],"G54D548*",40);
strncpy(alpha[26].glines[1],"X-1875Y-11250D02*",40);
strncpy(alpha[26].glines[2],"X-5625Y-7500D01*",40);
strncpy(alpha[26].glines[3],"Y7500D01*",40);
strncpy(alpha[26].glines[4],"X-1875Y11250D01*",40);
strncpy(alpha[26].glines[5],"X1875D01*",40);
strncpy(alpha[26].glines[6],"X5625Y7500D01*",40);
strncpy(alpha[26].glines[7],"Y-7500D01*",40);
strncpy(alpha[26].glines[8],"X1875Y-11250D01*",40);
strncpy(alpha[26].glines[9],"X-1875D01*",40);
strncpy(alpha[26].glines[10],"X-5625Y-7500D02*",40);
strncpy(alpha[26].glines[11],"X5625Y7500D01*",40);
strncpy(alpha[26].glines[12],"M02*",40);
strncpy(alpha[26].glines[13],"",4);

strncpy(alpha[27].glines[0],"G54D548*",40);
strncpy(alpha[27].glines[1],"X-3750Y7500D02*",40);
strncpy(alpha[27].glines[2],"X0Y11250D01*",40);
strncpy(alpha[27].glines[3],"Y-11250D01*",40);
strncpy(alpha[27].glines[4],"X-3750D02*",40);
strncpy(alpha[27].glines[5],"X3750D01*",40);
strncpy(alpha[27].glines[6],"M02*",40);
strncpy(alpha[27].glines[7],"",4);

strncpy(alpha[28].glines[0],"G54D548*",40);
strncpy(alpha[28].glines[1],"X-7500Y7500D02*",40);
strncpy(alpha[28].glines[2],"X-3750Y11250D01*",40);
strncpy(alpha[28].glines[3],"X3750D01*",40);
strncpy(alpha[28].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[28].glines[5],"Y3750D01*",40);
strncpy(alpha[28].glines[6],"X3750Y0D01*",40);
strncpy(alpha[28].glines[7],"X-3750D01*",40);
strncpy(alpha[28].glines[8],"X-7500Y-3750D01*",40);
strncpy(alpha[28].glines[9],"Y-11250D01*",40);
strncpy(alpha[28].glines[10],"X7500D01*",40);
strncpy(alpha[28].glines[11],"M02*",40);
strncpy(alpha[28].glines[12],"",4);

strncpy(alpha[29].glines[0],"G54D548*",40);
strncpy(alpha[29].glines[1],"X-7500Y7500D02*",40);
strncpy(alpha[29].glines[2],"X-3750Y11250D01*",40);
strncpy(alpha[29].glines[3],"X3750D01*",40);
strncpy(alpha[29].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[29].glines[5],"Y3750D01*",40);
strncpy(alpha[29].glines[6],"X3750Y0D01*",40);
strncpy(alpha[29].glines[7],"X0D01*",40);
strncpy(alpha[29].glines[8],"X3750D02*",40);
strncpy(alpha[29].glines[9],"X7500Y-3750D01*",40);
strncpy(alpha[29].glines[10],"Y-7500D01*",40);
strncpy(alpha[29].glines[11],"X3750Y-11250D01*",40);
strncpy(alpha[29].glines[12],"X-3750D01*",40);
strncpy(alpha[29].glines[13],"X-7500Y-7500D01*",40);
strncpy(alpha[29].glines[14],"M02*",40);
strncpy(alpha[29].glines[15],"",4);

strncpy(alpha[30].glines[0],"G54D548*",40);
strncpy(alpha[30].glines[1],"X7500Y-3750D02*",40);
strncpy(alpha[30].glines[2],"X-7500D01*",40);
strncpy(alpha[30].glines[3],"X3750Y11250D01*",40);
strncpy(alpha[30].glines[4],"Y-11250D01*",40);
strncpy(alpha[30].glines[5],"M02*",40);
strncpy(alpha[30].glines[6],"",4);

strncpy(alpha[31].glines[0],"G54D548*",40);
strncpy(alpha[31].glines[1],"X-7500Y-7500D02*",40);
strncpy(alpha[31].glines[2],"X-3750Y-11250D01*",40);
strncpy(alpha[31].glines[3],"X3750D01*",40);
strncpy(alpha[31].glines[4],"X7500Y-7500D01*",40);
strncpy(alpha[31].glines[5],"Y0D01*",40);
strncpy(alpha[31].glines[6],"X3750Y3750D01*",40);
strncpy(alpha[31].glines[7],"X-7500D01*",40);
strncpy(alpha[31].glines[8],"Y11250D01*",40);
strncpy(alpha[31].glines[9],"X7500D01*",40);
strncpy(alpha[31].glines[10],"M02*",40);
strncpy(alpha[31].glines[11],"",4);

strncpy(alpha[32].glines[0],"G54D548*",40);
strncpy(alpha[32].glines[1],"X-7500Y0D02*",40);
strncpy(alpha[32].glines[2],"X3750D01*",40);
strncpy(alpha[32].glines[3],"X7500Y-3750D01*",40);
strncpy(alpha[32].glines[4],"Y-7500D01*",40);
strncpy(alpha[32].glines[5],"X3750Y-11250D01*",40);
strncpy(alpha[32].glines[6],"X-3750D01*",40);
strncpy(alpha[32].glines[7],"X-7500Y-7500D01*",40);
strncpy(alpha[32].glines[8],"Y3750D01*",40);
strncpy(alpha[32].glines[9],"X0Y11250D01*",40);
strncpy(alpha[32].glines[10],"X3750D01*",40);
strncpy(alpha[32].glines[11],"M02*",40);
strncpy(alpha[32].glines[12],"",4);

strncpy(alpha[33].glines[0],"G54D548*",40);
strncpy(alpha[33].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[33].glines[2],"X7500D01*",40);
strncpy(alpha[33].glines[3],"X-3750Y-11250D01*",40);
strncpy(alpha[33].glines[4],"M02*",40);
strncpy(alpha[33].glines[5],"",4);

strncpy(alpha[34].glines[0],"G54D548*",40);
strncpy(alpha[34].glines[1],"X-3750Y-11250D02*",40);
strncpy(alpha[34].glines[2],"X-7500Y-7500D01*",40);
strncpy(alpha[34].glines[3],"Y-3750D01*",40);
strncpy(alpha[34].glines[4],"X-3750Y0D01*",40);
strncpy(alpha[34].glines[5],"X3750D01*",40);
strncpy(alpha[34].glines[6],"X7500Y3750D01*",40);
strncpy(alpha[34].glines[7],"Y7500D01*",40);
strncpy(alpha[34].glines[8],"X3750Y11250D01*",40);
strncpy(alpha[34].glines[9],"X-3750D01*",40);
strncpy(alpha[34].glines[10],"X-7500Y7500D01*",40);
strncpy(alpha[34].glines[11],"Y3750D01*",40);
strncpy(alpha[34].glines[12],"X-3750Y0D01*",40);
strncpy(alpha[34].glines[13],"X3750D02*",40);
strncpy(alpha[34].glines[14],"X7500Y-3750D01*",40);
strncpy(alpha[34].glines[15],"Y-7500D01*",40);
strncpy(alpha[34].glines[16],"X3750Y-11250D01*",40);
strncpy(alpha[34].glines[17],"X-3750D01*",40);
strncpy(alpha[34].glines[18],"M02*",40);
strncpy(alpha[34].glines[19],"",4);

strncpy(alpha[35].glines[0],"G54D548*",40);
strncpy(alpha[35].glines[1],"X-3750Y-11250D02*",40);
strncpy(alpha[35].glines[2],"X0D01*",40);
strncpy(alpha[35].glines[3],"X7500Y-3750D01*",40);
strncpy(alpha[35].glines[4],"Y7500D01*",40);
strncpy(alpha[35].glines[5],"X3750Y11250D01*",40);
strncpy(alpha[35].glines[6],"X-3750D01*",40);
strncpy(alpha[35].glines[7],"X-7500Y7500D01*",40);
strncpy(alpha[35].glines[8],"Y3750D01*",40);
strncpy(alpha[35].glines[9],"X-3750Y0D01*",40);
strncpy(alpha[35].glines[10],"X7500D01*",40);
strncpy(alpha[35].glines[11],"M02*",40);
strncpy(alpha[35].glines[12],"",4);

strncpy(alpha[36].glines[0],"G54D548*",40);       // amphersand
strncpy(alpha[36].glines[1],"X7500Y-3750D02*",40);
strncpy(alpha[36].glines[2],"X0Y-11250D01*",40);
strncpy(alpha[36].glines[3],"X-3750D01*",40);
strncpy(alpha[36].glines[4],"X-7500Y-7500D01*",40);
strncpy(alpha[36].glines[5],"Y-3750D01*",40);
strncpy(alpha[36].glines[6],"X0Y3750D01*",40);
strncpy(alpha[36].glines[7],"Y7500D01*",40);
strncpy(alpha[36].glines[8],"X-3750Y11250D01*",40);
strncpy(alpha[36].glines[9],"X-7500Y7500D01*",40);
strncpy(alpha[36].glines[10],"Y3750D01*",40);
strncpy(alpha[36].glines[11],"X7500Y-11250D01*",40);
strncpy(alpha[36].glines[12],"M02*",40);
strncpy(alpha[36].glines[13],"",4);

strncpy(alpha[37].glines[0],"G54D548*",40);         // bslash
strncpy(alpha[37].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[37].glines[2],"X7500Y-11250D01*",40);
strncpy(alpha[37].glines[3],"M02*",40);
strncpy(alpha[37].glines[4],"",4);

strncpy(alpha[38].glines[0],"G54D548*",40);           // comma
strncpy(alpha[38].glines[1],"X0Y-7500D02*",40);
strncpy(alpha[38].glines[2],"Y-11250D01*",40);
strncpy(alpha[38].glines[3],"X-3750Y-15000D01*",40);
strncpy(alpha[38].glines[4],"M02*",40);
strncpy(alpha[38].glines[5],"",4);

strncpy(alpha[39].glines[0],"G54D548*",40);       // copyright
strncpy(alpha[39].glines[1],"X4167Y-4167D02*",40);
strncpy(alpha[39].glines[2],"X2083Y-6250D01*",40);
strncpy(alpha[39].glines[3],"X-2083D01*",40);
strncpy(alpha[39].glines[4],"X-4167Y-4167D01*",40);
strncpy(alpha[39].glines[5],"Y4167D01*",40);
strncpy(alpha[39].glines[6],"X-2083Y6250D01*",40);
strncpy(alpha[39].glines[7],"X2083D01*",40);
strncpy(alpha[39].glines[8],"X4167Y4167D01*",40);
strncpy(alpha[39].glines[9],"G54D645*",40);
strncpy(alpha[39].glines[10],"X0Y0D03*",40);
strncpy(alpha[39].glines[11],"M02*",40);
strncpy(alpha[39].glines[12],"",4);

strncpy(alpha[40].glines[0],"G54D548*",40);         // dash
strncpy(alpha[40].glines[1],"X-7500Y0D02*",40);
strncpy(alpha[40].glines[2],"X7500D01*",40);
strncpy(alpha[40].glines[3],"M02*",40);
strncpy(alpha[40].glines[4],"",4);

strncpy(alpha[41].glines[0],"G54D548*",40);         // dot
strncpy(alpha[41].glines[1],"X3750Y-11250D02*",40);
strncpy(alpha[41].glines[2],"Y-6250D01*",40);
strncpy(alpha[41].glines[3],"M02*",40);
strncpy(alpha[41].glines[4],"",4);

strncpy(alpha[42].glines[0],"G54D548*",40);            // forward slash
strncpy(alpha[42].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[42].glines[2],"X7500Y11250D01*",40);
strncpy(alpha[42].glines[3],"M02*",40);    
strncpy(alpha[42].glines[4],"",4);      

}  // end init_alpha_glines

void init_alpha_char()
{
	alpha[0].gchar = 'A';
	alpha[1].gchar = 'B';
	alpha[2].gchar = 'C';
	alpha[3].gchar = 'D';
	alpha[4].gchar = 'E';
	alpha[5].gchar = 'F';
    alpha[6].gchar = 'G';
    alpha[7].gchar = 'H'; 
    alpha[8].gchar = 'I';
    alpha[9].gchar = 'J';
    alpha[10].gchar ='K';
    alpha[11].gchar ='L'; 
    alpha[12].gchar ='M';
    alpha[13].gchar ='N';
    alpha[14].gchar ='O';
    alpha[15].gchar ='P'; 
    alpha[16].gchar ='Q';
    alpha[17].gchar ='R'; 
    alpha[18].gchar ='S'; 
    alpha[19].gchar ='T';
    alpha[20].gchar ='U';
    alpha[21].gchar ='V';
	alpha[22].gchar ='W';
	alpha[23].gchar ='X';
	alpha[24].gchar ='Y';
    alpha[25].gchar ='Z';
    alpha[26].gchar ='0';
    alpha[27].gchar ='1';
    alpha[28].gchar ='2'; 
    alpha[29].gchar ='3';
    alpha[30].gchar ='4';
    alpha[31].gchar ='5';
    alpha[32].gchar ='6';
    alpha[33].gchar ='7';
    alpha[34].gchar ='8';
    alpha[35].gchar ='9';
    alpha[36].gchar ='&';
    alpha[37].gchar ='\\';
    alpha[38].gchar =',';
    alpha[39].gchar ='@';
    alpha[40].gchar ='.';
    alpha[41].gchar ='-';
    alpha[42].gchar ='/';

}  // end init_alpha_char

void placestandard_file( double x, double y, FILE *ofile)
{
int ii;
char a[10][40];
char b[10][40];
char c[10][40];
char d[10][40];
int val;
char X[40];
char Y[40];
double xval;
double yval;
int xint;
int yint;


  // printf("In placestandard\n");

   ii = 0;

  while ( strlen(glines[ii]) > 0){
    if (( strstr(glines[ii],"X") != NULL) && ( strstr(glines[ii],"Y")!= NULL)
		 && ( strstr(glines[ii],"G54") == NULL))
	{
       split(glines[ii],a[0],a[1],"Y");
       split(glines[ii],d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y);
	   xval=atof(X);
	   yval=atof(Y);
       xval=xval + x;
       yval=yval + y;
	   xint=(int)(xval);
	   yint=(int)(yval);
       fprintf(ofile,"G01X%dY%dD%s\n",xint,yint,d[1]);
    }
    else if( (strstr(glines[ii],"Y") == NULL) && (strstr(glines[ii],"X") != NULL))
	{
      split(glines[ii],b[0],b[1],"X");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
	  xval=atof(X);
	  xval=xval+x;
	  xint=(int) (xval);
      fprintf(ofile,"G01X%dD%s\n", xint,d[1]);
    }
    else if(( strstr(glines[ii],"Y") != NULL) && (strstr(glines[ii],"X") == NULL))
	{
      split(glines[ii],c[0],c[1],"Y");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4, Y);
	  yval=atof(Y);
	  yval=yval+y;
	  yint=(int ) (yval);
      fprintf(ofile,"G01Y%dD%s\n",yint,d[1]);
    }
    else if( strstr(glines[ii],"M0")==NULL)
	{
      fprintf(ofile,"%s\n",glines[ii]); 
    }
	ii += 1;
  }
  
}

void placestandard( double x, double y)
{
int ii;
char a[10][40];
char b[10][40];
char c[10][40];
char d[10][40];
int val;
char X[40];
char Y[40];
double xval;
double yval;
int xint;
int yint;


  // printf("In placestandard\n");

   ii = 0;

  while ( strlen(glines[ii]) > 0){
    if (( strstr(glines[ii],"X") != NULL) && ( strstr(glines[ii],"Y")!= NULL)
		 && ( strstr(glines[ii],"G54") == NULL))
	{
       split(glines[ii],a[0],a[1],"Y");
       split(glines[ii],d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y);
	   xval=atof(X);
	   yval=atof(Y);
       xval=xval + x;
       yval=yval + y;
	   xint=(int)(xval);
	   yint=(int)(yval);
       printf("G01X%dY%dD%s\n",xint,yint,d[1]);
    }
    else if( (strstr(glines[ii],"Y") == NULL) && (strstr(glines[ii],"X") != NULL))
	{
      split(glines[ii],b[0],b[1],"X");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
	  xval=atof(X);
	  xval=xval+x;
	  xint=(int) (xval);
      printf("G01X%dD%s\n", xint,d[1]);
    }
    else if(( strstr(glines[ii],"Y") != NULL) && (strstr(glines[ii],"X") == NULL))
	{
      split(glines[ii],c[0],c[1],"Y");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4, Y);
	  yval=atof(Y);
	  yval=yval+y;
	  yint=(int ) (yval);
      printf("G01Y%dD%s\n",yint,d[1]);
    }
    else if( strstr(glines[ii],"M0")==NULL)
	{
      printf("%s\n",glines[ii]); 
    }
	ii += 1;
  }
  
}

void parsetext( double myX, double myY, char *instring)
{
int len;
int i;
 int arrayindex;
int j;
char letter;

  len = strlen(instring);
  for( i = 0 ; i < len; i++)
   {
      letter = toupper( instring[i]);

	  // printf("Letter= %c , %d \n",letter,letter);
      arrayindex = -1;
      if( isalpha(letter))
      {
	arrayindex = letter - 'A';
      }
      if( isdigit(letter) )
       {
	 arrayindex = 26 + letter - '0';
      }
      if (letter == '&' )  // ampersand
       {
         arrayindex=36;
       }
      if (letter == '\\')  // backslash
       {
         arrayindex=37;
       }
      if (letter == ',' )   // comma
       {
         arrayindex=38;
       }
      if (letter == '@' )  // copyright
       {
         arrayindex=39;
       }
      if ( letter == '-')   //dash 
      {
  	     arrayindex=40;
      }
      if (letter == '.' )  //dot
       {
         arrayindex=41;
       }
      if (letter == '/' )  // forward slash
       {
         arrayindex=42;
       }
      if ( arrayindex > -1)
      {
        if (arrayindex < 43)
		{
		  for(j=0; j < 40; j += 1)
		  {
			  strncpy(glines[j],"",4);
		  }
          j= 0;
	      while( strlen(alpha[arrayindex].glines[j]) > 0 )
          {
		        strncpy(glines[j],alpha[arrayindex].glines[j],40);
                j += 1;
		  }
            placestandard( myX, myY);  // uses glines
			myX= myX + 2.54 * mult;
        }
        else
		{
            printf("Internal error \n");
		}
      }
     else
      {
	printf("letter not in printable set = %c  =%d \n",letter,letter);
      }
        
  }

}  // end parsetext

void parsetext_file( double myX, double myY, char *instring, FILE *ofile)
{
int len;
int i;
 int arrayindex;
int j;
char letter;

  len = strlen(instring);
  for( i = 0 ; i < len; i++)
   {
      letter = toupper( instring[i]);

	  // printf("Letter= %c , %d \n",letter,letter);
      arrayindex = -1;
      if( isalpha(letter))
      {
	arrayindex = letter - 'A';
      }
      if( isdigit(letter) )
       {
	 arrayindex = 26 + letter - '0';
      }
      if (letter == '&' )  // ampersand
       {
         arrayindex=36;
       }
      if (letter == '\\')  // backslash
       {
         arrayindex=37;
       }
      if (letter == ',' )   // comma
       {
         arrayindex=38;
       }
      if (letter == '@' )  // copyright
       {
         arrayindex=39;
       }
      if ( letter == '-')   //dash 
      {
  	     arrayindex=40;
      }
      if (letter == '.' )  //dot
       {
         arrayindex=41;
       }
      if (letter == '/' )  // forward slash
       {
         arrayindex=42;
       }
      if ( arrayindex > -1)
      {
        if (arrayindex < 43)
		{
		  for(j=0; j < 40; j += 1)
		  {
			  strncpy(glines[j],"",4);
		  }
          j= 0;
	      while( strlen(alpha[arrayindex].glines[j]) > 0 )
          {
		        strncpy(glines[j],alpha[arrayindex].glines[j],40);
                j += 1;
		  }
            placestandard_file( myX, myY, ofile);  // uses glines
			myX= myX + 2.54 * mult;
        }
        else
		{
            printf("Internal error \n");
		}
      }
     else
      {
	printf("letter not in printable set = %c  =%d \n",letter,letter);
      }
        
  }

}  // end parsetext_file

int placetext_call_out( char *infilestr, char *outfilestr)
{
FILE *infile;
FILE *outfile;
int endoffile;
int nf;

    infile=fopen(infilestr,"r");

	if (infile == NULL)
	{
		printf("In placetext, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

    outfile=fopen(outfilestr,"w");

	if (outfile == NULL)
	{
		printf("In placetext, unable to open the output file = %s \n",outfilestr);
		exit(-1);
	}

	init_alpha_glines();

	// printf("Init complete \n");

    

	endoffile = getline(infile,thisline);
	nf=split_line(thisline);

    mult =  pow(10,atoi(str_array[0])); 
 

    endoffile = getline(infile,thisline);
    nf = split_line(thisline);

    while(endoffile==FALSE)
     {
	   // printf("nf=%d\n",nf);
      if( nf == 3)
	  {
	   xtemp=atof(str_array[0]);
       ytemp=atof(str_array[1]);
       parsetext_file(xtemp * mult, ytemp * mult, str_array[2], outfile);
       }
      else 
       {
       xtemp = atof(str_array[0]);
       ytemp = atof(str_array[1]);

       X1 = xtemp * mult;
       count = nf;    // NF is change by function placestandard
       // strncpy(thisword,thisline,120);
	   
       parsetext_file(xtemp * mult, ytemp * mult, str_array[2],outfile);
      // $0 = word
       for( loopcnt = 4 ; loopcnt <= count; loopcnt++)
	   {
            tmp = loopcnt - 1;
	        X1 +=   (strlen(str_array[tmp-1]) + 1)*(2.54 * mult);
            parsetext_file(X1, ytemp * mult, str_array[loopcnt-1],outfile);
          // $0 = word
         }
      }
    endoffile=getline(infile,thisline);
    nf=split_line(thisline);
     }

    fclose(infile);

    fclose(outfile);
    return(0);

}  // placetext_call

int placetext_call( char *infilestr)
{
FILE *infile;
int endoffile;
int nf;

    infile=fopen(infilestr,"r");

	if (infile == NULL)
	{
		printf("In placetext, unable to open the input file = %s \n",infilestr);
		exit(-1);
	}

    
	init_alpha_glines();

	// printf("Init complete \n");

    

	endoffile = getline(infile,thisline);
	nf=split_line(thisline);

    mult =  pow(10,atoi(str_array[0])); 
 

    endoffile = getline(infile,thisline);
    nf = split_line(thisline);

    while(endoffile==FALSE)
     {
	   // printf("nf=%d\n",nf);
      if( nf == 3)
	  {
	   xtemp=atof(str_array[0]);
       ytemp=atof(str_array[1]);
       parsetext(xtemp * mult, ytemp * mult, str_array[2]);
       }
      else 
       {
       xtemp = atof(str_array[0]);
       ytemp = atof(str_array[1]);

       X1 = xtemp * mult;
       count = nf;    // NF is change by function placestandard
       // strncpy(thisword,thisline,120);
	   
       parsetext(xtemp * mult, ytemp * mult, str_array[2]);
      // $0 = word
       for( loopcnt = 4 ; loopcnt <= count; loopcnt++)
	   {
            tmp = loopcnt - 1;
	        X1 +=   (strlen(str_array[tmp-1]) + 1)*(2.54 * mult);
            parsetext(X1, ytemp * mult, str_array[loopcnt-1]);
          // $0 = word
         }
      }
    endoffile=getline(infile,thisline);
    nf=split_line(thisline);
     }

    fclose(infile);

    return(0);

}  // placetext_call


int main( int argc, char **argv)
{
int tint;

   tint = placetext_call( argv[1]);


}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

char thisline[200];
char str_array[120][120];
int endoffile;

double tx[100000];
double ty[100000];

#include "utilprogs.c"

// check to see if in rectangle defined by XBOT, YBOT, XTOP and YTOP
//     augmented in size by 1/2 the width of the hole
//
int  notinpoly( int a, int b, double XBOT, double YBOT, double XTOP, double YTOP, double inhole) 
{
int VAL;

     VAL = 0;
     if(( a < (int)(XBOT - inhole/2) ) || (a > (int)(XTOP + inhole/2)) || 
		 (b < (int)(YBOT - inhole/2) ) || (b > (int)(YTOP  + inhole/2)) )
	 {
	   VAL = 1;
     }
	 return(VAL);
}

//
//  placethiev4_call  controlfile mult kerf cfile=regcoords partcoords
//

int placethiev4_call( char *controlfilestr, char *multstr, char *kerfstr,
					  char *cfilestr, char *partcoordfile) 
{
int cnt;
int tcnt;
int exitvalue;

double SPACE;
double PANELSIZE ;
double PLACE;
int placeval;
double XOFF;
double YOFF;
double HOLE;   
double TEST ;
double PCMSIZE;
double XHIGH;
double XHIGH1;
double YHIGH;
double YHIGH1;
double XLOW;
double XLOW1;
double YLOW;
double YLOW1;
double KERF;
int XoddStart;
int YoddStart;
int XoddStop;
int YoddStop;
int XevenStart;
int YevenStart;
int XevenStop;
int YevenStop;
double xsize;
double ysize;
FILE *evengbrfile;
FILE *oddgbrfile;
FILE *thievfile;
FILE *cfile;
double value;
double txmax;
double txmin;
double tymax;
double tymin;
int mult;
int polyval;
double Xdiff;
double Ydiff;
double powerval;
double a[20];
FILE *file1,*file2;
int nf;
int t;
int i,j;

       mult=atoi(multstr);
	  // printf("mult = %d \n",mult);

	   KERF=atof(kerfstr);
     //  printf("KERF = %f \n",KERF);

       cnt = 0;
       //file1 is offval
	   file1 = fopen(controlfilestr,"r");

	   if ( file1 == NULL)
	   {
		   printf("In placethiev4, unable to open the input file = %s \n", controlfilestr);
		   exit(-1);
	   }

       cfile = fopen(cfilestr,"r");  // regcoords file
	   if ( cfile == NULL)
	   {
		   printf("In placethiev4, unable to open the input file = %s \n", cfilestr);
		   exit(-1);
	   }

       file2 = fopen(partcoordfile,"r");
	   if ( file2 == NULL)
	   {
		   printf("In placethiev4, unable to open the input file = %s \n", partcoordfile);
		   exit(-1);
	   }

	   endoffile=getline(file1,thisline);
	   nf=split_line(thisline);

       while (endoffile==FALSE)
	   {
	     a[cnt] = atof(str_array[0]); // $1
         cnt++;
		 endoffile=getline(file1,thisline);
		 nf=split_line(thisline);

       } 
	   fclose(file1);

	 
       xsize = (a[1] - a[0]);
       ysize = (a[3] - a[2]);
      
	   // printf("xsize=%f ysize = %f\n",xsize,ysize);
	   
       tcnt = 0;
	   endoffile=getline(cfile,thisline);
	   nf=split_line(thisline);

       while (endoffile==FALSE)    //regcoords
	   {
         tx[tcnt] = atof(str_array[0]); // $1;
	     ty[tcnt] = atof(str_array[1]); // $2;
	     tcnt++;
		 endoffile=getline(cfile,thisline);
		 nf=split_line(thisline);
       } 

	   fclose(cfile);

       txmax = -5000000;
       txmin =  5000000;
       tymax = -5000000;
       tymin =  5000000;

	   t=0;
       while( t < tcnt)
	   {
	    if(tx[t] > txmax)
		{
	     txmax = tx[t];
         }
	    else if (tx[t] < txmin)
		{
	     txmin = tx[t];
         }   
		t++;
       }

	   t=0;
       while( t < tcnt )
	   {
	    if(ty[t] > tymax)
		{
	     tymax = ty[t];
         }
	    else if (ty[t] < tymin)
		{
	     tymin = ty[t];
         }   
		t++;
       }  

       //print "txmax = " txmax | "cat 1>&2"
       //print "txmin = " txmin | "cat 1>&2"
       //print "tymax = " tymax | "cat 1>&2"
       //print "tymin = " tymin | "cat 1>&2"

     SPACE = 4;
     PANELSIZE =  304.8;
     XOFF = -152.4;
     YOFF = -152.4;
     PLACE = 2.54;
     HOLE = 2.2;   // hole size of 2mm + .1 mm buffer (.2/2 = .1)
     TEST = 2;
     PCMSIZE = 2;

   // mult is a passed in parameter if not defined then set to 4

      if( mult <= 0)
	  {
	  mult = 4;
	  }
      powerval=pow(10,mult);

       PLACE = PLACE * powerval;  // 25,400
	   placeval=(int ) PLACE;

       HOLE = HOLE * powerval;
       PANELSIZE = PANELSIZE * powerval;
       PCMSIZE = PCMSIZE * powerval;
// KERF is passed in parameter if not set will be 0
       KERF = KERF * powerval;
       TEST = TEST * powerval;
       SPACE = SPACE * powerval;
       printf( "KERF = (placethiev) %f\n", KERF);
       XOFF = XOFF * powerval; // 10 **  mult
       YOFF = YOFF * powerval;


   if ( PCMSIZE > TEST )
   {
      value = PCMSIZE / 2;
   }
   else
   {
      value = TEST / 2;
   }
   
//   print "value = " value  | "cat 1>&2"
 //  printf("value=%f\n",value);

   // read in first line 

   endoffile=getline(file2,thisline);
   nf=split_line(thisline);

   XLOW = atof(str_array[0]) - (KERF/2) - (xsize/2) - value;
   YLOW = atof(str_array[1]) - (KERF/2) - (ysize/2) - value;
   
   XevenStart  = -1511300 ;  // -15240000 + 12700
   XevenStop   =  1511300 ;   // 15240000 - 12700

   YevenStart  = -1511300 ;
   YevenStop   =  1511300 ;

   XoddStart = -1498600;     // -15240000 + 241400
   XoddStop  =  1498600;     // 15240000 - 241400

   YoddStart = -1498600;
   YoddStop  =  1498600;

// do nothing here 
// just read in all the lines
// XHIGH and YHIGH in "END" below are based on last line read 
// if there is only one part the $1 and $2 are from getline above in BEGIN

   while(endoffile==FALSE)
   {
	 nf=split_line(thisline);
     endoffile=getline(file2,thisline);
     // nf=split_line(thisline);
   }



   fclose(file2);

  evengbrfile=fopen("even.gbr","w");
  oddgbrfile=fopen("odd.gbr","w");
  thievfile=fopen("thievout.gbr","w");

  exitvalue = 0;
  // printf("lastline = %s %s  KERF/2 = %f xsize/2=%f value = %f\n",str_array[0],str_array[1],
	//              KERF/2, xsize/2, value);

  XHIGH = atof(str_array[0]) + (KERF/2) + (xsize/2)  + value;  // last line of partcoords
  YHIGH = atof(str_array[1]) + (KERF/2) + (ysize/2)  + value;


 //     print "xoff " XOFF 
 //     printf("%d %d %d %d\n", XLOW, YLOW, XHIGH, YHIGH) | "cat 1>&2" 

      fprintf(thievfile, "G54D252*\n" ); // >"thievout.gbr"
      fprintf(thievfile,"X%0.0fY%0.0fD02*\n",XLOW,YLOW); //  >   "thievout.gbr"
      fprintf(thievfile,"X%0.0fY%0.0fD01*\n",XLOW,YHIGH); // >   "thievout.gbr"
      fprintf(thievfile,"X%0.0fY%0.0fD01*\n",XHIGH,YHIGH); // >   "thievout.gbr"
      fprintf(thievfile,"X%0.0fY%0.0fD01*\n",XHIGH,YLOW); // >   "thievout.gbr"
      fprintf(thievfile,"X%0.0fY%0.0fD01*\n",XLOW,YLOW); // >   "thievout.gbr"
      Xdiff = (XOFF * (-1)) - XHIGH;
      Ydiff = (YOFF * (-1)) - YHIGH ;

    //  printf("%d %d \n", Xdiff, Ydiff) | "cat 1>&2" 

      if( ( Xdiff  > 11000) || ( Ydiff  > 11000 ) )

	  { 
     
      //  printf(" if in place worked%d %d \n", Xdiff, Ydiff) | "cat 1>&2" 

        fprintf(evengbrfile, "G54D524*\n"); // >"even.gbr"
        fprintf(oddgbrfile, "G54D524*\n"); // >"odd.gbr"

        for( i = XevenStart ; i <= XevenStop   ; i += placeval )
		{
          for( j = YevenStart ; j <= YevenStop  ; j += placeval )
		  {
	       YLOW1 = YLOW;
	       YHIGH1 = YHIGH;
	       XLOW1 = XLOW;
	       XHIGH1 = XHIGH;
		   t=0;
	       while(t < tcnt)
		   {
	        if(  ( (tx[t] - SPACE) < i) && (i < (tx[t] + SPACE)))
			{
                   YLOW1 =  YLOW - 20000;
		           YHIGH1 =  YHIGH + 20000;
             }
			t++;
          }
		  t=0;
	      while(t < tcnt)
		  {
	        if( (  (ty[t] - SPACE ) < j ) && ( j < (ty[t] + SPACE)) )
			{
               XLOW1 =  XLOW - 20000;
		       XHIGH1 =  XHIGH + 20000;
            }
		   t++;
		  }
		  
	      polyval = notinpoly( i,j,XLOW1,YLOW1,XHIGH1,YHIGH1,HOLE);

		 // printf("HOLE = %f YHIGH1 = %f i=%d j=%d polyval=%d \n",HOLE,YHIGH1,i,j,polyval);

	      if( polyval == 1 )
		   {
	  	    fprintf(evengbrfile,"X%dY%dD03*\n",i,j); //  > "even.gbr"
            }
          }
        }

        for( i = XoddStart ; i <= XoddStop  ; i += placeval )
		{
          for( j = YoddStart ; j <= YoddStop  ; j += placeval  )
		  {
	       YLOW1 = YLOW;
	       YHIGH1 = YHIGH;
	       XLOW1 = XLOW;
	       XHIGH1 = XHIGH;
		   t=0;
	       while(t < tcnt)
		   {
	        if(  ( (tx[t] - SPACE) < i) && (i < (tx[t] + SPACE) ))
			{
              YLOW1 =  YLOW - 20000;
		      YHIGH1 =  YHIGH + 20000;
             }
			 t++;
            }
		   t=0;
	       while(t < tcnt )
		   {
	        if((  (ty[t] - SPACE )< j )&& (j < (ty[t] + SPACE)) )
			{
             XLOW1 =  XLOW - 20000;
		     XHIGH1 =  XHIGH + 20000;
            }
		   t++;
		   }
	       polyval = notinpoly( i,j,XLOW1,YLOW1,XHIGH1,YHIGH1,HOLE);
	       if( polyval == 1 )
		   {
		    fprintf(oddgbrfile,"X%dY%dD03*\n",i,j); //  > "odd.gbr"
           }

		  } //for j
		}         // for i
     } 

    if( ( Xdiff  > 11000) && ( Ydiff > 11000 ) )
	 { 
	  exitvalue = 1;
     }
    else if( Xdiff  > 11000)
	 {
	  exitvalue = 3;
     }
    else if( Ydiff  > 11000 )
	{
	  exitvalue = 2;
     }
  //   printf "exitvalue " exitvalue | "cat 1>&2" 

	 fclose(evengbrfile);
	 fclose(oddgbrfile);
	 fclose(thievfile);
     return(exitvalue);
}

int main( int argc, char **argv)
{
int retval;

  retval=placethiev4_call( argv[1], argv[2], argv[3], argv[4],argv[5]);
  exit(retval);

}
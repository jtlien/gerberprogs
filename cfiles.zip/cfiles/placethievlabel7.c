#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

char thisline[200];
char str_array[120][120];
int endoffile;

int OFFSET;
int MINSPACE;
int SPACE;
int ADJUST;
int xcnt;
int xcnt1;
int ycnt;
FILE *file1;
FILE *file2;
FILE *oddgbrfile;
FILE *evengbrfile;

int nf;
int st1val;
int st0val;

int xarray1[100000];
int xarray[100000];
int yarray[100000];

// Split the line int fields

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} 

//! /usr/local/bin/gawk -f
//  difference from placethiev5 is X start & stop coordinates

void  sortA( int *myarray, int mycnt )
{
  int p;
  int q;
  int temp;

     for( p = 0 ; p < mycnt; p++){
	for ( q = 0 ; q < mycnt-1; q++){
	  if( myarray[q] > myarray[q+1]){
	    temp = myarray[q];
	    myarray[q] = myarray[q+1];
	    myarray[q+1] = temp;
           }
        }
     }
}

// place a horizontal row , spaced by OFFSET (25400)
//
void placehoriz(int start , int stop,int  y , FILE *ofile)
{
  int j;
  int i;

  j = 0;
  i = start;
  while( i <= stop  )
    {
     if(( i < xarray[j] - MINSPACE) || (i > xarray[xcnt- 1]+ MINSPACE))
      {
		// printf("i,y = %d %d \n",i,y);

	    fprintf(ofile,"X%dY%dD03*\n",i,y);  //  > filename	
	    i += OFFSET;
            // printf("%d %d %d \n", i,j, xarray[j])  | "cat 1>&2"
      }
     else
        {
	    while( i <= xarray[j] + MINSPACE)
             {
	       i += OFFSET;
	    }
	    j++;
        }
     }
  //  printf("end of func%d %d %d \n", i,j, stop)  | "cat 1>&2"

}  // placehoriz

// *** rev 6 changed to allow for barcode
//  Place horizontal row, if y is negative, skip region between -470000 and 470000

void  placehoriz1(int  start , int stop, int y , FILE *ofile)
{
  int i;
  int j;

  j = 0;
  i = start;

       // print "Start = " start  "  Stop = " stop  | "cat 1>&2"

     while( i <= stop  )
      {
	  if( (i < -470000) || (i > 470000) || (y > 0))
      {
	       fprintf(ofile,"X%dY%dD03*\n",i,y);   //    > filename	
	       i += OFFSET;
      }
	  else
      {
	    i += OFFSET; 
	  }
     }
     //    printf("end of func%d %d %d \n", i,j, stop)  | "cat 1>&2"
}

// place a vertical column at x

void placevert(int  start ,int  stop, int x , FILE *ofile)
{

  int i;
  int j;

  j = 0;
  i = start;

 
  while( i <= stop  )
    {
	 if( (i < yarray[j] - MINSPACE) ||( i > yarray[ycnt - 1]+ MINSPACE))
	 {
         if( (i < -290000)  || (i > 265000 ))
             {
	          fprintf(ofile,"X%dY%dD03*\n",x,i);   //   > filename	
             }
	     i += OFFSET;
	     // printf("%d %d %d \n", i,j, yarray[j])  | "cat 1>&2"
         }
	 else
	 {
	    while( i <= yarray[j] + MINSPACE)
		{
	      i += OFFSET; 
	    }
	    j++;
        }
     }
     //   printf("end of func%d %d %d \n", i,j, stop)  | "cat 1>&2"
}

void placethievlabel7_call(char *file1str, char *file2str, char *spacestr) 
{
  OFFSET = 25400;
  MINSPACE = 40000;
  ADJUST = 177800;
  xcnt = 0;
  ycnt = 0;
  
  SPACE=atoi(spacestr);

  file1=fopen( file1str,"r");
  if (file1 == NULL)
  {
	  printf("In placethievlabel7, unable to open the input file = %s \n",file1str);
	  exit(-1);
  }

  file2=fopen( file2str,"r");
  if (file2 == NULL)
  {
	  printf("In placethievlabel7, unable to open the input file = %s \n",file2str);
	  exit(-1);
  }
  endoffile = getline(file1,thisline);  // read in the labelcoords file
                                        // these are the coordinants from
                                        // the partcoords that are on the left and bottom
                                        // of the array

  while (endoffile==FALSE) 
  { // file1 = labelcoords
       if( strcmp(str_array[0],"X") == 0 )
	   {
	     xarray[xcnt] = atoi(str_array[1]);    // gets data from file1 & file2
	     xarray1[xcnt] = atoi(str_array[1]);   // gets data from file1 only
	     xcnt++;
       }
       if(strcmp(str_array[0],"Y") == 0 )
	   {
	    yarray[ycnt] = atoi(str_array[1]);  // $2
	    ycnt++;
       }
      endoffile=getline(file1,thisline);
	  nf=split_line(thisline);

     }
     fclose(file1);

    xcnt1 = xcnt;

      endoffile=getline(file2,thisline);   // mycoords file
	                                       // add the ones outfile of X -1490000 to 1490000
	                                       //                      or Y -1490000 to 1490000
	  nf=split_line(thisline);

     while (endoffile == FALSE)
	 {  // file2 = testcoords + punchcoords
		 st0val=atoi(str_array[0]);
		 st1val=atoi(str_array[1]);
	    if( (st0val <= -1490000 )|| (st0val >= 1490000))
		{ 
	      yarray[ycnt++] = atoi(str_array[1]);  // $2
        }
	    if( (st1val <= -1490000) || (st1val >= 1490000))
		{
	      xarray[xcnt++] = atoi(str_array[0]); //  $1
        }
	  endoffile=getline(file2,thisline);
	  nf=split_line(thisline);

     }
	 fclose(file2);

//
//	 printf("Made it to sort \n");

     sortA(xarray, xcnt);     

	 //printf("Made it past first sort \n");

     sortA(yarray, ycnt);

   // printf("Made it past second sort \n");

     oddgbrfile=fopen("odd1.gbr","w");

	 if (oddgbrfile == NULL)
	 {
		 printf("In placethievlabel7, unable to open the output file = odd1.gbr \n");
		 exit(-1);
	 }
     evengbrfile=fopen("even1.gbr","w");
     if (evengbrfile == NULL)
	 {
		 printf("In placethievlabel7, unable to open the output file = even1.gbr \n");
		 exit(-1);
	 }

    // printf("Made it past files open\n");

     // printf("x,y cnt %d %d  \n", xcnt,ycnt)  | "cat 1>&2"

     // place thieving dots on the even layer avoiding text

     fprintf(evengbrfile, "G54D524*\n"); //  >"even1.gbr"  D524 is 2 mm THIEVDOT
	 //fclose(evengbrfile);

       placehoriz(-1511300, 1511300, -1536700, evengbrfile );
    placehoriz1(-1485900, 1485900, -1562100, evengbrfile );
    placehoriz1(-1485900, 1485900, -1587500, evengbrfile );
    placehoriz(-1511300, 1511300, 1536700, evengbrfile );
    placehoriz1(-1485900, 1485900, 1562100, evengbrfile );
    placehoriz1(-1485900, 1485900, 1587500, evengbrfile );

    placevert(-1308100, 1308100 ,  1536700 , evengbrfile );
    placevert(-1308100, 1308100 , -1536700 , evengbrfile );

    
    // place thieving dots on the odd layer avoiding text

    fprintf(oddgbrfile, "G54D524*\n" );
  //  fclose(oddgbrfile);

    placehoriz1(-1473200, 1473200, -1600200, oddgbrfile );
    placehoriz1(-1473200, 1473200, -1574800, oddgbrfile );
    placehoriz( -1473200, 1473200, -1549400, oddgbrfile );
    placehoriz1(-1473200, 1473200, 1600200, oddgbrfile );
    placehoriz1(-1473200, 1473200, 1574800, oddgbrfile );
    placehoriz( -1473200, 1473200, 1549400, oddgbrfile );
    placevert( -1295400 ,1295400 , 1549400, oddgbrfile );
    placevert( -1295400,1295400, -1549400, oddgbrfile );

    // the following 4 lines place thieving dots that overlap the active area
    // and are only executed if space is available
   //  printf("SPACE = %d  \n", SPACE)  | "cat 1>&2"
    if( (SPACE == 1 ) || (SPACE == 2) )  // Y has space
	{
      placehoriz(-1498600, 1498600, -1524000, oddgbrfile );
      placehoriz(-1498600, 1498600,  1524000, oddgbrfile );
    }
    if( (SPACE == 1) || (SPACE == 3) )    // X has space
	{
      placevert( -1295400 , 1295400, 1524000, oddgbrfile );
      placevert( -1295400, 1295400, -1524000, oddgbrfile );
    }

	fclose(oddgbrfile);
	fclose(evengbrfile);
}

int main( int argc, char **argv)
{

	placethievlabel7_call( argv[1], argv[2], argv[3]);

}
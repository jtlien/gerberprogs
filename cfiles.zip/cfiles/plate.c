
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"



void plate_call_out(char *infilestr,char *commandstr, char *outfilestr)
{
int i;
int scale;
double dx;
double dy;
int nx;
int ny;
double lx;
double ly;
int top_y;
int bot_y;
int left_x;
int right_x;
int endoffile;
FILE *file1;
FILE *outfile;
int nf;
char thisline[300];

 scale=10000;

   file1 = fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

   outfile= fopen(outfilestr,"w");
   if (outfile==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",outfilestr);
	   exit(-1);
   }
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    if ((strcmp(str_array[0],"Xstep")==0) && (strcmp(str_array[3],"Ystep")==0))
	{
     dx = atof(str_array[2])*scale;
     dy = atof(str_array[5])*scale;
	}
    if (dx == 0)
     dx = 1532500*2;
    if (dy == 0)
     dy = 1532500*2;

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"Xnum")==0) && ( strcmp(str_array[3],"Ynum")==0))
	{                                        //$1 == "Xnum") && ($4 == "Ynum")){
    nx = atoi(str_array[2]); // $3
    ny = atoi(str_array[5]); // $6
	}
    endoffile=getline(file1,thisline);
    endoffile=getline(file1,thisline); // getline
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"X")==0) && (strcmp(str_array[3],"Y")==0)) 
	{
    lx = atoi(str_array[2])*scale - dx/2;
    ly = atoi(str_array[5])*scale - dy/2;
	}
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
   }

 fclose(file1);

 fprintf(outfile,"G54D299*\n");

 fprintf(outfile,"X-1532500Y-1532500D02*\n");
 fprintf(outfile,"X1532500Y-1532500D01*\n");
 fprintf(outfile,"X1532500Y1532500D01*\n");
 fprintf(outfile,"X-1532500Y1532500D01*\n");
 fprintf(outfile,"X-1532500Y-1532500D01*\n");

 fprintf(outfile,"X-1700000Y1300000D02*\n");
 fprintf(outfile,"X-1532500Y1300000D01*\n");
 fprintf(outfile,"X-1700000Y450000D02*\n");
 fprintf(outfile,"X-1532500Y450000D01*\n");
 fprintf(outfile,"X-1700000Y-1300000D02*\n");
 fprintf(outfile,"X-1532500Y-1300000D01*\n");
 fprintf(outfile,"X-1700000Y-450000D02*\n");
 fprintf(outfile,"X-1532500Y-450000D01*\n");
 fprintf(outfile,"X1700000Y1300000D02*\n");
 fprintf(outfile,"X1532500Y1300000D01*\n");
 fprintf(outfile,"X1700000Y450000D02*\n");
 fprintf(outfile,"X1532500Y450000D01*\n");
 fprintf(outfile,"X1700000Y-1300000D02*\n");
 fprintf(outfile,"X1532500Y-1300000D01*\n");
 fprintf(outfile,"X1700000Y-450000D02*\n");
 fprintf(outfile,"X1532500Y-450000D01*\n");


 bot_y = (int) ly;
 top_y = (int) (ly + (ny * dy));

 left_x = (int) lx;
 right_x = (int) ( lx + ( nx * dx)) ;

 fprintf(outfile,"G54D298*\n");
 for (i = 1; i <= nx+1; i++) 
 {
	 if ( strstr(commandstr,"b") == NULL)
	 {
	  fprintf(outfile,"X%dY-1532500D02*\n", (int) ( lx+(i-1)*dx) ) ;  //
	 }
	 else
	 { 
	  fprintf(outfile,"X%dY%dD02*\n", (int) ( lx+(i-1)*dx ) ,bot_y);  // 
	 }

	 if (strstr(commandstr,"t") == NULL)
	 {
      fprintf(outfile,"X%dY+1532500D01*\n", (int) (lx+(i-1)*dx) );
	 }
	 else
	 {
      fprintf(outfile,"X%dY%dD01*\n", ( int) ( lx+(i-1)*dx ),top_y);  // 
	 }
   
 }
 for (i = 1; i <= ny+1; i++) 
 {
	 if (strstr(commandstr,"l") == NULL)
	 {
      fprintf(outfile,"X-1532500Y%dD02*\n", (int) ( ly+(i-1)*dy)) ;
	 }
	 else
	 {
		fprintf(outfile,"X%dY%dD02*\n", left_x, (int) ( ly + (i-1)*dy) );
	 }

	 if (strstr(commandstr,"r") == NULL)
	 {
      fprintf(outfile,"X1532500Y%dD01*\n", (int) ( ly+(i-1)*dy) );
	 }
	 else
	 {
		 fprintf(outfile,"X%dY%dD01*\n", right_x, (int) ( ly+(i-1)*dy) );
	 }

 }
 
 fclose(outfile);

}  // end plate_call_out

void plate_call(char *infilestr,char *commandstr)
{
int i;
int scale;
double dx;
double dy;
int nx;
int ny;
double lx;
double ly;
int top_y;
int bot_y;
int left_x;
int right_x;
int endoffile;
FILE *file1;
int nf;
char thisline[300];

 scale=10000;

   file1 = fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

 
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    if ((strcmp(str_array[0],"Xstep")==0) && (strcmp(str_array[3],"Ystep")==0))
	{
     dx = atof(str_array[2])*scale;
     dy = atof(str_array[5])*scale;
	}
    if (dx == 0)
     dx = 1532500*2;
    if (dy == 0)
     dy = 1532500*2;

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"Xnum")==0) && ( strcmp(str_array[3],"Ynum")==0))
	{                                        //$1 == "Xnum") && ($4 == "Ynum")){
    nx = atoi(str_array[2]); // $3
    ny = atoi(str_array[5]); // $6
	}
    endoffile=getline(file1,thisline);
    endoffile=getline(file1,thisline); // getline
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"X")==0) && (strcmp(str_array[3],"Y")==0)) 
	{
    lx = atoi(str_array[2])*scale - dx/2;
    ly = atoi(str_array[5])*scale - dy/2;
	}
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
   }

 fclose(file1);

 printf("G54D299*\n");

 printf("X-1532500Y-1532500D02*\n");
 printf("X1532500Y-1532500D01*\n");
 printf("X1532500Y1532500D01*\n");
 printf("X-1532500Y1532500D01*\n");
 printf("X-1532500Y-1532500D01*\n");

 printf("X-1700000Y1300000D02*\n");
 printf("X-1532500Y1300000D01*\n");
 printf("X-1700000Y450000D02*\n");
 printf("X-1532500Y450000D01*\n");
 printf("X-1700000Y-1300000D02*\n");
 printf("X-1532500Y-1300000D01*\n");
 printf("X-1700000Y-450000D02*\n");
 printf("X-1532500Y-450000D01*\n");
 printf("X1700000Y1300000D02*\n");
 printf("X1532500Y1300000D01*\n");
 printf("X1700000Y450000D02*\n");
 printf("X1532500Y450000D01*\n");
 printf("X1700000Y-1300000D02*\n");
 printf("X1532500Y-1300000D01*\n");
 printf("X1700000Y-450000D02*\n");
 printf("X1532500Y-450000D01*\n");


 bot_y = (int) ly;
 top_y = (int) (ly + (ny * dy));

 left_x = (int) lx;
 right_x = (int) ( lx + ( nx * dx)) ;

 printf("G54D298*\n");
 for (i = 1; i <= nx+1; i++) 
 {
	 if ( strstr(commandstr,"b") == NULL)
	 {
	  printf("X%dY-1532500D02*\n", (int) ( lx+(i-1)*dx) ) ;  //
	 }
	 else
	 { 
	  printf("X%dY%dD02*\n", (int) ( lx+(i-1)*dx ) ,bot_y);  // 
	 }

	 if (strstr(commandstr,"t") == NULL)
	 {
      printf("X%dY+1532500D01*\n", (int) (lx+(i-1)*dx) );
	 }
	 else
	 {
      printf("X%dY%dD01*\n", ( int) ( lx+(i-1)*dx ),top_y);  // 
	 }
   
 }
 for (i = 1; i <= ny+1; i++) 
 {
	 if (strstr(commandstr,"l") == NULL)
	 {
      printf("X-1532500Y%dD02*\n", (int) ( ly+(i-1)*dy)) ;
	 }
	 else
	 {
		printf("X%dY%dD02*\n", left_x, (int) ( ly + (i-1)*dy) );
	 }

	 if (strstr(commandstr,"r") == NULL)
	 {
      printf("X1532500Y%dD01*\n", (int) ( ly+(i-1)*dy) );
	 }
	 else
	 {
		 printf("X%dY%dD01*\n", right_x, (int) ( ly+(i-1)*dy) );
	 }

 }
 
}  // end plate_call


int main(int argc, char **argv)
{

	if (argc == 2)
	{
	 plate_call(argv[1],"");
	}
	else
	{
		if (argc == 3)
		{
			plate_call(argv[1],argv[2]);
		}
		else
		{
		printf("Wrong number of arguments for plate \n");
		printf("Usage: plate step.txt [t][b][l][r] \n");
		exit(-1);
		}
	}

}







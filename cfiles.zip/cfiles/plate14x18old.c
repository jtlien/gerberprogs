
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void plate14x18_call_out(char *infilestr,char *commandstr, char *outfilestr)
{
int i;
int scale;
double dx;
double dy;
int nx;
int ny;
double lx;
double ly;
int bot_y;
int top_y;
int left_x;
int right_x;
int endoffile;
FILE *file1;
FILE *outfile;
int nf;
char thisline[300];

 scale=10000;

   file1 = fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

   outfile= fopen(outfilestr,"w");
   if (outfile==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",outfilestr);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    if ((strcmp(str_array[0],"Xstep")==0) && (strcmp(str_array[3],"Ystep")==0))
	{
     dx = atof(str_array[2])*scale;
     dy = atof(str_array[5])*scale;
	}
    if (dx == 0)
     dx = 1532500*2;
    if (dy == 0)
     dy = 2040500*2;

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"Xnum")==0) && ( strcmp(str_array[3],"Ynum")==0))
	{                                        //$1 == "Xnum") && ($4 == "Ynum")){
    nx = atoi(str_array[2]); // $3
    ny = atoi(str_array[5]); // $6
	}
    endoffile=getline(file1,thisline);
    endoffile=getline(file1,thisline); // getline
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"X")==0) && (strcmp(str_array[3],"Y")==0)) 
	{
    lx = atof(str_array[2])*scale - (dx/2);
    ly = atof(str_array[5])*scale - (dy/2);
	}
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
   }

 fclose(file1);

 
 fprintf(outfile,"G54D299*\n");
 fprintf(outfile,"X-1532500Y-2040500D02*\n");  // add 50.8 x 10000 to Y
 fprintf(outfile,"X1532500Y-2040500D01*\n");   // this is the outline
 fprintf(outfile,"X1532500Y2040500D01*\n");
 fprintf(outfile,"X-1532500Y2040500D01*\n");
 fprintf(outfile,"X-1532500Y-2040500D01*\n");

   // connect to big plating rectangles
  // on left side

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X-1618125Y1240000D03*\n");

 
  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X-1618125Y635000D03*\n");

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X-1618125Y-1240000D03*\n");

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X-1618125Y-635000D03*\n");

    // connect to big plating rectangles
    // on right side

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X1618125Y1240000D03*\n");

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X1618125Y635000D03*\n");


  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X1618125Y-1240000D03*\n");

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X1618125Y-635000D03*\n");

 

 // lines to connect to fids on left side
 //
 fprintf(outfile,"G54D297*\n");
 fprintf(outfile,"X-1559000Y222250D02*\n");
 fprintf(outfile,"X-1532500Y222250D01*\n");

 fprintf(outfile,"X-1559000Y158750D02*\n");
 fprintf(outfile,"X-1532500Y158750D01*\n");

 fprintf(outfile,"X-1559000Y95250D02*\n");
 fprintf(outfile,"X-1532500Y95250D01*\n");

 fprintf(outfile,"X-1559000Y31750D02*\n");
 fprintf(outfile,"X-1532500Y31750D01*\n");

 fprintf(outfile,"X-1559000Y-222250D02*\n");
 fprintf(outfile,"X-1532500Y-222250D01*\n");

 fprintf(outfile,"X-1559000Y-158750D02*\n");
 fprintf(outfile,"X-1532500Y-158750D01*\n");

 fprintf(outfile,"X-1559000Y-95250D02*\n");
 fprintf(outfile,"X-1532500Y-95250D01*\n");

 fprintf(outfile,"X-1559000Y-31750D02*\n");
 fprintf(outfile,"X-1532500Y-31750D01*\n");

 fprintf(outfile,"X-1547200Y1599000D02*\n");
 fprintf(outfile,"X-1532500Y1599000D01*\n");

 fprintf(outfile,"X-1547200Y1650500D02*\n");
 fprintf(outfile,"X-1532500Y1650500D01*\n");

 fprintf(outfile,"X-1547200Y1534160D02*\n");
 fprintf(outfile,"X-1532500Y1534160D01*\n");

 fprintf(outfile,"X-1547200Y-1599000D02*\n");
 fprintf(outfile,"X-1532500Y-1599000D01*\n");

 fprintf(outfile,"X-1547200Y-1650500D02*\n");
 fprintf(outfile,"X-1532500Y-1650500D01*\n");

 fprintf(outfile,"X-1547200Y-1534160D02*\n");
 fprintf(outfile,"X-1532500Y-1534160D01*\n");

// lines to connect to fids on right side
//

 fprintf(outfile,"X1559000Y222250D02*\n");
 fprintf(outfile,"X1532500Y222250D01*\n");

 fprintf(outfile,"X1559000Y158750D02*\n");
 fprintf(outfile,"X1532500Y158750D01*\n");

 fprintf(outfile,"X1559000Y95250D02*\n");
 fprintf(outfile,"X1532500Y95250D01*\n");

 fprintf(outfile,"X1559000Y31750D02*\n");
 fprintf(outfile,"X1532500Y31750D01*\n");

 fprintf(outfile,"X1559000Y-222250D02*\n");
 fprintf(outfile,"X1532500Y-222250D01*\n");

 fprintf(outfile,"X1559000Y-158750D02*\n");
 fprintf(outfile,"X1532500Y-158750D01*\n");

 fprintf(outfile,"X1559000Y-95250D02*\n");
 fprintf(outfile,"X1532500Y-95250D01*\n");

 fprintf(outfile,"X1559000Y-31750D02*\n");
 fprintf(outfile,"X1532500Y-31750D01*\n");

 fprintf(outfile,"X1547200Y1599000D02*\n");
 fprintf(outfile,"X1532500Y1599000D01*\n");

 fprintf(outfile,"X1547200Y1650500D02*\n");
 fprintf(outfile,"X1532500Y1650500D01*\n");

 fprintf(outfile,"X1547200Y1534160D02*\n");
 fprintf(outfile,"X1532500Y1534160D01*\n");

 fprintf(outfile,"X1547200Y-1599000D02*\n");
 fprintf(outfile,"X1532500Y-1599000D01*\n");

 fprintf(outfile,"X1547200Y-1650500D02*\n");
 fprintf(outfile,"X1532500Y-1650500D01*\n");

 fprintf(outfile,"X1547200Y-1534160D02*\n");
 fprintf(outfile,"X1532500Y-1534160D01*\n");


 bot_y = (int) ly;
 top_y = (int) (ly + (ny * dy));

 left_x = (int) lx;
 right_x = (int) (lx + ( nx * dx));

 fprintf(outfile,"G54D298*\n");
 for (i = 1; i <= nx+1; i++) 
 {
	 if ( strstr(commandstr,"b") == NULL)
	 {
	  fprintf(outfile,"X%dY-2040500D02*\n", (int) (lx+(i-1)*dx));  // add 50.8 * 10000
	 }
	 else
	 { 
	  fprintf(outfile,"X%dY%dD02*\n", (int )( lx+(i-1)*dx) ,bot_y);  // add 50.8 * 10000
	 }

	 if (strstr(commandstr,"t") == NULL)
	 {
      fprintf(outfile,"X%dY+2040500D01*\n",(int) ( lx+(i-1)*dx));
	 }
	 else
	 {
      fprintf(outfile,"X%dY%dD01*\n", (int )(lx+(i-1)*dx) ,top_y);  // add 50.8 * 10000
	 }
   
 }
 for (i = 1; i <= ny+1; i++) 
 {
	 if (strstr(commandstr,"l") == NULL)
	 {
      fprintf(outfile,"X-1532500Y%dD02*\n", (int )( ly+(i-1)*dy));
	 }
	 else
	 {
		fprintf(outfile,"X%dY%dD02*\n", left_x, (int) (ly + (i-1)*dy));
	 }

	 if (strstr(commandstr,"r") == NULL)
	 {
      fprintf(outfile,"X1532500Y%dD01*\n", (int) ( ly+(i-1)*dy));
	 }
	 else
	 {
		 fprintf(outfile,"X%dY%dD01*\n", right_x, (int ) (ly+(i-1)*dy));
	 }

 }

 fclose(outfile);

}  // end plate14x18_call_out

void plate14x18_call(char *infilestr,char *commandstr)
{
int i;
int scale;
double dx;
double dy;
int nx;
int ny;
double lx;
double ly;
int top_y;
int bot_y;
int left_x;
int right_x;
int endoffile;
FILE *file1;
int nf;
char thisline[300];

 scale=10000;

   file1 = fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

 
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    if ((strcmp(str_array[0],"Xstep")==0) && (strcmp(str_array[3],"Ystep")==0))
	{
     dx = atof(str_array[2])*scale;
     dy = atof(str_array[5])*scale;
//	 printf("dx dy = %f %f \n",dx, dy );
	}
    if (dx == 0)
     dx = 1532500*2;
    if (dy == 0)
     dy = 2040500*2;

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"Xnum")==0) && ( strcmp(str_array[3],"Ynum")==0))
	{                                        //$1 == "Xnum") && ($4 == "Ynum")){
    nx = atoi(str_array[2]); // $3
    ny = atoi(str_array[5]); // $6
//	printf("nx ny = %d %d \n",nx, ny );
	}
    endoffile=getline(file1,thisline);
    endoffile=getline(file1,thisline); // getline
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"X")==0) && (strcmp(str_array[3],"Y")==0)) 
	{
    lx = atof(str_array[2])*scale - (dx/2);
    ly = atof(str_array[5])*scale - (dy/2);
	}
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
   }

 // printf("lx ly = %f %f \n",lx, ly );

 fclose(file1);

 printf("G54D299*\n");
 printf("X-1532500Y-2040500D02*\n");  // add 50.8 x 10000 to Y
 printf("X1532500Y-2040500D01*\n");   // this is the outline
 printf("X1532500Y2040500D01*\n");
 printf("X-1532500Y2040500D01*\n");
 printf("X-1532500Y-2040500D01*\n");

   // connect to big plating rectangles
  // on left side

  printf("G54D716*\n");
  printf("X-1618125Y1240000D03*\n");

 
  printf("G54D716*\n");
  printf("X-1618125Y635000D03*\n");

  printf("G54D716*\n");
  printf("X-1618125Y-1240000D03*\n");

  printf("G54D716*\n");
  printf("X-1618125Y-635000D03*\n");

    // connect to big plating rectangles
    // on right side

  printf("G54D716*\n");
  printf("X1618125Y1240000D03*\n");

  printf("G54D716*\n");
  printf("X1618125Y635000D03*\n");


  printf("G54D716*\n");
  printf("X1618125Y-1240000D03*\n");

  printf("G54D716*\n");
  printf("X1618125Y-635000D03*\n");

 

 // lines to connect to fids on left side
 //
 printf("G54D297*\n");
 printf("X-1559000Y222250D02*\n");
 printf("X-1532500Y222250D01*\n");

 printf("X-1559000Y158750D02*\n");
 printf("X-1532500Y158750D01*\n");

 printf("X-1559000Y95250D02*\n");
 printf("X-1532500Y95250D01*\n");

 printf("X-1559000Y31750D02*\n");
 printf("X-1532500Y31750D01*\n");

 printf("X-1559000Y-222250D02*\n");
 printf("X-1532500Y-222250D01*\n");

 printf("X-1559000Y-158750D02*\n");
 printf("X-1532500Y-158750D01*\n");

 printf("X-1559000Y-95250D02*\n");
 printf("X-1532500Y-95250D01*\n");

 printf("X-1559000Y-31750D02*\n");
 printf("X-1532500Y-31750D01*\n");

 printf("X-1547200Y1599000D02*\n");
 printf("X-1532500Y1599000D01*\n");

 printf("X-1547200Y1650500D02*\n");
 printf("X-1532500Y1650500D01*\n");

 printf("X-1547200Y1534160D02*\n");
 printf("X-1532500Y1534160D01*\n");

 printf("X-1550000Y2017000D02*\n");
 printf("X-1532500Y2017000D01*\n");

 printf("X-1547200Y-1599000D02*\n");
 printf("X-1532500Y-1599000D01*\n");

 printf("X-1547200Y-1650500D02*\n");
 printf("X-1532500Y-1650500D01*\n");

 printf("X-1547200Y-1534160D02*\n");
 printf("X-1532500Y-1534160D01*\n");

 printf("X-1550000Y-2017000D02*\n");
 printf("X-1532500Y-2017000D01*\n");

// lines to connect to fids on right side
//

 printf("X1559000Y222250D02*\n");
 printf("X1532500Y222250D01*\n");

 printf("X1559000Y158750D02*\n");
 printf("X1532500Y158750D01*\n");

 printf("X1559000Y95250D02*\n");
 printf("X1532500Y95250D01*\n");

 printf("X1559000Y31750D02*\n");
 printf("X1532500Y31750D01*\n");

 printf("X1559000Y-222250D02*\n");
 printf("X1532500Y-222250D01*\n");

 printf("X1559000Y-158750D02*\n");
 printf("X1532500Y-158750D01*\n");

 printf("X1559000Y-95250D02*\n");
 printf("X1532500Y-95250D01*\n");

 printf("X1559000Y-31750D02*\n");
 printf("X1532500Y-31750D01*\n");

 printf("X1547200Y1599000D02*\n");
 printf("X1532500Y1599000D01*\n");

 printf("X1547200Y1650500D02*\n");
 printf("X1532500Y1650500D01*\n");

 printf("X1547200Y1534160D02*\n");
 printf("X1532500Y1534160D01*\n");

 printf("X1555000Y2017000D02*\n");
 printf("X1532500Y2017000D01*\n");

 printf("X1547200Y-1599000D02*\n");
 printf("X1532500Y-1599000D01*\n");

 printf("X1547200Y-1650500D02*\n");
 printf("X1532500Y-1650500D01*\n");

 printf("X1547200Y-1534160D02*\n");
 printf("X1532500Y-1534160D01*\n");

 printf("X1555000Y-2017000D02*\n");
 printf("X1532500Y-2017000D01*\n");

 bot_y = (int) ly;
 top_y = (int) (ly + (ny * dy));

 left_x = (int) lx;
 right_x = (int) (lx + ( nx * dx));

 printf("G54D298*\n");
 for (i = 1; i <= nx+1; i++) 
 {
	 if ( strstr(commandstr,"b") == NULL)
	 {
	  printf("X%dY-2040500D02*\n", (int) (lx+(i-1)*dx));  // add 50.8 * 10000
	 }
	 else
	 { 
	  printf("X%dY%dD02*\n", (int) (lx+(i-1)*dx) ,bot_y);  // add 50.8 * 10000
	 }

	 if (strstr(commandstr,"t") == NULL)
	 {
      printf("X%dY+2040500D01*\n", (int) (lx+(i-1)*dx));
	 }
	 else
	 {
      printf("X%dY%dD01*\n", (int) (lx+(i-1)*dx),top_y );  // add 50.8 * 10000
	 }
   
 }
 for (i = 1; i <= ny+1; i++) 
 {
	 if (strstr(commandstr,"l") == NULL)
	 {
      printf("X-1532500Y%dD02*\n", (int) (ly+(i-1)*dy ));
	 }
	 else
	 {
		printf("X%dY%dD02*\n", left_x, (int )( ly + (i-1)*dy) );
	 }

	 if (strstr(commandstr,"r") == NULL)
	 {
      printf("X1532500Y%dD01*\n", (int) ( ly+(i-1)*dy) );
	 }
	 else
	 {
		 printf("X%dY%dD01*\n", right_x, (int) ( ly+(i-1)*dy) );
	 }

 }
 
}  // end plate14x18_call


int main(int argc, char **argv)
{

	if (argc == 2)
	{
	 plate14x18_call(argv[1],"");
	}
	else
	{
		if (argc == 3)
		{
			plate14x18_call(argv[1],argv[2]);
		}
		else
		{
		printf("Wrong number of arguments for plate14x18 \n");
		printf("Usage: plate14x18 step.txt [t][b][l][r] \n");
		exit(-1);
		}
	}

}








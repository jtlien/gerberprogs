
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"



void plate18x18_call(char *infilestr,char *commandstr, char *kerfstr)
{
int i;
int scale;
double dx;
double dy;
int nx;
int ny;
double lx;
double kerf;        // kerf width
double ly;
int top_y;
int bot_y;
int left_x;
int right_x;
int endoffile;
FILE *file1;
int nf;
char thisline[300];
int kerfloops;
int kerfincr;
int ii,jj;
int dval;
int debug;
int halfkerf;
int yupper;
int ylower;
int xupper;
int xlower;

int yp_upper;
int yp_lower;
int xp_upper;
int xp_lower;

 debug =0;

 dval = 320;

 scale=10000;

   kerf= atof( kerfstr);

   if (debug) { printf("kerf = %f kerfstr = %s \n", kerf, kerfstr); }

   if (( kerf > 3.0 ) || ( kerf < .1))
   {
	   printf("Kerf must be in range of .1 to 3.0 \n");
	   exit(-1);
   }

   kerfloops = (int) ( kerf/.1 );

   file1 = fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

 
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    if ((strcmp(str_array[0],"Xstep")==0) && (strcmp(str_array[3],"Ystep")==0))
	{
     dx = atof(str_array[2])*scale;
     dy = atof(str_array[5])*scale;
//	 printf("dx dy = %f %f \n",dx, dy );
	}
    if (dx == 0)
     dx = 2040500*2;
    if (dy == 0)
     dy = 2040500*2;

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"Xnum")==0) && ( strcmp(str_array[3],"Ynum")==0))
	{                                        //$1 == "Xnum") && ($4 == "Ynum")){
    nx = atoi(str_array[2]); // $3
    ny = atoi(str_array[5]); // $6
//	printf("nx ny = %d %d \n",nx, ny );
	}
    endoffile=getline(file1,thisline);
    endoffile=getline(file1,thisline); // getline
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"X")==0) && (strcmp(str_array[3],"Y")==0)) 
	{
    lx = atof(str_array[2])*scale - (dx/2);
    ly = atof(str_array[5])*scale - (dy/2);
	}
   endoffile=getline(file1,thisline);
  nf=split_line(thisline);
   }

 // printf("lx ly = %f %f \n",lx, ly );

 fclose(file1);

 printf("G54D%d*\n",dval);
 kerfincr = 500;           // .1 * 10000 / 2

 halfkerf = kerfloops * 500;

 if (debug)
	{
 printf("kerfincr = %d kerf = %f kerfloops = %d \n",kerfincr,kerf, kerfloops);
 }

 for(ii=0; ii < kerfloops; ii += 1)
 {
   printf("X%dY%dD02*\n",-2040500 - halfkerf , (ii * kerfincr )-2040500);  // add 50.8 x 10000 to Y
   printf("X%dY%dD01*\n", 2040500 + halfkerf , (ii * kerfincr )-2040500);   // this is the outline
                                                    // left side
   printf("X%dY%dD02*\n",(ii * kerfincr) + 2040500 , -2040500 - halfkerf);
   printf("X%dY%dD01*\n",(ii * kerfincr) + 2040500 ,  2040500 + halfkerf);
                                                    // top
   printf("X%dY%dD02*\n",-2040500- halfkerf, (ii * kerfincr )+2040500);  // add 50.8 x 10000 to Y
   printf("X%dY%dD01*\n", 2040500+ halfkerf, (ii * kerfincr )+2040500);   // this is the outline
                                                    // right side
   printf("X%dY%dD02*\n",(ii * kerfincr) - 2040500 , -2040500-halfkerf);
   printf("X%dY%dD01*\n",(ii * kerfincr) - 2040500 ,  2040500+halfkerf);
                                                   // bottom
 }

 for(ii=0; ii < kerfloops; ii += 1)
 {
   jj = -ii;

   printf("X%dY%dD02*\n",-2040500-halfkerf, (jj * kerfincr )-2040500);  // add 50.8 x 10000 to Y
   printf("X%dY%dD01*\n", 2040500+halfkerf, (jj * kerfincr )-2040500);   // this is the outline
                                                    // left side
   printf("X%dY%dD02*\n",(jj * kerfincr) + 2040500 , -2040500-halfkerf);
   printf("X%dY%dD01*\n",(jj * kerfincr) + 2040500 ,  2040500+halfkerf);
                                                    // top
   printf("X%dY%dD02*\n",-2040500-halfkerf, (jj * kerfincr )+2040500);  // add 50.8 x 10000 to Y
   printf("X%dY%dD01*\n", 2040500+halfkerf, (jj * kerfincr )+2040500);   // this is the outline
                                                    // right side
   printf("X%dY%dD02*\n",(jj * kerfincr) - 2040500 , -2040500-halfkerf);
   printf("X%dY%dD01*\n",(jj * kerfincr) - 2040500 ,  2040500+halfkerf);
                                                   // bottom
 }


   // connect to big plating rectangles
  // on left side

  printf("G54D716*\n");
  printf("X-2126125Y1240000D03*\n");

 
  printf("G54D716*\n");
  printf("X-2126125Y635000D03*\n");

  printf("G54D716*\n");
  printf("X-2126125Y-1240000D03*\n");

  printf("G54D716*\n");
  printf("X-2126125Y-635000D03*\n");

    // connect to big plating rectangles
    // on right side

  printf("G54D716*\n");
  printf("X2126125Y1240000D03*\n");

  printf("G54D716*\n");
  printf("X2126125Y635000D03*\n");


  printf("G54D716*\n");
  printf("X2126125Y-1240000D03*\n");

  printf("G54D716*\n");
  printf("X2126125Y-635000D03*\n");

 

 // lines to connect to fids on left side
 //
 printf("G54D297*\n");
 printf("X-2067000Y222250D02*\n");
 printf("X-2040500Y222250D01*\n");

 printf("X-2067000Y158750D02*\n");
 printf("X-2040500Y158750D01*\n");

 printf("X-2067000Y95250D02*\n");
 printf("X-2040500Y95250D01*\n");

 printf("X-2067000Y31750D02*\n");
 printf("X-2040500Y31750D01*\n");

 printf("X-2067000Y-222250D02*\n");
 printf("X-2040500Y-222250D01*\n");

 printf("X-2067000Y-158750D02*\n");
 printf("X-2040500Y-158750D01*\n");

 printf("X-2067000Y-95250D02*\n");
 printf("X-2040500Y-95250D01*\n");

 printf("X-2067000Y-31750D02*\n");
 printf("X-2040500Y-31750D01*\n");

 printf("X-2055200Y1599000D02*\n");
 printf("X-2040500Y1599000D01*\n");

 printf("X-2055200Y1650500D02*\n");
 printf("X-2040500Y1650500D01*\n");

 printf("X-2055200Y1534160D02*\n");
 printf("X-2040500Y1534160D01*\n");

 printf("X-2058000Y2017000D02*\n");
 printf("X-2040500Y2017000D01*\n");

 printf("X-2055200Y-1599000D02*\n");
 printf("X-2040500Y-1599000D01*\n");

 printf("X-2055200Y-1650500D02*\n");
 printf("X-2040500Y-1650500D01*\n");

 printf("X-2055200Y-1534160D02*\n");
 printf("X-2040500Y-1534160D01*\n");

 printf("X-2058000Y-2017000D02*\n");
 printf("X-2040500Y-2017000D01*\n");

// lines to connect to fids on right side
//

 printf("X2067000Y222250D02*\n");
 printf("X2040500Y222250D01*\n");

 printf("X2067000Y158750D02*\n");
 printf("X2040500Y158750D01*\n");

 printf("X2067000Y95250D02*\n");
 printf("X2040500Y95250D01*\n");

 printf("X2067000Y31750D02*\n");
 printf("X2040500Y31750D01*\n");

 printf("X2067000Y-222250D02*\n");
 printf("X2040500Y-222250D01*\n");

 printf("X2067000Y-158750D02*\n");
 printf("X2040500Y-158750D01*\n");

 printf("X2067000Y-95250D02*\n");
 printf("X2040500Y-95250D01*\n");

 printf("X2067000Y-31750D02*\n");
 printf("X2040500Y-31750D01*\n");

 printf("X2055200Y1599000D02*\n");
 printf("X2040500Y1599000D01*\n");

 printf("X2055200Y1650500D02*\n");
 printf("X2040500Y1650500D01*\n");

 printf("X2055200Y1534160D02*\n");
 printf("X2040500Y1534160D01*\n");

 printf("X2063000Y2017000D02*\n");
 printf("X2040500Y2017000D01*\n");

 printf("X2055200Y-1599000D02*\n");
 printf("X2040500Y-1599000D01*\n");

 printf("X2055200Y-1650500D02*\n");
 printf("X2040500Y-1650500D01*\n");

 printf("X2055200Y-1534160D02*\n");
 printf("X2040500Y-1534160D01*\n");

 printf("X2063000Y-2017000D02*\n");
 printf("X2040500Y-2017000D01*\n");

 bot_y = (int) ly;
 top_y = (int) (ly + (ny * dy));

 left_x = (int) lx;
 right_x = (int) (lx + ( nx * dx));

 printf("G54D%d*\n",dval);
 for (ii=0; ii < kerfloops; ii += 1)
 {
   for (i = 1; i <= nx+1; i++) 
   {
	 if ( strstr(commandstr,"b") == NULL)
	 {
	  printf("X%dY-2040500D02*\n", (int) (lx+(i-1)*dx) + ii * kerfincr);  // add 50.8 * 10000
	 }
	 else
	 { 
	  printf("X%dY%dD02*\n", (int) (lx+(i-1)*dx) + ii * kerfincr ,bot_y);  // add 50.8 * 10000
	 }

	 if (strstr(commandstr,"t") == NULL)
	 {
      printf("X%dY+2040500D01*\n", (int) (lx+(i-1)*dx) + ii * kerfincr);
	 }
	 else
	 {
      printf("X%dY%dD01*\n", (int) (lx+(i-1)*dx)+ ii * kerfincr,top_y );  // add 50.8 * 10000
	 }
   }
 }

 for (ii=0; ii < kerfloops; ii += 1)
 {
   for (i = 1; i <= ny+1; i++) 
   {
	 if (strstr(commandstr,"l") == NULL)
	 {
      printf("X-2040500Y%dD02*\n", (int) (ly+(i-1)*dy ) + ii * kerfincr );
	 }
	 else
	 {
		printf("X%dY%dD02*\n", left_x, (int )( ly + (i-1)*dy) + ii * kerfincr );
	 }

	 if (strstr(commandstr,"r") == NULL)
	 {
      printf("X2040500Y%dD01*\n", (int) ( ly+(i-1)*dy) + ii * kerfincr );
	 }
	 else
	 {
		 printf("X%dY%dD01*\n", right_x, (int) ( ly+(i-1)*dy) + ii * kerfincr );
	 }
   }
 }


 for (ii=0; ii < kerfloops; ii += 1)
 {
	jj = -ii;

   for (i = 1; i <= nx+1; i++) 
   {
	 if ( strstr(commandstr,"b") == NULL)
	 {
	  printf("X%dY-2040500D02*\n", (int) (lx+(i-1)*dx) + jj * kerfincr);  // add 50.8 * 10000
	 }
	 else
	 { 
	  printf("X%dY%dD02*\n", (int) (lx+(i-1)*dx) + jj * kerfincr ,bot_y);  // add 50.8 * 10000
	 }

	 if (strstr(commandstr,"t") == NULL)
	 {
      printf("X%dY+2040500D01*\n", (int) (lx+(i-1)*dx) + jj * kerfincr);
	 }
	 else
	 {
      printf("X%dY%dD01*\n", (int) (lx+(i-1)*dx)+ jj * kerfincr,top_y );  // add 50.8 * 10000
	 }
   }
 }

 for (ii=0; ii < kerfloops; ii += 1)
 {
   jj=-ii;
   for (i = 1; i <= ny+1; i++) 
   {
	 if (strstr(commandstr,"l") == NULL)
	 {
      printf("X-2040500Y%dD02*\n", (int) (ly+(i-1)*dy ) + jj * kerfincr );
	 }
	 else
	 {
		printf("X%dY%dD02*\n", left_x, (int )( ly + (i-1)*dy) + jj * kerfincr );
	 }

	 if (strstr(commandstr,"r") == NULL)
	 {
      printf("X2040500Y%dD01*\n", (int) ( ly+(i-1)*dy) + jj * kerfincr );
	 }
	 else
	 {
		 printf("X%dY%dD01*\n", right_x, (int) ( ly+(i-1)*dy) + jj * kerfincr );
	 }
   }
 }
 
 // do the appropriate polygon to fill in the void between top and bottom and
 // active area

 yupper = 2040500;
 ylower = -2040500;
 xupper = 2040500;
 xlower = -2040500;

 xp_lower = (int) lx;
 yp_lower = (int) ly;
 xp_upper = right_x;
 yp_upper = top_y;  

 if (strstr(commandstr,"b") == NULL)  // no bottom clearout so fill bottom
	{
     printf("G36*\n");
     printf("X%dY%dD02*\n", xp_lower, ylower );
	 printf("X%dY%dD01*\n", xp_lower, yp_lower);
	 printf("X%dY%dD01*\n", xp_upper, yp_lower);
	 printf("X%dY%dD01*\n", xp_upper, ylower );
     printf("X%dY%dD01*\n", xlower, ylower );
	 printf("G37*\n");

	}
 if (strstr(commandstr,"t") == NULL)  // no top clearout so fill top
	{
     printf("G36*\n");
     printf("X%dY%dD02*\n", xp_lower, yp_upper );
	 printf("X%dY%dD01*\n", xp_lower, yupper ); 
	 printf("X%dY%dD01*\n", xp_upper, yupper);
	 printf("X%dY%dD01*\n", xp_upper, yp_upper );
     printf("X%dY%dD01*\n", xp_lower, yp_upper );
	 printf("G37*\n");

	}
  if (strstr(commandstr,"l") == NULL)  // no lef clearout so fill left
	{
     printf("G36*\n");

     printf("X%dY%dD02*\n", xlower, yp_lower );
	 printf("X%dY%dD01*\n", xlower, yp_upper ); 
	 printf("X%dY%dD01*\n", xp_lower, yp_upper);
	 printf("X%dY%dD01*\n", xp_lower, yp_lower );
     printf("X%dY%dD01*\n", xlower, yp_lower );

	 printf("G37*\n");
	}
 if (strstr(commandstr,"r") == NULL)
	{
     printf("G36*\n");
     printf("X%dY%dD02*\n", xp_upper, yp_lower );
	 printf("X%dY%dD01*\n", xp_upper, yp_upper ); 
	 printf("X%dY%dD01*\n", xupper, yp_upper);
	 printf("X%dY%dD01*\n", xupper, yp_lower );
     printf("X%dY%dD01*\n", xp_upper, yp_lower );

	 printf("G37*\n");
	}

 printf("G54D538*\n");
 printf("X2093000Y1905000D03*\n");   // flashes to connect ldifid
 printf("X-2093000Y1905000D03*\n"); 
 printf("X2093000Y-1905000D03*\n");   
 printf("X-2093000Y-1905000D03*\n"); 

}  // end plate18x18_call


void plate18x18_call_out(char *infilestr,char *commandstr, char *kerfstr, char *outfilestr)
{
int i;
int scale;
double dx;
double dy;
int nx;
int ny;
double lx;
double kerf;        // kerf width
double ly;
int top_y;
int bot_y;
int left_x;
int right_x;
int endoffile;
FILE *file1;
FILE *outfile;
int nf;
char thisline[300];
int kerfloops;
int kerfincr;
int ii,jj;
int dval;
int debug;
int halfkerf;
int yupper;
int ylower;
int xupper;
int xlower;

int yp_upper;
int yp_lower;
int xp_upper;
int xp_lower;

 debug =0;

 dval = 320;

 scale=10000;

   kerf= atof( kerfstr);

   if (debug) { printf("kerf = %f kerfstr = %s \n", kerf, kerfstr); }

   if (( kerf > 3.0 ) || ( kerf < .1))
   {
	   printf("Kerf must be in range of .1 to 3.0 \n");
	   exit(-1);
   }

   kerfloops = (int) ( kerf/.1 );

   file1 = fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }
   outfile = fopen(outfilestr,"w");
   if (file1==NULL)
   {
	   printf("In plate, unable to open the output file = %s \n",outfilestr);
	   exit(-1);
   }

 
   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    if ((strcmp(str_array[0],"Xstep")==0) && (strcmp(str_array[3],"Ystep")==0))
	{
     dx = atof(str_array[2])*scale;
     dy = atof(str_array[5])*scale;
//	 printf("dx dy = %f %f \n",dx, dy );
	}
    if (dx == 0)
     dx = 2040500*2;
    if (dy == 0)
     dy = 2040500*2;

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"Xnum")==0) && ( strcmp(str_array[3],"Ynum")==0))
	{                                        //$1 == "Xnum") && ($4 == "Ynum")){
    nx = atoi(str_array[2]); // $3
    ny = atoi(str_array[5]); // $6
//	printf("nx ny = %d %d \n",nx, ny );
	}
    endoffile=getline(file1,thisline);
    endoffile=getline(file1,thisline); // getline
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"X")==0) && (strcmp(str_array[3],"Y")==0)) 
	{
    lx = atof(str_array[2])*scale - (dx/2);
    ly = atof(str_array[5])*scale - (dy/2);
	}
   endoffile=getline(file1,thisline);
  nf=split_line(thisline);
   }

 // printf("lx ly = %f %f \n",lx, ly );

 fclose(file1);

 fprintf(outfile,"G54D%d*\n",dval);
 kerfincr = 500;           // .1 * 10000 / 2

 halfkerf = kerfloops * 500;

 if (debug)
	{
 printf("kerfincr = %d kerf = %f kerfloops = %d \n",kerfincr,kerf, kerfloops);
 }

 for(ii=0; ii < kerfloops; ii += 1)
 {
   fprintf(outfile,"X%dY%dD02*\n",-2040500 - halfkerf , (ii * kerfincr )-2040500);  // add 50.8 x 10000 to Y
   fprintf(outfile,"X%dY%dD01*\n", 2040500 + halfkerf , (ii * kerfincr )-2040500);   // this is the outline
                                                    // left side
   fprintf(outfile,"X%dY%dD02*\n",(ii * kerfincr) + 2040500 , -2040500 - halfkerf);
   fprintf(outfile,"X%dY%dD01*\n",(ii * kerfincr) + 2040500 ,  2040500 + halfkerf);
                                                    // top
   fprintf(outfile,"X%dY%dD02*\n",-2040500- halfkerf, (ii * kerfincr )+2040500);  // add 50.8 x 10000 to Y
   fprintf(outfile,"X%dY%dD01*\n", 2040500+ halfkerf, (ii * kerfincr )+2040500);   // this is the outline
                                                    // right side
   fprintf(outfile,"X%dY%dD02*\n",(ii * kerfincr) - 2040500 , -2040500-halfkerf);
   fprintf(outfile,"X%dY%dD01*\n",(ii * kerfincr) - 2040500 ,  2040500+halfkerf);
                                                   // bottom
 }

 for(ii=0; ii < kerfloops; ii += 1)
 {
   jj = -ii;

   fprintf(outfile,"X%dY%dD02*\n",-2040500-halfkerf, (jj * kerfincr )-2040500);  // add 50.8 x 10000 to Y
   fprintf(outfile,"X%dY%dD01*\n", 2040500+halfkerf, (jj * kerfincr )-2040500);   // this is the outline
                                                    // left side
   fprintf(outfile,"X%dY%dD02*\n",(jj * kerfincr) + 2040500 , -2040500-halfkerf);
   fprintf(outfile,"X%dY%dD01*\n",(jj * kerfincr) + 2040500 ,  2040500+halfkerf);
                                                    // top
   fprintf(outfile,"X%dY%dD02*\n",-2040500-halfkerf, (jj * kerfincr )+2040500);  // add 50.8 x 10000 to Y
   fprintf(outfile,"X%dY%dD01*\n", 2040500+halfkerf, (jj * kerfincr )+2040500);   // this is the outline
                                                    // right side
   fprintf(outfile,"X%dY%dD02*\n",(jj * kerfincr) - 2040500 , -2040500-halfkerf);
   fprintf(outfile,"X%dY%dD01*\n",(jj * kerfincr) - 2040500 ,  2040500+halfkerf);
                                                   // bottom
 }


   // connect to big plating rectangles
  // on left side

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X-2126125Y1240000D03*\n");

 
  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X-2126125Y635000D03*\n");

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X-2126125Y-1240000D03*\n");

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X-2126125Y-635000D03*\n");

    // connect to big plating rectangles
    // on right side

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X2126125Y1240000D03*\n");

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X2126125Y635000D03*\n");


  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X2126125Y-1240000D03*\n");

  fprintf(outfile,"G54D716*\n");
  fprintf(outfile,"X2126125Y-635000D03*\n");

 

 // lines to connect to fids on left side
 //
 fprintf(outfile,"G54D297*\n");
 fprintf(outfile,"X-2067000Y222250D02*\n"); //1559
 fprintf(outfile,"X-2040500Y222250D01*\n");

 fprintf(outfile,"X-2067000Y158750D02*\n");
 fprintf(outfile,"X-2040500Y158750D01*\n");

 fprintf(outfile,"X-2067000Y95250D02*\n");
 fprintf(outfile,"X-2040500Y95250D01*\n");

 fprintf(outfile,"X-2067000Y31750D02*\n");
 fprintf(outfile,"X-2040500Y31750D01*\n");

 fprintf(outfile,"X-2067000Y-222250D02*\n");
 fprintf(outfile,"X-2040500Y-222250D01*\n");

 fprintf(outfile,"X-2067000Y-158750D02*\n");
 fprintf(outfile,"X-2040500Y-158750D01*\n");

 fprintf(outfile,"X-2067000Y-95250D02*\n");
 fprintf(outfile,"X-2040500Y-95250D01*\n");

 fprintf(outfile,"X-2067000Y-31750D02*\n");
 fprintf(outfile,"X-2040500Y-31750D01*\n");

 fprintf(outfile,"X-2055200Y1599000D02*\n");
 fprintf(outfile,"X-2040500Y1599000D01*\n");

 fprintf(outfile,"X-2055200Y1650500D02*\n");
 fprintf(outfile,"X-2040500Y1650500D01*\n");

 fprintf(outfile,"X-2055200Y1534160D02*\n");
 fprintf(outfile,"X-2040500Y1534160D01*\n");

 fprintf(outfile,"X-2058000Y2017000D02*\n");
 fprintf(outfile,"X-2040500Y2017000D01*\n");

 fprintf(outfile,"X-2055200Y-1599000D02*\n");
 fprintf(outfile,"X-2040500Y-1599000D01*\n");

 fprintf(outfile,"X-2055200Y-1650500D02*\n");
 fprintf(outfile,"X-2040500Y-1650500D01*\n");

 fprintf(outfile,"X-2055200Y-1534160D02*\n");
 fprintf(outfile,"X-2040500Y-1534160D01*\n");

 fprintf(outfile,"X-2058000Y-2017000D02*\n");
 fprintf(outfile,"X-2040500Y-2017000D01*\n");

// lines to connect to fids on right side
//

 fprintf(outfile,"X2067000Y222250D02*\n");
 fprintf(outfile,"X2040500Y222250D01*\n");

 fprintf(outfile,"X2067000Y158750D02*\n");
 fprintf(outfile,"X2040500Y158750D01*\n");

 fprintf(outfile,"X2067000Y95250D02*\n");
 fprintf(outfile,"X2040500Y95250D01*\n");

 fprintf(outfile,"X2067000Y31750D02*\n");
 fprintf(outfile,"X2040500Y31750D01*\n");

 fprintf(outfile,"X2067000Y-222250D02*\n");
 fprintf(outfile,"X2040500Y-222250D01*\n");

 fprintf(outfile,"X2067000Y-158750D02*\n");
 fprintf(outfile,"X2040500Y-158750D01*\n");

 fprintf(outfile,"X2067000Y-95250D02*\n");
 fprintf(outfile,"X2040500Y-95250D01*\n");

 fprintf(outfile,"X2067000Y-31750D02*\n");
 fprintf(outfile,"X2040500Y-31750D01*\n");

 fprintf(outfile,"X2055200Y1599000D02*\n");
 fprintf(outfile,"X2040500Y1599000D01*\n");

 fprintf(outfile,"X2055200Y1650500D02*\n");
 fprintf(outfile,"X2040500Y1650500D01*\n");

 fprintf(outfile,"X2055200Y1534160D02*\n");
 fprintf(outfile,"X2040500Y1534160D01*\n");

 fprintf(outfile,"X2063000Y2017000D02*\n");
 fprintf(outfile,"X2040500Y2017000D01*\n");

 fprintf(outfile,"X2055200Y-1599000D02*\n");
 fprintf(outfile,"X2040500Y-1599000D01*\n");

 fprintf(outfile,"X2055200Y-1650500D02*\n");
 fprintf(outfile,"X2040500Y-1650500D01*\n");

 fprintf(outfile,"X2055200Y-1534160D02*\n");
 fprintf(outfile,"X2040500Y-1534160D01*\n");

 fprintf(outfile,"X2063000Y-2017000D02*\n");
 fprintf(outfile,"X2040500Y-2017000D01*\n");

 bot_y = (int) ly;
 top_y = (int) (ly + (ny * dy));

 left_x = (int) lx;
 right_x = (int) (lx + ( nx * dx));

 fprintf(outfile,"G54D%d*\n",dval);
 for (ii=0; ii < kerfloops; ii += 1)
 {
   for (i = 1; i <= nx+1; i++) 
   {
	 if ( strstr(commandstr,"b") == NULL)
	 {
	  fprintf(outfile,"X%dY-2040500D02*\n", (int) (lx+(i-1)*dx) + ii * kerfincr);  // add 50.8 * 10000
	 }
	 else
	 { 
	  fprintf(outfile,"X%dY%dD02*\n", (int) (lx+(i-1)*dx) + ii * kerfincr ,bot_y);  // add 50.8 * 10000
	 }

	 if (strstr(commandstr,"t") == NULL)
	 {
      fprintf(outfile,"X%dY+2040500D01*\n", (int) (lx+(i-1)*dx) + ii * kerfincr);
	 }
	 else
	 {
      fprintf(outfile,"X%dY%dD01*\n", (int) (lx+(i-1)*dx)+ ii * kerfincr,top_y );  // add 50.8 * 10000
	 }
   }
 }

 for (ii=0; ii < kerfloops; ii += 1)
 {
   for (i = 1; i <= ny+1; i++) 
   {
	 if (strstr(commandstr,"l") == NULL)
	 {
      fprintf(outfile,"X-2040500Y%dD02*\n", (int) (ly+(i-1)*dy ) + ii * kerfincr );
	 }
	 else
	 {
		fprintf(outfile,"X%dY%dD02*\n", left_x, (int )( ly + (i-1)*dy) + ii * kerfincr );
	 }

	 if (strstr(commandstr,"r") == NULL)
	 {
      fprintf(outfile,"X2040500Y%dD01*\n", (int) ( ly+(i-1)*dy) + ii * kerfincr );
	 }
	 else
	 {
		 fprintf(outfile,"X%dY%dD01*\n", right_x, (int) ( ly+(i-1)*dy) + ii * kerfincr );
	 }
   }
 }


 for (ii=0; ii < kerfloops; ii += 1)
 {
	jj = -ii;

   for (i = 1; i <= nx+1; i++) 
   {
	 if ( strstr(commandstr,"b") == NULL)
	 {
	  fprintf(outfile,"X%dY-2040500D02*\n", (int) (lx+(i-1)*dx) + jj * kerfincr);  // add 50.8 * 10000
	 }
	 else
	 { 
	  fprintf(outfile,"X%dY%dD02*\n", (int) (lx+(i-1)*dx) + jj * kerfincr ,bot_y);  // add 50.8 * 10000
	 }

	 if (strstr(commandstr,"t") == NULL)
	 {
      fprintf(outfile,"X%dY+2040500D01*\n", (int) (lx+(i-1)*dx) + jj * kerfincr);
	 }
	 else
	 {
      fprintf(outfile,"X%dY%dD01*\n", (int) (lx+(i-1)*dx)+ jj * kerfincr,top_y );  // add 50.8 * 10000
	 }
   }
 }

 for (ii=0; ii < kerfloops; ii += 1)
 {
   jj=-ii;
   for (i = 1; i <= ny+1; i++) 
   {
	 if (strstr(commandstr,"l") == NULL)
	 {
      fprintf(outfile,"X-2040500Y%dD02*\n", (int) (ly+(i-1)*dy ) + jj * kerfincr );
	 }
	 else
	 {
		fprintf(outfile,"X%dY%dD02*\n", left_x, (int )( ly + (i-1)*dy) + jj * kerfincr );
	 }

	 if (strstr(commandstr,"r") == NULL)
	 {
      fprintf(outfile,"X2040500Y%dD01*\n", (int) ( ly+(i-1)*dy) + jj * kerfincr );
	 }
	 else
	 {
		 fprintf(outfile,"X%dY%dD01*\n", right_x, (int) ( ly+(i-1)*dy) + jj * kerfincr );
	 }
   }
 }
 
 // do the appropriate polygon to fill in the void between top and bottom and
 // active area

 yupper = 2040500;
 ylower = -2040500;
 xupper = 2040500;   // 2040500;
 xlower = -2040500;  // -2040500;

 xp_lower = (int) lx;
 yp_lower = (int) ly;
 xp_upper = right_x;
 yp_upper = top_y;  

 if (strstr(commandstr,"b") == NULL)  // no bottom clearout so fill bottom
	{
     fprintf(outfile,"G36*\n");
     fprintf(outfile,"X%dY%dD02*\n", xp_lower, ylower );
	 fprintf(outfile,"X%dY%dD01*\n", xp_lower, yp_lower);
	 fprintf(outfile,"X%dY%dD01*\n", xp_upper, yp_lower);
	 fprintf(outfile,"X%dY%dD01*\n", xp_upper, ylower );
     fprintf(outfile,"X%dY%dD01*\n", xlower, ylower );
	 fprintf(outfile,"G37*\n");

	}
 if (strstr(commandstr,"t") == NULL)  // no top clearout so fill top
	{
     fprintf(outfile,"G36*\n");
     fprintf(outfile,"X%dY%dD02*\n", xp_lower, yp_upper );
	 fprintf(outfile,"X%dY%dD01*\n", xp_lower, yupper ); 
	 fprintf(outfile,"X%dY%dD01*\n", xp_upper, yupper);
	 fprintf(outfile,"X%dY%dD01*\n", xp_upper, yp_upper );
     fprintf(outfile,"X%dY%dD01*\n", xp_lower, yp_upper );
	 fprintf(outfile,"G37*\n");

	}
  if (strstr(commandstr,"l") == NULL)  // no left clearout so fill left
	{
     fprintf(outfile,"G36*\n");

     fprintf(outfile,"X%dY%dD02*\n", xlower, yp_lower );
	 fprintf(outfile,"X%dY%dD01*\n", xlower, yp_upper ); 
	 fprintf(outfile,"X%dY%dD01*\n", xp_lower, yp_upper);
	 fprintf(outfile,"X%dY%dD01*\n", xp_lower, yp_lower );
     fprintf(outfile,"X%dY%dD01*\n", xlower, yp_lower );

	 fprintf(outfile,"G37*\n");
	}
 if (strstr(commandstr,"r") == NULL)
	{
     fprintf(outfile,"G36*\n");
     fprintf(outfile,"X%dY%dD02*\n", xp_upper, yp_lower );
	 fprintf(outfile,"X%dY%dD01*\n", xp_upper, yp_upper ); 
	 fprintf(outfile,"X%dY%dD01*\n", xupper, yp_upper);
	 fprintf(outfile,"X%dY%dD01*\n", xupper, yp_lower );
     fprintf(outfile,"X%dY%dD01*\n", xp_upper, yp_lower );

	 fprintf(outfile,"G37*\n");
	}

 fprintf(outfile,"G54D538*\n");
 fprintf(outfile,"X2093000Y1905000D03*\n");   // flashes to connect ldifid
 fprintf(outfile,"X-2093000Y1905000D03*\n"); 
 fprintf(outfile,"X2093000Y-1905000D03*\n");   
 fprintf(outfile,"X-2093000Y-1905000D03*\n"); 

 fclose(outfile);

}  // end plate18x18_call_out

/*

int main(int argc, char **argv)
{

	if (argc == 3)
	{
	 plate18x18_call(argv[1],"",argv[2]);
	}
	else
	{
		if (argc == 4)
		{
			plate18x18_call(argv[1],argv[2],argv[3]);
		}
		else
		{
		printf("Wrong number of arguments for plate18x18 \n");
		printf("Usage: plate18x18n step.txt [t][b][l][r] kerf\n");
		exit(-1);
		}
	}

}


*/










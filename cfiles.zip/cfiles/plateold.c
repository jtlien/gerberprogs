
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


char str_array[120][120];

 
int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line


//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

void plate_call_out(char *infilestr,char *outfilestr)
{
int i;
int scale;
int dx;
int dy;
int nx;
int ny;
int lx;
int ly;
int endoffile;
FILE *file1;
FILE *outfile;
int nf;
char thisline[300];

 scale=10000;

   file1 = fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

   outfile= fopen(outfilestr,"w");
   if (outfile==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",outfilestr);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    if ((strcmp(str_array[0],"Xstep")==0) && (strcmp(str_array[3],"Ystep")==0))
	{
     dx = atoi(str_array[2])*scale;
     dy = atoi(str_array[5])*scale;
	}
    if (dx == 0)
     dx = 1532500*2;
    if (dy == 0)
     dy = 1532500*2;

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"Xnum")==0) && ( strcmp(str_array[3],"Ynum")==0))
	{                                        //$1 == "Xnum") && ($4 == "Ynum")){
    nx = atoi(str_array[2]); // $3
    ny = atoi(str_array[5]); // $6
	}
    endoffile=getline(file1,thisline);
    endoffile=getline(file1,thisline); // getline
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"X")==0) && (strcmp(str_array[3],"Y")==0)) 
	{
    lx = atoi(str_array[2])*scale - dx/2;
    ly = atoi(str_array[5])*scale - dy/2;
	}
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
   }

 fclose(file1);

 fprintf(outfile,"D299*\n");
 fprintf(outfile,"X-1532500Y-1532500D02*\n");
 fprintf(outfile,"X1532500Y-1532500D01*\n");
 fprintf(outfile,"X1532500Y1532500D01*\n");
 fprintf(outfile,"X-1532500Y1532500D01*\n");
 fprintf(outfile,"X-1532500Y-1532500D01*\n");

 fprintf(outfile,"X-1700000Y1300000D02*\n");
 fprintf(outfile,"X-1532500Y1300000D01*\n");
 fprintf(outfile,"X-1700000Y450000D02*\n");
 fprintf(outfile,"X-1532500Y450000D01*\n");
 fprintf(outfile,"X-1700000Y-1300000D02*\n");
 fprintf(outfile,"X-1532500Y-1300000D01*\n");
 fprintf(outfile,"X-1700000Y-450000D02*\n");
 fprintf(outfile,"X-1532500Y-450000D01*\n");
 fprintf(outfile,"X1700000Y1300000D02*\n");
 fprintf(outfile,"X1532500Y1300000D01*\n");
 fprintf(outfile,"X1700000Y450000D02*\n");
 fprintf(outfile,"X1532500Y450000D01*\n");
 fprintf(outfile,"X1700000Y-1300000D02*\n");
 fprintf(outfile,"X1532500Y-1300000D01*\n");
 fprintf(outfile,"X1700000Y-450000D02*\n");
 fprintf(outfile,"X1532500Y-450000D01*\n");

 fprintf(outfile,"D298*\n");
 for (i = 1; i <= nx+1; i++) 
 {
   fprintf(outfile,"X%dY-1532500D02*\n", lx+(i-1)*dx);
   fprintf(outfile,"X%dY+1532500D01*\n", lx+(i-1)*dx);
 }
 for (i = 1; i <= ny+1; i++) 
 {
   fprintf(outfile,"X-1532500Y%dD02*\n", ly+(i-1)*dy);
   fprintf(outfile,"X1532500Y%dD01*\n", ly+(i-1)*dy);
 }
 fclose(outfile);

}  // end plate_call_out

//  plate program

void plate_call(char *infilestr)
{
int i;
int scale;
int dx;
int dy;
int nx;
int ny;
int lx;
int ly;
int endoffile;
FILE *file1;
int nf;
char thisline[300];

 scale=10000;

   file1 = fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    if ((strcmp(str_array[0],"Xstep")==0) && (strcmp(str_array[3],"Ystep")==0))
	{
     dx = atoi(str_array[2])*scale;
     dy = atoi(str_array[5])*scale;
	}
    if (dx == 0)
     dx = 1532500*2;
    if (dy == 0)
     dy = 1532500*2;

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"Xnum")==0) && ( strcmp(str_array[3],"Ynum")==0))
	{                                        //$1 == "Xnum") && ($4 == "Ynum")){
    nx = atoi(str_array[2]); // $3
    ny = atoi(str_array[5]); // $6
	}
    endoffile=getline(file1,thisline);
    endoffile=getline(file1,thisline); // getline
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"X")==0) && (strcmp(str_array[3],"Y")==0)) 
	{
    lx = atoi(str_array[2])*scale - dx/2;
    ly = atoi(str_array[5])*scale - dy/2;
	}
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
   }

 fclose(file1);

 printf("D299*\n");
 printf("X-1532500Y-1532500D02*\n");
 printf("X1532500Y-1532500D01*\n");
 printf("X1532500Y1532500D01*\n");
 printf("X-1532500Y1532500D01*\n");
 printf("X-1532500Y-1532500D01*\n");

 printf("X-1700000Y1300000D02*\n");
 printf("X-1532500Y1300000D01*\n");
 printf("X-1700000Y450000D02*\n");
 printf("X-1532500Y450000D01*\n");
 printf("X-1700000Y-1300000D02*\n");
 printf("X-1532500Y-1300000D01*\n");
 printf("X-1700000Y-450000D02*\n");
 printf("X-1532500Y-450000D01*\n");
 printf("X1700000Y1300000D02*\n");
 printf("X1532500Y1300000D01*\n");
 printf("X1700000Y450000D02*\n");
 printf("X1532500Y450000D01*\n");
 printf("X1700000Y-1300000D02*\n");
 printf("X1532500Y-1300000D01*\n");
 printf("X1700000Y-450000D02*\n");
 printf("X1532500Y-450000D01*\n");

 printf("D298*\n");
 for (i = 1; i <= nx+1; i++) 
 {
   printf("X%dY-1532500D02*\n", lx+(i-1)*dx);
   printf("X%dY+1532500D01*\n", lx+(i-1)*dx);
 }
 for (i = 1; i <= ny+1; i++) 
 {
   printf("X-1532500Y%dD02*\n", ly+(i-1)*dy);
   printf("X1532500Y%dD01*\n", ly+(i-1)*dy);
 }
}  // end plate

int main(int argc, char **argv)
{

	plate_call(argv[1]);
}



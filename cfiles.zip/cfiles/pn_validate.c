
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


// Validate input as a part number.
// 2 possible formats: 8 or 8-2
// call external script to assure all numbers
// return codes: 1 for bad invocation, 2 for invalid result, 3 for valid

// Rev 0.0
// March 24, 1999

//////////////////////////////////// Functions
// Validate single input string is all numbers
// string can be any length
// return codes: 1 for bad invocation, 2 for invalid result, 3 for valid

int isnumber( char *vstr)
{
int poscount;
int goodchar;
int vlen;
char each_char;

poscount=0;
goodchar = 0;


vlen=strlen(vstr);

poscount = 0;

while ((poscount < vlen))
{
   each_char=vstr[poscount]; // get next character from line
   // The / and : characters precede and follow 0 and 9 in ASCII
   if ( isdigit( each_char ))
   {
     goodchar += 1;
   }
  poscount += 1;
}

if ((goodchar == vlen))
{
   return(3);
}
else
{
   return(2);

}

} // end isnumber

//////////////////////////////////////////////////////////////
//  pn_validate  - validate a part number
//
//////////////////////////////////////////////////////////

int pn_validate_call( char *pn)
{
int pnlen;
char base[120];
char tab[40];
int kk;
int ll;
int result;
int tresult;

int baselen;
int tablen;


pnlen=strlen(pn);

if (pnlen == 8)
{
   //printf( "8-digit string..."
   result = isnumber(pn);

   if (result == 1)
   {
      printf("incorrect call to isnumber \n");
      return(1);
   }
   if (result == 3)
   {
      printf("Part Number OK!\n");
      return(3);
   }
   else
   {
      printf("Part Number not valid!\n");
      return(2);
   }
 }
else if (pnlen == 11)
{
   // split into base and tab and validate each one
   
   kk=0;
   while((kk < (signed int) strlen(pn)) && ( pn[kk] != '-'))
   { 
	   base[kk] = pn[kk];
	   kk += 1;
   }
   base[kk] = 0;
   kk += 1;
   ll=0;
   while(kk < (signed int) strlen(pn))
   { 
	   tab[ll] = pn[kk];
	   ll +=1;
	   kk +=1;
   }
   tab[ll] = 0;

   baselen=strlen(base);
   tablen=strlen(tab);   

   if ((baselen == 8) && (tablen == 2))
   { 
      result = isnumber(base);
      if (result == 1)
      {
        printf("incorrect function call: isnumber\n");
	    return(1);
	  }
  
     if ((result == 3))
      {
         tresult =isnumber(tab);

	     if (tresult == 1)
		 {
	      printf("incorrect function call: isnumber\n"); 
	      return(1);
		 }
         if (tresult == 3)
         {
            printf( "Part Number OK!\n");
	        return(3);
		 }
         else
		 {
	       printf( "Part Number not valid! Non digit in tab \n");
	       return(2);
		 }
	 }
     else
	 {
         printf( "Part Number not valid! Non digit in base \n");
	     return(2);
	 }
   }
   else
   {
      printf( "INVALID TAB FORMAT, Should be xxxxxxxx-yy\n");
      return(2);
   }
 }
else
{
   printf( "WRONG LENGTH! Should be 8 or 11 \n");
   return(2);
}

} // end pn_validate

/*
int main( int argc, char **argv)
{
int this_return;

	this_return = pn_validate_call(argv[1]);

    printf("Return value = %d \n", this_return);

	exit(this_return);

}

  */

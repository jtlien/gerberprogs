#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include <math.h>


#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

FILE *outfile;

struct xystuff
{
	double xval;
	double yval;
}   xy_array[1000];

#include "utilprogs.h"

// routines to take gerber flash primitives and convert them to postscript
//
//  Non zero y_hole_dimen indicates rectangular hole

void do_polygon_flash( double outside_dimen, int number_sides, double begin_angle,
					   double x_hole_dimen, double y_hole_dimen, double xloc, double yloc)
{
double increment_angle;
double new_angle;
double radius;
int i;
double xval, yval;
double init_xval, init_yval;

 if ( (number_sides > 2)  && ( number_sides < 20))
 {

	  fprintf(outfile,"2 ClrSet\n");

	 increment_angle = (2.0 * 3.1415926535) / number_sides;

     new_angle = begin_angle;

	 radius = outside_dimen / ( 2.0 * sin( increment_angle / 2.0) );

	 i = 0;

     init_xval = radius * cos(new_angle);
     init_yval = radius * sin(new_angle);

	 while( i < number_sides)
	 {
		 xval = radius * cos(new_angle);
		 yval = radius * sin(new_angle);

		 fprintf(outfile,"%f %f\n", xloc + xval, yloc+yval);
		 new_angle = new_angle + increment_angle;

		 i += 1;
	 }
     
	 fprintf(outfile,"%f %f\n", init_xval+xloc, init_yval+yloc);

	 fprintf(outfile,"%d", number_sides + 1);
	 fprintf(outfile,"1\n-1\n1\n1\n");
	 fprintf(outfile,"BounOut\n");

	 if ( x_hole_dimen != 0.0)
	 {
		 if (y_hole_dimen != 0.0 )  // rectangle hole
		 {
		  fprintf(outfile,"Bknd setrgbcolor\n");
          fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/2.0)+yloc); // rt
          fprintf(outfile,"%f %f\n", (x_hole_dimen/-2.0)+xloc, (y_hole_dimen/2.0)+yloc); // lt
          fprintf(outfile,"%f %f\n", (x_hole_dimen/-2.0)+xloc, (y_hole_dimen/-2.0)+yloc); // lb
		  fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/-2.0)+yloc); // rb
          fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/2.0)+yloc); // rt
		  fprintf(outfile,"5\n");
		  fprintf(outfile,"0\n-1\n1\n1\n");
		  fprintf(outfile,"BoundOut\n");

		 }
		else   // circular hole
		{
		  fprintf(outfile,"Bknd setrgbcolor\n");
          fprintf(outfile,"%f %f %f \n", xloc, yloc, x_hole_dimen); // solid hole
         
		  fprintf(outfile,"0\n-1\n1\n1\n");
		  fprintf(outfile,"CircOut\n");
          
        }
	 }
	else   // no hole, do nothing
	  {

	  }

 }
 else
 {
	 printf("Polygon must have more than 2 points but not more than 20\n");

 }


}   // do_polygon_flash

void do_rect_flash( double x_dimen, int y_dimen, 
					   double x_hole_dimen, double y_hole_dimen,
					   double xloc, double yloc)
{

 
	fprintf(outfile,"2 ClrSet\n");

	fprintf(outfile,"%f %f\n", (x_dimen/2.0)+xloc, (y_dimen/2.0)+yloc); // rt
    fprintf(outfile,"%f %f\n", (x_dimen/-2.0)+xloc, (y_dimen/2.0)+yloc); // lt
    fprintf(outfile,"%f %f\n", (x_dimen/-2.0)+xloc, (y_dimen/-2.0)+yloc); // lb
    fprintf(outfile,"%f %f\n", (x_dimen/2.0)+xloc, (y_dimen/-2.0)+yloc); // rb
    fprintf(outfile,"%f %f\n", (x_dimen/2.0)+xloc, (y_dimen/2.0)+yloc); // rt
    fprintf(outfile,"5\n");
    fprintf(outfile,"1\n-1\n1\n1\n");
    fprintf(outfile,"BoundOut\n");

	 if ( x_hole_dimen != 0.0)
	 {
		 if (y_hole_dimen != 0.0 )  // rectangle hole
		 {
		  fprintf(outfile,"Bknd setrgbcolor\n");
          fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/2.0)+yloc); // rt
          fprintf(outfile,"%f %f\n", (x_hole_dimen/-2.0)+xloc, (y_hole_dimen/2.0)+yloc); // lt
          fprintf(outfile,"%f %f\n", (x_hole_dimen/-2.0)+xloc, (y_hole_dimen/-2.0)+yloc); // lb
		  fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/-2.0)+yloc); // rb
          fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/2.0)+yloc); // rt
		  fprintf(outfile,"5\n");
		  fprintf(outfile,"0\n-1\n1\n1\n");
		  fprintf(outfile,"BoundOut\n");

		 }
		else   // circular hole
		{
		  fprintf(outfile,"Bknd setrgbcolor\n");
          fprintf(outfile,"%f %f %f \n", xloc, yloc, x_hole_dimen); // rt
         
		  fprintf(outfile,"0\n-1\n1\n1\n");
		  fprintf(outfile,"CircOut\n");
          
        }
	 }
	else   // no hole, do nothing
	  {

	  }


}   // do_rect_flash

//  Not an elipse...
//  Just an x1,y1 to x2,y2 flash of diam round = min ( x_dimen, y_dimen)
//  
void do_obround_flash( double x_dimen, int y_dimen, 
					   double x_hole_dimen, double y_hole_dimen,
					   double xloc, double yloc)
{

double begin_x;
double begin_y;
double end_x;
double end_y;

 if (x_dimen < y_dimen)  // vertical flash
	{

	 begin_x = xloc;
	 begin_y = yloc - (( y_dimen - x_dimen)/2.0);

	 end_x = xloc;
	 end_y = yloc + (( y_dimen - x_dimen )/2.0);


	fprintf(outfile,"2 ClrSet\n");

	fprintf(outfile,"%f %f\n", begin_x, begin_y); // begin
    fprintf(outfile,"%f %f\n", end_x, end_y); // end

    fprintf(outfile,"2\n");
    fprintf(outfile,"1\n");
	fprintf(outfile,"%f\n", x_dimen/2.0);

    fprintf(outfile,"PthOut\n");

    if ( x_hole_dimen != 0.0)
	 {
		 if (y_hole_dimen != 0.0 )  // rectangle hole
		 {
		  fprintf(outfile,"Bknd setrgbcolor\n");
          fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/2.0)+yloc); // rt
          fprintf(outfile,"%f %f\n", (x_hole_dimen/-2.0)+xloc, (y_hole_dimen/2.0)+yloc); // lt
          fprintf(outfile,"%f %f\n", (x_hole_dimen/-2.0)+xloc, (y_hole_dimen/-2.0)+yloc); // lb
		  fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/-2.0)+yloc); // rb
          fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/2.0)+yloc); // rt
		  fprintf(outfile,"5\n");
		  fprintf(outfile,"0\n-1\n1\n1\n");
		  fprintf(outfile,"BoundOut\n");

		 }
		else   // circular hole
		{
		  fprintf(outfile,"Bknd setrgbcolor\n");
          fprintf(outfile,"%f %f %f \n", xloc, yloc, x_hole_dimen); // rt
         
		  fprintf(outfile,"0\n-1\n1\n1\n");
		  fprintf(outfile,"CircOut\n");
          
        }
	 }

 }
 else    // horizontal flash
 {

     begin_x = xloc - (( x_dimen - y_dimen)/2.0);
	 begin_y = yloc;

	 end_x = xloc + (( x_dimen - y_dimen)/2.0);
	 end_y = yloc ;


	fprintf(outfile,"2 ClrSet\n");

	fprintf(outfile,"%f %f\n", begin_x, begin_y); // begin
    fprintf(outfile,"%f %f\n", end_x, end_y); // end

    fprintf(outfile,"2\n");
    fprintf(outfile,"1\n");
	fprintf(outfile,"%f\n", y_dimen/2.0);

    fprintf(outfile,"PthOut\n");

    if ( x_hole_dimen != 0.0)
	 {
		 if (y_hole_dimen != 0.0 )  // rectangle hole
		 {
		  fprintf(outfile,"Bknd setrgbcolor\n");
          fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/2.0)+yloc); // rt
          fprintf(outfile,"%f %f\n", (x_hole_dimen/-2.0)+xloc, (y_hole_dimen/2.0)+yloc); // lt
          fprintf(outfile,"%f %f\n", (x_hole_dimen/-2.0)+xloc, (y_hole_dimen/-2.0)+yloc); // lb
		  fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/-2.0)+yloc); // rb
          fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/2.0)+yloc); // rt
		  fprintf(outfile,"5\n");
		  fprintf(outfile,"0\n-1\n1\n1\n");
		  fprintf(outfile,"BoundOut\n");

		 }
		else   // circular hole
		{
		  fprintf(outfile,"Bknd setrgbcolor\n");
          fprintf(outfile,"%f %f %f \n", xloc, yloc, x_hole_dimen); // rt
         
		  fprintf(outfile,"0\n-1\n1\n1\n");
		  fprintf(outfile,"CircOut\n");
          
        }
	 }
	

 }
	

}   // do_obround_flash

void do_circle_flash( double diam, int x_hole_dimen, 
					   double y_hole_dimen, 
					   double xloc, double yloc)
{


	 if ( x_hole_dimen != 0.0)
	 {
		 if (y_hole_dimen != 0.0 )  // rectangle hole
		 {
		  fprintf(outfile,"2 ClrSet\n");

       	  fprintf(outfile,"%f %f %f \n", xloc, yloc, (diam/2.0) ); // 
    
          fprintf(outfile,"1\n-1\n1\n1\n");
          fprintf(outfile,"CircOut\n");

		  fprintf(outfile,"Bknd setrgbcolor\n");
          fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/2.0)+yloc); // rt
          fprintf(outfile,"%f %f\n", (x_hole_dimen/-2.0)+xloc, (y_hole_dimen/2.0)+yloc); // lt
          fprintf(outfile,"%f %f\n", (x_hole_dimen/-2.0)+xloc, (y_hole_dimen/-2.0)+yloc); // lb
		  fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/-2.0)+yloc); // rb
          fprintf(outfile,"%f %f\n", (x_hole_dimen/2.0)+xloc, (y_hole_dimen/2.0)+yloc); // rt
		  fprintf(outfile,"5\n");
		  fprintf(outfile,"0\n-1\n1\n1\n");
		  fprintf(outfile,"BoundOut\n");

		 }
		else   // circular hole, donut 
		{
		  if ( x_hole_dimen <  diam )
		  {
       	   fprintf(outfile,"%f %f %f 0.0 360.0 \n", xloc, yloc, (diam/2.0) ); // 
    
		   fprintf(outfile,"%f\n", x_hole_dimen/2.0 );
           fprintf(outfile,"0\n");
           fprintf(outfile,"ArcOut\n");
		  }
		  else
		  {
			  printf("Circle flash with circular hole larger than flash \n");
		  }

          
        }
	 }
	else   // no hole, just do the circular flash
	  {
          fprintf(outfile,"2 ClrSet\n");
       	  fprintf(outfile,"%f %f %f \n", xloc, yloc, (diam/2.0) ); // 
    
          fprintf(outfile,"1\n-1\n1\n1\n");
          fprintf(outfile,"CircOut\n");

	  }


}   // do_circ_flash

// 
//  G36, G37 style area fill
//
do_polygon_area_fill( int number_points )
{
int i;

  i = 0;

   fprintf(outfile,"2 ClrSet\n");

   while(i < number_points)
   {

    fprintf(outfile,"%f %f\n", xy_array[i].xval, xy_array[i].yval) ; // rt

	i += 1;

   }

   fprintf(outfile,"%d\n",number_points+1);
   fprintf(outfile,"1\n-1\n1\n1\n");
   fprintf(outfile,"BounOut\n");


}   // do_polygon_area_fill

// 
//  Do solid lines from x,y  to x,y         coordinant in xy_array
//
do_solid_lines( int number_points, double line_width )
{
int i;

  i = 0;

   fprintf(outfile,"2 ClrSet\n");

   while(i < number_points)
   {

    fprintf(outfile,"%f %f\n", xy_array[i].xval, xy_array[i].yval) ; // rt

	i += 1;

   }

   fprintf(outfile,"%d\n",number_points+1);
   fprintf(outfile,"%f\n", line_width);
   fprintf(outfile,"1\n");
   fprintf(outfile,"PthOut\n");


}   // do_solid_lines



/*
int main( int argc, char **argv)
{

	if (argc != 5)
	{

       printf("In parse_bga, wrong number of arguments \n");
	   printf("Usage: parse_bga mytype smoffset bgaoffset infile \n");
	   exit(-1);

	}
	else
	{
		parse_bga_call( argv[1], atof(argv[2]), atof(argv[3]), argv[4]);
	}

}   // end main

  */

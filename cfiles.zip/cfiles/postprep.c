#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>


#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// postprep
//      requires executable tar zip cp mv rm
//
// created 8-31-99
// Clean up after panelization and re-arrange data for MDB release
// Supports substrates - the only thing that needs panelization
// Runs in current directory

// updated 9-15-99
// Place all top-level text files in general-info
// Place some text files in mfg
// Delete all CD-based source files
// Place all CD-bound result files in archive directory
// stiffener, adhesive stuff goes to archive directory

// updated 9-16-99
// place OFFSETS in general-info, needed for spins
// Add more verbiage at beginning and end

// updated 9-24-99
// added check that redundant control files are alike
// deletes one of them if they are alike, exits if they are not

// updated 10-22-99
// delete the makelog file from top level
// Version 0.2

// Updated 5-14-01
// Use fixed target area of /home/.../staging
// Assume there is a release-able RDB structure in target area
// Copies data instead of overwriting
// Clean up History updates
// Handles all subassemblies
// Assumes a source work area set up by scripts
// Version 0.3

// Updated 5-17-01
// Fix problem that excluded test from archive
// Fix problem with not found history file
// Version 0.31

// Updated 8-31-01
// Read .stagingpath file for staging path / allow entry of staging path
// Fix check for stiffener vendor drawing
// Improve handling of adhesive path names

// Updated 11-13-01
// Remove stencil folder to reduce confusion 
// Compare duplicated files 


// UPGRADES NEEDED:
// Deal correctly with stiffener vendor drawing
// full support of non-substrate assemblies
// Look for evidence of abnormal Xpan run, exit if found

// dependancies:  mv cp tar rm chmod gzip
//      
//
int postprep_call( )
{
char REV[40];
char REVB[40];
char ECO[100];
char username[200];
char offfile[300];
char *today;
char timestamp[60];
char spath[300];
char fromfilestr[300];
char tofilestr[300];
char checkstr[300];
char checkfilestr[300];
char checkfile2str[300];
char checkdirstr[300];
char targetfilestr[300];
char dirstr[300];
char makedirstr[300];
char stpath[300];
char spathfilestr[300];
char notestok[50];
char commandstr[400];
char rmfilestr[300];
char systemstr[300];

char rdbpath[300];
char target[300];
char validsource[100];
char sourcepath[300];
char rboardpath[300];
char brdnum[300];
char validtarg[300];
char adnum[300];
int anydiff;
int ctldiff;
int cddiff;
int offdiff;
int ecowidth;
int pnwidth;
int revwidth;

int numrisfiles;
char oldpn[300];
char newpn[300];
char ardnum[300];
int testfolder;
char pp[10];
char adpath[300];
char adsource[100];
char thisline[300];
char stifpath[300];
char stagingstr[300];
char stagingstr1[300];

int gifiles;
int endoffile;
int ii;
char file1str[300];
char file2str[300];
char lidpath[300];
char tfile[300];
char newname[300];
char newnamelo[300];
char camfilestr[300];
char nadpath[300];
char teststring[300];
char working_dir[300];
int dresult;
int tfilecount;
char *homestr;
int offcount;
int adfilecount;
int postcount;
int biascount;
int filecount;
char wdstr[300];
char mdrivestr[300];
int stiffiles;
int routfiles;

FILE *historytxtfile;
FILE *pathhistfile;
FILE *spathfile;
int risfilecount;
int madcount;
int lidcount;
int stencilcount;

int zipstat;

 strncpy(REV,"0.33",10);

if (WINDOWS)
{
	strncpy(dirsep,"\\",6);
}
else
{
	strncpy(dirsep,"/",4);
}

// Check for correct invocation

 get_whoami(username);  // =$(whoami)
// today=$(date '+%m/%d/%y')
 today=gettime_str();

 if ( get_month_number(monthstr) > 9 )  // 10, 11, 12
   {
   _snprintf(timestamp,60,"%d/%s/%c%c",get_month_number(monthstr),daystr,
	                       yearstr[2],yearstr[3]);
   }
   else
   {
    _snprintf(timestamp,60,"0%d/%s/%c%c",get_month_number(monthstr),daystr,
	                       yearstr[2],yearstr[3]);
   }

// sedtoday=$(date '+%m\/%d\/%y')
//   target=/home/$username/staging


printf( "****** POSTPREP: Post-Panelization Release & Archive Preparation ****** \n");
printf( "Creates a release-able mdb structure in the same staging directory as \n");
printf( "the rdb structure created by rdb-relprep. Copies data from a directory \n");
printf( "where makepanel was just run.\n");
printf( "***********************************************************************\n");
printf( " \n");

homestr=getenv("HOME");              // $HOME/.stagingpath
strncpy(checkfilestr,homestr,120);
strncat(checkfilestr,dirsep,10);
strncat(checkfilestr,".stagingpath",30);

  if ( ! file_exists( checkfilestr ) )    // no .staging file
  {
    strncpy(pp,"n",10);
  }
  else
  {
  
   strncpy(spathfilestr,homestr,160);
   strncat(spathfilestr,dirsep,10);
   strncat(spathfilestr,".stagingpath",30);

   spathfile=fopen(spathfilestr,"r");
   if (spathfile == NULL)
	{
		printf("Unable to open the %s file for reading \n",spathfilestr);
		exit(-1);
	}
	endoffile=getline(spathfile,thisline);

	strncpy(spath,thisline,120);

    fclose(spathfile);

	printf("pathfile from $HOME\\.stagingpath= %s \n",spath);


    if ( ! (file_exists( spath ) ) )
    {
      strncpy(pp,"n",10);
    }
    else
    {
      while( (strcmp(pp,"y") != 0 ) && (strcmp(pp,"n") != 0 ) )
      {
         printf( "Is %s the target staging path to use? (y/n)  \n",spath);
         gets(pp);
      }
	}
  }


strncpy(validtarg,"",10);

if ( strcmp(pp,"n") == 0 )           // $pp = n )
{
   getwd(wdstr);

   get_full_path_end(wdstr, brdnum);

   strncpy(mdrivestr,wdstr,200);

   get_full_path_begin( wdstr, stagingstr1);
   get_full_path_begin( stagingstr1, stagingstr);


   //strncpy(mdrivestr,"m:/design/staging_temp/staging_",120);
  
   printf("The target staging directory is now %s, is this ok? \n",stagingstr);
   printf(" Answer yes or no? \n");

   while((strcmp(validtarg,"yes")!=0) && ( strcmp(validtarg,"no")!=0 ))
   {
	   gets(validtarg);
   }
   if (strcmp(validtarg,"yes")!= 0 )
   {
    while( strcmp(validtarg,"yes") != 0 )
    {
      printf( "Enter the full target staging path name:\n");
      gets(target);
      if ( dir_exists( target ) )
      {
         //validtarg="yes"
		  strncpy(validtarg,"yes",10);

	  }
      else
	  {
         printf( "Your entry is not an existing directory!\n");
      }
    }
   }
   else   // yes ot validtarg
   {
	   strncpy(target,stagingstr,200);
   }

}
else
{
   //target=$spath
	strncpy(target,spath,160);

}

//rdbpath=$target/rdb

strncpy(rdbpath,target,200);  //$target/rdb
strncat(rdbpath,dirsep,10);
strncat(rdbpath,"rdb",10);


// Check for existence of needed folders
if ( ! (dir_exists( target ) ) )
{
   printf( "Staging directory %s does not exist. Exiting!\n",target);
   exit(-1);
}
if ( ! (dir_exists( rdbpath ) ) )
{
   printf( "Staging directory %s does not contain an rdb folder. Exiting!\n",rdbpath);
   exit(-1);
}
strncpy(checkdirstr,target,120);
strncat(checkdirstr,dirsep,10);
strncat(checkdirstr,"mdb",10);

if ( dir_exists(checkdirstr) )          // -d target/mdb )
{
   printf( "%s%smdb directory already present. Delete before re-running.\n", target,dirsep);
   exit(-1);
}

// Get and validate source path
// validsource="no"

getwd(wdstr);    // get the current working directory

strncpy(sourcepath,wdstr,200);


strncpy(validsource,"",5);

printf("The camjob source directory is %s \n", sourcepath);
printf("Is this where your source files are? Enter yes or no \n");

while((strcmp(validsource,"yes")!= 0 ) && (strcmp(validsource,"no")!=0))
{
  gets(validsource);
  
}


if (strcmp(validsource,"no")==0 )
{

  while( strcmp(validsource,"yes" ) != 0 )
  {
   printf( "Enter the full path name of the panelized data (ending in board number):\n");
   gets(sourcepath);
   if ( dir_exists( sourcepath ) )
   {
     // validsource="yes"
	   strncpy(validsource,"yes",10);
   }
  }
}

// Validate source path
 // brdnum=${sourcepath##*/}

 get_full_path_end( sourcepath, brdnum);


strncpy(checkfilestr,sourcepath,120);  // $sourcepath/control/$brdnum.ctl
strncat(checkfilestr,dirsep,10);
strncat(checkfilestr,"control",30);
strncat(checkfilestr,dirsep,10);
strncat(checkfilestr,brdnum,50);
strncat(checkfilestr,".ctl",10);

if ( ! file_exists(checkfilestr) )
{
   printf( "Path contains no control file control%s%s.ctl\n",dirsep,brdnum);
   exit(-1);
}

// Verify that the rdb structure in the target path is for the same part
//rboardpath=$rdbpath/board/$brdnum
strncpy(rboardpath,rdbpath,160);
strncat(rboardpath,dirsep,10);
strncat(rboardpath,"board",10);
strncat(rboardpath,dirsep,10);
strncat(rboardpath,brdnum,100);

if ( ! (dir_exists(rboardpath ) ) )
{
   printf( "ERROR! Staging area does not include rdb%sboard%s%s! Exiting!\n",
	   dirsep,dirsep,brdnum);
   printf(" staging path = %s \n",rdbpath);
   exit(-1);
}

printf( "Your mdb structure will be created in  %s\n",target);

//############# look for post-bias files in source area, exit if missing

strncpy(camfilestr,sourcepath,120);  // $sourcepath/cam
strncat(camfilestr,dirsep,10);
strncat(camfilestr,"cam",10);

filecount=scandir_matchall( camfilestr,0);

postcount=0;
biascount=0;
for(ii=0;ii < filecount; ii += 1)
{

	strncpy(teststring,scan_array[ii],20);
	teststring[4]='\0';
	if ((strcmp( teststring,"POST")== 0 ) || (strcmp( teststring,"post")==0))
	{
		postcount += 1;
	}
   if ((strcmp( teststring,"bias")== 0 ) || (strcmp( teststring,"BIAS")==0))
	{
		biascount += 1;
	}

}


if ( ( biascount == 0 ) || ( postcount == 0 ) )
{
   printf( "Can't find post-bias info in %s%scam folder. Exiting.\n",sourcepath,dirsep);
   exit(-1);
}




//###############################  Duplicate file checking  #######################
// Case-shift offsets file name   
//  may not be necessary in windows
//offlist=$(ls $sourcepath/brd_info 2>/dev/null)
strncpy(fromfilestr,sourcepath,160);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"brd_info",20);

offcount=scandir_matchall( fromfilestr,0);  // get files to scan_array

ii=0;
while( ii < offcount)   // offfile in $offlist
{
	strncpy(offfile,scan_array[ii],120);

	strncpy(checkfilestr,sourcepath,120);  
	strncat(checkfilestr,dirsep,10);
	strncat(checkfilestr,"brd_info",20);
	strncat(checkfilestr,dirsep,10);
	strncat(checkfilestr,offfile,100);

   if ( file_exists( checkfilestr) )  // -f $sourcepath/brd_info/$offile )
   {
      //newname=$offfile
	   strncpy(newname,offfile,200);

      //typeset -l newname
	  cv_tolower(newname, newnamelo);

      if ( strcmp(offfile,newnamelo ) != 0 )  // was in upper case
      {
		 strncpy(fromfilestr,sourcepath,120);  // $sourcepath/brd_info/$offfile
		 strncat(fromfilestr,dirsep,10);
		 strncat(fromfilestr,"brd_info",15);
		 strncat(fromfilestr,dirsep,10);
		 strncat(fromfilestr,offfile,60);

         strncpy(tofilestr,sourcepath,120);  // $sourcepath/brd_info/$newname
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,"brd_info",15);
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,newnamelo,60);

		// _snprintf(systemstr,300,"rename %s %s ",fromfilestr,tofilestr);
		 rename( fromfilestr, tofilestr);

         // mv $sourcepath/brd_info/$offfile $sourcepath/brd_info/$newname
		 //system(systemstr);
		 //rm_file(fromfilestr);
     }
  }
 ii +=1;
}
printf(" \n");
printf("Checking duplicate files.......... \n");

strncpy(file1str,rdbpath,120);  // $rdbpath/board/$brdnum/control/$brdnum.ctl
strncat(file1str,dirsep,10);
strncat(file1str,"board",15);
strncat(file1str,dirsep,10);
strncat(file1str,brdnum,60);
strncat(file1str,dirsep,10);
strncat(file1str,"control",15);
strncat(file1str,dirsep,10);
strncat(file1str,brdnum,60);
strncat(file1str,".ctl",10);

strncpy(file2str,sourcepath,120);  // $sourcepath/control/$brdnum.ctl
strncat(file2str,dirsep,10);
strncat(file2str,"control",15);
strncat(file2str,dirsep,10);
strncat(file2str,brdnum,60);
strncat(file2str,".ctl",10);

//diff -w $rdbpath/board/$brdnum/control/$brdnum.ctl $sourcepath/control/$brdnum.ctl  >/dev/null 2>/dev/null
//ctldiff=$?
ctldiff=diff_files( file1str, file2str);


if (ctldiff != 0)
{
   printf("\nPROBLEM! Control files different in rdb and camjob areas.\n");
   printf("control file in %s is different than the control in %s \n",file1str,file2str);
  // exit(-1);
}

strncpy(file1str,rdbpath,120);  // $rdbpath/board/$brdnum/cd.txt
strncat(file1str,dirsep,10);
strncat(file1str,"board",15);
strncat(file1str,dirsep,10);
strncat(file1str,brdnum,60);
strncat(file1str,dirsep,10);
strncat(file1str,"cd.txt",15);

strncpy(file2str,sourcepath,120);  // $sourcepath/cd.txt 
strncat(file2str,dirsep,10);
strncat(file2str,"cd.txt",15);

//diff -w $rdbpath/board/$brdnum/cd.txt $sourcepath/cd.txt >/dev/null 2>/dev/null
//cddiff=$?
cddiff=diff_files( file1str, file2str);

if (cddiff != 0)
{
   printf( "\nPROBLEM! cd.txt files different in rdb and camjob areas.\n");
   printf("file in %s is different from %s \n", file1str,file2str);
}


strncpy(file1str,rdbpath,120);  // $rdbpath/board/$brdnum/report/offsets
strncat(file1str,dirsep,10);
strncat(file1str,"board",15);
strncat(file1str,dirsep,10);
strncat(file1str,brdnum,60);
strncat(file1str,dirsep,10);
strncat(file1str,"report",15);
strncat(file1str,dirsep,10);
strncat(file1str,"offsets",20);

strncpy(file2str,sourcepath,120);  // $sourcepath/brd_info/offsets
strncat(file2str,dirsep,10);
strncat(file2str,"brd_info",15);
strncat(file2str,dirsep,10);
strncat(file2str,"offsets",20);

//diff -w $rdbpath/board/$brdnum/report/offsets $sourcepath/brd_info/offsets  >/dev/null 2>/dev/null
//ffdiff=$?
offdiff=diff_files(file1str,file2str);
if (offdiff != 0)
{
   printf( "\nPROBLEM! offsets files different in rdb and camjob areas.\n");
   printf(" file in %s is different than in %s \n", file1str, file2str);
}
anydiff = ctldiff + cddiff + offdiff;
if (anydiff != 0)
{
   printf( "Exiting! \n");
   exit(-1);
}
else
{
   printf( "Duplicate files OK.\n");
}
//##########################  End duplicate checking ##############################

strncpy(commandstr,"cp -p -R ",30);
strncat(commandstr, sourcepath,120);
strncat(commandstr," ",4);
strncat(commandstr,  target, 120);
system(commandstr);

//cd $target
printf("Changing directory to %s \n",target);

change_dir(target);

mkdir("mdb");

strncpy(tofilestr,"mdb",10);  // mdb/$brdnum
strncat(tofilestr,dirsep,10);
strncat(tofilestr,brdnum,120);

strncpy(commandstr,"mv ",10);
strncat(commandstr,brdnum,100);
strncat(commandstr," ",4);
strncat(commandstr,tofilestr,100);

//mv $brdnum mdb
//cp_file(brdnum,tofilestr);  // cp $brdnum mdb/$brdnum
printf("%s \n", commandstr);

system(commandstr);    // mv $brdnum mdb/$brdnum

strncpy(commandstr,"rm -r -f ",20);
strncat(commandstr,brdnum,120);

system(commandstr);   // rm -r -f $brdnum

system("chmod 777 mdb");

printf("Change to mdb directory \n");

change_dir("mdb"); //  mdb

// Get rid of unnecessary files
strncpy(targetfilestr,target,120);  // $target/mdb
strncat(targetfilestr,dirsep,10);
strncat(targetfilestr,"mdb",10);

filecount=scandir_matchext(targetfilestr,0,".pdf");  // get all .pdf files in dir

printf("Remove mdb\\auto*.pdf files \n");

for(ii=0; ii < filecount; ii += 1)
{
  strncpy(teststring,scan_array[ii],120);
  teststring[4]='\0';
  if (strcmp( teststring,"auto") == 0 )   // auto*.pdf
  {
	  strncpy(rmfilestr,targetfilestr,120);
	  strncat(rmfilestr,dirsep,10);
	  strncat(rmfilestr,scan_array[ii],120);

	  printf("Deleting %s \n",scan_array[ii]);

	  rm_file( rmfilestr);             // rm $target/mdb/auto*.pdf
  }

}


filecount=scandir_matchext(targetfilestr,0,".mcm");  // get all .mcm files in dir
printf("Remove mdb\\*.mcm files \n");

for(ii=0; ii < filecount; ii += 1)
{
  
	  strncpy(rmfilestr,targetfilestr,120);
	  strncat(rmfilestr,dirsep,10);
	  strncat(rmfilestr,scan_array[ii],120);
      printf("Deleting %s \n",scan_array[ii]);
	  rm_file( rmfilestr);             // rm $target/mdb/*.mcm
}


// history stuff
// Pad lengths of text strings

strncpy(REVB,"0",10);
strncpy(ECO,"n/a",10);
// ECO="n/a"
revwidth=6;
pnwidth=13;
ecowidth=7;
strncpy(oldpn,"",10);
strncpy(newpn,brdnum,14);

//typeset -L$revwidth REVB
//typeset -L$pnwidth oldpn
//typeset -L$pnwidth newpn
//typeset -L$ecowidth ECO

printf("About to copy history.txt file \n");

//dos2ux $rdbpath/board/$brdnum/history.txt > brd.tmp
//fprintf(brdtmpfile,"%s  %s%s%s%s Post-Processed & released to MDB\n",
//	    today, REVB, oldpn, newpn,ECO );  // >> brd.tmp
//ux2dos brd.tmp > history.txt
strncpy(fromfilestr,rdbpath,120);  // $rdbpath/board/$brdnum/history.txt 
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"board",15);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,brdnum,100);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"history.txt",20);

printf(" cp history text from %s \n", fromfilestr);

cp_file(fromfilestr,"history.txt");

printf("About to open history.txt \n");

historytxtfile = fopen("history.txt","a");

if ( historytxtfile != NULL)
{
fprintf(historytxtfile,"%s  %-6s%-13s%-13s%-7sPost-Processed & released to MDB\n",
	    timestamp, REVB, oldpn, newpn,ECO );  // >> brd.tmp
fclose(historytxtfile);

}
else
{
	printf("Unable to open the history.txt file for apend \n");
}

printf("Done with history.txt \n");

// Create the test data
// Case-shift file names

change_dir(brdnum);

system("chmod 777 test");

change_dir("test");

system("chmod 777 *");

change_dir("..");


// tlist=$(ls test 2>/dev/null)
tfilecount=scandir_matchall( "test",0);

ii=0;

while( ii < tfilecount)    // tfile in $tlist
{
	strncpy(tfile,scan_array[ii],120);

	strncpy(checkfilestr,"test",10);   // test/$tfile
	strncat(checkfilestr,dirsep,10);
	strncat(checkfilestr,tfile,120);

   if ( file_exists( checkfilestr) )    // -f test/$tfile )
   {
      //newname=tfile
	  strncpy(newname,tfile,120);
	  cv_tolower(newname,newnamelo);

     // typeset -l newname

      if ( strcmp(tfile,newnamelo ) != 0 )
      {
		  strncpy(fromfilestr,"test",10);  // test/$tfiles
		  strncat(fromfilestr,dirsep,10);
		  strncat(fromfilestr,tfile,120);

          strncpy(tofilestr,"test",10);    // $test/newname
		  strncat(tofilestr,dirsep,10);
		  strncat(tofilestr,newname,120);

         //mv test/$tfile test/$newname
		  cp_file(fromfilestr,tofilestr);
		  rm_file(fromfilestr);
     }
  }
 ii += 1;
}
testfolder=0;
// rislist=$(ls test/*.ris 2>/dev/null)


risfilecount=scandir_matchext("test",0,".ris");

numrisfiles=risfilecount;

//for xx in $rislist
//{
//   numrisfiles = numrisfiles + 1;
//}
if (numrisfiles == 0)
{
   strncpy(notestok,"",10);

   printf( "PROBLEM! No test/.ris files in test directory!\n");
   while( (strcmp(notestok,"y") != 0 ) && (strcmp(notestok,"n") != 0 ) )
   {
      printf("If this is OK, type y. Otherwise type n: \n");
      gets(notestok);
   }
   if ( strcmp(notestok,"n") == 0 ) 
   {
      printf( "Place at least one .ris file in the test directory!\n");
      exit(-1);
   }
}
else if(numrisfiles == 1)
{
  //risfn=$(ls test/$brdnum.ris 2>/dev/null)

   //isris=$?
	strncpy(checkfilestr,"test",10);  // test/$brdnum.ris
	strncat(checkfilestr,dirsep,10);
	strncat(checkfilestr,brdnum,160);
	strncat(checkfilestr,".ris",10);

   if ( ! ( file_exists( checkfilestr) ) )
   {
      printf( ".ris file mis-named in test directory. Should be %s.ris \n",brdnum);
  }
   testfolder=0;
}
else
{
   testfolder=1;
}

// Handle redundant control files

strncpy(checkfilestr,"brd_info",20);  // brd_info/$brdnum.ctl
strncat(checkfilestr,dirsep,10);
strncat(checkfilestr,brdnum,120);
strncat(checkfilestr,".ctl",10);

strncpy(checkfile2str,"control",20);  // control/$brdnum.ctl
strncat(checkfile2str,dirsep,10);
strncat(checkfile2str,brdnum,120);
strncat(checkfile2str,".ctl",10);

if ( file_exists(checkfilestr) && file_exists( checkfile2str ) )
{
   dresult=diff_files( checkfilestr , checkfile2str ); // >/dev/null
   
   if (dresult == 0)
   {
       strncpy(fromfilestr,"brd_info",20);  // brd_info/$brdnum.ctl
	   strncat(fromfilestr,dirsep,10);
	   strncat(fromfilestr,brdnum,120);
	   strncat(fromfilestr,".cntl",10);
	   rm_file( fromfilestr); 
      //rm -f brd_info/$brdnum.ctl
   }
   else
   {
      printf( "PROBLEM! Control files different in brd_info and control directories.\n");
      exit(-1);
  }
}
else
{
   if ( ! (file_exists( checkfile2str) )   )      // -a control/$brdnum.ctl  
   {
	   getwd(working_dir);
      printf( "Potential problem with missing control file(s). Check control directory.\n");
	  printf("Working directory = %s  checking %s \n",working_dir,checkfile2str);
      exit(-1);
  }
}

printf("Removing artwork files \n");

strncpy(commandstr,"rm -f ",10);
strncat(commandstr,"artwork",20);
strncat(commandstr,dirsep,10);
strncat(commandstr,"*",4);            // rm -f artwork/*  
system(commandstr);

          // rm -f mfg/stiff.* 
printf("Removing mfg and mech files \n");

rm_all_base("mfg","stiff.");

// rm -f mech/stiff.* 

rm_all_base("mech","stiff.");

// rm -f mech/stiff.* 


rm_all_base( "mfg","stencil.");

// rm -f mfg/stencil.* 
strncpy(commandstr,"rm -f ",10);
strncat(commandstr,"aper",20);
strncat(commandstr,dirsep,10);
strncat(commandstr,"*.prt",10);            // rm -f aper/*.prt
system(commandstr);

printf("Removing aper files \n");

//rm -f aper/*.prt
strncpy(commandstr,"rm -f ",10);
strncat(commandstr,"control",20);
strncat(commandstr,dirsep,10);
strncat(commandstr,"pcm.txt",14);            // rm -f control/pcm.txt
system(commandstr);

printf("Removing commandstr files \n");
// rm -f control/pcm.txt
strncpy(commandstr,"rm -f ",10);
strncat(commandstr,"brd_info",20);
strncat(commandstr,dirsep,10);
strncat(commandstr,"*.ctl",14);            // rm -f brd_info/*.ctl
system(commandstr);

// rm -f  brd_info/*.ctl
printf("Removing control files \n");

strncpy(fromfilestr,"control",15);    // control/$brdnum.ctl
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,brdnum,120);
strncat(fromfilestr,".ctl",10);

strncpy(tofilestr,"mfg",10);    // mfg/$brdnum.ctl
strncat(tofilestr,dirsep,10);
strncat(tofilestr,brdnum,120);
strncat(tofilestr,".ctl",10);

//cp -p control/$brdnum.ctl mfg
printf("copy control/%s.ctl file to mfg dir \n",brdnum);

cp_file(fromfilestr,tofilestr);

strncpy(fromfilestr,"aper",10);  // aper/$brdnum.apt
strncat(fromfilestr,dirsep,4);
strncat(fromfilestr,brdnum,120);
strncat(fromfilestr,".apt",10);

strncpy(commandstr,"mv ",10);
strncat(commandstr,fromfilestr,150);
strncat(commandstr," mfg",10);

printf("move  aper/%s.apt file to mfg dir \n",brdnum);
system(commandstr);

//mv aper/$brdnum.apt mfg
printf("cp  aoi/*.gbx files to mfg dir \n");

cp_files_ext("aoi",".gbx","mfg");

rm_all_ext("aoi",".gbx");

// mv aoi/*.gbx mfg

printf("cp  *.txt files to mfg dir \n");

// Place text files
strncpy(tofilestr,"mfg",10);    // mfg/align.txt
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"align.txt",20);

cp_file("align.txt", tofilestr);

strncpy(tofilestr,"mfg",10);     // mfg/parts.txt
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"parts.txt",20);

cp_file("parts.txt", tofilestr);

strncpy(tofilestr,"mfg",10);     // mfg/step.txt
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"step.txt",20);

cp_file("step.txt", tofilestr);

strncpy(tofilestr,"mfg",10);    // mfg/layers.txt
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"layers.txt",20);

cp_file("layers.txt", tofilestr);

strncpy(tofilestr,"mfg",10);    // mfg/singulate.txt
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"singulate.txt",30);

cp_file("singulate.txt", tofilestr);

strncpy(tofilestr,"mfg",10);    // mfg/$brdnum.hist
strncat(tofilestr,dirsep,10);
strncat(tofilestr,brdnum,120);
strncat(tofilestr,".hist",10);

cp_file("history.txt", tofilestr);
rm_file("history.txt");

mkdir("general-info");
printf("cp  *.txt files to new general-info dir \n");

system("mv *.txt general-info");

strncpy(camfilestr,".",10);   // ./cam
strncat(camfilestr,dirsep,10);
strncat(camfilestr,"cam",10);

filecount=scandir_matchall( camfilestr,0);   // get all files in cam directory

for(ii=0;ii < filecount; ii += 1)
{

	strncpy(teststring,scan_array[ii],20);
	teststring[4]='\0';
	if ((strcmp( teststring,"POST")== 0 ) || (strcmp( teststring,"post")==0))
	{
		
		strncpy(fromfilestr,camfilestr,40);  //   ./cam/$i
		strncat(fromfilestr,dirsep,10);
		strncat(fromfilestr,scan_array[ii],120);

        strncpy(tofilestr,"general-info",30);      //general-info/$i
        strncat(tofilestr,dirsep,10);
        strncat(tofilestr,scan_array[ii],120);

		cp_file(fromfilestr,tofilestr);

	}
   if ((strcmp( teststring,"bias")== 0 ) || (strcmp( teststring,"BIAS")==0))
	{
		strncpy(fromfilestr,camfilestr,40);   // ./cam/$i
		strncat(fromfilestr,dirsep,10);
		strncat(fromfilestr,scan_array[ii],120);

        strncpy(tofilestr,"general-info",30);    // general-info/$i
        strncat(tofilestr,dirsep,10);
        strncat(tofilestr,scan_array[ii],120);

		cp_file(fromfilestr,tofilestr);

	}

}

printf("cp  brd_info/min_clearance.txt file to general-info dir \n");

strncpy(fromfilestr,"brd_info",12);  // brd_info/min_clearance.txt
strncat(fromfilestr,dirsep,6);
strncat(fromfilestr,"min_clearance.txt",30);

strncpy(tofilestr,"general-info",30);  // general_info/min_clearance.txt
strncat(tofilestr,dirsep,6);
strncat(tofilestr,"min_clearance.txt",30);

if (file_exists(fromfilestr) )
{
 cp_file(fromfilestr,tofilestr);
}
else
{
	printf("No min_clearance.txt file \n");
}


// cp -p brd_info/min_clearance.txt general-info

strncpy(fromfilestr,"brd_info",12);  // brd_info/OFFSETS
strncat(fromfilestr,dirsep,6);
strncat(fromfilestr,"OFFSETS",30);

strncpy(tofilestr,"general-info",30);  // general_info/OFFSETS
strncat(tofilestr,dirsep,6);
strncat(tofilestr,"OFFSETS",30);

printf("cp  brd_info/offsets file to general-info dir \n");

if (file_exists(fromfilestr))
{
  cp_file(fromfilestr,tofilestr);
}

//cp -p brd_info/OFFSETS general-info 2>/dev/null
strncpy(fromfilestr,"brd_info",12);  // brd_info/offsets
strncat(fromfilestr,dirsep,6);
strncat(fromfilestr,"offsets",30);

strncpy(tofilestr,"general-info",30);  // general_info/offsets
strncat(tofilestr,dirsep,6);
strncat(tofilestr,"offsets",30);

if (file_exists(fromfilestr) )
{
cp_file(fromfilestr,tofilestr);
}
// cp -p brd_info/offsets general-info 2>/dev/null


// Archive for all X-script result files
mkdir("archive");

printf("mv sub-directories to archive directory \n");

system("mv X* archive");

system("mv control archive");

system("mv scm archive");
system("mv 274x archive");
system("mv brd_info archive");
system("mv cam archive");

strncpy(commandstr,"rm -f ",10);  // rm -f pre-bias/*
strncat(commandstr,"pre-bias",15);
strncat(commandstr,dirsep,4);
strncat(commandstr,"*",4);

system(commandstr);   // rm -f pre-bias/*

//rm -f pre-bias/*  2>/dev/null

printf("Making makelog \n");

rm_file("makelog");

if ( ! dir_exists("rout" ) )
{
   mkdir("rout");
}
else
{
   system("cp -p -R rout archive");
}

printf("Moving mech/* to rout \n");

strncpy(commandstr,"mv ",10);  // mv mech/* rout
strncat(commandstr,"mech",10);
strncat(commandstr,dirsep,4);
strncat(commandstr,"*",4);
strncat(commandstr," rout",10);
system(commandstr); ///* rout

printf("Remove aper aoi artwork mech and prebias directories \n");
rmdir( "aper");
rmdir( "aoi");
rmdir("artwork");
rmdir( "mech" );
rmdir("prebias");

// Change permissions to allow librarian to take ownership

printf("Changing permission on directories \n");

system("chmod -R 777 *");

//chmod( 777,  "*/*");
//chmod( 777, "*/*/*");
//chmod( 777, "*/*/*/*"); //  2>/dev/null
//chmod( 777, "*/*/*/*/*"); //  2>/dev/null
//chmod( 777, "*/*/*/*/*/*"); // 2>/dev/null


// Now create the nested structure

printf("Creating the nested structure \n");

mkdir("artwork");

strncpy(dirstr,"artwork",12); // artwork/brdnum
strncat(dirstr,dirsep,10);
strncat(dirstr,brdnum,120);

mkdir( dirstr); //  artwork/$brdnum

// mv mfg/* artwork/$brdnum 2>/dev/null
printf("cp  mfg/* files to artwork/%s dir \n",brdnum);

strncpy(fromfilestr,"mfg",10);    // mfg/*
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"*",10);

strncpy(tofilestr,"artwork",20);  // artwork/$brdnum
strncat(tofilestr,dirsep,10);
strncat(tofilestr,brdnum,120);

strncpy(commandstr,"cp ",10);
strncat(commandstr,fromfilestr,160);
strncat(commandstr," ",4);
strncat(commandstr,tofilestr,160);

system(commandstr);

rmdir("mfg");
printf("make the  laser/src dir \n");

strncpy(makedirstr,"laser",15);  // laser/src
strncat(makedirstr,dirsep,10);
strncat(makedirstr,"src",10);

mkdir(makedirstr);     //  laser/src
printf("make the  laser/src/%s dir \n",brdnum);

strncpy(makedirstr,"laser",20);  // laser/src/$brdnum
strncat(makedirstr,dirsep,10);
strncat(makedirstr,"src",10);
strncat(makedirstr,dirsep,10);
strncat(makedirstr,brdnum,120);

mkdir(makedirstr);
// mkdir laser/src/$brdnum

//mv laser/* laser/src/$brdnum 2>/dev/null
printf("cp the  laser/*.* files to laser/src/%s dir \n",brdnum);

strncpy(fromfilestr,"laser",20);   // laser/*.*
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"*.*",10);

strncpy(tofilestr,"laser",20);       // laser/src/$brdnum
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"src",10);
strncat(tofilestr,dirsep,10);
strncat(tofilestr,brdnum,120);

strncpy(commandstr,"cp ",10);
strncat(commandstr,fromfilestr,120);
strncat(commandstr," ",4);
strncat(commandstr,tofilestr,160);

system(commandstr);

printf("Removing the laser directory \n");

system("rm -r -f laser");  // was rmdir laser

printf("Make the general-info/%s dir \n",brdnum);

strncpy(makedirstr,"general-info",30);  // general-info/$brdnum
strncat(makedirstr,dirsep,10);
strncat(makedirstr,brdnum,120);

// mkdir( makedirstr);    // general-info/$brdnum

printf("Move the general-info/* files to general-info/%s \n",brdnum);

strncpy(fromfilestr,"general-info",30);   // general-info/*


gifiles = scandir_matchall("general-info",0);

mkdir( makedirstr);
ii=0;
while(ii < gifiles)
{
	strncpy(fromfilestr,"general-info",40);
	strncat(fromfilestr,dirsep,10);
	strncat(fromfilestr,scan_array[ii],200);

	printf("Copy %s to %s \n", fromfilestr, tofilestr);

	strncpy(tofilestr,makedirstr,120);
	strncat(tofilestr,dirsep,10);
	strncat(tofilestr,scan_array[ii],200);

	cp_file(fromfilestr,tofilestr);
	rm_file(fromfilestr);
    ii += 1;
}


printf("Make the rout/%s dir \n",brdnum);

strncpy(makedirstr,"rout",10);   // rout/$brdnum
strncat(makedirstr,dirsep,10);
strncat(makedirstr,brdnum,120);

strncpy(fromfilestr,"rout",10);  // rout/*


routfiles = scandir_matchall(fromfilestr,0);

mkdir( makedirstr);   //   rout/$brdnum
ii=0;
while(ii < routfiles)
{

	strncpy(fromfilestr,"rout",30);
	strncat(fromfilestr,dirsep,5);
	strncat(fromfilestr,scan_array[ii],120);

    strncpy(tofilestr,makedirstr,120);
	strncat(tofilestr,dirsep,10);
	strncat(tofilestr,scan_array[ii],200);

	cp_file(fromfilestr,tofilestr);
	printf("Copy %s to %s \n", fromfilestr,tofilestr);
	rm_file(fromfilestr);

    ii +=1;

}



// Move the test data
mkdir("temp");

strncpy(fromfilestr,"test",10);  // test/*
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"*",10);

strncpy(commandstr,"cp -p ",10);    // cp -p test/* temp
strncat(commandstr,fromfilestr,120);
strncat(commandstr," temp",12);

system(commandstr);   // cp -p test/* temp

printf("Copy test directory to archive \n");

system("cp -p -R test archive");

strncpy(commandstr,"rm -f ",10);   // rm -f test/*
strncat(commandstr,fromfilestr,150);

system(commandstr); //  test/*

strncpy(makedirstr,"test",10);  // test/$brdnum
strncat(makedirstr,dirsep,10);
strncat(makedirstr,brdnum,120);

mkdir(makedirstr); // test/$brdnum

strncpy(fromfilestr,"temp",20);    // temp/*
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"*",10);

strncpy(commandstr,"mv ",10);          // mv temp/* test/$brdnum
strncat(commandstr,fromfilestr,160);
strncat(commandstr," ",4);
strncat(commandstr,makedirstr,160);

 system(commandstr);  // test/$brdnum


strncpy(fromfilestr,rboardpath,120);  //  $rboardpath/test/*.dat
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"test",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"*.dat",10);

strncpy(tofilestr,"test",10);          // test/$brdnum
strncat(tofilestr,dirsep,10);
strncat(tofilestr,brdnum,120);

strncpy(commandstr,"cp -p ",10);
strncat(commandstr,fromfilestr,160);
strncat(commandstr," ",4);
strncat(commandstr,tofilestr,160);

system(commandstr); //  $rboardpath/test/*.dat test/$brdnum

rmdir( "temp");


// Create archive
change_dir("archive");

system("tar cf archive.tar *" ); //  2>/dev/null

system("gzip archive.tar");   // probably doesn't work on dos
zipstat=0;
// zipstat=$?

//strncpy(dirstr,target,120); //  $target/mdb
//strncat(dirstr,dirsep,10);
//strncat(dirstr,"mdb",10);
// change_dir( dirstr); //  $target/mdb

change_dir("..");

if (zipstat == 0)
{
   //mv archive/archive.tar.gz general-info/$brdnum

	strncpy(fromfilestr,"archive",20);  // archive/archive.tar.gz
	strncat(fromfilestr,dirsep,10);
	strncat(fromfilestr,"archive.tar.gz",30);

	strncpy(tofilestr,"general-info",30); // general-info/$brdnum
	strncat(tofilestr,dirsep,10);
	strncat(tofilestr,brdnum,120);

	if (file_exists( fromfilestr) )
	{
	 strncpy(commandstr,"mv ",10);
	 strncat(commandstr,fromfilestr,160);
	 strncat(commandstr," ",4);
	 strncat(commandstr,tofilestr,160);

	 system(commandstr);  
	 rmdir("archive");   //  2>/dev/null
     printf( "Archive compressed and moved to general-info.\n");
     printf( "Done!!  Board MDB data almost ready to release.\n");
	}
	else
	{
		printf("PROBLEM!  archive.tar.gz not created \n");
		printf( "Problem with compression of archive data. Try manual compression.\n" );

	}

}
else
{
   printf( "Problem with compression of archive data. Try manual compression.\n" );

   strncpy(fromfilestr,"archive",30);   // archive/archive.*
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"archive.*",30);

   strncpy(commandstr,"rm -f ",10);
   strncat(commandstr,fromfilestr,160);
   system(commandstr); // rm -f archive/archive.*
   printf( "Board data Finished!\n");
}

printf( "Check the text files, especially histories.\n");

printf( " \n");
printf( "*********************** Prepare subassemblies *************************\n");

// Handle other subassemblies

strncpy(dirstr,rdbpath,120);  // $rdbpath/adhesive
strncat(dirstr,dirsep,10);
strncat(dirstr,"adhesive", 20);

if ( dir_exists(dirstr) ) //      -d $rdbpath/adhesive )
{
   // Get and validate source path
   //adsource="no"

   printf("Adhesive path exist = %s \n", dirstr);

   strncpy(adsource,"no",10);

  // adnum=$(ls $rdbpath/adhesive)
   strncpy(fromfilestr,rdbpath,120);  // $rdbpath/adhesive
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"adhesive",20);

   adfilecount = scandir_matchalldir( fromfilestr,0);

   strncpy(adnum,"",10);

   if (adfilecount > 0 )
   {
	   strncpy(adnum, scan_array[0],120);
   }
   else
   {
	   printf("No adhesive parts found \n");
   }

   adsource[0]='\0';

   while ( strcmp(adsource,"yes") != 0 )
   {
      printf( "Enter the full path name of the adhesive mfg data (ending in adhesive number):\n");
      gets(adpath);
    //  ardnum=${adpath##*/}
	  get_full_path_end(adpath,ardnum);

	  printf("Trying to match end of path to adhesive part =%s\n",adnum);

      if ( strcmp(ardnum,adnum ) == 0 )
      {
         if ( dir_exists( adpath ) )
         {
            
			 strncpy(adsource,"yes",10);
        }
     }
   }

   strncpy(dirstr,target,120); // $target/mdb/adhesive
   strncat(dirstr,dirsep,10);
   strncat(dirstr,"mdb",10);
   strncat(dirstr,dirsep,10);
   strncat(dirstr,"adhesive",15);

   mkdir( dirstr); // $target/mdb/adhesive

   printf("Made the directory = %s \n",dirstr);

   strncpy(tofilestr,target,120); //$target/mdb/adhesive
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"mdb",10);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"adhesive",20);

   strncpy(commandstr,"cp -p -R " , 20);  // cp -p -R adpath target/mdb/adhesive
   strncat(commandstr,adpath,120);
   strncat(commandstr," ",4);
   strncat(commandstr,tofilestr,140);

   printf("Copying from %s to %s \n", adpath, tofilestr);

   system(commandstr);  // cp -p -R adpath target/mdb/adhesive


  // nadpath=$(ls $target/mdb/adhesive)

   strncpy(fromfilestr,target,160);  // $target/mdb/adhesive
   strncat(fromfilestr,dirsep,5);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,5);
   strncat(fromfilestr,"adhesive",15);

   strncpy(nadpath,"",10);

   madcount= scandir_matchall( fromfilestr,0 );
   if (madcount  > 0 )
   {
     strncpy(nadpath,scan_array[0],120);
   }

;

   strncpy(fromfilestr,target,120);  // $target/mdb/adhesive/$nadpath
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"adhesive",30);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,nadpath,100);

   printf("Looking for laser files in %s \n", fromfilestr);

   filecount=scandir_matchext(fromfilestr,0,".las");

 
   if ( filecount==0 )
   {
      printf( "WARNING! Can't find any laser files in adhesive folder = %s\n",
		      fromfilestr);
   }
  

   strncpy(tofilestr,target,120); // $target/mdb/adhesive
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"mdb",10);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"adhesive",20);

   printf("Doing chmod on %s \n", tofilestr);
   _snprintf(systemstr,300,"chmod 777 %s ",  tofilestr  );

   system(systemstr);  // chmod 777 $target/mdb/adhesize

   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"*",10);

   _snprintf(systemstr,300,"chmod 777 %s \n", tofilestr);

   printf("Doing chmod on %s \n", tofilestr);
   //chmod( 777,  tofilestr );

   system(systemstr);   // chmod 777 $target/mdb/adhesive/*

   printf( "Adhesive done.\n");
}

strncpy(checkstr,rdbpath,120);  // $rdbpath/lid
strncat(checkstr,dirsep,10);
strncat(checkstr,"lid",10);

if ( dir_exists(checkstr) )         //  $rdbpath/lid )
{
   printf( "Moving lid data.... \n");
   strncpy(fromfilestr,rdbpath,120);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"lid",10);

   strncpy(tofilestr,target,120);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"mdb",10);

   strncpy(commandstr,"cp -p -R ",15);  // cp -p -R $rdbpath/lid  $target/mdb
   strncat(commandstr,fromfilestr,120);
   strncat(commandstr," ",4);
   strncat(commandstr,tofilestr,120);

   system(commandstr); // cp -p -R $target/mdb  $target/mdb

  // lidpath=$(ls $target/mdb/lid)

   strncpy(fromfilestr,target,120);  // $target/mdb/lid
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"lid",10);

   lidcount=scandir_matchalldir(fromfilestr,0);
   if (lidcount > 0 )
   {
	   strncpy(lidpath,scan_array[0],120);
   }

   strncpy(fromfilestr,target,120);  // $target/mdb/lid/$lidpath/history.txt
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"lid",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,lidpath,100);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"history.txt",20);

   //dos2ux $target/mdb/lid/$lidpath/history.txt > lid.tmp
   //fprintf(lidtmpfile, "%s  %s%sPost-Processed & released to MDB\n",
    //   today, REVB, ECO );   // >> lid.tmp

   // ux2dos lid.tmp > $target/mdb/lid/$lidpath/history.txt
   historytxtfile=fopen(fromfilestr,"a");
   if (historytxtfile!=NULL)
   {
    fprintf(historytxtfile, "%s  %-6s%-7s Post-Processed & released to MDB\n",
         timestamp, REVB, ECO );   // 
    fclose(historytxtfile);
   }
   else
   {
	   printf("Unable to open the history.txt file for append\n");
   }


   printf( "done.\n");
   // rm_file("lid.tmp");
  // rm -f $target/mdb/lid/$lidpath/*.mcm

   strncpy(fromfilestr,target,120);   // $target/mdb/lid/$lidpath
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"lid",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,lidpath,100);

   rm_all_ext( fromfilestr,".mcm");

}

printf("Doing the stencil \n");

strncpy(checkstr,rdbpath,120);  // $rdbpath/stencil
strncat(checkstr,dirsep,10);
strncat(checkstr,"stencil",10);

if ( dir_exists( checkstr ) )
{
   printf( "Moving stencil data.... \n");

   strncpy(dirstr,target,120);
   strncat(dirstr,dirsep,10);
   strncat(dirstr,"mdb",10);
   strncat(dirstr,dirsep,10);
   strncat(dirstr,"stencil",20);

   _snprintf(systemstr,300,"mkdir %s ",dirstr);
   printf("Making directory = %s \n",dirstr);

   //system(systemstr);

   mkdir(dirstr);
   
// stpath=$(ls $rdbpath/stencil)
   strncpy(fromfilestr,rdbpath,120);  // $rdbpath/stencil
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stencil",20);

   stencilcount = scandir_matchalldir( fromfilestr,0);

   strncpy(stpath,"",10);

    if (stencilcount > 0 )
	{
		strncpy(stpath, scan_array[0],120);
	}

   strncpy(fromfilestr,rdbpath,120);  // $rdbpath/stencil/$stpath
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stencil",20);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,stpath,100);

   strncpy(tofilestr,target,120);   //  $target/mdb/stencil
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"mdb",10);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"stencil",20);

   printf("Copying %s to %s \n", fromfilestr, tofilestr);

   strncpy(commandstr,"cp -p -R ",10);
   strncat(commandstr,fromfilestr,160);
   strncat(commandstr," ",4);
   strncat(commandstr,tofilestr,160);

   system(commandstr);   // cp -p -R $rdbpath/stencil/$stpath $target/mdb/stencil

   //dos2ux $target/mdb/stencil/history.txt >sten.tmp
   //fprintf(stentmpfile, "%s %6s %7sPost-Processed & released to MDB\n",
    //           today, REVB, ECO);   // >> sten.tmp
   //ux2dos sten.tmp > $target/mdb/stencil/$stpath.hist

   strncpy(fromfilestr,target,120); // $target/mdb/stencil/history.txt
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stencil",15);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,stpath,120);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"history.txt",20);

   strncpy(tofilestr,target,120);    // $target/mdb/stencil/$stpath.hist
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"mdb",10);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"stencil",15);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,stpath,50);
   strncat(tofilestr,".hist",10);

   printf("Copy the file = %s to %s \n", fromfilestr, tofilestr);

   cp_file(fromfilestr,tofilestr);

   pathhistfile = fopen(tofilestr,"a");
   if (pathhistfile != NULL)
   {
     fprintf(pathhistfile, "%s %-6s%-7sPost-Processed & released to MDB\n",
               timestamp, REVB, ECO);   // 
     fclose(pathhistfile);
   }
   else
   {
	   printf("Unable to open the file = %s for append \n", tofilestr);
   }

   printf( "done.\n");

   strncpy(fromfilestr,target,120);  // $target/mdb/stencil
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stencil",20);

   //rm -f $target/mdb/stencil/*.mcm 

   printf("Removing all %s files in %s \n", ".mcm", fromfilestr);

   rm_all_ext(fromfilestr,".mcm");

   //rm -f $target/mdb/stencil/history.txt

   strncpy(fromfilestr,target,120);  // $target/mdb/stencil/history.txt
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stencil",20);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"history.txt",20);

   if (file_exists ( fromfilestr) )
   {
     rm_file( fromfilestr);
   }

   printf("Done with stencil \n");

}

strncpy(checkstr,rdbpath,120);   // $rdbpath/stiffener
strncat(checkstr,dirsep,10);
strncat(checkstr,"stiffener",15);

if ( dir_exists( checkstr ) )
{
   printf( "Moving stiffener data....\n");  

   strncpy(fromfilestr,rdbpath,120);      // $rdbpath/stiffener/
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stiffener",20);
   //strncat(fromfilestr,dirsep,10);

   strncpy(tofilestr,target,120);  // $target/mdb
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"mdb",10);

   strncpy(commandstr,"cp -p -R ",15);
   strncat(commandstr,fromfilestr,160);
   strncat(commandstr," ",4);
   strncat(commandstr,tofilestr,160); // $target/mdb


   system(commandstr);  // cp -p -R $rdbpath/stiffener/ $target/mdb


  // stifpath=$(ls $target/mdb/stiffener)

   strncpy(fromfilestr,target,120);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stiffener",30);

   stiffiles = scandir_matchall( fromfilestr, 0 );

   strncpy(stifpath,"",10);

   if (stiffiles > 0 )
   {
	   strncpy(stifpath,scan_array[0],200);


   // dos2ux $target/mdb/stiffener/$stifpath/history.txt >stif.tmp
   // fprintf(stiftmpfile, "%s  %s%sPost-Processed & released to MDB\n",
   //    today, REVB, ECO );  // >> stif.tmp
  // ux2dos stif.tmp > $target/mdb/stiffener/$stifpath/history.txt
   //rm_file("stif.tmp");

   printf("Writing history.txt file \n");

   strncpy(fromfilestr,target,120); // $target/mdb/stiffener/$stifpath/history.txt
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stiffener",15);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,stifpath,80);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"history.txt",20);

   historytxtfile=fopen(fromfilestr,"a");

   if (historytxtfile != NULL)
   {
    fprintf(historytxtfile, "%s  %-6s%-7sPost-Processed & released to MDB\n",
      timestamp, REVB, ECO );  // 
     fclose(historytxtfile);
   }
   else
   {
	   printf("Unable to open the file %s for append \n",fromfilestr);
   }


   strncpy(fromfilestr,target,120); // $target/mdb/stiffener/$stifpath
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"mdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stiffener",15);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,stifpath,80);

   //rm -f $target/mdb/stiffener/$stifpath/*.mcm

    printf("Removing all files with %s from  %s \n",".mcm",fromfilestr);

    rm_all_ext( fromfilestr, ".mcm");

    strncpy(fromfilestr,target,120); // $target/mdb/stiffener/$stifpath 
    strncat(fromfilestr,dirsep,10);
    strncat(fromfilestr,"mdb",20);
    strncat(fromfilestr,dirsep,10);
    strncat(fromfilestr,"stiffener",20);
    strncat(fromfilestr,dirsep,10);
    strncat(fromfilestr,stifpath,120);

    filecount = scandir_matchext( fromfilestr,0,".dwg");

    if ( filecount == 0)
    {
      printf( "Can't find any drawings in stiffener folder = %s \n",fromfilestr);
    }
   }

   printf( "Stiffener done.\n");
}

return(0);

}

int main( int argc, char **argv)
{
int numargs;
int retcode;

  numargs=argc;

  if (numargs != 1)
  {
    printf( "No arguments allowed!\n");
    exit(-1);
  }
  else
   {
     retcode=postprep_call( );
	 exit(retcode);
   }

} // end main

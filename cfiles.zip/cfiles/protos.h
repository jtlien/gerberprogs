
void setvars_14x14();
void setvars_14x18();
void setvars_18x18();

int aptintomm2_call( char *infilestr);

int aptintomm2_call_out( char *infilestr, char *outfilestr);

int gettext8_call( char *brd, char *lang, char *rev, char *pnl, char *infilestr);

int gettext8_cply_call( char *brd, char *lang, char *rev, char *pnl, char *infilestr);

void getlabelcoords_call_out( char *file1str, char *outfilestr);

void xcatall2_call( char *infilestr);

int getcoords3_call_out(char *multstr, char *kerfstr, char *infilestr, char *outfilestr);

int getcoords3_call(char *multstr, char *kerfstr, char *infilestr);

void placebarcode_call( char *file1str);

void placebarcode2_call( char *file1str);

int rmmo_call_out( char *file1str, char *file2str);

int rmmo_call( char *file1str);

int placetext_call_out( char *infilestr, char *outfilestr);

int placetext_call( char *infilestr);

int formatbarcode_call_out( char *infilestr, char *outfilestr);

int formatbarcode_call( char *infilestr);

int chk_thru_call( char *file1str);

void createphoto_call( char *file1str);

int xcenall_call( char *extstr);

int centergbr_call( char *file1_instr, char *file2_instr, char *file3_instr);

void getoffset_call( char *infilestr);

void xgbrall_call( char *extstr, char *crossrefstr);

int xconvert_call( char *codestr, char *dirstr);

int updategbr_call( char *infile1, char *infile2, char *outfile);

int gbrfmtchg_call(int mult1, char *infile, char *outfile );

int gbrintomm_call(char *infile, char *outfile);

int inctoabs_call( char *infilestr, char *outfilestr);

void makestep1_call( char *multstr, char *file1str, char *file2str);

void mod_min_apt1_call( char *relstr, char *pcmstr, char *minaptfile,
					     char *infilestr);

void mod_min_apt1_call_out( char *relstr, char *pcmstr, char *minaptfile,
					     char *infilestr, char *outfilestr);

void placethievlabel7_call(char *file1str, char *file2str, char *spacestr);

int placethiev4_call( char *cofilestr, char *multstr, char *kerfstr, 
					 char *cfilestr, char *pcfile); 

int placethiev4s_call( char *cofilestr, char *multstr, char *kerfstr, 
					  char *cfilestr, char *pcfile); 

void placethievlabel7_cply_call(char *file1str, char *file2str, char *spacestr);

void combineapt_call(char *infile1str, char* mainfilestr);

void combineapt_call_out(char *infile1str, char* mainfilestr, char *outfilestr);

int centergbr_call( char *file1_instr, char *file2_instr, char *file3_instr);

int getfmtgbx_call ( char *flagstr, char *infilestr);

int getminclearance2_call(char *pcmstr, char *relstr, char *file1str, char *file2str, char *file3str);

int getminclearance2_call_out(char *pcmstr, char *relstr, char *f1str, char *f2str, char *f3str, char *outfilestr);

void placepcms_call_out(char *file1str, char *pathstr, char *file3str, char *outfilestr);

void placetestpcms4_call_out(char *pathstr, char *file1str, char *outfilestr);

void placetestpcms4_call(char *pathstr, char *file1str);

int valid_control4_call( char *nmstr, char *numstr, char *f1str, char* infstr, int type_flag);

void placelabels3_call( char *partsizefilestr, char *labelfilestr);

void placelabels3_call_out( char *partsizefilestr, char *labelfilestr, char *outfilestr);

int gettestcoords4_call_out(char *file1str, char *file2str, char *file3str, char *kerfstr,
					  char *file4str, char *outfilestr);

int gettestcoords4_call(char *file1str, char *file2str, char *file3str, char *kerfstr,
					  char *file4str);

int getregcoords_call_out(char *file1str, char *file2str, char *file3str, char *kerfstr,
					  char *file4str, char *outfilestr);

int getregcoords_call(char *file1str, char *file2str, char *file3str, char *kerfstr,
					  char *file4str);

void getoptical8_call_out( char *file1str, char *outfilestr);

void getoptical8_call( char *file1str);

void getoptical8_cply_call_out( char *file1str, char *outfilestr);

void getoptical8_cply_call( char *file1str);

void getpcmkerf11_call_out( char *file1str, char *file2str, char *kerfstr, char *file4str,
						   char *outfilestr);

void getpcmkerf11_call( char *file1str, char *file2str, char *kerfstr, char *file4str);
						  
void xcat274x2_call( char *infilestr);

void xcat_cply3_call( char *infilestr);

void placepcmman_call( char *inpathstr, char *infilestr);

int coreclean_call( char *file1str);

int coreclean_call_out( char *file1str, char *outfilestr);

int splitcontrol_call( char *infilestr);

void getoffset_call_out( char *infilestr, char *outfilestr);

void off274x_call_out( char *infilestr, char *xvalstr, char *yvalstr, 
					  char *outfilestr);

void off274x_call( char *infilestr, char *xvalstr, char *yvalstr); 

void dooffset_call_out(char *fname, int in1 , int in2, char *outfilestr);

void dooffset_call_append(char *fname, int in1 , int in2, char *outfilestr);

int oddeven_call( char *infname);




#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include <io.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

#include "utilprogs.h"


int beepflag;

// rdb-relprep
// Re-arrange data to prepare for release to RDB
// Prompts for source path, uses pwd as target path
// Creates rdb directory with subdirs for each used subassy
// updated 9-24-99

// Version 0.2
// March 27, 2001
// Use a fixed destination path instead of pwd
// Verify empty-ness of destination path, exit if not empty
// Recognize stiffener, adhesive, lid, stencil files
// Correctly move input sheet htm file
// Fix path names for new server 
// Remove usage log
// Improve creation of history files
// Create camjob folder for direct use

// Version 0.25 
// March 28, 2001
// Add an adhesive folder to the camjob folder 

// Version 0.26
// May 14, 2001
// Do not copy control file to camjob folder - not needed
// Case-shift "all" file names to lowercase
// DOS translate "all" text files at top level
// Copy all mech mech/src data to assembly drawing/src folder
// Clean up screen messages

// Version 0.27
// May 17, 2001
// Fix problems with mech subfolders
// Copy all mech/dwg subfolders to assembly/drawing folder

// Version 0.28
// Aug 27, 2001
// Fix problem with adhesive - separate it from stiffener
// Support user choice of target path and validate choice 
// Save target path in hidden file in user's home directory for use
//   by other scripts - .stagingpath
// Correct problem with case shifting
// Preserve dates when copying to rdb structure

// Version 0.29
// Nov 13, 2001
// Place used.txt in assembly destination to help librarian
// Delete tmpfile in destination board folder
// Delete all dwg files from destination board folder
// More methodical approach to changing permissions

// Version 0.30
// June 16, 2003
// Add check for drc_summary report, check for duplicate reports,
//  and deletion of skeleton report from release area

// Version 0.35
// 05/05/05  BAC
// Corrected "cannot create" problem - tmp0 file target was not specific
// Copy entire control folder into camjob
// Copy entire cam folder into camjob, delete pre-bias exception reports
// If board history file exists, program does not overwrite it, instead
//   creates history2 file and puts message on screen
// Do not delete any dwg files from destination board folder
// Check for existence of prep files and echo message if absent (intercept not-found error)
// Echo revision number, change to 2-digit part rev

int is_owner( char *infilestr)
{
	return(TRUE);
}

void rdb_relprep_call(  )
{

char REV[40];
char ECO[100];
char REVB[40];
char username[120];
char target[300];
char SRC[300];
char targyn[40];
char targpath[300];
char chkdirstr[300];
char adhesive[300];
char stencil[300];
char stenused[40];
char stiffener[300];
char stiffbase[200];
char stiffext[200];
char stiffused[40];
char sourcepath[300];
char oldpn[300];
char newpn[300];
char ancestor[300];
char assy[300];

char brdnum[300];
char lid[300];
char lidbase[200];
char lidext[200];
char lidused[40];
char validsource[40];
int rdbthere;
int camthere;
int validtarg;
char checkdirstr[300];
char chkfilestr[300];
char catfilestr[300];
char chkfile2str[300];
char endentry[300];
char mkdirstr[300];
char today[300];
char sedtoday[300];
char LIBPATH[300];
char PROGPATH[300];
char MSPATH[300];
char date[200];
char xline[300];
char board[300];
char brdused[300];
char adhused[300];
int endoffile;
char fromfilestr[400];
char tofilestr[300];
FILE *tmp0file;
FILE *assytmpfile;
FILE *stentmpfile;
FILE *stiftmpfile;
FILE *brdtmpfile;
FILE *adtmpfile;
FILE *lidtmpfile;
FILE *stagefile;

char stagingpath[300];
int keywordfound;
int numfields;
int revwidth;
int pnwidth;
int ecowidth;
int afilecount;
char afile[300];
char commandstr[500];
int ii;
int desfile;
char timestr[300];
char yearshort[300];
int monthval;


char *proptarg;

 strncpy(lid,"",10);
 strncpy(assy,"",10);
 strncpy(brdused,"",10);
 strncpy(stenused,"",10);
 strncpy(stiffused,"",10);
 strncpy(adhused,"",10); 
 strncpy(lidused,"",10); 
 strncpy(adhesive,"",10);
 strncpy(board,"",10);
 strncpy(stencil,"",10);
 strncpy(stiffener,"",10);


//strncpy(release_stat,"1",10);       // change to 1 when released !!!!!!!!!!

// General variables
//if ( strcmp(release_stat,"0" ) == 0 )
//{
 //  strncpy(LIBPATH,"/home/bac/library",50);
 //  strncpy(PROGPATH,"/home/bac/library/flowscripts",60);
 //  strncpy(MSPATH,"/home/bac/library/flowscripts/ms2.5",70);
//}
//else
//{
 //  strncpy(LIBPATH,"/swtools/remote/library",50);
 //  strncpy(PROGPATH,"/swtools/remote/bin",70);
 //  strncpy(MSPATH,"/swtools/remote/bin/makestruct",80);
//}

if (WINDOWS)
{
	strncpy(dirsep,"/",4);
}
else
{
	strncpy(dirsep,"/",3);
}

strncpy(REV,"0.35",20);


// Check for correct invocation

//username=$(whoami)
 get_whoami(username);

//today=$(date '+%m/%d/%y')
 get_date(timestr);

 //sedtoday=$(date '+%m\/%d\/%y')

 _snprintf(yearshort,200,"%c%c",yearstr[2],yearstr[3]);

 monthval=get_month_number( monthstr);

 _snprintf(today,300,"%d",monthval);
 //strncpy(today,monthstr,20);
 strncat(today,"/",4);
 strncat(today,daystr,10);
 strncat(today,"/",4);
 strncat(today,yearshort,10);

 // printf("today = %s \n",today);

 strncpy(sedtoday,today,120);

  

  proptarg=getenv("HOME");

  if (proptarg == NULL)
  {
	  printf("No HOME environment variable \n");
	  exit(-1);
  }
  
  printf( "********* Running rdb-relprep version %s *********\n",REV);

//################# Set up & validate staging destination ###################

printf( "A staging directory will be created or used in the target path you choose.\n");
printf( "The target path must be write-able and available to NT.\n" );

printf( "Proposed target path for staging directory is %s\n",proptarg);

  

while( (strcmp(targyn,"y") != 0 ) && (strcmp(targyn,"n") != 0 ) )  
{
   printf( "Do you accept this as your staging path (y/n)? \n");
   gets(targyn);
}

if ( strcmp(targyn,"y" ) == 0 )
{
   // target=$proptarg/staging
	strncpy(target,proptarg,120);  // $proptarg/staging
	strncat(target,dirsep,10);
	strncat(target,"staging",20);

   //printf( "Your staging directory will be %s\n",target);
}
else
{
   validtarg=0;
   while ( validtarg != 1 )
   {
      printf( "Enter full path for the staging directory target you want: \n" );
      gets(targpath);
      // Check validity and permissions here
      //endentry=${targpath##*/}

	  get_full_path_end(targpath,endentry);

      if ( strcmp(endentry,"staging" ) == 0 )
      {
	    printf( "The path name must not end in staging - try again!\n");
        continue;
      }
      if ( dir_exists( targpath ) )
      {
	   if ( ! is_owner(targpath ) )
	   {
	    printf( "Not owner of %s. Pick another path.\n",targpath);
	   }
       else
	   {
	    //if ( -r $targpath && -w $targpath && -x $targpath )  // read, write, execute
		if ( file_is_readable(targpath) && file_is_writeable( targpath)
			 && file_is_executable(targpath) )
	    {
	       //target=$targpath/staging
			strncpy(target,targpath,120);  
			strncat(target,dirsep,10);
			strncat(target,"staging",20);

	       validtarg=1;
		}
        else
		{
	       printf( "Permissions problem with %s. Enter another path or control-C to exit.\n",
			                targpath); 
	    }
       }
	  }
     else
	 {
         printf("%s is not a valid or existing path name\n",targpath);
      }
   }
}


printf( "Your staging directory will be %s \n", target);

printf( "This directory name will be used by other scripts.\n");
printf( "...........................................................\n");
// Save the target path in a hidden file in user's home directory

strncpy(stagingpath,proptarg,120);  // staging = $proptarg/.stagingpath
strncat(stagingpath,dirsep,10);
strncat(stagingpath,".stagingpath",30);


stagefile=fopen(stagingpath,"w");
fprintf(stagefile, "%s > %s%s.stagingpath \n", target, proptarg,dirsep);
fclose(stagefile);


// Create target staging directory if not already present
if ( ! (dir_exists(target ) ) )
{
   printf( "Creating staging directory %s\n",target);
   mkdir(target);
}

// Check for pre-existing data
rdbthere=0;
camthere=0;

strncpy(checkdirstr,target,120);   // $target/rdb
strncat(checkdirstr,dirsep,10);
strncat(checkdirstr,"rdb",10);

if ( dir_exists(checkdirstr) )           // -d $target/rdb 
{
   printf( "Staging directory not empty. Remove %s%srdb and its contents.\n",target,dirsep);
   rdbthere=1;
}
strncpy(checkdirstr,target,120);      // $target/camjob
strncat(checkdirstr,dirsep,10);
strncat(checkdirstr,"camjob",15);

if ( dir_exists(checkdirstr) )
{
   printf( "Staging directory not empty. Remove %s%scamjob and its contents.\n",target,dirsep);
   camthere=1;
}
if ( (rdbthere == 1) || (camthere == 1 ) )
{
   exit(-1);
}

//########## End of destination setup #####################

// ########## Validate source path ########################
strncpy(validsource,"no",10);

while ( strcmp(validsource,"yes") != 0 )  
{
   printf( "Enter the full path name of the source data: \n" );
   gets(sourcepath);
   if ( dir_exists( sourcepath ) )
   {
      strncpy(validsource,"yes",10);
   }
}

//brdnum=${sourcepath##*/}

get_full_path_end( sourcepath,brdnum);

strncpy(chkfilestr,sourcepath,120);     // sourcepath/$brdnum.mcm
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,brdnum,120);
strncat(chkfilestr,".mcm",10);

if ( ! (file_exists(chkfilestr) )  )
{
   printf( "Path = %s contains no file named %s.mcm \n",sourcepath, brdnum);
   exit(-1);
}

// Validate source path for completeness and date integrity
printf( "Validating data in %s \n",sourcepath);

//SRC=$sourcepath
strncpy(SRC,sourcepath,120);

strncpy(chkfilestr,SRC,120);     // $SRC/pn.txt
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"pn.txt",20);


if ( ! file_exists(chkfilestr) )
{
   printf( "No pn.txt file! Exiting.\n");
   exit(-1);
}

strncpy(chkfilestr,SRC,120);     // $SRC/used.txt
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"used.txt",20);


if ( ! file_exists(chkfilestr) )         // -a $SRC/used.txt 
{
   printf( "No used.txt file! Exiting.\n");
   exit(-1);
}
strncpy(chkfilestr,SRC,120);     // $SRC/report/drc_summary
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"report",20);
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"drc_summary",30);
  
strncpy(chkfile2str,SRC,120);     // $SRC/report/drc_summary.txt
strncat(chkfile2str,dirsep,10);
strncat(chkfile2str,"report",20);
strncat(chkfile2str,dirsep,10);
strncat(chkfile2str,"drc_summary.txt",30);  

if ( (! (file_exists( chkfilestr) ) )  && ( ! (file_exists( chkfile2str) ) ) )
{
   printf( "No report\\drc_summary or report\\drc_summary.txt report! Exiting.\n");
   exit(-1);
}

if ( file_exists(chkfilestr)  &&  file_exists(chkfile2str) )
{
   printf( "Two copies of drc_summary exist - one with .txt extension.\n" );
   printf( "You must delete one of them.\n");
   exit(-1);
}

//########## End of source path validation ########################

//########## Parse pn and used files ########################

printf( "Checking pn and used files........\n");

strncpy(brdused,"new",10);
strncpy(stenused,"new",10);
strncpy(stiffused,"new",10);
strncpy(adhused,"new",10);
strncpy(lidused,"new",10);

//dos2ux $SRC/used.txt>$SRC/tmp0

strncpy(fromfilestr,SRC,120);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"used.txt",30);

tmp0file=fopen( fromfilestr,"r");  // read $SRC/used.txt
if (tmp0file== NULL)
{
	printf("Unable to open the input file = %s \n", fromfilestr);
	printf("Possible problem with file attributes \n");
	exit(-1);
}

endoffile=getline(tmp0file,xline);
numfields=split_line(xline);

while(endoffile==FALSE)        // read xline
{
//   set $xline
  // numfields=$#
   if (numfields != 3)
   {
      printf( "Field count incorrect in used.txt file.\n");
      printf( "Can't process %s \n",xline);
      exit(-1);
   }
   else
   {
	  keywordfound=FALSE;
      if (strcmp( str_array[0],"Assembly") == 0 )
	  {
		  strncpy(assy,str_array[1],120);
		  keywordfound=TRUE;
	  }
	  if (strcmp( str_array[0],"Board") == 0 )
	  {
		  strncpy(brdused,str_array[2],120);
          keywordfound=TRUE;
	  }
	  if (strcmp( str_array[0],"Stencil") == 0 )
	  {
		  strncpy(stenused,str_array[2],120);
          keywordfound=TRUE;
	  }
	  if (strcmp( str_array[0],"Stiffener") == 0 )
	  {
		  strncpy(stiffused,str_array[2],120);
          keywordfound=TRUE;
	  }
	  if (strcmp( str_array[0],"Adhesive") == 0 )
	  {
		  strncpy(adhused,str_array[2],120); 
		  keywordfound=TRUE;
	  }
	  if (strcmp( str_array[0],"Lid") == 0 )
	  {
		  strncpy(lidused,str_array[2],120); 
		  keywordfound=TRUE;
	  }
      if (keywordfound==FALSE)
	  {
        printf( "used.txt: Can't process %s  - unrecognized keyword \n",xline);
	   exit(-1);
	  }
      
   }
   endoffile=getline(tmp0file,xline);
   numfields=split_line(xline);
}                      // <$SRC/tmp0

fclose(tmp0file);

// rm -f $SRC/tmp0

//dos2ux $SRC/pn.txt>$SRC/tmp0

strncpy(fromfilestr,SRC,120);       // $SRC/pn.txt
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"pn.txt",20);

tmp0file=fopen(fromfilestr,"r");

if(tmp0file==NULL)
{
	printf("Unable to open the input file = %s \n",fromfilestr);
    printf("Possible problem with file attributes \n");
	exit(-1);
}

endoffile=getline( tmp0file, xline);
numfields=split_line(xline);

while(endoffile==FALSE) //  read xline
{
//   set $xline
  // numfields=$#
   if ( numfields != 2)
   {
      printf( "Too many fields in pn.txt file.\n");
      printf( "Can't process  %s \n",xline);
      exit(-1);
	}
   else
   {
	  keywordfound=FALSE;
      if (strcmp( str_array[0],"Assembly") == 0 )
	  {
		  strncpy(assy,str_array[1],120);
		  keywordfound=TRUE;
	  }
	  if (strcmp( str_array[0],"Board") == 0 )
	  {
		  strncpy(board,str_array[1],120);
          keywordfound=TRUE;
	  }
	  if (strcmp( str_array[0],"Stencil") == 0 )
	  {
		  strncpy(stencil,str_array[1],120);
          keywordfound=TRUE;
	  }
	  if (strcmp( str_array[0],"Stiffener") == 0 )
	  {
		  strncpy(stiffener,str_array[1],120);
          keywordfound=TRUE;
	  }
	  if (strcmp( str_array[0],"Adhesive") == 0 )
	  {
		  strncpy(adhesive,str_array[1],120); 
		  keywordfound=TRUE;
	  }
	  if (strcmp( str_array[0],"Lid") == 0 )
	  {
		  strncpy(lid,str_array[1],120); 
		  keywordfound=TRUE;
	  }
      if (keywordfound==FALSE)
	  {
        printf( "pn.txt: Can't process %s  - unrecognized keyword \n",xline);
	   exit(-1);
	  }
   }
   endoffile=getline( tmp0file, xline);
   numfields=split_line(xline);

}     // <$SRC/tmp0

fclose(tmp0file);

// rm -f $SRC/tmp0

if ( strcmp(brdnum,board ) != 0 )
{
   printf( "Mismatch between board numbers in pn.txt and directory!\n");
   exit(-1);
}

//########## End of Parse pn and used files ########################

//  Pad lengths of text strings
strncpy(REVB,"00",10);
strncpy(ECO,"n/a",10);

revwidth=6;
pnwidth=13;
ecowidth=7;
strncpy(ancestor,"",10);               // what is this?

strncpy(oldpn,ancestor,120);
strncpy(newpn,brdnum,120);

//typeset -L$revwidth REVB
//typeset -L$pnwidth oldpn
//typeset -L$pnwidth newpn
//typeset -L$ecowidth ECO

//strncpy(fancy_ptype,ptype,120);    not used

// cv_toupper(ptype, fancy_ptype);

// typeset -u fancy_ptype


printf( "Building RDB structure for %s........ \n",brdnum);
// Create the local rdb directories

change_dir(target);    //  destination directory

// Assembly

if ( ! (dir_exists("rdb" ) ) )
{
   mkdir("rdb");
}

change_dir("rdb");  // make the rdb directory

if ( ! (dir_exists("assembly" ) ) )
{
   mkdir("assembly");
}

strncpy(mkdirstr,"assembly",20);
strncat(mkdirstr,dirsep,10);
strncat(mkdirstr,assy,120);

mkdir(mkdirstr); // assembly/$assy

strncat(mkdirstr,dirsep,10);
strncat(mkdirstr,"drawing",10);

mkdir(mkdirstr);   //  assembly/$assy/drawing

strncat(mkdirstr,dirsep,10);
strncat(mkdirstr,"src",10);

mkdir(mkdirstr);  //  assembly/$assy/drawing/src

strncpy(fromfilestr,SRC,120);  // $SRC/pn.txt
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"pn.txt",15);

strncpy(tofilestr,"assembly",30);  // assembly/$assy/pn.txt
strncat(tofilestr,dirsep,10);
strncat(tofilestr,assy,120);
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"pn.txt",10);

printf("copy from %s to %s \n", fromfilestr,tofilestr);

cp_file( fromfilestr, tofilestr);   // -p $SRC/pn.txt assembly/$assy

strncpy(fromfilestr,SRC,120);  // $SRC/used.txt
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"used.txt",15);

strncpy(tofilestr,"assembly",30);  // assembly/$assy/used.txt
strncat(tofilestr,dirsep,10);
strncat(tofilestr,assy,120);
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"used.txt",15);

printf("copy from %s to %s \n", fromfilestr,tofilestr);

cp_file(fromfilestr, tofilestr);

// ux2dos $SRC/used.txt > assembly/$assy/used.txt

strncpy(fromfilestr,SRC,120);    //  $SRC/mech/dwg/*
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"mech",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"dwg",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"*",4);

strncpy(tofilestr,"assembly",20);    // assembly/$assy
strncat(tofilestr,dirsep,10);
strncat(tofilestr,assy,120);

_snprintf(commandstr,500,"cp -p -R %s %s", fromfilestr,tofilestr);
system(commandstr);

//system("cp -p -R $SRC/mech/dwg/* assembly/$assy " ); //  2>/dev/null


strncpy(fromfilestr,SRC,120);    //  $SRC/mech/src/*
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"mech",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"src",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"*",4);

strncpy(tofilestr,"assembly",20);    // assembly/$assy/drawing/src
strncat(tofilestr,dirsep,10);
strncat(tofilestr,assy,120);
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"drawing",20);
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"src",10);

_snprintf(commandstr,500,"cp -p -R %s %s", fromfilestr,tofilestr);
system(commandstr);
//system("cp -p -R $SRC/mech/src/* assembly/$assy/drawing/src "); // 2>/dev/null

strncpy(fromfilestr,SRC,120);    //  $SRC/mech/*
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"mech",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"*",10);

_snprintf(commandstr,500,"cp -p -R %s %s", fromfilestr,tofilestr);
system(commandstr);
//system("cp -p $SRC/mech/* assembly/$assy/drawing/src "); // 2>/dev/null

strncpy(fromfilestr,SRC,120);       // $SRC/
strncat(fromfilestr,dirsep,10);

strncpy(tofilestr,"assembly",20);  // assembly/$assy
strncat(tofilestr,dirsep,10);
strncat(tofilestr,assy,120);

cp_files_ext(fromfilestr,".des",tofilestr);
// system("cp -p $SRC/*.des assembly/$assy "); // 2>/dev/null
cp_files_ext(fromfilestr,".htm",tofilestr);

// system("cp -p $SRC/*.htm assembly/$assy "); //2>/dev/null

// strncpy(chkfilestr,dirsep,10);      // textfiles/assy.prep
strncpy(chkfilestr,"textfiles",15);
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"assy.prep",15);

if ( file_exists(chkfilestr) )    // -a  textfiles/assy.prep
{
   strncpy(fromfilestr,SRC,120);   // SRC/textfiles/assy.hist
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"textfiles",20);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"assy.hist",20);

   strncpy(tofilestr,"assy.tmp",20);   // assy.tmp
   
   //cat $SRC/textfiles/assy.hist $SRC/textfiles/assy.prep | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > assy.tmp
   cat_files(fromfilestr,chkfilestr,tofilestr);

   strncpy(fromfilestr,"assy.tmp",20); 
   strncpy(tofilestr,"assy.tmp1",20); 

   ssed( fromfilestr,"mmmmm",today,tofilestr);

   strncpy(fromfilestr,"assy.tmp1",20); 

   strncpy(tofilestr,"assembly",30);    // assembly/$assy/history.txt
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,assy,120);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"history.txt",20);
   
   ssed(fromfilestr,"mmm",username,tofilestr);
   rm_file("assy.tmp");
   rm_file("assy.tmp1");

}
else
{
   // cat $SRC/textfiles/assy.hist | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > assy.tmp
   strncpy(fromfilestr,SRC,120);   // SRC/textfiles/assy.hist
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"textfiles",20);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"assy.hist",20);

   strncpy(tofilestr,"assy.tmp",20);

   printf("About to call ssed %s %s\n",fromfilestr,today);

   ssed(fromfilestr,"mmmmm",today,tofilestr);

   printf("Return from ssed \n");

   strncpy(fromfilestr,"assy.tmp",20);

   strncpy(tofilestr,"assembly",30);  // assembly/$assy/history.txt
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,assy,120);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,"history.txt",20);
   ssed(fromfilestr,"mmm",username,tofilestr);

   rm_file("assy.tmp");
   printf( "No assembly review prep information available \n");
}

assytmpfile=fopen(tofilestr,"a");  // open in append mode
if (assytmpfile==NULL)
{
	printf("Unable to open the file %s for append \n", tofilestr);
	exit(-1);
}

fprintf(assytmpfile, "%s  %6s%7sRelease Preparation\n",today,REVB,ECO); // >> tofilestr
fclose(assytmpfile);

// ux2dos assy.tmp > assembly/$assy/history.txt
// rm -f assy.tmp

// Handle subfolders of mech/dwg
//assylist=$(ls assembly/$assy)
strncpy(fromfilestr,"assembly",30);  // assembly/$assy
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,assy,120);

afilecount=scandir_matchall( fromfilestr,0 );
ii=0;
while( ii < afilecount)  //  afile in $assylist
{
	strncpy(afile,scan_array[ii],120);

   strncpy(checkdirstr,"assembly",20); // assembly/$assy/$afile
   strncat(checkdirstr,dirsep,10);
   strncat(checkdirstr,assy,120);
   strncat(checkdirstr,dirsep,10);
   strncat(checkdirstr,afile,120);

   if ( dir_exists(checkdirstr) ) //  assembly/$assy/$afile 
   {
      if ( strcmp(afile,"drawing") != 0 )
      {
		 strncpy(fromfilestr,"assembly",30);  // assembly/$assy/$afile
		 strncat(fromfilestr,dirsep,10);
		 strncat(fromfilestr,assy,120);
		 strncat(fromfilestr,dirsep,10);
		 strncat(fromfilestr,afile,120); 

		 strncpy(tofilestr,"assembly",30);    // assembly/$assy/drawing
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,assy,120);
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,"drawing",20);

		 cp_file(fromfilestr,tofilestr);
		 rm_file(fromfilestr);
         // mv assembly/$assy/$afile assembly/$assy/drawing
      }
   }
   ii += 1;
}

chmod_file( 777, "assembly" );

strncpy(chkfilestr,"assembly",30);
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,assy,120);

chmod_file( 777, chkfilestr ); 

strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"*",4);

chmod_file( 777, chkfilestr);

strncpy(chkfilestr,"assembly",30);
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,assy,120);
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"drawing/*",30);

chmod_file( 777, chkfilestr);

strncat(chkfilestr,"/*",10);

chmod_file( 777, chkfilestr ); //  2> /dev/null

strncat(chkfilestr,"/*",10);

chmod_file( 777, chkfilestr ); // 2> /dev/null

strncat(chkfilestr,"/*",10);

chmod_file( 777, chkfilestr); //  2> /dev/null


if ( strcmp(stencil,"") != 0 )        //  != "" )
{
   if ( strcmp(stenused,"new" ) == 0 )
   {
      if ( ! (dir_exists("stencil" ) ) )
      {
         mkdir("stencil");
      }
	  strncpy(mkdirstr,"stencil",12);
	  strncat(mkdirstr,dirsep,10);
	  strncat(mkdirstr,stencil,120);

      mkdir(mkdirstr);       // stencil/$stencil

	  strncpy(fromfilestr,SRC,120);   // $SRC/stencil.mcm
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"stencil.mcm",30);

	  strncpy(tofilestr,"stencil",20);  // stencil/$stencil/$stencil.mcm
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,stencil,120);
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,stencil,120);
	  strncat(tofilestr,".mcm",10);

	  cp_file( fromfilestr, tofilestr);

      //cp -p $SRC/stencil.mcm stencil/$stencil/$stencil.mcm

      strncpy(fromfilestr,SRC,120);         // $SRC/pre-bias/stencil.art
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"pre-bias",30);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"stencil.art",30);

	  strncpy(tofilestr,"stencil",20);   // stencil/$stencil/$stencil.art
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,stencil,120);
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,stencil,120);
	  strncat(tofilestr,".art",10);

	  cp_file( fromfilestr, tofilestr);

      //cp -p $SRC/pre-bias/stencil.art stencil/$stencil/$stencil.art 2>/dev/null

      strncpy(fromfilestr,SRC,120);         // $SRC/stencil/stencil.art
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"stencil",30);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"stencil.art",30);

	  strncpy(tofilestr,"stencil",20);   // stencil/$stencil/$stencil.art
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,stencil,120);
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,stencil,120);
	  strncat(tofilestr,".art",10);

	  cp_file(fromfilestr,tofilestr);

     // cp -p $SRC/stencil/stencil.art stencil/$stencil/$stencil.art 2>/dev/null
      strncpy(fromfilestr,SRC,120);         // $SRC/stencil.dxf
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"stencil.dxf",30);
	  
	  strncpy(tofilestr,"stencil",20);   // stencil/$stencil/$stencil.dxf
	  strncat(tofilestr,dirsep,10);
      strncat(tofilestr,stencil,120);
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,stencil,120);
	  strncat(tofilestr,".dxf",10);

	  cp_file(fromfilestr,tofilestr);

     // cp -p $SRC/stencil.dxf stencil/$stencil/$stencil.dxf 2>/dev/null
     
      strncpy(fromfilestr,SRC,120);         // $SRC/stencil/stencil.dxf
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"stencil",20);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"stencil.dxf",30);
	  
	  strncpy(tofilestr,"stencil",20);   // stencil/$stencil/$stencil.dxf
	  strncat(tofilestr,dirsep,10);
      strncat(tofilestr,stencil,120);
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,stencil,120);
	  strncat(tofilestr,".dxf",10);

	  cp_file(fromfilestr,tofilestr);

    //cp -p $SRC/stencil/stencil.dxf stencil/$stencil/$stencil.dxf 2>/dev/null
      
     // strncpy(chkfilestr,dirsep,10);   // IS THIS OK?  textfiles/sten.prep
	  strncpy(chkfilestr,"textfiles",30);
	  strncat(chkfilestr,dirsep,10);
	  strncat(chkfilestr,"sten.prep",20);

      if ( file_exists(chkfilestr) )
      {
		 strncpy(fromfilestr,SRC,120);   // SRC/textfiles/sten.hist
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"textfiles",20);
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"sten.hist",20);

         strncpy(tofilestr,"sten.tmp",20);   // sten.tmp

		 strncpy(catfilestr,SRC,120);      // SRC/textfilest/sten.prep
		 strncat(catfilestr,dirsep,10);
		 strncat(catfilestr,chkfilestr,120);

         cat_files(fromfilestr,catfilestr,tofilestr);

		 strncpy(fromfilestr,"sten.tmp",30); 
         strncpy(tofilestr,"sten.tmp1",30);
		 ssed(fromfilestr,"mmmmm",today,tofilestr);

		 strncpy(fromfilestr,"sten.tmp1",30);

		 strncpy(tofilestr,"stencil",20);   // stencil/$stencil/history.txt
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,stencil,120);
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,"history.txt",30);

		 ssed(fromfilestr,"mmm",username,tofilestr);

		 rm_file("sten.tmp");
		 rm_file("sten.tmp1");

         //cat $SRC/textfiles/sten.hist $SRC/textfiles/sten.prep | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > sten.tmp
      }
	  else
	  { 
		  strncpy(fromfilestr,SRC,120);   // SRC/textfiles/sten.hist
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"textfiles",20);
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"sten.hist",20);

		 strncpy(tofilestr,"sten.tmp",20);
		 ssed(fromfilestr,"mmmmm",date,tofilestr);

		 strncpy(fromfilestr,"sten.tmp",20);

		 strncpy(tofilestr,"stencil",30);     // stencil/$stencil/history.txt
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,stencil,120);
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,"history.txt",20);

		 ssed(fromfilestr,"mmm",username,tofilestr);

		 rm_file("sten.tmp");

         //cat $SRC/textfiles/sten.hist | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > sten.tmp
         printf( "No stencil review prep information available\n");
      }
	  stentmpfile=fopen(tofilestr,"a");  // open for apend

      fprintf(stentmpfile, "%s  %6s%7sRelease Preparation \n",today, REVB,ECO); // >> sten.tmp 
	  fclose(stentmpfile);

      // ux2dos sten.tmp > stencil/$stencil/history.txt
     // rm -f sten.tmp
      chmod_file(777, "stencil" );

	  strncpy(chkfilestr,"stencil",30);
	  strncat(chkfilestr,dirsep,10);
	  strncat(chkfilestr,stencil,120);

      chmod_file( 777, chkfilestr );

	  strncat(chkfilestr,"/*",10);

      chmod_file( 777, chkfilestr);
   }
}

//#######################  Do something about strip stiffeners / adhesive screens ##############################
if ( (strcmp(stiffener,"") != 0 ) && ( strcmp(stiffused,"new" ) == 0 ) )
{
  //stiffbase=${stiffener%%-*}
   split(stiffener,stiffbase,stiffext,"-");

   if ( ! dir_exists( "stiffener" ) )
   {
      mkdir("stiffener");
   }
   strncpy(mkdirstr,"stiffener",20);    // stiffener/$stiffener
   strncat(mkdirstr,dirsep,10);
   strncat(mkdirstr,stiffener,120);

   mkdir(mkdirstr);           // stiffener/$stiffener

   strncpy(fromfilestr,SRC,120);    // $SRC/stiffener.mcm
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stiffener.mcm",20);

   strncpy(tofilestr,"stiffener",20);   // stiffener/$stiffener/$stiffener.mcm
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,stiffener,120);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,stiffener,120);
   strncat(tofilestr,".mcm",6);

   cp_file(fromfilestr,tofilestr);

  // cp -p $SRC/stiffener.mcm stiffener/$stiffener/$stiffener.mcm

   strncpy(fromfilestr,SRC,120);      // $SRC/stiffener.dxf
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"stiffener.dxf",20);

   strncpy(tofilestr,"stiffener",20);  // stiffener/$siffener/$stiffener.dxf
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,stiffener,120);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,stiffener,120);
   strncat(tofilestr,".dxf",6);

   cp_file(fromfilestr,tofilestr);

  // cp -p $SRC/stiffener.dxf stiffener/$stiffener/$stiffener.dxf
//######## stiffener drawing move - Where is it? What is its name? #################################
   
   strncpy(tofilestr,"stiffener",20);     // stiffener/$stiffener
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,stiffener,120);

   cp_files_ext(SRC,".dwg", tofilestr); // -p $SRC/*.dwg stiffener/$stiffener 

   //strncpy(chkfilestr,dirsep,10);   // IS THIS OK?  textfiles/stif.prep
   strncpy(chkfilestr,"textfiles",30);
   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,"stif.prep",20);

   if ( file_exists(chkfilestr) )   // -a /textfiles/stif.prep 
   {
	   strncpy(fromfilestr,SRC,120);   // SRC/textfiles/stif.hist
       strncat(fromfilestr,dirsep,10);
       strncat(fromfilestr,"textfiles",20);
       strncat(fromfilestr,dirsep,10);
       strncat(fromfilestr,"stif.hist",20);

	   strncpy(catfilestr,SRC,120);    // $SRC/textfiles/stif.prep
	   strncat(catfilestr,dirsep,10);
	   strncat(catfilestr,chkfilestr,120);

       strncpy(tofilestr,"stif.tmp",20);   // >stif.tmp

       cat_files(fromfilestr,catfilestr,tofilestr);  // >stif.tmp

	   strncpy(fromfilestr,"stif.tmp",30);
       strncpy(tofilestr,"stif.tmp1",30);
	   ssed(fromfilestr,"mmmmm",today,tofilestr);

	   strncpy(fromfilestr,"stif.tmp1",30);  // >stif.tmp1

	   strncpy(tofilestr,"stiffener",20);   // stiffener/$stiffener/history.txt
	   strncat(tofilestr,dirsep,10);
	   strncat(tofilestr,stiffener,120);
	   strncat(tofilestr,dirsep,10);
	   strncat(tofilestr,"history.txt",30);

	   ssed(fromfilestr,"mmm",username,tofilestr);

	   rm_file("stif.tmp");
	   rm_file("stif.tmp1");
     // cat $SRC/textfiles/stif.hist $SRC/textfiles/stif.prep | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > stif.tmp
   }
	else
   {
		strncpy(fromfilestr,SRC,120);   // SRC/textfiles/stif.hist
       strncat(fromfilestr,dirsep,10);
       strncat(fromfilestr,"textfiles",20);
       strncat(fromfilestr,dirsep,10);
       strncat(fromfilestr,"stif.hist",20);

	   strncpy(tofilestr,"stif.tmp",20);
	   ssed(fromfilestr,"mmmmm",today,tofilestr);

	   strncpy(fromfilestr,"stif.tmp",20);

	   strncpy(tofilestr,"stiffener",20);
	   strncat(tofilestr,dirsep,10);
	   strncat(tofilestr,stiffener,120);
	   strncat(tofilestr,dirsep,10);
	   strncat(tofilestr,"history.txt",30);

        ssed(fromfilestr,"mmm",username,tofilestr);  // > stiffener/$stiffener/history.txt
 
      // cat $SRC/textfiles/stif.hist | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > stif.tmp   
      printf( "No stiffener review prep information available\n");
   }

   stiftmpfile=fopen(tofilestr,"a");
   fprintf(stiftmpfile, "%s  %6s%7sRelease Preparation \n", today,REV,ECO ); // >> stif.tmp
   fclose(stiftmpfile);

  // ux2dos stif.tmp > stiffener/$stiffener/history.txt
  // rm -f stif.tmp
   chmod_file( 777, "stiffener");

   strncpy(chkfilestr,"stiffener",30);
   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,stiffener,120);

   chmod_file( 777, chkfilestr);

   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,"*",4);

   chmod_file( 777, chkfilestr);


}     


if ( (strcmp(adhesive,"") != 0 ) && (strcmp(adhused,"new") == 0 ) )
{
   if ( ! (dir_exists("adhesive" ) ) )
   {
      mkdir("adhesive");
   }
   strncpy(mkdirstr,"adhesive",30);   // adhesive/$adhesive
   strncat(mkdirstr,dirsep,10);
   strncat(mkdirstr,adhesive,120);

   mkdir(mkdirstr);          //  adhesive/$adhesive

   strncpy(fromfilestr,SRC,120);   //  $SRC/adhesive.mcm
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"adhesive.mcm",20);

   strncpy(tofilestr,"adhesive",120);   // adhesive/$adhesive/$adhesive.mcm
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,adhesive,100);
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,adhesive,100);
   strncat(tofilestr,".mcm",10);
   cp_file(fromfilestr,tofilestr);

   // cp -p $SRC/adhesive.mcm adhesive/$adhesive/$adhesive.mcm

   strncpy(fromfilestr,SRC,120);   //    $SRC/adhesive/*
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"adhesive",30);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"*",10);

   strncpy(tofilestr,"adhesive",120);   // adhesive/$adhesive
   strncat(tofilestr,dirsep,10);
   strncat(tofilestr,adhesive,100);
   _snprintf(commandstr,500,"cp -p %s %s",fromfilestr,tofilestr);
   system(commandstr);

   // cp -p "$SRC/adhesive/*" adhesive/$adhesive

  // strncpy(chkfilestr,dirsep,10);   // IS THIS OK?  textfiles/stif.prep
   strncpy(chkfilestr,"textfiles",30);
   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,"ad.prep",20);

   if ( file_exists( chkfilestr) )   // -a textfiles/ad.prep )
   {
         strncpy(fromfilestr,SRC,120);   // SRC/textfiles/ad.hist
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"textfiles",20);
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"ad.hist",20);

         strncpy(catfilestr,SRC,120);   // $SRC/textfilest/ad.prep
		 strncat(catfilestr,dirsep,10);
		 strncat(catfilestr,chkfilestr,120);

		 strncpy(tofilestr,"ad.tmp",30);

         cat_files(fromfilestr,catfilestr,tofilestr);  // > ad.tmp

         strncpy(fromfilestr,"ad.tmp",30);
         strncpy(tofilestr,"ad.tmp1",30);
		 ssed(fromfilestr,"mmmmm",today,tofilestr);       // > ad.tmp1

		 strncpy(fromfilestr,"ad.tmp1",30);

		 strncpy(tofilestr,"adhesive",20);  // adhesive/$adhesive/history.txt
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,adhesive,120);
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,"history.txt",30);

		 ssed(fromfilestr,"mmm",username,tofilestr);   // >adhesive/$adhesive/history.txt

		 rm_file("ad.tmp");
		 rm_file("ad.tmp1");
      //cat $SRC/textfiles/ad.hist $SRC/textfiles/ad.prep | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > ad.tmp
   }
	 else
   {
         strncpy(fromfilestr,SRC,120);   // SRC/textfiles/ad.hist
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"textfiles",20);
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"ad.hist",20);
          
		 strncpy(tofilestr,"ad.tmp",20);
		 ssed(fromfilestr,"mmmmm",today,tofilestr);

         strncpy(fromfilestr,"ad.tmp",20);

         strncpy(tofilestr,"adhesive",20);  // adhesive/$adhesive/history.txt
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,adhesive,120);
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,"history.txt",30);
		 ssed(fromfilestr,"mmm",username,tofilestr);

         rm_file("ad.tmp");

     // cat $SRC/textfiles/ad.hist | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > ad.tmp
      printf( "No adhesive review prep information available\n");
   }
   adtmpfile=fopen(tofilestr,"a");

   fprintf(adtmpfile, "%s  %6s%7sRelease Preparation",today,REVB,ECO); // >> ad.tmp
   fclose(adtmpfile);

   // ux2dos ad.tmp > adhesive/$adhesive/history.txt
   //rm -f ad.tmp
   //######### add drawing move here
   chmod_file( 777, "adhesive");

   strncpy(chkfilestr,"adhesive",30);
   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,adhesive,120);

   chmod_file( 777, chkfilestr );

   strncat(chkfilestr,dirsep,10);
   strncat(chkfilestr,"*",4);

   chmod_file( 777, chkfilestr );
}

if ( strcmp(lid,"" ) != 0 )
{
   if ( strcmp(lidused,"new" ) == 0 )
   {
      //lidbase=${lid%%-*}
	  split(lid,lidbase,lidext,"-");

      if ( ! (dir_exists("lid" ) ) )
      {
         mkdir("lid");
      }

      strncpy(mkdirstr,"lid",12);   // lid/$lid
	  strncat(mkdirstr,dirsep,10);
	  strncat(mkdirstr,lid,120);

      mkdir(mkdirstr);   //  lid/$lid

      strncpy(fromfilestr,SRC,120);    // $SRC/lid.mcm
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"lid.mcm",15);
	  
	  strncpy(tofilestr,"lid",10);  // lid/$lid/$lid.mcm
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,lid,120);
	  strncat(tofilestr,dirsep,10);
      strncat(tofilestr,lid,120);
	  strncat(tofilestr,".mcm",8);

       cp_file(fromfilestr,tofilestr);

      //cp -p $SRC/lid.mcm lid/$lid/$lid.mcm

	  strncpy(fromfilestr,SRC,120);    // $SRC/lid/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"lid",10);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",4);

      strncpy(tofilestr,"lid",10);  // lid/$lid
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,lid,120);

	   _snprintf(commandstr,500,"cp -p %s %s", fromfilestr,tofilestr);
       system(commandstr);
	   //cp -p "$SRC/lid/*" lid/$lid
// ############## drawing move

    // strncpy(chkfilestr,dirsep,10);   // IS THIS OK?  textfiles/lid.prep
     strncpy(chkfilestr,"textfiles",30);
     strncat(chkfilestr,dirsep,10);
     strncat(chkfilestr,"lid.prep",20);

      if ( file_exists( chkfilestr) )
      {
	     strncpy(fromfilestr,SRC,120);   // $SRC/textfiles/lid.hist
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"textfiles",20);
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"lid.hist",20);

         strncpy(catfilestr,SRC,120);   // $SRC/textfiles/lid.prep
		 strncat(catfilestr,dirsep,10);
		 strncat(catfilestr,chkfilestr,120);

		 strncpy(tofilestr,"lid.tmp",120); // >lid.tmp

         cat_files(fromfilestr,catfilestr,tofilestr);  // >lid.tmp

         strncpy(fromfilestr,"lid.tmp",30);
         strncpy(tofilestr,"lid.tmp1",30);
		 ssed(fromfilestr,"mmmmm",today,tofilestr);

		 strncpy(fromfilestr,"lid.tmp1",30);

		 strncpy(tofilestr,"lid",20);  // lid/$lid/history.txt
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,lid,120);
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,"history.txt",30);

		 ssed(fromfilestr,"mmm",username,tofilestr);

		 rm_file("lid.tmp");
		 rm_file("lid.tmp1");

         //cat $SRC/textfiles/lid.hist $SRC/textfiles/lid.prep | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > lid.tmp
       }
	   else
	   {
	     strncpy(fromfilestr,SRC,120);   // $SRC/textfiles/lid.hist
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"textfiles",20);
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"lid.hist",20);

         strncpy(tofilestr,"lid.tmp",20);   // lid.tmp

         ssed(fromfilestr,"mmmmm",today,tofilestr);        // lid.tmp

         strncpy(fromfilestr,"lid.tmp",20);

         strncpy(tofilestr,"lid",20);  // lid/$lid/history.txt
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,lid,120);
		 strncat(tofilestr,dirsep,10);
		 strncat(tofilestr,"history.txt",30);

         ssed(fromfilestr,"mmm",username,tofilestr);      // >lid/$lid/history.txt

         rm_file("lid.tmp");

         //cat $SRC/textfiles/lid.hist | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > lid.tmp
         printf( "No lid review prep information available\n");
      }
	  lidtmpfile=fopen(tofilestr,"a");

      fprintf(lidtmpfile, "%s  %6s%7sRelease Preparation\n",today,REVB,ECO); // >> lid.tmp
	  fclose(lidtmpfile);

      // ux2dos lid.tmp > lid/$lid/history.txt
      // rm -f lid.tmp
      chmod_file( 777, "lid" );

	  strncpy(chkfilestr,"lid",10);
	  strncat(chkfilestr,dirsep,10);
	  strncat(chkfilestr,lid,120);

      chmod_file( 777, chkfilestr);

	  strncat(chkfilestr,dirsep,5);
	  strncat(chkfilestr,"*",4);

      chmod_file( 777, chkfilestr );
   }
}

// Board
if ( strcmp(board,"" ) !=0 )
{
   if ( strcmp(brdused,"new" ) == 0 )
   {
      if ( ! (dir_exists("board" ) ) )
      {
         mkdir("board");
      }

	  strncpy(commandstr,"cp -R -p ",15);   // cp -p R $SRC $board
	  strncat(commandstr,SRC,120);
	  strncat(commandstr," ",10);
	  strncat(commandstr,"board",30);
	

	  printf("Copying board information from %s to %s \n",SRC,board);
	  system(commandstr);
      //cp -p -R $SRC board
      
      chmod_file( 777, "board");

	  strncpy(chkfilestr,"board",30);
	  strncat(chkfilestr,dirsep,5);
	  strncat(chkfilestr,board,200);

      chmod_file( 777, chkfilestr);
      
      //cd board/$board

      strncpy(tofilestr,"board",20);
	  strncat(tofilestr,dirsep,10);
	  strncat(tofilestr,board,140);

	  change_dir(tofilestr);

      rm_files_ext(".Z"); // -f *.Z

      
      // Board history file
	 // strncpy(chkfilestr,dirsep,10);
	  strncpy(chkfilestr,"textfiles",20);  // textfiles/brd.prep
	  strncat(chkfilestr,dirsep,10);
	  strncat(chkfilestr,"brd.prep",20);

      if ( file_exists( chkfilestr) )  //   -a /textfiles/brd.prep 
      { 
		  
		 strncpy(fromfilestr,SRC,120);   // SRC/textfiles/brd.hist
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"textfiles",20);
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"brd.hist",20);

         strncpy(catfilestr,SRC,120);   // $SRC/textfiles/brd.prep
		 strncat(catfilestr,dirsep,10);
		 strncat(catfilestr,chkfilestr,120);

		 strncpy(tofilestr,"brd.tmp",10);

         cat_files(fromfilestr,chkfilestr,tofilestr);   // brd.hist brd.prep > brd.tmp

         strncpy(fromfilestr,"brd.tmp",30);
         strncpy(tofilestr,"brd.tmp1",30);
		 ssed(fromfilestr,"mmmmm",today,tofilestr);  // chg mmmmm in brd.tmp to today > brd.tmp1

		 strncpy(fromfilestr,"brd.tmp1",30);

		 strncpy(tofilestr,"brd.tmp2",20);  // brd.tmp2

		 ssed(fromfilestr,"mmm",username,tofilestr); // chg mmm in brd.tmp1 to username >brd.tmp2

		 rm_file("brd.tmp");
		 rm_file("brd.tmp1");

         // cat $SRC/textfiles/brd.hist $SRC/textfiles/brd.prep | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > brd.tmp
      }
	  else
	  {
		 strncpy(fromfilestr,SRC,120);   // SRC/textfiles/brd.hist
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"textfiles",20);
         strncat(fromfilestr,dirsep,10);
         strncat(fromfilestr,"brd.hist",20);

		 strncpy(tofilestr,"brd.tmp",20);

		 ssed(fromfilestr,"mmmmm",today,tofilestr);  // sed SRC/textfiles/brd.hist -s/mmmmm/today/

          strncpy(fromfilestr,"brd.tmp",20);

		  strncpy(tofilestr,"brd.tmp2",20);

		  ssed(fromfilestr,"mmm",username,tofilestr);

         //cat $SRC/textfiles/brd.hist | sed s/mmmmm/"$sedtoday"/ | sed s/mmm/"$username"/ > brd.tmp
         printf( "No board review prep information available\n");
      }
	 brdtmpfile=fopen("brd.tmp2","a");

     fprintf(brdtmpfile,"%s  %s%13s%13s%7s Release Preparation\n",today,REVB,oldpn,newpn,ECO); //>> brd.tmp
      
	 fclose(brdtmpfile);

	if ( file_exists("history.txt") )  // -a history.txt 
      {
	   cp_file( "brd.tmp2","history2.txt"); //  > history2.txt
	   if (beepflag)
	   {
	     printf( "\a" );   // beep
	   }

	   printf( "**********************************************************\n");
	   printf( "NOTE - new board history info is in history2.txt.\n" );
	   printf( "       Combine this data with the existing history.\n");
	   printf( "       Also include assembly ancestry in assembly history.\n");
	   printf( "**********************************************************\n");
	  }
    else
	  {
         //ux2dos brd.tmp > history.txt
		cp_file("brd.tmp2","history.txt");

      }

      rm_file("brd.tmp2");

      
      // Need to remove stuff from board that was copied elsewhere
      
      // look for design input file
      // dummy=$(ls *.des > /dev/null)
      desfile=scandir_matchext( ".",0,".des");
      if (desfile != 0)
      {
	   printf( "No .des file found.  Paper Input Sheet needed for file!!!!!!!!\n");
      }
     
      
      // Get rid of extra & unnecessary files
      rm_files_ext(".old");

	  printf("Removing log \n");

	  rm_files_ext(".log");
	  //rm -f *,*            what is this?
	  rm_files_ext(".z");
	  rm_file("99xxx.mcm");
	  rm_files_ext(".jrl");
	  rm_file("master.tag");

	  rm_all_ext(".", ".htm");             // 2> /dev/null

      printf("Removing drag_it \n");

	  strncpy(fromfilestr,"drag_it",10);  // drag_it/*/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);

	  _snprintf(commandstr,500,"rm -f %s ",fromfilestr);

      //rm -f drag-it/*/*
	  strncpy(fromfilestr,"drag_it",10);  // drag_it/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);

	  _snprintf(commandstr,500,"rm -f %s ",fromfilestr);
      system(commandstr);

	 // rm -f drag-it/*           // 2> /dev/null 

      printf("Removing textfiles \n");

      strncpy(fromfilestr,"textfiles",10);  // textfiles/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);

      _snprintf(commandstr,500,"rm -f %s ",fromfilestr);
	  system(commandstr);

      printf("Removing mech/dwg/*/*  \n");
     // rm -f textfiles/* 
      strncpy(fromfilestr,"mech",10);  // mech/dwg/*/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"dwg",10);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);

      _snprintf(commandstr,500,"rm -f %s ",fromfilestr);
	  system(commandstr);

	 // rm -f mech/dwg/*/* 

	  printf("Removing mech/dwg/*  \n");
      strncpy(fromfilestr,"mech",10);  // mech/dwg/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"dwg",10);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);
	  
      _snprintf(commandstr,500,"rm -f %s ",fromfilestr);
	  system(commandstr);

	  //rm -f mech/dwg/* 

      printf("Removing mech/src/*/*  files\n");

	  strncpy(fromfilestr,"rm -f ",40);
      strncat(fromfilestr,"mech",10);  // mech/src/*/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"src",10);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);

     // sprintf(commandstr,"rm -f %s ",fromfilestr);   Window doesn't like */*
	  system(fromfilestr);

	 // rm -f mech/src/*/* 
     printf("Removing mech/src/* \n");

      strncpy(fromfilestr,"mech",10);  // mech/src/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"src",10);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);
	  
      _snprintf(commandstr,500,"rm -f %s ",fromfilestr);
	  system(commandstr);

      printf("Removing mech/* \n");

	 // rm -f mech/src/* 
      strncpy(fromfilestr,"mech",10);  // mech/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",10);

	  //rm -f mech/* 
	  _snprintf(commandstr,500,"rm -f %s",fromfilestr);
	  system(commandstr);

      printf("Removing all .des files \n");
	  rm_files_ext(".des"); 
	  rm_file("pn.txt");
	  rm_file("used.txt");
	  rm_file("stencil.mcm");          // 2> /dev/null

      system("rm -f stiffener.* \n");

	  rm_file("adhesive.mcm");

      printf("Removing pre_bias/stiff.art ");

	  strncpy(fromfilestr,"pre-bias",20);   // pre_bias/stiff.art
	  strncat(fromfilestr,dirsep,10);
      strncat(fromfilestr,"stiff.art",20);
	  rm_file(fromfilestr);

	 // rm -f pre-bias/stiff.art 

      strncpy(fromfilestr,"pre-bias",20);  // pre_bias/adhesive*
	  strncat(fromfilestr,dirsep,10);
      strncat(fromfilestr,"adhesive*",20);

	  _snprintf(commandstr,500,"rm -f %s",fromfilestr);
	  system(commandstr);

	  // rm -f pre-bias/adhesive* 

      printf("Removing all pre_bias/adhesive \n");
       strncpy(fromfilestr,"mech",20);  // pre_bias/adhesive
	  strncat(fromfilestr,dirsep,10);
      strncat(fromfilestr,"stiff*.*",20);

	  _snprintf(commandstr,500,"rm -f %s",fromfilestr);
	  system(commandstr);

	 // rm -f mech/stiff*.*             //2> /dev/null

      printf("Removing all pre_bias/stencil/*.* \n");
      strncpy(fromfilestr,"pre-bias",20);  // pre_bias/stencil*.*
	  strncat(fromfilestr,dirsep,10);
      strncat(fromfilestr,"stencil*.*",20);

	  _snprintf(commandstr,500,"rm -f %s",fromfilestr);
	  system(commandstr);

      // rm -f pre-bias/stencil*.*
	   printf("Removing all pre_bias/lid*.* \n");

	  strncpy(fromfilestr,"pre-bias",20);  // pre_bias/lid*.*
	  strncat(fromfilestr,dirsep,10);
      strncat(fromfilestr,"lid*.*",20);

	  _snprintf(commandstr,500,"rm -f %s",fromfilestr);
	  system(commandstr);

      // rm -f pre-bias/lid*.* 

      printf("Removing all mech/lid*.* \n");

      strncpy(fromfilestr,"mech",20);  // mech/lid*.*
	  strncat(fromfilestr,dirsep,10);
      strncat(fromfilestr,"lid*.*",20);

	  _snprintf(commandstr,500,"rm -f %s",fromfilestr);
	  system(commandstr);

	 // rm -f mech/lid*.* 
	  rm_file("lid.mcm"); 

      printf("Removing adhesive/* \n");

      strncpy(fromfilestr,"adhesive",20);  // adhesive/*
	  strncat(fromfilestr,dirsep,10);
      strncat(fromfilestr,"*",20);

	  _snprintf(commandstr,500,"rm -f %s",fromfilestr);
	  system(commandstr);

     // rm -f adhesive/* 

      printf("Removing stencil/* \n");
      strncpy(fromfilestr,"stencil",20);  // stencil/*
	  strncat(fromfilestr,dirsep,10);
      strncat(fromfilestr,"*",20);

      _snprintf(commandstr,500,"rm -f %s",fromfilestr);
	  system(commandstr);

	  // rm -f stencil/* 

      printf("Removing lid/* \n");
      strncpy(fromfilestr,"lid",20);  // lid/*
	  strncat(fromfilestr,dirsep,10);
      strncat(fromfilestr,"*",20);

      _snprintf(commandstr,500,"rm -f %s",fromfilestr);
	  system(commandstr);

	  // rm -f lid/* 

      printf("Removing report/drc_summ_skell \n");
	  strncpy(fromfilestr,"report",30);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"drc_summ_skell",30);
      rm_file(fromfilestr);

	  // rm -f report/drc_summ_skel    //  2> /dev/null
     // rmdir drag-it
	  rmdir("drag-it");
	  rmdir("textfiles");

      printf("Removing mech/src/* dirs \n");

	  strncpy(fromfilestr,"rm -r -f ",30);
	  strncat(fromfilestr,"mech",10);   // mech/src/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"src",10);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",4);

	  //sprintf(commandstr,"rmdir %s",fromfilestr);
	  system(fromfilestr);

	 // rmdir mech/src/*  
	  printf("Removing mech/src/* dirs\n");

	  strncpy(fromfilestr,"mech",10);   // mech/src
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"src/*",10);
	  rmdir(fromfilestr);

      printf("Removing mech/dwg/* \n");

	  strncpy(fromfilestr,"rm -r -f ",30);
      strncat(fromfilestr,"mech",10);   // mech/dwg/*
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"dwg",10);
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"*",4);


	 // sprintf(commandstr,"rmdir %s",fromfilestr);
	  system(fromfilestr);


	  //rmdir mech/dwg/* 

	  //rmdir mech/dwg 

      printf("Removing mech/dwg \n");

	  strncpy(fromfilestr,"mech",10);   // mech/dwg
	  strncat(fromfilestr,dirsep,10);
	  strncat(fromfilestr,"dwg",10);
	  rmdir(fromfilestr);

     printf("Removing directories: mech 274x mfg laser drill scm adhesiv lid \n");

	  rmdir("mech");
	  rmdir("274x");
	  rmdir("mfg");
	  rmdir("laser");
	  rmdir("drill"); 
	  rmdir("scm");
	  rmdir("adhesive");
	  rmdir("stencil");
	  rmdir("lid");          // 2>/dev/null

      chmod_file( 777,"*");
      chmod_file( 777, "*/*");
      chmod_file( 777, "*/*/*"); // 2>/dev/null
      chmod_file( 777, "*/*/*/*");  // 2>/dev/null
      chmod_file( 777, "*/*/*/*/*");   // 2>/dev/null
      chmod_file( 777, "*/*/*/*/*/*");  // 2>/dev/null
      chmod_file( 777, "*/*/*/*/*/*/*"); // 2>/dev/null
   }
}


// Build the camjob folder

printf("Creating camjob folder\n");

change_dir(target);
mkdir("camjob");
change_dir( "camjob");
mkdir(board);
change_dir( board );
mkdir("brd_info");
mkdir("274x");
if ( !dir_exists ( "pre-bias") )
{
	mkdir("pre-bias");
}

printf("Copying report/offsets \n");

strncpy(fromfilestr,target,120); // $target/rdb/board/$board/report/offsets
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"rdb",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"board",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,board,100);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"report",15);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"offsets",20);

strncpy(tofilestr,".",10);           // ./brd_info/offsets
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"brd_info",30);
strncat(tofilestr,dirsep,10);
strncat(tofilestr,"offsets",20);

cp_file(fromfilestr,tofilestr);


printf("Copying report/cd.txt \n");

// cp $target/rdb/board/$board/report/offsets ./brd_info

strncpy(fromfilestr,target,120); // $target/rdb/board/$board/report/cd.txt
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"rdb",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"board",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,board,120);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"cd.txt",20);

cp_file(fromfilestr,"cd.txt");

// cp $target/rdb/board/$board/cd.txt .
printf("Copying board/%s/cam info \n",board);

strncpy(fromfilestr,target,120);  // $target/rdb/board/$board/cam
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"rdb",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"board",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,board,120);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"cam",10);

_snprintf(commandstr,500,"cp -R %s . \n",fromfilestr);
system(commandstr);

printf("%s", commandstr);

// cp -R $target/rdb/board/$board/cam .

strncpy(fromfilestr,target,120);  // $target/rdb/board/$board/control
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"rdb",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"board",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,board,120);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"control",10);

_snprintf(commandstr,500,"cp -R %s . \n",fromfilestr);
system(commandstr);

if ( !dir_exists ( "pre-bias") )
{
	mkdir("pre-bias");
}

// cp -R $target/rdb/board/$board/control .
strncpy(fromfilestr,"cp -R ",10);
strncat(fromfilestr,target,120);  // $target/rdb/board/$board/pre-bias
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"rdb",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"board",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,board,120);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"pre-bias",15);
strncat(fromfilestr," .",10);

//sprintf(commandstr,"cp -R %s . \n",fromfilestr);
system(fromfilestr);

printf("%s\n", fromfilestr);

// cp -R $target/rdb/board/$board/pre-bias .

strncpy(fromfilestr,"cp -R ", 10);
strncat(fromfilestr,target,120);  // $target/rdb/board/$board/test
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"rdb",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"board",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,board,120);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"test",10);
strncat(fromfilestr," . ", 10);

//sprintf(commandstr,"cp -R %s . \n",fromfilestr);
system(fromfilestr);
printf("%s \n", fromfilestr);

// cp -R $target/rdb/board/$board/test .
//sprintf(commandstr,"mv pre-bias%sv*.art 274x",dirsep);

system("mv pre-bias/v*.art 274x");
printf("%s \n","mv pre-bias/v*art 274x");

system("mv pre-bias/s*.art 274x");

printf("%s \n", "mv pre-bias/s*.art 274x");

strncpy(fromfilestr,"pre-bias",20);  // pre-bias/outline.art
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"outline.art",30);

if ( file_exists(fromfilestr) )
{
  strncpy(tofilestr,"274x",10);
  strncat(tofilestr,dirsep,10);
  strncat(tofilestr,"outline.art",30);
  cp_file(fromfilestr,tofilestr);
  rm_file(fromfilestr);
}
else
{
	printf("Unable to copy 274x/outline.art, file does not exist \n");
}


//mv pre-bias/outline.art 274x

printf("Copy pre-bias/cutout.art \n");

strncpy(fromfilestr,"pre-bias",20);  // pre-bias/cutout.art
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"cutout.art",30);

if ( file_exists(fromfilestr) )
{
  strncpy(tofilestr,"274x",10);    // 274x/cutout.art
  strncat(tofilestr,dirsep,10);
  strncat(tofilestr,"cutout.art",30);
  cp_file(fromfilestr,tofilestr);
  rm_file(fromfilestr);
}
else
{
	printf("Unable to copy the pre-bias/cutout.art file, file does not exist \n");
}

// mv pre-bias/cutout.art 274x   // 2>/dev/null

strncpy(fromfilestr,"pre-bias",20);  // pre-bias/npd.art
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"npd.art",30);

if ( file_exists(fromfilestr) )
{
  strncpy(tofilestr,"274x",10);         // 274x/npd.art
  strncat(tofilestr,dirsep,10);
  strncat(tofilestr,"npd.art",30);
  cp_file(fromfilestr,tofilestr);
  rm_file(fromfilestr);
}
else
{
	printf("Unable to copy the pre-bias/npd.art file, file does not exist \n");
}

// mv pre-bias/npd.art 274x       // 2>/dev/null

printf("Removing cam/cam-exceptions \n");

strncpy(fromfilestr,"cam",10);
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"cam-exceptions",30);

rmdir(fromfilestr); //   cam/cam-exceptions/*

chmod_file(777, "*");
chmod_file(777, "*/*");
chmod_file(777, "*/*/*"); //  2>/dev/null
//cd ..
change_dir("..");

chmod_file(777, board );
change_dir(target);

strncpy(chkdirstr,target,120);  // $target/rdb/adhesive/$adhesive 
strncat(chkdirstr,dirsep,10);
strncat(chkdirstr,"rdb",10);
strncat(chkdirstr,dirsep,10);
strncat(chkdirstr,"adhesive",20);
strncat(chkdirstr,dirsep,10);
strncat(chkdirstr,adhesive,120);

printf("Check for rdb/adhesivie/%s \n", adhesive );

if ( dir_exists(chkdirstr) )     // $target/rdb/adhesive/$adhesive 
{

   strncpy(mkdirstr,"camjob",20);   // camjob/adhesive
   strncat(mkdirstr,dirsep,10);
   strncat(mkdirstr,"adhesive",20);

   mkdir(mkdirstr);  //  camjob/adhesive

   strncpy(fromfilestr,target,120);  // $target/rdb/adhesive/$adhesive 
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"rdb",10);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"adhesive",20);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,adhesive,100);

   _snprintf(commandstr,500,"cp -R %s %s",fromfilestr, mkdirstr);
   system(commandstr);

//   cp -R $target/rdb/adhesive/$adhesive camjob/adhesive

  // rm -f camjob/adhesive/$adhesive/*.mcm

   strncpy(fromfilestr,"camjob",20);  // camjob/adhesive/$adhesive 
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,"adhesive",20);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,adhesive,120);
   
   rm_all_ext(fromfilestr,".mcm");
}

//######################  Do something about strip stiffeners / adhesive screens ##############################



printf( "DONE!\n");
printf( " \n");
printf( "Data placed in %s%srdb\n",target,dirsep);
printf( "Check the contents of all folders.\n");
printf( "Check the text files, especially histories.\n");
printf( "Assure the history has the correct tabs and ECO references.\n");
printf( "Correct any problems with history files for all components.\n");
printf( "...........................................................\n");
printf( "Use the %s%scamjob%s%s folder for NT processing.\n",target,dirsep,dirsep,board);
printf( "Check its pre-bias and 274x folders for correct files.\n");


}  // end

int main( int argc, char **argv)
{
int numargs;

numargs=argc;
beepflag = TRUE;

if (numargs > 2)
{
   printf( "rdbrelprep: Wrong number of arguments !\n");
   printf("rdbrelprep [nobeep] \n");

   exit(-1);
}
else
{
	if (numargs == 2 )
	{
      if (strcmp ( argv[1], "nobeep" ) == 0 )
	  {
		  beepflag=FALSE;
	  }
	}


      rdb_relprep_call();
}


} // end main

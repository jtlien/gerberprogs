
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

void remover_call()
{
char proguser[300];
char *lichost;
char *licport;
char appname[300];
char username[300];
char handle[300];
char LIC_TOOLPATH[300];
char LIC_FILEPATH[300];
char systemstr[300];
int appl;
int result0;
int result1;
int allok;
int unlen;
int mnlen;
int result2;
int ii;
int app_count;
int grepcnt;
int handle_count;
char runyes[30];
int grepret;

// Remove FlexLM licenses
// Build the command based on application, user, and handle
// entered by operator.

// Limit operators to admins
get_whoami( proguser);
if( (strcmp(proguser,"dah") != 0 ) && (strcmp(proguser,"bac") != 0 )  && ( strcmp(proguser,"root") != 0 )
                                 && (strcmp(proguser,"cdsmgr") != 0 ))
{
   printf( "Sorry, %s is not authorized to use this program.\n",proguser);
   printf( "Please see bac or dah to deal with license problems.\n");
   exit(-1);
}

// Determine license host server
//lichost=${LM_LICENSE_FILE##*@}
lichost=getenv("LM_LICENSE_FILE");

if ( strcmp( lichost,"maui" ) == 0 )
{
   strncpy(LIC_TOOLPATH,"/usr/local/flexlm/tools.hppa/bin",120);
   strncpy(LIC_FILEPATH,"/usr/local/flexlm/share/license/license.dat",120);

   printf( "License host is %s \n", lichost);
}
else if ( strcmp( lichost,"sark") == 0 )
{
   strncpy(LIC_TOOLPATH,"/swtools/license/bin",120);
   strncpy(LIC_FILEPATH,"/swtools/license/data/license.txt",120);
   printf("License host is %s \n", lichost);
}
else
{
   printf( "Unrecognized license host: %s \n",lichost);
   printf( "Exiting!\n");
   exit(-1);
}

// Determine license port
//licport=${LM_LICENSE_FILE%%@*}

licport=getenv("LM_LICENSE_FILE");

printf("License port is %s \n",licport );


// Get and check for application name
appl=0;
result0=7;
allok=0;

while( allok != 1)
{
   while( result0 != 0)
   {
      while( appl <  1)
      {
         printf("Enter application name (exact match): \n");
         gets( appname);
         //appl=${#appname}
		 appl=strlen(appname);
	  }

    // $LIC_TOOLPATH/lmstat -a -c $LIC_FILEPATH | grep vendor | grep $appname > /dev/null

	  strncpy(systemstr,LIC_TOOLPATH,120);
	  strncat(systemstr,"/lmstat -a -c ",30);
	  strncat(systemstr,LIC_FILEPATH,120);
	  strncat(systemstr," >stat.tmp ",20);

	  system(systemstr);

	  grepret = grep_count("stat.tmp", "vendor",  &grepcnt);

	  app_count=0;
	  for(ii=0; ii < grepcnt; ii += 1)
	  {
		  if ( strstr(grep_array[ii], appname) != NULL)
		  {
			  app_count+=1;
		  }
	  }
     //result0=$?
	  result0=app_count;

     if (result0 > 0)
	 {
        printf( "String not found or no licenses checked out. Try again!\n");
        appl=0;
     }
   }
 

  // Get and check for user name
   unlen=0;
   result1=7;
   while( result1 != 0)
   {
      while( unlen < 1)
      {
         printf( "Enter user name: \n");
         gets(username);
        //unlen=${#username}
		 unlen=strlen(username);
      }
    //  $LIC_TOOLPATH/lmstat -a -c $LIC_FILEPATH | grep $username > /dev/null
	  strncpy(systemstr,LIC_TOOLPATH,120);
	  strncat(systemstr,"/lmstat -a -c ",30);
	  strncat(systemstr,LIC_FILEPATH,120);
	  strncat(systemstr," >stat.tmp ",20);

	  system(systemstr);

	  grepret = grep_count("stat.tmp",username,&grepcnt);

     // result1=$?
	  result1=grepcnt;

      if(result1 > 0)
      {
         printf( "User name not found in lmstat report. Try again!\n");
         unlen=0;
	  }
      else
	  {
        // $LIC_TOOLPATH/lmstat -a -c $LIC_FILEPATH | grep $username
		  system(systemstr);
		  grepcnt=sgrep("stat.tmp",username,300);
      }
   }

   // Get and check for magic number (handle)
   mnlen=0;
   result2=7;

   while( result2 != 0)
   {
      while(mnlen < 1)
      {
         printf("Enter handle of license to drop (last number in parens): \n");
         gets(handle);
         //mnlen=${#handle}
		 mnlen=strlen(handle);
      }

	  // $LIC_TOOLPATH/lmstat -a -c $LIC_FILEPATH | grep $username | grep $handle > /dev/null

	  strncpy(systemstr,LIC_TOOLPATH,120);
	  strncat(systemstr,"/lmstat -a -c ",30);
	  strncat(systemstr,LIC_FILEPATH,120);
	  strncat(systemstr," >stat.tmp ",20);

	  system(systemstr);

	  grepcnt = sgrep("stat.tmp",username,300);

	  handle_count = 0;

	  for(ii=0; ii < grepcnt; ii += 1)
	  {
		  if (strstr(grep_array[ii],handle) != NULL)
		  {
			  handle_count += 1;
		  }
	  }

     
    //  result2=$?

	  result2=handle_count;

      if ( result2 > 0)
      {
         printf( "Handle / user name combination not found. Try again!\n");
         mnlen=0;
	  }
      else
	  {
         printf("Here is the command: \n");

         printf("%s/lmremove -c %s -h %s %s %s %s \n",
			  LIC_TOOLPATH, LIC_FILEPATH, appname, lichost,licport,handle);

      }
   }

   printf(" \n");
   // printf("Here is the command: \n");
   //printf("%s/lmremove -c %s -h %s %s %s %s \n",LIC_TOOLPATH,LIC_FILEPATH,
       //        appname,lichost,licport,handle);
   strncpy(runyes,"x",10);

   while ( (strcmp( runyes,"y") != 0 ) && ( strcmp(runyes,"n") != 0 ))          //  $runyes = n ]]
   {
      printf("To execute this command, press y. To decline and start over, press n. \n");
      gets(runyes);
      if( strcmp(runyes, "y") == 0 )
      {
         printf( "Executing command...\n");
         allok=1;
         // execute command
       //  $LIC_TOOLPATH/lmremove -c $LIC_FILEPATH -h $appname $lichost $licport $handle
        strncpy(systemstr,LIC_TOOLPATH,120);
	    strncat(systemstr,"/lmremove -c ",30);
	    strncat(systemstr,LIC_FILEPATH,120);
	    strncat(systemstr," -h ",20);
		strncat(systemstr,appname,100);
		strncat(systemstr," ",5);
		strncat(systemstr,lichost,100);
        strncat(systemstr," ",5);
		strncat(systemstr,licport,100);
        strncat(systemstr," ",5);
		strncat(systemstr,handle,100);
	    system(systemstr);

         printf(" \n");
         printf( "Here is the new list of licenses used by  %s \n", username);
         //$LIC_TOOLPATH/lmstat -a -c $LIC_FILEPATH | grep $username

         strncpy(systemstr,LIC_TOOLPATH,120);
	     strncat(systemstr,"/lmstat -a -c ",30);
	     strncat(systemstr,LIC_FILEPATH,120);
	     strncat(systemstr," >stat.tmp ",20);

	     system(systemstr);

		 grepcnt=sgrep("stat.tmp", username,300);

         printf( " \n");
         printf( "Verify that you removed the desired license.\n");
         printf("exiting...\n");
		 }
      else
	  {
         appl=0;
         result0=7;
         unlen=0;
         result1=7;
         mnlen=0;
         result2=7;
         printf("STARTING OVER.....\n");
         printf(" \n");
	  }
      
   }
 }


} // end remover_call


int main(int argc, char **argv)
{
	if (argc != 1)
	{
		printf("Remover does not take arguments \n");
		exit(-1);
	}
    else
	{
		remover_call();
	}

}  // end main

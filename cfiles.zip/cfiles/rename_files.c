#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// rename_files
// program renames files in the current directory based on the names in the input file.
// renames files in column1 to the name in column 2

// Revision history
// rev 1 released to users on 8/8/03

void rename_files_call( char *infilestr)
{
char from[300];
char to[300];
int nf;
char thisline[300];
int endoffile;
FILE *file1;

  if(  file_exists( infilestr) )        //  $1
  {
	  file1=fopen(infilestr,"r");
	  if (file1 == NULL)
	  {
		  printf("In rename_files, unable to open the input file = %s \n", infilestr);
		  exit(-1);
	  }
     endoffile=getline(file1,thisline);
     nf=split_line(thisline);

     while( endoffile==FALSE)     // read from to
     {
		 // printf("str0 = %s str1 = %s \n",str_array[0], str_array[1]);

		 strncpy(from,str_array[0],100);

		 
		 strncpy(to,str_array[1],100);

        if( file_exists( from ) )
        {
			//printf("Renaming file %s to %s \n", from,to);

           cp_file(from,to);
		   rm_file(from);
		}
        else
		{
           fprintf(stderr,"file %s not found\n");
        }

		endoffile=getline(file1,thisline);
		nf=split_line(thisline);

		// printf("thisline=%s \n",thisline);

     }  //  < $1

	 fclose(file1);
  }
  else
  {
      fprintf(stderr,"%s not found \n",infilestr);
  }

} // end

int main( int argc, char **argv)
{

char USAGE[300];
char WHERE[300];
char EXAMPLE[300];

strncpy(USAGE,"usage: rename_files convert_file",80);
strncpy(WHERE,"\tconvert_file is file that contains the from name and to name",120);
strncpy(EXAMPLE,"\tex:  rename_files convert.txt",80);


if(argc != 2)
{
   printf("In rename_file, incorrect number of arguments \n");
   printf( "%s\n%s\n%s\n",USAGE,WHERE,EXAMPLE);
   exit(-1);

}
else
{

  rename_files_call( argv[1]);
}

} // end main

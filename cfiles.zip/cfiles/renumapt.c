
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//
#include "utilprogs.h"
int aptcnt;
char thisline[200];
char str_array[120][120];
FILE *file1;
FILE *renumfile;
char newstr[120];
int endoffile;

int nf;


void renumapt_call( char *startstr, char *infilestr)
{
int aptcnt;
char thisline[200];
FILE *file1;
FILE *renumfile;
char newstr[120];
int endoffile;
int nf;
int i;

  file1 = fopen(infilestr,"r");
  if (file1 == NULL)
  {
   printf("Unable to open the input file = %s \n",infilestr);
   exit(-1);
  }
  renumfile = fopen("renumref","w");
  if (renumfile == NULL)
  {
   printf("Unable to open the output file = %s \n","renumref");
   exit(-1);
  }
  aptcnt = atoi(startstr);    // first argument (start) == integer

  // printf("aptcnt = %d \n",aptcnt);

  fprintf(renumfile,"%5s%5s\n","OLD", "NEW"); //  > "renumref"

   endoffile = getline(file1,thisline);
   nf=split_line(thisline);

  while(endoffile==FALSE)
  {

	// printf("str_array0=%s \n",str_array[0]);

   if( ((str_array[0][0] == 'D') || (str_array[0][0] == 'd'))  && ( isdigit(str_array[0][1]) ) )
   {  
	_snprintf(newstr,80,"D%d", aptcnt);
	fprintf(renumfile,"%5s%5s\n",str_array[0],newstr); //  > "renumref" 
	strncpy(str_array[0],newstr,120);
	aptcnt++;
    for(i=0; i < nf; i+=1)
    {
     printf("%s ",str_array[i]); //  $0 
    }
    printf("\n");
   }
  else
  {
	  printf("%s",thisline);
  }

   endoffile = getline(file1,thisline);
   nf=split_line(thisline);
  }

  fclose(file1);
  fclose(renumfile);

}  // end renumapt_call

void renumapt_call_out( char *startstr, char *infilestr, char *outfilestr)
{
int aptcnt;
char thisline[200];
FILE *file1;
FILE *renumfile;
FILE *outfile;
char newstr[120];
int endoffile;
int nf;
int i;

  file1 = fopen(infilestr,"r");
  if (file1 == NULL)
  {
   printf("Unable to open the input file = %s \n",infilestr);
   exit(-1);
  }
  outfile = fopen(outfilestr,"w");
  if (outfile == NULL)
  {
   printf("Unable to open the output file = %s \n",outfilestr);
   exit(-1);
  }
  renumfile = fopen("renumref","w");
  if (renumfile == NULL)
  {
   printf("Unable to open the output file = %s \n","renumref");
   exit(-1);
  }
  aptcnt = atoi(startstr);    // first argument (start) == integer

  fprintf(renumfile,"%5s%5s\n","OLD", "NEW"); //  > "renumref"

   endoffile = getline(file1,thisline);
   nf=split_line(thisline);

  while(endoffile==FALSE)
  {
   if( ((str_array[0][0] == 'D') || (str_array[0][0] == 'd'))  && ( isdigit(str_array[0][1]) ) )
   {  
	_snprintf(newstr,80,"D%s", aptcnt);
	fprintf(renumfile,"%5s%5s\n",str_array[0],newstr); //  > "renumref" 
	strncpy(str_array[0],newstr,120);
	aptcnt++;
  
    for(i=0; i < nf; i+=1)
    {
     fprintf(outfile,"%s ",str_array[i]); //  $0 
    }
    fprintf(outfile,"\n");
   }
   else
   {
	  fprintf(outfile,"%s",thisline);
   }
   endoffile = getline(file1,thisline);
   nf=split_line(thisline);
  }

  fclose(file1);
  fclose(renumfile);
  fclose(outfile);

}  // end renumapt_call_out

int main( int argc, char **argv)
{
	if (argc != 3)
	{
		printf("In renumapt, wrong number of arguments \n");
		printf("Usage: renumapt startval infile \n");
		exit(-1);
	}
	else
	{
		renumapt_call( argv[1], argv[2]);
	}

}  // end main

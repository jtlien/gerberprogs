#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>


#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

int xcd_call();
int xsummary_call();
int drc_skel_call();
void mkdir( char *dirstr);
void xsmask_call( );
void xsmask_bga_call();



// progname=${0##*/}
// review_prep
// Version 0.1
// Copied from makepanel0.6 3-26-99

// run all panelization-related scripts and save log files
// quit if mcm file matching current subdirectory name is not present
// rev 0.2
// Change sequence so summary.txt file exists before Xplot runs
// April 7, 1999
 
// Copy outline into 274x directory so Xplot will run, then remove it after
// Remove DOS translation of makelog
// Require presence of pn.txt
// Rev 0.3
// April 13, 1999

// Add parsing of pn.txt file to determine which histories to update
// Add release status flag section, keep testmode flag independent
// Rev 0.4 
// May 14, 1999

// Remove code that placed outline in 274x directory. Instead look for it in
// pre-bias
// Rev 0.5
// Nov 10, 1999

// Add dbcheck for links and shapes on board file only
// rev 0.6
// Aug 31, 2000

// Add recognition for lid in pn.txt
// rev 0.7
// Dec 27, 2000

// Change syntax of timestamp
// Change path names to new server
// Drop usage log
// Fix history format & append problem
// Create folder for direct drag to G for design review
// Rev 0.8
// March 27, 2001

// Rev 0.9 released 05/30/01 tsa
// adds check for annular ring for bottom surface soldermask.
// does this by callin Xsmask_bga
//

// rev 1.0 released 10/02/01 tsa
// No longer calls Xreport. This is now done in makeart
//

// rev 1.1 released 05/16/02 bac
// Corrects case-shift problem that leaves gwk file out of drag-it folder 
// Removes prompts telling user to print

// rev1.2 released 06/04/02 tsa
// fixes permission problem with xsmask log files in report directory.
// does a chmod after files are generated.

// rev1.3 released 06/27/02
// fixes a problem of creating a empty History.txt

// rev1.4 released 11/15/02 - tsa
//   Now checks Xsummary result and exists if detects an error.
//   if fails restores old summary.txt
//   Also removes summary.txt header generation. this is now done by Xsummary

// rev 1.5 released 01/10/03 - bac
// Minor corrections to printed messages at end
// Handle differences in database checking between APD versions
// NOTE - temporary fix that ignores DRC out of date warnings

// rev 1.6 released 02/04/03 - tsa
// removes header cd.txt header generation. This is now done by Xcd
// changes call to Xcd (no longer need "Xcd a" or "Xcd f") also exits if Xcd fails. 
// no longer creates cd.txt.old or summary.txt.old

// rev 1.7 released 02/08/03 - tsa
// changes several error messages

// rev 1.8 released 06/16/03 - bac
// Add DRC summary skeleton report generation 

// rev 1.9 released 12/13/04 - bac
// More case-shifting of filenames - everything in cam, report, test, pre-bias, top
// Change requirement for mcm file to make it optional (build-to-print support)
//   Make steps that depend on presence of mcm file conditional
//   If no mcm file, summary and cd reports are required before running
// Remove dbdoctor section because of 13-14-15 incompatibility issues
//   Instead add report to list of required files (in case of mcm file only)
// Allow plotting to be optional with prompt
// Beeps at prompts or any program exits

// rev 1.91 released 03/12/06 - bac
// Add raw folder to drag-it structure

char basename[300];
char aptname[300];
char areaname[300];
char ctlname[300];
char localname[300];
char infoname[300];
char infoname1[300];
char username[300];
char userdate[300];
char infoname1[300];
char logname[300];
char artname[300];
int release_stat;
char outline[300];
char dbcheckname[300];
char REV[300];
int endoffile;
char mcmfile[300];
char answer[30];
char *today;
char thisline[300];
char destype[300];
char vintage[300];
char parttype[300];
char timestamp[100];
char timestamp2[100];
int lineok;
char line2[300];
char line1[300];
char linev[300];
char plotanswer[20];
char fromfilestr[300];
char tofilestr[300];
char working_dir[300];
char pname[300];
char testmode[300];
char MSVER[300];
char LIBPATH[300];
char MSPATH[300];
char MSVERLINE[300];
char junkstr[300];
int xcd_result;
int xsum_result;
int nf;         // number of fields
int rval;
int artcount;
int sound;
int grepret;

FILE *tempfile;
FILE *lidprepfile;
FILE *adprepfile;
FILE *stenprepfile;
FILE *stifprepfile;
FILE *brdprepfile;
FILE *assyprepfile;

void review_prep_call( )
{

	sound = 0;

	getwd(working_dir);

	get_full_path_end( working_dir, basename);

   // basename=${PWD##*\/}

strncpy(localname,basename,120);   // $basename.mcm
strncat(localname,".mcm",10);

strncpy(aptname,"aper/",20);          // aper/$basename.prt
strncat(aptname,basename,120);
strncat(aptname,".prt",10);

// aptname="aper/$basename.prt"

strncpy(areaname,"area/analysis/",30);   // area/analysis/$basename.area
strncat(areaname,basename,120);
strncat(areaname,".area",30);

//areaname="area/analysis/$basename.area"

strncpy(ctlname,"control/",30);  // control/$basename.ctl
strncat(ctlname,basename,120);
strncat(ctlname,".ctl",30);

//ctlname="control/$basename.ctl"

strncpy(infoname,"report/Linfo",80);

strncpy(infoname1,"report/linfo",60);

strncpy(artname,"artwork/*.art",60);

strncpy(outline,"pre-bias/outline.art",40);

strncpy(logname,"report/makelog",40);

strncpy(dbcheckname,"report/dbcheck_all.good",80);

strncpy(pname,"pn.txt",30);
strncpy(REV,"1.91",30);

  get_whoami(username);

//userdate=$(date)

///######## Change this section before release  ##################################
release_stat=1;  	//change to 1 when released !!!!!!!!!!

// strncpy(testmode,"yes",30);	//allows test to skip slow steps
strncpy(testmode,"no",20);

//testmode="yes"

// General variables
if( release_stat == 0 )
{
   strncpy(LIBPATH,"/home/bac/library",80);
   strncpy(MSPATH,"/home/bac/library/flowscripts/ms2.5",100);
}
else
{
   strncpy(LIBPATH,"/swtools/remote/library",120);
   strncpy(MSPATH,"/swtools/remote/bin/makestruct",120);
}

// Acquire version of released makestruct
//MSVERLINE=$(grep 'REV=' $MSPATH)
strncpy(MSVERLINE,"REV=2.5",30);

strncpy(MSVER,"2.5",30);

// Copy outline into 274x so Xplot will run
//cp pre-bias/outline.art 274x

// Check for mcm file
strncpy(mcmfile,"yes",10);

if ( ! (file_exists(localname ) ) )
{
	if ( sound ) { printf("\a" );  }    // beep
   printf("No such file: %s \n",localname);

   strncpy(answer,"",4);

   while( (strcmp(answer,"y") != 0 ) && (strcmp(answer,"n")!= 0 ))
	                // $answer = y || $answer = n ]] 2>/dev/null
   {
      printf("Is this OK (y/n): \n");
      gets(answer);
   }
   if ( strcmp(answer,"n" )==0 )
   {
	   if (sound) { printf( "\a" );	} // beep
      printf("Assure that %s is present and re-run.\n",localname);
      exit(1);
   }
   else
   {
      printf("Checking for presence of summary.txt and cd.txt files\n");

      if( ! (file_exists("summary.txt") )  || ! (file_exists("cd.txt") ) )
      {
		  if (sound) { printf("\a"); }	// beep
		  if (! file_exists("cd.txt") )
		  {
	       printf("cd.txt missing. Create before re-running.\n");
	       exit(1);
		  }
		  if (! file_exists("summary.txt") )
		  {
	       printf("summary.txt missing. Create before re-running.\n");
	       exit(1);
		  }
      }
      strncpy(mcmfile,"no",10);
   }
}

// Check for necessary files and exit if all are not found
// for needfile in $aptname $areaname $ctlname $outline $artname $logname $pname
//do
   if( ! file_exists(aptname ) )
   {
	   if (sound) { printf("\a"); }	// beep
      printf(" %s does not exist.\n",aptname);
      exit(1);
   }
   
   if( ! file_exists(areaname ) )
   {
	   if (sound) { printf("\a"); }	// beep
      printf(" %s does not exist.\n",areaname);
      exit(1);
   }

 if( ! file_exists( ctlname) ) 
   {
	 if (sound) { printf("\a");	 } // beep
      printf(" %s does not exist.\n",ctlname);
      exit(1);
   }
 if( ! file_exists( outline ) )
   {
	 if (sound) { printf("\a"); }	// beep
      printf(" %s does not exist.\n",outline);
      exit(1);
   }
 //if( ! file_exists( artname ) )
  // {
   //   printf("\a");	// beep
    //  printf(" %s does not exist.\n",artname);
     // exit(1);
   //}

 artcount = scandir_matchext("artwork",0,".art");
    if (artcount == 0 )
	{
		if (sound) { printf("\a"); }

		printf("No .art files in the artwork directory \n");
		exit(-1);
	}
 if( ! file_exists( logname) )
   {
	 if (sound) { printf("\a");	} // beep
      printf(" %s does not exist.\n",logname);
      exit(1);
   }
 if( ! file_exists( pname) )
   {
	 if (sound) { printf("\a");	} // beep
      printf(" %s does not exist.\n",pname);
      exit(1);
   }
// Check for dbdoctor report, only if mcm file present
if ( strcmp(mcmfile,"yes")==0 )
{
   if( ! file_exists( dbcheckname ) )
   {
	   if (sound) { printf("\a");    }   // beep
      printf("%s  does not exist.\n",dbcheckname);
      exit(1);
   }
}

if ( (! file_exists(infoname) ) && (! file_exists( infoname1 ) ) )
{
	if (sound) { printf("\a"); } // beep
   printf("linfo file in report folder is missing or misnamed.\n");
   exit(1);
}


// Check vintage of makelog file
//dos2ux $logname>tmp0
cp_file(logname,"tmp0");

//linev=$(grep "version" tmp0)
   grepret = sgrep("tmp0","version",100);
   if (grepret == 0 )
   {
     strncpy(linev,grep_array[0],120);
	 split(linev,junkstr,vintage,":");
   }
   else
   {
	   strncpy(linev,"",10);
	   strncpy(vintage,"",10);
	   printf("Unable to find a version: string in the log file = %s \n",logname);
	   exit(-1);
   }


if( strcmp(vintage,MSVER ) != 0 )
{
	if (sound) { printf("\a");  }  // beep
   printf("makelog is out of date. Please update makelog and re-run review_prep.\n");
   exit(1);
}

  today=gettime_str();

//timestamp=`date +%m/%d/%y`

  if ( get_month_number(monthstr) > 9 )
   {
   sprintf(timestamp,"%d/%s/%c%c",get_month_number(monthstr),daystr,
	                       yearstr[2],yearstr[3]);
   }
   else
   {
    sprintf(timestamp," %d/%s/%c%c",get_month_number(monthstr),daystr,
	                       yearstr[2],yearstr[3]);
   }

//timestamp2=`date +%m-%d-%y`
 if ( get_month_number(monthstr) > 9 )
   {
   sprintf(timestamp2,"%d-%s-%c%c",get_month_number(monthstr),daystr,
	                       yearstr[2],yearstr[3]);
   }
   else
   {
    sprintf(timestamp2," %d-%s-%c%c",get_month_number(monthstr),daystr,
	                       yearstr[2],yearstr[3]);
   }


// Log usage
//echo $progname|awk '{printf("%-15s",$1)}'>>$USELOG
//echo "$REV     $basename     $username     $userdate" >> $USELOG

printf("Running review_prep version %s\n",REV);

//  Save old text files
// mv summary.txt summary.txt.old 2>/dev/null
// mv cd.txt cd.txt.old 2>/dev/null

cp_file( "History.txt", "History.txt.old"); // 2>/dev/null
rm_file("History.txt");
//mv history.txt history.txt.old 2>/dev/null
printf( "Previous versions of text files now have the .old extension.\n");

// ############################## Add derived file checking here!

// Parse the pn.txt file to find the components
//dos2ux pn.txt>tmp1
cp_file("pn.txt","tmp1");

tempfile = fopen("tmp1","r");
if (tmpfile==NULL)
{
	printf("Unable to open a copy of the pn.txt file = %s \n","tmp1");
	exit(-1);
}

endoffile = getline(tempfile,thisline);
nf=split_line(thisline);

while( endoffile==FALSE) // read xline
{
   //set $xline
   //numfields=$#
   if(nf != 2)
   {
	   if (sound) { printf("\a"); }  // beep
      printf("Too many fields in pn.txt file.\n");
      printf("Can't process %s",thisline);
      exit(0);
   }
   else
   {
      lineok=FALSE;
	  if (strcmp( str_array[0],"Assembly") == 0 )
	  {
		  {
			  printf("Assembly = %s \n",str_array[1]);
			  assyprepfile=fopen("textfiles/assy.prep","w");

			  if (assyprepfile==NULL)
			  {
				  printf("Unable to open the file %s for writing \n",
					  "textfiles/assy.prep");
				  exit(-1);
			  }
			  fprintf(assyprepfile,"%s  0     n/a    Review Preparation\n",
				      timestamp);

			  fclose(assyprepfile);
			  lineok=TRUE;
		  }
	  }
	  if (strcmp( str_array[0],"Board") == 0 )
	  {
		  {
			  printf("Board = %s \n",str_array[1]);
			  brdprepfile=fopen("textfiles/brd.prep","w");

			  if (brdprepfile==NULL)
			  {
				  printf("Unable to open the file %s for writing \n",
					  "textfiles/brd.prep");
				  exit(-1);
			  }
			  fprintf(brdprepfile,"%s  0     n/a    Review Preparation\n",
				      timestamp);
			  fclose(brdprepfile);
			  lineok=TRUE;
		  }
	  } 
	  if (strcmp( str_array[0],"Stencil") == 0 )
	  {
		  {
			  printf("Stencil = %s \n",str_array[1]);
              stenprepfile=fopen("textfiles/sten.prep","w");

			  if (stenprepfile==NULL)
			  {
				  printf("Unable to open the file %s for writing \n",
					  "textfiles/sten.prep");
				  exit(-1);
			  }
			  fprintf(stenprepfile,"%s  0     n/a    Review Preparation\n",
				      timestamp);
			  fclose(stenprepfile);
			  lineok=TRUE;
		  }
	  } 
	  if (strcmp( str_array[0],"Stiffener") == 0 )
	  {
		  {
			  printf("Stiffener = %s \n",str_array[1]);    
			  stifprepfile=fopen("textfiles/stif.prep","w");

			  if (stifprepfile==NULL)
			  {
				  printf("Unable to open the file %s for writing \n",
					  "textfiles/stif.prep");
				  exit(-1);
			  }
			  fprintf(stifprepfile,"%s  0     n/a    Review Preparation\n",
				      timestamp);
			  fclose(stifprepfile);
			  lineok=TRUE;
		  }
	  }
	  if (strcmp( str_array[0],"Adhesive") == 0 )
	  {
		  {
			  printf("Adhesive = %s \n",str_array[1]);    
			  adprepfile=fopen("textfiles/ad.prep","w");

			  if (adprepfile==NULL)
			  {
				  printf("Unable to open the file %s for writing \n",
					  "textfiles/ad.prep");
				  exit(-1);
			  }
			  
			  fprintf(adprepfile,"%s  0     n/a    Review Preparation\n",
				      timestamp);
			  fclose(adprepfile);

			  lineok=TRUE;
		  }
	  } 
	  if (strcmp( str_array[0],"Lid") == 0 )
	  {
		  {
			  printf("Lid = %s \n",str_array[1]);
              lidprepfile=fopen("textfiles/lid.prep","w");

			  if (lidprepfile==NULL)
			  {
				  printf("Unable to open the file %s for writing \n",
					  "textfiles/lid.prep");
				  exit(-1);
			  }
			  fprintf(lidprepfile,"%s  0     n/a    Review Preparation\n",
				      timestamp);
			  fclose(lidprepfile);
			  lineok=TRUE;
		  }
	  }
	  if ( lineok == FALSE)
	  {
		  printf( "Can't process %s  - unrecognized keyword \n", thisline);
		  exit(-1);
      }

	 
   }

   endoffile=getline(tempfile,thisline);
   nf=split_line(thisline);
}

fclose(tempfile);


rm_file("tmp1");

// Re-create base text files
//sed s/mmmmm/"$timestamp2"/ textfiles/brd.hist > brd.tmp
if ( file_exists("textfiles/brd.hist") )
{
   ssed("textfiles/brd.hist","mmmmm",timestamp2, "brd.tmp");
}
else
{
	printf("Unable to open the textfiles/brd.hist file \n");
	exit(-1);
}

cat_files("brd.tmp", "textfiles/brd.prep","history.txt"); // > history.txt
rm_file("brd.tmp");   // was -f 

// ################ Now check for corruption of board file used to generate artwork
// NOTE - removed this section because of gross incompatibilities between behavior and outputs of 13, 14, 15
//################ End of source file corruption checking

if(strcmp(mcmfile,"yes")==0 ) 
{
   // Determine design type and run X scripts
   // Get part info from makelog
   //line2=$(grep "Design Type" tmp0)
	grepret = sgrep("tmp0","Design Type",100);
	if (grepret == 0 )
	{
	  strncpy(line2,grep_array[0],120);
	  split( line2,junkstr, destype,":");
	}
	else
	{
		strncpy(line2,"",10);
		printf("Unable to find Design Type: string in logfile file = %s \n", logname);
		strncpy(destype,"",10);
		exit(-1);
	}


  // destype=${line2##*:}

   printf("Design Type is %s \n",destype);

   //***************************************
   // run Xsummary  and exit if fails
   //***************************************
   xsum_result=xsummary_call();
   //xsum_result=$?
   if( xsum_result != 0 )
   {
	   if (sound) { printf( "\a");  } // beep
      exit(0);    // no messege needed Xsummary outputs appropriate message
   }

   //***************************************
   // run Xcd and exit if fails
   //***************************************

   xcd_result=xcd_call(); // Xcd 
  // xcd_result=$?
   if( xcd_result != 0 )
   {
	   if (sound) { printf( "\a" );  } // beep
      exit(0);      //  no message needed Xcd outputs appropriate message
   }
}


if(strcmp(testmode,"yes")==0)
{
   if(strcmp(mcmfile,"yes") == 0 )
   {
      printf("***** Running new part reports.\n");
      system("rm -f report/*,1");

      // Determine part type and run Xsmask only for non-WLBI
      // Get part info from makelog
     // line1=$(grep "Part Type" tmp0)
	  grepret= sgrep("tmp0","Part Type",100);
	  if (grepret == 0 )
	  {
	    strncpy(line1,grep_array[0],120);

     // parttype=${line1##*:}
	    split(line1,junkstr,parttype,":");

        printf("Part Type is %s\n",parttype);

        if( strcmp(parttype,"wlbi")==0 )
		{
         //system("xsmask");
			xsmask_call();
         //system("xsmask_bga");
			xsmask_bga_call();
		}
     
        if( file_exists("report/xsmask_bgalog")  )  // was -f ( regular file)
		{
         system("chmod 755 report/xsmask_bgalog");
		}

        if( file_exists("report/xsmasklog")  )  // was -f 
		{
         system("chmod 755 report/xsmasklog");
		} 
	  } 
	 else
	 {
		 printf("Unable to find Part Type: string in makelog \n");
		 exit(-1);
	 }
   }
 //  printf("\a");	// beep
  // strncpy(plotanswer,"",4);
  // while( (strcmp(plotanswer,"y") != 0 ) && ( strcmp(plotanswer,"n") != 0 )) // ]] 2>/dev/null
  // {
     // printf("Do you want plots? (y/n): \n");
   //   gets(plotanswer);
  // }
  // if (strcmp(plotanswer,"y")==0 )
  // {
  //    system("rm -f plot/*");
   //   printf("***** Running xplot.\n");

   //   xplot_call_out(basename, "art", "cust", "report/Xplotlog");
    //  if( file_exists("plot/core" ) )
    //   {
   //      printf("Xplot produced a core dump... file will be removed.\n");
   //   }
   //   printf("***** Xplot complete.\n");
  // }
}



// Create DRC summary report
if( strcmp(mcmfile, "yes") == 0 ) 
{
   printf("Creating Skeleton DRC summary report...\n");
   rval=drc_skel_call(); //  > /dev/null
  // rval=$?
   if(rval == 1)
   {
      printf("ERROR! - Unable to find DRC report from APD.\n");
    }
   else if (rval == 2)
   {
      printf("ERROR! - Unable to detect end of DRC report.\n");
	}
   else if (rval == 3)
   {
      printf("ERROR! - drc_summ_skel report not created.\n");
	}
   else
   {
      printf("DRC Skeleton Summary report created: report/drc_summ_skel\n" );
      printf("Edit this report to justify each DRC error or group of errors.\n");
      printf("Save it as report/drc_summary.\n\n");
   }
}

// ##### Create drag-it folder here #####

if( dir_exists("drag-it") )
{
   
   system("rm -r -f drag-it");   // 2>/dev/null
   
}


mkdir("drag-it");

cp_file(areaname,"drag-it/area.txt");

strncpy(tofilestr,"drag-it/",20);  // drag-it/localname
strncat(tofilestr,localname,120);

cp_file( localname, tofilestr);      // drag-it 2>/dev/null

//ux2dos $ctlname > drag-it/$basename.ctl
strncpy(tofilestr,"drag-it",20);     // drag-it/$basename.ctl
strncat(tofilestr,dirsep,10);
strncat(tofilestr,basename,120);
strncat(tofilestr,".ctl",10);

cp_file(ctlname, tofilestr);
//ux2dos pn.txt > drag-it/pn.txt
cp_file("pn.txt","drag-it/pn.txt");

system("cp mech/dwg/*  drag-it");
cp_files_ext(".",".des","drag-it");  //  *.des drag-it
cp_files_ext(".",".htm", "drag-it");
cp_file( "cam/pre-bias.gwk", "drag-it/pre-bias.gwk");
system("cp -R cam/cam-exceptions drag-it/cam-exceptions");
system("cp -R report drag-it");
system("cp -R raw drag-it"); //  2>/dev/null
//ux2dos summary.txt > drag-it/summary.txt
cp_file("summary.txt","drag-it/summary.txt");
//ux2dos cd.txt > drag-it/cd.txt
cp_file("cd.txt","drag-it/cd.txt");

if( strcmp(plotanswer,"y")==0 )    
{
   system("cp -R plot drag-it");
}
system("cp -R test drag-it");

if( dir_exists("stencil" ) )
{
   cp_file( "stencil/stencil.dxf", "drag-it/stencil.dxf");
}

printf("***** Finished! \n");
printf("The text files are updated.\n");
printf("The drag-it folder is ready for design review.\n");

if( file_exists("fixed.mcm") )        //  -a fixed.mcm ]]
{
   printf("******************** WARNING **************************\n");
   printf("    Use or delete fixed.mcm - the result of dbdoctor.\n");
   printf("******************** WARNING **************************\n");
}

//rm -f plot/core 274x/outline.art

  rm_file("plot/core");
  rm_file("274x/outline.art");

//echo "Print the following files: cd.txt summary.txt pn.txt report/"$basename.rsum $areaname
//echo "Print all the mechanical drawings and the stiffener vendor drawing."
//echo "Print the layer plots."
//echo "cd to plot and run lpps to print the plots."

// Beep when finished
if (sound)
{
  printf("Done!\a\n");
}
else
{
 printf("Done!\n");
}


} //end review_prep_call


int main(int argc, char **argv)
{

	if (argc != 1)
	{
		printf("Wrong number of arguments to review_prep \n");
		printf("Usage: review_prep \n");
		exit(-1);
	}
	else
	{
		review_prep_call();
	}

}  // end main
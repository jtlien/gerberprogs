#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void rm_unused_call_out( char *infilestr, char *outfilestr)
{
FILE *unusedfile;
FILE *file1;
FILE *outfile;
int endoffile;
int number_fields;
char thisline[200];
int lineno;

   file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  outfile  = fopen(outfilestr, "w");

  if (outfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
  }

   unusedfile = fopen("unused.dat", "w");

  if (unusedfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n","unused.dat");
	  exit(-1);
  }

  endoffile=getline(file1,thisline);

  fprintf(outfile,"%s",thisline);


  endoffile=getline(file1,thisline);
  number_fields = split_line(thisline);

  lineno=2;
  while( endoffile == FALSE)
  {
   if (number_fields < 7)
   {
       fprintf(unusedfile,"%d %s",lineno,thisline);
		   //NR " " $0 > "unused.dat"
   }
   else if ( number_fields == 7)
   {
      // printf("%10.4f %10.4f %5d",$1,$2,$3)
	   fprintf(outfile,"%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),
		                   atoi(str_array[2]));

      // printf("%3s %5s %5s",$4,$5,$6)
	   fprintf(outfile,"%3s %5s %5s",str_array[3],str_array[4],str_array[5]);

      // printf("%20s %10d\n",$7,-1)
	   fprintf(outfile,"%20s %10d\n",str_array[6],-1);

   } 
   else
   { 
      printf("%s",thisline);
   }

  endoffile=getline(file1,thisline);
  number_fields = split_line(thisline);

   lineno+=1;

  }  // while end of file == false

  fclose(file1);
  fclose(unusedfile);
  fclose(outfile);
}  // rm_unused_call_out

void rm_unused_call( char *infilestr)
{
FILE *unusedfile;
FILE *file1;
int endoffile;
int number_fields;
char thisline[200];
int lineno;

   file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

   unusedfile = fopen("unused.dat", "w");

  if (unusedfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n","unused.dat");
	  exit(-1);
  }

  endoffile=getline(file1,thisline);

  printf("%s",thisline);

  lineno=2;
  endoffile=getline(file1,thisline);
  number_fields = split_line(thisline);

  while( endoffile == FALSE)
  {
   if (number_fields < 7)
   {
       fprintf(unusedfile,"%d %s",lineno,thisline);
		   //NR " " $0 > "unused.dat"
   }
   else if ( number_fields == 7)
   {
      // printf("%10.4f %10.4f %5d",$1,$2,$3)
	   printf("%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),
		                   atoi(str_array[2]));

      // printf("%3s %5s %5s",$4,$5,$6)
	   printf("%3s %5s %5s",str_array[3],str_array[4],str_array[5]);

      // printf("%20s %10d\n",$7,-1)
	   printf("%20s %10d\n",str_array[6],-1);

   } 
   else
   { 
      printf("%s",thisline);
   }

  endoffile=getline(file1,thisline);
  number_fields = split_line(thisline);

   lineno+=1;

  }  // while end of file == false

  fclose(file1);
  fclose(unusedfile);

}  // rm_unused_call

/*
int main( int argc, char **argv)
{
	if (argc != 2)
	{
     printf("In rm_unused, wrong number of arguments \n");
	 printf("Usage: rm_unused fname \n");
	 exit(-1);
	}
	else
	{
		rm_unused_call(argv[1]);
	}

} // end main

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// Rev 1
// Title: rmmo2  (remove M02 )
// written by Ted Ammann  1/2/97

// calling Syntax
//     rmmo2   infile outfile

// Program  removes all "M" codes from a gerber file

// Revision history
//  Rev1  released on 1/2/97

//************* Start of main *********


int rmmo2_call( char *file1str)
{
FILE *file1;
int endoffile;
char thisline[200];

    file1  = fopen(file1str, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",file1str);
	  exit(-1);
	}

    
  //if a line does not have an M or if line contains
  // a "%" then print the line
  // this prevents any line containing a M code from
  // being printed.

  endoffile=getline(file1,thisline);

  while( endoffile == FALSE)
  {
    if(( strstr(thisline,"M") == NULL) || (strstr(thisline,"%") != NULL) )
	{
      printf("%s",thisline);
	}
   endoffile = getline(file1,thisline);
  }
  fclose(file1);
  
  return(0);
}


int main( int argc, char **argv)
{
int tint;

    if ( argc != 2)
	{
		printf("In rmmo2, wrong number of arguments \n");
		printf("Usage:  rmmo2 infile \n");
		exit(-1);
	}
	else
	{
	 tint = rmmo2_call( argv[1]);

	 exit(tint);

	}

}  // end rmmo

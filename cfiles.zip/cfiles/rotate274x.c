#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINELEN  81

void getstring274( val , myval)
char*  val; char*  myval;
{
  val++;
  *myval= *val; 
  val++;
  myval++;
  while( isdigit(*val) ){
     *myval = *val ;
     val++;
     myval++;
  }
  *myval = '\0';
}

void getbefore( mystring, myval , mychar)
char* mystring; char* myval ; char mychar;
{
  while( *mystring != mychar ){
     *myval = *mystring ;
     mystring++;
     myval++;
  }
  *myval = '\0';
}

void getrest( instring,  outstring,  mychar)
char*  instring; char*  outstring; char mychar;
{
  while( *instring != mychar ){
     instring++;
  }
  instring++;
  while( isdigit(*instring) || *instring == '-' ){
    instring++;
  }

  while( *instring != '\0' ){
       *outstring = *instring ;
       outstring++;
       instring++;
  }
  *outstring = '\0';
}

void ProcessString274_270(char *thestring, int Xval, int Yval)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];
    
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 printf("%sX%dY%d%s",FIRST, Xval+atoi(Y), Yval-atoi(X), REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	 printf("%sX%d%s",FIRST, Xval+atoi(Y) ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 printf("%sY%d%s",FIRST,Yval- atoi(X),REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}


void ProcessString274_180(char *thestring, int Xval, int Yval)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];
    
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 printf("%sX%dY%d%s",FIRST, Xval-atoi(X), Yval-atoi(Y), REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	 printf("%sX%d%s",FIRST, Xval-atoi(X) ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 printf("%sY%d%s",FIRST,Yval- atoi(Y),REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}


void ProcessString274_90(char *thestring, int Xval, int Yval)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];
    
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 printf("%sX%dY%d%s",FIRST, Xval-atoi(Y),atoi(X)+ Yval, REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	 printf("%sX%d%s",FIRST, Xval-atoi(Y) ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	printf("%sY%d%s",FIRST,atoi(X)+  Yval,REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

void ProcessString274(char *thestring, int Xval, int Yval)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];
    
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 printf("%sX%dY%d%s",FIRST,atoi(X)+  Xval,atoi(Y)+ Yval, REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	printf("%sX%d%s",FIRST,atoi(X)+  Xval ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	printf("%sY%d%s",FIRST,atoi(Y)+  Yval,REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}


void ProcessStringOut274_270(char *thestring, int Xval, int Yval, FILE *ofile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];
    
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 fprintf(ofile,"%sX%dY%d%s",FIRST, Xval+atoi(Y), Yval-atoi(X), REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	 fprintf(ofile,"%sX%d%s",FIRST, Xval+atoi(Y) ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 fprintf(ofile,"%sY%d%s",FIRST,Yval- atoi(X),REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       fprintf(ofile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}


void ProcessStringOut274_180(char *thestring, int Xval, int Yval, FILE *ofile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];
    
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 fprintf(ofile,"%sX%dY%d%s",FIRST,Xval-atoi(X), Yval-atoi(Y), REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	 fprintf(ofile,"%sX%d%s",FIRST, Xval-atoi(X) ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 fprintf(ofile,"%sY%d%s",FIRST,Yval- atoi(Y),REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       fprintf(ofile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}


void ProcessStringOut274_90(char *thestring, int Xval, int Yval, FILE *ofile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];
    
     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 fprintf(ofile,"%sX%dY%d%s",FIRST, Xval-atoi(Y),atoi(X)+ Yval, REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	 fprintf(ofile,"%sX%d%s",FIRST, Xval-atoi(Y) ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 fprintf(ofile,"%sY%d%s",FIRST,atoi(X)+  Yval,REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       fprintf(ofile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

ProcessStringOut274(char *thestring,int  Xval, int  Yval, FILE *ofile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];
     char X[LINELEN];
     char Y[LINELEN];

     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	 fprintf(ofile,"%sX%dY%d%s",FIRST,atoi(X)+  Xval,atoi(Y)+ Yval, REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring274(placeX,X);
	 getrest(thestring,REST,'X');
	fprintf(ofile,"%sX%d%s",FIRST,atoi(X)+  Xval ,REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring274(placeY,Y);
	 getrest(thestring,REST,'Y');
	fprintf(ofile,"%sY%d%s",FIRST,atoi(Y)+  Yval,REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       fprintf(ofile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

void rotate274x_call_out( char *infilestr, char *rotatestr, char *xvalstr, char *yvalstr, 
					  char *outfilestr)
{
FILE*  INFILE;
FILE* outfile;
char *getres;

   int Xvalue;
   int Yvalue;
     int Rotvalue;

   char line[LINELEN];
   Xvalue = atoi( xvalstr);
   Yvalue = atoi( yvalstr);
     Rotvalue = atoi( rotatestr);

   outfile =  fopen( outfilestr,"w");
   if (outfile==NULL)
   {
	   printf("In rotate274x, unable to open the output file = %s \n", outfilestr);
	   exit(-1);
   }

   INFILE =  fopen( infilestr,"r");
   if (INFILE != NULL)
   {
       getres=fgets(line, LINELEN, INFILE) ; 
       while( getres != NULL)
	   { 

	 if (Rotvalue == 0 )
	   {	 
             ProcessStringOut274(line, Xvalue, Yvalue, outfile );
		  getres= fgets(line, LINELEN, INFILE) ; 
	    }

	 if (Rotvalue == 90 )
	   {	 
             ProcessStringOut274_90(line, Xvalue, Yvalue, outfile );
	     getres= fgets(line, LINELEN, INFILE) ; 
	    }

	 if (Rotvalue == 180 )
	   {	 
             ProcessStringOut274_180(line, Xvalue, Yvalue, outfile );
		  getres= fgets(line, LINELEN, INFILE) ; 
	    }

	 if (Rotvalue == 270 )
	   {	 
             ProcessStringOut274_270(line, Xvalue, Yvalue, outfile );
		  getres= fgets(line, LINELEN, INFILE) ; 
	    }
		  
       } 
   }
   else
   {
	   printf("In rotate274x, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }
   fclose(INFILE);
   fclose(outfile);

}  // rotatex_call_out

void rotate274x_call( char *infilestr, char* rotatestr, char *xvalstr, char *yvalstr)
					
{
FILE*  INFILE;
char *getres;

   int Xvalue;
   int Yvalue;
   int Rotvalue;

   char line[LINELEN];
   Xvalue = atoi( xvalstr);
   Yvalue = atoi( yvalstr);
   Rotvalue = atoi (rotatestr);

   if ((Rotvalue != 0) && (Rotvalue != 90 ) && (Rotvalue != 180) && (Rotvalue != 270))
     {
       printf("Value of rotation has to 0, 90, 180 or 270 \n");
     }

   INFILE =  fopen( infilestr,"r");
   if (INFILE != NULL)
   {
       getres= fgets(line, LINELEN, INFILE) ; 
       while( getres != NULL){

	 if (Rotvalue == 0 )
	   {	 
             ProcessString274(line, Xvalue, Yvalue );
		  getres= fgets(line, LINELEN, INFILE) ; 
	    }

	 if (Rotvalue == 90 )
	   {	 
             ProcessString274_90(line, Xvalue, Yvalue );
		  getres= fgets(line, LINELEN, INFILE) ; 
	    }

	 if (Rotvalue == 180 )
	   {	 
             ProcessString274_180(line, Xvalue, Yvalue );
		  getres= fgets(line, LINELEN, INFILE) ; 
	    }

	 if (Rotvalue == 270 )
	   {	 
             ProcessString274_270(line, Xvalue, Yvalue );
		  getres= fgets(line, LINELEN, INFILE) ; 
	    }

       } 
   }
   else
   {
	   printf("In rotate274x, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }
   fclose(INFILE);

}

int main( int argc, char **argv)
{
    if (argc != 5)
	{
	 printf("In rotate274x, wrong number of arguments \n");
	 printf("Usage: rotate274x infile rotval xval yval \n");
	 exit(-1);
	}
	else
	{
	  rotate274x_call( argv[1],argv[2], argv[3], argv[4]);
	}

}


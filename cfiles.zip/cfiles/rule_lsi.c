#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  rule_lsi  rev 1.0  7/28/95
//  written by Ted Ammann
//  This script generates a several report files from the Allegro 
// .tech output file by calling the AWK scripts below.
// Please see the .awk files for descriptions 

void space_names_call_out( char *fromfilestr, char *tofilestr);
void phy_names_call_out( char *fromfilestr, char *tofilestr);
void spacing_call_out( char *file1str, char *fromfilestr, char *tofilestr);
void physical_call_out(char *file1str, char *fromfilestr, char *tofilestr);
void nvr_chk_call( char *fromfilestr, char *tofilestr);
void physical_lsi_call_out(char *file1str, char *fromfilestr, char *tofilestr);

int grep3out( char *infilestr, char *grepstr1, char *grepstr2, char *grepstr3, char *outfilestr)
{
FILE *infile;
FILE *outfile;
int endoffile;
int grepcount;
char thisline[300];

  infile=fopen(infilestr,"r");
  if (infile == NULL)
  {
	  printf("Unable to open the input file = %s \n",infilestr);
	  exit(-1);
  }
  grepcount=0;

  outfile=fopen(outfilestr,"w");
  if (outfile == NULL)
  {
	  printf("Unable to open the output file = %s \n",outfilestr);
	  exit(-1);
  }

  endoffile=getline(infile,thisline);

  while(endoffile==FALSE)
  {

	if (( strstr(thisline,grepstr1) != NULL) || ( strstr(thisline,grepstr2) != NULL) ||
                     ( strstr(thisline,grepstr3) != NULL) )
	{
		fprintf(outfile,"%s",thisline);
		grepcount += 1;
	}


    endoffile=getline(infile,thisline);
  }

  fclose(infile);
  fclose(outfile);

  return(grepcount);

}
int grep3append( char *infilestr, char *grepstr1, char *grepstr2, char *grepstr3, char *outfilestr)
{
FILE *infile;
FILE *outfile;
int endoffile;
int grepcount;
char thisline[300];

  infile=fopen(infilestr,"r");
  if (infile == NULL)
  {
	  printf("Unable to open the input file = %s \n",infilestr);
	  exit(-1);
  }
  grepcount=0;

  outfile=fopen(outfilestr,"a");
  if (outfile == NULL)
  {
	  printf("Unable to open the output file = %s \n",outfilestr);
	  exit(-1);
  }

  endoffile=getline(infile,thisline);

  while(endoffile==FALSE)
  {

	if (( strstr(thisline,grepstr1) != NULL) || ( strstr(thisline,grepstr2) != NULL) ||
                     ( strstr(thisline,grepstr3) != NULL) )
	{
		fprintf(outfile,"%s",thisline);
		grepcount += 1;
	}


    endoffile=getline(infile,thisline);
  }

  fclose(infile);
  fclose(outfile);

  return(grepcount);

}
void rule_lsi_call( char *numstr)
{
char fromfilestr[300];
char tofilestr[300];
char file1str[300];
FILE *rsumfile;

    if (WINDOWS)
	{
		strncpy(dirsep,"\\",4);
	}
    else
	{
		strncpy(dirsep,"/",4);
	}

    printf( "Generating Rule Check Summary\n");

    strncpy(fromfilestr,"report",20);  // report/$numstr.tech
    strncat(fromfilestr,dirsep,5);
	strncat(fromfilestr,numstr,120);
	strncat(fromfilestr,".tech",10);

	strncpy(tofilestr,"report",20);    // report/space
	strncat(tofilestr,dirsep,10);
	strncat(tofilestr,"space",20);

	space_names_call_out( fromfilestr, tofilestr);

//awk -f  /usr/local/bin/space_names.awk report/$1.tech > report/space

    strncpy(file1str,"report",20);   // report/space
	strncat(file1str,dirsep,10);
	strncat(file1str,"space",20);

	strncpy(tofilestr,"report",20);  // report/$1.space
	strncat(tofilestr,dirsep,10);
	strncat(tofilestr,numstr,120);
	strncat(tofilestr,".space",10);

    spacing_call_out( file1str, fromfilestr, tofilestr);

//awk  -f /usr/local/bin/spacing.awk -v 
//            file1=report/space report/$1.tech > report/$1.space 

    strncpy(tofilestr,"report",20);  // report/tmp.phy
	strncat(tofilestr,dirsep,10);
	strncat(tofilestr,"tmp.phy",20);

    phy_names_call_out( fromfilestr, tofilestr);

// awk -f  /usr/local/bin/phy_names.awk report/$1.tech > report/tmp.phy

    strncpy(file1str,"report",20);   // report/tmp.phy
	strncat(file1str,dirsep,10);
	strncat(file1str,"tmp.phy",20);

	strncpy(tofilestr,"report",20);   // report/$1.physical
	strncat(tofilestr,dirsep,10);
	strncat(tofilestr,numstr,120);
	strncat(tofilestr,".physical",30);

	physical_lsi_call_out(file1str, fromfilestr, tofilestr);

//awk  -f /usr/local/bin/physical.awk -v file1=report/tmp.phy 
//            report/$1.tech > report/$1.physical 

    strncpy(tofilestr,"report",20);   // report/$1.nvrchk
	strncat(tofilestr,dirsep,10);
	strncat(tofilestr,numstr,120);
	strncat(tofilestr,".nvrchk",30);

     nvr_chk_call( fromfilestr, tofilestr);

//awk -f /usr/local/bin/nvr_chk.awk report/$1.tech > report/$1.nvrchk

//  The 3 lines below create a file called .rsum that only has the min space and
// min physical geometry.
//  Note that the first grep creates the .rsum file ( UNIX > )
//  and the echo and second grep append to it (UNIX >> ) 

strncpy(fromfilestr,"report",20);         // report/$numstr.physical
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,numstr,120);
strncat(fromfilestr,".physical",20);


strncpy(tofilestr,"report",20);        // report/$numstr.rsum
strncat(tofilestr,dirsep,10);
strncat(tofilestr,numstr,120);
strncat(tofilestr,".rsum",20);

grep3out(fromfilestr,"SET","Layer","MIN", tofilestr);

//grep -E "SET|Layer|MIN" report/$1.physical > report/$1.rsum
rsumfile=fopen(tofilestr,"a");

fprintf(rsumfile,"\n"); // >> report/$1.rsum

fclose(rsumfile);

// grep -E "SET|Layer|MIN" report/$1.space >> report/$1.rsum

strncpy(fromfilestr,"report",20);         // report/$numstr.space
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,numstr,120);
strncat(fromfilestr,".space",20);


grep3append(fromfilestr,"SET","Layer","MIN",tofilestr);

//rm report/space  
strncpy(fromfilestr,"report",30); // report/space
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"space",10);

rm_file( fromfilestr);
// rm report/tmp.phy  // delete the temporary files

strncpy(fromfilestr,"report",30); // report/tmp.phy
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"tmp.phy",15);

rm_file( fromfilestr);
printf("Complete\n");


}  // end rule_lsi_call

int main( int argc, char **argv)
{

	if (argc != 2)
	{
		printf("In rule_lsi, wrong number of arguments \n");
		printf("Usage rule_lsi partnum \n");
		exit(-1);
	}
    else
	{
		rule_lsi_call( argv[1]);
	}

} // end main
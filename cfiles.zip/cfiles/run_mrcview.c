#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void mrcview_call( char *infile, char *layerstr);

int main( int argc, char **argv)
{
char USAGE1[300];
char USAGE2[300];
char EXAMPLE1[300];
char EXAMPLE2[300];
char name[300];
char extstr[200];
char commandstr[300];

// progname=${0##*/}
strncpy(USAGE1,"usage: run_mrcview filename",120);
strncpy(USAGE2,"usage: run_mrcview filename layer_switch",120);
strncpy(EXAMPLE1,"\tex:  run_mrcview p1f.txt",120);
strncpy(EXAMPLE2,"\tex:  run_mrcview p1f.txt mrc_airgap",120);

//************************************************************************************* 
// mrcview  tsa
// program ia a wrapper for mrcview.awk.  Creates scripts to create mrc bowties in APD.
//to be executed on the text file output by the mrc script in GC-CAM.
//************************************************************************************* 

// Revision History
// Version 1.0 released to users on 10/08/02

if(argc == 2)
{
  if( file_exists( argv[1]) )  //    -f $1 
  {
     split(argv[1],name,extstr,"."); // =${1%%.*}

	 strncpy(commandstr,"rm -f ",20);
	 strncat(commandstr,name,120);
	 strncat(commandstr,"*.scr",10);
	 system(commandstr);

     // rm -f $name*.scr
     
     mrcview_call( argv[1],"");   //  $name.tmp
     
  }
  else
  {
     printf("ERROR: In run_mrcview, input file %s does not exist\n",argv[1]);
     exit(-1);
  }
}
if ( argc == 3 )
{
  if( file_exists( argv[1]) )     //  -f $1 
  {
      split(argv[1],name,extstr,"."); // name=${1%%.*}
      //rm -f $name*.scr
      strncpy(commandstr,"rm -f ",20);
	 strncat(commandstr,name,120);
	 strncat(commandstr,"*.scr",10);
	 system(commandstr);

      mrcview_call( argv[1], argv[2]); //  -v lyr=$2 $name.tmp
  }
  else
  {
     printf( "ERROR: In run_mrcview, input file %s does not exist\n",argv[1]);
     exit(-1);
  }
}

if (( argc != 2) && (argc != 3) )
{
   printf("ERROR: incorrect number of parameters\n");
   printf("%s\n%s\n%s\n%s\n",USAGE1,EXAMPLE1,USAGE2,EXAMPLE2);
}

} // end main

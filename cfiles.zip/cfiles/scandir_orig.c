/*Copyright (C) 2005 Matteo Lucarelli - matteo@matteolucarelli.net
* 
*This program is free software; you can redistribute it and/or
*modify it under the terms of the GNU General Public License
*as published by the Free Software Foundation; either version 2
*of the License, or (at your option) any later version.
*
*This program is distributed in the hope that it will be useful,
*but WITHOUT ANY WARRANTY; without even the implied warranty of
*MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*GNU General Public License for more details.
*
*You should have received a copy of the GNU General Public License
*along with this program; if not, write to the Free Software
*Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
******************************************************************************/

// scandir is a small function to traverse (scan recursivly) directory
// works both under windows and under POSIX systems

#include <stdlib.h>
#include <windows.h>

// that's maximum dimension of strings (path an so on)
// a better code would have them dynamic
#define MAXSTRING 1024

void scandir(	const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		char* subdir)		// starting dir, could be an arbitrary label
{
	char newsub[MAXSTRING];
	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	
	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	snprintf(szDir,MAXSTRING, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	if (hList == INVALID_HANDLE_VALUE){ 
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return;
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;
		
		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			snprintf(newdir,MAXSTRING,"%s/%s",dir,fname);
    			snprintf(newsub,MAXSTRING,"%s%s/",subdir,fname);
    			scandir(newdir,recurse,newsub);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name 
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/
		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return;
}



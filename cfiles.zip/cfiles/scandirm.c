/*Copyright (C) 2005 Matteo Lucarelli - matteo@matteolucarelli.net
* 
*This program is free software; you can redistribute it and/or
*modify it under the terms of the GNU General Public License
*as published by the Free Software Foundation; either version 2
*of the License, or (at your option) any later version.
*
*This program is distributed in the hope that it will be useful,
*but WITHOUT ANY WARRANTY; without even the implied warranty of
*MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*GNU General Public License for more details.
*
*You should have received a copy of the GNU General Public License
*along with this program; if not, write to the Free Software
*Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
******************************************************************************/

// scandir is a small function to traverse (scan recursivly) directory
// works both under windows and under POSIX systems

#include <stdlib.h>
#include <windows.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>


// that's maximum dimension of strings (path an so on)
// a better code would have them dynamic
#define MAXSTRING 1024

char scan_array[1000][120];
int reg_file_count;

void scandir(	const char* dir,	// starting directory (absolute or relative)
		int recurse)		// 1 to recurse in subdirectory
{
	
	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	
	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	sprintf(szDir, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	reg_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE){ 
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return;
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;
		
		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			sprintf(newdir,"%s/%s",dir,fname);
    		//	sprintf(newsub,"%s%s/",subdir,fname);
    			scandir(newdir,recurse);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name 
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/
			printf("fname = %s \n",fname);
			if (reg_file_count < 1000 )
			{
			 strncpy(scan_array[reg_file_count],fname,120);
		     reg_file_count+=1;
			}
		    else
			{
				printf("More than 1000 files in the directory \n");
			}

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return;
}

//
//   Scan directory for regular files that match a particular string
//
int scandir_match(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr)		// starting dir, could be an arbitrary label
{

	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	int scan_file_count;
	
	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	sprintf(szDir, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	scan_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE){ 
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return(-1);
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;
		
		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			sprintf(newdir,"%s/%s",dir,fname);

    			scandir_match(newdir,recurse,matchstr);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name 
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/
			if (strstr(fname,matchstr) != NULL)
			{
			// printf("fname = %s \n",fname);
			  if (scan_file_count < 1000 )
			  {
				 strncpy(scan_array[scan_file_count],fname,120);
				 scan_file_count += 1;
			  }
			  else
			  {
				  printf("Number of files in the directory exceeds 1000 \n");
			  }

			}

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return(scan_file_count);
}

//
//   Scan directory for regular files that match a particular extension
//
int scandir_matchext(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr)		// starting dir, could be an arbitrary label
{

	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	int ll;
	int kk;
	char fname_ext[MAXSTRING];
	int scan_file_count;

	
	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	sprintf(szDir, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	scan_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE){ 
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return(-1);
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;
		
		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			sprintf(newdir,"%s/%s",dir,fname);

    			scandir_matchext(newdir,recurse,matchstr);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name 
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/

			 // get the ext ( all chars after first dot )

			kk=0;
			ll=0;
			fname_ext[0]=0;
			while((fname[kk] != '.') && (kk < strlen(fname)) )
			{
				kk += 1;
			}
			if ( fname[kk] == '.')
			{
				fname_ext[ll]=fname[kk];
				kk += 1;
				ll += 1;
			}
			while( kk < strlen(fname))
			{
				fname_ext[ll] = fname[kk];
				kk += 1;
				ll += 1;
			}
			fname_ext[ll] = 0;

			// printf("fname_ext = %s \n",fname_ext);

			if (strcmp(fname_ext,matchstr) == 0 )
			{
			// printf("fname = %s \n",fname);
			  if (scan_file_count < 1000 )
			  {
				 strncpy(scan_array[scan_file_count],fname,120);
				 scan_file_count += 1;
			  }
			  else
			  {
				  printf("Number of files in the directory exceeds 1000 \n");
			  }

			}

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return(scan_file_count);
}

//
//

int main ( int argc, char **argv)
{
int tcount;

	tcount = scandir_matchext("c:\\clib",0,".c");


}  // end main
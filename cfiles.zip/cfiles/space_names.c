#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  space_names.awk  rev 1.0  7/31/95
//  written by Ted Ammann
//
//  This program is meant to work on the Allegro .tech report file
//  The output of this program are the rule names associated with
//  the spacing check data in the .tech file. The reader is encouraged to
//  to look at the .tech file.
//
//  The output of this file is meant to be redirected ( UNIX ">") to 
//  another file for further processing.
//  That further processing is done by the spacing.awk program.

// The begin section of this program simply moves down the input file (.tech)
// until it finds the line containing spacingSetName. This takes us past the 
// ALWAYS_CHECK/NEVER_CHECK portion of the .tech file and gets us to "data" 
// portion of the file.


void space_names_call( char *infilestr)
{
int endoffile;
FILE *file1;
char thisline[300];
int nf;
char tmpstr[300];

	 file1 = fopen( infilestr,"r");
	 if (file1 == NULL)
	 {
		 printf("In get space_names, unable to open the input file = %s \n", infilestr);
		 exit(-1);
	 }

     endoffile= getline(file1,thisline);

     while(( strstr( thisline, "spacingSetName") == NULL)  && (endoffile==FALSE) )
                                     //strip off all lines down to
	  {
         endoffile=getline( file1,thisline );   // spacingSetName
		 nf=split_line(thisline);
      }



//********* Start Of Main ***************
//  The Main section of this program simply outputs the first 20 chars. of the
//  spacing rule name on the current line. 
//****************************************
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  while(endoffile == FALSE)
  {

   if( strstr(thisline,"spacingLayerGroup")!= NULL)   // found spacingLayerGroup
    {              // The names we want start after the
    
                                     // containing spacingLayerGroup
     endoffile=getline( file1,thisline);
	 nf=split_line(thisline);

     while (strcmp(str_array[0],")") != 0 )  // The Right Paren. ")" is the delimiter
	 {             
		 awk_substr(str_array[0],2,21,tmpstr); // for this section.
         printf("%s\n",tmpstr);  // output the name 
         endoffile=getline(file1,thisline);          // get the next line.
		 nf=split_line(thisline);
	 }

    // exit the program -- we only need the names from the first 
    // spacing group (i.e. the names in any following spacing groups
    //      are assumed to be the same as the first group).
  

     exit(0);
   }
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  }  // while not endoffile

 fclose(file1);
}  // end space_names_call


void space_names_call_out( char *infilestr, char *outfilestr)
{
int endoffile;
FILE *file1;
FILE *outfile;
char thisline[300];
int nf;
char tmpstr[300];

	 file1 = fopen( infilestr,"r");
	 if (file1 == NULL)
	 {
		 printf("In get space_names, unable to open the input file = %s \n", infilestr);
		 exit(-1);
	 }

     outfile = fopen( outfilestr,"w");
	 if (outfile == NULL)
	 {
		 printf("In get space_names, unable to open the output file = %s \n",outfilestr);
		 exit(-1);
	 }

     endoffile= getline(file1,thisline);

     while(( strstr( thisline, "spacingSetName") == NULL)  && (endoffile==FALSE) )
                                     //strip off all lines down to
	  {
         endoffile=getline( file1,thisline );   // spacingSetName
		 nf=split_line(thisline);
      }



//********* Start Of Main ***************
//  The Main section of this program simply outputs the first 20 chars. of the
//  spacing rule name on the current line. 
//****************************************
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  while(endoffile == FALSE)
  {

   if( strstr(thisline,"spacingLayerGroup")!= NULL)   // found spacingLayerGroup
    {              // The names we want start after the
    
                                     // containing spacingLayerGroup
     endoffile=getline( file1,thisline);
	 nf=split_line(thisline);

     while (strcmp(str_array[0],")") != 0 )  // The Right Paren. ")" is the delimiter
	 {             
		 awk_substr(str_array[0],2,21,tmpstr); // for this section.
         fprintf(outfile,"%s\n",tmpstr);  // output the name 
         endoffile=getline(file1,thisline);          // get the next line.
		 nf=split_line(thisline);
	 }

    // exit the program -- we only need the names from the first 
    // spacing group (i.e. the names in any following spacing groups
    //      are assumed to be the same as the first group).
  

     exit(0);
   }
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  }  // while not endoffile

 fclose(file1);
 fclose(outfile);

}  // end space_names_call_out

/*
int main( int argc, char **argv)
{

	if (argc != 2)
	{
		printf("In space_names, wrong number of arguments \n");
		printf("Usage: space_names infile \n");
	}
	else
	{
		space_names_call( argv[1]);
	}

}  // end main
	  
*/


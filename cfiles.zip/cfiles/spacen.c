//  space_names.awk  rev 1.0  7/31/95
//  written by Ted Ammann
//
//  This program is meant to work on the Allegro .tech report file
//  The output of this program are the rule names associated with
//  the spacing check data in the .tech file. The reader is encouraged to
//  to look at the .tech file.
//
//  The output of this file is meant to be redirected ( UNIX ">") to 
//  another file for further processing.
//  That further processing is done by the spacing.awk program.

// The begin section of this program simply moves down the input file (.tech)
// until it finds the line containing spacingSetName. This takes us past the 
// ALWAYS_CHECK/NEVER_CHECK portion of the .tech file and gets us to "data" 
// portion of the file.

FILE *file1;

void main( int argc, char **argv)
{

       getline( thisline,file1);

      while(strstr( thisline, "spacingSetName") == NULL))
                                     //strip off all lines down to
	  {
         getline( thisline, file1);   // spacingSetName
      }



//********* Start Of Main ***************
//  The Main section of this program simply outputs the first 20 chars. of the
//  spacing rule name on the current line. 
//****************************************
{
   if( strstr(splits[0],"spacingLayerGroup")!= NULL)
     {              // The names we want start after the
    
                                     // containing spacingLayerGroup
     getline( thisline, file1);
     }

    while ($1 != ")" )              // The Right Paren. ")" is the delimiter
     {                                // for this section.
         printf("%s\n", substr($1,2,20));  // output the name 
         getline(thisline,file1);    // get the next line.
    }

    // exit the program -- we only need the names from the first 
    // spacing group (i.e. the names in any following spacing groups
    //      are assumed to be the same as the first group).
  

    exit(0);

} // end main


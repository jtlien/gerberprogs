#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//  spacing.awk  rev 1.0  7/28/95
//  written by Ted Ammann
//
//  This program is meant to work on the temporary file called space
//  that was create by the space_names.awk script.

//  To view this temp. file modify the rule_check script
//  by commenting out the line that deletes the temp files.
//  ( change it back when done)  ;^)

//  The results from spacing.awk are meant to be redirected (UNIX ">") to 
//  the .space file which is the finished output report file for design.

//  The output of this program is a multi-column file  that contains a summary
//  of the spacing checks that were done on the design that this script was run
//  on.

//  Sample Output
//  (allegroTechFile "/usr/home/dah/projects/95020/report/bb.tech"

//        SET NAME =  "DEFAULT"

//           Layer Name      "L01      "L02      "L03  
//         sameNetCheck     FALSE     FALSE     FALSE 
// differentialPairPrim         0         0         0
// differentialPairSeco         0         0         0
//             spacing                             
// blindBuriedViaToBlin     0.035     0.075     0.075 


// file1 below is a command line parameter specifing the name of the file
// that contains the spacing rule name ( for us the temporary file space )

// The BEGIN section of the this program creates a 2d array (data) whose
// subsripts  are [row,0] and the elements contain the rule name.


//***************** function outarray ***********************
// The function outarray outputs the passed in array out using the row,col
// parameters.  This function also finds the min space that is checked for
// on a layer by layer basis. Those min spaces are output after the array.
//*************************************************************
 
char data[120][120][30];


void outarray_out_sp(FILE *outfile, int row, int col)
{ 
int i,j;
int min[1000];

  // Output the Array 

  for( i = 0 ; i < row ; i++ ) 
  {
         fprintf(outfile,"%20s",data[i][0]);
     for( j = 1 ; j < col ; j++) 
	 {
         fprintf(outfile,"%10s", data[i][j]);
     }
     fprintf(outfile,"\n");
  }

  // Initailize the array min with 999 (a "LARGE" default value)
  // "LARGE" meaning greater than any min space could ever be. 

  for( i = 1; i < col ; i++ )
  {  
      min[i] = 999;
  }

  // find the min spacing for each layer (store in the array data by columns)
  // The if statement prevents looking at the line with "spacing" header and
  // prevents the Allegro default 0 from being included in the search for the
  // min value.

  for( i = 1 ; i < row ; i++)
  {
     for( j = 1 ; j < col ; j++) 
	 {
        if(( strcmp(data[i][0],"spacing") != 0 ) && 
			(atoi(data[i][j]) != 0 ) && (atoi(data[i][j]) < min[j] ) )
            min[j] = atoi(data[i][j]);
     }
  }

  // output the min spacings (all one one line)

  fprintf(outfile,"\n%20s","MIN SPACING");

  for ( i = 1 ; i < col ; i++)
      fprintf(outfile,"%10s", min[i]);

  fprintf(outfile,"\n\n");

} // end outarray_out

void outarray_sp( int row, int col)
{ 
int i,j;
int min[1000];

  // Output the Array 

  for( i = 0 ; i < row ; i++ ) 
  {
         printf("%20s",data[i][0]);
     for( j = 1 ; j < col ; j++) 
	 {
         printf("%10s", data[i][j]);
     }
     printf("\n");
  }

  // Initailize the array min with 999 (a "LARGE" default value)
  // "LARGE" meaning greater than any min space could ever be. 

  for( i = 1; i < col ; i++ )
  {  
      min[i] = 999;
  }

  // find the min spacing for each layer (store in the array data by columns)
  // The if statement prevents looking at the line with "spacing" header and
  // prevents the Allegro default 0 from being included in the search for the
  // min value.

  for( i = 1 ; i < row ; i++)
  {
     for( j = 1 ; j < col ; j++) 
	 {
        if(( strcmp(data[i][0],"spacing") != 0 ) && 
			(atoi(data[i][j]) != 0 ) && (atoi(data[i][j]) < min[j] ) )
            min[j] = atoi(data[i][j]);
     }
  }

  // output the min spacings (all one one line)

  printf("\n%20s","MIN SPACING");

  for ( i = 1 ; i < col ; i++)
      printf("%10s", min[i]);

  printf("\n\n");

} // end outarray

void spacing_call_out( char *infile1str, char *infile2str, 
					   char *outfilestr)
{
FILE *file1, *file2;
FILE *outfile;
char thisline[200];
int number_fields;
int row;
int col;
int endoffile;
int indexval;  
   
      file1  = fopen(infile1str, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
	 }

     outfile  = fopen(outfilestr, "w");

     if (outfile == NULL)
	 {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
	 }
      // get the rule names from file1 and put into array data.

      strncpy(data[0][0],"Layer Name",20);

      row = 1;
      endoffile = getline( file1, thisline);

      while (endoffile == FALSE)
	  {
          strncpy(data[row][0],str_array[0],20);
          row++;
		  endoffile = getline( file1, thisline);

      }

	  fclose(file1);

      file2 = fopen(infile2str, "r");

     if (file2 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile2str);
	  exit(-1);
	 }

      // get the first line from the .tech file and output it. The first
      // line contains the input file name and path.

      endoffile = getline(file2,thisline);
      fprintf(outfile,"%s",thisline);
      fprintf(outfile,"\n");


  endoffile = getline(file2, thisline);
  number_fields = split_line( thisline);

  while( endoffile == FALSE)
  {                                 //START OF MAIN LOOP

   if( strstr(thisline,"spacingSetName") != NULL)
   {
     printf("\tSET NAME =  %s\n",str_array[1]);
     col = 1;

     while( strcmp( str_array[0],")") != 0 )
	 {                   //process the Spacing SET Group
                
 
       if( strstr(thisline,"spacingLayerGroup" ) != NULL)
	   {                // Process the layer group.
        row = 0;                          // start at row 0
        while( strcmp(str_array[0],")" ) != 0 )

		{  // read in the data and place in array.
		  
		  indexval = strlen(str_array[1])-1; // kill last char?
		  str_array[1][indexval]=0;

          strncpy(data[row][col],str_array[1],100);

          row++;

          endoffile = getline(file2, thisline);
		  number_fields = split_line( thisline);

        }
       col++;
       }             // end of layer group processing

     if( strcmp(str_array[0],")" ) == 0 )
	  {                     //KLUDGE  covers extra ) in "SPACING"
         endoffile = getline(file2, thisline);
		 number_fields = split_line( thisline);
	  }

      endoffile = getline(file2, thisline);
      number_fields = split_line( thisline);

     }  // end of Spacing Set Group

    endoffile = getline(file2, thisline);
	number_fields = split_line( thisline);

   } // while loop

   fclose(file2);

   outarray_out_sp(outfile,row,col);
   fclose(outfile);
  }

}    // end of spacing_call_out

void spacing_call( char *infile1str, char *infile2str)
{
FILE *file1, *file2;
char thisline[200];
int number_fields;
int row;
int col;
int endoffile;
int indexval;  
   
      file1  = fopen(infile1str, "r");

     if (file1 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
	 }

      // get the rule names from file1 and put into array data.

      strncpy(data[0][0],"Layer Name",20);

      row = 1;
      endoffile = getline( file1, thisline);

      while (endoffile == FALSE)
	  {
          strncpy(data[row][0],str_array[0],20);
          row++;
		  endoffile = getline( file1, thisline);

      }

	  fclose(file1);

      file2 = fopen(infile2str, "r");

     if (file2 == NULL)
	 {
	  printf("Error: Unable to open input file = %s \n",infile2str);
	  exit(-1);
	 }

      // get the first line from the .tech file and output it. The first
      // line contains the input file name and path.

      endoffile = getline(file2,thisline);
      printf("%s",thisline);
      printf("\n");


  endoffile = getline(file2, thisline);
  number_fields = split_line( thisline);

  while( endoffile == FALSE)
  {                                 //START OF MAIN LOOP

   if( strstr(thisline,"spacingSetName") != NULL)
   {
     printf("\tSET NAME =  %s\n",str_array[1]);
     col = 1;

     while( strcmp( str_array[0],")") != 0 )
	 {                   //process the Spacing SET Group
                
 
       if( strstr(thisline,"spacingLayerGroup" ) != NULL)
	   {                // Process the layer group.
        row = 0;                          // start at row 0
        while( strcmp(str_array[0],")" ) != 0 )

		{  // read in the data and place in array.
		  
		  indexval = strlen(str_array[1])-1; // kill last char?
		  str_array[1][indexval]=0;

          strncpy(data[row][col],str_array[1],100);

          row++;

          endoffile = getline(file2, thisline);
		  number_fields = split_line( thisline);

        }
       col++;
       }             // end of layer group processing

     if( strcmp(str_array[0],")" ) == 0 )
	  {                     //KLUDGE  covers extra ) in "SPACING"
         endoffile = getline(file2, thisline);
		 number_fields = split_line( thisline);
	  }

      endoffile = getline(file2, thisline);
      number_fields = split_line( thisline);

     }  // end of Spacing Set Group

    endoffile = getline(file2, thisline);
	number_fields = split_line( thisline);

   } // while loop

   fclose(file2);

   outarray_sp(row,col);
  }
}    // end of spacing_call

/*
int main( int argc, char **argv)
{

	if (argc != 3)
	{

		printf("In spacing, wrong number of arguments \n");
		printf("Usage: spacing infile1 infile2 \n");
		exit(-1);
	}
   else
   { 
	   spacing_call( argv[1],argv[2]);
   }

}  // end main

  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


 
#define MAX_PBM_ROWS  3000
#define MAX_PBM_COLS  8000

char pbm_row_data[MAX_PBM_ROWS][MAX_PBM_COLS];   // 24megabytes



void get_pbm_width( FILE *infile, char *widthstr)
{
char inchar;
int l;


	inchar=fgetc(infile);

	 widthstr[0] = '\0';

	//printf("First char = %d \n",inchar);

	if (inchar == 'P')
	{
		inchar = fgetc(infile);
		if (inchar == '4')
		{
			inchar=fgetc(infile);  // skip paste cr

			inchar=fgetc(infile);
			while( inchar == ' ')
			{
				inchar = fgetc(infile);
			}

			 l = 0;
             while((isdigit(inchar) ) && ( l < 40))
			 {
                widthstr[l] = inchar;
				inchar=fgetc(infile);
				l+=1;
			 }
			 widthstr[l] = '\0';

		}
	}


}

void get_pbm_height( FILE *infile, char *heightstr)
{
char inchar;
int l;
int debug;

     debug = 0;

     if (debug)
	 {
      printf("In get_pbm_height \n");
	 }

	inchar = fgetc(infile);

	while( inchar == ' ')
	{
	 inchar = fgetc(infile);
	 printf("Got a space \n");
	}
	

	l = 0;
    while((isdigit(inchar) ) && ( l < 40))
	{
       heightstr[l] = inchar;
	   if (debug)
	   {
	     printf("Heightstr of %d = %c \n", l, inchar);
	   }

	   inchar=fgetc(infile);
	   l+=1;
	}
	heightstr[l] = '\0';

	inchar = fgetc(infile); // skip paste \n

}


void put_header( FILE *ofile, int width, int height )
{
char ostr[300];
int k;

  fputc('P',ofile);
  fputc('4',ofile);
  fputc(0x0a,ofile);

  _snprintf(ostr,300,"%d %d%c",width,height, 0x0a);

  for(k = 0; k < (int) strlen( ostr); k += 1)
    {
      fputc(ostr[k],ofile  );
    }

 

}  // end put_header


void get_rows( FILE *ifile, int new_pbm_row_size, int pbm_width)
{
  int k;
  int l;

  printf("Getting %d rows of data of %d bytes\n", new_pbm_row_size, pbm_width );

  for(k=0; k < new_pbm_row_size; k += 1)
    {
      for(l=0; l < pbm_width ; l += 1)
	  {
          pbm_row_data[k][l]=fgetc(ifile);
      }
    }

}

void put_out_data(FILE *ofile, char *dataptr, int length)
{
  int k;

  for(k=0; k < length; k += 1)
    {
      fputc(*dataptr,ofile);
      dataptr++;
    }

}



void split_pbm( char *infilename, FILE *infile,int xdiv, int ydiv )
{
  int pbm_width;
  int pbm_height;
  int pbm_cols;

  double pbmw;
  double pbmh;
  double npbm_rowsize;
  double npbm_colsize;
  int new_pbm_row_size;
  int new_pbm_col_size;

  char pbm_width_str[300];
  char pbm_height_str[300];

  FILE *ofile;
  int i,j,k;
  char *cptr;
  int debug;
  char outfilename[300];


  debug = 0;

  get_pbm_width(infile ,pbm_width_str);

  if (debug)
  {
    printf("Pbm width str = %s \n", pbm_width_str);
  }

  pbm_width=atoi(pbm_width_str);


  pbm_cols = pbm_width/8;

  get_pbm_height(infile,pbm_height_str);

  if (debug)
  {
    printf("Pbm height str = %s \n", pbm_height_str);
  }

  pbm_height=atoi(pbm_height_str);


  pbmw = (double) pbm_width;
  pbmh = (double) pbm_height;

  npbm_rowsize = pbmh / ydiv;
  npbm_colsize = pbmw / xdiv;

  new_pbm_row_size = (int) npbm_rowsize;
  

  new_pbm_col_size = pbm_width/xdiv;

  

      for( j=0; j < ydiv; j += 1 )
	{
 
		  // printf("About to get rows of data \n");

		  printf("Getting from infile = %d rows of %d columns \n", new_pbm_row_size,
			            pbm_cols);

          get_rows (infile,  new_pbm_row_size, pbm_cols);

          for(i=0; i < xdiv ; i += 1)
		  {

             _snprintf(outfilename,300,"%s_%d%d", infilename,i,j);
             ofile=fopen(outfilename,"w");
             if(ofile==NULL)
               {
		         printf("Unable to open the output file = %s \n",outfilename);
                 exit(-1);
               }
             put_header(ofile,new_pbm_col_size,new_pbm_row_size);

             for(k=0; k < new_pbm_row_size; k += 1)
               {
				cptr = pbm_row_data[k];
				if (debug)
				{
				  printf("offset = %d \n",i * (new_pbm_col_size/8 ) );
				}

				if ((new_pbm_col_size && 7 ) > 0 )
				{
				  cptr = cptr +  ( i * ((new_pbm_col_size/8)+1)); 
				  put_out_data(ofile,cptr, ((new_pbm_col_size/8)+1));
				}
				else
				{
                  cptr = cptr +  ( i * (new_pbm_col_size/8)); 
				  put_out_data(ofile,cptr, (new_pbm_col_size/8));
				}

               }
             fclose(ofile);
		  }
        }

	  fclose(infile);
   
}

int main( int argc, char **argv)
{
FILE *infile;

	if (argc != 4 )
	{
      printf("In split_pbm, wrong number of arguments \n");
	  printf("Usage:  split_bpm infile xcols yrows \n");
	  exit(-1);

	}
	else
	{


	 infile=fopen(argv[1],"rb");

	 if (infile != NULL)
	 {
      split_pbm( argv[1], infile,  atoi(argv[2]), atoi(argv[3]) );
	 }
	 else
	 {
		 printf("In split_pbm, unable to open the input file = %s \n", argv[1]);
		 exit(-1);
	 }


	}

}  // end main




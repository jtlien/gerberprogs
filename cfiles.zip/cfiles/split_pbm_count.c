#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


 
#define MAX_PBM_ROWS  3000
#define MAX_PBM_COLS  8000

char pbm_row_data[MAX_PBM_ROWS][MAX_PBM_COLS];   // 24megabytes

int bit_total_array[MAX_PBM_ROWS];

int sub_pbm_bitsset;     // total bits set in the sub_pbm

void get_pbm_width( FILE *infile, char *widthstr)
{
char inchar;
int l;


	inchar=fgetc(infile);

	 widthstr[0] = '\0';

	//printf("First char = %d \n",inchar);

	if (inchar == 'P')
	{
		inchar = fgetc(infile);
		if (inchar == '4')
		{
			inchar=fgetc(infile);  // skip paste cr

			inchar=fgetc(infile);
			while( inchar == ' ')
			{
				inchar = fgetc(infile);
			}

			 l = 0;
             while((isdigit(inchar) ) && ( l < 40))
			 {
                widthstr[l] = inchar;
				inchar=fgetc(infile);
				l+=1;
			 }
			 widthstr[l] = '\0';

		}
	}


}

void get_pbm_height( FILE *infile, char *heightstr)
{
char inchar;
int l;
int debug;

    debug = 0;

   if (debug) { printf("In get_pbm_height \n"); }


	inchar = fgetc(infile);

	while( inchar == ' ')
	{
	 inchar = fgetc(infile);
	 printf("Got a space \n");
	}
	

	l = 0;
    while((isdigit(inchar) ) && ( l < 40))
	{
       heightstr[l] = inchar;
	   if (debug) { printf("Heightstr of %d = %c \n", l, inchar); }

	   inchar=fgetc(infile);
	   l+=1;
	}
	heightstr[l] = '\0';

	inchar = fgetc(infile); // skip paste \n

}


void put_header( FILE *ofile, int width, int height )
{
char ostr[300];
int k;

  fputc('P',ofile);
  fputc('4',ofile);
  fputc(0x0a,ofile);

  _snprintf(ostr,300,"%d %d%c",width,height, 0x0a);

  for(k = 0; k < (int) strlen( ostr); k += 1)
    {
      fputc(ostr[k],ofile  );
    }

 

}  // end put_header


void get_rows( FILE *ifile, int new_pbm_row_size, int pbm_width)
{
  int k;
  int l;

  for(k=0; k < new_pbm_row_size; k += 1)
    {
      for(l=0; l < pbm_width ; l += 1)
	  {
          pbm_row_data[k][l]=fgetc(ifile);
      }
    }

}

int count_bits( char inchar)
{
int bsets;
int mask;
int j;
   
   mask = 1;
   bsets = 0;
   for(j=0; j < 8; j += 1)
   {
	   if (inchar && mask )
	   {
		   bsets += 1;
	   }
	   mask = mask << 1;
   }

 return(bsets);
}


void count_out_data( char *indata, int length, int index)
{
int j;
int bcs;
int settotal;

  settotal = 0;
 
  for(j=0; j < length; j += 1)
  {
	  bcs = count_bits(*indata);
	  settotal += bcs;
	  indata++;
  }

  bit_total_array[index] = settotal;
  sub_pbm_bitsset += settotal;

}

void split_pbm_count( char *infilename, FILE *infile,int xdiv, int ydiv )
{
  int pbm_width;
  int pbm_height;
  int pbm_cols;

  double pbmw;
  double pbmh;
  double npbm_rowsize;
  double npbm_colsize;
  int new_pbm_row_size;
  int new_pbm_col_size;

  char pbm_width_str[300];
  char pbm_height_str[300];

  int total_bits;

  FILE *ofile;
  int i,j,k;
  char *cptr;
  int debug;
  char outfilename[300];


  debug = 0;

  get_pbm_width(infile ,pbm_width_str);

  if (debug)
  {
    printf("Pbm width str = %s \n", pbm_width_str);
  }

  pbm_width=atoi(pbm_width_str);


  pbm_cols = pbm_width/8;

  get_pbm_height(infile,pbm_height_str);

  if (debug)
  {
    printf("Pbm height str = %s \n", pbm_height_str);
  }

  pbm_height=atoi(pbm_height_str);


  pbmw = (double) pbm_width;
  pbmh = (double) pbm_height;

  npbm_rowsize = pbmh / ydiv;
  npbm_colsize = pbmw / xdiv;

  new_pbm_row_size = (int) npbm_rowsize;
  new_pbm_col_size = pbm_width/xdiv;

      for( j=0; j < ydiv; j += 1 )
	{
 
		  // printf("About to get rows of data \n");

		  if ( debug )
		  {
		    printf("Getting from infile = %d rows of %d columns \n", new_pbm_row_size,
			            pbm_cols);
		  }

          get_rows (infile,  new_pbm_row_size, pbm_cols);

          for(i=0; i < xdiv ; i += 1)
		  {

             _snprintf(outfilename,300,"%s_cnt%d%d", infilename,i,j);
             ofile=fopen(outfilename,"w");
             if(ofile==NULL)
               {
		         printf("Unable to open the output file = %s \n",outfilename);
                 exit(-1);
               }
             put_header(ofile,new_pbm_col_size,new_pbm_row_size);

			 sub_pbm_bitsset = 0;

             for(k=0; k < new_pbm_row_size; k += 1)
               {
				cptr = pbm_row_data[k];
				cptr = cptr +  ( i * (new_pbm_col_size/8));

		        count_out_data(cptr, (new_pbm_col_size/8),k );
               }
			 fprintf(ofile,"Total bits = %d   total set = %d \n", 
				 (new_pbm_col_size * new_pbm_row_size * 8 ), sub_pbm_bitsset);
			 total_bits = new_pbm_col_size * new_pbm_row_size * 8;

			 fprintf(ofile,"Percent area for %d %d = %f \n", i,j, (100.0 * (double) sub_pbm_bitsset / (double) total_bits ) );

             fclose(ofile);
		  }
        }

	  fclose(infile);
   
}

int main( int argc, char **argv)
{
FILE *infile;

	if (argc != 4 )
	{
      printf("In split_pbm_count, wrong number of arguments \n");
	  printf("Usage:  split_bpm_count infile xcols yrows \n");
	  exit(-1);

	}
	else
	{


	 infile=fopen(argv[1],"rb");

	 if (infile != NULL)
	 {
      split_pbm_count( argv[1], infile,  atoi(argv[2]), atoi(argv[3]) );
	 }
	 else
	 {
		 printf("In split_pbm_count, unable to open the input file = %s \n", argv[1]);
		 exit(-1);
	 }


	}

}  // end main




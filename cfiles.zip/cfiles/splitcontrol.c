#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


// Rev 1
// Title: splitcontrol 
// written by Ted Ammann  1/2/97

// calling Syntax
//     splitcontrol infile.ctl 

// Program splits the input "Control file" in to two new
// files. It creates 2 files "locals" and "layers"

// Note: if any input line does not have 2 or 8 fields
//       program returns an error and exits


// set CODE to default value of 0 




int splitcontrol_call( char *infilestr)
 {
FILE *file1;
int code;
int nf;
int endoffile;
char thisline[200];
FILE *localfile,*layerfile;

   code = 0;

   file1  = fopen(infilestr, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
	}

   layerfile = fopen("layers", "w");

    if (layerfile == NULL)
	{
	  printf("Error: Unable to open output file = %s \n","layers");
	  exit(-1);
	}

   localfile = fopen("locals", "w");

    if (localfile == NULL)
	{
	  printf("Error: Unable to open output file = %s \n","locals");
	  exit(-1);
	}

//*********** Start Of MAIN ***********************************
// any line that has exactly 2 fields is written to "locals"
// any line that has exactly 8 fields is written to "layers"
// any other line will cause an error an program will exit
// program returns 0 if no it exits normally
//*************************************************************

   endoffile=getlinet(file1,thisline);
   nf=split_line(thisline);

   while(endoffile == FALSE)
   {
    if((nf !=2) &&  (nf != 8 ))
     {
      code = 99;
      return(code);
     }
    if( nf == 2) {
      fprintf(localfile,"%s",thisline); //  $0 >  "locals"
      } 
    if(( nf > 2) && (strstr(str_array[0],"NAME") == NULL))  // 
      {                                    // keeps header line out of layers
      fprintf(layerfile,"%s",thisline); //  $0 >  "layers"
      } 
    endoffile=getlinet(file1,thisline);
    nf=split_line(thisline);
}

fclose(file1);
fclose(layerfile);
fclose(localfile);

// exit returning CODE as return vlaue

return( code);

} // end splitcontrol_call

/*
int main( int argc, char **argv)
{
int retval;

  if (argc != 2)
  {
   printf("In splitcontrol, wrong number of arguments \n");
   printf("Usage: splitcontrol controlfile \n");
   exit(-1);
   }
  else
   {
    retval=splitcontrol_call(argv[1]);
    exit(retval);
   }
}    
  
 */




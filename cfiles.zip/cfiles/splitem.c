#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINELEN  81

char X[LINELEN];
char Y[LINELEN];
int kk;

void getstring( val , myval)
char*  val; char*  myval;
{
  val++;
  *myval= *val; 
  val++;
  myval++;
  while( isdigit(*val) ){
     *myval = *val ;
     val++;
     myval++;
  }
  *myval = '\0';
}

void getbefore( mystring, myval , mychar)
char* mystring; char* myval ; char mychar;
{
  while( *mystring != mychar ){
     *myval = *mystring ;
     mystring++;
     myval++;
  }
  *myval = '\0';
}

void getrest( instring,  outstring,  mychar)
char*  instring; char*  outstring; char mychar;
{
  while( *instring != mychar ){
     instring++;
  }
  instring++;
  while( isdigit(*instring) || *instring == '-' ){
    instring++;
  }

  while( *instring != '\0' ){
       *outstring = *instring ;
       outstring++;
       instring++;
  }
  *outstring = '\0';
}

ProcessString(thestring)
char  thestring[];
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[LINELEN];
     char REST[LINELEN];


     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring(placeX,X);
	 getstring(placeY,Y);
	 getrest(thestring,REST,'Y');
	 printf("%sX%dY%d%s",FIRST,atoi(X),atoi(Y), REST );
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'X');
         getstring(placeX,X);
	 getrest(thestring,REST,'X');
	 printf("%sX%dY%d%s",FIRST,atoi(X),atoi(Y), REST );
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbefore(thestring,FIRST,'Y');
	 getstring(placeY,Y);
	 getrest(thestring,REST,'Y');
	 printf("%sX%dY%d%s",FIRST,atoi(X),atoi(Y), REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       printf("%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}


void splitem_call( char *infilestr) 

{
FILE*  INFILE;

   char line[LINELEN];

   for(kk=0; kk < 81; kk += 1)
	 {
		 X[kk] = 0;
		 Y[kk]=0;
	 }
   INFILE =  fopen( infilestr,"r");
   if (INFILE != NULL){
       fgets(line, LINELEN, INFILE) ; 
       while( fgets(line, LINELEN, INFILE) != NULL){
          ProcessString(line);
       } 
   }
   //else
   //{
	//   printf("In splitem, unable to open the input file = %s \n",infilestr);
	//   exit(-1);
   //}

}  // end splitem

int main(int argc, char **argv)
{
	if (argc != 2)
	{
		printf("In splitem, wrong number of arguments \n");
		printf("Usage: splitem infile \n");
		exit(-1);
	}
	else
	{
		splitem_call( argv[1]);
	}

}  // end main

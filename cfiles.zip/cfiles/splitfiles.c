#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"


int  splitfiles_call( char *infilestr)
{
int endoffile;
char thisline[300];
char name[300];
char fname[300];
char FILENAME[300];
FILE *file1;
FILE *fnamefile;
int cnt;
char arr[10][120];
char cntstr[120];

 strncpy(FILENAME,infilestr,120);

 split(FILENAME,arr[0],arr[1],".");

 strncpy(name,arr[0],120);
 cnt=1;
 
 strncpy(fname,name,120);
 strncat(fname,".all",10);

 //fname = (name".all")

  file1=fopen(infilestr,"r");
  if(file1 == NULL)
  {
	  printf("In splitfiles, unable to open the input file =%s \n", infilestr);
	  exit(-1);
  }

  endoffile=getline(file1,thisline);
  
 while(endoffile==FALSE)
 {
   if( strstr(thisline,"%LP") != NULL) 
   {
      cnt++;
	  _snprintf(cntstr,120,"%d",cnt);

	  strncpy(fname,name,120);
	  strncat(fname,".",5);
	  strncat(fname,cntstr,10);

      // fname = (name"."cnt)
   }

   fnamefile=fopen(fname,"a");   // open for apend

   fprintf(fnamefile,"%s",thisline);  //  $0 > fname

   fclose(fnamefile);

   endoffile=getline(file1,thisline);
   

 }  // end while

 fclose(file1);

   return(cnt);
}

int main( int argc, char **argv)
{
int retval;
	
	if (argc != 2)
	{
		printf("In splitfiles, wrong number of arguments \n");
		printf("Usage: splitfiles infile \n");
		exit(-1);
	}
	else
	{
      retval=splitfiles_call( argv[1]);
	  exit(retval);
	}

}  // end main

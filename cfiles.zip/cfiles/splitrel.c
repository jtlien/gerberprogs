
#include <stdio.h>
#include <string.h>
#include <process.h>
#define NULLCHAR 0
#define MAX_ABREV_TABLE 8
#define TRUE 1
#define FALSE 0


struct layerinfo
{
  char mmm_layer_name[120];
  char source_str[40];
  char short_layer_name[10];
  char abrev_name[20];
  char layer_name[100];   // long name for abrev_name
} layer_table[100];

// table of layer abreviations and layer names
//   these abreviations are the last column of the 
//    the Layer Summary section of the .det report of the PAR tool
//
struct layerdesc
{
	char layer_abrev[20];
	char layer_name[120];
} layer_desc[100] = {{ "BVIA","Buried / Blind Via"},
{"SIG","Signal"},{"NPD","Non-plated Drill"},{"SM","Solder Mask"},
{"DRL","Drill"},{"PLN","Copper Plane"},{"DOC",""},{"OTL",""}};

//  This is a list of the section headers of the .det file
//    to search for when splitting the .det file
//
struct compstuff
{
 char compstr[120];
 char subdirstr[40];
 char filetypestr[10];
 int skiplines;
}  comp_array[100] = {{"Trace Termination","traceterm",".trt",2},
                     {"Self Spacing","selfsp",".ssp",2},
{"Spacing","det",".l1a",2},
{"Plated Drill Annular","pda",".l2a",2},
{"Non-Plated Drill Annular","npda",".l2a",2},
{"Registration","reg",".l3d",2},
{"Width","width",".l8a",2},
{"zzzz","",".zzz",2}};

int head_count = 8;

char rlines[5000][120];

char token_array[40][140];

int start_index[5000];
int i,j,k;
int head_num;

FILE *infile, *outfile, *lsufile;


char dirstr[120];
char filetypestr[20];
char outfilestr[140];

char basefilestr[120];
int lines_in;

char thisline[120];

// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return ( 1);
 }
}

// tokenize a line delimited by spaces
//   return number of tokens

int bust_line(char *instring)
{
int token_count;
char * pch;
char thisstring[140];

token_count = 0;

strncpy(thisstring,instring,120);
thisstring[strlen(instring)-1]=';';


//printf ("Splitting string \"%s\" in tokens:\n",thisstring);

pch = strtok (thisstring," ");

while (pch != NULL)
  {
    // printf ("next token = %s\n",pch);
    if ( token_count < 40 )
	{
		strncpy( token_array[token_count], pch, 120);
        pch = strtok (NULL, " ;");
		if ( token_array[token_count][0] != ' ')
		{
	    token_count += 1;
		}
	}
    else
	{
		printf("Too many tokens on line = %s \n", instring );
	}
}
  return token_count;
}
//
// find the given abreviation in the list of abreviations vs names
//
int find_in_table( char *abrev_in_str )
{
int abrev_found;
int kk;

 abrev_found = FALSE;

 kk = 0;
 while ( ( kk< MAX_ABREV_TABLE) && ( abrev_found == FALSE))
 {
	// printf("Comparing %s to %s \n",abrev_in_str,
		 //                layer_table[kk].abrev_name);

	 if ( strcmp( abrev_in_str, layer_desc[kk].layer_abrev) == 0)
	 {
		 abrev_found = TRUE;
		 return(kk);
	 }
	kk += 1;
 }

 if (( kk == MAX_ABREV_TABLE ) && (abrev_found == FALSE))
	{
	 printf("Error: Could not find abreviation = %s in table \n",
		  abrev_in_str);
 }
 return(-1);

}

//
// make a sub directory
//
void mkdir ( char *infilestr)
{
char commandstr[120];

strncpy( commandstr,"mkdir ",30);
strcat( commandstr,infilestr);

system( commandstr);
}

int main ( int *argc, char **argv)

{

 for (i = 0; i < 5000; i += 1)
   {
    start_index[i] = 0;
   }
    
 infile = fopen( argv[1],"r");
 
 strncpy( basefilestr, argv[1], 120);

 k = 0;
 while( ( k < strlen(basefilestr) ) && ( basefilestr[k] != '.' ))
	{
	  k += 1;
	}
 basefilestr[k] = NULLCHAR;

 if ( infile == NULL)
   {
      printf("Cannot open the input file = %s \n", argv[1]);
   }

 lines_in = 0;

// do the main split here

 k = 0;               // first, find the number of headers

 while(( k < 100 ) && ((comp_array[k].compstr[0] != 'z') 
	            |   ( comp_array[k].compstr[1] != 'z') 
				|   ( comp_array[k].compstr[2] != 'z')) )
	{
	  k += 1;
	}
  printf("k=%d \n",k);
  head_count = k;

 for ( k = 0; k < head_count; k += 1)
 {
	 printf("compare string = %s k = %d dir = %s \n",
		  comp_array[k].compstr,k, comp_array[k].subdirstr);
 }
 for (i = 0; i < 5000; i += 1)
   {
    start_index[i] = 0;
   }
    
 infile = fopen( argv[1],"r");
 
 strncpy( basefilestr, argv[1], 120);

 k = 0;
 while( ( k < strlen(basefilestr) ) && ( basefilestr[k] != '.' ))
	{
	  k += 1;
	}
 basefilestr[k] = NULLCHAR;

 if ( infile == NULL)
   {
      printf("Cannot open the input file = %s \n", argv[1]);
   }

 lines_in = 0;

 while ( getline(infile, thisline) == 0)
    {
	  // printf("Line in = %s \n", thisline);
      for ( k = 0; k < head_count; k += 1)
        {
         if (strstr(thisline, comp_array[k].compstr) != NULL)   // a header found
            {
             start_index[lines_in] = k + 1;
			 // printf("Setting start_index at %d to %d \n", lines_in,k+1);
            }
         }
      strncpy( rlines[lines_in], thisline, 120);
	  // printf("rline = %s \n", rlines[lines_in]);

      lines_in += 1;
	  // printf("lines_in = %d \n", lines_in);
    }

  fclose(infile);

  i = 0;
  printf("lines in = %d \n", lines_in);

  while( i < lines_in)
    {
      if (start_index[i] > 0 )
        {
          head_num = start_index[i] -1;
          strncpy( dirstr,comp_array[head_num].subdirstr,120);
          strncpy( filetypestr,comp_array[head_num].filetypestr,20);
          i += 1;
          if (strstr(rlines[i],"----") != NULL)  // dash underline
           {
            if (strlen( dirstr) > 0 )
              {
			   rmdir( dirstr);
               mkdir( dirstr);   // make a sub dir, if it doesn't exist already
               strncpy( outfilestr,dirstr,120);
               strcat(outfilestr,"\\");
			   strcat(outfilestr,basefilestr);
			   strcat(outfilestr,".");
               strcat(outfilestr,filetypestr);

               }
             else
               {
                strncpy( outfilestr,basefilestr,120);
                strcat( outfilestr, filetypestr);
                }

             outfile = fopen(  outfilestr,"w");     // open the new file

             while(( start_index[i] == 0 ) && ( i < lines_in))
              {
                 fprintf(outfile,"%s",rlines[i]);
                 i += 1;
               }
              fclose( outfile);
              i = i -1;
             }
           }
      i += 1;
    }
          
           
}  // end main

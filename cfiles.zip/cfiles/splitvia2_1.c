
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


FILE *file2;
FILE *file1;
FILE *errfile;
FILE *nonfile;
FILE *corefile;


int endoffile;

char thisline[200];
char a[10][120];
char b[10][120];
char c[10][120];
char d[10][120];

char *dptr;
int xval1;
int yval1;

int xcore[10000];
int ycore[10000];
char coords[10000][10000];
int first;
int result;
char X[40];
char Y[40];
char tmpstr[120];

int i;
int j;
int ncore;
int IS_FLASH;
int nvia;
int ngnd;
int nsig;
int xval;
int yval;
int val;
int found;

void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk;

  ii=0;
  kk = 0;

 while((instr[ii] != srchstr[0]) && ( ii < strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;


}  // end split

//
// perform awk compatible awk_index, counts from 1 at the leftmost
//
int awk_index( char *instr, char *inchr)
{
int kk,ll,mm;
char tstr[120];

	if (strstr(instr, inchr) == NULL)    // not found at all in string, return 0
	{
		return(0);
	}
	else    // the inchr string is a substring
	{
		kk = 0;
		while( kk < strlen( instr))
		{
          ll = 0;
		  mm = kk;
		  while( mm < strlen( instr))
		  {
			tstr[ll] = instr[mm];
			mm += 1;
			ll += 1;
		  }
		  tstr[ll] = 0;
		  if (strstr( tstr,inchr) == NULL)  // no longer found as substring
		  {
			return(kk);
		  }
		 kk += 1;
		}
	}

  return(0);

 
} // awk compatible index


// perform awk compatible substr, except the 4th parameter is the
//   result string
//
void awk_substr( char *instr, int sbegin, int slength, char *resultstr)
{

char tstr[120];
int kk;
int ll;

     if ( sbegin > 0)
	 {
		 sbegin = sbegin-1;
	 }
     kk = sbegin;
     ll = 0;
	 while ( ( kk < strlen(instr) && ( ll < slength)) )
	 {
		 tstr[ll] = instr[kk];
		 kk += 1;
		 ll  += 1;
	 }
	 tstr[ll]=0;

	 strncpy( resultstr,tstr,slength+2);

}   // awk substr
//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;
int ii;

 err = fgets(tline,120,infile);

 // ii = 0;
   // while( tline[ii] != 0 )
 //{
  //if (tline[ii] == '\n') tline[ii]= 0;	 
 // ii +=1;
// }

 if (err != NULL)
 {

   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

int main( int argc, char **argv)
{


  file1  = fopen(argv[1], "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",argv[1]);
	  exit(-1);
  }

  result = 0;
  i = 0;
  strncpy(X,"0",4);
  strncpy(Y,"0",4);

  first = 0;
  printf("reading core artwork file ... %s\n", argv[1]); 

  endoffile = getline(file1,thisline);

  while (endoffile == FALSE)
   {
    IS_FLASH = 0;
    if ( strstr(thisline,"X") != NULL)
	{
	   if (strstr(thisline,"Y") != NULL)   // both X and Y
	   {
            split(thisline,a[0],a[1],"Y");
		

			dptr = strstr(thisline,"D03*");
			
            if (dptr != NULL)
			{
			
				// printf("a0 = %s a1=%s \n",a[0],a[1]);

                val =  awk_index(a[0],"X");
                awk_substr( a[0],val +1,strlen(a[0]),X);

                awk_substr( a[1],1,strlen(a[1]) -4,Y);

                if (first == 1 ) { first = 0; }
                IS_FLASH = 1;
               }
	   }
	 else                   // X but no Y
	  { 
           split(thisline,b[0],b[1],"X");
           dptr = strstr(thisline,"D03*");
	
           if (dptr != NULL )
	       { 
              awk_substr(b[1],1,strlen(b[1]) - 4,X);
              if (first == 1)
              {
                strncpy(Y,"0",4);
                first = 0;
			  }
             IS_FLASH = 1;
		   }
	 }
	}
   else        // no X
    {
      if( strstr(thisline,"Y") != NULL)   // Y but no X
	  {
          
          split(thisline,c[0],c[1],"Y");
          dptr = strstr(thisline,"D03*");
          if ( dptr != NULL )
	       {
	        awk_substr(c[1],1,strlen(c[1]) - 4,Y);
            if (first == 1)
             {
              strncpy(X,"0",4);
              first = 0;
			}
           IS_FLASH = 1;
		  }
	  }
     else  //  no X no Y
	 {
	 } 
    }
   
   if (IS_FLASH == 1) 
    {
    
     i++;
     xval=atoi(X);
     yval=atoi(Y);
     xcore[i] = xval;
     ycore[i] = yval;

	 // printf("xval,yval = %d %d \n",xval,yval);

	 if (xval < 0 )
	 {
		xval1 = (5000 + xval/1000);
	 }
	 else
	 {
		 xval1 = xval/1000;
	 } 
	 if (yval < 0 )
	 {
		yval1 = (5000 + yval/1000);
	 }
	 else
	 {
		 yval1 = yval/1000;
	 }
     if (( xval1< 10000) && (yval1 < 10000))
	   {
            if (coords[xval1][yval1] == 0 )
			{
				coords[xval1][yval1] =1;
			}
			else
			{
				coords[xval1][yval1] += 1;
				printf("Hit = %d \n",coords[xval1][yval1]);
			}
	   }
     else
	   {
	    printf("Error: xval or yval out of range %d %d\n",xval1,yval1);
	   }
    }
   endoffile = getline(file1,thisline);
   }

   fclose(file1);

   ncore = i;

   file2  = fopen(argv[2], "r");

   if (file2 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",argv[2]);
	  exit(-1);
   }
  
   corefile  = fopen("vxxcore.art", "w");

   if (corefile == NULL)
   {
	  printf("Error: Unable to open core output file = %s \n","vxxcore.art");
	  exit(-1);
   }

   nonfile = fopen("vxxnon.art", "w");

   if (nonfile == NULL)
   {
	  printf("Error: Unable to open non core output file = %s \n","vxxnon.art");
	  exit(-1);
   }

   errfile = fopen("split_vias.err", "w");

   if (errfile == NULL)
   {
	  printf("Error: Unable to open error output file = %s \n","split_vias.err");
	  exit(-1);
   }

   first = 1;
   nvia = 0;
   ngnd = 0;
   nsig = 0;


   // fprintf(STDERR," > found %d core flashes\n", ncore);
   printf(" > found %d core flashes\n", ncore);
   printf("reading via artwork file ...\n");

   endoffile = getline(file2,thisline);

   while(endoffile == FALSE)
   {
    IS_FLASH = 0;
    if ( strstr(thisline,"X") != NULL)
	{
	   if (strstr(thisline,"Y") != NULL)   // both X and Y
	   {
            split(thisline,a[0],a[1],"Y");
			dptr = strstr(thisline,"D03*");

            if (dptr != NULL )
	       {
               
                val =  awk_index(a[0],"X");
                awk_substr( a[0],val +1,strlen(a[0]),X);
                awk_substr( a[1],1,strlen(a[1]) -4,Y);
                if(first == 1 ) { first = 0; }
                IS_FLASH = 1;
               }
	   }
	 else                   // X but no Y
	  { 
         
           split(thisline,b[0],b[1],"X");
           dptr = strstr(thisline,"D03*");

            if (dptr != NULL )
	       {
              awk_substr(b[1],1,strlen(b[1]) - 4,X);
              if (first == 1)
              {
                strncpy(Y,"0",4);
                first = 0;
	      }
             IS_FLASH = 1;
	   }
	 }
	}
   else        //  no X
    {
      if( strstr(thisline,"Y" ) != NULL)   // Y but no X
	 {
        
          split(thisline,c[0],c[1],"Y");
          dptr = (thisline,"D03");

          if (dptr != NULL) 
           {
            
	        awk_substr(c[1],1,strlen(c[1]) - 4,Y);
            if (first == 1)
             {
              strncpy(X,"0",4);
              first = 0;
	    }
           IS_FLASH = 1;
	  }
	}
   else  //  no X no Y
	{
	}  
   }
   if (IS_FLASH == 1)
    {
     nvia++;
     found = 0;
     strncpy(tmpstr,X,40);
     strcat(tmpstr,",");
     strcat(tmpstr,Y);
     xval=atoi(X);
	 yval=atoi(Y);
	 
     if (xval < 0 )
	 {
		xval1 = (5000 + xval/1000);
	 }
	 else
	 {
		 xval1 = xval/1000;
	 } 
	 if (yval < 0 )
	 {
		yval1 = (5000 + yval/1000);
	 }
	 else
	 {
		 yval1 = yval/1000;
	 }
     if ((xval1 < 10000) && (yval1 < 10000))
	 {
      if (coords[xval1][yval1]==1){
        found = 1;
	  }
	 }
     if (found == 0) {
      ngnd++;
      fprintf(corefile,"X%sY%sD03*\n", X, Y); //  "vxxcore.art"
     }
     else
     {
      nsig++;
      fprintf(nonfile,"X%sY%sD03*\n", X, Y);    //  "vxxnon.art"
     }
    }
   else
    fprintf(errfile,"(ignored) %s\n", thisline);  // "split_vias.err"

   endoffile = getline(file2,thisline);
   }

   fclose(file2);

  // fprintf(STDERR," > found %d vias contacting the core\n", ngnd);
  // fprintf(STDERR," > found %d vias isolated from the core\n", nsig);   
  printf(" > found %d vias contacting the core\n", ngnd);      
  printf(" > found %d vias isolated from the core\n", nsig);
  if (nsig != ncore){
    result = 1;
  }
  fclose(nonfile);
  fclose(errfile);
  fclose(corefile);

  exit(result);
}

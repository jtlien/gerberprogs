
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "fnv.h"
#include "utilprogs.h"

#define FNV1_32_INITV 2166136261

struct hash_col_type
{
	char value[40];
	struct hash_col_type *next;
	char str[40];
} ;

struct hash_array_stuff
{
	char value[40];
	char str[40];
	int hit;
	struct hash_col_type *collist;
} hash_array[ 70000];



int ii;


FILE *file2;
FILE *file1;
FILE *errfile;
FILE *nonfile;
FILE *corefile;


int endoffile;

char hashstr[200];
int hashval;

char thisline[200];
char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];
char retstr[120];
int retval;

char *dptr;
int xval1;
int yval1;

int xcore[10000];
int ycore[10000];

int first;
int result;
char X[40];
char Y[40];
char tmpstr[120];

int i;
int j;
int ncore;
int IS_FLASH;
int nvia;
int ngnd;
int nsig;
int xval;
int yval;
int val;
int found;


Fnv32_t fnv_32_str(char *str, Fnv32_t hval)
{
    unsigned char *s = (unsigned char *)str;	/* unsigned string */

    /*
     * FNV-1 hash each octet in the buffer
     */
    while (*s) {

	/* multiply by the 32 bit FNV magic prime mod 2^32 */
#if defined(NO_FNV_GCC_OPTIMIZATION)
	hval *= FNV_32_PRIME;
#else
	hval += (hval<<1) + (hval<<4) + (hval<<7) + (hval<<8) + (hval<<24);
#endif

	/* xor the bottom with the current octet */
	hval ^= (Fnv32_t)*s++;
    }

    /* return our new hash value */
    return hval;
}

 int get_hash( char *instr )
{
int thisval;
Fnv32_t hashval;

 hashval = fnv_32_str(instr, 2166136261);

 thisval = (hashval >>16) ^ (hashval & 0xffff);

 return(thisval);
}


void hash_init( )
{
int jj;

	for (jj=0; jj < 65000; jj += 1)
	{
	  hash_array[jj].hit = 0;
	  hash_array[jj].str[0]=0;
	  hash_array[jj].value[0]='0';
	  hash_array[jj].value[1]=0;
	  hash_array[jj].collist=NULL;
	}
}

int find_in_hash( char *instr, char *outval)
{
int hshval;
struct hash_col_type *listptr;
int hashfound;

        hshval = get_hash( instr);
	if (strcmp( hash_array[hshval].str,instr) == 0)
	{
	  strncpy(outval,hash_array[hshval].value,40);
	  return(0);
	}
	else
	{
	  listptr = hash_array[hshval].collist;
	  hashfound = FALSE;
	  while(( listptr != NULL ) && ( hashfound == FALSE))
	  {
		 // printf("Comparing %s to %s \n", listptr->str, instr);

		  if (strcmp(listptr->str, instr) == 0 )
		  {
			  strncpy(outval,listptr->value,40);
			  hashfound = TRUE;
			  return(0);
		  }
		  else
		  {
			  listptr=listptr->next;
		  }
	  }
	  if (( listptr == NULL )&& ( hashfound == FALSE))
	  {
		  printf("Internal error not found in hash = %s \n",instr);
		  return(-1);
	  }
	}
   return(-1);
}


void add_to_hash( char *instr, char *inval)
{
int hshval;
struct hash_col_type *listptr;
struct hash_col_type *tptr;

    hshval = get_hash( instr);
	if (hash_array[hshval].hit == 0)
	{
	  strncpy(hash_array[hshval].value,inval,40);
      strncpy(hash_array[hshval].str,instr,40);
	  hash_array[hshval].hit = 1;
	}
	else
	{
	  if ( strcmp(hash_array[hshval].str,instr) != 0)
	  {
		// printf("Doing a collision \n");
	    listptr = hash_array[hshval].collist;
	    while( listptr != NULL ) 
		{
		 listptr = listptr->next; 
		}
	   tptr = malloc( sizeof( struct hash_col_type ));
	  
	   strncpy(tptr->str,instr,40);
	   strncpy(tptr->value,inval,40);
	   tptr->next = hash_array[hshval].collist;

	   hash_array[hshval].collist = tptr;
	  }
	 else                               // just update the value
	 {
	   strncpy(hash_array[hshval].value,inval,40);
	 }
	}
	  
}

int splitvia2_call( char *corefilestr, char *lfilestr)
{

  hash_init();


  file1  = fopen(corefilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",corefilestr);
	  exit(-1);
  }

  result = 0;
  i = 0;
  strncpy(X,"0",4);
  strncpy(Y,"0",4);

  first = 0;
  printf("reading core artwork file ... %s\n", corefilestr); 

  endoffile = getline(file1,thisline);

  while (endoffile == FALSE)
   {
    IS_FLASH = 0;
    if ( strstr(thisline,"X") != NULL)
	{
	   if (strstr(thisline,"Y") != NULL)   // both X and Y
	   {
            split(thisline,a[0],a[1],"Y");
		

	       dptr = strstr(thisline,"D03*");
			
               if (dptr != NULL)
			{
				// printf("a0 = %s a1=%s \n",a[0],a[1]);

                val =  awk_index(a[0],"X");
                awk_substr( a[0],val +1,strlen(a[0]),X);

                awk_substr( a[1],1,strlen(a[1]) -4,Y);

                if (first == 1 ) { first = 0; }
                IS_FLASH = 1;
               }
	   }
	 else                   // X but no Y
	  { 
           split(thisline,b[0],b[1],"X");
           dptr = strstr(thisline,"D03*");
	
           if (dptr != NULL )
	       { 
              awk_substr(b[1],1,strlen(b[1]) - 4,X);
              if (first == 1)
              {
                strncpy(Y,"0",4);
                first = 0;
			  }
             IS_FLASH = 1;
		   }
	 }
	}
   else        // no X
    {
      if( strstr(thisline,"Y") != NULL)   // Y but no X
	  {
          
          split(thisline,c[0],c[1],"Y");
          dptr = strstr(thisline,"D03*");
          if ( dptr != NULL )
	       {
	        awk_substr(c[1],1,strlen(c[1]) - 4,Y);
            if (first == 1)
             {
              strncpy(X,"0",4);
              first = 0;
			}
           IS_FLASH = 1;
		  }
	  }
     else  //  no X no Y
	 {
	 } 
    }
   
   if (IS_FLASH == 1) 
    {
    
     i++;
     xval=atoi(X);
     yval=atoi(Y);
     xcore[i] = xval;
     ycore[i] = yval;

     strncpy( hashstr, X,40);
     strncat(hashstr,",",4);
     strncat(hashstr,Y,40);
    // hashval = get_hash(hashstr);
	// printf("str=%s one\n",hashstr);
     add_to_hash( hashstr, "1");

     // printf("Hashstr = %s hashval = %d \n", hashstr, hashval);

	
     
    }
   endoffile = getline(file1,thisline);
   }

   fclose(file1);

   ncore = i;

   file2  = fopen(lfilestr, "r");

   if (file2 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",lfilestr);
	  exit(-1);
   }
  
   corefile  = fopen("vxxcore.art", "w");

   if (corefile == NULL)
   {
	  printf("Error: Unable to open core output file = %s \n","vxxcore.art");
	  exit(-1);
   }

   nonfile = fopen("vxxnon.art", "w");

   if (nonfile == NULL)
   {
	  printf("Error: Unable to open non core output file = %s \n","vxxnon.art");
	  exit(-1);
   }

   errfile = fopen("split_vias.err", "w");

   if (errfile == NULL)
   {
	  printf("Error: Unable to open error output file = %s \n","split_vias.err");
	  exit(-1);
   }

   first = 1;
   nvia = 0;
   ngnd = 0;
   nsig = 0;


   // fprintf(STDERR," > found %d core flashes\n", ncore);
    printf(" > found %d core flashes\n", ncore);
    printf("reading via artwork file ...\n");

   endoffile = getline(file2,thisline);

   while(endoffile == FALSE)
   {
    IS_FLASH = 0;
    if ( strstr(thisline,"X") != NULL)
	{
	   if (strstr(thisline,"Y") != NULL)   // both X and Y
	   {
            split(thisline,a[0],a[1],"Y");
			dptr = strstr(thisline,"D03*");

            if (dptr != NULL )
	       {
               
                val =  awk_index(a[0],"X");
                awk_substr( a[0],val +1,strlen(a[0]),X);
                awk_substr( a[1],1,strlen(a[1]) -4,Y);
                if(first == 1 ) { first = 0; }
                IS_FLASH = 1;
            }
	   }
	 else                   // X but no Y
	  { 
         
           split(thisline,b[0],b[1],"X");
           dptr = strstr(thisline,"D03*");

            if (dptr != NULL )
	       {
              awk_substr(b[1],1,strlen(b[1]) - 4,X);
              if (first == 1)
              {
                strncpy(Y,"0",4);
                first = 0;
			  }
             IS_FLASH = 1;
			}
	   }
	}
   else        //  no X
    {
      if( strstr(thisline,"Y" ) != NULL)   // Y but no X
	 {   
          split(thisline,c[0],c[1],"Y");
          dptr = strstr(thisline,"D03");

          if (dptr != NULL) 
           {
            
	        awk_substr(c[1],1,strlen(c[1]) - 4,Y);
            if (first == 1)
             {
              strncpy(X,"0",4);
              first = 0;
	    }
           IS_FLASH = 1;
	  }
	}
   else  //  no X no Y
	{
	}  
   }
   if (IS_FLASH == 1)
    {
     nvia++;
     found = 0;
     strncpy(tmpstr,X,40);
     strcat(tmpstr,",");
     strcat(tmpstr,Y);

     xval=atoi(X);
     yval=atoi(Y);
	 
//	 printf("str=%s two\n",tmpstr);

     found = find_in_hash( tmpstr,retstr);
     retval=atoi(retstr);
     found=retval;

     if (found == 0) {
      ngnd++;
      fprintf(corefile,"X%sY%sD03*\n", X, Y); //  "vxxcore.art"
     }
     else
     {
      nsig++;
      fprintf(nonfile,"X%sY%sD03*\n", X, Y);    //  "vxxnon.art"
     }
    }
   else
    fprintf(errfile,"(ignored) %s\n", thisline);  // "split_vias.err"

   endoffile = getline(file2,thisline);
   }

   fclose(file2);
printf(" > found %d core flashes\n", ncore);

  // fprintf(STDERR," > found %d vias contacting the core\n", ngnd);
  // fprintf(STDERR," > found %d vias isolated from the core\n", nsig);   
   printf(" > found %d vias contacting the core\n", ngnd);      
   printf(" > found %d vias isolated from the core\n", nsig);
  if (nsig != ncore){
    result = 1;
  }
  fclose(nonfile);
  fclose(errfile);
  fclose(corefile);

  return(result);
}

/*
int main(int argc, char **argv)
{
int retval;

  if (argc != 3)
	 {
	  printf("Wrong number of arguments to splitvia2 \n");
	  printf("Usage: splitvia2 corefile dotlfile \n");
	  exit(-1);
	 }
  else
  {
	  retval=splitvia2_call( argv[1], argv[2]);
	  exit(retval);
  }

}   */



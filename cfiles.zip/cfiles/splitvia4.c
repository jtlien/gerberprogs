
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

char col1_data[500000][40];


// check that all the data in column1 of  file1 are in 
//   column 1 of infile

void splitvia4_call( char *file1str, char *infilestr)
{

int endoffile;
char thisline[300];
FILE *file1;
FILE *infile;
int nf;
int data_count;
int kk;
int found;

  file1=fopen(file1str,"r");
  if (file1==NULL)
  {
    printf("In splitvia4, unable to open the input file = %s \n",file1str);
	exit(-1);
  }

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  data_count=0;

  while (endoffile==FALSE )
  {
    if (data_count < 500000)                         //possible[$1] = 0
	{
	//	printf("storing %s at %d \n",str_array[0],data_count);

		strncpy(col1_data[data_count],str_array[0],40);
		data_count += 1;
	}
	else
	{
		printf("Array size exceeded for splitvia4 \n");
	}
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  }

  fclose(file1);

  printf("reading via artwork file ...\n");

  infile=fopen(infilestr,"r");
  if (infile==NULL)
  {
    printf("In splitvia4, unable to open the input file = %s \n",infilestr);
	exit(-1);
  }


  endoffile=getline(infile,thisline);
  nf=split_line(thisline);


  while(endoffile==FALSE)
  {

   for(kk=0; kk < (signed int) strlen( str_array[0]) ; kk += 1)
   {
	   if (str_array[0][kk] == '\n')
	   {
		   str_array[0][kk]= '\0';
	   }
   }

   kk=0;
   found=FALSE;
   while((kk < data_count) && ( found==FALSE))
   {
	   if (strcmp(col1_data[kk], str_array[0]) == 0 )
	   {
		   found=TRUE;
	   }
	 kk += 1;
   }
   if( found)
   {
     //possible[$1] = 1
   }
   else
   {
     printf("FATAL ERROR in %s : can't process %s \n",infilestr,str_array[0]); //| "cat 1>&2" 
   }

   endoffile=getline(infile,thisline);
   nf=split_line(thisline);

  }

  fclose(infile);

}  // end splitvia4_call


int main( int argc, char **argv)
{

	if (argc != 3)
	{
		printf("In splitvia4, wrong number of arguments \n");
		printf("Usage: splitvia4 file1 via_art_file \n");
		exit(-1);
	}
	else
	{
		splitvia4_call( argv[1], argv[2]);
	}

}  // end main
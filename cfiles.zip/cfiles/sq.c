

// Handle a rectangle with a rectangular aperture 
//   where the rectange is moved by less than the width of the aperture


 void small_move_rect( double xbegin, double ybegin, double xend, double yend,
	                   double rect_width, double rect_height, double hole_width,
					   double hole_height, double theta)
 {

 double h_l_x;
 double h_l_y;
 double h_u_x;
 double h_u_y;

 double 
 double dist;

 double holex1;
 double holey1;
 double holex2;
 double holey2;
 double holex3;
 double holey3;
 double holex4;
 double holey4;

 double rect_b_x1;
 double rect_b_y1;

 double rect_b_x2;
 double rect_b_y2;

 double rect_b_x3;
 double rect_b_y3;

 double rect_b_x4;
 double rect_b_y4;

 double rect_e_x1;
 double rect_e_y1;

 double rect_e_x2;
 double rect_e_y2;

 double rect_e_x3;
 double rect_e_y3;

 double rect_e_x4;
 double rect_e_y4;


     rect_b_x1 = xbegin - (rect_width/2.0);
	 rect_b_y1 = ybegin - (rect_height/2.0);

	 rect_b_x2 = xbegin - (rect_width/2.0);
	 rect_b_y2 = ybegin + (rect_height/2.0);

	 rect_b_x3 = xbegin + (rect_width/2.0);
	 rect_b_y3 = ybegin + (rect_height/2.0);

	 rect_b_x4 = xbegin + (rect_width/2.0);
     rect_b_y4 = ybegin - (rect_height/2.0);

     rect_e_x1 = xend - (rect_width/2.0);
	 rect_e_y1 = yend - (rect_height/2.0);

	 rect_e_x2 = xend - (rect_width/2.0);
	 rect_e_y2 = yend + (rect_height/2.0);

	 rect_e_x3 = xend + (rect_width/2.0);
	 rect_e_y3 = yend + (rect_height/2.0);

	 rect_e_x4 = xend + (rect_width/2.0);
     rect_e_y4 = yend - (rect_height/2.0);

     h_l_x = xbegin - (hole_width/2.0);
	 h_l_y = ybegin - (hole_height/2.0);

	 h_u_x = xbegin + (hole_width/2.0);
	 h_u_y = ybegin + (hole_height/2.0);

	 dist = ( xbegin - xend) * ( xbegin-xend) + (ybegin-yend) * (ybegin - yend)

	 dist = sqrt( dist);

	 if (theta < (PI/2.0))
	 {
	   if ( (  (h_l_x + dist * cos( theta) ) < h_u_x ) && ( ( h_l_y + dist * sin( theta) )
		                             < h_u_y) )

	   {  // has hole


         holex1 = h_l_x + dist * cos(theta);
		 holey1 = h_l_y + dist * sin(theta);

		 holex2 = h_l_x + dist * cos(theta);
		 holey2 = h_u_y;

		 holex3 = h_u_x;
		 holey3 = h_u_y;

		 holex4 = h_u_x;
		 holey4 = h_l_y + dist * sin(theta); 
		 do_rect_hole( holex1, holey1, holex2, holey2, holex3, holey3, holex4, holey4);

	   }

	   else
	   {

		   do_poly6( rect_b_x1, rect_b_y1, rect_b_x2, rect_b_y2,
			         rect_e_x2, rect_e_y2, rect_e_x3, rect_e_y3,
					 rect_e_x4, rect_e_y4, rect_b_x4, rect_e_y4);
	   }
	 }

	 if (( theta >= (PI/2.0) ) && ( theta < PI))
	 {
		 if (( h_u_x + dist * cos(theta ) > h_l_x) && ( h_l_y + dist * sin(theta) < h_u_y) )

		 {           // has hole

		 holex1 = h_l_x;
		 holey1 = h_l_y + dist * sin(theta);

		 holex2 = h_l_x;
		 holey2 = h_u_y;

		 holex3 = h_u_x + dist * cos(theta);
		 holey3 = h_u_y;

		 holex4 = h_u_x + dist * cos(theta);
		 holey4 = h_l_y + dist * sin(theta);

		 do_rect_hole( holex1, holey1, holex2, holey2, holex3, holey3, holex4, holey4);

		 }
		 else
		 {
           do_poly6( rect_b_x1, rect_b_y1, rect_e_x1, rect_e_y1,
			         rect_e_x2, rect_e_y2, rect_e_x3, rect_e_y3,
					 rect_b_x3, rect_b_y3, rect_b_x4, rect_b_y4);


		 }

	 }

    if (( theta >= (PI) ) && ( theta < (3*PI/2.0))
	 {
		 if (( h_u_x + dist * cos(theta ) > h_l_x) && ( h_u_y + dist * sin(theta) > h_l_y) )

		 {           // has hole

         holex1 = h_l_x;
		 holey1 = h_l_y;

		 holex2 = h_l_x;
		 holey2 = h_u_y + dist * sin(theta);

		 holex3 = h_u_x + dist * cos(theta);
		 holey3 = h_u_y + dist * sin(theta);

		 holex4 = h_l_x ;
		 holey4 = h_u_y + dist * sin(theta); 
		 do_rect_hole( holex1, holey1, holex2, holey2, holex3, holey3, holex4, holey4);
		 }
		 else
		 {

           do_poly6( rect_e_x1, rect_e_y1, rect_e_x2, rect_e_y2,
			         rect_b_x2, rect_b_y2, rect_b_x3, rect_b_y3,
					 rect_b_x4, rect_b_y4, rect_e_x4, rect_e_y4);


		 }

	 } 
	if (( theta >= (3*PI/2.0) ) && ( theta < (2*PI))
	 {
		 if (( h_l_x + dist * cos(theta ) > h_u_x) && ( h_u_y + dist * sin(theta) > h_l_y) )

		 {           // has hole

         holex1 = h_l_x;
		 holey1 = h_u_y + dist * sin(theta);

		 holex2 = h_l_x + dist * cos(theta);
		 holey2 = h_u_y + dist * sin(theta);

		 holex3 = h_u_x ;
		 holey3 = h_u_y + dist * sin(theta);

		 holex4 = h_u_x ;
		 holey4 = h_u_y ;
		 do_rect_hole( holex1, holey1, holex2, holey2, holex3, holey3, holex4, holey4);
		 }
		 else
		 {

           do_poly6( rect_b_x1, rect_b_y1, rect_b_x2, rect_b_y2,
			         rect_b_x3, rect_b_y3, rect_e_x3, rect_e_y3,
					 rect_e_x4, rect_e_y4, rect_e_x1, rect_e_y1);

		 }

	 }
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// strip removes lines that do no begin with a capital letter
//   if passes to output all lines that begin with capital letter
//   but do not begin with VIA 


void strip_call_out(char *infilestr, char *outfilestr)
{

FILE *file1;
FILE *outfile;
char thisline[200];
int endoffile;	
int nf;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  outfile  = fopen(outfilestr, "w");

  if (outfile == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",outfilestr);
	  exit(-1);
  }

  endoffile = getline(file1, thisline);
  nf=split_line(thisline);

  while ( endoffile == FALSE)
  {
     // printf("line = %s",thisline);

	 if ( ( hasupper( str_array[0] )  && (strcmp( str_array[0],"VIA") != 0 ))
		    || ( hasdigit( str_array[0] ) ))
	 {
		
			fprintf(outfile,"%s", thisline);
     }
    endoffile = getline(file1, thisline);
	nf=split_line(thisline);
  }
  
  fclose( file1);
  fclose( outfile);


}  // end strip_call_out

//
//  Strip out lines that begin with VIA
//
void strip_call(char *infilestr)
{
FILE *file1;
char thisline[200];
int endoffile;		
int nf;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
  }

  endoffile = getline(file1, thisline);
  nf=split_line(thisline);

  while ( endoffile == FALSE)
  {
     // printf("line = %s",thisline);

	 if ( ( hasupper( str_array[0] )  && (strcmp( str_array[0],"VIA") != 0 ))
		    || ( hasdigit( str_array[0] ) ))
	 {
		
			printf("%s", thisline);
     }
    endoffile = getline(file1, thisline);
	nf=split_line(thisline);
  }
  
  fclose( file1);


}  // end strip_call

/*
int main( int argc, char **argv)
{
	if (argc != 2)
	{

		printf("In strip, wrong number of arguments \n");
		printf("Usage: strip  fname \n");
		exit(-1);
	}
	else
	{
		strip_call(argv[1]);
	}

}

*/


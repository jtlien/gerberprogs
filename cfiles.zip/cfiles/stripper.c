
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

// Create a stripped-down netlist for use in stiffener, adhesive, stencil
//  files
// bac 1/30/03

FILE *file1,*nonet_file;
char netline[200];
int netsfound;
char endoffile;
int linkret;


int main ( int argc, char **argv)
{

// rm -f nonet.txt

// system("rm -f nonet.txt");
 linkret = unlink("nonet.txt");
 if ( linkret != 0 )
	{
	 printf("Problem with stripper script: Unable to remove nonet.txt\n");
 }

nonet_file = fopen("nonet.txt","w");
if ( nonet_file == NULL)
{
   printf("Can't open the output file nonet.txt!\n");
   exit(-1);
}

file1 = fopen("netlist.txt","r");
if ( file1 == NULL)
{
   printf("Can't open the file netlist.txt!\n");
   exit(-1);
}

endoffile = getline(file1,netline);
netsfound = FALSE;

while ((endoffile == FALSE) && (netsfound == FALSE))
{
   if ( strstr(netline,"$PACKAGES") != NULL) 
   {
      fprintf(nonet_file,"%s",netline);
   }
   else
   {
      if (strstr(netline,"$NETS") != NULL)
      {
         netsfound = TRUE;
	  }
      else
	  {
         fprintf(nonet_file,"%s",netline);
      }
    }
 endoffile = getline(file1,netline);

}   

fprintf(nonet_file, "$END\n"); 

fclose(nonet_file);
fclose(file1);

printf("The file nonet.txt includes all packages but no nets.\n");
printf("For stencil, delete all packages that don't have stencil openings.\n");
printf("For stiffener and adhesive, delete all packages.\n");

}  // end main



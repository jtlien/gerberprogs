
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

double kerf;
FILE *outfile;
FILE *summaryfile;
int subpart_count;
double s_kerf;        // side of subpart kerf
double t_kerf;        // top of subpart kerf
int flag14x18;
int flag18x18;
int flag14x14;

// print out the gerber for the header

do_gbr_head()
{
char percentchar='%';

	printf("%cFSLAX34Y34*%c\n",percentchar, percentchar);
    printf("G04 Units: mm   *\n");
    printf("%cMOMM*%c\n",percentchar, percentchar);
    printf("%cADD800C,1.0*%c\n", percentchar, percentchar);
    printf("%cADD801C,%f5.2*%c\n", percentchar, kerf/(4.0 * 10000.0), percentchar);
	printf("%cADD802C,%f5.2*%c\n",percentchar,  min(s_kerf,t_kerf)/(10.0 * 10000.0), percentchar);

}

do_rectangle( int xloc, int yloc, int xsize, int ysize)
{
int outx;
int outy;
int debug;

     debug = 0;
     outx = xloc - (xsize/2);
	 outy = yloc - (ysize/2);

	 printf("X%dY%dD02*\n",outx,outy);

     outx = xloc - (xsize/2);
	 outy = yloc + (ysize/2);

	 printf("X%dY%dD01*\n",outx,outy);

     outx = xloc + (xsize/2);
	 outy = yloc + (ysize/2);

	 printf("X%dY%dD01*\n",outx,outy);

     outx = xloc + (xsize/2);
	 outy = yloc - (ysize/2);

	 printf("X%dY%dD01*\n",outx,outy);

     outx = xloc - (xsize/2);
	 outy = yloc - (ysize/2);

	 printf("X%dY%dD01*\n",outx,outy);

	 if (debug) { printf("Rectangle at %d %d \n", xloc, yloc); }

	 fprintf(outfile,"%d :   %d %d \n", subpart_count, xloc, yloc);
	 subpart_count += 1;


}

// get the kerf value from the control/pn.ctl file

get_kerf_ctl( char *instr)
{
FILE *infile;
int endfile;
char thisline[300];
int kk,ll;
char valstr[120];
int kerffound;
int debug;


   debug=0;

infile = fopen(instr,"r");
if (infile == NULL)
{
   printf("Unable to open the control file = %s \n",instr);
   exit(-1);
}

endfile=getline(infile,thisline);

kerffound = FALSE;

while(endfile==FALSE)
{

	if (strstr(thisline,"KERF")!= NULL )   // kerf found
	{
      kk=4;
	  ll=0;
	  while((thisline[kk] != '\0') && (ll < 40))   // while not end of string
	  {
		  valstr[ll] = thisline[kk];
		  kk += 1;
		  ll += 1;
	  }
	  valstr[ll] ='0';
	  kerf = atof(valstr);
	  kerffound =TRUE;
	  if (debug) { printf("kerf = %f \n",kerf); }

	}


	endfile=getline(infile,thisline);
}

fclose(infile);

if (kerffound == FALSE)
{
printf("Was not able to find KERF in control file ! Exiting \b");
}


}   // end get_kerf_ctl

void subpanart_call(char *infilestr, char *controlfilestr,
					 double skerf, double tkerf, int subnx, int subny)
{
int i;
int j,k,l,m;

int scale;
double dx;
double dy;
int nx;
int ny;
double lx;
double ly;
double lcx;
double lcy;
double partwidth;
double partheight;
double subwidth;
double subheight;
double sub_stepx;
double sub_stepy;
double mainx;
double mainy;
double subx;
double suby;


int top_y;
int bot_y;
int left_x;
int right_x;
int endoffile;
FILE *file1;


int nf;
char thisline[300];
int debug;

 debug = 0;

 scale=10000;



   file1 = fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In subpanart, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }


   outfile=fopen("subpart.locs","w");
   if (outfile == NULL)
   {
	   printf("Unable to open the subpart.locs file for writing \n");
	   exit(-1);
   }

   subpart_count = 0;

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    if ((strcmp(str_array[0],"Xstep")==0) && (strcmp(str_array[3],"Ystep")==0))
	{
     dx = atof(str_array[2])*scale;
     dy = atof(str_array[5])*scale;
	}
    if (dx == 0)
     dx = 1532500*2;
    if (dy == 0)
     dy = 1532500*2;

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"Xnum")==0) && ( strcmp(str_array[3],"Ynum")==0))
	{                                        //$1 == "Xnum") && ($4 == "Ynum")){
    nx = atoi(str_array[2]); // $3
    ny = atoi(str_array[5]); // $6
	}
    endoffile=getline(file1,thisline);
    endoffile=getline(file1,thisline); // getline
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"X")==0) && (strcmp(str_array[3],"Y")==0)) 
	{
    lx = atoi(str_array[2])*scale - dx/2;
	lcx = atoi(str_array[2])*scale;
    ly = atoi(str_array[5])*scale - dy/2;
	lcy = atoi( str_array[5])*scale;
	}
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
   }

 fclose(file1);


 if (debug) { printf("Read the step.txt file \n"); }

 get_kerf_ctl( controlfilestr);
 
 kerf = kerf * scale;

 s_kerf = skerf * scale;
 t_kerf = tkerf * scale;

 do_gbr_head();

 printf("G54D800*\n");           // use D800 for main part separator

 if (flag14x14)
 {
    printf("X-1532500Y-1532500D02*\n");  // outline of active area
    printf("X1532500Y-1532500D01*\n");
    printf("X1532500Y1532500D01*\n");
    printf("X-1532500Y1532500D01*\n");
    printf("X-1532500Y-1532500D01*\n");
 }
 if (flag14x18)
 {
   printf("X-1532500Y-2045000D02*\n");  // outline of active area
    printf("X1532500Y-2045000D01*\n");
    printf("X1532500Y2045000D01*\n");
    printf("X-1532500Y2045000D01*\n");
    printf("X-1532500Y-2045000D01*\n");

 }
 if (flag18x18)
 {
   printf("X-2045000Y-2045000D02*\n");  // outline of active area
    printf("X2045000Y-2045000D01*\n");
    printf("X2045000Y2045000D01*\n");
    printf("X-2045000Y2045000D01*\n");
    printf("X-2045000Y-2045000D01*\n");

 }
 

 bot_y = (int) ly;
 top_y = (int) (ly + (ny * dy));

 left_x = (int) lx;
 right_x = (int) ( lx + ( nx * dx)) ;

 // draw in the  grid of the outside of the main part

 printf("G54D801*\n");
 for (i = 1; i <= nx+1; i++) 
 {
	 
	  printf("X%dY%dD02*\n", (int) ( lx+(i-1)*dx ) ,bot_y);  // 
      printf("X%dY%dD01*\n", ( int) ( lx+(i-1)*dx ),top_y);  // 
   
 }
 for (i = 1; i <= ny+1; i++) 
 {
	
		printf("X%dY%dD02*\n", left_x, (int) ( ly + (i-1)*dy) );
		printf("X%dY%dD01*\n", right_x, (int) ( ly+(i-1)*dy) );
	
 }

 if (debug ) { printf("Printed the main part outlines \n"); }

 partwidth = dx - kerf;
 partheight = dy - kerf;

 subwidth = (partwidth/subnx) - s_kerf - (s_kerf / subnx);
 subheight = ( partheight/ subny) - t_kerf - (t_kerf / subny);

 sub_stepx = subwidth + s_kerf;
 sub_stepy = subheight + t_kerf;


 printf("G54D802*\n");    // use D802 for sub part width

 // draw in the subparts

 for(j = 1; j < nx + 1; j += 1)
 {
	 mainx = (int) ( lcx + (j-1)*dx );

	 for(k=1; k < ny + 1 ; k += 1)
	 {
		 mainy = (int) ( lcy + (k-1)*dy );

		  for( l=0; l < subnx; l += 1)
		  {
			  subx = mainx - (partwidth/2.0 ) + s_kerf + (subwidth/2.0)
				  + l * (sub_stepx);
			  for(m=0; m < subny; m += 1)
			  {
				  suby = mainy - (partheight/2.0) + t_kerf + (subheight/2.0 )
					   + m * ( sub_stepy);
			      do_rectangle( (int) subx, (int) suby, (int) subwidth,(int) subheight);
			  }
		  }

	 }
 }

 printf("M02*\n");

 fclose(outfile);

 summaryfile=fopen("subpart.sum","w");
 if (summaryfile==NULL)
 {
	 printf("Unable to open the summary file = subpart.sum \n");
	 exit(-1);
 }
 fprintf(summaryfile,"subpartsize = %d %d \n",(int) subwidth, (int) subheight);
 fprintf(summaryfile,"mainpartsize = %d %d \n",(int) partwidth, (int) partheight);

 fclose(summaryfile);

}  // end subpanart_call


int main(int argc, char **argv)
{

	if ((argc == 7)|| (argc == 8 ))
	{
	 if (argc == 7 )
	 {
	  flag14x14=TRUE;           // default 14x14
      flag14x18=FALSE;
      flag18x18=FALSE;
	  subpanart_call(argv[1],argv[2],atof(argv[3]), atof(argv[4]), atoi(argv[5]),atoi( argv[6]));
	 }
	 else
	 {

		 if (strcmp(argv[7],"14x18") == 0 )
		 {
			 flag14x14=FALSE;
			 flag14x18=TRUE;
			 flag18x18=FALSE;
		     subpanart_call(argv[1],argv[2],atof(argv[3]), 
			       atof(argv[4]), atoi(argv[5]),atoi( argv[6]));
		 }
        if (strcmp(argv[7],"18x18") == 0 )
		 {
			 flag14x14=FALSE;
			 flag14x18=FALSE;
			 flag18x18=TRUE;
		     subpanart_call(argv[1],argv[2],atof(argv[3]), 
			       atof(argv[4]), atoi(argv[5]),atoi( argv[6]));
		 }
	 }
	}
	else
	{
	
		printf("Wrong number of arguments for subpanart \n");
		printf("Usage: supanart step.txt controlfile skerf tkerf nx ny [14x18 | 18x18] \n");
		printf("Where skerf and tkerf are the side and top kerf for the subpanel parts\n");
		printf(" and nx and ny are the number of parts in the x and y direction \n");
		exit(-1);
	}

}







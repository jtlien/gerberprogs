#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"


void sumlength_extract_call( )
{
FILE *sumlengthfile;
char quotchar;
char PARTNUMBER[300];
char chkfilestr[300];
char junkstr[300];
char extractstr[100];
char systemstr[300];

if (WINDOWS)
{
  strncpy(dirsep,"\\",5);
  strncpy(extractstr,"extracta",20);
}
else
{
	strncpy(dirsep,"/",5);
	strncpy(extractstr,"extract",30);
}

// revision 1 released to users on 11/15/02 - tsa
// extracts cline information from .mcm file

//--------------------------------------------------------------
//Removes tmp file
//--------------------------------------------------------------

rm_file("sumlength_tmp");
rm_file("sum_length.txt");


//--------------------------------------------------------------
//Parse Partnumber
//--------------------------------------------------------------

strncpy(chkfilestr,"report",20);
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"makelog",20);

if(  ! (file_exists( chkfilestr) ) )        // -r report/makelog 
{
    printf("FATAL ERROR: report%smakelog does not exist or is not readable\n",dirsep);
    exit(-1);
}


// PARTNUMBER=`grep "Part Number" report/makelog | cut -d: -f2`  //extracts part number
sgrep(chkfilestr,"Part Number",100);

split( grep_array[0],junkstr,PARTNUMBER,":");

//--------------------------------------------------------------
//Extracts VIA information from design
//--------------------------------------------------------------

sumlengthfile=fopen("sum_length.txt","w");

if (sumlengthfile==NULL)
{
	printf("In sumlength_extract, unable to wrte the sum_length.txt file \n");
	exit(-1);
}
quotchar=34;

fprintf(sumlengthfile, "# View:\n");   // >> sum_length.txt
fprintf(sumlengthfile, "Geometry\n");  // >> sum_length.txt
fprintf(sumlengthfile, "# Select:\n"); // >> sum_length.txt
fprintf(sumlengthfile, "CLASS = %cETCH%c\n",quotchar,quotchar); // >> sum_length.txt
fprintf(sumlengthfile, "SUBCLASS\n");   // >> sum_length.txt
fprintf(sumlengthfile, "NET_NAME\n");   // >> sum_length.txt
fprintf(sumlengthfile, "GRAPHIC_DATA_NAME = %cLINE%c\n",quotchar,quotchar); 
                                      // >> sum_length.txt
fprintf(sumlengthfile, "GRAPHIC_DATA_1\n");  //  >> sum_length.txt
fprintf(sumlengthfile, "GRAPHIC_DATA_2\n");  // >> sum_length.txt
fprintf(sumlengthfile, "GRAPHIC_DATA_3\n");  // >> sum_length.txt
fprintf(sumlengthfile, "GRAPHIC_DATA_4\n");  // >> sum_length.txt
fprintf(sumlengthfile, "GRAPHIC_DATA_5\n");  // >> sum_length.txt
fprintf(sumlengthfile, "GRAPHIC_DATA_10\n");  // >> sum_length.txt

fclose(sumlengthfile);

strncpy(systemstr,extractstr,120);
strncat(systemstr," -q ",10);
strncat(systemstr,PARTNUMBER,100);
strncat(systemstr,".mcm sum_length > sumlength_tmp",60);

system(systemstr);

//extract -q  $PARTNUMBER.mcm sum_length > sumlength_tmp

//--------------------------------------------------------------
//Removes tmp file
//--------------------------------------------------------------

rm_file("sum_length.txt");

}  // end sumlength_extract_call

/*
int main( int argc, char **argv)
{

	if (argc != 1)
	{
		printf("In sumlength_extract, wrong number of arguments \n");
		printf("Usage: sumlength_extract  \n");
		exit(-1);
	}
	else
	{
		sumlength_extract_call( );
	}

}  // end main

  */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include <math.h>

#include "dirent.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define SUBSEP ","
#define MAX_ECL_NETS 10000

#include "utilprogs.h"

int ecl_net_count;
int non_crit_count;
int non_crit_dist_count;
int non_crit_width_dist_count;
int mydist_count;
int width_dist_count;
int non_crit_net_count;

struct mydiststuff
{
	double dist;
	char netname[120];
}  mydist[10000],non_crit_dist[10000], non_crit_width_dist[10000],
width_dist[10000];

char ecl_nets[120][MAX_ECL_NETS];
char non_critical_nets[120][MAX_ECL_NETS];

// revision 1 released to users 11/15/02 - tsa
//   calculates line length from extracted data from .mcm file
//  outputs line length information on a per layer basis
//  outputs line length per part area on a per layer basis
//  outputs line width verses line length on a per layer basis
//  seperates nets in to critical non-critical based on ECL property




void add_to_mydist( char *innet, double indist)
{
int found;
int ii;

  found= FALSE;
  ii = 0;
  while(( ii < mydist_count) && ( found == FALSE))
  {
	  if (strcmp(innet, mydist[ii].netname) == 0 ) 
	  {
		  found =TRUE;
		  mydist[ii].dist += indist;
	      return;
	  }

	ii += 1;
  }
  if (found == FALSE)
  {
	  strncpy(mydist[mydist_count].netname,innet,120);
	  mydist[mydist_count].dist = indist;
      if (mydist_count < 10000)
	  {
		  mydist_count += 1;
	  }
  }

}  // end add_to_mydist

void add_to_noncrit_dist( char *innet, double indist)
{
int found;
int ii;

  found= FALSE;
  ii = 0;
  while(( ii < non_crit_dist_count) && ( found == FALSE))
  {
	  if (strcmp(innet,non_crit_dist[ii].netname) == 0 ) 
	  {
		  found =TRUE;
		  non_crit_dist[ii].dist += indist;
	      return;
	  }

	ii += 1;
  }
  if (found == FALSE)
  {
	  strncpy(non_crit_dist[non_crit_dist_count].netname,innet,120);
	  non_crit_dist[non_crit_dist_count].dist = indist;
      if (non_crit_dist_count < MAX_ECL_NETS)
	  {
		  non_crit_dist_count += 1;
	  }
	  else
	  {
		  printf("In add to non crit dist, Number of ECL nets exceeds %d \n",MAX_ECL_NETS);
		  exit(-1);
	  }
  }

}  // end add_to_non_crit_dist

void add_to_widthdist( char *innet, char *innet2, double indist)
{
int found;
int ii;
char tmpstr[300];

  found= FALSE;
  ii = 0; 
  strncpy(tmpstr,innet,120);
  strncat(tmpstr,",",4);
  strncat(tmpstr,innet2,120);
  while(( ii < width_dist_count) && ( found == FALSE))
  {

	  if (strcmp(tmpstr, width_dist[ii].netname) == 0 ) 
	  {
		  found =TRUE;
		  width_dist[ii].dist += indist;
	      return;
	  }

	ii += 1;
  }
  if (found == FALSE)
  {
	  strncpy(width_dist[width_dist_count].netname,tmpstr,120);
	  width_dist[width_dist_count].dist = indist;
      if (width_dist_count < MAX_ECL_NETS)
	  {
		  width_dist_count += 1;
	  }
	  else
	  {
		  printf("In add_to_widthdist, count exceeds %d \n",MAX_ECL_NETS);
		  exit(-1);
	  }
  }

}  // end add_to_widthdist



void add_to_noncrit_width_dist( char *innet, char *innet2, double indist)
{
int found;
int ii;
char tmpstr[300];

  found= FALSE;
  ii = 0; 
  strncpy(tmpstr,innet,120);
  strncat(tmpstr,",",4);
  strncat(tmpstr,innet2,120);
  while(( ii < non_crit_width_dist_count) && ( found == FALSE))
  {

	  if (strcmp(tmpstr, non_crit_width_dist[ii].netname) == 0 ) 
	  {
		  found =TRUE;
		  non_crit_width_dist[ii].dist += indist;
	      return;
	  }

	ii += 1;
  }
  if (found == FALSE)
  {
	  strncpy(non_crit_width_dist[non_crit_width_dist_count].netname,tmpstr,120);
	  non_crit_width_dist[non_crit_width_dist_count].dist = indist;
      if (non_crit_width_dist_count < MAX_ECL_NETS)
	  {
		  non_crit_width_dist_count += 1;
	  }
	  else
	  {
		  printf("In add to noncrit width dist, count exceeds = %d \n",MAX_ECL_NETS);
		  exit(-1);
	  }
  }

}  // end add_to_noncrit_width_dist

int find_in_mydist( char *innet)
{
int found;
int ii;

  ii = 0;
  found = FALSE;
  while((ii < mydist_count) && ( found == FALSE))
  {
	  if (strcmp(mydist[ii].netname, innet) == 0 )
	  {
		  return(TRUE);
	  }

	ii += 1;
  }

  return(FALSE);

} // end find_in_mydist

int find_in_width_dist( char *innet)
{
int found;
int ii;

  ii = 0;
  found = FALSE;
  while((ii < width_dist_count) && ( found == FALSE))
  {
	  if (strcmp(width_dist[ii].netname, innet) == 0 )
	  {
		  return(TRUE);
	  }

	ii += 1;
  }

  return(FALSE);

} // end find_in_mydist

int find_in_ecl_nets( char *innet)
{
int found;
int ii;

  ii = 0;
  found = FALSE;
  while((ii < ecl_net_count) && ( found == FALSE))
  {
	  if (strcmp(ecl_nets[ii], innet) == 0 )
	  {
		  return(TRUE);
	  }

	ii += 1;
  }

  return(FALSE);

} // end find_in_ecl_nets

double dist( double x1, double y1, double x2, double y2)
{
double dx;
double dy;
double d;

   dx = (x2-x1)*(x2-x1);
   dy = (y2-y1)*(y2-y1);
   d  = sqrt(dx+dy);
   return(d);
}

void summary_get_dist_call_append(double x, double y, char *infile1str, char *infile2str ,
								     char *appendfilestr)
{

FILE *file1;
FILE *file2;
FILE *len_tmp1file;
FILE *len_tmp2file;
FILE *len_tmp3file;
FILE *len_tmp4file;
FILE *len_tmp5file;
FILE *len_tmp6file;
FILE *appendfile;

double myarea;
int endoffile;
int nf;
char thisline[300];
char chkstr[300];
char thisnet[300];
char commandstr[300];

char *tptr;
char tmpstr[300];

double tmpdist;
char units[300];
double l_mult;
double w_mult;
int res;
char tmp[30];
char lay_wid[120][20];
int i;
int tt;
double tmp_total;
int debug;

    debug=0;

    l_mult = 1;
    w_mult = 1000;

    mydist_count = 0;
    ecl_net_count = 0;
	non_crit_dist_count=0;
    non_crit_width_dist_count=0;

	width_dist_count=0;

    file1 = fopen(infile1str,"r");
	if (file1 == NULL)
	{
		printf("In summary_get_dist, unable to open the input file = %s \n",infile1str);
		exit(-1);
	}

    file2 = fopen(infile2str,"r");
	if (file2 == NULL)
	{
		printf("In summary_get_dist, unable to open the input file = %s \n",infile2str);
		exit(-1);
	}

    appendfile = fopen(appendfilestr,"a");

	if (appendfile == NULL)
	{
		printf("In summary_get_dist, unable to open the append output file = %s \n",appendfilestr);
		exit(-1);
	}
   // FS="!"

	// Read in the file of nets

	//  S!NETA!YES              - Neta is an ecl net
	//  S!NETB!NO               - Netb is not an ecl net
	//  S!!YES                  - UNamed is an ecl net

	endoffile=getline(file1,thisline);
	nf = split_line_seper(thisline,"!");

    while(endoffile==FALSE)            //    (getline < file1)
	{
	//	printf("str_array[0] = %s str_array[1] = %s str_array[2] = %s \n",
		   //      str_array[0], str_array[1], str_array[2] );

     if(( toupper(str_array[0][0]) == 'S') && (strlen(str_array[0]) == 1 )) // $1
	 {
       if ( strcmp(str_array[1],"") == 0 )         //       $2 == "")
	   {
          strncpy( str_array[1],"UNNAMED",30);      // $2 = "UNNAMED" 
       }
	   cv_toupper(str_array[2],chkstr);

	   if (debug)
	   {
	     printf("str_array[0] = %s str_array[1] = %s str_array[2] = %s \n",
		         str_array[0], str_array[1], str_array[2] );
	   }

       if( strcmp(chkstr,"YES")== 0 )         // toupper($3) == "YES")
	   {
		 strncpy(ecl_nets[ecl_net_count], str_array[1],120);
		 if (ecl_net_count < MAX_ECL_NETS)
		 {
			 ecl_net_count += 1;
		 }
		 else
		 {
			 printf("In summary_get_dist_call, ecl_net_count exceeds = %d \n", MAX_ECL_NETS);
			 exit(-1);
		 }
         //ecl_nets[toupper($2)] = 1;
       }
       else
	   {
		 strncpy(non_critical_nets[non_crit_net_count], str_array[1],120);
		 if (non_crit_net_count < MAX_ECL_NETS)
		 {
			 non_crit_net_count += 1;
		 }
        else
		 {
			 printf("In summary_get_dist_call, non_crit_net_count exceeds = %d \n", MAX_ECL_NETS);
			 exit(-1);
		 }
         // non_critical[toupper($2)] = 1;
       }
     }
	 endoffile=getline(file1,thisline);
	 nf=split_line_seper(thisline,"!");

    }

	fclose(file1);

    myarea = x * y ; 
	
	debug = 0;

    if (debug)
	{
		printf("myarea = %f x = %f y = %f \n", myarea, x, y );
	}

//   Readin file of nets
//
//  J!...                            !MILLIMETERS
//  S!TOP!NETA!10.0!10.0!20.0!20.0!AAA!CONNECT
//  S!TOP!NETA!20.0!20.0!30.0!30.0!AAA!CONNECT
//  S!BOT!NETA!30.0!30.0!50.0!50.0!BBB!CONNECT
//    .
//    .
//    .
  endoffile=getline(file2,thisline);
  nf=split_line_seper(thisline,"!");

  while(endoffile==FALSE)
  {
   if(((str_array[0][0] == 'J') || (str_array[0][0] == 'j'))
	           && (strlen(str_array[0])==1) )    // ($1) == "J")
   {
	   cv_toupper( str_array[8], units);

      //strncpy(units,toupper($9),120);

      if (strcmp(units,"MILLIMETERS")==0)
	  {
         l_mult =1;
         w_mult =1000;
         res = 0;
		 if (debug)
		 {
		    printf("Units = MILLIMETERS \n");
		 }

      }
      else if ( strcmp(units,"MICRONS")==0)
	  {
         l_mult = 1000;
         w_mult = 1;
         res = 0; 
		 if (debug)
		 {
		    printf("Units = MICRONS \n");
		 }
      }
      else 
	  {
         res = 1 ;
      }
   }


   //printf(" str_array[0] = %s str_array[1] = %s str_array[3] = %s \n",
			//	       str_array[0],str_array[1],str_array[2] );


   if(((str_array[0][0] == 'S') || (str_array[0][0]=='s')) && (strlen(str_array[0])==1) ) // ($1) == "S")
   {
      //tmp = toupper(substr($2,1,2));
	   tmp[0] = '\0';
	   if ( strlen( str_array[1]) > 1 )
	   {
	    tmp[0] = toupper(str_array[1][0]);
	    tmp[1] = toupper(str_array[1][1]);
	    tmp[2]='\0';
	   }
	   if ( strlen( str_array[1] ) == 1 )
	   {
		   tmp[0] = toupper( str_array[1][0]);
		   tmp[1] = '\0';
	   }

	  cv_toupper( str_array[8], chkstr);

	 // printf("chkstr = %s  tmp= %s \n", chkstr,tmp);

      if( (strcmp(chkstr,"CONNECT")==0) && (strcmp(tmp,"WB") != 0 ) )
	  {
         tmpdist = dist(atof(str_array[3]),
			            atof(str_array[4]),
						atof(str_array[5]),
						atof(str_array[6]) ) / l_mult;   // $4,$5,$6,$7)/l_mult;

        // sub("_STRAP","",str_array[1]);
		 if (strstr("_STRAP",str_array[1]) != NULL)    // if name contains _STRAP
		 {

           strncpy(tmpstr,str_array[1],120);   // replace first occurance of _STRAP
		   tptr = strstr("_STRAP",tmpstr);
		   *tptr = '\0';                    // get base

		   tptr += 6;
		   tt = strlen( tmpstr);
		   while(( tt < 120) && ( *tptr != '\0' ) )
		   {
			   tmpstr[tt]= *tptr;
			   tt += 1;
			   tptr += 1;
		   }

		    tmpstr[tt] = '\0';
            strncpy(str_array[1], tmpstr,120);

		 }

		 cv_toupper(str_array[2],thisnet);

		 if (debug)
		 {
			 printf(" str_array[0] = % str_array[1] = %s str_array[3] = %s thisnet = %s \n",
				       str_array[0],str_array[1],str_array[2], thisnet);
		 }
         if ( find_in_ecl_nets(thisnet) )     // ecl net
		 {
            // mydist[$2] += tmpdist
			add_to_mydist( str_array[1], tmpdist);   // update mydist

            add_to_widthdist( str_array[1],str_array[7],tmpdist);  // $8 = layer
			        // width_dist[$2,$8]+= tmpdist

         }
         else                       // non-ecl net
		 {
            //non_crit_dist[$2] += tmpdist
			 add_to_noncrit_dist( str_array[1], tmpdist);

             add_to_noncrit_width_dist( str_array[1],
				                       str_array[7],
									   tmpdist); // non_crit_width_dist[$2,$8] += tmpdist 
			
         }
      }
   }

   endoffile=getline(file2,thisline);
   nf=split_line_seper(thisline,"!");
  }

   fclose(file2);

   len_tmp1file = fopen("len.tmp1","w");
   if (len_tmp1file == NULL)
   {
	   printf("Unable to open the len.tmp1 file for writing \n");
	   exit(-1);
   }
   fprintf(appendfile,"%19s %15s %7s\n","CRITICAL","NON-CRITICAL","TOTAL");
   fprintf(appendfile,"%-8s %11s %13s %11s\n","LAYER","LENGTH(mm)","LENGTH(mm)","LENGTH(mm)");

   for ( i=0 ; i < mydist_count; i += 1)        //in mydist)
   {
      tmp_total =  mydist[i].dist + non_crit_dist[i].dist;
      fprintf(len_tmp1file, "%-8s %7.0f %13.0f %11.0f\n", 
		  mydist[i].netname, mydist[i].dist, non_crit_dist[i].dist,tmp_total); //  > "len.tmp1"
   }
   
   for ( i=0; i < non_crit_dist_count; i += 1)   // i in non_crit_dist)
   {
      if ( ! (find_in_mydist( non_crit_dist[i].netname) ))
	  {
          tmp_total =  mydist[i].dist + non_crit_dist[i].dist;
          fprintf(len_tmp1file,"%-8s %7.0f %13.0f %11.0f\n", 
			  non_crit_dist[i].netname, mydist[i].dist, non_crit_dist[i].dist,tmp_total); 
		                                                                // > "len.tmp1"
      }
   }

   fclose(len_tmp1file);

   strncpy(commandstr,"sort len.tmp1 > len.tmp2",120);
   system(commandstr);

   len_tmp2file=fopen("len.tmp2","r");
   if ( len_tmp2file==NULL)
   {
	   printf("In summary_get_dist, unable to open the len.tmp1 file for reading\n");
	   exit(-1);
   }

   endoffile=getline(len_tmp2file,thisline);

   while( endoffile == FALSE)       // getline < "len.tmp2")
   {
        fprintf(appendfile,"%s",thisline); //  $0

		endoffile=getline(len_tmp2file,thisline);
   }

   fclose(len_tmp2file);
 
   len_tmp5file = fopen("len.tmp5","w");

   if (len_tmp5file == NULL)
   {
	   printf("Unable to open the len.tmp5 file for writing \n");
	   exit(-1);
   }
   fprintf(appendfile,"\n%24s %25s %19s\n","CRITICAL","NON-CRITICAL","TOTAL");
   fprintf(appendfile,"%-8s %11s %23s %23s\n",
	   "LAYER","LENGTH(mm)/AREA(mm^2)","LENGTH(mm)/AREA(mm^2)",
	   "LENGTH(mm)/AREA(mm^2)");

   for ( i=0; i < mydist_count; i += 1)      //  in mydist)
   {
      tmp_total =  mydist[i].dist + non_crit_dist[i].dist;
      fprintf(len_tmp5file, "%-8s %13.3f %23.3f %23.3f\n",
		  mydist[i].netname, mydist[i].dist/myarea, non_crit_dist[i].dist/myarea,tmp_total/myarea);
	                           //> "len.tmp5"
   }
   for ( i =0; i < non_crit_dist_count ; i += 1) // in non_crit_dist)
   {
      if ( ! (find_in_mydist( non_crit_dist[i].netname)) )
	  {
         tmp_total =  mydist[i].dist + non_crit_dist[i].dist;
          fprintf(len_tmp5file,"%-8s %13.3f %23.3f %23.3f\n", i, mydist[i].dist/myarea, 
			  non_crit_dist[i].dist/myarea,tmp_total/myarea);
		                  // > "len.tmp5"
      }
   }

   fclose(len_tmp5file);

   strncpy(commandstr,"sort len.tmp5 > len.tmp6",120);
   system(commandstr);

   len_tmp6file=fopen("len.tmp6","r");
   if ( len_tmp6file==NULL)
   {
	   printf("In summary_get_dist, unable to open the len.tmp6 file for reading\n");
	   exit(-1);
   }

   endoffile=getline(len_tmp6file,thisline);

   while( endoffile==FALSE)              // getline < "len.tmp6")
   {
        fprintf(appendfile,"%s",thisline); // $0

		endoffile = getline(len_tmp6file,thisline);
   }

   fclose(len_tmp2file);

   len_tmp3file = fopen("len.tmp3","w");
   if (len_tmp3file == NULL)
   {
	   printf("Unable to open the len.tmp3 file for writing \n");
	   exit(-1);
   }

   fprintf(appendfile,"\n%31s %15s %9s\n","CRITICAL","NON-CRITICAL","TOTAL");
   fprintf(appendfile,"%-10s %4s %11s %13s %13s\n",
	   "LAYER","WIDTH(um)","LENGTH(mm)","LENGTH(mm)","LENGTH(mm)");

   for ( i =0; i < width_dist_count; i += 1)   // in width_dist)
   {
      split(width_dist[i].netname,lay_wid[0],lay_wid[1],SUBSEP);
      tmp_total =  width_dist[i].dist + non_crit_width_dist[i].dist;
      fprintf(len_tmp3file,"%-10s %7.1f %10.0f %12.0f %14.0f\n", 
	  lay_wid[0],atof(lay_wid[1])*w_mult, width_dist[i].dist,
	  non_crit_width_dist[i].dist,tmp_total); // > "len.tmp3"
   }
   for ( i =0; i < non_crit_count; i += 1) // in non_crit_width_dist)
   {
     if( ! (  find_in_width_dist(non_crit_width_dist[i].netname) ))
	 {
          split(non_crit_width_dist[i].netname,lay_wid[0],lay_wid[1],SUBSEP);
          tmp_total =  width_dist[i].dist + non_crit_width_dist[i].dist;
          fprintf(len_tmp3file, "%-10s %7.1f %10.0f %12.0f %14.0f\n", lay_wid[0],
		  atof(lay_wid[1])*w_mult, width_dist[i].dist,non_crit_width_dist[i].dist,tmp_total);
		      // > "len.tmp3"
     }
   }

   fclose(len_tmp3file);

   strncpy(commandstr,"sort len.tmp3 > len.tmp4",120);
   system(commandstr);


   len_tmp4file=fopen("len.tmp4","r");
   if ( len_tmp4file==NULL)
   {
	   printf("In summary_get_dist, unable to open the len.tmp4 file for reading\n");
	   exit(-1);
   }

   endoffile=getline(len_tmp4file,thisline);


   while( endoffile==FALSE)        // getline < "len.tmp4")
   {
        fprintf(appendfile,"%s",thisline); // $0
		endoffile=getline(len_tmp4file,thisline);

   }

   fclose(len_tmp4file);

   fprintf(appendfile,"\n\n%s\n", "The following nets are considered non-critical");

   for ( i =0; i < non_crit_net_count; i +=1 )  // in non_critical)
   {
      fprintf(appendfile,"%s\n",non_critical_nets[i] );
   }
   
   fclose(appendfile);

//  system( "rm -f len.tmp1 len.tmp2 len.tmp3 len.tmp4")
}


void summary_get_dist_call(double x, double y, char *infile1str, char *infile2str )
{

FILE *file1;
FILE *file2;
FILE *len_tmp1file;
FILE *len_tmp2file;
FILE *len_tmp3file;
FILE *len_tmp4file;
FILE *len_tmp5file;
FILE *len_tmp6file;

double myarea;
int endoffile;
int nf;
char thisline[300];
char chkstr[300];
char thisnet[300];
char commandstr[300];

char *tptr;
char tmpstr[300];

double tmpdist;
char units[300];
double l_mult;
double w_mult;
int res;
char tmp[30];
char lay_wid[120][20];
int i;
int tt;
double tmp_total;
int debug;

    debug=0;

    l_mult = 1;
    w_mult = 1000;

    mydist_count = 0;
    ecl_net_count = 0;
	non_crit_dist_count=0;
    non_crit_width_dist_count=0;

	width_dist_count=0;

    file1 = fopen(infile1str,"r");
	if (file1 == NULL)
	{
		printf("In summary_get_dist, unable to open the input file = %s \n",infile1str);
		exit(-1);
	}

    file2 = fopen(infile2str,"r");
	if (file2 == NULL)
	{
		printf("In summary_get_dist, unable to open the input file = %s \n",infile2str);
		exit(-1);
	}

   // FS="!"

	// Read in the file of nets

	//  S!NETA!YES              - Neta is an ecl net
	//  S!NETB!NO               - Netb is not an ecl net
	//  S!!YES                  - UNamed is an ecl net

	endoffile=getline(file1,thisline);
	nf = split_line_seper(thisline,"!");

    while(endoffile==FALSE)            //    (getline < file1)
	{
	//	printf("str_array[0] = %s str_array[1] = %s str_array[2] = %s \n",
		   //      str_array[0], str_array[1], str_array[2] );

     if(( toupper(str_array[0][0]) == 'S') && (strlen(str_array[0]) == 1 )) // $1
	 {
       if ( strcmp(str_array[1],"") == 0 )         //       $2 == "")
	   {
          strncpy( str_array[1],"UNNAMED",30);      // $2 = "UNNAMED" 
       }
	   cv_toupper(str_array[2],chkstr);

	   if (debug)
	   {
	     printf("str_array[0] = %s str_array[1] = %s str_array[2] = %s \n",
		         str_array[0], str_array[1], str_array[2] );
	   }

       if( strcmp(chkstr,"YES")== 0 )         // toupper($3) == "YES")
	   {
		 strncpy(ecl_nets[ecl_net_count], str_array[1],120);
		 if (ecl_net_count < MAX_ECL_NETS)
		 {
			 ecl_net_count += 1;
		 }
		 else
		 {
			 printf("In summary_get_dist_call, ecl_net_count exceeds = %d \n", MAX_ECL_NETS);
			 exit(-1);
		 }
         //ecl_nets[toupper($2)] = 1;
       }
       else
	   {
		 strncpy(non_critical_nets[non_crit_net_count], str_array[1],120);
		 if (non_crit_net_count < MAX_ECL_NETS)
		 {
			 non_crit_net_count += 1;
		 }
        else
		 {
			 printf("In summary_get_dist_call, non_crit_net_count exceeds = %d \n", MAX_ECL_NETS);
			 exit(-1);
		 }
         // non_critical[toupper($2)] = 1;
       }
     }
	 endoffile=getline(file1,thisline);
	 nf=split_line_seper(thisline,"!");

    }

	fclose(file1);

    myarea = x * y ; 
	
	debug = 0;

    if (debug)
	{
		printf("myarea = %f x = %f y = %f \n", myarea, x, y );
	}

//   Readin file of nets
//
//  J!...                            !MILLIMETERS
//  S!TOP!NETA!10.0!10.0!20.0!20.0!AAA!CONNECT
//  S!TOP!NETA!20.0!20.0!30.0!30.0!AAA!CONNECT
//  S!BOT!NETA!30.0!30.0!50.0!50.0!BBB!CONNECT
//    .
//    .
//    .
  endoffile=getline(file2,thisline);
  nf=split_line_seper(thisline,"!");

  while(endoffile==FALSE)
  {
   if(((str_array[0][0] == 'J') || (str_array[0][0] == 'j'))
	           && (strlen(str_array[0])==1) )    // ($1) == "J")
   {
	   cv_toupper( str_array[8], units);

      //strncpy(units,toupper($9),120);

      if (strcmp(units,"MILLIMETERS")==0)
	  {
         l_mult =1;
         w_mult =1000;
         res = 0;
		 if (debug)
		 {
		    printf("Units = MILLIMETERS \n");
		 }

      }
      else if ( strcmp(units,"MICRONS")==0)
	  {
         l_mult = 1000;
         w_mult = 1;
         res = 0; 
		 if (debug)
		 {
		    printf("Units = MICRONS \n");
		 }
      }
      else 
	  {
         res = 1 ;
      }
   }


   //printf(" str_array[0] = %s str_array[1] = %s str_array[3] = %s \n",
			//	       str_array[0],str_array[1],str_array[2] );


   if(((str_array[0][0] == 'S') || (str_array[0][0]=='s')) && (strlen(str_array[0])==1) ) // ($1) == "S")
   {
      //tmp = toupper(substr($2,1,2));
	   tmp[0] = '\0';
	   if ( strlen( str_array[1]) > 1 )
	   {
	    tmp[0] = toupper(str_array[1][0]);
	    tmp[1] = toupper(str_array[1][1]);
	    tmp[2]='\0';
	   }
	   if ( strlen( str_array[1] ) == 1 )
	   {
		   tmp[0] = toupper( str_array[1][0]);
		   tmp[1] = '\0';
	   }

	  cv_toupper( str_array[8], chkstr);

	 // printf("chkstr = %s  tmp= %s \n", chkstr,tmp);

      if( (strcmp(chkstr,"CONNECT")==0) && (strcmp(tmp,"WB") != 0 ) )
	  {
         tmpdist = dist(atof(str_array[3]),
			            atof(str_array[4]),
						atof(str_array[5]),
						atof(str_array[6]) ) / l_mult;   // $4,$5,$6,$7)/l_mult;

        // sub("_STRAP","",str_array[1]);
		 if (strstr("_STRAP",str_array[1]) != NULL)    // if name contains _STRAP
		 {

           strncpy(tmpstr,str_array[1],120);   // replace first occurance of _STRAP
		   tptr = strstr("_STRAP",tmpstr);
		   *tptr = '\0';                    // get base

		   tptr += 6;
		   tt = strlen( tmpstr);
		   while(( tt < 120) && ( *tptr != '\0' ) )
		   {
			   tmpstr[tt]= *tptr;
			   tt += 1;
			   tptr += 1;
		   }

		    tmpstr[tt] = '\0';
            strncpy(str_array[1], tmpstr,120);

		 }

		 cv_toupper(str_array[2],thisnet);

		 if (debug)
		 {
			 printf(" str_array[0] = % str_array[1] = %s str_array[3] = %s thisnet = %s \n",
				       str_array[0],str_array[1],str_array[2], thisnet);
		 }
         if ( find_in_ecl_nets(thisnet) )     // ecl net
		 {
            // mydist[$2] += tmpdist
			add_to_mydist( str_array[1], tmpdist);   // update mydist

            add_to_widthdist( str_array[1],str_array[7],tmpdist);  // $8 = layer
			        // width_dist[$2,$8]+= tmpdist

         }
         else                       // non-ecl net
		 {
            //non_crit_dist[$2] += tmpdist
			 add_to_noncrit_dist( str_array[1], tmpdist);

             add_to_noncrit_width_dist( str_array[1],
				                       str_array[7],
									   tmpdist); // non_crit_width_dist[$2,$8] += tmpdist 
			
         }
      }
   }

   endoffile=getline(file2,thisline);
   nf=split_line_seper(thisline,"!");
  }

   fclose(file2);

   len_tmp1file = fopen("len.tmp1","w");
   if (len_tmp1file == NULL)
   {
	   printf("Unable to open the len.tmp1 file for writing \n");
	   exit(-1);
   }
   printf("%19s %15s %7s\n","CRITICAL","NON-CRITICAL","TOTAL");
   printf("%-8s %11s %13s %11s\n","LAYER","LENGTH(mm)","LENGTH(mm)","LENGTH(mm)");

   for ( i=0 ; i < mydist_count; i += 1)        //in mydist)
   {
      tmp_total =  mydist[i].dist + non_crit_dist[i].dist;
      fprintf(len_tmp1file, "%-8s %7.0f %13.0f %11.0f\n", 
		  mydist[i].netname, mydist[i].dist, non_crit_dist[i].dist,tmp_total); //  > "len.tmp1"
   }
   
   for ( i=0; i < non_crit_dist_count; i += 1)   // i in non_crit_dist)
   {
      if ( ! (find_in_mydist( non_crit_dist[i].netname) ))
	  {
          tmp_total =  mydist[i].dist + non_crit_dist[i].dist;
          fprintf(len_tmp1file,"%-8s %7.0f %13.0f %11.0f\n", 
			  non_crit_dist[i].netname, mydist[i].dist, non_crit_dist[i].dist,tmp_total); 
		                                                                // > "len.tmp1"
      }
   }

   fclose(len_tmp1file);

   strncpy(commandstr,"sort len.tmp1 > len.tmp2",120);
   system(commandstr);

   len_tmp2file=fopen("len.tmp2","r");
   if ( len_tmp2file==NULL)
   {
	   printf("In summary_get_dist, unable to open the len.tmp1 file for reading\n");
	   exit(-1);
   }

   endoffile=getline(len_tmp2file,thisline);

   while( endoffile == FALSE)       // getline < "len.tmp2")
   {
        printf("%s",thisline); //  $0

		endoffile=getline(len_tmp2file,thisline);
   }

   fclose(len_tmp2file);
 
   len_tmp5file = fopen("len.tmp5","w");

   if (len_tmp5file == NULL)
   {
	   printf("Unable to open the len.tmp5 file for writing \n");
	   exit(-1);
   }
   printf("\n%24s %25s %19s\n","CRITICAL","NON-CRITICAL","TOTAL");
   printf("%-8s %11s %23s %23s\n",
	   "LAYER","LENGTH(mm)/AREA(mm^2)","LENGTH(mm)/AREA(mm^2)",
	   "LENGTH(mm)/AREA(mm^2)");

   for ( i=0; i < mydist_count; i += 1)      //  in mydist)
   {
      tmp_total =  mydist[i].dist + non_crit_dist[i].dist;
      fprintf(len_tmp5file, "%-8s %13.3f %23.3f %23.3f\n",
		  mydist[i].netname, mydist[i].dist/myarea, non_crit_dist[i].dist/myarea,tmp_total/myarea);
	                           //> "len.tmp5"
   }
   for ( i =0; i < non_crit_dist_count ; i += 1) // in non_crit_dist)
   {
      if ( ! (find_in_mydist( non_crit_dist[i].netname)) )
	  {
         tmp_total =  mydist[i].dist + non_crit_dist[i].dist;
          fprintf(len_tmp5file,"%-8s %13.3f %23.3f %23.3f\n", i, mydist[i].dist/myarea, 
			  non_crit_dist[i].dist/myarea,tmp_total/myarea);
		                  // > "len.tmp5"
      }
   }

   fclose(len_tmp5file);

   strncpy(commandstr,"sort len.tmp5 > len.tmp6",120);
   system(commandstr);

   len_tmp6file=fopen("len.tmp6","r");
   if ( len_tmp6file==NULL)
   {
	   printf("In summary_get_dist, unable to open the len.tmp6 file for reading\n");
	   exit(-1);
   }

   endoffile=getline(len_tmp6file,thisline);

   while( endoffile==FALSE)              // getline < "len.tmp6")
   {
        printf("%s",thisline); // $0

		endoffile = getline(len_tmp6file,thisline);
   }

   fclose(len_tmp6file);

   len_tmp3file = fopen("len.tmp3","w");
   if (len_tmp3file == NULL)
   {
	   printf("Unable to open the len.tmp3 file for writing \n");
	   exit(-1);
   }

   printf("\n%31s %15s %9s\n","CRITICAL","NON-CRITICAL","TOTAL");
   printf("%-10s %4s %11s %13s %13s\n",
	   "LAYER","WIDTH(um)","LENGTH(mm)","LENGTH(mm)","LENGTH(mm)");

   for ( i =0; i < width_dist_count; i += 1)   // in width_dist)
   {
      split(width_dist[i].netname,lay_wid[0],lay_wid[1],SUBSEP);
      tmp_total =  width_dist[i].dist + non_crit_width_dist[i].dist;
      fprintf(len_tmp3file,"%-10s %7.1f %10.0f %12.0f %14.0f\n", 
	  lay_wid[0],atof(lay_wid[1])*w_mult, width_dist[i].dist,
	  non_crit_width_dist[i].dist,tmp_total); // > "len.tmp3"
   }
   for ( i =0; i < non_crit_count; i += 1) // in non_crit_width_dist)
   {
     if( ! (  find_in_width_dist(non_crit_width_dist[i].netname) ))
	 {
          split(non_crit_width_dist[i].netname,lay_wid[0],lay_wid[1],SUBSEP);
          tmp_total =  width_dist[i].dist + non_crit_width_dist[i].dist;
          fprintf(len_tmp3file, "%-10s %7.1f %10.0f %12.0f %14.0f\n", lay_wid[0],
		  atof(lay_wid[1])*w_mult, width_dist[i].dist,non_crit_width_dist[i].dist,tmp_total);
		      // > "len.tmp3"
     }
   }

   fclose(len_tmp3file);

   strncpy(commandstr,"sort len.tmp3 > len.tmp4",120);
   system(commandstr);


   len_tmp4file=fopen("len.tmp4","r");
   if ( len_tmp4file==NULL)
   {
	   printf("In summary_get_dist, unable to open the len.tmp4 file for reading\n");
	   exit(-1);
   }

   endoffile=getline(len_tmp4file,thisline);


   while( endoffile==FALSE)        // getline < "len.tmp4")
   {
        printf("%s",thisline); // $0
		endoffile=getline(len_tmp4file,thisline);

   }

   fclose(len_tmp4file);

   printf("\n\n%s\n", "The following nets are considered non-critical");

   for ( i =0; i < non_crit_net_count; i +=1 )  // in non_critical)
   {
      printf("%s\n",non_critical_nets[i] );
   }
   
//  system( "rm -f len.tmp1 len.tmp2 len.tmp3 len.tmp4")
}

/*
int main( int argc, char **argv)
{

  if (argc != 5)
  {
	  printf("Wrong number of arguments for summary_get_dist \n");
	  printf("Usage: summary_get_dist x_size y_size infile1 infile2 \n");
	  exit(-1);
  }
  else
  {
	  summary_get_dist_call( atof(argv[1]),atof(argv[2]),
		                    argv[3], argv[4]);

  }


}  // end main

  */

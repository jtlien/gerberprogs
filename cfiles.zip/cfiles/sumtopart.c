#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>


#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//
//  Check that units are correct
//


int ii;
char thisline[240];
FILE *file1;
FILE *file2;
char str_array[120][120];

int endoffile;

int stn;
int dcode;
double width;
char typestr[200];
char usechar;
int number_fields;


//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,240,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = '\0';
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line


void out_head(  )
{

fprintf(file2,"APTUNITS mm\n");
fprintf(file2,"ARCRES 9.0000\n");
fprintf(file2,"CIRCULAR off\n");
fprintf(file2,"FONT /usr/local/cad_util/asm500/simplex.shx\n");
fprintf(file2,"FONTDIR /usr/local/cad_util/asm500/\n");
fprintf(file2,"FORMAT 5.4\n");
fprintf(file2,"LINE d10\n");
fprintf(file2,"MSCALE 1.0\n");
fprintf(file2,"START_APT d10\n");
fprintf(file2,"OUTLINE off\n");
fprintf(file2,"GBR_END M02\n");
fprintf(file2,"ABSOLUTE on\n");
fprintf(file2,"CIRANG 360\n");
fprintf(file2,"FLASH on\n");
fprintf(file2,"TRACE off\n");
fprintf(file2,"PEND 0\n");
fprintf(file2,"OFFSET0 0.0 0.0\n");

} // end out_head

int main( int argc, char  **argv)
{

	if (argc != 3)
	{
		printf("Usage: sumtopart infile outfile \n");
		printf("        example:   sumtopart sumlist 10130816-00.prt \n");
		exit(-1);
	}
    file1  = fopen(argv[1], "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",argv[1]);
	  exit(-1);
	}

    file2  = fopen(argv[2], "w");

    if (file2 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",argv[2]);
	  exit(-1);
	}

	out_head();

    endoffile = getline(file1, thisline);
    number_fields = split_line(thisline);

    while( endoffile == FALSE)
	{
	  
	 if (strstr(thisline,"SUMMARY WHEEL LISTING") != NULL)
	 {
		endoffile=getline(file1,thisline);  // skip underscore line
	    endoffile=getline(file1,thisline);  // skip column headers
		endoffile=getline(file1,thisline);
	 }
	 else
	 {
		if (number_fields == 5 )   // square or circle
		{
          stn = atoi(str_array[0]);
		  dcode = atoi(str_array[1]);
		  strncpy(typestr,str_array[2],30);
		  usechar=tolower(str_array[3][0]);
		 
          //width= atof(str_array[4]);

		  fprintf(file2,"D%d %s %c %s %s %s \n",dcode,str_array[4],usechar,
			  typestr,str_array[4],str_array[4]);
		}	
	   if (number_fields == 6 )   // rectangle or oblong
		{
          stn = atoi(str_array[0]);
		  dcode = atoi(str_array[1]);
		  strncpy(typestr,str_array[2],30);
		  usechar=tolower(str_array[3][0]);
		 
          //width= atof(str_array[4]);

		  fprintf(file2,"D%d %s %c %s %s %s \n",dcode,str_array[4],usechar,
			  typestr,str_array[4],str_array[5]);
		}
	 }
	
	 endoffile = getline(file1, thisline);
     number_fields = split_line(thisline);

	}  // end while

   fclose(file1);
   fclose(file2);


} // end main

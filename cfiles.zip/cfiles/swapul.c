#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"


void swapul_call_out(char *infilestr, char *outfilestr)
{
int endoffile;
FILE *file1;
FILE *outfile;
char thisline[200];
int number_fields;


  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n", infilestr);
	  exit(-1);
  }

  outfile  = fopen(outfilestr, "w");

  if (outfile == NULL)
  {
	  printf("Error: Unable to open output file = %s \n", outfilestr);
	  exit(-1);
  }

  endoffile = getline(file1,thisline);
  number_fields = split_line(thisline);

  while(endoffile == FALSE)
  {
   if(strcmp(str_array[3],"U")== 0)
   {
    if( number_fields == 8)
	{
     fprintf(outfile,"%10.4f %10.4f %5d",atof(str_array[0]),
		                        atof(str_array[1]),atoi(str_array[2]));
     fprintf(outfile,"%3s %5s %5s","L",str_array[4],str_array[5]);
     fprintf(outfile,"%20s %10.4f\n",str_array[6],atof(str_array[7]));
	}
    else 
	{    
     fprintf(outfile,"%10.4f %10.4f %5d",atof(str_array[0]),
		          atof(str_array[1]),atoi(str_array[2]));
     fprintf(outfile,"%3s %5s %5s","L",str_array[4],str_array[5]);
     fprintf(outfile,"%20s\n",str_array[6]);
	}
   }
  else if( strcmp(str_array[3],"L")== 0)
   {
    if( number_fields == 8)
	{
     fprintf(outfile,"%10.4f %10.4f %5d",atof(str_array[0]),
		                        atof(str_array[1]),atoi(str_array[2]));
     fprintf(outfile,"%3s %5s %5s","U",str_array[4],str_array[5]);
     fprintf(outfile,"%20s %10.4f\n",str_array[6],atof(str_array[7]));
	}
    else 
	{    
     fprintf(outfile,"%10.4f %10.4f %5d",atof(str_array[0]),
		 atof(str_array[1]),atoi(str_array[2]));
     fprintf(outfile,"%3s %5s %5s","U",str_array[4],str_array[5]);
     fprintf(outfile,"%20s\n",str_array[6]);
	} 
   }
  else // field 4 not "U" or "L"
  {
    fprintf(outfile,"%s",thisline);
  } 

  endoffile = getline(file1,thisline);
  number_fields = split_line(thisline);

 } // while not endoffile

 fclose(file1);
 fclose(outfile);

} // end swapul_call_out


void swapul_call(char *infilestr)
{
int endoffile;
FILE *file1;
char thisline[200];
int number_fields;


  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n", infilestr);
	  exit(-1);
  }

  endoffile = getline(file1,thisline);
  number_fields = split_line(thisline);

  while(endoffile == FALSE)
  {
   if(strcmp(str_array[3],"U")== 0)
   {
    if( number_fields == 8)
	{
     printf("%10.4f %10.4f %5d",atof(str_array[0]),
		                        atof(str_array[1]),atoi(str_array[2]));
     printf("%3s %5s %5s","L",str_array[4],str_array[5]);
     printf("%20s %10.4f\n",str_array[6],atof(str_array[7]));
	}
    else 
	{    
     printf("%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),atoi(str_array[2]));
     printf("%3s %5s %5s","L",str_array[4],str_array[5]);
     printf("%20s\n",str_array[6]);
	}
   }
  else if( strcmp(str_array[3],"L")== 0)
   {
    if( number_fields == 8)
	{
     printf("%10.4f %10.4f %5d",atof(str_array[0]),
		                        atof(str_array[1]),atoi(str_array[2]));
     printf("%3s %5s %5s","U",str_array[4],str_array[5]);
     printf("%20s %10.4f\n",str_array[6],atof(str_array[7]));
	}
    else 
	{    
     printf("%10.4f %10.4f %5d",atof(str_array[0]),atof(str_array[1]),atoi(str_array[2]));
     printf("%3s %5s %5s","U",str_array[4],str_array[5]);
     printf("%20s\n",str_array[6]);
	} 
   }
  else // field 4 not "U" or "L"
  {
    printf("%s",thisline);
  } 

  endoffile = getline(file1,thisline);
  number_fields = split_line(thisline);

 } // while not endoffile

 fclose(file1);

} // end swapul_call

/*
int main( int argc, char **argv)
{

  if (argc != 2)
  {
	  printf("In swapul, wrong number of arguments \n");
	  printf("Usage: swapul infile \n");
	  exit(-1);
  }
  else
  {
	  swapul_call(argv[1]);
  }

}  // end main
*/

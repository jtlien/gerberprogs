#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0



int main(int argc , char **argv)
{
double resval;

    resval=atof("397.");

	printf("result = %f \n", resval );
	resval=atof("20.e3");

	printf("result = %f \n", resval );

	resval=atof("20e3");

	printf("result = %f \n", resval );

    resval=atof("20.3e3");

	printf("result = %f \n", resval );
}
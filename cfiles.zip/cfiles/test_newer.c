
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void test_newer_call( char *infile1str, char *infile2str)
{

	if (is_newer( infile1str, infile2str) )
	{
		printf("%s is newer \n",infile1str);
	}
	else
	{
		printf("%s is newer \n",infile2str);
	}


}  // end test_newer_call


int main( int argc, char **argv)

{

	if ( argc !=3)
	{
		printf("In test_newer, wrong number of arguments \n");
		printf("Usage: test_newer file1 file2\n");
		exit(-1);
	}
	else
	{
	 test_newer_call( argv[1], argv[2]);
	}
	

}  // end main

  

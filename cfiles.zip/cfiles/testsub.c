#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include "dirent.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"



// first parameter is a directory
//   find all the files in the directory that end with .gbr
//   and run addstar on them and put the results into .gbrf

int main( int argc, char **argv)
{

char tofilestr[300];


 
    strncpy(tofilestr,"the quick brown ' fox jumped fox over the lazy",120);

	gsubs("fox","dalmation",tofilestr);

	printf("str = %s \n",tofilestr);


}

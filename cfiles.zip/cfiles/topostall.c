#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include "dirent.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//
//  This program is used to run gbrtops on all the files in a given directory
//      that end with .art.
//     
//

double getx( char *instr)
{
char tstr[300];
int kk;
int ll;
char valstr[200];

  // printf("In step x \n");

   strncpy(tstr,instr,200);
   kk=0;
   ll=0;

   while((tstr[kk] != '=')  && ( kk < 200))
   {
	   kk += 1;
   }
   kk += 1;  // skip past =

   while((tstr[kk] == ' ') && (kk < 200))
   {
	   kk += 1;
   }
   
   ll=0;
   while( (tstr[kk] != ' ') && ( tstr[kk] != '\n') && (kk < 200))
   {
	   valstr[ll] = tstr[kk];
       kk += 1;
	   ll +=1;
   }
   valstr[ll]= '\0';

   //printf("X val str = %s \n", valstr);

   return( atof(valstr));

}

double gety( char *instr)
{
char tstr[300];
int kk;
int ll;
char valstr[200];

   //printf("In gety \n");

   strncpy(tstr,instr,200);
   kk=0;
   ll=0;

   while((tstr[kk] != '=')  && ( kk < 200))
   {
	   kk += 1;
   }
   kk +=1;

   while((tstr[kk] != '=')  && (kk < 200 ))
   {
	   kk += 1;
   }
   kk += 1;

   while((tstr[kk] == ' ') && ( kk < 200 ))
   {
	   kk += 1;
   }

   ll=0;
   while( (tstr[kk] != ' ') && ( tstr[kk] != '\n') && ( kk < 200) )
   {
	   valstr[ll] = tstr[kk];
       kk += 1;
	   ll +=1;
   }
   valstr[ll]= '\0';

    // printf("Y val str = %s \n", valstr);
   return( atof(valstr));

}

void strtovals( char *instr, double *fval)
{
char tstr[300];
int kk;
int ll;
char valstr[200];

   strncpy(tstr,instr,200);
   kk=0;
   ll=0;

   while(tstr[kk] == ' ')
   {
	   kk += 1;
   }
   while( tstr[kk] != ' ')
   {
	   valstr[ll] = tstr[kk];
       kk += 1;
	   ll +=1;
   }
   valstr[ll]= '\0';

   fval[0]=atof(valstr);

   while (tstr[kk] == ' ' )
   {
	   kk += 1;
   }

   ll=0;
   while( tstr[kk] != ' ')
   {
	   valstr[ll] = tstr[kk];
       kk += 1;
	   ll +=1;
   }
   valstr[ll]= '\0';

   fval[1]=atof(valstr);
   while (tstr[kk] == ' ' )
   {
	   kk += 1;
   }

   ll=0;
   while( tstr[kk] != ' ')
   {
	   valstr[ll] = tstr[kk];
       kk += 1;
	   ll +=1;
   }
   valstr[ll]= '\0';

   fval[2]=atof(valstr);

   while (tstr[kk] == ' ' )
   {
	   kk += 1;
   }

   ll=0;
   while( (tstr[kk] != ' ') && (tstr[kk] != '\n'))
   {
	   valstr[ll] = tstr[kk];
       kk += 1;
	   ll +=1;
   }
   valstr[ll]= '\0';

   fval[3]=atof(valstr);

}

// first parameter is a directory
//   find all the files in the directory that end with .gbr
//   and run addstar on them and put the results into .gbrf

void topostall_call( char *dirstr, char *commandstr)
{
int i;
char fromfilestr[300];
char tofilestr[300];
int file_count;
char newfname[300];
char systemstr[300];
FILE *errorfile;
FILE *stepfile;
int endoffile;
char thisline[300];
int k,l;
double fval[10];
char valstr[300];
double minx;
double miny;
double maxx;
double maxy;
double stepx;
double stepy;
double xdim;
double ydim;
char errfilestr[300];


 strncpy(errfilestr,"partinfo.txt",40);


 

 if (dir_exists( dirstr ) )  // check if the directory exists
	{

	 file_count = scandir_matchext(dirstr,0,".art");  // get all .art files

	 // printf("file count = %d \n", file_count);

       
	   rm_file(errfilestr);  // if errorfile exists, remove it

	 for(i=0; i < file_count; i += 1)
	 {
	   // printf("test i = %d \n",i);

	   replace_ext( scan_array[i], newfname,".ps");

	   strncpy(fromfilestr,dirstr,120);
	   strncat(fromfilestr,"\\",3);
	   strncat(fromfilestr,scan_array[i],120);

      // printf("test i = %d \n",i);

	   strncpy(tofilestr,dirstr,120);
	   strncat(tofilestr,"\\",3);
       strncat(tofilestr,newfname,120);

	  // printf(" i = %d fromfilestr = %s tofilestr = %s \n", i,fromfilestr, tofilestr);


	   strncpy(systemstr,"gbrtops ",30);
	   strncat(systemstr,fromfilestr,120);
	   strncat(systemstr," ",10);
	   strncat(systemstr,tofilestr,120);


       system( systemstr);  // update the original

	 }

	 // now read and analyze the errorfile

	 errorfile=fopen(errfilestr,"r");
	 if (errorfile == NULL)
	 {
		 printf("Unable to open the errorfile \n");
		 exit(-1);
	 }

	 fval[0]=0;
	 fval[1]=0;
	 fval[2]=0;
	 fval[3]=0;

	 minx = 0.0;
	 miny = 0.0;
	 maxx = 0.0;
	 maxy = 0.0;

	 endoffile=getline(errorfile,thisline);

	 while( endoffile==FALSE)
	 {

		 if ((thisline[0] == 'E' ) && (thisline[1]=='x')) // extents line
		 {
			 k=9;
			 l=0;
			 while(( thisline[k] != '\n') && ( l < 120))
			 {
				 valstr[l]= thisline[k];
				 k+=1;
				 l+=1;
			 }

			 valstr[l] = '\0';
			// printf("valstr = %s \n",valstr);

			 strtovals(valstr,fval);

			 //printf("vals = %f %f %f %f \n",fval[0],fval[1],fval[2],fval[3]);

			 if (fval[0] < minx )
			 {
				 minx = fval[0];
			 }
             if (fval[1] < miny )
			 {
				 miny = fval[1];
			 }
             if (fval[2] > maxx )
			 {
				 maxx = fval[2];
			 }
             if (fval[3] > maxy )
			 {
				 maxy = fval[3];
			 }

		 }

		 endoffile=getline(errorfile,thisline);
	 }

	 fclose(errorfile);

	 errorfile=fopen(errfilestr,"a");

	 fprintf(errorfile," \n");

	
     printf("Overall extents = %f %f %f %f \n",minx, miny, maxx, maxy);
	 fprintf(errorfile,"Overall extents = %f %f %f %f \n",minx, miny, maxx, maxy);

	 printf("Part dimensions = %f %f \n", (maxx - minx)/100000.0, (maxy-miny)/100000.0);
     fprintf(errorfile,"Part dimensions = %f %f \n", 
		         (maxx - minx)/100000.0, (maxy-miny)/100000.0);
	 xdim = (maxx-minx)/100000.0;
	 ydim = (maxy-miny)/100000.0;

	
	 stepfile=fopen("step.txt","r");

	 if (stepfile==NULL)
	 {
		 printf("Unable to find the step.txt file \n");
		 exit(-1);
	 }
	 else
	 {
		 endoffile= getline(stepfile, thisline);
		 // first line of stepfile should be
		 //    Xstep = %f Ystep = %f 

		 stepx=getx(thisline);
		 stepy=gety(thisline);
         
		 printf("Step file dimensions = %f %f\n", stepx, stepy);
		 fprintf(errorfile,"Step file dimensions = %f %f\n", stepx, stepy);

		 printf("Difference from step file = %f %f\n", xdim-stepx, ydim-stepy);
         fprintf(errorfile,"Difference from step file = %f %f\n", xdim-stepx, ydim-stepy);
		 
		 fclose(stepfile);
         if (xdim-stepx > .45 )
		 {
			 fclose(errorfile);
			 printf("X dimension is larger than half the default kerf width \n");
			 exit(-1);
		 }
         if (ydim-stepy > .45 )
		 {
			 fclose(errorfile);
			 printf("Y dimension is larger than half the default kerf width \n");
			 exit(-1);
		 }
		 

	 }

	 fclose(errorfile);

	 if (strlen(commandstr) > 0 )
	 {
		 //printf("argv 2 = %s \n",argv[2]);

		 if (strcmp( commandstr,"nosave") == 0 )
		 {
			 printf("Deleting .ps files from %s \n", dirstr);

			 strncpy(systemstr,"rm ",10);
			 strncat(systemstr,dirstr,120);
			 strncat(systemstr,"\\",10);
			 strncat(systemstr,"*.ps",10);
		  
			 system(systemstr);
		 }

	 }
 }
 else
 {
	 printf("In topostall, unable to open the directory = %s \n",dirstr);
	 exit(-1);

 }

}


int main( int argc, char **argv)
{


if ((argc != 2) && (argc != 3 ))
	{
	 printf("topostall called with wrong number of arguments \n");
	 printf("Usage: topostall  dirname [nosave]\n");
	 printf("Usage:  nosave will cause .ps files to be deleted \n");
	 printf("      dirname is the name of the directory \n");
	 exit(-1);
	}
 else
	{
	    if (argc == 2)
		{
          topostall_call( argv[1], "");
		}
		else
		{
			if (strcmp( argv[2],"nosave") == 0 )
			{
				topostall_call(argv[1],"nosave");
			}
			else
			{
				printf("Usage: topostall dirname [nosave] \n");
				exit(-1);
			}

		}
	}

}  // end main




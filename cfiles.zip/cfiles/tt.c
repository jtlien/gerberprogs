 dist =  fabs( (-( total_x_width / 2.0 ) * mymult ) - xmin) / mymult;

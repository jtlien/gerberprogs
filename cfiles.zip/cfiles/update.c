#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// subset of makestruct that creates the prototype text files.
// assumes that makelog does not contain info about customer,
// description, and via combinations
// designed to update to prepare for use of makelayers and panelize
// bac, 12-23-97
// Version 1.0


void update_call( )
{

char localname[300];
char basename[300];
char pwdstr[300];
int llc;
char customer[300];
char description[300];
char mors[30];
char lcounttext[300];
char thruvias[30];
char blindvias[30];
char viadescrip[300];
char USER[300];
char progname[300];
char datestr[300];
char logfilestr[300];
char llcstr[300];
char viatype[30];
int monthnum;

FILE *histfile;
FILE *sumfile;
FILE *pcdfile;
FILE *logfile;
FILE *protofile;

strncpy(logfilestr,"c:\\log\\logfile.txt",40);  // may need to change

// Log usage
logfile=fopen(logfilestr,"a");

if (logfile==NULL)
{
	printf("Unable to open the log file for append, file = %s \n",logfilestr);
	printf("You can create a log directory c:\\log \n");
	exit(-1);
}

//date>>/users/bac/library/usage_log

get_date(datestr);

//printf("datestr=%s\n",datestr);

fprintf(logfile,"%s",datestr);

strncpy(progname,"update",30);

get_whoami( USER);

fprintf(logfile, "%s: used by %s\n",progname,USER); // >>/users/bac/library/usage_log
fclose(logfile);

// check for correct current directory
//basename=${PWD##*\/}

getwd(pwdstr);

get_full_path_end( pwdstr,basename);

//localname=${PWD##*\/}.mcm
strncpy(localname,basename,120);
strncat(localname,".mcm",10);

if( ! (file_exists(localname ) ) )   // -a $localname
{
   printf("%s does not exist. \n",localname);
   printf("Change to your target directory.\n");
   exit(-1);
}
else
{
   // Get Customer name
   printf("Enter customer name followed by ENTER: \n");
   gets(customer);
}

   // Get description
   printf("Enter brief description followed by ENTER: \n");
   gets(description);

   // Change information in text file header 
  // sed s/xxxxx/"$basename"/ /users/bac/library/templates/common/header.txt|sed s/uuu/"$USER"/|sed s/zzzzz/"$customer"/|sed s/ddddd/"$description"/>proto.txt
   protofile=fopen("proto.txt","w");

   monthnum=get_month_number( monthstr);

   fprintf(protofile,
"======================================================================\n");
   fprintf(protofile,"P/N           %s\n",basename);
   fprintf(protofile,"Date          %02d-%s-%c%c\n",monthnum,daystr,yearstr[2],
	                                                    yearstr[3]);
   fprintf(protofile,"Customer      %s\n",customer); //zzzzzz
   fprintf(protofile,"Enduser       %s\n","wwwww"); // wwwww
   fprintf(protofile,"Description   %s\n",description);  // ddddd
   fprintf(protofile,"Designer      %s\n",USER); // uuu
   fprintf(protofile,
"======================================================================\n");

   fclose(protofile);

   // Get layer count
   llc=0;
   while ( llc != 3 && llc != 5 && llc != 7 )
   {
      printf("Enter 3 for 3-layer, 5 for 5-layer or 7 for 7-layer: \n");
      gets(llcstr);
	  llc=atoi(llcstr);
   }
   // Handle 2 versions for 5-layer
   if ( llc == 5 )
   {
	  strncpy(thruvias,"",4);
      strncpy(mors,"",10);
      while( (strcmp(mors,"m")!=0 ) && (strcmp(mors,"s")!=0 ))  //$mors = s ]]
	  {
        printf("5-layer: Enter m for microstrip or s for stripline: \n");
        gets( mors);
	  }
      if( strcmp(mors,"m") == 0 ) //  "$mors" = m 
      {
         strncpy(lcounttext,"5-layer microstrip",40);

         strncpy(thruvias,"y",5);
		 strncpy(blindvias,"",4);
         while( ( strcmp(blindvias,"y") != 0 ) && (strcmp(blindvias,"n")!=0)) 
		 {
            printf( "Will you be using blind vias? (y/n) \n");
            gets( blindvias);
		 }
	  }
      else
	  {
         strncpy(lcounttext,"5-layer stripline",40);

         while( (strcmp(thruvias,"y")!=0) && (strcmp(thruvias,"n")!=0 )) 
		 {
            printf( "Will you be using through vias? (y/n) \n");
            gets(thruvias);
		 }
         if (strcmp(thruvias,"y" )==0)
         {
			strncpy(blindvias,"",4);

            while( (strcmp(blindvias,"y")!=0) && (strcmp(blindvias,"n")!=0))
			{
               printf("will you also be using blind vias? (y/n) \n");
               gets( blindvias);
			}
		 }
      }
   }
   else  // 3-layer or 7-layer case
   {
      if( llc==3) 
      {
         strncpy(lcounttext,"3-layer",30);
         strncpy(thruvias,"y",5);
		 strncpy(blindvias,"",4);
         while( (strcmp(blindvias,"y")!=0) && ( strcmp(blindvias,"n") != 0 ))
		 {
            printf("Will you be using blind vias? (y/n) \n");
            gets(blindvias);
		 }
      }
      else
	  {
         strncpy(lcounttext,"7-layer",30);

		 strncpy(thruvias,"",4);
         while( (strcmp(thruvias,"y")!=0) && (strcmp(thruvias,"n")!=0) )
		 {
            printf( "Will you be using through vias? (y/n) \n");
            gets(thruvias);
		 }
         if( strcmp(thruvias,"y")==0 ) 
         {
			 strncpy(blindvias,"",4);
            while( (strcmp(blindvias,"y")!=0) && (strcmp(blindvias,"n")!=0))
			{
               printf( "will you also be using blind vias? (y/n) \n");
               gets(blindvias);
			}
		 }
      }
   }

   // Determine via type combination from inputs
   if( strcmp(thruvias,"y")== 0 )     //  "$thruvias" = "y" 
   {
      if( strcmp(blindvias,"y")==0 ) 
      {
         strncpy(viatype,"BT",4);
	  }
      else
	  {
         strncpy(viatype,"TO",4);
      }
   }
   else
   {
      strncpy(viatype,"BBB",6);

   }
   if (strcmp(viatype,"BT")== 0 )
   {
     strncpy(viadescrip," Blind-Through",40);
   }
   if (strcmp(viatype,"TO")==0)
   {
      strncpy(viadescrip," Through-only",40);
   }
   if (strcmp(viatype,"BBB")==0)
   {
      strncpy(viadescrip," Blind-Buried-Blind",50);
   }

   // create prototype text files 
   cp_file( "proto.txt", "psummary.txt");

   sumfile=fopen("psummary.txt","a");

   fprintf(sumfile, "Stackup:\n");        //>>psummary.txt
   fprintf(sumfile, "%s%s\n", lcounttext,viadescrip); // >>psummary.txt

   fclose(sumfile);

	cp_file("proto.txt","pHistory.txt");

	histfile=fopen("pHistory.txt","a");

fprintf(histfile,"DATE      REVISION  ECO   ACTION \n");
fprintf(histfile,"----------------------------------------------------------------------\n");
fprintf(histfile,"MM/DD/YY  0         n/a   Original design completed\n");
fprintf(histfile,"MM/DD/YY  0         n/a   Sent design to customer for approval\n");
fprintf(histfile,"MM/DD/YY  0         n/a   Sent design to customer for approval\n");
fprintf(histfile,"MM/DD/YY  0         n/a   Customer approval received\n");

   //cat proto.txt /users/bac/library/History.txt>pHistory.txt
   cp_file("proto.txt","pcd.txt");

   pcdfile=fopen("pcd.txt","a");

   fprintf(pcdfile,"\n");
   fprintf(pcdfile,"Critical Dimensions\n");
   fprintf(pcdfile,"\n");
   fclose(histfile);
   fclose(pcdfile);

  // cat proto.txt /users/bac/library/cd.txt>pcd.txt
   cp_file( "proto.txt", "players.txt");
   rm_file("temp1"); 
   rm_file("temp2"); 
   rm_file( "proto.txt");


}

int main( int argc, char **argv)
{

	if (argc != 1)
	{
		printf("update does not take any arguments \n");
		printf("Usage: update_call \n");
		exit(-1);
	}
	else
	{
	update_call();
	}

}  // end main

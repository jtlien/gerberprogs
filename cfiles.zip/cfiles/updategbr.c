
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// Rev 2
// Title: updategbr 
// written by Ted Ammann 7/25/96 

// calling Syntax
//     updategbr -v file1=crossreffile  infile > outfile
// program updates gerber files after aperture file has been modified
//         replaces old D-code with new D-code

// Revision History
//    Rev 1  released on 7/25/96 
//    Rev 2  7/27/96   tsa  // modify to handle if new d-code is selected without G54




struct codestuff
{
 char oldcode[40];
 char newcode[40];
} newcodes[1000];

int newcode_count;

//
//  Look to see if the oldcode is already there, if not add, if so update
//
void add_to_codes( char *oldcode, char *newcode)
{
int ii;
int code_found;

 code_found = FALSE;

 ii = 0;
 while( ( ii < newcode_count) && (code_found == FALSE) && ( ii < 1000))
	{
	 if (strcmp( newcodes[ii].oldcode,oldcode) == 0 )
	 {
		 strncpy(newcodes[ii].newcode,newcode,40);
		 code_found=TRUE;
	 }

   ii += 1;
 }

 if (code_found == FALSE)
	{
	 strncpy(newcodes[newcode_count].newcode,newcode,40);
	 strncpy(newcodes[newcode_count].oldcode,oldcode,40);
	// printf("Adding to newcodes at %d - %s \n",newcode_count, oldcode );
	 if (newcode_count < 1000 )
	 {
		 newcode_count += 1;
	 }
	}

} // end add_to_codes


//
//  Look up the oldcode in the newcode table, return newcode
//
void get_from_codes( char *oldcode, char *newcode)
{
int ii;
int code_found;

 code_found = FALSE;

 ii = 0;
 while( ( ii < newcode_count) && (code_found == FALSE) && ( ii < 1000))
	{
	 if (strcmp( newcodes[ii].oldcode,oldcode) == 0 )
	 {
		 strncpy(newcode,newcodes[ii].newcode,40);
		 code_found=TRUE;
	 }

   ii += 1;
 }

 if (code_found == FALSE)
	{
	 
	 printf("Error:  Code not found in table %s\n",oldcode);
     strncpy(newcode,"",4);
	}

} // end get_from_codes



// update a gerber file with new apertures

int updategbr_call_out( char *infile1, char *infile2, char *outfile)
{
int endoffile;
int nf;
FILE *file1;
FILE *outfile1;
char thisline[300];
char foo[10][200];
char locate[300];
char tempstr[200];
char newcode[300];

    // file1 is a crossref file 
    // First line is header so remove

	newcode_count = 0;

    file1  = fopen(infile1, "r");

      if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",infile1);
	   exit(-1);
	  }
	  
	endoffile=getline(file1,thisline);

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

	while( endoffile == FALSE)
	{
    // read in new d-codes into array using old d-code as subscript
    // $1 is OLD dcode //2 is NEW dcode 
    //       D10             D255
    
	add_to_codes(str_array[0],str_array[1]); // newcodes[$1] = $2

    endoffile=getline(file1,thisline);
 	nf=split_line(thisline);
    }

	fclose(file1);


//****************** START of MAIN ******************************

    file1  = fopen(infile2, "r");

      if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",infile2);
	   exit(-1);
	  }

      outfile1  = fopen(outfile, "w");

      if (outfile1 == NULL)
	  {
	   printf("Error: Unable to open output file = %s \n",outfile);
	   exit(-1);
	  }

	// read argv[2] file

    endoffile=getline(file1,thisline);
 	nf=split_line(thisline);

	while(endoffile == FALSE)
	{
      //replace OLD dcode with NEW dcode
      // G54 is gerber command for selecting new apt
      // splitting at "D" places OLD dcode in foo[2]
      //REV 2 adds check for first char of $1 being a 'D' or 'd'
      if( (strstr(thisline,"G54") != NULL) || (str_array[0][0] == 'D')|| (str_array[0][0]=='d'))
		
	  {
        split(thisline, foo[0],foo[1],"D");
	    awk_substr(foo[1],1, (strlen(foo[1]) -1 ),locate);   // get rid of '*'
        //REV 2 adds if below to insure only apertures get modified

	    if( atoi(locate) >= 10 )
		{                          // assumes apertures  start at 10
	      strncpy(tempstr,"D",5);
		  strcat(tempstr,locate);
		  strncpy(locate,tempstr,40);
		  get_from_codes( locate,newcode);
		// strcat(tempstr,= ("D" locate)    // d was renmoved by 'split' above 
            fprintf(outfile1,"G54%s*\n", newcode);
		}
   	   else 
	   {                     //prints out any line that has D-code D0 thru D09
	    fprintf(outfile1,"%s",thisline);
       }
	  }
     else
	 {                        //prints out lines that do not contain a D-code
	  if (strstr("\n",thisline) != NULL)   // has a newline
	  {
	    fprintf(outfile1,"%s",thisline); 
      }
	  else
	  {
		fprintf(outfile1,"%s\n",thisline);
	  }
	 
     }

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
	}
	fclose(file1);
	fclose(outfile1);

	return(0);

} // updategbr_call_out

// update a gerber file with new apertures

int updategbr_call( char *infile1, char *infile2)
{
int endoffile;
int nf;
FILE *file1;
char thisline[300];
char foo[10][200];
char locate[300];
char tempstr[200];
char newcode[300];

    // file1 is a crossref file 
    // First line is header so remove

	newcode_count = 0;

    file1  = fopen(infile1, "r");

      if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",infile1);
	   exit(-1);
	  }

    endoffile=getline(file1,thisline);  // file header

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

	while( endoffile == FALSE)
	{
    // read in new d-codes into array using old d-code as subscript
    // $1 is OLD dcode //2 is NEW dcode 
    //       D10             D255
    
	add_to_codes(str_array[0],str_array[1]); // newcodes[$1] = $2

    endoffile=getline(file1,thisline);
 	nf=split_line(thisline);
    }

	fclose(file1);


//****************** START of MAIN ******************************

    file1  = fopen(infile2, "r");

      if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",infile2);
	   exit(-1);
	  }

	// read argv[2] file

    endoffile=getline(file1,thisline);
 	nf=split_line(thisline);

	while(endoffile == FALSE)
	{
      //replace OLD dcode with NEW dcode
      // G54 is gerber command for selecting new apt
      // splitting at "D" places OLD dcode in foo[2]
      //REV 2 adds check for first char of $1 being a 'D' or 'd'
      if( (strstr(thisline,"G54") != NULL) || (str_array[0][0] == 'D')|| (str_array[0][0]=='d'))
		
	  {
        split(thisline, foo[0],foo[1],"D");
	    awk_substr(foo[1],1, (strlen(foo[1]) -1 ),locate);   // get rid of '*'
        //REV 2 adds if below to insure only apertures get modified

	    if( atoi(locate) >= 10 )
		{                          // assumes apertures  start at 10
	      strncpy(tempstr,"D",5);
		  strcat(tempstr,locate);
		  strncpy(locate,tempstr,40);
		  get_from_codes( locate,newcode);
		// strcat(tempstr,= ("D" locate)    // d was renmoved by 'split' above 
            printf("G54%s*\n", newcode);
		}
   	   else 
	   {                     //prints out any line that has D-code D0 thru D09
	    printf("%s",thisline);
       }
	  }
     else
	 {                        //prints out lines that do not contain a D-code
	 // if (strstr("\n",thisline) != NULL)   // has a newline
	  //{
	    printf("%s",thisline); 
      //}
	  //else
	  //{
	//	  printf("%s\n",thisline);
	  //}
     }
	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
	}
	fclose(file1);

	return(0);

} // updategbr_call




int main(int argc, char **argv)
{
char usage_str[300];
char example_str[300];

  strncpy(usage_str,"usage:  updategbr crossref  infile >outfile",60);
  
  strncpy(example_str,"     ex:  updategbr  mergeaptref infile > outfile ",60);

  if(argc != 3)
  {
   printf("In updategbr, incorrect number of arguments\n");
   printf("%s \n  %s \n",usage_str,example_str);
   exit(-1);
  }
  else
  {
          updategbr_call(argv[1], argv[2]);
  }

}  // end main


  


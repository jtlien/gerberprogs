#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//
#include "fnv.h"


#define FNV1_32_INITV 2166136261

char *data_str;

int val;

struct hash_col_type
{
	char value[40];
	struct hash_col_type *next;
	char str[40];
} ;

struct hash_array_stuff
{
	char value[120];
	char str[120];
	int hit;
	struct hash_col_type* collist;
} hash_array[ 70000];

#include "fnvhash_32.c"

 int get_hash( char *instr )
{
int thisval;
Fnv32_t hashval;

 hashval = fnv_32_str(data_str, 2166136261);

 thisval = (hashval >>16) ^ (hashval & 0xffff);

 return(thisval);
}

void hash_init( )
{

	for (ii=0; ii < 65000; ii += 1)
	{
	  hash_array[ii].hit = 0;
	  hash_array[ii].str[0]=0;
	  hash_array[ii].value[0]=0;
	  hash_array[ii].collist=NULL;
	}
}

int find_in_hash( char *instr, char *outval)
{
int hshval;
struct hash_col_type *listptr;
int hashfound;

    hshval = get_hash( instr);
	if (strcmp( hash_array[hshval].str,instr) == 0)
	{
	  strncpy(outval,hash_array[hshval].value,120);
	  return(0);
	}
	else
	{
	  listptr = hash_array[hshval].collist;
	  hashfound = FALSE;
	  while(( listptr != NULL ) && ( hashfound == FALSE))
	  {
		  if (strcmp(listptr->str, instr) == 0 )
		  {
			  strncpy(outval,listptr->value,120);
			  hashfound = TRUE;
			  return(0);
		  }
		  else
		  {
			  listptr=listptr->next;
		  }
	  }
	  if (( listptr == NULL )&& ( hashfound == FALSE))
	  {
		  printf("Internal error \n");
		  return(-1);
	  }
	}
	  
}


int add_to_hash( char *instr, char *inval)
{
int hshval;
char resstr[120];
struct hash_col_type *listptr;
struct hash_col_type *tptr;

    hshval = get_hash( instr);
	if (hash_array[hshval].hit == 0)
	{
	  strncpy(hash_array[hshval].value,inval,120);
	  hash_array[hshval].hit = 1;
	  return(0);
	}
	else
	{
	  listptr = hash_array[hshval].collist;
	  while( listptr != NULL ) 
	  {
		 listptr = listptr->next; 
	  }
	  tptr = malloc( sizeof( struct hash_col_type ));
	  
	  strncpy(tptr->str,instr,120);
	  strncpy(tptr->value,inval,120);
	  tptr->next = NULL;

	  listptr = tptr;

	}
	  
}



int main( int argc, char **argv)
{


 val = get_hash("the quick brown fox");

}

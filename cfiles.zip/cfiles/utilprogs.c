#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include <time.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

#include "dirent.h"

#define WINDOWS 1
#define MAXSTRING 256

char str_array[120][120];
char scan_array[1000][256];
char cp_list[1000][256];
char grep_array[10000][256];
char time_array[20][300];
char dirsep[10];

char dayofweekstr[120];
char monthstr[120];
char daystr[120];
char timeofdaystr[120];
char yearstr[120];


char glines[40][40];


struct xytype{ 
	double x;
	double y;
	char rest[20];
} ;

struct xytype xyarray[100000];


struct alphastuff
{
	char gchar;
	char glines[40][40];
} alpha[44];

//
// windows version of time
//
char *gettime_str( )
{
long *epochtime;
char *timestr;
int ii;
int kk;
int ll;
char time_array[10][200];

 epochtime=malloc(sizeof(long));

 *epochtime=time(0); // since 1970


 timestr = ctime(epochtime);
 // printf("timestr = %s",timestr);

 kk=0;
 for(ii=0; ii < 5; ii += 1)
 {
	ll=0;
	while((timestr[kk] != ' ')&&(kk< (signed int) strlen(timestr)) )
	{
		time_array[ii][ll]=timestr[kk];
		ll+=1;
		kk+=1;
	}
	time_array[ii][ll]='\0';

	while((timestr[kk] == ' ')&&(kk<(signed int) strlen(timestr)) )
	{
	 kk+=1;
	}
 }

 strncpy(dayofweekstr,time_array[0],120);
 strncpy(monthstr,time_array[1],120);
 strncpy(daystr,time_array[2],120);
 strncpy(timeofdaystr,time_array[3],120);

 // get rid of troublesome eoln
 for (kk=0; kk < (signed int) strlen(time_array[4]); kk += 1)
	{
	 if (time_array[4][kk] == '\n')
	 {
		 time_array[4][kk] = '\0';
	 }
	}

 for (kk=0; kk < (signed int) strlen(timestr); kk += 1)
	{
	 if (timestr[kk] == '\n')
	 {
		 timestr[kk] = '\0';
	 }
	}
 strncpy(yearstr,time_array[4],120);

 return(timestr);

} // end gettime_str

void cv_toupper( char *instr, char *outstr)
{
int kk;

kk=0;

 while(( *instr != 0) && ( kk < 200))
 {
	 *outstr=toupper(*instr);
	 outstr++;
	 instr++;
	 kk+=1;
 }

 *outstr=0;
}

void get_date( char *outstr)
{

  gettime_str();
  strncpy(outstr,dayofweekstr,30);
  strncat(outstr," ",4);
  strncat(outstr,monthstr,30);
  strncat(outstr," ",4);
  strncat(outstr,daystr,30);
  strncat(outstr," ",4);
  strncat(outstr,timeofdaystr,30);
  strncat(outstr," CST ",30);       // kludge for now
  strncat(outstr,yearstr,30);

} // end get_data


int dir_exists( char *dirname)
{
DIR *dir;

	dir = opendir( dirname);
	if (dir == NULL)
	{
		return(0);
	}
	else
	{
		closedir( dir);
		return(1);
	}
}


void rm_file( char *filestr)
{

  unlink(filestr);

}

void get_whoami( char *outstr)
{
 char *tstr;

 if (WINDOWS)
 {
	tstr=getenv("LOTUSUSERNAME");
	if (tstr == NULL)
	{
     tstr = getenv("USERNAME");
	}
 }
 else
 {
  tstr = getenv("LOGNAME");
 }

 strncpy(outstr,tstr,40);

} // get_whoami

//
// get the current working directory
//
void getwd( char *wdbuff)
{
int wdlen;


  wdlen=GetCurrentDirectory(120,wdbuff);
}

int split_line_seps( char *tline, char *file_sep)
{
int ii;
char tstr[200];
char *token;

 ii = 0;

 strncpy( tstr, tline,200);

 token = strtok( tstr,file_sep);

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL,file_sep);

	}

 // for (jj=0; jj <ii ; jj += 1)
 //{
 //	 printf("str_array[%d] = %s \n",jj,str_array[jj]);
 //}

 return(ii);

} // end split_line_seps


//
// perform awk compatible awk_index, counts from 1 at the leftmost
//
int awk_index( char *instr, char *inchr)
{
int kk,ll,mm;
char tstr[120];

	if (strstr(instr, inchr) == NULL)    // not found at all in string, return 0
	{
		return(0);
	}
	else    // the inchr string is a substring
	{
		kk = 0;
		while( kk < (signed int) strlen( instr))
		{
          ll = 0;
		  mm = kk;
		  while( mm < (signed int) strlen( instr))
		  {
			tstr[ll] = instr[mm];
			mm += 1;
			ll += 1;
		  }
		  tstr[ll] = 0;
		  if (strstr( tstr,inchr) == NULL)  // no longer found as substring
		  {
			return(kk);
		  }
		 kk += 1;
		}
	}

  return(0);


} // awk compatible index

// perform awk compatible substr, except the 4th parameter is the
//   result string
//
void awk_substr( char *instr, int sbegin, int slength, char *resultstr)
{

char tstr[120];
int kk;
int ll;

     if ( sbegin > 0)
	 {
		 sbegin = sbegin-1;
	 }
     kk = sbegin;
     ll = 0;
	 while ( ( kk < (signed int) strlen(instr) && ( ll < slength)) )
	 {
		 tstr[ll] = instr[kk];
		 kk += 1;
		 ll  += 1;
	 }
	 tstr[ll]=0;

	 strncpy( resultstr,tstr,slength+2);

}   // awk substr

//
//   move one file to another, doesn't delete original
//
void move_one_file( char *infile, char *outfile)
{
char buf[1024];
FILE *f_from;
FILE *f_to;


    /* copy source file to target file, line by line. */

/* open the source and the target files. */
    f_from = fopen(infile, "r");
    if (!f_from) {
	fprintf(stderr, "Cannot open source file: %s",infile);
	perror("");
	exit(1);
    }
    f_to = fopen(outfile, "w+");
    if (!f_to) {
	fprintf(stderr, "Cannot open target file: %s ",outfile);
	perror("");
	exit(1);
    }

/* copy source file to target file, line by line. */

    while (fgets(buf, 512, f_from))
	{
	 if (fputs(buf, f_to) == EOF)
	 {  /* error writing data */
	    fprintf(stderr, "Error writing to target file: ");
	    perror("");
	    exit(1);
	 }
    }
   fclose(f_from);
   fclose(f_to);

}  // move_one_file

void mv_a_file( char *infile, char *outfile)
{
	move_one_file( infile,outfile);
}

//
//   Scan directory for regular files that match a particular extension
//
int scandir_matchext(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr)		// starting dir, could be an arbitrary label
{

	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	int ll;
	int kk;
	char fname_ext[MAXSTRING];
	int scan_file_count;


	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	_snprintf(szDir,MAXSTRING, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	scan_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE){
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return(-1);
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;

		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			_snprintf(newdir,MAXSTRING,"%s/%s",dir,fname);

    			scandir_matchext(newdir,recurse,matchstr);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/

			 // get the ext ( all chars after first dot )

			kk=0;
			ll=0;
			fname_ext[0]=0;
			while((fname[kk] != '.') && (kk < (signed int) (signed int) strlen(fname)) )
			{
				kk += 1;
			}
			if ( fname[kk] == '.')
			{
				fname_ext[ll]=fname[kk];
				kk += 1;
				ll += 1;
			}
			while( kk < (signed int) strlen(fname))
			{
				fname_ext[ll] = fname[kk];
				kk += 1;
				ll += 1;
			}
			fname_ext[ll] = 0;

			// printf("fname_ext = %s \n",fname_ext);

			if (strcmp(fname_ext,matchstr) == 0 )
			{
			// printf("fname = %s \n",fname);
			  if (scan_file_count < 1000 )
			  {
				 strncpy(scan_array[scan_file_count],fname,120);
				 scan_file_count += 1;
			  }
			  else
			  {
				  printf("Number of files in the directory exceeds 1000 \n");
			  }

			}

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return(scan_file_count);
}

//
//   Scan directory for regular files that match a particular extension
//        Returns count only, does not have side effect of changing scan_array

int scandir_matchext_count(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr)		// starting dir, could be an arbitrary label
{

	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	int ll;
	int kk;
	char fname_ext[MAXSTRING];
	int scan_file_count;


	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	_snprintf(szDir,MAXSTRING, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	scan_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE){
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return(-1);
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;

		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			_snprintf(newdir,MAXSTRING,"%s/%s",dir,fname);

    			scandir_matchext(newdir,recurse,matchstr);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/

			 // get the ext ( all chars after first dot )

			kk=0;
			ll=0;
			fname_ext[0]=0;
			while((fname[kk] != '.') && (kk < (signed int) (signed int) strlen(fname)) )
			{
				kk += 1;
			}
			if ( fname[kk] == '.')
			{
				fname_ext[ll]=fname[kk];
				kk += 1;
				ll += 1;
			}
			while( kk < (signed int) strlen(fname))
			{
				fname_ext[ll] = fname[kk];
				kk += 1;
				ll += 1;
			}
			fname_ext[ll] = 0;

			// printf("fname_ext = %s \n",fname_ext);

			if (strcmp(fname_ext,matchstr) == 0 )
			{
			// printf("fname = %s \n",fname);
			  if (scan_file_count < 10000 )
			  {

				 scan_file_count += 1;
			  }
			  else
			  {
				  printf("Number of files in the directory exceeds 10000 \n");
			  }

			}

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return(scan_file_count);
}

//
//   Scan directory for regular files that match a particular base
//
int scandir_matchbase(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr)		// starting dir, could be an arbitrary label
{

	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	int ll;
	int kk;
	char fname_base[MAXSTRING];
	int scan_file_count;


	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	_snprintf(szDir,MAXSTRING, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	scan_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE){
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return(-1);
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;

		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			_snprintf(newdir,MAXSTRING,"%s/%s",dir,fname);

    			scandir_matchbase(newdir,recurse,matchstr);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/

			 // get the base ( all chars before first dot )

			kk=0;
			ll=0;
			fname_base[0]=0;
			while((fname[kk] != '.') && (kk < (signed int) strlen(fname)) )
			{
				fname_base[kk]=fname[kk];
				kk += 1;
			}
		    fname_base[kk]=0;


			// printf("fname_base = %s \n",fname_base);

			if (strcmp(fname_base,matchstr) == 0 )
			{
			// printf("fname = %s \n",fname);
			  if (scan_file_count < 1000 )
			  {
				 strncpy(scan_array[scan_file_count],fname,120);
				 scan_file_count += 1;
			  }
			  else
			  {
				  printf("Number of files in the directory exceeds 1000 \n");
			  }

			}

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return(scan_file_count);
}

//
//   Scan directory for directories
//
int scandir_matchalldir(const char* dir,	// starting directory (absolute or relative)
		int recurse)		// 1 to recurse in subdirectory

{

	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	int scan_file_count;

	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	_snprintf(szDir,MAXSTRING, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	scan_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE){
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return(-1);
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;

		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse)
			{
    			// recurse scandir function in subdirectory
    			_snprintf(newdir,MAXSTRING,"%s/%s",dir,fname);

    			scandir_matchalldir(newdir,recurse);
           	}
            if (scan_file_count < 1000 )
			  {
				 strncpy(scan_array[scan_file_count],fname,120);
				 scan_file_count += 1;
			  }
			  else
			  {
				  printf("Number of directories in the directory exceeds 1000 \n");
			  }


		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/

			 // get the ext ( all chars after first dot )

			// printf("fname = %s \n",fname);
			 

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return(scan_file_count);
}


//
//   Scan directory for regular files
//
int scandir_matchall(const char* dir,	// starting directory (absolute or relative)
		int recurse)		// 1 to recurse in subdirectory

{

	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	int scan_file_count;

	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	_snprintf(szDir,MAXSTRING, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	scan_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE){
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return(-1);
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;

		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			_snprintf(newdir,MAXSTRING,"%s/%s",dir,fname);

    			scandir_matchall(newdir,recurse);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/

			 // get the ext ( all chars after first dot )

			// printf("fname = %s \n",fname);
			  if (scan_file_count < 1000 )
			  {
				 strncpy(scan_array[scan_file_count],fname,120);
				 scan_file_count += 1;
			  }
			  else
			  {
				  printf("Number of files in the directory exceeds 1000 \n");
			  }

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return(scan_file_count);
}


void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk;

  ii=0;
  kk = 0;

  outstr1[0]='\0';
  outstr2[0]='\0';

 while((instr[ii] != srchstr[0]) && ( ii < (signed int) strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = '\0';

  if (instr[ii] == srchstr[0])
  {
	  ii += 1;
  }
  else
  {
	  return;
  }

  outstr2[0] = '\0';
  kk = 0;
  while ( (instr[ii] != '\0' ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= '\0';


}  // end split

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = (signed int) strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 // get rid of pesky, stupid tabs

 for (kk=0; kk < (signed int) strlen(tstr); kk +=1 )
 {
	 if (tstr[kk] == '\t')
	 {
		 tstr[kk] = ' ';
	 }
 }

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line

//
//  Take a file name string with one extension and
//     replace it with another   extension at most 30 chars
//
void subexten( char* instr, char *outstr, char *newext)
{
char a[10][120];
char tempstr[200];

  split(instr,a[0],a[1],".");
  strncpy(tempstr,a[0],120);
  strncat(tempstr,newext,30);
  strncpy(outstr,tempstr,120);

}  // end subexten

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;
int kk;

 err = fgets(tline,120,infile);

 if (strstr(tline,"\t") != NULL)
 {
	                     // a nasty tab char, why in the hell was this ever invented?

	 kk=0;
	 while(kk < (signed int) strlen(tline) )
	 {
		 if (tline[kk]== '\t')
		 {
			 tline[kk] = ' ';
		 }
		kk +=1;
	 }

 }

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	kk=0;
	while( (tline[kk] != EOF ) && (kk < 120))
	{
		 kk += 1;
	}
	tline[kk] = '\0';

	return (1);
 }
} // end getline//
//
// get an input line, preserve tabs
//
int getlinet( FILE *infile, char *tline)  // get a line of input
{
char *err;
int kk;

 err = fgets(tline,120,infile);



 if (err != NULL)
 {
   return(0);
 }
 else
 {
	kk=0;
	while( (tline[kk] != EOF ) && (kk < 120))
	{
		 kk += 1;
	}
	tline[kk] = '\0';

	return (1);
 }
} // end getlinet
//
// get an input line
//
int getlined( FILE *infile, char *tline, int dbg)  // get a line of input
{
int kk;
char newch;

 newch=' ';
 kk=0;
 while((kk < 120)  && ( newch != '\n') && ( newch != EOF))
 {
   newch=fgetc(infile);
   tline[kk]= newch;
   kk += 1;
 }
 tline[kk]= '\0';

 if (newch == EOF)
 {
	 return(1);
 }

// err = fgets(tline,120,infile);

 //if (dbg)
//	{
//	 printf("err in getline = %s \n",err);

//	 for (kk=0; kk < 120; kk += 1)
//	 {
//		 printf("infile %d = %d %c\n",kk,tline[kk],tline[kk]);
//	 }
// }

 if (strstr(tline,"\t") != NULL)
 {
	                     // a nasty tab char, why in the hell was this ever invented?

	 kk=0;
	 while(kk < (signed int) strlen(tline) )
	 {
		 if (tline[kk]== '\t')
		 {
			 tline[kk] = ' ';
		 }
		kk +=1;
	 }

 }

 return(0);

/*
 if (err != NULL)
 {
   return(0);
 }
 else
 {
	kk=0;
	while( (tline[kk] != EOF ) && (kk < 120))
	{
		 kk += 1;
	}
	tline[kk] = '\0';

	return (1);
 }              */

} // end getlined

//
//  Move all files with a given extention to copies with another extention
//
void mvall( char *fromext, char *toext )
{
int ii;
char frmfilestr[120];
char toofilestr[120];
char dirstr[10];
int tscan_file_count;

  strncpy(dirstr,".",4);

  tscan_file_count = scandir_matchext( dirstr,0,fromext);

  ii =0;

  while(ii < tscan_file_count)
  {
	  strncpy(frmfilestr,scan_array[ii],120);
	  subexten(frmfilestr,toofilestr,toext);

      move_one_file( frmfilestr, toofilestr);
      ii += 1;

  }

}  // mvall


//
// find occurances of a string in a file
//
//
int sgrep( char *infilestr, char *searchstr,int arraysize)
{
int ii;
FILE *infile;
int endfile;
char thisline[300];

   infile=fopen(infilestr,"r");
   if (infile == NULL)
   {
	   printf("In sgrep, unable to open the input file =%s\n",infilestr);
	   exit(-1);
   }

  ii=0;
  endfile=getline(infile,thisline);
  while( endfile==FALSE)
  {
     // printf("line in = %s search val = [%s] \n",thisline,searchstr);

	  if (strstr(thisline,searchstr) != NULL)
	  {
		strncpy(grep_array[ii],thisline,120);
		 // printf("Found in sgrep , line = %s \n",thisline);
		if (ii < arraysize)
		{
        ii+=1;
		}
	  }
    endfile=getline(infile,thisline);
  }
  fclose(infile);

  if (ii > 0 )  // return code like goofy grep
  {
    return(0);
  }
  else
  {
	return(1);
  }

}

//
// find occurances of a string in a file, returning count of lines
//    ignore case,
//
int grep_ignore_count( char *infilestr, char *searchstr,int *linecount)
{
int ii;
FILE *infile;
int endfile;
char thisline[300];
char thisline_upper[300];
char searchstr_upper[300];
int lines;

   cv_toupper(searchstr, searchstr_upper);
   infile=fopen(infilestr,"r");
   if (infile == NULL)
   {
	   printf("In grep_ignore_count, unable to open the input file =%s\n",infilestr);
	   exit(-1);
   }

  ii=0;
  lines=0;
  endfile=getline(infile,thisline);
  cv_toupper(thisline, thisline_upper);

  while( endfile==FALSE)
  {
      // printf("line in = %s search val =%s: \n",thisline,searchstr);

	  if (strstr(thisline_upper,searchstr_upper) != NULL)
	  {
		strncpy(grep_array[ii],thisline,120);
		lines += 1;
		if ( ii < 10000 )
		{
         ii += 1;
		}

	  }
    endfile=getline(infile,thisline);
	cv_toupper(thisline,thisline_upper);
  }
  fclose(infile);

  *linecount =lines;

  if (ii > 0 )  // return code like goofy grep
  {
    return(0);
  }
  else
  {
	return(1);
  }

}
//
// find occurances of a string in a file, returning count of lines
//    count only, do not put lines into grep_array
//
int grep_count( char *infilestr, char *searchstr,int *linecount)
{
int ii;
FILE *infile;
int endfile;
char thisline[300];
int lines;

   infile=fopen(infilestr,"r");
   if (infile == NULL)
   {
	   printf("In grep_count, unable to open the input file =%s\n",infilestr);
	   exit(-1);
   }

  ii=0;
  lines=0;
  endfile=getline(infile,thisline);

  while( endfile==FALSE)
  {
      // printf("line in = %s search val =%s: \n",thisline,searchstr);

	  if (strstr(thisline,searchstr) != NULL)
	  {

		lines += 1;
	  }
    endfile=getline(infile,thisline);
  }
  fclose(infile);

  *linecount =lines;

  ii = lines;
  if (ii > 0 )  // return code like goofy grep
  {
    return(0);
  }
  else
  {
	return(1);
  }

}
//
// find occurances of a string in a file, returning count of lines
//    count only, do put lines into grep_array
//
int grep_counter( char *infilestr, char *searchstr,int *linecount)
{
int ii;
FILE *infile;
int endfile;
char thisline[300];
int lines;

   infile=fopen(infilestr,"r");
   if (infile == NULL)
   {
	   printf("In grep_counter, unable to open the input file =%s\n",infilestr);
	   exit(-1);
   }

  ii=0;
  lines=0;
  endfile=getline(infile,thisline);

  while( endfile==FALSE)
  {
      // printf("line in = %s search val =%s: \n",thisline,searchstr);

	  if (strstr(thisline,searchstr) != NULL)
	  {

		  strncpy(grep_array[lines], thisline,120);

		lines += 1;
	  }
    endfile=getline(infile,thisline);
  }
  fclose(infile);

  *linecount =lines;

  ii = lines;
  if (ii > 0 )  // return code like goofy grep
  {
    return(0);
  }
  else
  {
	return(1);
  }

}
//
// find occurances of a either of two strings  in a file, returning count of lines
//    count only,  put lines into grep_array
//
int grep_count2( char *infilestr, char *searchstr1, char *searchstr2,int *linecount)
{
int ii;
FILE *infile;
int endfile;
char thisline[300];
int lines;

   infile=fopen(infilestr,"r");
   if (infile == NULL)
   {
	   printf("In grep_count, unable to open the input file =%s\n",infilestr);
	   exit(-1);
   }

  ii=0;
  lines=0;
  endfile=getline(infile,thisline);

  while( endfile==FALSE)
  {
      // printf("line in = %s search val =%s: \n",thisline,searchstr);

	  if ((strstr(thisline,searchstr1) != NULL) || ( strstr(thisline,searchstr2) != NULL) )
	  {

		strncpy(grep_array[ii],thisline,200);

		lines += 1;
		if (ii < 10000)
		{
			ii += 1;
		}
	  }
    endfile=getline(infile,thisline);

  }
  fclose(infile);

  *linecount =lines;

  if (ii > 0 )  // return code like goofy grep
  {
    return(0);
  }
  else
  {
	return(1);
  }

}
//
//  sed fakeout  replaces first occurance of fromstr in a line from
//        infile with tostr and writes to outfile
//
void ssed( char *infilestr,char *fromstr, char *tostr, char *outfilestr)
{
FILE *infile;
FILE *outfile;
int endfile;
char thisline[300];
char outstr[1000];
char endstr[300];
char basestr[300];
char *endptr;


 infile=fopen(infilestr,"r");
 if (infile==NULL)
	{
	 printf("In ssed, unable to open the input file = %s \n",infilestr);
	 return;
	}

 outfile=fopen(outfilestr,"w");
  if (outfile==NULL)
	{
	 printf("In ssed, unable to open the output file = %s \n",outfilestr);
	 return;
	}

 // printf("reading file \n");
 endfile=getline(infile,thisline);

 while(endfile==FALSE)
	{
	 if (strstr(thisline,fromstr) != NULL)
	 {

		 strncpy(basestr,thisline,300);
		 endptr =strstr(basestr,fromstr);

		 *endptr='\0';
		 endptr=endptr+(signed int) strlen(fromstr);

		 strncpy(endstr,endptr,120);

		 _snprintf(outstr,1000,"%s%s%s",basestr,tostr,endstr);
		 fprintf(outfile,"%s",outstr);
	 }
	 else
	 {
		 fprintf(outfile,"%s",thisline);
	 }
	endfile=getline(infile,thisline);
 }
 fclose(infile);
 fclose(outfile);


}

// ssed
//
//  Check if a file exists
//
int file_exists( char *infile)
{
int debug;
int retcode;

    debug=0;
	retcode = _access( infile, 0 );
    if (retcode == 0 )
	{
		return(TRUE);
	}
	else
	{
		return(FALSE);
	}
 if (debug) {printf("Testing if %s exists \n",infile); }


} // file_exists

int is_ordinary( char *infilestr)
{
	if ( dir_exists(infilestr) )
	{
		return(0);
	}
	else
	{
		return(1);
	}
}

//
// rm all the files with a given extension from a subdirectory
//

void rm_all_ext( char *subdir, char *extstr)
{
char rmfilestr[200];
int files_found;
int ii;


 strncpy(rmfilestr,subdir,120);

 files_found = scandir_matchext( subdir,0,extstr);

 ii =0;
 while(ii < files_found)
 {

	 strncpy(rmfilestr,subdir,120);
     strncat(rmfilestr,dirsep,10);
	 strncat(rmfilestr,scan_array[ii],60);

    // printf("remove = %s \n",rmfilestr);
	 unlink(rmfilestr);
      ii += 1;
 }

 // unlink(rmfilestr);
}


//
// rm all the files with a given extension from a subdirectory
//

void rm_all_keep_ext2( char *subdir, char *extstr1, char *extstr2)
{
char rmfilestr[200];
int files_found;
int ii;
char dotstr[100];
char basestr[300];
char extstr[300];

 strncpy(rmfilestr,subdir,120);

 files_found = scandir_matchall( subdir,0);

 ii =0;
 while(ii < files_found)
 {

   strncpy(dotstr,".",10);
   split(scan_array[ii],basestr,extstr,".");
   strncat(dotstr,extstr,80);

   if (( strcmp(dotstr,extstr1) != 0 ) && ( strcmp(dotstr,extstr2) != 0 ))
     {
	 strncpy(rmfilestr,subdir,120);
         strncat(rmfilestr,dirsep,10);
	 strncat(rmfilestr,scan_array[ii],60);

    // printf("remove = %s \n",rmfilestr);
     }
      unlink(rmfilestr);
      ii += 1;
 }

 // unlink(rmfilestr);
}

//
// rm all the files with a given base from a subdirectory
//

void rm_all_base( char *subdir, char *basestr)
{
char rmfilestr[200];
int files_found;
int ii;


 strncpy(rmfilestr,subdir,120);

 files_found = scandir_matchbase( subdir,0,basestr);

 ii =0;
 while(ii < files_found)
 {

	 strncpy(rmfilestr,subdir,120);
     strncat(rmfilestr,dirsep,10);
	 strncat(rmfilestr,scan_array[ii],60);

    // printf("remove = %s \n",rmfilestr);
	 unlink(rmfilestr);
      ii += 1;
 }

 // unlink(rmfilestr);
}


//
//  copy one file to another
//
void copy_one_file( char *infile, char *outfile)
{
char buf[1024];
FILE *f_from;
FILE *f_to;
int debug;

   debug=0;
   if (debug) { printf("copy file %s to %s \n",infile,outfile); }


    /* copy source file to target file, line by line. */

/* open the source and the target files. */
    f_from = fopen(infile, "r");
    if (!f_from) {
	fprintf(stderr, "Cannot open source file: %s\n",infile);
	perror("");
	exit(1);
    }

    f_to = fopen(outfile, "w+");
    if (!f_to) {
	fprintf(stderr, "Cannot open target file: %s \n",outfile);
	perror("");
	exit(1);
    }

/* copy source file to target file, line by line. */

    while (fgets(buf, 512, f_from))
	{
	 if (fputs(buf, f_to) == EOF)
	 {  /* error writing data */
	    fprintf(stderr, "Error writing to target file: ");
	    perror("");
	    exit(1);
	 }
    }
   fclose(f_from);
   fclose(f_to);

}  // copy_one_file

void cp_file( char *infile, char *outfile)
{
	copy_one_file(infile,outfile);
}

// print a file to standard out

void print_file( char *infile, char *outfile)
{
FILE *file1;
int endoffile;
char thisline[300];

    file1= fopen(infile,"r");
	if (file1==NULL)
	{
		printf("In print_file, unable to open the input file for read = %s \n", infile);
		exit(-1);
	}

	endoffile=getline(file1,thisline);

	while(endoffile==FALSE)
	{
		printf("%s",thisline);
		endoffile=getline(file1,thisline);
	}

	fclose(file1);

}
//
// cp all the files in a given directory from a subdirectory to another directory
//

void cp_files_all( char *frsubdir, char *tosubdir)
{
char frfilestr[200];
char tofilestr[200];
int files_found;
int ii;


 // strncpy(frfilestr,subdir,120);

 files_found = scandir_matchall( frsubdir,0);

 ii =0;
 while(ii < files_found)
 {

	 strncpy(frfilestr,frsubdir,120);
     strncat(frfilestr,dirsep,10);
	 strncat(frfilestr,scan_array[ii],60);

     strncpy(tofilestr,tosubdir,120);
     strncat(tofilestr,dirsep,10);
	 strncat(tofilestr,scan_array[ii],60);

    // printf("remove = %s \n",rmfilestr);
	 copy_one_file(frfilestr,tofilestr);
      ii += 1;
 }


} // cp_files_all

//
// Remove MO2 from a gerber file
//

int rmmo2_call_out( char *file1str, char *file2str)
{
FILE *file1;
FILE *file2;
int  endoffile;
char thisline[300];

    file1  = fopen(file1str, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",file1str);
	  exit(-1);
	}

    file2 = fopen(file2str, "w");

    if (file2 == NULL)
	{
	  printf("Error: Unable to open output file = %s \n",file1str);
	  exit(-1);
	}

  //if a line does not have an M or if line contains
  // a "%" then print the line
  // this prevents any line containing a M code from
  // being printed.

  endoffile=getline(file1,thisline);

  while( endoffile == FALSE)
  {
    if(( strstr(thisline,"M") == NULL) || (strstr(thisline,"%") != NULL) )
	{
      fprintf(file2,"%s",thisline);
	}
   endoffile = getline(file1,thisline);
  }
  fclose(file1);
  fclose(file2);
  return(0);
}


//
// Remove MO2 from a gerber file and delete the apertures in front
//

void rmmo2_truncate_call_out( char *file1str, char *file2str)
{
FILE *file1;
FILE *file2;
int  endoffile;
char thisline[300];
int endofapts_found;

    file1  = fopen(file1str, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",file1str);
	  exit(-1);
	}

    file2 = fopen(file2str, "w");

    if (file2 == NULL)
	{
	  printf("Error: Unable to open output file = %s \n",file1str);
	  exit(-1);
	}

  endofapts_found = FALSE;

  //if a line does not have an M or if line contains
  // a "%" then print the line
  // this prevents any line containing a M code from
  // being printed.

  endoffile=getline(file1,thisline);

  while(( endofapts_found == FALSE) && ( endoffile==FALSE))
  {
    if( strstr(thisline,"G04 End of Panel Ap") != NULL) 
	{
      endofapts_found=TRUE;
	}
   endoffile = getline(file1,thisline);
  }

  while( endoffile == FALSE)
  {
    if(( strstr(thisline,"M02") == NULL) || (strstr(thisline,"%") != NULL) )
	{
      fprintf(file2,"%s",thisline);
	}
   endoffile = getline(file1,thisline);
  }
  fclose(file1);
  fclose(file2);
  
}


//
// Fix the FLAX (gerber 274x format statment), and Remove MO2 from a gerber file
//

int rmmo2_fix_call_out( char *file1str, char *file2str)
{
FILE *file1;
FILE *file2;
int  endoffile;
char thisline[300];
char quotchar;

    quotchar='%';

    file1  = fopen(file1str, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",file1str);
	  exit(-1);
	}

    file2 = fopen(file2str, "w");

    if (file2 == NULL)
	{
	  printf("Error: Unable to open output file = %s \n",file1str);
	  exit(-1);
	}

  //if a line does not have an M or if line contains
  // a "%" then print the line
  // this prevents any line containing a M code from
  // being printed.

  endoffile=getline(file1,thisline);

  while( endoffile == FALSE)
  {

	if (strstr(thisline,"FSLAX") != NULL) // replace FSLAX
	{
       fprintf(file2,"%cFSLAX45Y45*%c\n",quotchar,quotchar);
	}
    else            // Is the MM02 line
	{
      if(( strstr(thisline,"M02") == NULL) || (strstr(thisline,"%") != NULL) )
	  {
      fprintf(file2,"%s",thisline);
	  }
	}
   endoffile = getline(file1,thisline);
  }
  fclose(file1);
  fclose(file2);
  return(0);
}

//
// cp one file to a sub directory file line by line
//
void cp_file_tosub(  char *infile1_str, char *outsubdir, char *outfile_str)
{
FILE *infile1;
FILE *outfile;
int endfile;
char thislinein[200];
char fnameoutstr[200];
char dirsep[4];

 if (WINDOWS == TRUE)
	{
	 strncpy(dirsep,"\\",2);
 }
 else
 {
	 strncpy(dirsep,"/",2);
 }
 strncpy( fnameoutstr,outsubdir,40);
 strncat( fnameoutstr,dirsep,5);
 strncat( fnameoutstr,outfile_str,120);


 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in cp_file, unable to open input file = %s \n",
		  infile1_str);
	 exit(-1);
 }


 outfile = fopen(fnameoutstr,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  fnameoutstr);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 fclose( outfile);

}  // end cp_file_tosub

//
// cp one file from a sub directory file line by line
//
void cp_file_from_to( char *insubdir, char *infile1_str, char *outsubdir, char *outfile_str)
{
FILE *infile1;
FILE *outfile;
int endfile;
char thislinein[200];
char fnameinstr[300];
char fnameoutstr[300];
char dirsep[4];

 if (WINDOWS == TRUE)
	{
	 strncpy(dirsep,"\\",4);
 }
 else
 {
	 strncpy(dirsep,"/",4);
 }
 strncpy( fnameoutstr,outsubdir,120);
 strncat( fnameoutstr,dirsep,5);
 strncat( fnameoutstr,outfile_str,120);

 strncpy( fnameinstr,insubdir,120);
 strncat( fnameinstr,dirsep,5);
 strncat( fnameinstr,infile1_str,120);

 infile1 = fopen(fnameinstr,"r");

 if (infile1 == NULL)
	{
	 printf("Error in cp_file_from_to, unable to open input file = %s \n",
		  fnameinstr);
	 exit(-1);
 }


 outfile = fopen(fnameoutstr,"w");

 if (outfile == NULL)
	{
	 printf("Error in cp_file_from_to, unable to open output file = %s \n",
		  fnameoutstr);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 fclose( outfile);

}  // end cp_file_from_to


void cv_tolower( char *instr, char *outstr)
{
int kk;

kk=0;

 while(( *instr != 0) && ( kk < 200))
 {
	 *outstr=tolower(*instr);
	 outstr++;
	 instr++;
	 kk+=1;
 }

 *outstr=0;
}

void change_dir( char *dirname)
{

// printf("doing the cd to %s \n",tstr);
  //execl("cd",tstr);

  if (WINDOWS)
  {
  SetCurrentDirectory(dirname);
  }
  else
  {
  //  execl("cd",dirname);
  }
}

// count the number of lines in a file
//

int count_lines( char *infilestr)
{
int lncnt;
FILE *infile;
char tstr[300];
int endfile;

  infile=fopen(infilestr,"r");
  lncnt=0;
  endfile=getline(infile,tstr);
  while(endfile==FALSE)
  {
    lncnt+=1;
    endfile=getline(infile,tstr);
  }

  fclose(infile);

  return(lncnt);
}


//
// cat together two files and put into a third
//
void cat_files( char *infile1_str, char *infile2_str, char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *outfile;

char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
   	 // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
	 // exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	      exit(-1);
 }


 if (infile1 != NULL)
 {
  while( !( getline(infile1,thislinein)) )
  {
	 fprintf(outfile,"%s",thislinein);
  }
  fclose( infile1);
 }


 if (infile2 != NULL)
 {
  while( !( getline(infile2,thislinein)) )
  {
	 fprintf(outfile,"%s",thislinein);
  }
  fclose( infile2);
 }

 fclose( outfile);

}  // end cat_files

//
// cat together three files and put into a fourth
//
void cat_3files( char *infile1_str, char *infile2_str, char *infile3_str,char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat  3 files, unable to open input file 1 = %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 3 files, unable to open input file 2 = %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 3 files, unable to open input file 3 = %s \n",
		  infile3_str);
	 // exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
  endfile = getline( infile1, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
  }
  fclose( infile1);
 }


 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {
  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
  fclose( infile3);
 }

 fclose( outfile);

}  // end cat_3files
//
// cat together four files and put into a fifth
//
void cat_4files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str,char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat 4 files, unable to open input file 1 = %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 4 files, unable to open input file 2 = %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 4 files, unable to open input file 3= %s \n",
		  infile3_str);
	 // exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat 4 files, unable to open input file 4 = %s \n",
		  infile4_str);
	 // exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
  endfile = getline( infile1, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
  }
  fclose( infile1);
 }

 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {
  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
 fclose( infile3);
 }

 if (infile4 != NULL)
 {
  endfile = getline( infile4, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
  }
  fclose( infile4);
 }

 fclose( outfile);

}  // end cat_4files


//
// cat together five files and put into a sixth
//
void cat_5files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat 5 files, unable to open input file 1 = %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 5 files, unable to open input file 2= %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 5 files, unable to open input file 3= %s \n",
		  infile3_str);
	 // exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat 5 files, unable to open input file 4= %s \n",
		  infile4_str);
	 // exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat 5 files, unable to open input file 5= %s \n",
		  infile5_str);
	 // exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat 5 files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
   endfile = getline( infile1, thislinein);

   while( endfile == FALSE)
   {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
   }
  fclose( infile1);
 }

 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {

  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
  fclose( infile3);
 }

 if (infile4 != NULL)
 {

  endfile = getline( infile4, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
  }
  fclose( infile4);
 }


 if (infile5 != NULL)
 {
  endfile = getline( infile5, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
  }
 fclose( infile5);
 }

 fclose( outfile);

}  // end cat_5files


//
// cat together six files and put into a seventh
//
void cat_6files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat 6 files, unable to open input file 1= %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 6 files, unable to open input file 2= %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 6 files, unable to open input file 3= %s \n",
		  infile3_str);
	 // exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat 6 files, unable to open input file 4= %s \n",
		  infile4_str);
	 // exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat 6 files, unable to open input file 5= %s \n",
		  infile5_str);
	 // exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat 6 files, unable to open input file 6= %s \n",
		  infile6_str);
	 // exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
  endfile = getline( infile1, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
  }
  fclose( infile1);
 }

 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {
  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
  fclose( infile3);
 }

 if (infile4 != NULL)
 {
  endfile = getline( infile4, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
  }
  fclose( infile4);
 }

 if (infile5 != NULL)
 {
  endfile = getline( infile5, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
  }
  fclose( infile5);
 }

 if (infile6 != NULL)
 {
  endfile = getline( infile6, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
  }
  fclose( infile6);
 }

 fclose( outfile);

}  // end cat_6files

//
// cat together seven files and put into a eighth
//
void cat_7files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat 7 files, unable to open input file 1= %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 7 files, unable to open input file 2= %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 7 files, unable to open input file 3= %s \n",
		  infile3_str);
	 // exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat 7 files, unable to open input file 4= %s \n",
		  infile4_str);
	 // exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat 7 files, unable to open input file 5= %s \n",
		  infile5_str);
	 // exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat 7 files, unable to open input file 6= %s \n",
		  infile6_str);
	 // exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat 7 files, unable to open input file 7= %s \n",
		  infile7_str);
	 // exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat 7 files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
  endfile = getline( infile1, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
  }
  fclose( infile1);
 }

 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {
  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
  fclose( infile3);
 }

 if (infile4 != NULL)
 {
  endfile = getline( infile4, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
  }
  fclose( infile4);
 }

 if (infile5 != NULL)
 {
  endfile = getline( infile5, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
  }
  fclose( infile5);
 }

 if (infile6 != NULL)
 {
  endfile = getline( infile6, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
  }
  fclose( infile6);
 }

 if (infile7 != NULL)
 {
  endfile = getline( infile7, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
  }
  fclose( infile7);
 }

 fclose( outfile);

}  // end cat_7files

//
// cat together eight files and put into a ninth
//
void cat_8files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat 8 files, unable to open input file 1= %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 8 files, unable to open input file 2= %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 8 files, unable to open input file 3= %s \n",
		  infile3_str);
	 // exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat 8 files, unable to open input file 4= %s \n",
		  infile4_str);
	 // exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat 8 files, unable to open input file 5= %s \n",
		  infile5_str);
	 // exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat 8 files, unable to open input file 6= %s \n",
		  infile6_str);
	 // exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat 8 files, unable to open input file 7= %s \n",
		  infile7_str);
	 // exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat 8 files, unable to open input file 8= %s \n",
		  infile8_str);
	 // exit(-1);
 }
 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat 8 files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
  endfile = getline( infile1, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
  }
  fclose( infile1);
 }

 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {
  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
  fclose( infile3);
 }

 if (infile4 != NULL)
 {
  endfile = getline( infile4, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
  }
  fclose( infile4);
 }

 if (infile5 != NULL)
 {
  endfile = getline( infile5, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
  }
  fclose( infile5);
 }

 if (infile6 != NULL)
 {
  endfile = getline( infile6, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
  }
  fclose( infile6);
 }

 if (infile7 != NULL)
 {
  endfile = getline( infile7, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
  }
  fclose( infile7);
 }

 if (infile8 != NULL)
 {
  endfile = getline( infile8, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
  }
  fclose( infile8);
 }

 fclose( outfile);

}  // end cat_8files

//
// cat together 9 files and put into a tenth
//
void cat_9files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *infile9;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat 9 files, unable to open input file 1= %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 9 files, unable to open input file 2= %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 9 files, unable to open input file 3= %s \n",
		  infile3_str);
	 // exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat 9 files, unable to open input file 4= %s \n",
		  infile4_str);
	 // exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat 9 files, unable to open input file 5= %s \n",
		  infile5_str);
	 // exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat 9 files, unable to open input file 6= %s \n",
		  infile6_str);
	 // exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat 9 files, unable to open input file 7= %s \n",
		  infile7_str);
	 // exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat 9 files, unable to open input file 8= %s \n",
		  infile8_str);
	 // exit(-1);
 }

 infile9 = fopen(infile9_str,"r");


 if (infile9 == NULL)
	{
	 printf("Error in concat 9 files, unable to open input file 9= %s \n",
		  infile9_str);
	 // exit(-1);
 }


 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat 9 files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
  endfile = getline( infile1, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
  }
  fclose( infile1);
 }

 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {
  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
  fclose( infile3);
 }

 if (infile4 != NULL)
 {
  endfile = getline( infile4, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
  }
 fclose( infile4);
 }

 if (infile5 != NULL)
 {
  endfile = getline( infile5, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
  }
  fclose( infile5);
 }


 if (infile6 != NULL)
 {
  endfile = getline( infile6, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
  }
  fclose( infile6);
 }


 if (infile7 != NULL)
 {
  endfile = getline( infile7, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
  }
  fclose( infile7);
 }

 if (infile8 != NULL)
 {
  endfile = getline( infile8, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
  }
  fclose( infile8);
 }

 if (infile9 != NULL)
 {
  endfile = getline( infile9, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile9, thislinein);
  }
  fclose( infile9);
 }

 fclose( outfile);

}  // end cat_9files

//
// cat together 10 files and put into an eleventh
//
void cat_10files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *infile9;
FILE *infile10;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat 10 files, unable to open input file 1= %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 10 files, unable to open input file 2= %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 10 files, unable to open input file 3= %s \n",
		  infile3_str);
	 // exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat 10 files, unable to open input file 4= %s \n",
		  infile4_str);
	 // exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat 10 files, unable to open input file 5= %s \n",
		  infile5_str);
	 // exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat 10 files, unable to open input file 6= %s \n",
		  infile6_str);
	 // exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat 10 files, unable to open input file 7= %s \n",
		  infile7_str);
	 // exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat 10 files, unable to open input file 8= %s \n",
		  infile8_str);
	 // exit(-1);
 }

 infile9 = fopen(infile9_str,"r");


 if (infile9 == NULL)
	{
	 printf("Error in concat 10 files, unable to open input file 9= %s \n",
		  infile9_str);
	 // exit(-1);
 }

 infile10 = fopen(infile10_str,"r");


 if (infile10 == NULL)
	{
	 printf("Error in concat 10 files, unable to open input file 10= %s \n",
		  infile10_str);
	 // exit(-1);
 }


 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat 10 files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
  endfile = getline( infile1, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
  }
  fclose( infile1);
 }

 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {
  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
  fclose( infile3);
 }

 if (infile4 != NULL)
 {
  endfile = getline( infile4, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
  }
  fclose( infile4);
 }

 if (infile5 != NULL)
 {
  endfile = getline( infile5, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
  }
  fclose( infile5);
 }

 if (infile6 != NULL)
 {
  endfile = getline( infile6, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
  }
  fclose( infile6);
 }


 if (infile7 != NULL)
 {
  endfile = getline( infile7, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
  }
 fclose( infile7);
 }

 if (infile8 != NULL)
 {
  endfile = getline( infile8, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
  }
  fclose( infile8);
 }


 if (infile9 != NULL)
 {
  endfile = getline( infile9, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile9, thislinein);
  }
  fclose( infile9);
 }

 if (infile10 != NULL)
 {
  endfile = getline( infile10, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile10, thislinein);
  }
  fclose( infile10);
 }

 fclose( outfile);

}  // end cat_10files

//
// cat together 11 files and put into a twelfth
//
void cat_11files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str, char *infile11_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *infile9;
FILE *infile10;
FILE *infile11;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 1= %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 2= %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 3= %s \n",
		  infile3_str);
	 // exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 4= %s \n",
		  infile4_str);
	 // exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 5= %s \n",
		  infile5_str);
	 // exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 6= %s \n",
		  infile6_str);
	 // exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 7= %s \n",
		  infile7_str);
	 // exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 8= %s \n",
		  infile8_str);
	 // exit(-1);
 }

 infile9 = fopen(infile9_str,"r");


 if (infile9 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 9= %s \n",
		  infile9_str);
	 // exit(-1);
 }

 infile10 = fopen(infile10_str,"r");


 if (infile10 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 10= %s \n",
		  infile10_str);
	 // exit(-1);
 }

 infile11 = fopen(infile11_str,"r");


 if (infile11 == NULL)
	{
	 printf("Error in concat 11 files, unable to open input file 11= %s \n",
		  infile11_str);
	 // exit(-1);
 }


 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat 11 files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
  endfile = getline( infile1, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
  }
  fclose( infile1);
 }

 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {
  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
 fclose( infile3);
 }

 if (infile4 != NULL)
 {
  endfile = getline( infile4, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
  }
  fclose( infile4);
 }

 if (infile5 != NULL)
 {
  endfile = getline( infile5, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
  }
  fclose( infile5);
 }

 if (infile6 != NULL)
 {
  endfile = getline( infile6, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
  }
 fclose( infile6);
 }

 if (infile7 != NULL)
 {
  endfile = getline( infile7, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
  }
  fclose( infile7);
 }


 if (infile8 != NULL)
 {
  endfile = getline( infile8, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
  }
  fclose( infile8);
 }

 if (infile9 != NULL)
 {
  endfile = getline( infile9, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile9, thislinein);
  }
  fclose( infile9);
 }


 if (infile10 != NULL)
 {
  endfile = getline( infile10, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile10, thislinein);
  }
  fclose( infile10);

 }

 if (infile11 != NULL)
 {
  endfile = getline( infile11, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile11, thislinein);
  }
 fclose( infile11);
 }


 fclose( outfile);

}  // end cat_11files

//
// cat together 12 files and put into a twelfth
//
void cat_12files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
		  	     char *infile10_str, char *infile11_str, char *infile12_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *infile9;
FILE *infile10;
FILE *infile11;
FILE *infile12;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 1= %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 2= %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 3= %s \n",
		  infile3_str);
	 // exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 4= %s \n",
		  infile4_str);
	 // exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 5= %s \n",
		  infile5_str);
	 // exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 6= %s \n",
		  infile6_str);
	 // exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 7= %s \n",
		  infile7_str);
	 // exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 8 = %s \n",
		  infile8_str);
	 // exit(-1);
 }

 infile9 = fopen(infile9_str,"r");


 if (infile9 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 9= %s \n",
		  infile9_str);
	 // exit(-1);
 }

 infile10 = fopen(infile10_str,"r");


 if (infile10 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 10= %s \n",
		  infile10_str);
	 // exit(-1);
 }

 infile11 = fopen(infile11_str,"r");


 if (infile11 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 11= %s \n",
		  infile11_str);
	 // exit(-1);
 }

infile12 = fopen(infile12_str,"r");


 if (infile12 == NULL)
	{
	 printf("Error in concat 12 files, unable to open input file 12= %s \n",
		  infile12_str);
	 // exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat 12 files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
  endfile = getline( infile1, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
  }
  fclose( infile1);
 }

 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {
  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
 fclose( infile3);
 }

 if (infile4 != NULL)
 {
  endfile = getline( infile4, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
  }
  fclose( infile4);
 }

 if (infile5 != NULL)
 {
  endfile = getline( infile5, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
  }
  fclose( infile5);
 }

 if (infile6 != NULL)
 {
  endfile = getline( infile6, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
  }
 fclose( infile6);
 }

 if (infile7 != NULL)
 {
  endfile = getline( infile7, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
  }
  fclose( infile7);
 }


 if (infile8 != NULL)
 {
  endfile = getline( infile8, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
  }
  fclose( infile8);
 }

 if (infile9 != NULL)
 {
  endfile = getline( infile9, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile9, thislinein);
  }
  fclose( infile9);
 }


 if (infile10 != NULL)
 {
  endfile = getline( infile10, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile10, thislinein);
  }
  fclose( infile10);

 }

 if (infile11 != NULL)
 {
  endfile = getline( infile11, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile11, thislinein);
  }
 fclose( infile11);
 }


 if (infile12 != NULL)
 {
  endfile = getline( infile12, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile12, thislinein);
  }
 fclose( infile12);
 }


 fclose( outfile);

}  // end cat_12files



// cat together 13 files and put into a 14th
//
void cat_13files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str, char *infile11_str,char *infile12_str,
				 char *infile13_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *infile9;
FILE *infile10;
FILE *infile11;
FILE *infile12;
FILE *infile13;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 1= %s \n",
		  infile1_str);
     // exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 2= %s \n",
		  infile2_str);
    // exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 3= %s \n",
		  infile3_str);
	 // exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 4= %s \n",
		  infile4_str);
	 // exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 5= %s \n",
		  infile5_str);
	 // exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 6= %s \n",
		  infile6_str);
	 // exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 7= %s \n",
		  infile7_str);
	 // exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 8= %s \n",
		  infile8_str);
	 // exit(-1);
 }

 infile9 = fopen(infile9_str,"r");


 if (infile9 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 9= %s \n",
		  infile9_str);
	 // exit(-1);
 }

 infile10 = fopen(infile10_str,"r");


 if (infile10 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 10= %s \n",
		  infile10_str);
	 // exit(-1);
 }

 infile11 = fopen(infile11_str,"r");


 if (infile11 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 11= %s \n",
		  infile11_str);
	 // exit(-1);
 }

 infile12 = fopen(infile12_str,"r");


 if (infile12 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 12= %s \n",
		  infile12_str);
	 // exit(-1);
 }


 infile13 = fopen(infile13_str,"r");


 if (infile13 == NULL)
	{
	 printf("Error in concat 13 files, unable to open input file 13= %s \n",
		  infile13_str);
	 // exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat 13 files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 if (infile1 != NULL)
 {
  endfile = getline( infile1, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
  }
  fclose( infile1);
 }

 if (infile2 != NULL)
 {
  endfile = getline( infile2, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
  }
  fclose( infile2);
 }

 if (infile3 != NULL)
 {
  endfile = getline( infile3, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
  }
 fclose( infile3);
 }

 if (infile4 != NULL)
 {
  endfile = getline( infile4, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
  }
  fclose( infile4);
 }

 if (infile5 != NULL)
 {
  endfile = getline( infile5, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
  }
  fclose( infile5);
 }

 if (infile6 != NULL)
 {
  endfile = getline( infile6, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
  }
 fclose( infile6);
 }

 if (infile7 != NULL)
 {
  endfile = getline( infile7, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
  }
  fclose( infile7);
 }


 if (infile8 != NULL)
 {
  endfile = getline( infile8, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
  }
  fclose( infile8);
 }

 if (infile9 != NULL)
 {
  endfile = getline( infile9, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile9, thislinein);
  }
  fclose( infile9);
 }


 if (infile10 != NULL)
 {
  endfile = getline( infile10, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile10, thislinein);
  }
  fclose( infile10);

 }

 if (infile11 != NULL)
 {
  endfile = getline( infile11, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile11, thislinein);
  }
 fclose( infile11);
 }


 if (infile12 != NULL)
 {
  endfile = getline( infile12, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile12, thislinein);
  }
  fclose( infile12);
 }

 if (infile13 != NULL)
 {
  endfile = getline( infile13, thislinein);

  while( endfile == FALSE)
  {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile13, thislinein);
  }
 fclose( infile13);
 }


 fclose( outfile);

}  // end cat_13files


void rm_files_base( char *basestr)

{
int file_count;
int kk;
char rmfilestr[200];
int debug;

  debug=0;

  file_count=scandir_matchbase(".",0,basestr);
  if (debug) { printf("Returned from scandir_matchbase, file_count = %d basestr=%s\n",
	  file_count,basestr); }


  kk=0;

  while( kk < file_count)
  {
	  strncpy(rmfilestr,scan_array[kk],120);

	  if (debug) { printf("In rm_files_base, file to remove = %s \n",rmfilestr); }

	  rm_file(rmfilestr);
	  kk+=1;
  }

}

void rm_files_ext( char *extstr)

{
int file_count;
int kk;
char rmfilestr[200];
int debug;

  debug=0;

  file_count=scandir_matchext(".",0,extstr);
  if (debug) { printf("Returned from scandir_matchext, file_count = %d extstr=%s\n",
	  file_count,extstr); }


  kk=0;

  while( kk < file_count)
  {
	  strncpy(rmfilestr,scan_array[kk],120);

	  if (debug) { printf("In rm_files_ext, file to remove = %s \n",rmfilestr); }

	  rm_file(rmfilestr);
	  kk+=1;
  }

}

//
//  rm a file from a subdirectory
//
void rm_sub_file( char *dirname, char *filename)

{
char rmfilestr[240];

   strncpy(rmfilestr,dirname,120);
   if (WINDOWS)
   {
	   strncat(rmfilestr,"\\",4);
   }
   else
   {
	   strncat(rmfilestr,"/",4);
   }
   strncat(rmfilestr,filename,120);

   rm_file(rmfilestr);

}

// compare function for sortxy...   equivalent to sort -n -k1 -k2

//int  sortxy_compare( const struct xytype *inxy1, const  struct xytype *inxy2)
int  sortxy_compare( const void *inxy1, const  void *inxy2)
{
  struct xytype *inxxy1;
  struct xytype *inxxy2;
  
  inxxy1 = (struct xytype*) inxy1;
  inxxy2 = (struct xytype*) inxy2;
  
  if (inxxy1->x < inxxy2->x)
  {
	  return(-1);
  }
  if (inxxy1->x > inxxy2->x )
  {
	  return(1);
  }
  if (inxxy1->x == inxxy2->x)
  {

	  if (inxxy1->y < inxxy2->y)
	  {
		  return(-1);
	  }
	  if (inxxy1->y > inxxy2->y)
	  {
		  return(1);
	  }
	  if (inxxy1->y == inxxy2->y)
	  {
		  return(0);
	  }
  }
  return(0);
}

// use qsort to sort a file of x, y values
//
void sortxy( char *infilestr, char *outfilestr)
{
FILE *infile;
FILE *outfile;
int line_count;
int endoffile;
int nf;
int kk;
double xval;
double yval;
char thisline[300];

  infile=fopen(infilestr,"r");
  if (infile == NULL)
	 {
	  printf("In sortxy, unable to open the input file = %s \n", infilestr);
	  exit(-1);
	 }

  line_count=0;

  endoffile=getline(infile,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {
    xval=atof(str_array[0]);
	yval=atof(str_array[1]);

	if (nf > 2)
	{
		strncpy( xyarray[line_count].rest, str_array[2],10);
	}
	else
	{
		strncpy( xyarray[line_count].rest,"",10);
	}
	if ( line_count < 100000)
	{
		xyarray[line_count].x = xval;
		xyarray[line_count].y = yval;
	    line_count +=1;
	}
   else
   {
	   printf("In sortxy, number of lines exceeded \n");
	   exit(-1);
   }
  endoffile=getline(infile,thisline);
  nf=split_line(thisline);
  }

  fclose(infile);

  qsort(( struct xytype *) xyarray,line_count,sizeof( struct xytype),sortxy_compare);

  outfile=fopen(outfilestr,"w");
  if (outfile == NULL)
	 {
	  printf("In sortxy, unable to open the ouput file = %s \n", outfilestr);
	  exit(-1);
	 }

  for(kk=0; kk < line_count; kk += 1)
  {
	  fprintf(outfile,"%0.0f %0.0f %s\n",xyarray[kk].x, xyarray[kk].y,xyarray[kk].rest);
  }

  fclose(outfile);

}  // end sortxy

//
//  Copy files from a directory to another directory, all files with a given extention
//        from or to dirs may be ".", but not both "."
//
int cp_files_ext( char *fromdirstr, char *extstr, char *todirstr)
{
int file_count;
int kk;
char fromfilestr[300];
char tofilestr[300];

   file_count=scandir_matchext(fromdirstr,0,extstr);

   for(kk=0; kk < file_count; kk += 1)
   {
	   if (strcmp(fromdirstr,".") == 0 )
	   {
		 strncpy(tofilestr,todirstr,120);
		 strncat(tofilestr,dirsep,4);
		 strncat(tofilestr,scan_array[kk],120);

         cp_file(scan_array[kk],tofilestr);
		 strncpy(cp_list[kk],tofilestr,120);

	   }
	  else
	  {
        strncpy(fromfilestr,fromdirstr,120);
		strncat(fromfilestr,dirsep,4);
		strncat(fromfilestr,scan_array[kk],120);

		if ( strcmp( todirstr,".") == 0 )
		{
			cp_file( fromfilestr,scan_array[kk]);
            strncpy(cp_list[kk],scan_array[kk],120);  // kludge for pcmplacement

		}
		else
		{
          strncpy(tofilestr,todirstr,120);
		 strncat(tofilestr,dirsep,4);
		 strncat(tofilestr,scan_array[kk],120);

         cp_file(fromfilestr,tofilestr);
         strncpy(cp_list[kk],tofilestr,120);      // kludge for

		}
	  }
   }

   return(file_count);

}  // end cp_files_dir_ext
//
//  Copy files from a directory to another directory, all files with a given base
//        from or to dirs may be ".", but not both "."
//
int cp_files_base( char *fromdirstr, char *basestr, char *todirstr)
{
int file_count;
int kk;
char fromfilestr[300];
char tofilestr[300];

   file_count=scandir_matchbase(fromdirstr,0,basestr);

   for(kk=0; kk < file_count; kk += 1)
   {
	   if (strcmp(fromdirstr,".") == 0 )
	   {
		 strncpy(tofilestr,todirstr,120);
		 strncat(tofilestr,dirsep,4);
		 strncat(tofilestr,scan_array[kk],120);

         cp_file(scan_array[kk],tofilestr);
		 strncpy(cp_list[kk],tofilestr,120);

	   }
	  else
	  {
        strncpy(fromfilestr,fromdirstr,120);
		strncat(fromfilestr,dirsep,4);
		strncat(fromfilestr,scan_array[kk],120);

		if ( strcmp( todirstr,".") == 0 )
		{
			cp_file( fromfilestr,scan_array[kk]);
            strncpy(cp_list[kk],scan_array[kk],120);  // kludge for pcmplacement

		}
		else
		{
          strncpy(tofilestr,todirstr,120);
		 strncat(tofilestr,dirsep,4);
		 strncat(tofilestr,scan_array[kk],120);

         cp_file(fromfilestr,tofilestr);
         strncpy(cp_list[kk],tofilestr,120);      // kludge for

		}
	  }
   }

   return(file_count);

}  // end cp_files_dir_base

//
//  Copy files from a directory to another directory, all files with a given extention
//        from or to dirs may be ".", but not both "."
//
int cp_files_dir_ext( char *fromdirstr, char *extstr, char *todirstr)
{
int file_count;
int kk;
char fromfilestr[300];
char tofilestr[300];

   file_count=scandir_matchext(fromdirstr,0,extstr);

   for(kk=0; kk < file_count; kk += 1)
   {
	   if (strcmp(fromdirstr,".") == 0 )
	   {
		 strncpy(tofilestr,todirstr,120);
		 strncat(tofilestr,dirsep,4);
		 strncat(tofilestr,scan_array[kk],120);

         cp_file(scan_array[kk],tofilestr);
		 strncpy(cp_list[kk],tofilestr,120);

	   }
	  else
	  {
        strncpy(fromfilestr,fromdirstr,120);
		strncat(fromfilestr,dirsep,4);
		strncat(fromfilestr,scan_array[kk],120);

		if ( strcmp( todirstr,".") == 0 )
		{
			cp_file( fromfilestr,scan_array[kk]);
            strncpy(cp_list[kk],scan_array[kk],120);  // kludge for pcmplacement

		}
		else
		{
          strncpy(tofilestr,todirstr,120);
		 strncat(tofilestr,dirsep,4);
		 strncat(tofilestr,scan_array[kk],120);

         cp_file(fromfilestr,tofilestr);
         strncpy(cp_list[kk],tofilestr,120);      // kludge for

		}
	  }
   }

   return(file_count);

}  // end cp_files_ext


void mv_ext_ext( char *ext1str, char *ext2str)
{
int file_count;
char tofilestr[300];
int kk;
int ii;

    file_count=scandir_matchext( ".",0, ext1str);

	for(kk=0; kk < file_count; kk += 1)
	{
		strncpy(tofilestr,scan_array[kk],120);

		ii=0;
		while((tofilestr[ii] != '.') && (ii <(signed int) strlen(tofilestr)) )
		{
			ii += 1;
		}
		if (tofilestr[ii]== '.')
		{
			tofilestr[ii]=0;
			strncat(tofilestr,ext2str,80);
			cp_file(scan_array[kk],tofilestr);
			rm_file(scan_array[kk]);
		}
	   else
	   {
		   printf("In mv_ext_ext, expected . in filename \n");
		   exit(-1);
	   }
    }

}  // end mv_ext_ext

//
// rm all files in subdirectory
//

void rm_dir_files( char *dirnamestr)
{
int file_count;
char tofilestr[300];
int kk;

    file_count=scandir_matchall(dirnamestr,0);

	for(kk=0; kk < file_count; kk += 1)
	{
		strncpy(tofilestr,dirnamestr,120);
		strncat(tofilestr,dirsep,4);
		strncat(tofilestr,scan_array[kk],120);
	    rm_file(tofilestr);

    }

}  // end rm_dir_files

void chmod_file( int modval, char *infilestr)
{

	// what to do?


}  // chmod_file end


//
// cp one file from a sub directory file line by line
//
void cp_file_fromsub(char *subdir, char *infile1_str, char *outfile_str)
{
FILE *infile1;
FILE *outfile;
int endfile;
char thislinein[200];
char fnamestr[200];
char dirsep[4];

 if (WINDOWS == TRUE)
	{
	 strncpy(dirsep,"\\",4);
 }
 else
 {
	 strncpy(dirsep,"/",4);
 }
 strncpy( fnamestr,subdir,40);
 strncat( fnamestr,dirsep,5);
 strncat( fnamestr,infile1_str,120);

 infile1 = fopen(fnamestr,"r");

 if (infile1 == NULL)
	{
	 printf("Error in cp_file_fromsub, unable to open input file = %s \n",
		  fnamestr);
	 exit(-1);
 }


 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in cp_file_fromsub , unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 fclose( outfile);

}  // end cp_file_fromsub

// find the minimum of an array of integers
//   with size = cnt

int mindiff( int *myarray, int cnt )
{
int i;
int value;

   value = myarray[0];
   for( i = 1 ; i < cnt ; i+= 1)
   {
      if( myarray[i] < value )
	  {
         value = myarray[i];
      }
   }
   return( value);

}

void uniq_lines( char *infilestr, char *outfilestr)
{
char prevline[300];
char thisline[300];
FILE *infile;
FILE *outfile;
int endfile;

 infile = fopen(infilestr,"r");
 if (infile == NULL)
 {
	printf("In uniq_lines, unable to open the input file = %s \n",infilestr);
	exit(-1);
 }
 outfile = fopen(outfilestr,"w");
 if (outfile == NULL)
 {
	printf("In uniq_lines, unable to open the output file = %s \n",outfilestr);
	exit(-1);
 }



 endfile=getline(infile,thisline);
  strncpy(prevline,"",10);

 while(endfile==FALSE)
 {

	if (strcmp(thisline,prevline)!= 0 )
	{
		fprintf(outfile,"%s\n",thisline);
	}

	strncpy(prevline,thisline,300);
	endfile=getline(infile,thisline);
 }

 fclose(infile);
 fclose(outfile);

}  // end uniq_lines

//
// grep for a string in a given file and write the results to another (opened) file
//
//     do not close the output file
//
void grep_file_to_file( char *searchstr, char *infilestr, FILE *outfile)
{
FILE *infile;

int endfile;
char thisline[400];

 infile = fopen(infilestr,"r");
 if (infile == NULL)
	{
	 printf("In grep_file_out, unable to open the input file = %s \n",infilestr);
	 exit(-1);
 }


 endfile=getline(infile,thisline);
 while(endfile == FALSE)
 {

	 if (strstr(thisline,searchstr) != NULL)
	 {
		fprintf(outfile,"%s",thisline);
	 }

	 endfile=getline(infile,thisline);
 }

 fclose(infile);


} // grep_file_to_file


//
// grep for a string in a given file and append the results to another file
//

void grep_file_append( char *searchstr, char *infilestr, char *outfilestr)
{
FILE *infile;
FILE *outfile;

int endfile;
char thisline[400];

 infile = fopen(infilestr,"r");
 if (infile == NULL)
	{
	 printf("In grep_file_out, unable to open the input file = %s \n",infilestr);
	 exit(-1);
 }
 outfile = fopen(outfilestr,"a");   // for append
 if (outfile == NULL)
	{
	 printf("In grep_file_out, unable to open the output file = %s \n",outfilestr);
	 exit(-1);
 }

 endfile=getline(infile,thisline);
 while(endfile == FALSE)
 {

	 if (strstr(thisline,searchstr) != NULL)
	 {
		fprintf(outfile,"%s",thisline);
	 }

	 endfile=getline(infile,thisline);
 }

 fclose(infile);
 fclose(outfile);


} // grep_file_append

//
// grep for a string in a given file and write the results to another file
//

void grep_file_out( char *searchstr, char *infilestr, char *outfilestr)
{
FILE *infile;
FILE *outfile;

int endfile;
char thisline[400];

 infile = fopen(infilestr,"r");
 if (infile == NULL)
	{
	 printf("In grep_file_out, unable to open the input file = %s \n",infilestr);
	 exit(-1);
 }
 outfile = fopen(outfilestr,"w");   // for write
 if (outfile == NULL)
	{
	 printf("In grep_file_out, unable to open the output file = %s \n",outfilestr);
	 exit(-1);
 }

 endfile=getline(infile,thisline);
 while(endfile == FALSE)
 {

	 if (strstr(thisline,searchstr) != NULL)
	 {
		fprintf(outfile,"%s",thisline);
	 }

	 endfile=getline(infile,thisline);
 }

 fclose(infile);
 fclose(outfile);


} // grep_file_out


void placestandard_out( double x, double y, FILE *ofile)
{
int ii;
char a[10][40];
char b[10][40];
char c[10][40];
char d[10][40];
int val;
char X[40];
char Y[40];
double xval;
double yval;
int xint;
int yint;


  // printf("In placestandard_out\n");

   ii = 0;

  while ( (signed int) strlen(glines[ii]) > 0){
    if (( strstr(glines[ii],"X") != NULL) && ( strstr(glines[ii],"Y")!= NULL)
		 && ( strstr(glines[ii],"G54") == NULL))
	{
       split(glines[ii],a[0],a[1],"Y");
       split(glines[ii],d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,(signed int) strlen(a[0]),X );
       awk_substr( a[1],1,(signed int) strlen(a[1]) -4,Y);
	   xval=atof(X);
	   yval=atof(Y);
       xval=xval + x;
       yval=yval + y;
	   xint=(int)(xval);
	   yint=(int)(yval);
       fprintf(ofile,"G01X%dY%dD%s\n",xint,yint,d[1]);
    }
    else if( (strstr(glines[ii],"Y") == NULL) && (strstr(glines[ii],"X") != NULL))
	{
      split(glines[ii],b[0],b[1],"X");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(b[1],1,(signed int) strlen(b[1]) - 4,X);
	  xval=atof(X);
	  xval=xval+x;
	  xint=(int) (xval);
      fprintf(ofile,"G01X%dD%s\n", xint,d[1]);
    }
    else if(( strstr(glines[ii],"Y") != NULL) && (strstr(glines[ii],"X") == NULL))
	{
      split(glines[ii],c[0],c[1],"Y");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(c[1],1,(signed int) strlen(c[1]) - 4, Y);
	  yval=atof(Y);
	  yval=yval+y;
	  yint=(int ) (yval);
      fprintf(ofile,"G01Y%dD%s\n",yint,d[1]);
    }
    else if( strstr(glines[ii],"M0")==NULL)
	{
      fprintf(ofile,"%s\n",glines[ii]);
    }
	ii += 1;
  }

}

void placestandard( double x, double y)
{
int ii;
char a[10][40];
char b[10][40];
char c[10][40];
char d[10][40];
int val;
char X[40];
char Y[40];
double xval;
double yval;
int xint;
int yint;


  // printf("In placestandard\n");

   ii = 0;

  while ( (signed int) strlen(glines[ii]) > 0){
    if (( strstr(glines[ii],"X") != NULL) && ( strstr(glines[ii],"Y")!= NULL)
		 && ( strstr(glines[ii],"G54") == NULL))
	{
       split(glines[ii],a[0],a[1],"Y");
       split(glines[ii],d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,(signed int) strlen(a[0]),X );
       awk_substr( a[1],1,(signed int) strlen(a[1]) -4,Y);
	   xval=atof(X);
	   yval=atof(Y);
       xval=xval + x;
       yval=yval + y;
	   xint=(int)(xval);
	   yint=(int)(yval);
       printf("G01X%dY%dD%s\n",xint,yint,d[1]);
    }
    else if( (strstr(glines[ii],"Y") == NULL) && (strstr(glines[ii],"X") != NULL))
	{
      split(glines[ii],b[0],b[1],"X");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(b[1],1,(signed int) strlen(b[1]) - 4,X);
	  xval=atof(X);
	  xval=xval+x;
	  xint=(int) (xval);
      printf("G01X%dD%s\n", xint,d[1]);
    }
    else if(( strstr(glines[ii],"Y") != NULL) && (strstr(glines[ii],"X") == NULL))
	{
      split(glines[ii],c[0],c[1],"Y");
      split(glines[ii],d[0],d[1],"D");
      awk_substr(c[1],1,(signed int) strlen(c[1]) - 4, Y);
	  yval=atof(Y);
	  yval=yval+y;
	  yint=(int ) (yval);
      printf("G01Y%dD%s\n",yint,d[1]);
    }
    else if( strstr(glines[ii],"M0")==NULL)
	{
      printf("%s\n",glines[ii]);
    }
	ii += 1;
  }

}

//
// make gerber in array alpha for all chars
//
void init_alpha_glines( )
{

strncpy(alpha[0].glines[0],"G54D548*",40);
strncpy(alpha[0].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[0].glines[2],"Y-3750D01*",40);
strncpy(alpha[0].glines[3],"X0Y11250D01*",40);
strncpy(alpha[0].glines[4],"X7500Y-3750D01*",40);
strncpy(alpha[0].glines[5],"Y-11250D01*",40);
strncpy(alpha[0].glines[6],"X-7500Y-3750D02*",40);
strncpy(alpha[0].glines[7],"X7500D01*",40);
strncpy(alpha[0].glines[8],"M02*",40);
strncpy(alpha[0].glines[9],"",4);

strncpy(alpha[1].glines[0],"G54D548*",40);
strncpy(alpha[1].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[1].glines[2],"X3750D01*",40);
strncpy(alpha[1].glines[3],"X7500Y-7500D01*",40);
strncpy(alpha[1].glines[4],"Y-3750D01*",40);
strncpy(alpha[1].glines[5],"X3750Y0D01*",40);
strncpy(alpha[1].glines[6],"X-3750D01*",40);
strncpy(alpha[1].glines[7],"X3750D02*",40);
strncpy(alpha[1].glines[8],"X7500Y3750D01*",40);
strncpy(alpha[1].glines[9],"Y7500D01*",40);
strncpy(alpha[1].glines[10],"X3750Y11250D01*",40);
strncpy(alpha[1].glines[11],"X-7500D01*",40);
strncpy(alpha[1].glines[12],"X-3750D02*",40);
strncpy(alpha[1].glines[13],"Y-11250D01*",40);
strncpy(alpha[1].glines[14],"M02*",40);
strncpy(alpha[1].glines[15],"",4);

strncpy(alpha[2].glines[0],"G54D548*",40);
strncpy(alpha[2].glines[1],"X7500Y-7500D02*",40);
strncpy(alpha[2].glines[2],"X3750Y-11250D01*",40);
strncpy(alpha[2].glines[3],"X-3750D01*",40);
strncpy(alpha[2].glines[4],"X-7500Y-7500D01*",40);
strncpy(alpha[2].glines[5],"Y7500D01*",40);
strncpy(alpha[2].glines[6],"X-3750Y11250D01*",40);
strncpy(alpha[2].glines[7],"X3750D01*",40);
strncpy(alpha[2].glines[8],"X7500Y7500D01*",40);
strncpy(alpha[2].glines[9],"M02*",40);
strncpy(alpha[2].glines[10],"",4);

strncpy(alpha[3].glines[0],"G54D548*",40);
strncpy(alpha[3].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[3].glines[2],"X3750D01*",40);
strncpy(alpha[3].glines[3],"X7500Y-7500D01*",40);
strncpy(alpha[3].glines[4],"Y7500D01*",40);
strncpy(alpha[3].glines[5],"X3750Y11250D01*",40);
strncpy(alpha[3].glines[6],"X-7500D01*",40);
strncpy(alpha[3].glines[7],"X-3750D02*",40);
strncpy(alpha[3].glines[8],"Y-11250D01*",40);
strncpy(alpha[3].glines[9],"M02*",40);
strncpy(alpha[3].glines[10],"",4);

strncpy(alpha[4].glines[0],"G54D548*",40);
strncpy(alpha[4].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[4].glines[2],"Y11250D01*",40);
strncpy(alpha[4].glines[3],"X7500D01*",40);
strncpy(alpha[4].glines[4],"X-7500Y0D02*",40);
strncpy(alpha[4].glines[5],"X0D01*",40);
strncpy(alpha[4].glines[6],"X-7500Y-11250D02*",40);
strncpy(alpha[4].glines[7],"X7500D01*",40);
strncpy(alpha[4].glines[8],"M02*",40);
strncpy(alpha[4].glines[9],"",4);

strncpy(alpha[5].glines[0],"G54D548*",40);
strncpy(alpha[5].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[5].glines[2],"Y11250D01*",40);
strncpy(alpha[5].glines[3],"X7500D01*",40);
strncpy(alpha[5].glines[4],"X-7500Y0D02*",40);
strncpy(alpha[5].glines[5],"X0D01*",40);
strncpy(alpha[5].glines[6],"M02*",40);
strncpy(alpha[5].glines[7],"",4);

strncpy(alpha[6].glines[0],"G54D548*",40);
strncpy(alpha[6].glines[1],"X3750Y0D02*",40);
strncpy(alpha[6].glines[2],"X7500D01*",40);
strncpy(alpha[6].glines[3],"Y-11250D01*",40);
strncpy(alpha[6].glines[4],"X-3750D01*",40);
strncpy(alpha[6].glines[5],"X-7500Y-7500D01*",40);
strncpy(alpha[6].glines[6],"Y7500D01*",40);
strncpy(alpha[6].glines[7],"X-3750Y11250D01*",40);
strncpy(alpha[6].glines[8],"X7500D01*",40);
strncpy(alpha[6].glines[9],"M02*",40);
strncpy(alpha[6].glines[10],"",4);


strncpy(alpha[7].glines[0],"G54D548*",40);
strncpy(alpha[7].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[7].glines[2],"Y11250D01*",40);
strncpy(alpha[7].glines[3],"Y0D02*",40);
strncpy(alpha[7].glines[4],"X7500D01*",40);
strncpy(alpha[7].glines[5],"Y11250D02*",40);
strncpy(alpha[7].glines[6],"Y-11250D01*",40);
strncpy(alpha[7].glines[7],"M02*",40);
strncpy(alpha[7].glines[8],"",4);

strncpy(alpha[8].glines[0],"G54D548*",40);
strncpy(alpha[8].glines[1],"X-3750Y11250D02*",40);
strncpy(alpha[8].glines[2],"X3750D01*",40);
strncpy(alpha[8].glines[3],"X0D02*",40);
strncpy(alpha[8].glines[4],"Y-11250D01*",40);
strncpy(alpha[8].glines[5],"X-3750D02*",40);
strncpy(alpha[8].glines[6],"X3750D01*",40);
strncpy(alpha[8].glines[7],"M02*",40);
strncpy(alpha[8].glines[8],"",4);

strncpy(alpha[9].glines[0],"G54D548*",40);
strncpy(alpha[9].glines[1],"X-7500Y-7500D02*",40);
strncpy(alpha[9].glines[2],"X-3750Y-11250D01*",40);
strncpy(alpha[9].glines[3],"X3750D01*",40);
strncpy(alpha[9].glines[4],"X7500Y-7500D01*",40);
strncpy(alpha[9].glines[5],"Y11250D01*",40);
strncpy(alpha[9].glines[6],"M02*",40);
strncpy(alpha[9].glines[7],"",4);

strncpy(alpha[10].glines[0],"G54D548*",40);
strncpy(alpha[10].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[10].glines[2],"Y11250D01*",40);
strncpy(alpha[10].glines[3],"X7500D02*",40);
strncpy(alpha[10].glines[4],"X-3750Y0D01*",40);
strncpy(alpha[10].glines[5],"X-7500D01*",40);
strncpy(alpha[10].glines[6],"X-3750D02*",40);
strncpy(alpha[10].glines[7],"X7500Y-11250D01*",40);
strncpy(alpha[10].glines[8],"M02*",40);
strncpy(alpha[10].glines[9],"",4);

strncpy(alpha[11].glines[0],"G54D548*",40);
strncpy(alpha[11].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[11].glines[2],"Y-11250D01*",40);
strncpy(alpha[11].glines[3],"X7500D01*",40);
strncpy(alpha[11].glines[4],"M02*",40);
strncpy(alpha[11].glines[5],"",4);

strncpy(alpha[12].glines[0],"G54D548*",40);
strncpy(alpha[12].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[12].glines[2],"Y11250D01*",40);
strncpy(alpha[12].glines[3],"X0Y-3750D01*",40);
strncpy(alpha[12].glines[4],"X7500Y11250D01*",40);
strncpy(alpha[12].glines[5],"Y-11250D01*",40);
strncpy(alpha[12].glines[6],"M02*",40);
strncpy(alpha[12].glines[7],"",4);

strncpy(alpha[13].glines[0],"G54D548*",40);
strncpy(alpha[13].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[13].glines[2],"Y11250D01*",40);
strncpy(alpha[13].glines[3],"X7500Y-11250D01*",40);
strncpy(alpha[13].glines[4],"Y11250D01*",40);
strncpy(alpha[13].glines[5],"M02*",40);
strncpy(alpha[13].glines[6],"",4);

strncpy(alpha[14].glines[0],"G54D548*",40);
strncpy(alpha[14].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[14].glines[2],"Y11250D01*",40);
strncpy(alpha[14].glines[3],"X7500D01*",40);
strncpy(alpha[14].glines[4],"Y-11250D01*",40);
strncpy(alpha[14].glines[5],"X-7500D01*",40);
strncpy(alpha[14].glines[6],"M02*",40);
strncpy(alpha[14].glines[7],"",4);

strncpy(alpha[15].glines[0],"G54D548*",40);
strncpy(alpha[15].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[15].glines[2],"Y11250D01*",40);
strncpy(alpha[15].glines[3],"X3750D01*",40);
strncpy(alpha[15].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[15].glines[5],"Y3750D01*",40);
strncpy(alpha[15].glines[6],"X3750Y0D01*",40);
strncpy(alpha[15].glines[7],"X-7500D01*",40);
strncpy(alpha[15].glines[8],"M02*",40);
strncpy(alpha[15].glines[9],"",4);

strncpy(alpha[16].glines[0],"G54D548*",40);
strncpy(alpha[16].glines[1],"X0Y-3750D02*",40);
strncpy(alpha[16].glines[2],"X3750Y-7500D01*",40);
strncpy(alpha[16].glines[3],"X0Y-11250D01*",40);
strncpy(alpha[16].glines[4],"X-3750D01*",40);
strncpy(alpha[16].glines[5],"X-7500Y-7500D01*",40);
strncpy(alpha[16].glines[6],"Y7500D01*",40);
strncpy(alpha[16].glines[7],"X-3750Y11250D01*",40);
strncpy(alpha[16].glines[8],"X3750D01*",40);
strncpy(alpha[16].glines[9],"X7500Y7500D01*",40);
strncpy(alpha[16].glines[10],"Y-3750D01*",40);
strncpy(alpha[16].glines[11],"X3750Y-7500D01*",40);
strncpy(alpha[16].glines[12],"X7500Y-11250D01*",40);
strncpy(alpha[16].glines[13],"M02*",40);
strncpy(alpha[16].glines[14],"",4);

strncpy(alpha[17].glines[0],"G54D548*",40);
strncpy(alpha[17].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[17].glines[2],"Y11250D01*",40);
strncpy(alpha[17].glines[3],"X3750D01*",40);
strncpy(alpha[17].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[17].glines[5],"Y3750D01*",40);
strncpy(alpha[17].glines[6],"X3750Y0D01*",40);
strncpy(alpha[17].glines[7],"X-7500D01*",40);
strncpy(alpha[17].glines[8],"X-3750D02*",40);
strncpy(alpha[17].glines[9],"X7500Y-11250D01*",40);
strncpy(alpha[17].glines[10],"M02*",40);
strncpy(alpha[17].glines[11],"",4);

strncpy(alpha[18].glines[0],"G54D548*",40);
strncpy(alpha[18].glines[1],"X-7500Y-7500D02*",40);
strncpy(alpha[18].glines[2],"X-3750Y-11250D01*",40);
strncpy(alpha[18].glines[3],"X3750D01*",40);
strncpy(alpha[18].glines[4],"X7500Y-7500D01*",40);
strncpy(alpha[18].glines[5],"X-7500Y7500D01*",40);
strncpy(alpha[18].glines[6],"X-3750Y11250D01*",40);
strncpy(alpha[18].glines[7],"X3750D01*",40);
strncpy(alpha[18].glines[8],"X7500Y7500D01*",40);
strncpy(alpha[18].glines[9],"M02*",40);
strncpy(alpha[18].glines[10],"",4);

strncpy(alpha[19].glines[0],"G54D548*",40);
strncpy(alpha[19].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[19].glines[2],"X7500D01*",40);
strncpy(alpha[19].glines[3],"X0D02*",40);
strncpy(alpha[19].glines[4],"Y-11250D01*",40);
strncpy(alpha[19].glines[5],"M02*",40);
strncpy(alpha[19].glines[6],"",4);

strncpy(alpha[20].glines[0],"G54D548*",40);
strncpy(alpha[20].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[20].glines[2],"Y-7500D01*",40);
strncpy(alpha[20].glines[3],"X-3750Y-11250D01*",40);
strncpy(alpha[20].glines[4],"X3750D01*",40);
strncpy(alpha[20].glines[5],"X7500Y-7500D01*",40);
strncpy(alpha[20].glines[6],"Y11250D01*",40);
strncpy(alpha[20].glines[7],"M02*",40);
strncpy(alpha[20].glines[8],"",4);

strncpy(alpha[21].glines[0],"G54D548*",40);
strncpy(alpha[21].glines[1],"X-6150Y11250D02*",40);
strncpy(alpha[21].glines[2],"X975Y-11250D01*",40);
strncpy(alpha[21].glines[3],"X8475Y11250D01*",40);
strncpy(alpha[21].glines[4],"M02*",40);
strncpy(alpha[21].glines[5],"",4);

strncpy(alpha[22].glines[0],"G54D548*",40);
strncpy(alpha[22].glines[1],"X-6150Y11250D02*",40);
strncpy(alpha[22].glines[2],"X-1275Y-11250D01*",40);
strncpy(alpha[22].glines[3],"X975Y0D01*",40);
strncpy(alpha[22].glines[4],"X3600Y-11250D01*",40);
strncpy(alpha[22].glines[5],"X8475Y11250D01*",40);
strncpy(alpha[22].glines[6],"M02*",40);
strncpy(alpha[23].glines[7],"",4);

strncpy(alpha[23].glines[0],"G54D548*",40);
strncpy(alpha[23].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[23].glines[2],"X7500Y11250D01*",40);
strncpy(alpha[23].glines[3],"X-7500D02*",40);
strncpy(alpha[23].glines[4],"X7500Y-11250D01*",40);
strncpy(alpha[23].glines[5],"M02*",40);
strncpy(alpha[23].glines[6],"",4);

strncpy(alpha[24].glines[0],"G54D548*",40);
strncpy(alpha[24].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[24].glines[2],"X0Y0D01*",40);
strncpy(alpha[24].glines[3],"Y-11250D01*",40);
strncpy(alpha[24].glines[4],"Y0D02*",40);
strncpy(alpha[24].glines[5],"X7500Y11250D01*",40);
strncpy(alpha[24].glines[6],"M02*",40);
strncpy(alpha[25].glines[7],"",4);

strncpy(alpha[25].glines[0],"G54D548*",40);
strncpy(alpha[25].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[25].glines[2],"X7500D01*",40);
strncpy(alpha[25].glines[3],"X-7500Y-11250D01*",40);
strncpy(alpha[25].glines[4],"X7500D01*",40);
strncpy(alpha[25].glines[5],"M02*",40);
strncpy(alpha[25].glines[6],"",4);

strncpy(alpha[26].glines[0],"G54D548*",40);
strncpy(alpha[26].glines[1],"X-1875Y-11250D02*",40);
strncpy(alpha[26].glines[2],"X-5625Y-7500D01*",40);
strncpy(alpha[26].glines[3],"Y7500D01*",40);
strncpy(alpha[26].glines[4],"X-1875Y11250D01*",40);
strncpy(alpha[26].glines[5],"X1875D01*",40);
strncpy(alpha[26].glines[6],"X5625Y7500D01*",40);
strncpy(alpha[26].glines[7],"Y-7500D01*",40);
strncpy(alpha[26].glines[8],"X1875Y-11250D01*",40);
strncpy(alpha[26].glines[9],"X-1875D01*",40);
strncpy(alpha[26].glines[10],"X-5625Y-7500D02*",40);
strncpy(alpha[26].glines[11],"X5625Y7500D01*",40);
strncpy(alpha[26].glines[12],"M02*",40);
strncpy(alpha[26].glines[13],"",4);

strncpy(alpha[27].glines[0],"G54D548*",40);
strncpy(alpha[27].glines[1],"X-3750Y7500D02*",40);
strncpy(alpha[27].glines[2],"X0Y11250D01*",40);
strncpy(alpha[27].glines[3],"Y-11250D01*",40);
strncpy(alpha[27].glines[4],"X-3750D02*",40);
strncpy(alpha[27].glines[5],"X3750D01*",40);
strncpy(alpha[27].glines[6],"M02*",40);
strncpy(alpha[27].glines[7],"",4);

strncpy(alpha[28].glines[0],"G54D548*",40);
strncpy(alpha[28].glines[1],"X-7500Y7500D02*",40);
strncpy(alpha[28].glines[2],"X-3750Y11250D01*",40);
strncpy(alpha[28].glines[3],"X3750D01*",40);
strncpy(alpha[28].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[28].glines[5],"Y3750D01*",40);
strncpy(alpha[28].glines[6],"X3750Y0D01*",40);
strncpy(alpha[28].glines[7],"X-3750D01*",40);
strncpy(alpha[28].glines[8],"X-7500Y-3750D01*",40);
strncpy(alpha[28].glines[9],"Y-11250D01*",40);
strncpy(alpha[28].glines[10],"X7500D01*",40);
strncpy(alpha[28].glines[11],"M02*",40);
strncpy(alpha[28].glines[12],"",4);

strncpy(alpha[29].glines[0],"G54D548*",40);
strncpy(alpha[29].glines[1],"X-7500Y7500D02*",40);
strncpy(alpha[29].glines[2],"X-3750Y11250D01*",40);
strncpy(alpha[29].glines[3],"X3750D01*",40);
strncpy(alpha[29].glines[4],"X7500Y7500D01*",40);
strncpy(alpha[29].glines[5],"Y3750D01*",40);
strncpy(alpha[29].glines[6],"X3750Y0D01*",40);
strncpy(alpha[29].glines[7],"X0D01*",40);
strncpy(alpha[29].glines[8],"X3750D02*",40);
strncpy(alpha[29].glines[9],"X7500Y-3750D01*",40);
strncpy(alpha[29].glines[10],"Y-7500D01*",40);
strncpy(alpha[29].glines[11],"X3750Y-11250D01*",40);
strncpy(alpha[29].glines[12],"X-3750D01*",40);
strncpy(alpha[29].glines[13],"X-7500Y-7500D01*",40);
strncpy(alpha[29].glines[14],"M02*",40);
strncpy(alpha[29].glines[15],"",4);

strncpy(alpha[30].glines[0],"G54D548*",40);
strncpy(alpha[30].glines[1],"X7500Y-3750D02*",40);
strncpy(alpha[30].glines[2],"X-7500D01*",40);
strncpy(alpha[30].glines[3],"X3750Y11250D01*",40);
strncpy(alpha[30].glines[4],"Y-11250D01*",40);
strncpy(alpha[30].glines[5],"M02*",40);
strncpy(alpha[30].glines[6],"",4);

strncpy(alpha[31].glines[0],"G54D548*",40);
strncpy(alpha[31].glines[1],"X-7500Y-7500D02*",40);
strncpy(alpha[31].glines[2],"X-3750Y-11250D01*",40);
strncpy(alpha[31].glines[3],"X3750D01*",40);
strncpy(alpha[31].glines[4],"X7500Y-7500D01*",40);
strncpy(alpha[31].glines[5],"Y0D01*",40);
strncpy(alpha[31].glines[6],"X3750Y3750D01*",40);
strncpy(alpha[31].glines[7],"X-7500D01*",40);
strncpy(alpha[31].glines[8],"Y11250D01*",40);
strncpy(alpha[31].glines[9],"X7500D01*",40);
strncpy(alpha[31].glines[10],"M02*",40);
strncpy(alpha[31].glines[11],"",4);

strncpy(alpha[32].glines[0],"G54D548*",40);
strncpy(alpha[32].glines[1],"X-7500Y0D02*",40);
strncpy(alpha[32].glines[2],"X3750D01*",40);
strncpy(alpha[32].glines[3],"X7500Y-3750D01*",40);
strncpy(alpha[32].glines[4],"Y-7500D01*",40);
strncpy(alpha[32].glines[5],"X3750Y-11250D01*",40);
strncpy(alpha[32].glines[6],"X-3750D01*",40);
strncpy(alpha[32].glines[7],"X-7500Y-7500D01*",40);
strncpy(alpha[32].glines[8],"Y3750D01*",40);
strncpy(alpha[32].glines[9],"X0Y11250D01*",40);
strncpy(alpha[32].glines[10],"X3750D01*",40);
strncpy(alpha[32].glines[11],"M02*",40);
strncpy(alpha[32].glines[12],"",4);

strncpy(alpha[33].glines[0],"G54D548*",40);
strncpy(alpha[33].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[33].glines[2],"X7500D01*",40);
strncpy(alpha[33].glines[3],"X-3750Y-11250D01*",40);
strncpy(alpha[33].glines[4],"M02*",40);
strncpy(alpha[33].glines[5],"",4);

strncpy(alpha[34].glines[0],"G54D548*",40);
strncpy(alpha[34].glines[1],"X-3750Y-11250D02*",40);
strncpy(alpha[34].glines[2],"X-7500Y-7500D01*",40);
strncpy(alpha[34].glines[3],"Y-3750D01*",40);
strncpy(alpha[34].glines[4],"X-3750Y0D01*",40);
strncpy(alpha[34].glines[5],"X3750D01*",40);
strncpy(alpha[34].glines[6],"X7500Y3750D01*",40);
strncpy(alpha[34].glines[7],"Y7500D01*",40);
strncpy(alpha[34].glines[8],"X3750Y11250D01*",40);
strncpy(alpha[34].glines[9],"X-3750D01*",40);
strncpy(alpha[34].glines[10],"X-7500Y7500D01*",40);
strncpy(alpha[34].glines[11],"Y3750D01*",40);
strncpy(alpha[34].glines[12],"X-3750Y0D01*",40);
strncpy(alpha[34].glines[13],"X3750D02*",40);
strncpy(alpha[34].glines[14],"X7500Y-3750D01*",40);
strncpy(alpha[34].glines[15],"Y-7500D01*",40);
strncpy(alpha[34].glines[16],"X3750Y-11250D01*",40);
strncpy(alpha[34].glines[17],"X-3750D01*",40);
strncpy(alpha[34].glines[18],"M02*",40);
strncpy(alpha[34].glines[19],"",4);

strncpy(alpha[35].glines[0],"G54D548*",40);
strncpy(alpha[35].glines[1],"X-3750Y-11250D02*",40);
strncpy(alpha[35].glines[2],"X0D01*",40);
strncpy(alpha[35].glines[3],"X7500Y-3750D01*",40);
strncpy(alpha[35].glines[4],"Y7500D01*",40);
strncpy(alpha[35].glines[5],"X3750Y11250D01*",40);
strncpy(alpha[35].glines[6],"X-3750D01*",40);
strncpy(alpha[35].glines[7],"X-7500Y7500D01*",40);
strncpy(alpha[35].glines[8],"Y3750D01*",40);
strncpy(alpha[35].glines[9],"X-3750Y0D01*",40);
strncpy(alpha[35].glines[10],"X7500D01*",40);
strncpy(alpha[35].glines[11],"M02*",40);
strncpy(alpha[35].glines[12],"",4);

strncpy(alpha[36].glines[0],"G54D548*",40);       // amphersand
strncpy(alpha[36].glines[1],"X7500Y-3750D02*",40);
strncpy(alpha[36].glines[2],"X0Y-11250D01*",40);
strncpy(alpha[36].glines[3],"X-3750D01*",40);
strncpy(alpha[36].glines[4],"X-7500Y-7500D01*",40);
strncpy(alpha[36].glines[5],"Y-3750D01*",40);
strncpy(alpha[36].glines[6],"X0Y3750D01*",40);
strncpy(alpha[36].glines[7],"Y7500D01*",40);
strncpy(alpha[36].glines[8],"X-3750Y11250D01*",40);
strncpy(alpha[36].glines[9],"X-7500Y7500D01*",40);
strncpy(alpha[36].glines[10],"Y3750D01*",40);
strncpy(alpha[36].glines[11],"X7500Y-11250D01*",40);
strncpy(alpha[36].glines[12],"M02*",40);
strncpy(alpha[36].glines[13],"",4);

strncpy(alpha[37].glines[0],"G54D548*",40);         // bslash
strncpy(alpha[37].glines[1],"X-7500Y11250D02*",40);
strncpy(alpha[37].glines[2],"X7500Y-11250D01*",40);
strncpy(alpha[37].glines[3],"M02*",40);
strncpy(alpha[37].glines[4],"",4);

strncpy(alpha[38].glines[0],"G54D548*",40);           // comma
strncpy(alpha[38].glines[1],"X0Y-7500D02*",40);
strncpy(alpha[38].glines[2],"Y-11250D01*",40);
strncpy(alpha[38].glines[3],"X-3750Y-15000D01*",40);
strncpy(alpha[38].glines[4],"M02*",40);
strncpy(alpha[38].glines[5],"",4);

strncpy(alpha[39].glines[0],"G54D548*",40);       // copyright
strncpy(alpha[39].glines[1],"X4167Y-4167D02*",40);
strncpy(alpha[39].glines[2],"X2083Y-6250D01*",40);
strncpy(alpha[39].glines[3],"X-2083D01*",40);
strncpy(alpha[39].glines[4],"X-4167Y-4167D01*",40);
strncpy(alpha[39].glines[5],"Y4167D01*",40);
strncpy(alpha[39].glines[6],"X-2083Y6250D01*",40);
strncpy(alpha[39].glines[7],"X2083D01*",40);
strncpy(alpha[39].glines[8],"X4167Y4167D01*",40);
strncpy(alpha[39].glines[9],"G54D645*",40);
strncpy(alpha[39].glines[10],"X0Y0D03*",40);
strncpy(alpha[39].glines[11],"M02*",40);
strncpy(alpha[39].glines[12],"",4);

strncpy(alpha[40].glines[0],"G54D548*",40);         // dash
strncpy(alpha[40].glines[1],"X-7500Y0D02*",40);
strncpy(alpha[40].glines[2],"X7500D01*",40);
strncpy(alpha[40].glines[3],"M02*",40);
strncpy(alpha[40].glines[4],"",4);

strncpy(alpha[41].glines[0],"G54D548*",40);         // dot
strncpy(alpha[41].glines[1],"X3750Y-11250D02*",40);
strncpy(alpha[41].glines[2],"Y-6250D01*",40);
strncpy(alpha[41].glines[3],"M02*",40);
strncpy(alpha[41].glines[4],"",4);

strncpy(alpha[42].glines[0],"G54D548*",40);            // forward slash
strncpy(alpha[42].glines[1],"X-7500Y-11250D02*",40);
strncpy(alpha[42].glines[2],"X7500Y11250D01*",40);
strncpy(alpha[42].glines[3],"M02*",40);
strncpy(alpha[42].glines[4],"",4);

}  // end init_alpha_glines


int isvalid( double myX , double myY, int okval, double tsize)
{
double myY1;
int result;

    result = 0;
    if( myX >= 0)
	{
       myX = myX + tsize/2;
    }
    else
	{
       myX = myX - tsize/2;
    }

    if( myY  >= 0)
	{
       myY  = myY + tsize/2;
       myY1 = myY - tsize/2;
    }
    else
	{
       myY  = myY - tsize/2;
       myY1 = myY + tsize/2;
    }
    if( (myX >= -1544000 )&& (myX <= 1544000) &&
		(myY >= -1544000) && ( myY  <= 1544000) && (okval == 1))
	{
       result =1;
    }

    // prevent test mark placement in alignment mark area

    if( (myX  < -1525000 || myX > 1525000) && (myY1  < 250000 && myY1  > -250000))
	{
       result = 0;
    }
   return(result );
}

long GetTheFileSize(const TCHAR *fileName)
{
    BOOL                        fOk;
    WIN32_FILE_ATTRIBUTE_DATA   fileInfo;

    if (NULL == fileName)
        return -1;

    fOk = GetFileAttributesEx(fileName, GetFileExInfoStandard, (void*)&fileInfo);
    if (!fOk)
        return -1;
  //  assert(0 == fileInfo.nFileSizeHigh);
    return (long)fileInfo.nFileSizeLow;
}

int file_not_empty( char *infilestr)
{
	if (file_exists(infilestr)  && ( GetTheFileSize( infilestr) > 0 ) )
	{
		return(TRUE);
	}
    else
	{
		return(FALSE);
	}
}   // end file_not_empty


// get the begin part of a fully qualified path name ( up to last / )

void get_full_path_begin( char *instr, char *outstr)
{
int ii;
char tempstr[200];
int lastsep;

	strncpy(tempstr, instr,200);
    lastsep=-1;

	ii=0;
	while(ii < (signed int) strlen(tempstr) )
	{

		if ( tempstr[ii] == '\\' )
		{
			lastsep=ii;
		}

		if ( tempstr[ii] == '/' )
		  {
			  lastsep=ii;
		  }

	  ii += 1;
	}

  if (lastsep != -1)
  {

    tempstr[lastsep]='\0';
	strncpy(outstr,tempstr,200);

  }
  else
  {
	  strncpy(outstr,"",4);
  }

} // get_full_path_begin

// get the end part of a fully qualified path name

void get_full_path_end( char *instr, char *outstr)
{
int ii;
char tempstr[200];
int lastsep;

	strncpy(tempstr, instr,200);
    lastsep=-1;

	ii=0;
	while(ii < (signed int) strlen(tempstr) )
	{

		if ( tempstr[ii] == '\\' )
		{
			lastsep=ii;
		}

	    if ( tempstr[ii] == '/' )
		  {
			  lastsep=ii;
		  }
	  ii += 1;
	}

  if (lastsep != -1)
  {
	  for(ii=lastsep+1; ii < (signed int) strlen(tempstr); ii += 1)
	  {
		  *outstr=tempstr[ii];
		  outstr++;
	  }
	  *outstr='\0';
  }
  else
  {
	  strncpy(outstr,tempstr,200);
  }

} // get_full_path_end


// check to see if two files are identical
//
int diff_files( char *infile1str, char *infile2str)
{
FILE *file1;
FILE *file2;
int diffs_found;
int endoffile1;
int endoffile2;
char file1line[300];
char file2line[300];

  diffs_found=FALSE;

  file1 = fopen(infile1str,"r");
  if (file1==NULL)
  {
	  printf("In diff_files, unable to open the input file = %s \n",infile1str);
	  exit(-1);
  }
  file2 = fopen(infile2str,"r");
  if (file2==NULL)
  {
	  printf("In diff_files, unable to open the input file = %s \n",infile1str);
	  exit(-1);

  }

  endoffile1 = getline(file1,file1line);
  endoffile2 = getline(file2,file2line);

  while( ( endoffile1 == FALSE) && (endoffile2 == FALSE))
  {
	  if (strcmp(file1line,file2line) != 0 )
	  {
		  diffs_found=TRUE;
	  }

	endoffile1 = getline(file1,file1line);
	endoffile2 = getline(file2,file2line);
  }

  fclose(file1);
  fclose(file2);

  if (endoffile1 != endoffile2)
  {
	  diffs_found= TRUE;
  }

  return(diffs_found);

}  // diff_files

int file_is_readable( char *infile)
{
int retcode;


	retcode = _access( infile, 4 );

	if (retcode == 0 )
	{
		return(TRUE);
	}
	else
	{
		return(FALSE);
	}

}

int file_is_writeable( char *infile)
{
int retcode;


	retcode = _access( infile, 2 );

    if (retcode == 0 )
	{
		return(TRUE);
	}
	else
	{
		return(FALSE);
	}

}

// replace the extention on the end of a file name from
// one name to another
//

void replace_ext( char *fromstr, char *tostr, char *extstr)
{
char tstr[400];

char *dotptr;
int ii;

  strncpy(tstr,fromstr,120);

  dotptr = strstr( tstr,".");

  if (dotptr != NULL)
  {
	ii=0;
	while( (extstr[ii] != 0 ) && ( ii < (signed int) strlen(extstr)))
	{
		*dotptr= extstr[ii];
	//	printf("adding %c\n", extstr[ii]);
		dotptr++;
		ii++;
	}
    *dotptr=0;
	strncpy(tostr,tstr,120);
  }
  else
  {

   printf("Internal error \n");
  }

}

// convert the month and day srings to an integer equal to day of year

int monthday_toyearday( char *month, char *day)
{
int addval;
int dayval;
int ii;

    dayval=atoi(day);

	for(ii=0;ii< (signed int) strlen(month); ii += 1)
	{
		month[ii]=tolower(month[ii]);
	}

	if (strstr(month,"jan")!=NULL)
	{
		addval=0;
	}
    if (strstr(month,"feb")!=NULL)
	{
		addval=29;
	}
    if (strstr(month,"mar")!=NULL)
	{
		addval=59;
	}
    if (strstr(month,"apr")!=NULL)
	{
		addval=90;
	}
	if (strstr(month,"may")!=NULL)
	{
		addval=120;
	}
    if (strstr(month,"jun")!=NULL)
	{
		addval=151;
	}
    if (strstr(month,"jul")!=NULL)
	{
		addval=181;
	}
    if (strstr(month,"aug")!=NULL)
	{
		addval=212;
	}

   if (strstr(month,"sep")!=NULL)
	{
		addval=242;
	}
    if (strstr(month,"oct")!=NULL)
	{
		addval=273;
	}
    if (strstr(month,"nov")!=NULL)
	{
		addval=303;
	}
    if (strstr(month,"dec")!=NULL)
	{
		addval=333;
	}

  return(addval+dayval);
}

int file_is_executable( char *infile)
{
int retcode;


	retcode = _access( infile, 2 );
    if (retcode == 0 )
	{
		return(TRUE);
	}
	else
	{
		return(FALSE);
	}

}

// substitute one string in another
//  like the awk gsub but without regexes etc
//
void gsubs( char *findstr, char *repstr, char *tostr)
{
char tempstr[300];
char temp1str[500];
char *tptr;
int kk,ll;

  while( strstr(tostr,findstr) != NULL)
  {
    strncpy(tempstr,tostr,300);
	tptr=strstr(tempstr,findstr);   // get the to str up to the first findstr
	if (tptr != NULL)
	{
	   *tptr='\0';
	   strncpy(temp1str,tempstr,300);   // add on the replacement
	   strncat(temp1str,repstr,200);
 	   kk=strlen(tempstr) + strlen(findstr);

	   ll=strlen(temp1str);
	   while((tempstr[kk] != '\0') && ( kk < 300))
	   {
		temp1str[ll]=tempstr[kk];
		ll +=1;
		kk +=1;
	   }
	  strncpy(tostr,temp1str,300);
	}
  }

}  // gsubs

// substitute one string in another
//  like the awk sub but without regexes etc
//
void subs( char *findstr, char *repstr, char *tostr)
{
char tempstr[300];
char temp1str[500];
char *tptr;
int kk,ll;


  if( strstr(tostr,findstr) != NULL)
  {
    strncpy(tempstr,tostr,300);
	tptr=strstr(tempstr,findstr);   // get the to str up to the first findstr
	if (tptr != NULL)
	{
	   *tptr='\0';
	   strncpy(temp1str,tempstr,300);   // add on the replacement
	   strncat(temp1str,repstr,200);
 	   kk=strlen(tempstr) + strlen(findstr);  // add on the rest of the string

	   ll=strlen(temp1str);
	   while((tempstr[kk] != '\0') && ( kk < 300))
	   {
		temp1str[ll]=tempstr[kk];
		ll +=1;
		kk +=1;
	   }
	  strncpy(tostr,temp1str,300);
	}
  }

}  // subs



//
// returns the time the file last modified in ctime format
//
int get_file_modtime( char *filename)
{
   struct _stat buf;
   int result;
  // char timebuf[26];
  // errno_t err;

   // Get data associated with "crt_stat.c":
   result = _stat( filename, &buf );

   // Check if statistics are valid:
   if( result != 0 )
   {
      printf( "In get_file_modtime, Problem getting information\n" );
      switch (errno)
      {
         case ENOENT:
           printf("File %s not found.\n", filename);
           break;
         case EINVAL:
           printf("Invalid parameter to _stat.\n");
           break;
         default:
           /* Should never be reached. */
           printf("Unexpected error in _stat.\n");

      }
	  return(-1);
   }
   else
   {
	  return( buf.st_mtime);
   }

}
//
// returns the size of the file
//
int get_file_size( char *filename)
{
   struct _stat buf;
   int result;


   // Get data associated with "crt_stat.c":
   result = _stat( filename, &buf );

   // Check if statistics are valid:
   if( result != 0 )
   {
      printf( "In get_file_modtime, Problem getting information\n" );
      switch (errno)
      {
         case ENOENT:
           printf("File %s not found.\n", filename);
           break;
         case EINVAL:
           printf("Invalid parameter to _stat.\n");
           break;
         default:
           /* Should never be reached. */
           printf("Unexpected error in _stat.\n");

      }
	  return(-1);
   }
   else
   {
	  return( buf.st_size);
   }

}  // get_file_size

// check to see which file is newer( modify time of file1 > modify time of file 2)
//
//
int is_newer( char *infile1str, char *infile2str)
{
 int modtime1;
 int modtime2;


  modtime1 = get_file_modtime( infile1str);
  modtime2 = get_file_modtime( infile2str);

  if ( modtime1 > modtime2)
  {
	  return(TRUE);
  }
  else
  {
	  if (modtime1 == modtime2 )
	  {
		  return(TRUE);
	  }
	  else
	  {
		  return(FALSE);
	  }
  }

}   // is_newer

//
//  get_month_number   given a string for month, return its number from
//     1-12

int get_month_number( char *inmonthstr)
{
int kk;
char monthstr[300];

  kk=0;
  while(kk < (signed int) strlen( inmonthstr) )
  {
	  monthstr[kk] = tolower(inmonthstr[kk]);
      kk += 1;
  }
  monthstr[kk]='\0';

  if (strstr(monthstr,"jan")!=NULL)
  {
	  return(1);
  }
  if (strstr(monthstr,"feb")!=NULL)
  {
	  return(2);
  }
  if (strstr(monthstr,"mar")!=NULL)
  {
	  return(3);
  }
  if (strstr(monthstr,"apr")!=NULL)
  {
	  return(4);
  }
  if (strstr(monthstr,"may")!=NULL)
  {
	  return(5);
  }
  if (strstr(monthstr,"jun")!=NULL)
  {
	  return(6);
  }
  if (strstr(monthstr,"jul")!=NULL)
  {
	  return(7);
  }
  if (strstr(monthstr,"aug")!=NULL)
  {
	  return(8);
  }
  if (strstr(monthstr,"sep")!=NULL)
  {
	  return(9);
  }
  if (strstr(monthstr,"oct")!=NULL)
  {
	  return(10);
  }
  if (strstr(monthstr,"nov")!=NULL)
  {
	  return(11);
  }
  if (strstr(monthstr,"dec")!=NULL)
  {
	  return(12);
  }

  return(0);

}  // end get_month_number

int hasupper( char *instr)
{
int kk;

kk = 0;

 while(kk < ( signed int) strlen(instr) )
 {
         if (isupper( instr[kk]) )
         {
                 return(TRUE);
         }
  kk += 1;
 }

 return(FALSE);
}  // end hasupper

int hasdigit( char *instr)
{
int kk;

kk = 0;

 while(kk < ( signed int) strlen(instr) )
 {
         if (isdigit( instr[kk]) )
         {
                 return(TRUE);
         }
  kk += 1;
 }

 return(FALSE);

}  // end hasdigit

int strtoks( char *instr, char *file_sep, char *token, int in_index)
{
int tindex;
int i;

  tindex = in_index;
  i=0;
  while( (instr[tindex] != *file_sep) && ( instr[tindex] != '\0') && (
	   instr[tindex] != '\n') && (tindex < 120))
  {

	   token[i] = instr[tindex];
	   tindex += 1;
	   i += 1;
  }

  token[i] = '\0';

  return( tindex + 1);
}

int split_line_seper( char *tline, char *file_sep)
{
int ii;
char tstr[200];
char this_token[100];
int newindex;
int index;

 ii = 0;

 strncpy( tstr, tline,200);

 index=0;
 newindex = strtoks( tstr,file_sep,this_token,index);

 while((ii < 20) && ( newindex < 120) )
	{
      strncpy( str_array[ii], this_token, 120);

      ii += 1;
	  index = newindex;
	  newindex = strtoks( tstr,file_sep, this_token,index);

	}

 // for (jj=0; jj <ii ; jj += 1)
 //{
 //	 printf("str_array[%d] = %s \n",jj,str_array[jj]);
 //}

 return(ii);

} // end split_line_seper

// replace all the occurances in a string of old string with newstring
//

char *replace(char *string, char *oldpiece, char *newpiece)
 {

   int str_index, newstr_index, oldpiece_index, end,

      new_len, old_len, cpy_len;
   char *c;
   static char newstring[500];

   if ((c = (char *) strstr(string, oldpiece)) == NULL)

      return string;

   new_len        = strlen(newpiece);
   old_len        = strlen(oldpiece);
   end            = strlen(string)   - old_len;
   oldpiece_index = c - string;


   newstr_index = 0;
   str_index = 0;
   while(str_index <= end && c != NULL)
   {

      /* Copy characters from the left of matched pattern occurence */
      cpy_len = oldpiece_index-str_index;
      strncpy(newstring+newstr_index, string+str_index, cpy_len);
      newstr_index += cpy_len;
      str_index    += cpy_len;

      /* Copy replacement characters instead of matched pattern */
      strcpy(newstring+newstr_index, newpiece);
      newstr_index += new_len;
      str_index    += old_len;

      /* Check for another pattern match */
      if((c = (char *) strstr(string+str_index, oldpiece)) != NULL)
         oldpiece_index = c - string;


   }
   /* Copy remaining characters from the right of last matched pattern */    strcpy(newstring+newstr_index, string+str_index);
   return newstring;
}

// split a string in two pieces

// calling syntax gettext -v brd="brdname" -v lang="language" -v rev="rev number"

//
//  split the time string and put the results in time_array
//
int split_time( char *tline)
{
int ii;
char tstr[200];
char *token;


 ii = 0;

 strncpy( tstr, tline,200);

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( time_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_time

// remove LPC and LPD from a file
//

void remove_lpc( char *infilestr, char *outfilestr)
{
FILE *infile,*outfile;
char thisline[300];
int endoffile;
 int debug;

 debug=0;

 if (debug)
   {
    printf("In remove_lpc , input file = %s outfile = %s \n",infilestr, outfilestr);
   }

   infile=fopen(infilestr,"r");

   if (infile != NULL)
   {
	   printf("Unable to open the input file = %s \n",infilestr);
   }

   outfile=fopen(outfilestr,"w");

   if (infile != NULL)
   {
	   printf("Unable to open the input file = %s \n",infilestr);
   }
   endoffile=getline(infile,thisline);

   while(endoffile==FALSE)
   {
	   if (strstr(thisline,"LP")== NULL)    // LPC or LPD not found
	   {
		   fprintf(outfile,"%s",thisline);
	   }

	endoffile=getline(infile,thisline);
   }

   fclose(infile);
   fclose(outfile);

}  // end remove_lpc

//
// Check to see if three x,y points are collinear
//
int points_3_collinear( double x1, double y1, double x2, double y2, double x3, double y3)
{
double prod1;
double prod2;
double prod3;

    prod1 = x1 * ( y2 - y3);
	prod2 = x2 * ( y3 - y1);
	prod3 = x3 * ( y1 - y2);

    if (( prod1 + prod2 + prod3 ) == 0 )
	{
		return(1);
	}
	else
	{
		return(0);
	}

}   // 3 points collinear

//
//  grep thru a file and remove lines that contain excludestr
//

void exclude_grep( char *infilestr, char *excludestr, char *outfilestr)
{
FILE *infile;
FILE *outfile;
char thisline[300];
int endoffile;


 infile=fopen(infilestr,"r");

 if (infile==NULL)
 {
	 printf("In exclude_grep, unable to open the input file = %s \n", infilestr);
	 exit(-1);
 }

 outfile=fopen(outfilestr,"w");
 if (outfile==NULL)
 {
	 printf("In exclude_grep, unable to open the input file = %s \n", outfilestr);
	 exit(-1);
 }

 endoffile=getline(infile,thisline);

 while(endoffile==FALSE)
 {
	 if (strstr(thisline, excludestr) == NULL)
	 {
		 fprintf(outfile,"%s",thisline);
	 }

    endoffile=getline(infile,thisline);
 }

 fclose(infile);
 fclose(outfile);

}  // end 


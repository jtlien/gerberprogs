#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>


#include "dirent.h"

#define WINDOWS 1
#define MAXSTRING 256

char str_array[120][120];
char scan_array[1000][256];
char cp_list[1000][256];
char grep_array[1000][256];
char time_array[20][300];
char dirsep[10];

char dayofweekstr[120];
char monthstr[120];
char daystr[120];
char timeofdaystr[120];
char yearstr[120];

char glines[40][40];

struct xytype{
	double x;
	double y;
	char rest[20];
} ;

struct xytype xyarray[100000];


struct alphastuff
{
	char gchar;
	char glines[40][40];
} alpha[44];

//
// windows version of time
//
char *gettime_str( );

void get_date( char *outstr);

int dir_exists( char *dirname);

void rm_file( char *filestr);

void get_whoami( char *outstr);

void getwd( char *wdbuff);

int split_line_seps( char *tline, char *file_sep);

int split_line_seper( char *tline, char *file_sep);

int awk_index( char *instr, char *inchr);

void awk_substr( char *instr, int sbegin, int slength, char *resultstr);

void move_one_file( char *infile, char *outfile);

void mv_a_file( char *infile, char *outfile);

int scandir_matchext(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr);		// starting dir, could be an arbitrary label

int scandir_matchext_count(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr);		// starting dir, could be an arbitrary label

int scandir_matchbase(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr);		// starting dir, could be an arbitrary label

int scandir_matchall(const char* dir,	// starting directory (absolute or relative)
		int recurse);		// 1 to recurse in subdirectory

int scandir_matchalldir(const char* dir,	// starting directory (absolute or relative)
		int recurse);		// 1 to recurse in subdirectory

void split( char *instr, char *outstr1, char *outstr2, char *srchstr);

int split_line( char *tline);

void subexten( char* instr, char *outstr, char *newext);

int getline( FILE *infile, char *tline);  // get a line of input

int getlinet( FILE *infile, char *tline);  // get a line of input, save tabs

int getlined( FILE *infile, char *tline, int dbg);

void mvall( char *fromext, char *toext );

int sgrep( char *infilestr, char *searchstr,int arraysize);

int grep_count( char *infilestr, char *searchstr, int *linecount);

int grep_counter( char *infilestr, char *searchstr, int *linecount);

int grep_count2( char *infilestr, char *searchstr1, char *searchstr2, int *linecount);

int grep_ignore_count( char *infilestr, char *searchstr, int *linecount);

void ssed( char *infilestr,char *fromstr, char *tostr, char *outfilestr);

int file_exists( char *infile);

void rm_all_ext( char *subdir, char *extstr);

void rm_all_keep_ext2( char *subdir, char *extstr1, char *extstr2);

void rm_all_base( char *subdir, char *basestr);

void copy_one_file( char *infile, char *outfile);

void cp_file( char *infile, char *outfile);

void cp_files_ext( char *frsubdir, char *extstr, char *tosubdir);

void cp_files_base( char *frsubdir, char *basestr, char *tosubdir);

int rmmo2_call_out( char *file1str, char *file2str);

int rmmo2_fix_call_out( char *file1str, char *file2str);

void rmmo2_truncate_call_out( char *file1str, char *file2str);

void cp_file_tosub(  char *infile1_str, char *outsubdir, char *outfile_str);

void cp_file_from_to( char *insubdir, char *infile1_str, char *outsubdir, char *outfile_str);

void cv_tolower( char *instr, char *outstr);

void change_dir( char *dirname);

int count_lines( char *infilestr);

void cv_toupper( char *instr, char *outstr);

void cat_files( char *infile1_str, char *infile2_str, char *outfile_str);

void cat_3files( char *infile1_str, char *infile2_str, char *infile3_str,char *outfile_str);

void cat_4files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str,char *outfile_str);

void cat_5files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *outfile_str);

void cat_6files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *outfile_str);

void cat_7files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str,
				 char *outfile_str);

void cat_8files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str,
				 char *outfile_str);

void cat_9files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *outfile_str);

void cat_10files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str,
				 char *outfile_str);

void cat_11files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str, char *infile11_str,
				 char *outfile_str);

void cat_12files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str,char *infile11_str,char *infile12_str,
				 char *outfile_str);
void cat_13files( char *infile1_str, char *infile2_str, char *infile3_str,
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str, char *infile11_str, char *infile12_str,
				 char *infile13_str,
				 char *outfile_str);

void rm_files_ext( char *extstr);

void rm_files_base( char *basestr);

void rm_sub_file( char *dirname, char *filename);

int  sortxy_compare( const struct xytype *inxy1, const  struct xytype *inxy2);

void sortxy( char *infilestr, char *outfilestr);

int cp_files_dir_ext( char *fromdirstr, char *extstr, char *todirstr);

void mv_ext_ext( char *ext1str, char *ext2str);

void rm_dir_files( char *dirnamestr);

void chmod_file( int modval, char *infilestr);

void cp_file_fromsub(char *subdir, char *infile1_str, char *outfile_str);

int mindiff( int *myarray, int cnt );

void placestandard_out( double x, double y, FILE *ofile);

void placestandard( double x, double y);

void uniq_lines( char *infilestr, char *outfilestr);

void grep_file_append( char *searchstr, char *infilestr, char *outfilestr);

void grep_file_to_file( char *searchstr, char *infilestr, FILE *outfile);

void grep_file_write( char *searchstr, char *infilestr, char *outfilestr);

void init_alpha_glines( );

int isvalid( double myX , double myY, int okval, double tsize);

long GetTheFileSize( const TCHAR *infilestr);

int file_not_empty( char *infilestr);

void get_full_path_begin( char *instr, char *outstr);

void get_full_path_end( char *instr, char *outstr);

int diff_files( char *infile1str, char *infile2str);

void print_file( char *infilestr);

int file_is_readable( char *infile);

int file_is_writeable( char *infile);

int file_is_executable( char *infile);

void replace_ext( char *fromstr, char *tostr, char *extstr);

int monthday_toyearday( char *monthstr, char *daystr);

int get_file_size( char *filename);

int get_file_modtime( char *filename);

int is_newer( char *infile1str, char *infile2str);

int is_ordinary( char *infilestr);

int get_month_number( char *inmonthstr);

int hasdigit( char *instr);

int hasupper( char *instr);

void subs( char *modstr, char *fromstr, char *tostr);

void gsubs( char *modstr, char *fromstr, char *tostr);

char *replace(char *string, char *oldpiece, char *newpiece);

int split_time (char *instr);

void remove_lpc( char *infilestr, char *outfilestr);

int points_3_collinear( double x1, double y1, double x2, double y2, double x3, double y3);

void exclude_grep( char *infilestr, char *instr, char *outfilestr);

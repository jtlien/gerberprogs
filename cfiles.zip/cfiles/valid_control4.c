#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

// This version of valid_control4 combines the 
//      valid_control_cply and valid_control_maxtek using an added flag
//    type_flag, 0 == normal, 1= cply 2=maxtek, 3 =

char fname_array[500][120];
int fname_count;


//
// search thru the array of fnames
//
int found_in_fname( char *instr)
{
int ii;
int fname_found;

 ii = 0;
 fname_found=FALSE;
 while( ( ii < fname_count) && ( ii < 500))
 {
	// printf("In found_in_fname compare = %s %s \n",instr, fname_array[ii]);

	 if (strcmp(instr,fname_array[ii]) == 0 )
	 {
		 fname_found=TRUE;
		 return(TRUE);
	 }
	ii += 1;
 }

 return(FALSE);


} // find_in_fname

// nmstr = partnumber
// pcmtypestr = 5layer, 7layer etc
// f1str = makelog file
// infilestr = control/layers
// type_flag == 0 indicates norm 
// type_flag == 1 indicates cply
// type_flag == 2 indicates maxtek

int valid_control4_call( char *nmstr, char *pcmtypestr, char *f1str, char* infstr,
						int type_flag)
{
int exitvalue;
int thru;
int buried;
char parttype[120];
char thisline[200];
char namestr[200];
char tmpnum[200];
char tmp1[200];
int mfglayer[300];
int minus_mfglayer[300];
char file1str[200];
int absval;
int i;
int j;
int kk;
int maxlayer;
int nf;
int endoffile;
int testin_count;
int blindout_count;

FILE *infile;
FILE *file1;

char num[200];

char ltmp[10][120];
char ptmp[10][120];
char tmp[10][120];
char tstr[200];
int maxtek_flag;
int use_type_flag;
int debug;

    debug=0;

	use_type_flag = type_flag;

	if (type_flag == 2)   // type_flag == 2 indicate maxtek type
	{
      use_type_flag = 0;
	  maxtek_flag = TRUE;
	}
	else
	{
		maxtek_flag = FALSE;
	}

	strncpy(namestr,nmstr,120);
	strncpy(num,pcmtypestr,120);

	strncpy( file1str,f1str,120);

	fname_count = 0;

	for(kk = 0; kk < 300; kk += 1)
	{
		minus_mfglayer[kk] = 0;
		mfglayer[kk] = 0;
	}

	file1=fopen(file1str,"r");
	if (file1 == NULL)
	{
		printf("ERROR: valid_control4 unable to open input file = %s \n", file1str);
		exit(-1);
	}

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

	ptmp[0][0]='\0';
	ptmp[1][0]='\0';
	ltmp[0][0]='\0';
	ltmp[1][0]='\0';

    while( endoffile== FALSE )
	{
        if( strstr(thisline,"Part Type" ) != NULL )
		{
          split(thisline,ptmp[0],ptmp[1],":");
        }
        if( strstr(thisline,"Layers") != NULL)
		{
          split(thisline,ltmp[0],ltmp[1],":");
        }
	  endoffile=getline(file1,thisline);
	  nf=split_line(thisline);

    }

	fclose(file1);

    //parttype = (ptmp[2] "," ltmp[2])

	strncpy(parttype,ptmp[1],120);
	strncat(parttype,",",4);
	strncat(parttype,ltmp[1],60);

	if (debug) { printf("parttype = %s \n",parttype); }

    // print "PARTTYPE "  parttype
    exitvalue = 0;
    thru = 0;
    buried = 0;


    awk_substr(num,1,1,tmpnum);

    // printf( "tmpnum = %s", tmpnum);
    
	// check to see if valid type layer combination

    if (( strcmp(parttype,"wlbi,5") != 0 ) &&
		( strcmp(parttype,"wlbi,7") != 0 ) && 
		( strcmp(parttype,"scm,3" ) != 0 ) &&
		( strcmp(parttype,"scm,5" ) != 0 ) &&
		( strcmp(parttype,"scm,7" ) != 0 ) )
	{
       printf("%s \n",parttype);
       printf("ERROR: Don't know how to process %s layer %s\n",ltmp[1],ptmp[1]);
       exitvalue = 92; 
       exit(exitvalue);
    }
    

   testin_count = 0;
   blindout_count = 0;

   infile=fopen(infstr,"r");
   if (infile == NULL)
	{
		printf("ERROR: valid_control4 unable to open input file = %s \n", infstr);
		exit(-1);
	}
   endoffile=getline(infile, thisline);
   nf= split_line(thisline);

   while(endoffile==FALSE)
   {
    split(str_array[1],tmp[0],tmp[1],".");

	//printf("tmp 0 = %s str_array 1 = %s  \n",tmp[0], str_array[1]);
    if ( found_in_fname(tmp[0]) )
	{
	 printf("ERROR: duplicate filenames in %s.ctl \n",namestr);
	 printf( "   %s ",thisline); 
	 printf( "  %s \n",tmp[0]);
        exitvalue = 99;
    }
    else
	{
      if (fname_count < 500 )                 //add_to_fname(tmp[0]); 
	  {
		  //printf("Adding to fname = %s \n",tmp[0]);

		  strncpy(fname_array[fname_count],tmp[0],120);
		  fname_count += 1;
	  }
	  else
	  {
		  printf("In valid_control4, number of files exceeds 500 \n");
		  exit(-1);
	  }
    }

    if (strcmp(str_array[3],"NA") != 0)
	{
	  if ( atoi(str_array[3]) > -1 )
	  {
	   if ( mfglayer[atoi(str_array[3])] != 0)
	   {
	    printf("ERROR: duplicate mfg layer numbers in %s.ctl \n",namestr);
	    printf( "  %s \n", thisline);
	    printf( "  %s \n",str_array[3]);
	    exitvalue = 98;
	   }
	   else
	   {
	    mfglayer[ atoi( str_array[3])] = 1;
	   }
	  }
	  else
	  {

	   absval=abs(atoi(str_array[3]));

	   if ( minus_mfglayer[absval] != 0)
	   {
	    printf("ERROR: duplicate mfg layer numbers in %s.ctl \n",namestr);
	    printf( "  %s \n", thisline);
	    printf( "  %s \n",str_array[3]);
	    exitvalue = 98;
	   }
	   else
	   {
	    minus_mfglayer[ absval] = 1;
	   }

	  }
    }
    
    //tmp1 = tolower($4);
	strncpy(tmp1,str_array[3],120);
	kk=0;
	while( kk < (signed int) strlen(str_array[3]) )
	{
		tmp1[kk] = tolower( tmp1[kk]);
		kk += 1;
	}

    if(( strcmp(tmp1,"na") != 0 ) && (strcmp(str_array[4],"PosLg") !=  0) &&
		                (strcmp(str_array[4],"PosSm") !=  0) && 
						(strcmp(str_array[4],"NegLg") !=  0) && 
						(strcmp(str_array[4],"NegSm") !=  0) )
						
	{
	 printf("ERROR: improper photo type = %s in  %s.ctl \n", str_array[4],namestr);
	 printf("   %s \n",thisline); 
	 exitvalue = 97;
    }
 
    // check to see if layer is an allowed layer

	if(( strcmp(str_array[2],"TSOLDER") != 0 ) &&
       (strcmp(str_array[2],"TSM") != 0 ) &&
       (strcmp(str_array[2],"BLINDOUT") != 0 ) &&
       (strcmp(str_array[2],"TESTIN") != 0 ) &&
	   (strcmp(str_array[2],"TESTINP") != 0 ) &&        // plating type layer
       (strcmp(str_array[2],"METAL") != 0 ) &&
       (strcmp(str_array[2],"CORE") != 0 ) &&
       (strcmp(str_array[2],"BSM" ) != 0 ) &&
       (strcmp(str_array[2],"BSOLDER") != 0 ) &&
       (strcmp(str_array[2],"THRU") != 0 ) &&
       (strcmp(str_array[2],"BURIED") != 0 ) && 
       (strcmp(str_array[2],"STIFF")  != 0 ) &&
       (strcmp(str_array[2],"OUTLINE") != 0 ) &&
       (strcmp(str_array[2],"STENCIL") != 0 ) &&
       (strcmp(str_array[2],"CUTOUT") != 0 ) &&
       (strcmp(str_array[2],"DRILL")  != 0 ) &&
       (strcmp(str_array[2],"RESISTOR")  != 0 ) && (use_type_flag == 0 ))
	   {
 	    printf( "ERROR:  %s  layer type %s.ctl not supported \n",str_array[2],namestr);
	   exitvalue = 96;
	   }
      if(( strcmp(str_array[2],"TSOLDER") != 0 ) &&   // cply_case
       (strcmp(str_array[2],"TSM") != 0 ) &&
	   (strcmp(str_array[2],"TSP") != 0 ) &&
       (strcmp(str_array[2],"BLINDOUT") != 0 ) &&
	   (strcmp(str_array[2],"BLINDOUT2") != 0 ) &&
       (strcmp(str_array[2],"TESTIN") != 0 ) &&
	   (strcmp(str_array[2],"TESTINP") != 0 ) &&
       (strcmp(str_array[2],"METAL") != 0 ) &&
       (strcmp(str_array[2],"CORE") != 0 ) &&
       (strcmp(str_array[2],"BSM" ) != 0 ) &&
	   (strcmp(str_array[2],"BSP" ) != 0 ) &&
       (strcmp(str_array[2],"BSOLDER") != 0 ) &&
       (strcmp(str_array[2],"THRU") != 0 ) &&
       (strcmp(str_array[2],"BURIED") != 0 ) && 
       (strcmp(str_array[2],"STIFF")  != 0 ) &&
       (strcmp(str_array[2],"OUTLINE") != 0 ) &&
       (strcmp(str_array[2],"STENCIL") != 0 ) &&
       (strcmp(str_array[2],"CUTOUT") != 0 ) &&
       (strcmp(str_array[2],"DRILL")  != 0 ) &&
	   (strcmp(str_array[2],"CPLY1")  != 0 ) &&
	   (strcmp(str_array[2],"CPLY2")  != 0 ) &&
       (strcmp(str_array[2],"RESISTOR")  != 0 ) && (use_type_flag == 1 ))
	   {
 	    printf( "ERROR:  %s  layer type %s.ctl not supported \n",str_array[2],namestr);
	   exitvalue = 96;
	   }
	  
	  if(( strcmp(str_array[2],"TSOLDER") != 0 ) &&   // 180 case
       (strcmp(str_array[2],"TSM") != 0 ) &&
	   (strcmp(str_array[2],"TSP") != 0 ) &&
       (strcmp(str_array[2],"BLINDOUT") != 0 ) &&
	   (strcmp(str_array[2],"BLINDOUT2") != 0 ) &&
       (strcmp(str_array[2],"TESTIN") != 0 ) &&
	   (strcmp(str_array[2],"TESTINP") != 0 ) &&
       (strcmp(str_array[2],"METAL") != 0 ) &&
       (strcmp(str_array[2],"CORE") != 0 ) &&
       (strcmp(str_array[2],"BSM" ) != 0 ) &&
	   (strcmp(str_array[2],"BSP" ) != 0 ) &&
       (strcmp(str_array[2],"BSOLDER") != 0 ) &&
       (strcmp(str_array[2],"THRU") != 0 ) &&
       (strcmp(str_array[2],"BURIED") != 0 ) && 
       (strcmp(str_array[2],"STIFF")  != 0 ) &&
       (strcmp(str_array[2],"OUTLINE") != 0 ) &&
       (strcmp(str_array[2],"STENCIL") != 0 ) &&
       (strcmp(str_array[2],"CUTOUT") != 0 ) &&
       (strcmp(str_array[2],"DRILL")  != 0 ) &&
       (strcmp(str_array[2],"RESISTOR")  != 0 ) && (use_type_flag == 3 ))
	   {
 	    printf( "ERROR:  %s  layer type %s.ctl not supported \n",str_array[2],namestr);
	   exitvalue = 96;
	   }
     strncpy(tstr,str_array[2],120);
     kk=0;
	 while( kk < (signed int) strlen(tstr) )
	 {
	  tstr[kk] = toupper(tstr[kk]);
       kk += 1;
	 }
     if( strcmp(tstr,"THRU") == 0 )
	 {
       thru = 1;
     }
     if( strcmp(tstr,"BURIED") == 0)
	 {
        buried = 1;
     }
     if( (strcmp(tstr,"TESTIN") == 0) || (strcmp(tstr,"TESTINP") == 0 ))
	 {
        testin_count+=1;
     }
     if( strcmp(tstr,"BLINDOUT") == 0)
	 {
        blindout_count+=1;
     }
    // count[$3] ++;

    endoffile=getline(infile, thisline);
    nf= split_line(thisline);

   } // end while

  fclose(infile);

   
    if ( exitvalue !=  92 )
	{
      if ( strcmp(tmpnum,ltmp[1] ) != 0 )
	  {
         printf("ERROR: PCMTYPE in %s.ctl doesn't match Layers in makelog\n",namestr);
		 printf("Makelog layers = %s, PCMTYPE = %s \n", ltmp[1],tmpnum);

         exitvalue = 90; 
      }

	  if(strcmp(parttype,"wlbi,5") == 0 )
	  {
         maxlayer=3;
	  }
      if(strcmp(parttype,"wlbi,7") == 0 )
	  {
         maxlayer=4;
	  }
      if(strcmp(parttype,"scm,3") == 0 )
	  {
         maxlayer=2;
	  }
	  if(strcmp(parttype,"scm,5") == 0 )
	  {
		 if (use_type_flag == 0 )
		 {
           maxlayer=3;
		 }
		 else
		 {
	      maxlayer=2;
		 }
	  } 
	  if(strcmp(parttype,"scm,7") == 0 )
	  {
         maxlayer=4;
	  }
      for ( i = 1; i <= maxlayer; i++)
	  {
         j = i ;
         if( !(mfglayer[i]==1) || !(minus_mfglayer[j] == 1)  )
		 {
           printf("ERROR Alignment marks not all present need +/- %d\n", i);
           exitvalue = 91;
         }
      } 

     if((strcmp(num,"7layer") == 0) || (strcmp(num,"5layer")== 0 ))
	 {
	   if ( use_type_flag == 0 )
	   {
        if(testin_count != 2)
		{
	       printf("ERROR: Must Have 2 TESTIN layers in %s.ctl \n", namestr);
           printf("Control file specifies %d TESTIN layers = %d \n",testin_count);
           exitvalue = 95;
        }	
        if(blindout_count != 2)
		{
	       printf( "ERROR: Must Have 2 BLINDOUT layers in %s.ctl\n",namestr);
           exitvalue = 94;
        } 
	   }
	   else
	   {
        if(testin_count != 4)
		{
	       printf("ERROR: Must Have 4 TESTIN layers in %s.ctl\n", namestr);
		   printf("Control file specifies %d TESTIN layers = %d \n",testin_count);
           exitvalue = 95;
        }	
	   }
     }
	 if (maxtek_flag == FALSE)
	 {
       if( thru == 1 && buried == 1)
	   {
	  printf( "ERROR: BURIED & THRU layers not allowed TOGETHER  in %s.ctl \n", namestr);
          exitvalue = 93;
	   }
	 }
  }	  
  return(exitvalue);

}  // end valid_control4


int main( int argc, char **argv)
{
int tint;

    if ((argc != 5) && ( argc != 6))
	 {
	  printf("In valid_control4, wrong number of arguments \n");
	  printf("Usage: valid_control4 name  pcmtype logfile control_layers [type_flag]\n");
	  printf("If no type_flag given, normal type, if type_flag = 1, cply type \n");
	  printf("If type_flag =2, maxtek type, if type_flag =3, 180 type \n");
	  exit(-1);
	  }
	else
	 {
	  if (argc == 5)
	  {
	   tint=valid_control4_call( argv[1],argv[2],argv[3],argv[4],0);  // non-cply
   	    exit(tint);
	  } 
	  if (argc == 6)
	  {
	   tint=valid_control4_call( argv[1],argv[2],argv[3],argv[4],atoi(argv[5]) );  // non-cply
   	    exit(tint);
	  }

    }
}  




#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


char fname_array[500][120];
int fname_count;


//
// search thru the array of fnames
//
int found_in_fname( char *instr)
{
int ii;
int fname_found;

 ii = 0;
 fname_found=FALSE;
 while( ( ii < fname_count) && ( ii < 500))
 {
	// printf("In found_in_fname compare = %s %s \n",instr, fname_array[ii]);

	 if (strcmp(instr,fname_array[ii]) == 0 )
	 {
		 fname_found=TRUE;
		 return(TRUE);
	 }
	ii += 1;
 }

 return(FALSE);


} // find_in_fname

int valid_control_180_call( char *nmstr, char *pcmtypestr, char* infstr)
{
int exitvalue;
int thru;
int buried;
char thisline[200];
char namestr[200];
char tmp1[200];
int mfglayer[1000];
int minus_mfglayer[1000];
int absval;
int kk;
int nf;
int endoffile;
int testin_count;
int blindout_count;
FILE *infile;
char num[200];
char tmp[10][120];
char tstr[200];

int debug;

    debug=0;

	strncpy(namestr,nmstr,120);
	strncpy(num,pcmtypestr,120);

	fname_count = 0;

	for(kk = 0; kk < 1000; kk += 1)
	{
		minus_mfglayer[kk] = 0;
		mfglayer[kk] = 0;
	}
    

    exitvalue = 0;
    thru = 0;
    buried = 0;

   testin_count = 0;
   blindout_count = 0;

   infile=fopen(infstr,"r");
   if (infile == NULL)
	{
		printf("ERROR: valid_control4 unable to open input file = %s \n", infstr);
		exit(-1);
	}
   endoffile=getline(infile, thisline);
   nf= split_line(thisline);

   while(endoffile==FALSE)
   {
    split(str_array[1],tmp[0],tmp[1],".");

	//printf("tmp 0 = %s str_array 1 = %s  \n",tmp[0], str_array[1]);
    if ( found_in_fname(tmp[0]) )
	{
	 printf("ERROR: duplicate filenames in %s.ctl \n",namestr);
	 printf( "   %s ",thisline); 
	 printf( "  %s \n",tmp[0]);
        exitvalue = 99;
    }
    else
	{
      if (fname_count < 500 )                 //add_to_fname(tmp[0]); 
	  {
		  //printf("Adding to fname = %s \n",tmp[0]);

		  strncpy(fname_array[fname_count],tmp[0],120);
		  fname_count += 1;
	  }
	  else
	  {
		  printf("In valid_control_180, number of files exceeds 500 \n");
		  exit(-1);
	  }
    }

    if (strcmp(str_array[3],"NA") != 0)
	{
	  if ( atoi(str_array[3]) > -1 )
	  {
	   if ( mfglayer[atoi(str_array[3])] != 0)
	   {
	    printf("ERROR: duplicate mfg layer numbers in %s.ctl \n",namestr);
	    printf( "  %s \n", thisline);
	    printf( "  %s \n",str_array[3]);
	    exitvalue = 98;
	   }
	   else
	   {
	    mfglayer[ atoi( str_array[3])] = 1;
	   }
	  }
	  else
	  {

	   absval=abs(atoi(str_array[3]));

	   if ( minus_mfglayer[absval] != 0)
	   {
	    printf("ERROR: duplicate mfg layer numbers in %s.ctl \n",namestr);
	    printf( "  %s \n", thisline);
	    printf( "  %s \n",str_array[3]);
	    exitvalue = 98;
	   }
	   else
	   {
	    minus_mfglayer[ absval] = 1;
	   }

	  }
    }
    
    //tmp1 = tolower($4);
	strncpy(tmp1,str_array[3],120);
	kk=0;
	while( kk < (signed int) strlen(str_array[3]) )
	{
		tmp1[kk] = tolower( tmp1[kk]);
		kk += 1;
	}

    if(( strcmp(tmp1,"na") != 0 ) && (strcmp(str_array[4],"PosLg") !=  0) &&
		                (strcmp(str_array[4],"PosSm") !=  0) && 
						(strcmp(str_array[4],"NegLg") !=  0) && 
						(strcmp(str_array[4],"NegSm") !=  0) )
						
	{
	 printf("ERROR: improper photo type = %s in  %s.ctl \n", str_array[4],namestr);
	 printf("   %s \n",thisline); 
	 exitvalue = 97;
    }
 
    // check to see if layer is an allowed layer

	if(( strcmp(str_array[2],"TSOLDER") != 0 ) &&
       (strcmp(str_array[2],"TSM") != 0 ) &&
	   (strcmp(str_array[2],"TSP") != 0 ) && 
       (strcmp(str_array[2],"BLINDOUT") != 0 ) &&
	   (strcmp(str_array[2],"BLINDOUT2") != 0 ) &&
       (strcmp(str_array[2],"TESTIN") != 0 ) &&
       (strcmp(str_array[2],"METAL") != 0 ) &&
       (strcmp(str_array[2],"CORE") != 0 ) &&
       (strcmp(str_array[2],"BSM" ) != 0 ) &&
	   (strcmp(str_array[2],"BSP") != 0 ) &&
       (strcmp(str_array[2],"BSOLDER") != 0 ) &&
       (strcmp(str_array[2],"THRU") != 0 ) &&
       (strcmp(str_array[2],"BURIED") != 0 ) && 
       (strcmp(str_array[2],"STIFF")  != 0 ) &&
       (strcmp(str_array[2],"OUTLINE") != 0 ) &&
       (strcmp(str_array[2],"STENCIL") != 0 ) &&
       (strcmp(str_array[2],"CUTOUT") != 0 ) &&
       (strcmp(str_array[2],"DRILL")  != 0 ) &&
       (strcmp(str_array[2],"RESISTOR")  != 0 ))
	   {
 	    printf( "ERROR:  %s  layer type %s.ctl not supported \n",str_array[2],namestr);
	   exitvalue = 96;
	   }

     strncpy(tstr,str_array[2],120);
     kk=0;
	 while( kk < (signed int) strlen(tstr) )
	 {
	  tstr[kk] = toupper(tstr[kk]);
       kk += 1;
	 }
     if( strcmp(tstr,"THRU") == 0 )
	 {
       thru = 1;
     }
     if( strcmp(tstr,"BURIED") == 0)
	 {
        buried = 1;
     }
     if( strcmp(tstr,"TESTIN") == 0)
	 {
        testin_count+=1;
     }
     if( strcmp(tstr,"BLINDOUT") == 0)
	 {
        blindout_count+=1;
     }
    // count[$3] ++;

    endoffile=getline(infile, thisline);
    nf= split_line(thisline);

   } // end while

  fclose(infile);

  

     if((strcmp(num,"7layer") == 0) || (strcmp(num,"5layer")== 0 ))
	 {
        if(testin_count != 2)
		{
	       printf("ERROR: Must Have 2 TESTIN layers in %s.ctl \n", namestr);
           exitvalue = 95;
        }	
        if(blindout_count != 2)
		{
	       printf( "ERROR: Must Have 2 BLINDOUT layers in %s.ctl\n",namestr);
           exitvalue = 94;
        } 
     }
     if( thru == 1 && buried == 1)
	 {
	  printf( "ERROR: BURIED & THRU layers not allowed TOGETHER  in %s.ctl \n", namestr);
          exitvalue = 93;
     }
  
  return(exitvalue);

}  // end valid_control_180


int main( int argc, char **argv)
{
int tint;

    if (argc != 4)
	 {
	  printf("In valid_control_180, wrong number of arguments \n");
	  printf("Usage: valid_control_180 name  pcmtype control_layers \n");
	  exit(-1);
	  }
	else
	 {
	tint=valid_control_180_call( argv[1],argv[2],argv[3]);
	exit(tint);
      }
}  




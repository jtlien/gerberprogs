#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"


void via_extract_call( )
{
FILE *viacountfile;
char PARTNUMBER[300];
char chkfilestr[300];
char junkstr[300];
char extractstr[100];
char systemstr[300];
int sgok;
int debug;

debug = 0;

if (WINDOWS)
{
  strncpy(dirsep,"\\",5);
  strncpy(extractstr,"extracta",20);
}
else
{
	strncpy(dirsep,"/",5);
	strncpy(extractstr,"extract",30);
}

// Revision 1 released tousers on 11/15/02 -tsa
// Program extract via information for .mcm file.

//--------------------------------------------------------------
//Removes tmp file
//--------------------------------------------------------------

rm_file("viacount_tmp");

//--------------------------------------------------------------
//Parse Partnumber
//--------------------------------------------------------------
strncpy(chkfilestr,"report",20);     // report/makelog
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"makelog",20);

if(  ! (file_exists( chkfilestr) && file_is_readable( chkfilestr))  )   // -r report/makelog 
{
    printf("FATAL ERROR: report%smakelog does not exist or is not readable\n",dirsep);
    exit(-1);
}


// PARTNUMBER=`grep "Part Number" report/makelog | cut -d: -f2`  //extracts part number
sgok=sgrep(chkfilestr,"Part Number",100);

if (sgok == 0 )
{
 split( grep_array[0],junkstr,PARTNUMBER,":");
}
else
{
	printf("No Part Number field in report%smakelog file \n",dirsep);
	exit(-1);
}



//--------------------------------------------------------------
//Extracts VIA information from design
//--------------------------------------------------------------

viacountfile=fopen("via_count.txt","w");
if (viacountfile == NULL)
{
	printf("In via_extract, unable to open the via_count.txt file for writing \n");
	exit(-1);
}

fprintf(viacountfile, "#View:\n");            // >>  via_count.txt
fprintf(viacountfile, "COMPOSITE_PAD\n");     // >>  via_count.txt
fprintf(viacountfile, "#Select:\n");          // >>  via_count.txt
fprintf(viacountfile, "CLASS\n");             // >>  via_count.txt
fprintf(viacountfile, "PAD_STACK_NAME\n");    // >>  via_count.txt
fprintf(viacountfile, "NET_NAME\n");          // >> via_count.txt
fprintf(viacountfile, "START_LAYER_NAME\n");  // >> via_count.txt
fprintf(viacountfile, "END_LAYER_NAME\n");    // >> via_count.txt

fclose(viacountfile);

// extract -q  $PARTNUMBER.mcm via_count  >> viacount_tmp

strncpy(systemstr,extractstr,120);
strncat(systemstr," -q ",10);
strncat(systemstr,PARTNUMBER,100);
strncat(systemstr,".mcm via_count >> viacount_tmp",60);

if (debug) { printf("system call  with :  %s \n", systemstr); }

system(systemstr);

//--------------------------------------------------------------
//Removes tmp file
//--------------------------------------------------------------
 rm_file("via_count.txt");


} // end via_extract_call

/*
int main( int argc, char **argv)
{

	if (argc != 1)
	{
		printf("In via_extract, wrong number of arguments \n");
		printf("Usage: via_extract  \n");
		exit(-1);
	}
	else
	{
	   via_extract_call( );
	}

}  // end main

 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

//   usage : via_new  file1 file2
//
//  via_new.c rev 2.0  3/14/96
//  rev2: changed dummy layer value from 'A' to 'Z' "easier for test to notice"
//        changed while loop statement from "$0 !~ /Pad name/" to "$0 !~ /DRILL/" 
//        this fixes problem in detecting uppper and lower layer in xx.pad file
//        were the stack description is longer than one page.
//  via_new.awk  rev 1.0  7/28/95
//  written by Ted Ammann
//
//  This program is meant to work on the Allegro .pad file 

//  The results from via_new.c are meant to be redirected (UNIX ">") to
//  another file for further processing

//  The output of this program is a two column file with the first column being
//  the via name and the second being a symbol to indicate a layer.
//  That symbol can be one of the following
//		U - Indicates Top layer
//               L - Indicates Bottom layer
//               B - Indicates BOTH Top & Bottom layers

// Sample Output
//      V16    B
//     XBGA    L
//     YCHP    U

// file1 below is a command line parameter specifing the name of the design
// file that has the names of the Top and Bottom layers.
// For Example a file called Linfo might have the lines
//       L01
//       L06

// That indiacte the L01 is the layer name for Top surface metal and the L06
// is the layer name for Bottom surface metal.

// The BEGIN section of the this program simply reads the TOP and BOTTOM layer
// names from the file indicated by file1 



void via_new_call_out(char *infile1str, char *infile2str, char *outfilestr)
{
char name[120];
char layer[120];
char top_str[200];
char bottom_str[200];
FILE *file1;
FILE *file2;
FILE *outfile;

int endoffile;
char thisline[120];
int number_fields;
int kk;

   file1  = fopen(infile1str, "r");

   if (file1 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
   }

   endoffile = getline(file1,thisline);
   strncpy(top_str,thisline,100);

   for(kk=0; kk < (signed int) strlen( top_str); kk += 1)
   {
	   if (top_str[kk]== '\n' )
	   {
		   top_str[kk]= '\0';
	   }
   }
   endoffile = getline(file1,thisline); 
   strncpy(bottom_str,thisline,100);

   for(kk=0; kk < (signed int) strlen( bottom_str); kk += 1)
   {
	   if (bottom_str[kk]== '\n' )
	   {
		   bottom_str[kk]= '\0';
	   }
   }
   fclose(file1);

   strncpy(layer,"Z",4);       // set layer to a dummy value

   file2 = fopen(infile2str, "r");

   if (file2 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",infile2str);
	  exit(-1);
   }

   outfile = fopen(outfilestr, "w");

   if (outfile == NULL)
   {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
   }

// Start of Main Loop

  endoffile = getline(file2,thisline);
  number_fields = split_line(thisline);

  while( endoffile == FALSE)
  {
    if(strstr(thisline,"Pad name") != NULL)
	{                      // when a line contains "Pad name" start processing
     strncpy(name,str_array[3],120);          // the Via name is in the 4th Field 
     endoffile =getline(file2, thisline);
     number_fields = split_line(thisline);

     while( strstr(thisline,"DRILL") == NULL)
	 {                     // process the current via stack 
       endoffile =getline(file2,thisline);
       number_fields = split_line(thisline);

       if (( strstr(str_array[0],top_str) != NULL ) && ( number_fields > 6))
          strncpy(layer,"U",4);
       if (( strstr(str_array[0],bottom_str) != NULL ) && ( number_fields > 6)
		                        && (strcmp(layer,"U")== 0) ){
          strncpy(layer,"B",4); 
       }
       else if (( strstr(str_array[0],bottom_str) != NULL ) && 
		         ( number_fields > 6))
         strncpy(layer,"L",4); 
     }
     fprintf(outfile,"%10s%5s\n",name,layer);
     strncpy(layer,"Z",4);                            // set layer to a dummy value
	}
  endoffile = getline(file2,thisline);
  number_fields = split_line(thisline);
  }
  fclose(file2);
  fclose(outfile);

} // end via_new_call_out


void via_new_call(char *infile1str, char *infile2str)
{
char name[120];
char layer[120];
char top_str[200];
char bottom_str[200];
FILE *file1;
FILE *file2;
int endoffile;
char thisline[120];
int number_fields;
int kk;

   file1  = fopen(infile1str, "r");

   if (file1 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",infile1str);
	  exit(-1);
   }

   endoffile = getline(file1,thisline);
   strncpy(top_str,thisline,100);

   for(kk=0; kk < (signed int) strlen( top_str); kk += 1)
   {
	   if (top_str[kk]== '\n' )
	   {
		   top_str[kk]= '\0';
	   }
   }
   endoffile = getline(file1,thisline); 
   strncpy(bottom_str,thisline,100);

   for(kk=0; kk < (signed int) strlen( bottom_str); kk += 1)
   {
	   if (bottom_str[kk]== '\n' )
	   {
		   bottom_str[kk]= '\0';
	   }
   }
   fclose(file1);

   strncpy(layer,"Z",4);       // set layer to a dummy value

   file2 = fopen(infile2str, "r");

   if (file2 == NULL)
   {
	  printf("Error: Unable to open input file = %s \n",infile2str);
	  exit(-1);
   }


  // printf("topstr = %s bottomstr = %s \n",top_str, bottom_str);

// Start of Main Loop

  endoffile = getline(file2,thisline);
  number_fields = split_line(thisline);

  while( endoffile == FALSE)
  {
    if(strstr(thisline,"Pad name") != NULL)
	{                      // when a line contains "Pad name" start processing
     strncpy(name,str_array[3],120);          // the Via name is in the 4th Field 
     endoffile =getline(file2, thisline);
     number_fields = split_line(thisline);

	 //printf("first line after pad name = %s \n",thisline);

     while( strstr(thisline,"DRILL") == NULL)
	 {                     // process the current via stack 
       endoffile =getline(file2,thisline);
       number_fields = split_line(thisline);

       if (( strstr(str_array[0],top_str) != NULL ) && ( number_fields > 6))
          strncpy(layer,"U",4);
       if (( strstr(str_array[0],bottom_str) != NULL ) && ( number_fields > 6)
		                        && (strcmp(layer,"U")== 0) ){
          strncpy(layer,"B",4); 
       }
       else if (( strstr(str_array[0],bottom_str) != NULL ) && 
		         ( number_fields > 6))
         strncpy(layer,"L",4); 
     }
     printf("%10s%5s\n",name,layer);
     strncpy(layer,"Z",4);                            // set layer to a dummy value
	}
  endoffile = getline(file2,thisline);
  number_fields = split_line(thisline);
  //printf("got a new line = %s \n",thisline);

  }
  fclose(file2);

} // end via_new_call

/*
int main( int argc, char **argv)
{

	if (argc != 3)
	{
		printf("In via_new, wrong number of arguments \n");
		printf("Usage: via_new  file1 file2 \n");
		exit(-1);
	}
    else
	{
		via_new_call(argv[1],argv[2]);
	}
}
*/

  




#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "utilprogs.h"
#include "dirent.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

void beginfile( char *layerstr)
{
printf("  0\n");
printf("SECTION\n");
printf("  2\n");
printf("HEADER\n");
printf("  9\n");
printf("$CLAYER\n");
printf("  8\n");
printf("0\n");
printf("  9\n");
printf("$VIEWDIR\n");
printf(" 10\n");
printf("0.0\n");
printf(" 20\n");
printf("0.0\n");
printf(" 30\n");
printf("1.0\n");
printf("999\n");
printf("DXF Unit: MM\n");
printf("  9\n");
printf("$LIMMAX\n");
printf(" 10\n");
printf("30.3505\n");
printf(" 20\n");
printf("64.3505\n");
printf("  9\n");
printf("$LIMMIN\n");
printf(" 10\n");
printf("-30.3505\n");
printf(" 20\n");
printf("-64.3505\n");
printf("  0\n");
printf("ENDSEC\n");
printf("  0\n");
printf("SECTION\n");
printf("  2\n");
printf("TABLES\n");
printf("  0\n");
printf("TABLE\n");
printf("  2\n");
printf("LTYPE\n");
printf(" 70\n");
printf("    12\n");
printf("  0\n");
printf("LTYPE\n");
printf("  2\n");
printf("CONTINUOUS\n");
printf("  3\n");
printf("Solid\n");
printf(" 70\n");
printf("     0\n");
printf(" 72\n");
printf("    65\n");
printf(" 73\n");
printf("     0\n");
printf(" 40\n");
printf("0\n");
printf("  0\n");
printf("ENDTAB\n");
printf("  0\n");
printf("TABLE\n");
printf("  2\n");
printf("LAYER\n");
printf(" 70\n");
printf("     1\n");
printf("  0\n");
printf("LAYER\n");
printf("  2\n");
printf("%s\n",layerstr);
printf(" 62\n");
printf("     1\n");
printf("  6\n");
printf("CONTINUOUS\n");
printf(" 70\n");
printf("     0\n");
printf("  0\n");
printf("ENDTAB\n");
printf("  0\n");
printf("TABLE\n");
printf("  2\n");
printf("STYLE\n");
printf(" 70\n");
printf("     4\n");
printf("  0\n");
printf("STYLE\n");
printf("  2\n");
printf("FONT0\n");
printf(" 70\n");
printf("     0\n");
printf(" 40\n");
printf("1\n");
printf(" 41\n");
printf("1\n");
printf(" 50\n");
printf("0\n");
printf(" 71\n");
printf("     0\n");
printf(" 42\n");
printf("1\n");
printf("  3\n");
printf("txt\n");
printf("  4\n");
printf("\n");
printf("  0\n");
printf("STYLE\n");
printf("  2\n");
printf("FONT3\n");
printf(" 70\n");
printf("     0\n");
printf(" 40\n");
printf("1\n");
printf(" 41\n");
printf("1\n");
printf(" 50\n");
printf("0\n");
printf(" 71\n");
printf("     0\n");
printf(" 42\n");
printf("1\n");
printf("  3\n");
printf("txt\n");
printf("  4\n");
printf("\n");
printf("  0\n");
printf("ENDTAB\n");
printf("  0\n");
printf("ENDSEC\n");
printf("  0\n");
printf("SECTION\n");
printf("  2\n");
printf("BLOCKS\n");
printf("  0\n");
printf("ENDSEC\n");
printf("  0\n");
printf("SECTION\n");
printf("  2\n");
printf("ENTITIES\n");
printf("  0\n");


}

void beginfile_out(  char *layerstr, FILE *outfile)
{
fprintf(outfile,"  0\n");
fprintf(outfile,"SECTION\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"HEADER\n");
fprintf(outfile,"  9\n");
fprintf(outfile,"$CLAYER\n");
fprintf(outfile,"  8\n");
fprintf(outfile,"0\n");
fprintf(outfile,"  9\n");
fprintf(outfile,"$VIEWDIR\n");
fprintf(outfile," 10\n");
fprintf(outfile,"0.0\n");
fprintf(outfile," 20\n");
fprintf(outfile,"0.0\n");
fprintf(outfile," 30\n");
fprintf(outfile,"1.0\n");
fprintf(outfile,"999\n");
fprintf(outfile,"DXF Unit: MM\n");
fprintf(outfile,"  9\n");
fprintf(outfile,"$LIMMAX\n");
fprintf(outfile," 10\n");
fprintf(outfile,"30.3505\n");
fprintf(outfile," 20\n");
fprintf(outfile,"64.3505\n");
fprintf(outfile,"  9\n");
fprintf(outfile,"$LIMMIN\n");
fprintf(outfile," 10\n");
fprintf(outfile,"-30.3505\n");
fprintf(outfile," 20\n");
fprintf(outfile,"-64.3505\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"ENDSEC\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"SECTION\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"TABLES\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"TABLE\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"LTYPE\n");
fprintf(outfile," 70\n");
fprintf(outfile,"    12\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"LTYPE\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"CONTINUOUS\n");
fprintf(outfile,"  3\n");
fprintf(outfile,"Solid\n");
fprintf(outfile," 70\n");
fprintf(outfile,"     0\n");
fprintf(outfile," 72\n");
fprintf(outfile,"    65\n");
fprintf(outfile," 73\n");
fprintf(outfile,"     0\n");
fprintf(outfile," 40\n");
fprintf(outfile,"0\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"ENDTAB\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"TABLE\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"LAYER\n");
fprintf(outfile," 70\n");
fprintf(outfile,"     1\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"LAYER\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"%s\n",layerstr);
fprintf(outfile," 62\n");
fprintf(outfile,"     1\n");
fprintf(outfile,"  6\n");
fprintf(outfile,"CONTINUOUS\n");
fprintf(outfile," 70\n");
fprintf(outfile,"     0\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"ENDTAB\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"TABLE\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"STYLE\n");
fprintf(outfile," 70\n");
fprintf(outfile,"     4\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"STYLE\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"FONT0\n");
fprintf(outfile," 70\n");
fprintf(outfile,"     0\n");
fprintf(outfile," 40\n");
fprintf(outfile,"1\n");
fprintf(outfile," 41\n");
fprintf(outfile,"1\n");
fprintf(outfile," 50\n");
fprintf(outfile,"0\n");
fprintf(outfile," 71\n");
fprintf(outfile,"     0\n");
fprintf(outfile," 42\n");
fprintf(outfile,"1\n");
fprintf(outfile,"  3\n");
fprintf(outfile,"txt\n");
fprintf(outfile,"  4\n");
fprintf(outfile,"\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"STYLE\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"FONT3\n");
fprintf(outfile," 70\n");
fprintf(outfile,"     0\n");
fprintf(outfile," 40\n");
fprintf(outfile,"1\n");
fprintf(outfile," 41\n");
fprintf(outfile,"1\n");
fprintf(outfile," 50\n");
fprintf(outfile,"0\n");
fprintf(outfile," 71\n");
fprintf(outfile,"     0\n");
fprintf(outfile," 42\n");
fprintf(outfile,"1\n");
fprintf(outfile,"  3\n");
fprintf(outfile,"txt\n");
fprintf(outfile,"  4\n");
fprintf(outfile,"\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"ENDTAB\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"ENDSEC\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"SECTION\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"BLOCKS\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"ENDSEC\n");
fprintf(outfile,"  0\n");
fprintf(outfile,"SECTION\n");
fprintf(outfile,"  2\n");
fprintf(outfile,"ENTITIES\n");
fprintf(outfile,"  0\n");


}

void endfile( )
{
	printf("ENDSEC\n");
	printf("  0\n");
	printf("EOF\n");
}

void endfile_out( FILE *outfile)
{
	fprintf(outfile,"ENDSEC\n");
	fprintf(outfile,"  0\n");
	fprintf(outfile,"EOF\n");
}

void onevia( double x, double y, double diam, char *layerstr)
{

  printf("CIRCLE\n");
  printf("  8\n");
  printf("%s\n",layerstr);
  printf(" 10\n");
  printf("%6.4f\n",x);
  printf(" 20\n");
  printf("%6.4f\n",y);
  printf(" 40\n");
  printf("%6.4f\n",diam);
  printf("  0\n");
}

void onevia_out( double x, double y, double diam, char *layerstr, FILE *outfile)
{

  fprintf(outfile,"CIRCLE\n");
  fprintf(outfile,"  8\n");
  fprintf(outfile,"%s\n",layerstr);
  fprintf(outfile," 10\n");
  fprintf(outfile,"%6.4f\n",x);
  fprintf(outfile," 20\n");
  fprintf(outfile,"%6.4f\n",y);
  fprintf(outfile," 40\n");
  fprintf(outfile,"%6.4f\n",diam);
  fprintf(outfile,"  0\n");
}

//  call interface to getoffset, write to stdout
//
void viastodxf_call( char *infilestr)
{
int cnt;
int endoffile;
char X[200];
char Y[200];
char a[10][200];
char b[10][200];
char c[10][200];
int val;
FILE *file1;

double xmin;
double ymin;
double xmax;
double ymax;
double xval;
double yval;
char layerstr[300];
char junkstr[300];
char upstr[300];
int first;
char thisline[200];

 
  xmin = -10000000;
  xmax = 10000000;
  ymin = -1000000;
  ymax = 10000000;

  if (strstr(infilestr,".") != NULL)
  {
	  split(infilestr,layerstr,junkstr,".");
  }
  else
  {
	  strncpy(layerstr,"viaxxx",30);
  }

  beginfile(layerstr);

  first=0;
  cnt=0;
  file1=fopen(infilestr,"r");
   if ( file1 == NULL)
   {
	   printf("In getoffset, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }
  endoffile=getline(file1,thisline);

 
  while(endoffile==FALSE)
  {
   if ( (strstr(thisline,"X") != NULL) && 
	   (strstr(thisline,"Y") != NULL) && 
	   (strstr(thisline,"G54") == NULL) &&
	   (strstr(thisline,"G04")==NULL) &&
	   (strstr(thisline,"%")==NULL) )    // $0 ~/X/ && $0 ~/Y/  &&  $0 !~/G54/)
   {
       split(thisline,a[0],a[1],"Y");

       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X);
	   if (strstr(a[1],"D")!=NULL)
	   {
         awk_substr( a[1],1,strlen(a[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( a[1],1,strlen(a[1]) -1, Y);    // no D
	   }
//       printf("%s %s\n", X,Y)
	   xval=atof(X);
	  yval=atof(Y);

	   cv_toupper(layerstr,upstr);

	  onevia( xval/10000.0, yval/10000.0, .005, upstr);

	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   else if( (strstr(thisline,"Y") == NULL) &&
	       (strstr(thisline,"X") != NULL) &&
		   (strstr(thisline,"G54") == NULL) &&
	       (strstr(thisline,"G04")==NULL) &&
	       (strstr(thisline,"%")==NULL) )   //  $0 !~ /Y/ && $0 ~/X/ )
   {
      split(thisline,b[0],b[1],"X");
	  if (strstr(b[1],"D")!=NULL)
	   {
         awk_substr( b[1],1,strlen(b[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( b[1],1,strlen(b[1]) -1, Y);    // no D
	   }
//       printf("%s  %s\n", X,Y)
	  xval=atof(X);
	  yval=atof(Y);
      onevia( xval/10000.0, yval/10000.0, .005, layerstr);


	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   else if( (strstr(thisline,"X") == NULL) && 
	        (strstr(thisline,"Y") != NULL) &&
			(strstr(thisline,"G54") == NULL) &&
	        (strstr(thisline,"G04")==NULL) &&
	        (strstr(thisline,"%")==NULL)   )     // $0 !~ /X/ && $0 ~/Y/ )
   {
      split(thisline,c[0],c[1],"Y");
	  if (strstr(c[1],"D")!=NULL)
	   {
         awk_substr( c[1],1,strlen(c[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( c[1],1,strlen(c[1]) -1, Y);    // no D
	   }
      
//      printf("%s %s\n", X,Y)
	  xval=atof(X);
	  yval=atof(Y);

      onevia( xval/10000.0, yval/10000.0, .005, layerstr);

	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   endoffile=getline(file1,thisline);
  
  }
  fclose(file1);

   
  endfile();

   //printf("%0.0f\n",xmin);
   //printf("%0.0f\n",xmax);
  // printf("%0.0f\n",ymin);
  // printf("%0.0f\n",ymax);

   
} // end viastodxf_call



//  call interface to getoffset, write to stdout
//
void viastodxf_call_out( char *infilestr, char *outfilestr)
{
int cnt;
int endoffile;
char X[200];
char Y[200];
char a[10][200];
char b[10][200];
char c[10][200];
int val;
FILE *file1;
FILE *outfile;

double xmin;
double ymin;
double xmax;
double ymax;
double xval;
double yval;
char layerstr[300];
char junkstr[300];
char upstr[300];
int first;
char thisline[200];

 
  xmin = -10000000;
  xmax = 10000000;
  ymin = -1000000;
  ymax = 10000000;

  if (strstr(infilestr,".") != NULL)
  {
	  split(infilestr,layerstr,junkstr,".");
  }
  else
  {
	  strncpy(layerstr,"viaxxx",30);
  }


  first=0;
  cnt=0;

  file1=fopen(infilestr,"r");
   if ( file1 == NULL)
   {
	   printf("In viastodxf, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

   outfile=fopen(outfilestr,"w");
   if ( outfile == NULL)
   {
	   printf("In viastodxf, unable to create the output file = %s \n",outfilestr);
	   exit(-1);
   }

  beginfile_out(layerstr,outfile);

  endoffile=getline(file1,thisline);

 
  while(endoffile==FALSE)
  {
   if ( (strstr(thisline,"X") != NULL) && 
	   (strstr(thisline,"Y") != NULL) && 
	   (strstr(thisline,"G54") == NULL) &&
	   (strstr(thisline,"G04")==NULL) &&
	   (strstr(thisline,"%")==NULL) )    // $0 ~/X/ && $0 ~/Y/  &&  $0 !~/G54/)
   {
       split(thisline,a[0],a[1],"Y");

       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X);
	   if (strstr(a[1],"D")!=NULL)
	   {
         awk_substr( a[1],1,strlen(a[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( a[1],1,strlen(a[1]) -1, Y);    // no D
	   }
//       printf("%s %s\n", X,Y)
	   xval=atof(X);
	  yval=atof(Y);

	   cv_toupper(layerstr,upstr);

	  onevia_out( xval/10000.0, yval/10000.0, .005, upstr, outfile);

	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   else if( (strstr(thisline,"Y") == NULL) &&
	       (strstr(thisline,"X") != NULL) &&
		   (strstr(thisline,"G54") == NULL) &&
	       (strstr(thisline,"G04")==NULL) &&
	       (strstr(thisline,"%")==NULL) )   //  $0 !~ /Y/ && $0 ~/X/ )
   {
      split(thisline,b[0],b[1],"X");
	  if (strstr(b[1],"D")!=NULL)
	   {
         awk_substr( b[1],1,strlen(b[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( b[1],1,strlen(b[1]) -1, Y);    // no D
	   }
//       printf("%s  %s\n", X,Y)
	  xval=atof(X);
	  yval=atof(Y);
      onevia_out( xval/10000.0, yval/10000.0, .005, layerstr,outfile);


	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   else if( (strstr(thisline,"X") == NULL) && 
	        (strstr(thisline,"Y") != NULL) &&
			(strstr(thisline,"G54") == NULL) &&
	        (strstr(thisline,"G04")==NULL) &&
	        (strstr(thisline,"%")==NULL)   )     // $0 !~ /X/ && $0 ~/Y/ )
   {
      split(thisline,c[0],c[1],"Y");
	  if (strstr(c[1],"D")!=NULL)
	   {
         awk_substr( c[1],1,strlen(c[1]) -4, Y);  // has D
	   }
	   else
	   {
        awk_substr( c[1],1,strlen(c[1]) -1, Y);    // no D
	   }
      
//      printf("%s %s\n", X,Y)
	  xval=atof(X);
	  yval=atof(Y);

      onevia_out( xval/10000.0, yval/10000.0, .005, layerstr, outfile);

	  if (first > 0)
	   {
        if ( xval < xmin )
		{
			xmin = xval;
		}
		else if ( xval > xmax) 
		{
			xmax=xval;
		}
		if ( yval < ymin )
		{
			ymin = yval;
		}
		else if ( yval > ymax) 
		{
			ymax= yval;
		}
 
	   }
	   else  // first = 0
	   {
          xmin=xval;
		  xmax=xval;
		  ymin=yval;
		  ymax=yval;
		  first=1;
	   }
	   cnt+=1;
   }
   endoffile=getline(file1,thisline);
  
  }
  fclose(file1);

   
  endfile_out(outfile);

  fclose(outfile);

   //printf("%0.0f\n",xmin);
   //printf("%0.0f\n",xmax);
  // printf("%0.0f\n",ymin);
  // printf("%0.0f\n",ymax);

   
} // end viastodxf_call_out


int main( int argc, char **argv)

{
char outstr[150];
int k;
int lfilecnt;
char basestr[200];
char extstr[50];

  if (argc != 2 )
  {
    printf("In viastodxf, wrong number of arguments \n");
	printf("Usage: viastodxf infile \n");
	exit(-1);
   }
  else
  {

	if (strcmp(argv[1],"*.l")== 0 )
	{
      lfilecnt=scandir_matchext(".",0,".l");

	  for(k=0; k < lfilecnt; k += 1)
	  {

		  strncpy(outstr,scan_array[k],120);
		  split(outstr,basestr,extstr,".");
		  strncpy(outstr,basestr,120);
		  strncat(outstr,".dxf",10);

		  viastodxf_call_out( scan_array[k], outstr);

	  }

	}
    else
	{
     strncpy(outstr,argv[1],120);
	 
     split(outstr,basestr,extstr,".");
	 strncpy(outstr,basestr,120);
     strncat(outstr,".dxf",10);


	 viastodxf_call_out( argv[1],outstr);
	}

  }
}  
  








  

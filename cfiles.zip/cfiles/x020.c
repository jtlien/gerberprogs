
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void create_020_call ( char *pnstr);
void rule_check_call( char *pnstr);

void do_report( char *instr, char *typestr)
{
int debug;
char systemstr[300];

  debug = 0;

  strncpy(systemstr,"report -v ",30);
  strncat(systemstr,typestr,10);
  strncat(systemstr," ",4);
  strncat(systemstr, instr, 100);
  strncat(systemstr," report/",30);
  strncat(systemstr, instr, 100);
  strncat(systemstr,".",4);
  strncat(systemstr,typestr,10);

  if (debug)
  {
	  printf("About to do system call with , %s \n", systemstr);
  }
   system(systemstr);
}

void x020_call( char *instr)
{
char systemstr[300];
int debug;

  debug = 0;

  if ( file_exists("report/Linfo") )
  {

   do_report( instr, "uaf");      //    -v uaf $1 report/$1.uaf
   do_report( instr, "ucn");      //    -v ucn $1 report/$1.ucn
   do_report( instr, "upc");      //    -v upc $1 report/$1.upc
   do_report( instr, "drc");      //    -v drc $1 report/$1.drc
   do_report( instr, "ecl");      //    -v ecl $1 report/$1.ecl
   do_report( instr, "cmp");      //    -v cmp $1 report/$1.cmp
   do_report( instr, "pcp");      //    -v pcp $1 report/$1.pcp
   do_report( instr, "spn");      //    -v spn $1 report/$1.spn
   do_report( instr, "pad");      //  -v pad $1 report/$1.pad

//   techfile -w     $1 report/$1.tech

   strncpy(systemstr,"techfile -w  ",30);  // techfile -w $1 report/$1.tech
   strncat(systemstr,instr,100);
   strncat(systemstr," report/",30);
   strncat(systemstr,instr,100);
   strncat(systemstr,".tech",10);

   if (debug) { printf("About to call system with %s \n",systemstr); }

   system(systemstr);

   create_020_call( instr);
   rule_check_call( instr);   // $1

   system("rm *.log*");
  }
  else
  {
   printf("report/Linfo does not exist \n");
   printf("report/Linfo must be created before further processing\n");
  }

}  // end x020_call


int main( int argc, char **argv)
{

  if (argc != 2)
  {
	  printf("Wrong number of arguments for x020\n");
	  printf("Usage: x020 pn \n");
  }
  else
  {
	  x020_call( argv[1]);
  }


}  // end main
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

#include "utilprogs.h"

// USAGE="usage: $progname filename "
// EXAMPLE="\tex:  $progname layers"

// start of MAIN

void oddeven_call( char *instring);

void xcat_cply_call( char *infilestr)
{
char thisline[200];
int nf;

FILE *file1;
int layer_valid;

char fname[200];
char fnameo[200];
char fnamem[200];
char fnamep[200];
char fnamey[200];
char fnamew[200];
char fnamebb[200];
char fnamebc[200];
char fnameacm[200];
char fnamerts[200];
char fnamegbx[200];
char fnamepan[200];
char fnamepanl[200];
char fnamecen[200];
char typestr[200];
char pcmname[200];
char pcmnamex[200];
char fnamescml[200];
char myfile[200];
int kk;

int endoffile;



   if ( file_exists(infilestr) )
   {
      oddeven_call(infilestr); // $1
      cat_5files( "aoi.gbr", "arrow.gbr","cdalign.gbr", "lamination.gbr", "laser.gbr","metalx.gbr");

      cat_4files( "outline.gbr", "tooling.gbr", "plating.gbr", "text.gbr","metaly.gbr");

      cat_4files( "labels.z", "registration.gbr", "artwork.gbr", "preco.gbr","metalz.gbr"); // >>   metal.gbr

	  cat_3files("metalx.gbr","metaly.gbr","metalz.gbr","metal.gbr");
	  rm_file("metalx.gbr");
	  rm_file("metaly.gbr");
	  rm_file("metalz.gbr");

      cat_4files( "arrow.gbr", "outline.gbr", "laser.gbr", "artwork.gbr", "nonmetal.gbr");


      file1=fopen(infilestr,"r");
      if ( file1==NULL)
          {
                  printf("In xcat_cply, unable to open the input control file =%s \n",infilestr);
                  exit(-1);
          }


      endoffile=getline(file1,thisline);
      nf=split_line(thisline);

      while( endoffile == FALSE) //  read name myfile type mfg photo layer mask pcmname
      {
	   // fname=${myfile%.*}
	   strncpy(fname,myfile,120);
	   kk=0; 
	   while( kk < (signed int) strlen(fname))  // shorten fname up to '.'
	   {
		   if (fname[kk] == '.')
		   {
			   fname[kk] = 0;
		   }
		kk += 1;
	   }
	   strncpy(typestr,str_array[2],120);
	   strncpy(pcmname,str_array[7],120);
	   strncpy(pcmnamex,pcmname,120);
	   strncat(pcmnamex,".x",10);

       strncpy(fnamep,fname,120);
	   strncat(fnamep,".p",10);

       strncpy(fnamem,fname,120);
	   strncat(fnamem,".m",10);

       strncpy(fnamew,fname,120);
	   strncat(fnamew,".w",10);

	   strncpy(fnameo,fname,120);
	   strncat(fnameo,".o",10);

       strncpy(fnamey,fname,120);
	   strncat(fnamey,".y",10);

       strncpy(fnamepan,fname,120);
	   strncat(fnamepan,".pan",10);

       strncpy(fnamecen,fname,120);
	   strncat(fnamecen,".cen",10);

       strncpy(fnamepanl,fname,120);
	   strncat(fnamepanl,"pan.l",10);

       strncpy(fnamerts,fname,120);
	   strncat(fnamerts,".rts",10);

       strncpy(fnameacm,fname,120);
	   strncat(fnameacm,".acm",10);

       strncpy(fnamegbx,fname,120);
	   strncat(fnamegbx,".gbx",10);

       strncpy(fnamescml,fname,120);
	   strncat(fnamescml,"scm.l",10);

       strncpy(fnamebb,fname,120);
	   strncat(fnamebb,".bb",10);

       strncpy(fnamebc,fname,120);
	   strncat(fnamebc,".bc",10);

	   layer_valid=FALSE;

	   if(strcmp(typestr,"TSOLDER")== 0)
	   {
		   cat_10files( fnamerts,"nonmetal.gbr",fnameo,fnameacm,fnamew,pcmnamex,"smask.t",
			   "soldermask.gbr",fnamepan,"tsolder.gbr",fnamebb); //   >> $fname.pan ;;
		   layer_valid=TRUE;
	   }
	   if(strcmp(typestr,"PS") == 0 )
	   {
		   cp_file("M02.gbr",fnamepan); //  $fname.p M02.gbr >> $fname.pan;; 
           layer_valid=TRUE;
	   }
       if(strcmp(typestr,"TSM") == 0 )
	   {
		 cat_13files( fnamerts,"pulltest.gbr", "metal.gbr",fnameacm,pcmnamex,
			 fnameo,fnamew,"outer.t","testout.gbr",fnamey,"tsm.gbr",fnamebc,fnamebb,fnamepan);
         layer_valid=TRUE;
	   }
       if(strcmp(typestr,"METAL") == 0 )
	   { 
		   cat_11files(fnamerts,"metal.gbr",pcmnamex,fnameacm,fnameo,fnamew,
			   "inner.t","testin.gbr",fnamey,fnamebc,fnamebb,fnamepan); 
           layer_valid=TRUE;
	   }
       if(strcmp(typestr,"TESTIN") == 0 )
	   {
		   cat_11files( fnamerts,"metal.gbr",fnamep,pcmnamex,fnameo,
			   fnamew,"outer.t","testout.gbr",fnamey,fnamebb,fnamebc,fnamepan);  
	       layer_valid=TRUE; 
	   }
	   if(strcmp(typestr,"CORE" ) == 0 )
	   {
		   cat_9files( fnamerts,"arrow.gbr", "cdalign.gbr",fnameacm, "outline.gbr",pcmnamex,
			        fnamew,"core.gbr",fnamebb,fnamepan); 
	       layer_valid=TRUE; 
	   }
	   if(strcmp(typestr,"BSM"  ) == 0 )
	   {
		   cat_13files( "pulltest.gbr", "metal.gbr",fnameacm,pcmnamex,fnameo,
			   fnamew,"outer.t","testout.gbr",fnamey,"bsm.gbr",fnamerts,fnamebb,fnamebc,fnamepan); 
	       layer_valid=TRUE;
	   }
	   if(strcmp(typestr,"BSOLDER")== 0 )
	   {
		   cat_9files( "nonmetal.gbr",fnameacm,fnameo,fnamew,"smask.t","soldermask.gbr",
			   "bsolder.gbr",fnamerts,fnamebb,fnamepan); // $fname.pan;;
	       layer_valid=TRUE; 
	   }
	   
       if(strcmp(typestr,"BLINDOUT")== 0)
		{
			cat_9files("nonmetal.gbr",fnameacm,"cdalign.gbr",pcmnamex,
				fnamerts,fnameo,fnamew,"aoiviamask.gbr","blind.t",fnamepan); // > $fname.pan
	        cat_3files(pcmnamex,"blind.t",fnamerts,fnamepanl);    // $pcmname.x blind.t > $fname"pan.l"
	        cp_file_fromsub("scm",fnamecen,fnamescml); // ../scm/$fname.cen $fname"scm.l" ;;
            layer_valid=TRUE;
		}
       if(strcmp(typestr,"BLINDIN")== 0 )
	   {
		   cat_7files( "nonmetal.gbr","cdalign.gbr",fnameacm,pcmnamex,fnameo,fnamew,"aoiviamask.gbr",fnamepan); // > $fname.pan
	       // cat $pcmname.x > $fname"pan.l"
		   cp_file(pcmnamex,fnamepanl);
	       cp_file_fromsub("scm",fnamecen,fnamescml); // ../scm/$fname.cen $fname"scm.l" ;;
		   layer_valid=TRUE;
	   }

	   if(strcmp(typestr,"RESISTOR")==0)
	   {
		  cat_10files( "arrow.gbr", "outline.gbr", fnameacm,"cdalign.gbr","artwork.gbr",
			  pcmnamex,fnameo,fnamew,fnamebc,fnamebb,fnamepan);  
		  layer_valid=TRUE;
	   }
	  
	  if((strcmp(typestr,"MECH") == 0 ) || 
		(strcmp(typestr,"CUTOUT")==0) ||
		(strcmp(typestr,"DRILL" )== 0 ))
	  {
		 cp_file_tosub(fnamep,"mech",fnamem); 
         layer_valid=TRUE;
	  }

	  if(strcmp(typestr,"OUTLINE")== 0)
	  {
		 cat_4files(fnamep,pcmnamex,"outline.gbr",fnameacm,fnamepan); // 
		 cp_file_tosub(fnamep,"mech",fnamem); 
		 layer_valid=TRUE;
	  }

	 if(strcmp(typestr,"STENCIL")== 0)
	 {
		 layer_valid=TRUE;
	 }

	 if((strcmp(typestr,"STIFFENER")== 0) ||
	    (strcmp(typestr,"STIFFNER")==0) ||
		(strcmp(typestr,"STIFF") ==0))
	 {
		 cp_file_from_to("scm",fnamecen,"mech",fnamem); // ../scm/$fname.cen  ../mech/$fname.m ;;
		 layer_valid=TRUE;
	 }
	    
	 if(strcmp(typestr,"BURIED")==0)
	 {
		      cat_3files(pcmnamex,"buried.t",fnamerts,fnamepanl); // 
		      cp_file_from_to("mfg",fnamegbx,"aoi",fnamegbx); // $fname.gbx  ../aoi/$fname.gbx
		      cp_file_fromsub("scm",fnamecen,fnamescml);  // $fname"scm.l" ;;
			  layer_valid=TRUE;
	 }
	 if(strcmp(typestr,"THRU")==0)
	 {
		     cat_files( pcmname, "thruvia.gbr",fnamepanl); //  > $fname"pan.l"
		      cp_file_from_to("mfg",fnamegbx,"aoi",fnamegbx); // ../scm/$fname.gbx  ../aoi/$fname.gbx 
		      cp_file_fromsub("scm",fnamecen,fnamescml); // ../scm/$fname.cen $fname"scm.l" ;;
			 layer_valid=TRUE;
	 }

	 if(layer_valid == FALSE)
	 {
	    printf( "$myfile Invalid layer type");
	 }

	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);
   }                          // end while
   fclose(file1);
  }
 else  // if file exists
  {
	  printf( "File not found =%s\n", infilestr);
  }

}  // end  xcat_cply3_call


/*
int main( int argc, char **argv)
{
char progname[300];
char usagestr[300];
char examplestr[300];

strncpy(progname,"xcat_cply", 20);

 sprintf( usagestr,"usage: %s filename",progname);
 sprintf(examplestr,"    ex: %s layers",progname);

 if(argc != 2)
 { 
   printf("incorrect number of arguments\n");
   printf("%s \n %s \n",usagestr,examplestr); // "$USAGE\n$EXAMPLE\n"
   exit(-1);
 }
 else
 {
	 xcat_cply_call( argv[1]);
 }

}  // end main

  */

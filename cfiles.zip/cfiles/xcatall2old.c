#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

#include "fnv.h"

#define FNV1_32_INITV 2166136261

struct hash_col_type
{
	char value[40];
	struct hash_col_type *next;
	char str[40];
} ;

struct hash_array_stuff
{
	char value[40];
	char str[40];
	int hit;
	struct hash_col_type *collist;
} hash_array[ 70000];

// USAGE="usage: $progname filename "
// EXAMPLE="\tex:  $progname layers"

// start of MAIN

char str_array[120][120];

char thisline[200];
int nf;

FILE *file1;
char examplestr[200];
char usagestr[200];
int layer_valid;

char fname[200];
char fnamex[200];
char fnameo[200];
char fnamem[200];
char fnamep[200];
char fnamey[200];
char fnamew[200];
char fnamepan[200];
char fnamepanl[200];
char fnamecen[200];
char progname[200];
char typestr[200];
char pcmname[200];
char pcmnamex[200];
char fnamescml[200];
char myfile[200];
int kk;

int endoffile;


int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line

void rm_file( char *filestr)
{

  unlink(filestr);

}

//
//  Check if a file exists
//
int file_exists( char *infile)
{
FILE *tfile;

 tfile = fopen(infile,"r");

 if (tfile == NULL)
 {
	 return(0);
 }
 else
 {
	 fclose(tfile);
	 return(1);
 }

} // file_exists

//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline
//
// cp one file to another line by line 
//
void cp_file( char *infile1_str, char *outfile_str)
{
FILE *infile1;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in cp_file, unable to open input file = %s \n",
		  infile1_str);
	 exit(-1);
 }


 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 fclose( outfile);

}  // end cp_file

//
// cp one file from a sub directory file line by line 
//
void cp_file_fromsub(char *subdir, char *infile1_str, char *outfile_str)
{
FILE *infile1;
FILE *outfile;
int endfile;
char thislinein[200];
char fnamestr[200];
char dirsep[4];

 if (WINDOWS == TRUE)
	{
	 strncpy(dirsep,"\\",2);
 }
 else
 {
	 strncpy(dirsep,"/",2);
 }
 strncpy( fnamestr,subdir,40);
 strncat( fnamestr,dirsep,5);
 strncat( fnamestr,infile1_str,120);

 infile1 = fopen(fnamestr,"r");

 if (infile1 == NULL)
	{
	 printf("Error in cp_file, unable to open input file = %s \n",
		  fnamestr);
	 exit(-1);
 }


 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 fclose( outfile);

}  // end cp_file_fromsub

//
// cp one file to a sub directory file line by line 
//
void cp_file_tosub(  char *infile1_str, char *outsubdir, char *outfile_str)
{
FILE *infile1;
FILE *outfile;
int endfile;
char thislinein[200];
char fnameoutstr[200];
char dirsep[4];

 if (WINDOWS == TRUE)
	{
	 strncpy(dirsep,"\\",2);
 }
 else
 {
	 strncpy(dirsep,"/",2);
 }
 strncpy( fnameoutstr,outsubdir,40);
 strncat( fnameoutstr,dirsep,5);
 strncat( fnameoutstr,outfile_str,120);

 
 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in cp_file, unable to open input file = %s \n",
		  infile1_str);
	 exit(-1);
 }


 outfile = fopen(fnameoutstr,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  fnameoutstr);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 fclose( outfile);

}  // end cp_file_tosub

//
// cp one file from a sub directory file line by line 
//
void cp_file_from_to( char *insubdir, char *infile1_str, char *outsubdir, char *outfile_str)
{
FILE *infile1;
FILE *outfile;
int endfile;
char thislinein[200];
char fnameinstr[200];
char fnameoutstr[200];
char dirsep[4];

 if (WINDOWS == TRUE)
	{
	 strncpy(dirsep,"\\",2);
 }
 else
 {
	 strncpy(dirsep,"/",2);
 }
 strncpy( fnameoutstr,outsubdir,40);
 strncat( fnameoutstr,dirsep,5);
 strncat( fnameoutstr,outfile_str,120);

 strncpy( fnameinstr,insubdir,40);
 strncat( fnameinstr,dirsep,5);
 strncat( fnameinstr,infile1_str,120);

 infile1 = fopen(fnameinstr,"r");

 if (infile1 == NULL)
	{
	 printf("Error in cp_file, unable to open input file = %s \n",
		  fnameinstr);
	 exit(-1);
 }


 outfile = fopen(fnameoutstr,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  fnameoutstr);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 fclose( outfile);

}  // end cp_file_from_to

//
// cat together two files and put into a third
//
void cat_files( char *infile1_str, char *infile2_str, char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
	 exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile1);
 fclose( outfile);

}  // end cat_files

//
// cat together three files and put into a fourth
//
void cat_3files( char *infile1_str, char *infile2_str, char *infile3_str,char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 fclose( outfile);

}  // end cat_3files

//
// cat together four files and put into a fifth
//
void cat_4files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str,char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);
 fclose( outfile);

}  // end cat_4files


//
// cat together five files and put into a sixth
//
void cat_5files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);
 fclose( outfile);

}  // end cat_5files


//
// cat together six files and put into a seventh
//
void cat_6files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);
 fclose( outfile);

}  // end cat_6files

//
// cat together seven files and put into a eighth
//
void cat_7files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile7_str);
	 exit(-1);
 }

 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);

 endfile = getline( infile7, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
 }
 fclose( infile7);

 fclose( outfile);

}  // end cat_7files

//
// cat together eight files and put into a ninth
//
void cat_8files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile7_str);
	 exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile8_str);
	 exit(-1);
 }
 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);

 endfile = getline( infile7, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
 }
 fclose( infile7);

 endfile = getline( infile8, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
 }
 fclose( infile8);

 fclose( outfile);

}  // end cat_8files


//
// cat together 11 files and put into a twelfth
//
void cat_11files( char *infile1_str, char *infile2_str, char *infile3_str, 
				 char *infile4_str, char *infile5_str, char *infile6_str,
				 char *infile7_str, char *infile8_str, char *infile9_str,
				 char *infile10_str, char *infile11_str,
				 char *outfile_str)
{
FILE *infile1;
FILE *infile2;
FILE *infile3;
FILE *infile4;
FILE *infile5;
FILE *infile6;
FILE *infile7;
FILE *infile8;
FILE *infile9;
FILE *infile10;
FILE *infile11;

FILE *outfile;
int endfile;
char thislinein[200];

 infile1 = fopen(infile1_str,"r");

 if (infile1 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile1_str);
     exit(-1);
 }

 infile2 = fopen(infile2_str,"r");


 if (infile2 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile2_str);
    exit(-1);
 }

 infile3 = fopen(infile3_str,"r");


 if (infile3 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile3_str);
	 exit(-1);
 }

 infile4 = fopen(infile4_str,"r");


 if (infile4 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile4_str);
	 exit(-1);
 }

 infile5 = fopen(infile5_str,"r");


 if (infile5 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile5_str);
	 exit(-1);
 }

 infile6 = fopen(infile6_str,"r");


 if (infile6 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile6_str);
	 exit(-1);
 }

 infile7 = fopen(infile7_str,"r");


 if (infile7 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile7_str);
	 exit(-1);
 }

 infile8 = fopen(infile8_str,"r");


 if (infile8 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile8_str);
	 exit(-1);
 }

 infile9 = fopen(infile9_str,"r");


 if (infile9 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile9_str);
	 exit(-1);
 }

 infile10 = fopen(infile10_str,"r");


 if (infile10 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile10_str);
	 exit(-1);
 }

 infile11 = fopen(infile11_str,"r");


 if (infile11 == NULL)
	{
	 printf("Error in concat files, unable to open input file = %s \n",
		  infile11_str);
	 exit(-1);
 }


 outfile = fopen(outfile_str,"w");

 if (outfile == NULL)
	{
	 printf("Error in concat files, unable to open output file = %s \n",
		  outfile_str);
	 exit(-1);
 }

 endfile = getline( infile1, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile1, thislinein);
 }
 fclose( infile1);

 endfile = getline( infile2, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile2, thislinein);
 }
 fclose( infile2);

 endfile = getline( infile3, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile3, thislinein);
 }
 fclose( infile3);

 endfile = getline( infile4, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile4, thislinein);
 }
 fclose( infile4);

 endfile = getline( infile5, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile5, thislinein);
 }
 fclose( infile5);

 endfile = getline( infile6, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile6, thislinein);
 }
 fclose( infile6);

 endfile = getline( infile7, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile7, thislinein);
 }
 fclose( infile7);

 endfile = getline( infile8, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile8, thislinein);
 }
 fclose( infile8);

 endfile = getline( infile9, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile9, thislinein);
 }
 fclose( infile9);

 endfile = getline( infile10, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile10, thislinein);
 }
 fclose( infile10);

 endfile = getline( infile11, thislinein);

 while( endfile == FALSE)
 {
	 fprintf(outfile,"%s",thislinein);
	 endfile = getline(infile11, thislinein);
 }
 fclose( infile11);

 fclose( outfile);

}  // end cat_11files

void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk;

  ii=0;
  kk = 0;

 while((instr[ii] != srchstr[0]) && ( ii < strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;


}  // end split

Fnv32_t fnv_32_str(char *str, Fnv32_t hval)
{
    unsigned char *s = (unsigned char *)str;	/* unsigned string */

    /*
     * FNV-1 hash each octet in the buffer
     */
    while (*s) {

	/* multiply by the 32 bit FNV magic prime mod 2^32 */
#if defined(NO_FNV_GCC_OPTIMIZATION)
	hval *= FNV_32_PRIME;
#else
	hval += (hval<<1) + (hval<<4) + (hval<<7) + (hval<<8) + (hval<<24);
#endif

	/* xor the bottom with the current octet */
	hval ^= (Fnv32_t)*s++;
    }

    /* return our new hash value */
    return hval;
}

int get_hash( char *instr )
{
int thisval;
Fnv32_t hashval;

 hashval = fnv_32_str(instr, 2166136261);

 thisval = (hashval >>16) ^ (hashval & 0xffff);

 return(thisval);
}

void hash_init( )
{
int ii;

	for (ii=0; ii < 65000; ii += 1)
	{
	  hash_array[ii].hit = 0;
	  hash_array[ii].str[0]=0;
	  hash_array[ii].value[0]='0';
	  hash_array[ii].value[1]=0;
	  hash_array[ii].collist=NULL;
	}
}

int find_in_hash( char *instr, char *outval)
{
int hshval;
struct hash_col_type *listptr;
int hashfound;

        hshval = get_hash( instr);
	if (strcmp( hash_array[hshval].str,instr) == 0)
	{
	  strncpy(outval,hash_array[hshval].value,40);
	  return(0);
	}
	else
	{
	  listptr = hash_array[hshval].collist;
	  hashfound = FALSE;
	  while(( listptr != NULL ) && ( hashfound == FALSE))
	  {
		 // printf("Comparing %s to %s \n", listptr->str, instr);

		  if (strcmp(listptr->str, instr) == 0 )
		  {
			  strncpy(outval,listptr->value,40);
			  hashfound = TRUE;
			  return(0);
		  }
		  else
		  {
			  listptr=listptr->next;
		  }
	  }
	  if (( listptr == NULL )&& ( hashfound == FALSE))
	  {
		  printf("Internal error not found in hash = %s \n",instr);
		  return(-1);
	  }
	}
   return(-1);
}


void add_to_hash( char *instr, char *inval)
{
int hshval;
struct hash_col_type *listptr;
struct hash_col_type *tptr;

    hshval = get_hash( instr);
	if (hash_array[hshval].hit == 0)
	{
	  strncpy(hash_array[hshval].value,inval,40);
      strncpy(hash_array[hshval].str,instr,40);
	  hash_array[hshval].hit = 1;
	}
	else
	{
	  if ( strcmp(hash_array[hshval].str,instr) != 0)
	  {
		// printf("Doing a collision \n");
	    listptr = hash_array[hshval].collist;
	    while( listptr != NULL ) 
		{
		 listptr = listptr->next; 
		}
	   tptr = malloc( sizeof( struct hash_col_type ));
	  
	   strncpy(tptr->str,instr,40);
	   strncpy(tptr->value,inval,40);
	   tptr->next = hash_array[hshval].collist;

	   hash_array[hshval].collist = tptr;
	  }
	 else                               // just update the value
	 {
	   strncpy(hash_array[hshval].value,inval,40);
	 }
	}
	  
}

int oddeven_call( char *infname)
{

int min;
int max;
char name[20];
char outname[120];
int i;
char str_array[120][120];
char thisline[200];
int nf;
int endoffile;
int compval;
char istr[120];
char hash_outstr[120];
FILE *file1;
char out[10][120];

  hash_init();
	
  file1  = fopen(infname, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infname);
	  exit(-1);
	}

  min = 999;
  max = -999;

  endoffile=getline(file1,thisline);
  nf=split_line(thisline);

  while(endoffile==FALSE)
  {
     if((strcmp(str_array[2],"TSM")== 0) ||
		(strcmp(str_array[2],"BSM")== 0) || 
		(strcmp(str_array[2],"METAL")==0) ||
		(strcmp(str_array[2],"CORE")==0) ||
		(strcmp(str_array[2],"TESTIN")==0))
	 {
        add_to_hash(str_array[3],str_array[1]);   // array[$4] = $2;

	    compval=atoi(str_array[3]);

	    if( compval < min)
	      min = compval;
        if( compval > max )
	      max = compval;
     }
	endoffile=getline(file1,thisline);
	nf=split_line(thisline);

  }
  fclose(file1);

  strncpy(name,"odd.y",10);


   for( i = min ; i <= max; i++)
   {
	sprintf(istr,"%d",i);
    if( find_in_hash(istr,hash_outstr) )
	 {
	   split(hash_outstr,out[0],out[1],".");
	   strncpy(outname,out[0],80);
	   strcat(outname,".y");

	  // command = ("cp " name " " outname)
	  // system(command);

	   cp_file(name,outname);

       if( strcmp(name,"odd.y") == 0)
	   {
	    strncpy(name,"even.y",20);
	   }
       else
	   {
	    strncpy(name,"odd.y",20);
	   }
	}
   }

  return(0);

}  // end oddeven_call

int main( int argc, char **argv)
{
 strncpy(progname,"xcatall2.2", 20);

 sprintf( usagestr,"usage: %s filename",progname);
 sprintf(examplestr,"    ex: %s layers",progname);

 if(argc != 2)
 { 
   printf("incorrect number of arguments\n");
   printf("%s \n %s \n",usagestr,examplestr); // "$USAGE\n$EXAMPLE\n"
 }
 else
 {
   if ( file_exists(argv[1]) )
   {
      oddeven_call(argv[1]); // $1
      cat_4files( "aoi4_5.gbr", "arrow.gbr", "lamination.gbr", "laser.gbr","metalx.gbr");

      cat_4files( "outline.gbr", "tooling.gbr", "plating.gbr", "text.gbr","metaly.gbr");

      cat_4files( "labels.z", "registration.gbr", "artwork.gbr", "preco.gbr","metalz.gbr"); // >>   metal.gbr

	  cat_3files("metalx.gbr","metaly.gbr","metalz.gbr","metal.gbr");
	  rm_file("metalx.gbr");
	  rm_file("metaly.gbr");
	  rm_file("metalz.gbr");

      cat_4files( "arrow.gbr", "outline.gbr", "laser.gbr", "artwork.gbr", "nonmetal.gbr");

      while( endoffile == FALSE) //  read name myfile type mfg photo layer mask pcmname
      {
	   // fname=${myfile%.*}
	   strncpy(fname,myfile,120);
	   kk=0; 
	   while( kk < strlen(fname))  // shorten fname up to '.'
	   {
		   if (fname[kk] == '.')
		   {
			   fname[kk] = 0;
		   }
		kk += 1;
	   }
	   strncpy(typestr,str_array[2],120);
	   strncpy(pcmname,str_array[7],120);
	   strncpy(pcmnamex,pcmname,120);
	   strncat(pcmnamex,".x",10);

       strncpy(fnamep,fname,120);
	   strncat(fnamep,".p",10);

       strncpy(fnamem,fname,120);
	   strncat(fnamem,".m",10);

       strncpy(fnamew,fname,120);
	   strncat(fnamew,".w",10);

	   strncpy(fnameo,fname,120);
	   strncat(fnameo,".o",10);

       strncpy(fnamey,fname,120);
	   strncat(fnamey,".y",10);

       strncpy(fnamepan,fname,120);
	   strncat(fnamepan,".pan",10);

       strncpy(fnamecen,fname,120);
	   strncat(fnamecen,".cen",10);

       strncpy(fnamepanl,fname,120);
	   strncat(fnamepanl,"pan.l",10);

       strncpy(fnamescml,fname,120);
	   strncat(fnamescml,"scm.l",10);

	   layer_valid=FALSE;

	   if(strcmp(typestr,"TSOLDER")== 0)
	   {
		   cat_7files( "nonmetal.gbr",fnamep,fnameo,fnamew,pcmnamex,"smask.t","soldermask.gbr",fnamepan); //   >> $fname.pan ;;
		   layer_valid=TRUE;
	   }
	   if(strcmp(typestr,"PS") == 0 )
	   {
		   cat_files(fnamep,"M02.gbr",fnamepan); //  $fname.p M02.gbr >> $fname.pan;; 
           layer_valid=TRUE;
	   }
       if(strcmp(typestr,"TSM") == 0 )
	   {
		 cat_11files( "pulltest.gbr", "metal.gbr",fnamep,pcmnamex,
			 fnameo,fnamew,"outer.t","testout.gbr","punch.z",fnamey,"tsm.gbr",fnamepan);
         layer_valid=TRUE;
	   }
       if(strcmp(typestr,"METAL") == 0 )
	   { 
		   cat_8files("metal.gbr",fnamep,pcmnamex,fnameo,fnamew,
			   "inner.t","testin.gbr",fnamey,fnamepan); 
           layer_valid=TRUE;
	   }
       if(strcmp(typestr,"TESTIN") == 0 )
	   {
		   cat_7files( "metal.gbr",fnamep,pcmnamex,fnameo,
			   fnamew,"outer.t","testout.gbr",fnamepan);  
	       layer_valid=TRUE; 
	   }
	   if(strcmp(typestr,"CORE" ) == 0 )
	   {
		   cat_7files( "arrow.gbr", "laser.gbr", "outline.gbr",fnamep,
			         fnamex,fnamew,"core.gbr",fnamepan); 
	       layer_valid=TRUE; 
	   }
	   if(strcmp(typestr,"BSM"  ) == 0 )
	   {
		   cat_11files( "pulltest.gbr", "metal.gbr",fnamep,pcmnamex,fnameo,
			   fnamew,"outer.t","testout.gbr",fnamey,"punch.z","bsm.gbr",fnamepan); 
	       layer_valid=TRUE;
	   }
	   if(strcmp(typestr,"BSOLDER")== 0 )
	   {
		   cat_6files( "nonmetal.gbr",fnamep,fnameo,fnamew,"smask.t","soldermask.gbr",fnamepan); // $fname.pan;;
	       layer_valid=TRUE; 
	   }
	   
       if(strcmp(typestr,"BLINDOUT")== 0)
		{
			cat_7files("nonmetal.gbr",fnamep,pcmnamex,fnameo,fnamew,"aoiviamask.gbr","blind.t",fnamepan); // > $fname.pan
	        cat_files(pcmnamex,"blind.t",fnamepanl);    // $pcmname.x blind.t > $fname"pan.l"
	        cp_file_fromsub("scm",fnamecen,fnamescml); // ../scm/$fname.cen $fname"scm.l" ;;
            layer_valid=TRUE;
		}
       if(strcmp(typestr,"BLINDIN")== 0 )
	   {
		   cat_6files( "nonmetal.gbr",fnamep,pcmnamex,fnameo,fnamew,"aoiviamask.gbr",fnamepan); // > $fname.pan
	       // cat $pcmname.x > $fname"pan.l"
		   cp_file(pcmnamex,fnamepanl);
	       cp_file_fromsub("scm",fnamecen,fnamescml); // ../scm/$fname.cen $fname"scm.l" ;;
		   layer_valid=TRUE;
	   }

	   if(strcmp(typestr,"RESISTOR")==0)
	   {
		  cat_6files( "arrow.gbr", "outline.gbr", "artwork.gbr",pcmnamex,fnameo,fnamew,fnamepan);  
		  layer_valid=TRUE;
	   }
	  
	  if((strcmp(typestr,"MECH") == 0 ) || 
		(strcmp(typestr,"CUTOUT")==0) ||
		(strcmp(typestr,"DRILL" )== 0 ))
	  {
		 cp_file_tosub(fnamep,"mech",fnamem); 
         layer_valid=TRUE;
	  }

	  if(strcmp(typestr,"OUTLINE")== 0)
	  {
		 cat_3files(fnamep,pcmnamex,"outline.gbr",fnamepan); // 
		 cp_file_tosub(fnamep,"mech",fnamem); 
		 layer_valid=TRUE;
	  }

	 if(strcmp(typestr,"STENCIL")== 0)
	 {
		 cat_3files(fnamep,fnamew,"stencil.gbr",fnamepan); 
		 layer_valid=TRUE;
	 }

	 if((strcmp(typestr,"STIFFENER")== 0) ||
	    (strcmp(typestr,"STIFFNER")==0) ||
		(strcmp(typestr,"STIFF") ==0))
	 {
		 cp_file_from_to("scm",fnamecen,"mech",fnamem); // ../scm/$fname.cen  ../mech/$fname.m ;;
		 layer_valid=TRUE;
	 }
	    
	 if(strcmp(typestr,"BURIED")==0)
	 {
		      cat_files(pcmnamex,"buried.t",fnamepanl); // 
		      cp_file_from_to("scm",fnamecen,"aoi",fnamecen); // $fname.cen  ../aoi/$fname.cen 
		      cp_file_fromsub("scm",fnamecen,fnamescml);  // $fname"scm.l" ;;
			  layer_valid=TRUE;
	 }
	 if(strcmp(typestr,"THRU")==0)
	 {
		     cat_files( pcmname, "thruvia.gbr",fnamepanl); //  > $fname"pan.l"
		      cp_file_from_to("scm",fnamecen,"aoi",fnamecen); // ../scm/$fname.cen  ../aoi/$fname.cen 
		      cp_file_fromsub("scm",fnamecen,fnamescml); // ../scm/$fname.cen $fname"scm.l" ;;
			 layer_valid=TRUE;
	 }

	 if(layer_valid == FALSE)
	 {
	    printf( "$myfile Invalid layer type");
	 }

	 endoffile=getline(file1,thisline);
	 nf=split_line(thisline);
   }                          // end while
   fclose(file1);
  }
 else  // if file exists
  {
	  printf( "File not found \n");
  }
 }   // arg count ok

}  // end main

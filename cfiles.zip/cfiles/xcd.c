#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <windows.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS  1

int chk_wb_call(char *infilestr);
void mod_top_bot2_call_out( char *infilestr, char *infile2str, char *outfilestr);
//void add_tol_call_out( char *infile1str, char *infile2str, char *outfilestr);
void add_tol2_call_out( char *infile1str, char *infile2str, char *outfilestr);
int makehdr_call();
void get_cd_call_out(char *infile1str, char *infile2str, char *outfilestr);
void getcd_wlbi_call_out(char *infile1str, char *infile2str, char *outfilestr);

int splitcontrol_call( char *infile);

//Format script for 7 layer scm packages.  Formats cd.txt file
//09/24/97 wlee
//
//Revision History
//09/25/97 - rev 1 - initial release
//09/30/97 - rev 2 - changed PARTNUMBER variable to grep part number from
//                   report/makelog
//11/19/97 - rev 3 - added feature to exit if $PARTNUMBER.mcm is not found
//02/12/98 - rev 4 - added "layer type finished artwork tolerance header" information
//02/24/98 - rev 5 - Removed V25 information
//12/02/98 - rev 6 - grep for STENCIL and add to cd.txt

//02/04/03 - rev7 - modified script completely. now handle micron designs.
//                   adjust data with offset from offsets file. stencil information removed.
//                   support for wlbi 5 removed. - tsa

//03/09/03 - rev7.1- now calls add_tol2.awk. This only tolerances the first feature of each layer.
//                     converts report/makelog to unix format
//                   - converts control/partnumber.ctl to unix format
//                   - converts report/offsets to unix format (tsa)

int endoffile;
char PROGNAME[120];  // ${0##*/}
char myname[120];
char myfname[120];
char mytype[120];
char chkfilestr[200];
char offsetfilestr[300];
char chkfile1str[200];
char mcmfilestr[300];
char makelogfilestr[300];
char partnumberfilestr[300];
char commandstr[300];
char REV[100];
int kk;
int hdr_res;
int debug;

char thisline[300];
int type_res;
int split_ret;

char rest[120];
FILE *protofile;
FILE *layerfile;
FILE *itxtfile;
FILE *cdfile;
char LIBPATH[200];
char PARTNUMBER[200];

// PROGPATH="/swtools/remote/bin/cd_file"

// LIBPATH="/usr/local/library"

int status;


void get_partnumber( char *infilestr, char *partstr)
{
FILE *infile;
int endfile;
char thisline[400];
char tmp[120][10];

 infile = fopen(infilestr,"r");
 if (infile == NULL)
	{
	 printf("In get_partnumber, unable to open the input file = %s \n",infilestr);
	 exit(-1);
 }

 endfile=getline(infile,thisline);
 while(endfile == FALSE)
 {

	 if (strstr(thisline,"Part Number") != NULL)
	 {
		 split(thisline,tmp[0],tmp[1],":");
         strncpy(partstr,tmp[1],120);
         return;
	 }

	 endfile=getline(infile,thisline);
 }

 fclose(infile);
 printf("Error in get_partnumber: No partnumber found \n");

} 



void  exit_program_cd( int statval)
{
int tmp_status;

   tmp_status=statval;
   if ( statval == 0 )
   {
       cat_files( "proto.hdr", "cd_tmp", "cd.txt"); // >  cd.tmp
      // ux2dos  cd.tmp > cd.txt
       printf("cd.txt has been updated \n");
       //rm -rf cd_myold.txt 
	   rm_file("cd_myold.txt");
	   rm_file("proto.hdr");
   }
   else
   {
       printf( "cd.txt has NOT been updated\n");
       if ( file_exists( "cd_myold.txt" ) )
       {
           cp_file("cd_myold.txt","cd.txt");
		   rm_file("cd_myold.txt");
       }
   }

  // rm -rf extract.log* input.txt cd_tmp layers locals extract_tmp1 extract_tmp2 parse_tmp1 parse_tmp2
  // rm -rf extract.log* 

system("rm extract.log*");
rm_file("input.txt");
rm_file("cd_tmp");  
rm_file("layers"); // -rf layers 
rm_file("locals");
rm_file("extract_tmp1");
rm_file("extract_tmp2");
rm_file("parse_tmp1"); 
rm_file("parse_tmp2");
 
//exit(statval);
}

int xcd_call()
{
//---------------------------------------------------------------
// Creates partnumber variable to be passed on
//---------------------------------------------------------------

if ( WINDOWS)
{
	strncpy(dirsep,"\\",4);
}
else
{
	strncpy(dirsep,"/",4);
}

//strncpy(LIBPATH,dirsep,10);  // usr/local/library
//strncat(LIBPATH,"usr",10);
//strncat(LIBPATH,dirsep,10);
//strncat(LIBPATH,"local",10);
//strncat(LIBPATH,dirsep,10);
//strncat(LIBPATH,"library",20);

system("rm extract.log*");
rm_file("input.txt");
rm_file("cd_tmp");  
rm_file("layers"); // -rf layers 
rm_file("locals");
rm_file("extract_tmp1");
rm_file("extract_tmp2");
rm_file("parse_tmp1"); 
rm_file("parse_tmp2");

rm_file("proto.hdr"); // -rf  proto.hdr


strncpy(REV,"7.1",20);

status=0;
debug = 0;
strncpy(PROGNAME,"xcd",90);

printf( "Running %s %s\n",PROGNAME,REV);

if (  file_exists( "cd.txt" ) )
{
    // mv cd.txt cd_myold.txt
	cp_file("cd.txt","cd_myold.txt");
	rm_file("cd.txt");

}

strncpy(chkfilestr,"report",20);   // report/makelog
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"makelog",20);

if (debug) { printf("checking %s \n", chkfilestr); }


if (  (! (file_exists(chkfilestr) ) ) || (! ( file_is_readable(chkfilestr) ) ))   // -r report/makelog 
{
    printf("FATAL ERROR: report%smakelog does not exist or is not readable\n",dirsep);
    status=1;
    exit_program_cd(status);
	return(status);
}

// dos2ux report/makelog > report/makelog.tmp
// mv  report/makelog.tmp report/makelog

  strncpy( makelogfilestr,chkfilestr,120);

//PARTNUMBER=`grep "Part Number" report/makelog | cut -d: -f2`  // extracts part number

 get_partnumber( makelogfilestr, PARTNUMBER);

strncpy(chkfilestr,PARTNUMBER,120);  // $PARTNUMBER.mcm
strncat(chkfilestr,".mcm",10);

if (debug) { printf("Checking %s \n", chkfilestr); }

if (  (! file_exists(chkfilestr)  )  || ( ! file_is_readable( chkfilestr) ) ) //     -r $PARTNUMBER.mcm 
{
    printf("FATAL ERROR: %s.mcm does not exist or is not readable\n",PARTNUMBER);
    status=2;
    exit_program_cd(status);
	return(status);
}
strncpy(chkfilestr,"control",120);  // control/$PARTNUMBER.ctl
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,PARTNUMBER,120);
strncat(chkfilestr,".ctl",10);

if (  (! (file_exists(chkfilestr)  ) ) || (! (file_is_readable(chkfilestr) ) ) )
                                              // ,-r control/$PARTNUMBER.ctl 
{
    printf("FATAL ERROR: control/%s.ctl does not exist or is not readable\n",
		 PARTNUMBER);
    status=3;
    exit_program_cd(status);
	return(status);
}

// dos2ux control/$PARTNUMBER.ctl > control/$PARTNUMBER.ctl.tmp
//mv control/$PARTNUMBER.ctl.tmp control/$PARTNUMBER.ctl

split_ret=splitcontrol_call(chkfilestr);

// split=$?

if ( split_ret != 0 )
{
    printf("FATAL ERROR: control/%s.ctl is corrupt\n",PARTNUMBER);
    status=4;
    exit_program_cd(status);
	return(status);
}

strncpy(chkfilestr,"report",30);  // report/OFFSETS
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"offsets",20);

if (  (! ( file_exists( chkfilestr) ) ) || ( ! (file_is_readable( chkfilestr) ) ) )
                                               //  -r report/offsets 
{
	strncpy(chkfile1str,"report",30);   // report/OFFSETS
    strncat(chkfile1str,dirsep,10);
    strncat(chkfile1str,"OFFSETS",20);

	if ( ! WINDOWS)
	{ 
      if (  file_exists( chkfile1str)  && file_is_readable( chkfilestr) ) //  -r report/OFFSETS  reduncant on window, same file
	  {
      cp_file(chkfile1str,chkfilestr); // report/OFFSETS report/offsets
	  }
     else
	 {
      printf("FATAL ERROR: report%soffsets does not exist or is not readable\n",dirsep);
      status=5;
      exit_program_cd(status);
	  return(status);
	 }
	}
	else
	{
      printf("FATAL ERROR: report%soffsets does not exist or is not readable\n",dirsep);
      status=5;
      exit_program_cd(status);
	  return(status);
	}
}   

// dos2ux report/offsets > report/offsets.tmp
// mv report/offsets.tmp report/offsets

hdr_res = makehdr_call();      // update the header information.
// hdr_res=$?

if ( hdr_res != 0 )
{
    printf("FATAL ERROR: unable to create header information\n");
    status=6;
    exit_program_cd(status);
}

strncpy(makelogfilestr,"report",20);     // report/makelog
strncat(makelogfilestr,dirsep,10);
strncat(makelogfilestr,"makelog",20);

type_res=chk_wb_call( makelogfilestr  );       // test see if part is a WLBI part 

// type_res=$?                      //  type_res = 2 if a WLBI part

//---------------------------------------------------------------
// Extracts Package information
//---------------------------------------------------------------
itxtfile=fopen("input.txt","w");
if (itxtfile==NULL)
{
	printf("In xcd, unable to open the file = %s for writing\n","input.txt");
	exit(-1);
}

fprintf(itxtfile, "# VIEW:\n" ); // >  input.txt
fprintf(itxtfile, "FULL_GEOMETRY\n"); //     // >>  input.txt
fprintf(itxtfile, "# VIEW OPTIONS:\n"); // >> input.txt
fprintf(itxtfile, "SUBCLASS\n");           // >> input.txt
fprintf(itxtfile, "PAD_STACK_NAME\n"); // >> input.txt
fprintf(itxtfile, "GRAPHIC_DATA_NAME\n"); // >> input.txt
fprintf(itxtfile, "GRAPHIC_DATA_10\n"); //  >> input.txt
fprintf(itxtfile, "GRAPHIC_DATA_4\n"); // >> input.txt
fprintf(itxtfile, "GRAPHIC_DATA_5\n"); // >> input.txt
fprintf(itxtfile, "GRAPHIC_DATA_7\n"); // >> input.txt
printf(           "\n");
printf(           "Extracting from %s.mcm\n",PARTNUMBER); //

fclose(itxtfile);

//---------------------------------------------------------------
// Extracts information on the package and changes output file.
// so it is ready for the next step.
//---------------------------------------------------------------

strncpy(mcmfilestr,PARTNUMBER,100);  // $PARTNUMBER.mcm
strncat(mcmfilestr,".mcm",10);

if (WINDOWS)
{
  strncpy(commandstr,"extracta -q ",30);
}
else
{
  strncpy(commandstr,"extract -q ", 30);
}
strncat(commandstr,mcmfilestr,120);
strncat(commandstr," input >extract_tmp1",100);

system (commandstr );  // > extract_tmp1

strncpy(partnumberfilestr,"control",20);  // control/$PARTNUMBER.ctl
strncat(partnumberfilestr,dirsep,10);
strncat(partnumberfilestr,PARTNUMBER,120);
strncat(partnumberfilestr,".ctl",10);

if (debug) { printf("About to call mod_top_bot2\n"); }

mod_top_bot2_call_out( partnumberfilestr ,  "extract_tmp1", "tmpz");

if (debug) { printf("About to call sort\n"); }

// cat tmpz | sort |uniq > extract_tmp2
system("sort tmpz >tmpzz");
uniq_lines("tmpzz","extract_tmp2");
rm_file("tmpz");
rm_file("tmpzz");

strncpy(offsetfilestr,"report",20);   // report/offsets
strncat(offsetfilestr,dirsep,10);
strncat(offsetfilestr,"offsets",20);

if ( type_res == 2 )
{
   printf("Part is a WLBI \n");

   getcd_wlbi_call_out(offsetfilestr, "extract_tmp2", "tmpx" );
   // cat tmpx | sort | uniq > parse_tmp1 
    system("sort tmpx >tmpxx");
    uniq_lines("tmpxx","parse_tmp1");
    rm_file("tmpxx");
}
else
{
	if (debug) { printf("About to call get_cd \n"); }

   get_cd_call_out( offsetfilestr ,"extract_tmp2","tmpy");
   // cat tmpy | sort | uniq > parse_tmp1

   if (debug) { printf("About to call sort for tmpyy\n"); }

    system("sort tmpy >tmpyy");
    uniq_lines("tmpyy","parse_tmp1");
    rm_file("tmpyy");
}

if (debug) { printf("About to call add_tol2_call \n"); }

   add_tol2_call_out( offsetfilestr , "parse_tmp1","parse_tmp2"); //  > parse_tmp2 
//---------------------------------------------------------------
// Parses the parse_tmp file and creates format_tmp file.
//---------------------------------------------------------------

protofile=fopen("proto.hdr","a");
if (protofile == NULL)
{
  printf("In xcd, unable to open the output file = %s \n", "proto.hdr");
  exit(-1);
}

fprintf(protofile,"\nCritical Dimensions\n"); //  >> proto.hdr
fprintf(protofile,"layer   type    finished   artwork    tolerance \n"); // >> proto.hdr
fclose(protofile);

if (debug) { printf("Opening cd_tmp \n"); }

cdfile=fopen("cd_tmp","w");
if (cdfile == NULL)
{
  printf("In xcd, unable to open the output file = %s \n", "cd_tmp");
  exit(-1);
}

// typeset -u myname

if (debug) { printf("Opening layers \n"); }

 layerfile=fopen("layers","r");

 if (layerfile==NULL)
 {
	 printf("Unable to open the layers file for reading \n");
	 exit(-1);
 }

endoffile=getline(layerfile,thisline);
split_line(thisline);


while(endoffile == FALSE)        // read myname myfname mytype rest
{
	if (debug) { printf("reading layers file , line = %s \n", thisline); }

 strncpy(myname,str_array[0],120);
 for(kk=0;kk<(signed int) strlen(myname); kk +=1)
 {
	 myname[kk]=toupper(myname[kk]);
 }

 strncpy(myfname,str_array[1],120);
 strncpy(mytype,str_array[2],120);
 strncpy(rest,str_array[3],120);

 if (  (strcmp(mytype,"BURIED" )!=0) && (  strcmp(mytype,"THRU" ) != 0 ) )
 {
    fprintf(cdfile,"\n"); //   >> cd_tmp
    grep_file_to_file(myname,"parse_tmp2", cdfile ); // >> cd_tmp
 }
 if (  myname[0] == 'L' )    //         = L* 
 {
    fprintf(cdfile, "%s     SPACE \n",myname); //  >> cd_tmp
 }


 endoffile=getline(layerfile,thisline);
 split_line(thisline);

}  // read from  < layers

fclose(layerfile);

if ( type_res == 2 )
{
   grep_file_to_file("R0","parse_tmp2",cdfile); //  "R0" parse_tmp2 >> cd_tmp
}

fclose(cdfile);

exit_program_cd(status);
return(status);

}  // end

/*
int main( int argc, char **argv)
{
int xcdstat;

	if (argc != 1)
	{
		printf("xcd: no arguments to xcd \n");
		exit(-1);
	}
	else
	{
		xcdstat = xcd_call();
	}

}  // end main

  */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAXSTRING 120

char scan_array[1000][120];

// Rev 1
// Title: Xcenall
// written by Ted Ammann 7/25/96

// calling Syntax
//     Xcenall .ext   (i.e. Xcenall .art)

// Program centers standard gerber files around 0,0
// It does this for all files in the current directory that
// have the extension passed in from the command line ($1).  A new file
// with a .cen extension is created for each file.
// 
// Note: the program creates a file called offval 
// Note: Program uses calls two other scripts getoffset and centergbr
//       Please see those scripts for possible other side effects.
// Note: A file called outline.ext is required to be in the current directory

// Revision History
//    Rev 1  released on 7/25/96

//
//   Scan directory for regular files that match a particular extension
//
int scandir_matchext(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr)		// starting dir, could be an arbitrary label
{

	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	int ll;
	int kk;
	char fname_ext[MAXSTRING];
	int scan_file_count;

	
	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	sprintf(szDir, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	scan_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE){ 
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return(-1);
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;
		
		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			sprintf(newdir,"%s/%s",dir,fname);

    			scandir_matchext(newdir,recurse,matchstr);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name 
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/

			 // get the ext ( all chars after first dot )

			kk=0;
			ll=0;
			fname_ext[0]=0;
			while((fname[kk] != '.') && (kk < strlen(fname)) )
			{
				kk += 1;
			}
			if ( fname[kk] == '.')
			{
				fname_ext[ll]=fname[kk];
				kk += 1;
				ll += 1;
			}
			while( kk < strlen(fname))
			{
				fname_ext[ll] = fname[kk];
				kk += 1;
				ll += 1;
			}
			fname_ext[ll] = 0;

			// printf("fname_ext = %s \n",fname_ext);

			if (strcmp(fname_ext,matchstr) == 0 )
			{
			// printf("fname = %s \n",fname);
			  if (scan_file_count < 1000 )
			  {
				 strncpy(scan_array[scan_file_count],fname,120);
				 scan_file_count += 1;
			  }
			  else
			  {
				  printf("Number of files in the directory exceeds 1000 \n");
			  }

			}

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return(scan_file_count);
}


//
//  Check if a file exists
//
int file_exists( char *infile)
{
FILE *tfile;

 tfile = fopen(infile,"r");

 if (tfile == NULL)
 {
	 return(0);
 }
 else
 {
	 fclose(tfile);
	 return(1);
 }

} // file_exists

int xcenall_call( char *extstr)
{
char outlinefilestr[200];
int number_ext_files;
int i;
char censtr[200];
int kk;



	strncpy(outlinefilestr,"outline",20);
	strncat(outlinefilestr,extstr,10);

    if ( file_exists( outlinefilestr ) ) // verify outline.ext is present
    {
	// get the offset values
        printf( "RUNNING getoffset outline%s > offval \n",extstr);

        getoffset_call(outlinefilestr,"offval"); // outline$1 > offval
	// center each file in directory
       // tmp=$(ls *$1)
		// get all the files with the ext = extstr in the current directory

	    number_ext_files =scandir_matchext(".",0,extstr);    // not recursive

		i=0;
        while( i < number_ext_files) // in $tmp
        {
			strncpy(censtr,scan_array[i],120);
			kk=0;
			while(( censtr[kk] != '.') && (kk < strlen(censtr)))
			{
				kk += 1;
			}
			censtr[kk] = 0;
			strncat(censtr,".cen",10);

            printf( "RUNNING centergbr offval %s %s \n",scan_array[i],censtr);
				                           
            centergbr_call("offval", scan_array[i], censtr); 
		}
	}
    else
	{
       printf( "No outline%s  file found \n",extstr);
    }
 
  return(0);

}  // end xcenall_call

int main( int argc , char **argv)
{
int tint;
char progname[200];
char usagestr[200];
char wherestr[200];
char examplestr[200]; 

 strncpy(progname,"xcenall",40);  // =${0##*/}
  sprintf(usagestr,"usage: %s .from ",progname); 
  strncpy(wherestr,"  from extention of gerber files ",80);
  sprintf(examplestr,"   %s .gbr ",progname);

 if (argc == 2)
 {
  tint=xcenall_call( argv[1]);
 }
 else
 {
  printf( "incorrect number of arguments\n");
   printf( "%s \n %s\n %s\n",usagestr,wherestr,examplestr);
 }

}   // end main
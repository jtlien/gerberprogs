#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <math.h>

#include "utilprogs.h"


#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

int centergbr_call( char *file1_instr, char *file2_instr, char *file3_instr);
void getoffset3_call_out( char *infilestr,char *outfilestr);

// Rev 1
// Title: Xcenall
// written by Ted Ammann 7/25/96

// calling Syntax
//     Xcenall2 .ext   (i.e. Xcenall2 .art)

// Program centers standard gerber files around 0,0
// It does this for all files in the current directory that
// have the extension passed in from the command line ($1).  A new file
// with a .cen extension is created for each file.
// 
// Note: the program creates a file called offval 
// Note: Program uses calls two other scripts getoffset and centergbr
//       Please see those scripts for possible other side effects.
// Note: A file called outline.ext is required to be in the current directory

// Revision History
//    Rev 1  released on 7/25/96


int xcenall2_call( char *extstr)
{
char outlinefilestr[200];
int number_ext_files;
int i;
char censtr[200];
int kk;



	strncpy(outlinefilestr,"outline",20);
	strncat(outlinefilestr,extstr,10);

    if ( file_exists( outlinefilestr ) ) // verify outline.ext is present
    {
	// get the offset values
        printf( "RUNNING getoffset3 outline%s > offval \n",extstr);

        getoffset3_call_out(outlinefilestr,"offval"); // outline$1 > offval

	// center each file in directory
       // tmp=$(ls *$1)
		// get all the files with the ext = extstr in the current directory

	    number_ext_files =scandir_matchext(".",0,extstr);    // not recursive

		i=0;
        while( i < number_ext_files) // in $tmp
        {
			strncpy(censtr,scan_array[i],120);
			kk=0;
			while(( censtr[kk] != '.') && (kk < (signed int) strlen(censtr)))
			{
				kk += 1;
			}
			censtr[kk] = 0;
			strncat(censtr,".cen",10);

            printf( "RUNNING centergbr offval %s %s \n",scan_array[i],censtr);
				                           
            centergbr_call("offval", scan_array[i], censtr); 

			i += 1;
		}
	}
    else
	{
       printf( "No outline%s  file found \n",extstr);
    }
 
  return(0);

}  // end xcenall2_call



int main( int argc, char **argv)
{

  if ( argc != 2 )
   {
    printf("In xcenall2, wrong number of arguments \n");
	printf("Usage: xcenall2 ext \n");
	printf("Example: xcenall2 .gbr ( you also need a file outline.gbr ) \n");
	exit(-1);
   }
   else
   {
    xcenall2_call( argv[1]);
	}

}  








#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0



// progname=${0##*/}
// USAGE="usage: $progname aptcode .from "
// WHERE="\t.from =  extention of gerber files"
// EXAMPLE="\tex:  $progname 204 .gbr"

// Rev 1
// Title: xconvert
// written by Ted Ammann 1/2/97

// calling Syntax
//     xconvert aptcode .ext   (i.e. Xcenall 204 .art)

// Program converts gerber files based on command line parameter
// aptcode. Aptcode is the result from calling the script AptINtoMM
// Converts gerber files from inches to millimeters, from
// from incremental to absolute coordinates, or changes the precision
// of the gerber data
// 
// Note: program calls 3 other scripts GbrINtoMM, InctoAbs, and
//       GbrFmtChg. Please see those file for possible other side effects 



int gbrfmtchg_call(int mult1, char *infile, char *outfile )
{
FILE *file1;
FILE *file2;

char thisline[200];
int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];

double xval;
double yval;

char X[120];
char Y[120];
int val;
int tmp;
double mult;

    file1  = fopen(infile, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infile);
	  exit(-1);
	}

   file2  = fopen(outfile, "w");

    if (file2 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",outfile);
	  exit(-1);
	}

// mult1 is command line varible that is current format

  // mult1 = atoi(argv[1]);

  tmp = 4 - mult1;          

  //  output a warning if precision is x.5 or more

  if( tmp < 0){
     printf("FORMAT IS GREATER THAN 5.4 \n" );
     printf("DATA MAY BE LOST \n");
  }

 // MULT = 10 ** tmp 
  mult = pow(10.0,tmp);


 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL))     // G54 preceeds aperture
   {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       
       
       xval=atof(X);
       yval=atof(Y);
       xval=xval*mult;
       yval=yval*mult;
       fprintf(file2,"X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
  }
  // if line has only X data modify it
  else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {
      split(thisline,b[0],b[1],"X");
      split(thisline,d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
      xval=atof(X);
     
      xval= mult * xval;
      fprintf(file2,"X%0.0fD%s\n", xval,d[1]);
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
      split(thisline,c[0],c[1],"Y");
      split(thisline,d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
   
      yval=atof(Y);
      yval=yval * mult;
      fprintf(file2,"Y%0.0fD%s\n",yval,d[1]);
  }
  // line has no X or Y data so just output it
  else
  {
    fprintf(file2,"%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }

 fclose(file1);
 fclose(file2);

 return(0);

}  // end gbrfmtchg_call

int gbrintomm_call(char *infile, char *outfile)
{

FILE *file1;
FILE *file2;

char thisline[200];

int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];

double xval;
double yval;

char X[120];
char Y[120];
int val;

  file1  = fopen(infile, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infile);
	  return(-1);
  }

  file2  = fopen(outfile, "w");

  if (file2 == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",outfile);
	  return(-1);
  }

 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL))
   {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       //	 X = X * 25.4;
       // Y = Y * 25.4;
       xval=atof(X);
	  // printf("Y = %s  strlen a1 = %d a1 = %s \n",Y,strlen(a[1]),a[1]);

       yval=atof(Y);
       xval=xval*25.4;
       yval=yval*25.4;
       fprintf(file2,"X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
  }
  // if line has only X data modify it
  else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {
      split(thisline,b[0],b[1],"X");
      split(thisline,d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
      xval=atof(X);
      // X = X * 25.4;
      xval=25.4 * xval;
      fprintf(file2,"X%0.0fD%s\n", xval,d[1]);
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
      split(thisline,c[0],c[1],"Y");
      split(thisline,d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
      // Y = Y * 25.4
      yval=atof(Y);
      yval=yval * 25.4;
      fprintf(file2,"Y%0.0fD%s\n",yval,d[1]);
  }
  // line has no X or Y data so just output it
  else
  {
    fprintf(file2,"%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }

 fclose(file1);
 fclose(file2);

 return(0);

}  // end grbintomm_call


int inctoabs_call( char *infilestr, char *outfilestr)
{
FILE *file1;
FILE *file2;

int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];

double xval;
double yval;

char X[120];
char Y[120];
int val;
double xoffset;
double yoffset;
char thisline[200];

  xoffset = 0.0;
  yoffset = 0.0;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
    {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
    }

  file2 = fopen(outfilestr, "w");

  if (file2 == NULL)
    {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
    }
//**************START OF MAIN *********************************
// handles data depending on if the line has  X & Y data,
// X data only, Y data only , or no X,Y data.
//********************************************************************

 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL))     // G54 preceeds aperture
   {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       xval=atof(X);
       yval=atof(Y);
       xval = xval + xoffset;
       yval = yval + yoffset;
       xoffset = xval;   // set x and y offset to current position
       yoffset = yval;
       fprintf(file2,"X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
  }
  // if line has only X data modify it
   else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {
      split(thisline,b[0],b[1],"X");
      split(thisline,d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
      xval=atof(X);
      xval = xval + xoffset;
      xoffset = xval;    // adjust xoffset
      fprintf(file2,"X%0.0fD%s\n", xval,d[1]);
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
      split(thisline,c[0],c[1],"Y");
      split(thisline,d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
   
      yval=atof(Y);
      yval = yval + yoffset;
      yoffset = yval;   //adjust yoffset
      fprintf(file2,"Y%0.0fD%s\n", yval,d[1]);
  }
  //   line has no X or Y data so just output it
 else
  {
    fprintf(file2,"%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }
 fclose(file1);
 fclose(file2);
 return(0);

} // end 

// Revision History
//    Rev 1  released on 1/2/97

int xconvert_call( char *codestr, char *dirstr)
{
int code;

char fromfilestr[200];
char tofilestr[200];
char currentdirstr[200];
int scan_file_count;
int i;

 strncpy(currentdirstr,"",4);

 
   code = atoi(codestr);

   //  if CODE is >= 100 then convert gerber files
   //  from inches to millimeters

  if ( code  >= 100 )
   {
     mvall(dirstr,".tmp");  // copy all that end with string1, to files ending in str2

	 scan_file_count=scandir_matchext(currentdirstr,0,".tmp");
	 i=0;

	 while( i < scan_file_count)
	 {
		strncpy(fromfilestr,scan_array[i],120);
		subexten(fromfilestr,tofilestr,dirstr);     // replace .tmp with argv[2]

     
	    printf("RUNNNING gbrintomm %s %s \n",fromfilestr,tofilestr); //
                                                   //   > ${i%.*}$2" 
	    gbrintomm_call( fromfilestr,tofilestr);       // GbrINtoMM $i > ${i%.*}$2
	    i += 1;
	 }
     code=code-100;     // decrement CODE by 100
   } 

   // if code is >= 10 then convert gerber files from
   // incremental to absolute coordinates

  if ( code >= 10  )
   {
     mvall(dirstr,".tmp");
     scan_file_count= scandir_matchext(currentdirstr,0,".tmp");
	 i=0;

	 while( i < scan_file_count)
	 {
		strncpy(fromfilestr,scan_array[i],120);
		subexten(fromfilestr,tofilestr,dirstr);     // replace .tmp with argv[2]
        printf("RUNNING inctoabs %s %s \n",fromfilestr,tofilestr); //
                                                  //  $i > ${i%.*}$2"
        inctoabs_call( fromfilestr,tofilestr); // InctoAbs $i > ${i%.*}$2
		i+=1;
     }
   code=code-10;  //  decrement CODE by 10
   }

   // if code is != 4 then change precision of gerber files to be 4
   if ( code != 4 )
   {
     mvall(dirstr,".tmp");
     scan_file_count = scandir_matchext(currentdirstr,0,".tmp");
	 i=0;
	 while( i < scan_file_count)
	 {
		strncpy(fromfilestr,scan_array[i],120);
		subexten(fromfilestr,tofilestr,dirstr);     // replace .tmp with argv[2]
   
	    printf("RUNNING gbrfmtchg %d %s %s \n",code,fromfilestr,
	       tofilestr);   //  $i > ${i%.*}$2"
         gbrfmtchg_call(code,fromfilestr,tofilestr); // -v mult1=$CODE $i > ${i%.*}$2
		 i+= 1;
	 }
   }
  return(0);

 }  // end xconvert_call


/*
int main( int argc, char **argv)
{
int tint;

 if(argc != 3)
 {
   printf("incorrect number of arguments");
   printf("usage: xconvert aptcode .from \n");
   printf("where from = extention of gerber files \n");
   printf(" example: xconvert 204 .gbr \n");
   exit(-1);
 }
 else
 {
    tint=xconvert_call( argv[1], argv[2]);
 } 

}  
*/



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <math.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

double xoffset;
double yoffset;


// progname=${0##*/}
// USAGE="usage: $progname aptcode .from "
// WHERE="\t.from =  extention of gerber files"
// EXAMPLE="\tex:  $progname 204 .gbr"

// Rev 1
// Title: xconvert
// written by Ted Ammann 1/2/97

// calling Syntax
//     xconvert aptcode .ext   (i.e. Xcenall 204 .art)

// Program converts gerber files based on command line parameter
// aptcode. Aptcode is the result from calling the script AptINtoMM
// Converts gerber files from inches to millimeters, from
// from incremental to absolute coordinates, or changes the precision
// of the gerber data
// 
// Note: program calls 3 other scripts GbrINtoMM, InctoAbs, and
//       GbrFmtChg. Please see those file for possible other side effects 

void getstring274f( val , myval)
char*  val; char*  myval;
{
  val++;
  *myval= *val; 
  val++;
  myval++;
  while( isdigit(*val) ){
     *myval = *val ;
     val++;
     myval++;
  }
  *myval = '\0';
}

void getbeforef( mystring, myval , mychar)
char* mystring; char* myval ; char mychar;
{
  while( *mystring != mychar ){
     *myval = *mystring ;
     mystring++;
     myval++;
  }
  *myval = '\0';
}

void getrestf( instring,  outstring,  mychar)
char*  instring; char*  outstring; char mychar;
{
  while( *instring != mychar ){
     instring++;
  }
  instring++;
  while( isdigit(*instring) || *instring == '-' ){
    instring++;
  }

  while( *instring != '\0' ){
       *outstring = *instring ;
       outstring++;
       instring++;
  }
  *outstring = '\0';
}

ProcessRestFmt274x(double mult, char *thestring, FILE *ofile)
{
     char* placeI;
     char* placeJ;
     char* placeD; 
     char FIRST[300];
     char REST[300];
     char I[300];
     char J[300];

     placeI = strchr( thestring, 'I');
     placeJ = strchr( thestring, 'J');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeI != NULL) && (placeJ != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbeforef(thestring,FIRST,'I');
         getstring274f(placeI,I);
	 getstring274f(placeJ,J);
	 getrestf(thestring,REST,'J');
	 fprintf(ofile,"%sI%0.0fJ%0.0f%s",FIRST,atof(I) * mult,atof(J)*mult, REST );
     }
     else if (  ( placeI != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbeforef(thestring,FIRST,'I');
         getstring274f(placeI,I);
	 getrestf(thestring,REST,'I');
	 fprintf(ofile,"%sI%0.0f%s",FIRST,atof(I) * mult ,REST );
     }
     else if ( ( placeJ != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbeforef(thestring,FIRST,'J');
	 getstring274f(placeJ,J);
	 getrestf(thestring,REST,'J');
	 fprintf(ofile,"%sJ%0.0f%s",FIRST,atof(J) * mult,REST );
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       fprintf(ofile,"%s", thestring);
    } 
    placeI = NULL;
    placeJ = NULL;
    placeD = NULL;
}


ProcessRestTomm274x(double mult, char *thestring, FILE *ofile)
{
     char* placeI;
     char* placeJ;
     char* placeD; 
     char FIRST[300];
     char REST[300];
     char I[300];
     char J[300];

     placeI = strchr( thestring, 'I');
     placeJ = strchr( thestring, 'J');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeI != NULL) && (placeJ != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbeforef(thestring,FIRST,'I');
         getstring274f(placeI,I);
	 getstring274f(placeJ,J);
	 getrestf(thestring,REST,'J');
	 fprintf(ofile,"%sI%0.0fJ%0.0f%s",FIRST,atof(I) * mult,atof(J)*mult, REST );
     }
     else if (  ( placeI != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbeforef(thestring,FIRST,'I');
         getstring274f(placeI,I);
	 getrestf(thestring,REST,'I');
	 fprintf(ofile,"%sI%0.0f%s",FIRST,atof(I) * mult ,REST );
     }
     else if ( ( placeJ != NULL) && (strchr(thestring, '%')  == NULL) ){
	 getbeforef(thestring,FIRST,'J');
	 getstring274f(placeJ,J);
	 getrestf(thestring,REST,'J');
	 fprintf(ofile,"%sJ%0.0f%s",FIRST,atof(J) * mult,REST );
     }
     else 
	 {                         /* if ( strchr(thestring , 'M') == NULL){*/
       fprintf(ofile,"%s", thestring);
    } 
    placeI = NULL;
    placeJ = NULL;
    placeD = NULL;
}

ProcessStringFmt274x(double mult, char *thestring,FILE *ofile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[300];
     char REST[300];
     char X[300];
     char Y[300];

     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) )
	 {
	  getbeforef(thestring,FIRST,'X');
         getstring274f(placeX,X);
	  getstring274f(placeY,Y);
	  getrestf(thestring,REST,'Y');
	  if ((strstr(REST,"I")==NULL) && (strstr(REST,"J")==NULL))  // no I or J
	  {
	   fprintf(ofile,"%sX%0.0fY%0.0f%s",FIRST,atof(X) * mult,atof(Y)*mult, REST );
	  }
	  else
	  { 
		fprintf(ofile,"%sX%0.0fY%0.0f",FIRST,atof(X) * mult,atof(Y)*mult);
        ProcessRestFmt274x(mult, REST, ofile);   // process I and J
	  }
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) )
	 {
	   getbeforef(thestring,FIRST,'X');
         getstring274f(placeX,X);
	   getrestf(thestring,REST,'X');
	   if ((strstr(REST,"I")==NULL) && (strstr(REST,"J")==NULL))  // no I or J
	   {
	     fprintf(ofile,"%sX%0.0f%s",FIRST,atof(X) * mult, REST );
	   }
	   else
	   {
		 fprintf(ofile,"%sX%0.0f",FIRST,atof(X) * mult );
         ProcessRestFmt274x( mult, REST, ofile);   // process I and J
	   }
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) )
	 {
	   getbeforef(thestring,FIRST,'Y');
	   getstring274f(placeY,Y);
	   getrestf(thestring,REST,'Y');
       if ((strstr(REST,"I")==NULL) && (strstr(REST,"J")==NULL))  // no I or J
	   {
	    fprintf(ofile,"%sY%0.0f%s",FIRST,atof(Y) * mult,REST );
	   }
	   else
	   {
		 fprintf(ofile,"%sY%0.0f",FIRST,atof(Y) * mult );
         ProcessRestFmt274x( mult, REST, ofile);   // process I and J
	   }
     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/
       fprintf(ofile,"%s", thestring);
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}

//
//  Process string for InctoAbs
//
ProcessStringInc274x( char *thestring,FILE *ofile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[300];
     char REST[300];
     char X[300];
     char Y[300];
     double xval;
	 double yval;

     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) )
	 {
	  getbeforef(thestring,FIRST,'X');
         getstring274f(placeX,X);
	  getstring274f(placeY,Y);
	  getrestf(thestring,REST,'Y');
	  
	  xval=atof(X);
	  yval=atof(Y);

	   fprintf(ofile,"%sX%0.0fY%0.0f%s",FIRST,atof(X) + xoffset,atof(Y)+ yoffset, REST );
	   xoffset=xval + xoffset;
	   yoffset=yval + yoffset;

     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) )
	 {
	   getbeforef(thestring,FIRST,'X');
         getstring274f(placeX,X);
	   getrestf(thestring,REST,'X');
	   
	     xval=atof(X);

	     fprintf(ofile,"%sX%0.0f%s",FIRST,atof(X) + xoffset, REST );
		 xoffset=xoffset+xval;

     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) )
	 {
	   getbeforef(thestring,FIRST,'Y');
	   getstring274f(placeY,Y);
	   getrestf(thestring,REST,'Y');
       
	   yval=atof(Y);

	    fprintf(ofile,"%sY%0.0f%s",FIRST,atof(Y) + yoffset,REST );

		yoffset=yoffset+yval;

     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/

		if (strstr(thestring,"FS") == NULL)
		{
           fprintf(ofile,"%s", thestring);
		}
		else
		{
			if ((thestring[0] == '%') && (thestring[1]=='F') && (thestring[2] == 'S')
				         && (thestring[4]=='I'))
			{
				thestring[4] = 'A';      // change %FS_I to %FS_A
			}
          fprintf(ofile,"%s",thestring);
		}
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}


//
//
//
ProcessStringTomm274x(double mult, char *thestring,FILE *ofile)
{
     char* placeX;
     char* placeY;
     char* placeD; 
     char FIRST[300];
     char REST[300];
     char X[300];
     char Y[300];

     placeX = strchr( thestring, 'X');
     placeY = strchr( thestring, 'Y');
    /* placeD = strchr( thestring, 'D');*/
     if( (placeX != NULL) && (placeY != NULL) && (strchr(thestring, '%')  == NULL) )
	 {
	   getbeforef(thestring,FIRST,'X');
         getstring274f(placeX,X);
	   getstring274f(placeY,Y);
	   getrestf(thestring,REST,'Y');
       if ((strstr(REST,"I")==NULL) && (strstr(REST,"J")==NULL))  // no I or J
	   {
	    fprintf(ofile,"%sX%0.0fY%0.0f%s",FIRST,atof(X) * mult,atof(Y)*mult, REST );
	   }
	   else
	   {
	    fprintf(ofile,"%sX%0.0fY%0.0f",FIRST,atof(X) * mult,atof(Y)*mult );
		ProcessRestTomm274x( mult,REST,ofile);
	   }
     }
     else if (  ( placeX != NULL) && (strchr(thestring, '%')  == NULL) )
	 {
	   getbeforef(thestring,FIRST,'X');
       getstring274f(placeX,X);
	   getrestf(thestring,REST,'X');
       if ((strstr(REST,"I")==NULL) && (strstr(REST,"J")==NULL))  // no I or J
	   {
	    fprintf(ofile,"%sX%0.0f%s",FIRST,atof(X) * mult ,REST );
	   }
	   else
	   {
        fprintf(ofile,"%sX%0.0f%s",FIRST,atof(X) * mult ,REST );
        ProcessRestTomm274x( mult,REST,ofile);
	   }
     }
     else if ( ( placeY != NULL) && (strchr(thestring, '%')  == NULL) )
	 {
	   getbeforef(thestring,FIRST,'Y');
	   getstring274f(placeY,Y);
	   getrestf(thestring,REST,'Y'); 
	   if ((strstr(REST,"I")==NULL) && (strstr(REST,"J")==NULL))  // no I or J
	   {
	     fprintf(ofile,"%sY%0.0f%s",FIRST,atof(Y) * mult,REST );
	   }
	   else
	   {
		 fprintf(ofile,"%sY%0.0f%s",FIRST,atof(Y) * mult,REST );
         ProcessRestTomm274x( mult,REST,ofile);
	   }

     }
     else {                         /* if ( strchr(thestring , 'M') == NULL){*/

	   if ( strstr(thestring,"MO")== NULL)
	   {
         fprintf(ofile,"%s", thestring);

	   }
       else
	   {
			if ((thestring[0] == '%') && (thestring[1]=='M') && (thestring[2] == 'O')
				         && (thestring[3]=='I') && (thestring[4]=='N'))
			{
				thestring[3] = 'M';      // change %FS_I to %FS_A
				thestring[4] = 'M';
			}
          fprintf(ofile,"%s",thestring);
		}
    } 
    placeX = NULL;
    placeY = NULL;
    placeD = NULL;
}



int gbrfmtchg_274x_call(int mult1, char *infilestr, char *outfilestr)
{
  
FILE *infile;
FILE *outfile;

char line[400];
int tmp;
double mult;

   tmp = 4 - mult1;          

  //  output a warning if precision is x.5 or more

  if( tmp < 0)
  {
     printf("FORMAT IS GREATER THAN 5.4 \n" );
     printf("DATA MAY BE LOST \n");
  }

 // MULT = 10 ** tmp 
   mult = pow(10.0,tmp);

   outfile =  fopen( outfilestr,"w");
   if (outfile==NULL)
   {
	   printf("In gbrfmtchg_274x_call, unable to open the output file = %s \n", outfilestr);
	   exit(-1);
   }

   infile =  fopen( infilestr,"r");
   if (infile != NULL)
   {
       //fgets(line, 200, infile) ; 
       while( fgets(line, 200, infile) != NULL)
	   {
          ProcessStringFmt274x(mult, line, outfile);
       } 
   }
   else
   {
	   printf("In gbrfmtchg_274x_call , unable to open the input file = %s \n",infilestr);
	   fclose(outfile);

	   exit(-1);
   }
   
   fclose(infile);
   fclose(outfile);

   return(0);
}


int gbrintomm_274x_call(char *infilestr, char *outfilestr)
{
  
FILE *infile;
FILE *outfile;

char line[400];
double mult;

      

  //  output a warning if precision is x.5 or more

  
   mult = 25.4;
   outfile =  fopen( outfilestr,"w");
   if (outfile==NULL)
   {
	   printf("In gbrintomm_274x_call, unable to open the output file = %s \n", outfilestr);
	   exit(-1);
   }

   infile =  fopen( infilestr,"r");

   if (infile != NULL)
   {
       //fgets(line, 200, infile) ; 
       while( fgets(line, 200, infile) != NULL)
	   {
          ProcessStringTomm274x( mult, line, outfile);
       } 
   }
   else
   {
	   printf("In gbrintomm_274x_call , unable to open the input file = %s \n",infilestr);
	   fclose(outfile);
	   exit(-1);
   }
   
   fclose(infile);
   fclose(outfile);

   return(0);
}


int incrtoabs_274x_call(char *infilestr, char *outfilestr)
{
  
FILE *infile;
FILE *outfile;

char line[400];


  //  output a warning if precision is x.5 or more

   xoffset = 0.0;
   yoffset = 0.0;

  
   outfile =  fopen( outfilestr,"w");
   if (outfile==NULL)
   {
	   printf("In inctoabs_274x_call, unable to open the output file = %s \n", outfilestr);
	   exit(-1);
   }

   infile =  fopen( infilestr,"r");

   if (infile != NULL)
   {
       //fgets(line, 200, infile) ; 
       while( fgets(line, 200, infile) != NULL)
	   {
          ProcessStringInc274x(  line, outfile);
       } 
   }
   else
   {
	   printf("In inctoabs_274x_call , unable to open the input file = %s \n",infilestr);
	   fclose(outfile);
	   exit(-1);
   }
   
   fclose(infile);
   fclose(outfile);

   return(0);
}

//
// 274d version, does not handle I and J
//  
int gbrfmtchg_call(int mult1, char *infile, char *outfile )
{
FILE *file1;
FILE *file2;

char thisline[200];
int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];

double xval;
double yval;

char X[120];
char Y[120];
int val;
int tmp;
double mult;

    file1  = fopen(infile, "r");

    if (file1 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",infile);
	  exit(-1);
	}

   file2  = fopen(outfile, "w");

    if (file2 == NULL)
	{
	  printf("Error: Unable to open input file = %s \n",outfile);
	  exit(-1);
	}

// mult1 is command line varible that is current format

  // mult1 = atoi(argv[1]);

  tmp = 4 - mult1;          

  //  output a warning if precision is x.5 or more

  if( tmp < 0){
     printf("FORMAT IS GREATER THAN 5.4 \n" );
     printf("DATA MAY BE LOST \n");
  }

 // MULT = 10 ** tmp 
  mult = pow(10.0,tmp);


 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL) )     // G54 preceeds aperture
   {
	  if (thisline[0] != '%')
	  {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       
       
       xval=atof(X);
       yval=atof(Y);
       xval=xval*mult;
       yval=yval*mult;
       fprintf(file2,"X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
	  }
	  else   // leave % unmolested
	  {
          fprintf(file2,"%s",thisline);
	  }
  }
  // if line has only X data modify it
  else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {

       if (thisline[0] != '%')
	   {
         split(thisline,b[0],b[1],"X");
         split(thisline,d[0],d[1],"D");
         awk_substr(b[1],1,strlen(b[1]) - 4,X);
         xval=atof(X);
     
         xval= mult * xval;
         fprintf(file2,"X%0.0fD%s\n", xval,d[1]);
	   }
	   else
	   {
        fprintf(file2,"%s",thisline);
	   }
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
	  if (thisline[0] != '%')
	  {
        split(thisline,c[0],c[1],"Y");
        split(thisline,d[0],d[1],"D");
        awk_substr(c[1],1,strlen(c[1]) - 4,Y);
   
        yval=atof(Y);
        yval=yval * mult;
        fprintf(file2,"Y%0.0fD%s\n",yval,d[1]);
	  }
	  else
	  {
		  fprintf(file2,"%s",thisline);
	  }

  }
  // line has no X or Y data so just output it
  else
  {
    fprintf(file2,"%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }

 fclose(file1);
 fclose(file2);

 return(0);

}  // end gbrfmtchg_call

int gbrintomm_call(char *infile, char *outfile)
{

FILE *file1;
FILE *file2;

char thisline[200];

int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];

double xval;
double yval;

char X[120];
char Y[120];
int val;

  file1  = fopen(infile, "r");

  if (file1 == NULL)
  {
	  printf("Error: Unable to open input file = %s \n",infile);
	  return(-1);
  }

  file2  = fopen(outfile, "w");

  if (file2 == NULL)
  {
	  printf("Error: Unable to open output file = %s \n",outfile);
	  return(-1);
  }

 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL))
   {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       //	 X = X * 25.4;
       // Y = Y * 25.4;
       xval=atof(X);
	  // printf("Y = %s  strlen a1 = %d a1 = %s \n",Y,strlen(a[1]),a[1]);

       yval=atof(Y);
       xval=xval*25.4;
       yval=yval*25.4;
	   if (strstr(thisline,"D")!=NULL)
	   {
         fprintf(file2,"X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
	   }
	   else  // missing D
	   {
        fprintf(file2,"X%0.0fY%0.0f\n", xval,yval);
	   }
  }
  // if line has only X data modify it
  else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {
      split(thisline,b[0],b[1],"X");
      split(thisline,d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
      xval=atof(X);
      // X = X * 25.4;
      xval=25.4 * xval;

	  if (strstr(thisline,"D")!= NULL)
	  {
        fprintf(file2,"X%0.0fD%s\n", xval,d[1]);
	  }
	  else
	  {
       fprintf(file2,"X%0.0f\n", xval);
	  }
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
      split(thisline,c[0],c[1],"Y");
      split(thisline,d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
      // Y = Y * 25.4
      yval=atof(Y);
      yval=yval * 25.4;
	  if (strstr(thisline,"D")!= NULL)
	  {
        fprintf(file2,"Y%0.0fD%s\n",yval,d[1]);
	  }
	  else
	  {
        fprintf(file2,"Y%0.0\n",yval);
	  }
  }
  // line has no X or Y data so just output it
  else
  {
    fprintf(file2,"%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }

 fclose(file1);
 fclose(file2);

 return(0);

}  // end grbintomm_call


int inctoabs_call( char *infilestr, char *outfilestr)
{
FILE *file1;
FILE *file2;

int endoffile;

char a[120][120];
char b[120][120];
char c[120][120];
char d[120][120];

double xval;
double yval;

char X[120];
char Y[120];
int val;
double xoffset;
double yoffset;
char thisline[200];

  xoffset = 0.0;
  yoffset = 0.0;

  file1  = fopen(infilestr, "r");

  if (file1 == NULL)
    {
	  printf("Error: Unable to open input file = %s \n",infilestr);
	  exit(-1);
    }

  file2 = fopen(outfilestr, "w");

  if (file2 == NULL)
    {
	  printf("Error: Unable to open output file = %s \n",outfilestr);
	  exit(-1);
    }
//**************START OF MAIN *********************************
// handles data depending on if the line has  X & Y data,
// X data only, Y data only , or no X,Y data.
//********************************************************************

 endoffile = getline(file1,thisline);

 while(endoffile == FALSE)
 {
  // if line has X & Y data modify both
  if ((strstr(thisline,"X") !=NULL) && (strstr(thisline,"Y")!=NULL)
      && (strstr(thisline,"G54") == NULL))     // G54 preceeds aperture
   {
       split(thisline,a[0],a[1],"Y"); 
       split(thisline,d[0],d[1],"D");
       val =  awk_index(a[0],"X");
       awk_substr( a[0],val +1,strlen(a[0]),X );
       awk_substr( a[1],1,strlen(a[1]) -4,Y); 
       xval=atof(X);
       yval=atof(Y);
       xval = xval + xoffset;
       yval = yval + yoffset;
       xoffset = xval;   // set x and y offset to current position
       yoffset = yval;
       fprintf(file2,"X%0.0fY%0.0fD%s\n", xval,yval,d[1]);
  }
  // if line has only X data modify it
   else if(( strstr(thisline,"Y") == NULL) && (strstr(thisline,"X") != NULL))
     {
      split(thisline,b[0],b[1],"X");
      split(thisline,d[0],d[1],"D");
      awk_substr(b[1],1,strlen(b[1]) - 4,X);
      xval=atof(X);
      xval = xval + xoffset;
      xoffset = xval;    // adjust xoffset
      fprintf(file2,"X%0.0fD%s\n", xval,d[1]);
  }
  //if line has only Y data modify it
  else if(( strstr(thisline,"X") == NULL) && (strstr(thisline,"Y") != NULL))
    {
      split(thisline,c[0],c[1],"Y");
      split(thisline,d[0],d[1],"D");
      awk_substr(c[1],1,strlen(c[1]) - 4,Y);
   
      yval=atof(Y);
      yval = yval + yoffset;
      yoffset = yval;   //adjust yoffset
      fprintf(file2,"Y%0.0fD%s\n", yval,d[1]);
  }
  //   line has no X or Y data so just output it
 else
  {
    fprintf(file2,"%s",thisline);
  }

  endoffile = getline(file1,thisline);
 }
 fclose(file1);
 fclose(file2);
 return(0);

} // end 

// Revision History
//    Rev 1  released on 1/2/97

int xconvert274x_call( char *codestr, char *dirstr)
{
int code;

char fromfilestr[200];
char tofilestr[200];
char currentdirstr[200];
int scan_file_count;
int i;

 strncpy(currentdirstr,"",4);

 
   code = atoi(codestr);

   //  if CODE is >= 100 then convert gerber files
   //  from inches to millimeters

  if ( code  >= 100 )
   {
     mvall(dirstr,".tmp");  // copy all that end with string1, to files ending in str2

	 scan_file_count=scandir_matchext(currentdirstr,0,".tmp");
	 i=0;

	 while( i < scan_file_count)
	 {
		strncpy(fromfilestr,scan_array[i],120);
		subexten(fromfilestr,tofilestr,dirstr);     // replace .tmp with argv[2]

     
	    printf("RUNNNING gbrintomm_274x %s %s \n",fromfilestr,tofilestr); //
                                                   //   > ${i%.*}$2" 
	    gbrintomm_274x_call( fromfilestr,tofilestr);       // GbrINtoMM $i > ${i%.*}$2
	    i += 1;
	 }
     code=code-100;     // decrement CODE by 100
   } 

   // if code is >= 10 then convert gerber files from
   // incremental to absolute coordinates

  if ( code >= 10  )
   {
     mvall(dirstr,".tmp");
     scan_file_count= scandir_matchext(currentdirstr,0,".tmp");
	 i=0;

	 while( i < scan_file_count)
	 {
		strncpy(fromfilestr,scan_array[i],120);
		subexten(fromfilestr,tofilestr,dirstr);     // replace .tmp with argv[2]
        printf("RUNNING inctoabs %s %s \n",fromfilestr,tofilestr); //
                                                  //  $i > ${i%.*}$2"
        inctoabs_call( fromfilestr,tofilestr); // InctoAbs $i > ${i%.*}$2
		i+=1;
     }
   code=code-10;  //  decrement CODE by 10
   }

   // if code is != 4 then change precision of gerber files to be 4
   if ( code != 4 )
   {
     mvall(dirstr,".tmp");
     scan_file_count = scandir_matchext(currentdirstr,0,".tmp");
	 i=0;
	 while( i < scan_file_count)
	 {
		strncpy(fromfilestr,scan_array[i],120);
		subexten(fromfilestr,tofilestr,dirstr);     // replace .tmp with argv[2]
   
	    printf("RUNNING gbrfmtchg_274x %d %s %s \n",code,fromfilestr,
	       tofilestr);   //  $i > ${i%.*}$2"
         gbrfmtchg_274x_call(code,fromfilestr,tofilestr); // -v mult1=$CODE $i > ${i%.*}$2
		 i+= 1;
	 }
   }
  return(0);

 }  // end xconvert_call



int main( int argc, char **argv)
{
int tint;

 if(argc != 3)
 {
   printf("incorrect number of arguments");
   printf("usage: xconvert code .from \n");
   printf("if code=100, convert from inches to mm \n");
   printf("if code=10, convert from incremental to absolute \n");
   printf("if code<10, convert from 4.x to 4.4 format \n");
   printf("where from = extention of gerber files \n");
   printf(" example: xconvert274x 100 .gbr \n");
   exit(-1);
 }
 else
 {
    tint=xconvert274x_call( argv[1], argv[2]);
 } 

}  




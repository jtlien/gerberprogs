#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

void xconvert_call( int AptCode, char *infile );
int getcoords3_call_out( char *mult ,char *kerf, char *partfile , char *coorsfile );
void formatsize_call_out( char *infile  , double xsize, double ysize);
int aptintomm2_call_out(char  *fromfilestr , char *tofilestr);
int splitcontrol_call( char *infilestr);
void getoffset_call_out( char *infilestr, char *outfilestr);
int valid_control4_call( char *partnumstr,char *pcmstr, char *layerfilestr);


// MASTER="/usr/local/bin/PANEL"
// USELOG="/usr/local/bin/scripts/usage/Xcntlog"

// Revision history

char GERBER[300];
char BRDREV[300];
char KERF[300];
char PARTS[300];
char PCMS[300];
char TEST[300];
char PCMTYPE[300];
char THIEVING[300];
char PUNCH[300];
char RELIABILITY[300];

// same as what is in MASTER/VALUES/deflocals
//
void set_switch_defaults( )
{
 strncpy(GERBER,"STD",10);
 strncpy(BRDREV,"A",4);
 strncpy(KERF,"2",4);
 strncpy(PARTS,"AUTO",10);
 strncpy(PCMS,"AUTO",10);
 strncpy(PCMTYPE,"7layer",20);
 strncpy(THIEVING,"AUTO",20);
 strncpy(RELIABILITY,"-30",10);

 strncpy(PUNCH,"",4);
 strncpy(TEST,"",4);


} // end set_switch_defaults

//*******************************************
// function - getswitches
// input params - $1 = input switch filename
// returns nothing
// reads specfic varibles from $1
//********************************************
void  getswitches ( char *infilestr)
{
FILE *infile;
char varup[120];
char varstr[200];
int varfound;
char thisline[200];
int nf;
int endoffile;
int debug;

 debug=0;

 infile=fopen(infilestr,"r");
 if ( infile == NULL)
 {
	 printf("ERROR: getswitches unable to open the input file = %s \n", infilestr);
	 exit(-1);
 }


 strncpy(GERBER,"",4);
 strncpy(BRDREV,"",4);
 strncpy(KERF,"",4);
 strncpy(PARTS,"",4);
 strncpy(PCMS,"",4);
 strncpy(TEST,"",4);
 strncpy(PCMTYPE,"",4);
 strncpy(THIEVING,"",4);
 strncpy(RELIABILITY,"",4);
    
 endoffile=getline(infile,thisline);
 nf=split_line( thisline);   
 
 while ( endoffile == FALSE)  // read var value
 {
	 varfound = FALSE;
	 strncpy(varstr,str_array[0],120);
	 cv_toupper(varstr,varup);

	 if (strcmp(varup,"GERBER")== 0 )
	 {
		 strncpy(GERBER,str_array[1],120);
		 varfound=TRUE;
	 }
	 if (strcmp(varup,"BRDREV")== 0 )
	 {
		 strncpy(BRDREV,str_array[1],120);
		 varfound=TRUE;
	 }
     if (strcmp(varup,"KERF")== 0 )
	 {
		 strncpy(KERF,str_array[1],120);
		 varfound=TRUE;
	 }
	 if (strcmp(varup,"PARTS")== 0 )
	 {
		 strncpy(PARTS,str_array[1],120);
		 varfound=TRUE;
	 }
	 if (strcmp(varup,"PCMS")== 0 )
	 {
		 strncpy(PCMS,str_array[1],120);
         varfound=TRUE;
	 } 
	 if (strcmp(varup,"TEST")== 0 )
	 {
		 strncpy(TEST,str_array[1],120);
         varfound=TRUE;
	 } 
	 if (strcmp(varup,"PCMTYPE")== 0 )
	 {
		 strncpy(PCMTYPE,str_array[1],120);
         varfound=TRUE;
	 }
	 if (strcmp(varup,"THIEVING")== 0 )
	 {
		 strncpy(THIEVING,str_array[1],120);
         varfound=TRUE;
	 }
	 if (strcmp(varup,"RELIABILITY")== 0 )
	 {
		 strncpy(RELIABILITY,str_array[1],120);
         varfound=TRUE;
	 }
     if (varfound == FALSE)
	 {
		 printf("Variable %s IGNORED \n",varup);
	 }
 endoffile=getline(infile,thisline);
 nf=split_line( thisline);
 } // < $1
 fclose(infile);

 if (debug)
 {
	 printf("GERBER=%s\n",GERBER);
	 printf("BRDREV=%s\n",BRDREV); 
	 printf("KERF=%s\n",KERF);
	 printf("PARTS=%s\n",PARTS);
	 printf("PCMS=%s\n",PCMS); 
	 printf("TEST=%s\n",TEST);
     printf("PCMTYPE=%s\n",PCMTYPE);
     printf("THIEVING=%s\n",THIEVING);
	 printf("RELIABILITY=%s\n",RELIABILITY);
 }

}  // end getswitches


void xcount_call(  char *partnumstr)
{

int vresult;
int split;
char pwdstr[300];
char mypath[300];
int AptCode;
int coordtmp;
char fromfilestr[300];
char tofilestr[300];
char partsup[300];
char chkfilestr[300];
char chkfile1str[300];
int kerfval;
char commandstr[300];
int kk;
int endoffile;
char thisline[300];
FILE *numpartsfile;
FILE *cnttxtfile;
int xnum;
int ynum;
double xsize;
double ysize;
int mycnt;
char *masterstr;
char deflocalsfile[300];

// ***************** START OF MAIN **********************************************


  // get default switch values

  masterstr=getenv( "MASTERDIR");

  if (masterstr != NULL)
  {
   strncpy(deflocalsfile,masterstr,120);
   strncat(deflocalsfile,dirsep,10);
   strncat(deflocalsfile,"VALUES",20);
   strncat(deflocalsfile,dirsep,10);
   strncat(deflocalsfile,"defocals",20);

  
   if ( file_exists( deflocalsfile ) )
   {
    getswitches( deflocalsfile );
   }
   else
   {
	   printf("deflocals file not found, setting defaults internally\n");
	  set_switch_defaults();
   }
  }
  else   // No MASTERDIR defined
  {
	  set_switch_defaults();
  }

  // check to see if calling from correct spot
  if(  dir_exists( "aper") && dir_exists( "control") && 
	   dir_exists( "artwork" ))  // if these are present proceed
  {
	 getwd(pwdstr);

     strncpy(mypath,pwdstr,120); // PWD  we move around a little so,lets
	                             // keep the current directory

	 strncpy(commandstr,"chmod -R 777 ",30);
	 strncat(commandstr,mypath,120);
	 strncat(commandstr,dirsep,10);
	 strncat(commandstr,"control",30);

     //chmod -R 777 $mypath/control

	 system(commandstr);

     //   check to see if control file exists

     strncpy(chkfilestr,"control",30);   // control/$1.ctl
	 strncat(chkfilestr,dirsep,10);
	 strncat(chkfilestr,partnumstr,80);
	 strncat(chkfilestr,".ctl",10);

	 strncpy(chkfile1str,"aper",30);    // aper/$1.prt
	 strncat(chkfile1str,dirsep,10);
	 strncat(chkfile1str,partnumstr,80);
	 strncat(chkfile1str,".prt",10);

     if ( (! (file_exists(chkfilestr) ) ) || ( ! (file_exists( chkfile1str) ) ) )
     {
	    printf( "ERROR: One of these files is missing\n");
	    printf( "\tcontrol/%s.ctl \taper/%s.prt\n",partnumstr, partnumstr);
        printf("PROGRAM HALTED\n");
         exit(-1);   //  missing *.ctl or *.prt file so exit 
     }	  

     if( file_exists("cnt.txt" ) )
	 {
	  rm_file( "cnt.txt");
     }

     mkdir("tmpcnt");
     change_dir( "tmpcnt");

//    split control file into two files called layers & locals

	 strncpy(fromfilestr,mypath,120);  // $mypath/control/$1.ctl
	 strncat(fromfilestr,dirsep,10);
	 strncat(fromfilestr,"control",30);
	 strncat(fromfilestr,dirsep,10);
	 strncat(fromfilestr,partnumstr,80);
	 strncat(fromfilestr,".ctl",10);

	 strncpy(tofilestr,partnumstr,80);
	 strncat(tofilestr,".ctl1",10);

     cp_file(fromfilestr,tofilestr);  // dos2ux $mypath/control/$1.ctl > $1.ctl1
     split=splitcontrol_call( tofilestr); //  $1.ctl1

    // split=$? 

//   if splitcontrol is not succesful (split != 0) then exit
     if ( split != 0 )
     {
        printf( "split = %d \n", split);
        printf("ERROR: %s.ctl contains line with incorrect field count \n",partnumstr);
        printf("ONLY FIELD WIDTHS of 2 & 8 supported\n");
        printf("PROGRAM HALTED \n");
        exit(-1);  // splitcontrol failed so exit
     }


     // Process "locals" file
     //  get user switches form local files       
     getswitches("locals");

     printf("GERBER=%s\n", GERBER);  
     printf("BRDREV=%s\n", BRDREV); 
     printf("KERF=%s\n", KERF); 
     printf("PARTS=%s\n", PARTS); 
     printf("PCMS=%s\n", PCMS);  
     printf("TEST=%s\n", TEST);  
     printf("PCMTYPE=%s\n", PCMTYPE);  
     printf("THIEVING=%s\n", THIEVING);  
     printf("PUNCH=%s\n", PUNCH);  

	 kerfval=atoi(KERF);

     if( kerfval < 0 )
     {
       printf( "\nKERF = %d \n", kerfval);
       printf( "ERROR:  KERF less than 0 \n");
       printf(" PROGRAM HALTED\n ");
       exit(-1); 
     }


	 printf("Calling valid_control name=%s num=%s layers \n",partnumstr,PCMTYPE);
     vresult=valid_control4_call( partnumstr,PCMTYPE,"layers");
	                              // -v name=$1 -v num=$PCMTYPE  layers
    // vresult=$?
     if( vresult != 0 )
     {
       printf("vresult = %d",vresult);
       printf(" PROGRAM HALTED\n");
       exit(-1);          // control file has errors so exit
	 }
     else
	 {
       printf( "%s.ctl is valid\n",partnumstr);
     }


      // check to see if outline file exist

	 strncpy(chkfilestr,mypath,120);  // $mypath/artwork/outline.art
	 strncat(chkfilestr,dirsep,10);
	 strncat(chkfilestr,"artwork",30);
	 strncat(chkfilestr,dirsep,10);
	 strncat(chkfilestr,"outline.art",40);

     if( ! ( file_exists( chkfilestr) ) ) // -f $mypath/artwork/outline.art )
     {
       printf("%s/artwork/outline.art does not exist\n",mypath);
       printf( "ERROR: PROGRAM HALTED\n");
       exit(-1);  
	 }
     else
	 {
	   strncpy(fromfilestr,mypath,120);  // $mypath/artowrk/outline.art
	   strncat(fromfilestr,dirsep,10);
	   strncat(fromfilestr,"artwork",30);
	   strncat(fromfilestr,dirsep,10);
	   strncat(fromfilestr,"outline.art",30);

	   cp_file(fromfilestr,"outline.art");
       //cp $mypath/artwork/outline.art .
     }

//*********************************************************************
// Check for "manual" user files before going on
//********************************************************************
	 cv_toupper(PARTS,partsup);

	 strncpy(chkfilestr,mypath,120);  // $mypath/control/partcoords.man
	 strncat(chkfilestr,dirsep,10);
	 strncat(chkfilestr,"control",30);
	 strncat(chkfilestr,dirsep,10);
	 strncat(chkfilestr,"partcoords.man",30);

     if( (strcmp(partsup,"MAN")== 0)  &&
		 (! ( file_exists( chkfilestr)  ) ) )
	 {
	    printf( "File not found -- %s/control/partcoords.man\n",mypath);
	    printf("ERROR: PROGRAM HALTED\n");
        exit(-1);
     }

	 strncpy(fromfilestr,mypath,120); // $mypath/aper/$1.part
	 strncat(fromfilestr,dirsep,10);
	 strncat(fromfilestr,"aper",10);
	 strncat(fromfilestr,dirsep,4);
	 strncat(fromfilestr,partnumstr,120);
	 strncat(fromfilestr,".prt",10);

	 strncpy(tofilestr,partnumstr,120);  // $1.prt
	 strncat(tofilestr,".prt",10);

	 cp_file(fromfilestr,tofilestr);   // was dos2ux

     //dos2ux $mypath/aper/$1.prt >$1.prt

	 strncpy(fromfilestr,partnumstr,120); // $1.prt
	 strncat(fromfilestr,".prt",10);
      
	 strncpy(tofilestr,partnumstr,120); // $1.tmp
	 strncat(tofilestr,".tmp",10);

     AptCode=aptintomm2_call_out( fromfilestr , tofilestr);
   //  AptCode=$?
     printf("AptCode %d \n",AptCode);

     if( AptCode == 255 )
     {
       printf("ERROR: Incorrect Format in Aperture file (# fields?)\n");
       printf( "PROGRAM HALTED\n");
       exit(-1);
     }

     xconvert_call( AptCode, "outline.art");

     getoffset_call_out( "outline.art", "offval");

	 xsize=0;
	 ysize=0;

     formatsize_call_out( "partsize" , xsize, ysize);
    // read xsize ysize < tmpsize
	 cnttxtfile=fopen("cnt.txt","w");
	 if (cnttxtfile==NULL)
	 {
		 printf("Unable to open the cnt.txt file for write \n");
		 exit(-1);
	 }

     fprintf(cnttxtfile, "Xsize = %f  Ysize = %f \n",xsize,ysize); // > cnt.txt

//  *************************************************

     cv_toupper(PARTS,partsup);

     if( strcmp(partsup,"MAN") == 0 ) //$PARTS = [Mm][Aa][Nn] )   
		                       // place PARTS at user coordinates
     {
		strncpy(fromfilestr,mypath,120); // $mypath/control/partcoords.tmp
		strncat(fromfilestr,dirsep,10);
		strncat(fromfilestr,"control",30);
		strncat(fromfilestr,dirsep,10);
		strncat(fromfilestr,"partcoords.tmp",40);

       cp_file( fromfilestr, "partcoords.tmp");  // was dos2ux

      // mycnt=$(wc -l partcoords.tmp)   // get number of lines in partcoords.tmp
       //mycnt=${mycnt%%p*}

	   mycnt=count_lines( "partcoords.tmp");

       fprintf(cnttxtfile, "Number = %d\n",mycnt); // >> cnt.txt

	   strncpy(tofilestr,mypath,120);  // $mypath/cnt.txt
	   strncat(tofilestr,dirsep,10);
	   strncat(tofilestr,"cnt.txt",20);

       cp_file( "cnt.txt", tofilestr); //  mv cnt.txt $mypath/cnt.txt
	   rm_file("cnt.txt");
	 }
     else if ( strcmp(partsup,"NONE")==0 ) // no parts placed   
	   {
       printf("NO PARTS PLACED\n");
	 }
     else 
	 {                                     // assume AUTO placement of PARTS 
       printf("RUNNING getcoords3 mult=4 KERF=%s partsize> partcoords\n",KERF);
       coordtmp=getcoords3_call_out( "4" , KERF, "partsize", "partcoords" );
      // coordtmp=$?
       if( coordtmp == 255 )
       {
         printf("ERROR: Can Not Get Count\n");
         printf( "PROGRAM HALTED\n");
	      exit(-1);
       }
       //exec 8< numparts
	   numpartsfile=fopen("numparts","r");
	   if ( numpartsfile==NULL)
	   {
		   printf("Unable to open the numparts file \n");
		   exit(-1);
	   }
	   endoffile=getline(numpartsfile,thisline);
	   kk=0;
	   while(kk < (signed int) strlen(thisline))
	   {
		   if ( thisline[kk] == '\n')
		   {
			   thisline[kk] = '\0';
		   }
		 kk += 1;
	   }

	   xnum=atoi(thisline);
       endoffile=getline(numpartsfile,thisline);
	   kk=0;
	   while(kk < (signed int) strlen(thisline))
	   {
		   if ( thisline[kk] == '\n')
		   {
			   thisline[kk] = '\0';
		   }
		 kk += 1;
	   }

		 ynum=atoi(thisline);

      // read -u8 xnum
      // read -u8 ynum  
       printf( "%d   %d \n",xnum,ynum);
       mycnt = xnum * ynum;
       fprintf(cnttxtfile, "Number = %d\n",mycnt); // >> cnt.txt
	   fclose(cnttxtfile);

	   strncpy(tofilestr,mypath,120); // $mypath/cnt.txt
	   strncat(tofilestr,dirsep,10);
	   strncat(tofilestr,"cnt.txt",20);

	   cp_file("cnt.txt", tofilestr);
	   rm_file("cnt.txt");
       //mv cnt.txt $mypath/cnt.txt
     } 
     change_dir(mypath);

     // rm -r tmpcnt
   }
   else  // exit if no aper or artwork directories found
   {
     printf( "aper,artwork or control directories not found\n");
   }


} // end xcount_call

int main(int argc, char **argv)
{
char USAGE[300];
char EXAMPLE[300];
char username[300];
char PROGNAME[300];
char userdate[300];
char REV[300];

FILE *logfile;

strncpy(PROGNAME,"xcount",30); 

strncpy(USAGE,"usage:",30);
strncat(USAGE,PROGNAME,40);
strncat(USAGE," boardname",30);

strncpy(EXAMPLE,"\tex:  ",30);
strncat(EXAMPLE,PROGNAME,40);
strncat(EXAMPLE," 96009",20);

strncpy(REV,"1.0",20);

if( argc != 2 )   // check to see if correct number of params
{
  printf("incorrect number of arguments\n");
  printf( "%s\n%s\n",USAGE,EXAMPLE);
}
else
{
  printf("RUNNING Xcount%s\n",REV);
  // log usage 
  get_whoami(username);       // =$(whoami)
  //userdate=$(date)
  get_date(userdate);

  logfile=fopen("Logfile","w");

  fprintf(logfile, "%s     %s     %s     %s      %s \n",
              PROGNAME,REV,argv[1], username, userdate);  // >> $USELOG
  fclose(logfile);

  xcount_call( argv[1]);
  
}

} // end main

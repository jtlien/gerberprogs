
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <math.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define MAXSTRING 120

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0


char scan_array[1000][120];
int endoffile;
char namestr[200];
int filescan_count;
char dirstr[100];

char usage_str[200];
char where_str[200];
char example_str[200];
char outfilestr[200];
char infilestr[200];
int i;



// Rev 1
// Title: xgbrall
// written by Ted Ammann 7/25/96

// calling Syntax
//     xgbrall .ext crossref  (i.e. xgbrall .art combineaptref)

// Program updates Dcodes in all gerber files i current directory
// with the .ext (command line param). It does the by calling updategbr
// for each file. Input files are over written (.gbk backups are created).
//
// Note: Program uses calls script updategbr
//       Please see those scripts for possible other side effects
//       or requirements.

// Revision History
//    Rev 1  released on 7/25/96

// Some helper information that is output if program is called incorrectly
//
// progname=${0##*/}
// USAGE="usage: $progname .from crossref"
// WHERE="\t.from extention of gerber files"
// EXAMPLE="\tex:  $progname .gbr mergeaptref"


char str_array[120][120];
char thisline[200];
int nf;
int endoffile;
char newcode[40];
char foo[12][200];
char locate[200];
char tempstr[200];

FILE *file1;
FILE *outfile1;


struct codestuff
{
 char oldcode[40];
 char newcode[40];
} newcodes[1000];

int newcode_count;

// perform awk compatible substr, except the 4th parameter is the
//   result string
//
void awk_substr( char *instr, int sbegin, int slength, char *resultstr)
{

char tstr[120];
int kk;
int ll;

     if ( sbegin > 0)
	 {
		 sbegin = sbegin-1;
	 }
     kk = sbegin;
     ll = 0;
	 while ( ( kk < strlen(instr) && ( ll < slength)) )
	 {
		 tstr[ll] = instr[kk];
		 kk += 1;
		 ll  += 1;
	 }
	 tstr[ll]=0;

	 strncpy( resultstr,tstr,slength+2);

}   // awk substr

int split_line( char *tline)
{
int ii;
char tstr[200];
char *token;
int kk;

 ii = 0;

 strncpy( tstr, tline,200);

 kk = strlen(tstr);
 if (kk > 0 )
	{
	 if (tstr[kk-1] == 10)
	 {
		tstr[kk-1] = 0;
	 }
	}

 token = strtok( tstr," ");

 while((ii < 20) && (token != NULL))
	{
      strncpy( str_array[ii], token, 120);

      ii += 1;
	  token = strtok( NULL, " ");

	}

 return(ii);

} // end split_line


//
// get an input line
//
int getline( FILE *infile, char *tline)  // get a line of input
{
char *err;

 err = fgets(tline,120,infile);

 if (err != NULL)
 {
   return(0);
 }
 else
 {
	return (1);
 }
} // end getline

//
//  Look to see if the oldcode is already there, if not add, if so update
//
void add_to_codes( char *oldcode, char *newcode)
{
int ii;
int code_found;

 code_found = FALSE;

 ii = 0;
 while( ( ii < newcode_count) && (code_found == FALSE) && ( ii < 1000))
	{
	 if (strcmp( newcodes[ii].oldcode,oldcode) == 0 )
	 {
		 strncpy(newcodes[ii].newcode,newcode,40);
		 code_found=TRUE;
	 }

   ii += 1;
 }

 if (code_found == FALSE)
	{
	 strncpy(newcodes[newcode_count].newcode,newcode,40);
	 strncpy(newcodes[newcode_count].oldcode,oldcode,40);
	 if (newcode_count < 1000 )
	 {
		 newcode_count += 1;
	 }
	}

} // end add_to_codes


//
//  Look up the oldcode in the newcode table, return newcode
//
void get_from_codes( char *oldcode, char *newcode)
{
int ii;
int code_found;

 code_found = FALSE;

 ii = 0;
 while( ( ii < newcode_count) && (code_found == FALSE) && ( ii < 1000))
	{
	 if (strcmp( newcodes[ii].oldcode,oldcode) == 0 )
	 {
		 strncpy(newcode,newcodes[ii].newcode,40);
		 code_found=TRUE;
	 }

   ii += 1;
 }

 if (code_found == FALSE)
	{
	 
	 printf("Error:  Code not found in table \n");
     strncpy(newcode,"",4);
	}

} // end get_from_codes

// split a string in two

void split( char *instr, char *outstr1, char *outstr2, char *srchstr)
{

int ii,kk;

  ii=0;
  kk = 0;

 while((instr[ii] != srchstr[0]) && ( ii < strlen(instr)) )
	{
	  outstr1[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr1[kk] = 0;

  ii += 1;
  outstr2[0] = 0;
  kk = 0;
  while ( (instr[ii] != 0 ) && (instr[ii] != '\n') && ( kk < 120))
	{

	  outstr2[kk] = instr[ii];
	  kk += 1;
	  ii += 1;
	}
  outstr2[kk]= 0;


}  // end split

// update a gerber file with new aperatures

int updategbr_call( char *infile1, char *infile2, char *outfile)
{
    // file1 is a crossref file 
    // First line is header so remove

	newcode_count = 0;

    file1  = fopen(infile1, "r");

      if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",infile1);
	   exit(-1);
	  }


    endoffile=getline(file1,thisline);

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

	while( endoffile == FALSE)
	{
    // read in new d-codes into array using old d-code as subscript
    // $1 is OLD dcode //2 is NEW dcode 
    //       D10             D255
    
	add_to_codes(str_array[0],str_array[1]); // newcodes[$1] = $2

    endoffile=getline(file1,thisline);
 	nf=split_line(thisline);
    }

	fclose(file1);


//****************** START of MAIN ******************************

    file1  = fopen(infile2, "r");

      if (file1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",infile2);
	   exit(-1);
	  }

      outfile1  = fopen(outfile, "w");

      if (outfile1 == NULL)
	  {
	   printf("Error: Unable to open input file = %s \n",outfile);
	   exit(-1);
	  }

	// read argv[2] file

    endoffile=getline(file1,thisline);
 	nf=split_line(thisline);

	while(endoffile == FALSE)
	{
      //replace OLD dcode with NEW dcode
      // G54 is gerber command for selecting new apt
      // splitting at "D" places OLD dcode in foo[2]
      //REV 2 adds check for first char of $1 being a 'D' or 'd'
      if( (strstr(thisline,"G54") != NULL) || (str_array[0][0] == 'D')|| (str_array[0][0]=='d'))
		
	  {
        split(thisline, foo[0],foo[1],"D");
	    awk_substr(foo[1],1, (strlen(foo[1]) -1 ),locate);   // get rid of '*'
        //REV 2 adds if below to insure only apertures get modified

	    if( atoi(locate) >= 10 )
		{                          // assumes apertures  start at 10
	      strncpy(tempstr,"D",5);
		  strcat(tempstr,locate);
		  strncpy(locate,tempstr,40);
		  get_from_codes( locate,newcode);
		// strcat(tempstr,= ("D" locate)    // d was renmoved by 'split' above 
            fprintf(outfile1,"G54%s*\n", newcode);
		}
   	   else 
	   {                     //prints out any line that has D-code D0 thru D09
	    fprintf(outfile1,"%s",thisline);
       }
	  }
     else
	 {                        //prints out lines that do not contain a D-code
	  fprintf(outfile1,"%s",thisline); 
     }

	endoffile=getline(file1,thisline);
	nf=split_line(thisline);
	}
	fclose(file1);
	fclose(outfile1);

	return(0);

} // updategbr_call

void move_one_file(  char *infile, char *outfile)
{
char buf[1024];
FILE *f_from;
FILE *f_to;


    /* copy source file to target file, line by line. */

/* open the source and the target files. */
    f_from = fopen(infile, "r");
    if (!f_from) {
	fprintf(stderr, "Cannot open source file: %s",infile);
	perror("");
	exit(1);
    }
    f_to = fopen(outfile, "w+");
    if (!f_to) {
	fprintf(stderr, "Cannot open target file: %s ",outfile);
	perror("");
	exit(1);
    }

/* copy source file to target file, line by line. */

    while (fgets(buf, 512, f_from)) 
	{
	 if (fputs(buf, f_to) == EOF)
	 {  /* error writing data */
	    fprintf(stderr, "Error writing to target file: ");
	    perror("");
	    exit(1);
	 }
    }
   fclose(f_from);
   fclose(f_to);
	
}  // move_one_file

//
//   Scan directory for regular files that match a particular extension
//
int scandir_matchext(const char* dir,	// starting directory (absolute or relative)
		int recurse,		// 1 to recurse in subdirectory
		 char *matchstr)		// starting dir, could be an arbitrary label
{

	char newdir[MAXSTRING];
	char fname[MAXSTRING];
	int ll;
	int kk;
	char fname_ext[MAXSTRING];
	int scan_file_count;

	
	// try to open directory

	HANDLE hList;
	TCHAR szDir[MAXSTRING];
	WIN32_FIND_DATA FileData;
	sprintf(szDir, "%s/*", dir);
	hList = FindFirstFile(szDir, &FileData);
	scan_file_count = 0;

	if (hList == INVALID_HANDLE_VALUE){ 
		/******************************************
		 * ADD ERROR HANDLING HERE
		 ******************************************/
		return(-1);
	}
	// start scanning directory

	do{
		strncpy(fname,FileData.cFileName,MAXSTRING);
		// we don't want to consider these directories
		if (!strcmp(fname,".")) continue;
		if (!strcmp(fname,"..")) continue;
		
		// for dirs

		if (FileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                  {
			/******************************************************
			 * here we have a subdirectory
			 * ADD DIR HANDLING HERE
			******************************************************/
			if (recurse){
    			// recurse scandir function in subdirectory
    			sprintf(newdir,"%s/%s",dir,fname);

    			scandir_matchext(newdir,recurse,matchstr);
           	         }
		}
		else{
			/******************************************************
			 * here we have a regular file
			 * "fname" contains file name 
			 * "dir" contains the complete path
			 * "subdir" contains path relative to starting directory
			 * ADD FILE HANDLING HERE
			 ******************************************************/

			 // get the ext ( all chars after first dot )

			kk=0;
			ll=0;
			fname_ext[0]=0;
			while((fname[kk] != '.') && (kk < strlen(fname)) )
			{
				kk += 1;
			}
			if ( fname[kk] == '.')
			{
				fname_ext[ll]=fname[kk];
				kk += 1;
				ll += 1;
			}
			while( kk < strlen(fname))
			{
				fname_ext[ll] = fname[kk];
				kk += 1;
				ll += 1;
			}
			fname_ext[ll] = 0;

			// printf("fname_ext = %s \n",fname_ext);

			if (strcmp(fname_ext,matchstr) == 0 )
			{
			// printf("fname = %s \n",fname);
			  if (scan_file_count < 1000 )
			  {
				 strncpy(scan_array[scan_file_count],fname,120);
				 scan_file_count += 1;
			  }
			  else
			  {
				  printf("Number of files in the directory exceeds 1000 \n");
			  }

			}

		}
	} while (FindNextFile(hList, &FileData));
	FindClose(hList);
	return(scan_file_count);
}


//
//  Take a file name string with one extension and 
//     replace it with another   extension at most 30 chars
//
void subexten( char* instr, char *outstr, char *newext)
{
char a[10][120];
char tempstr[200];

  split(instr,a[0],a[1],".");
  strncpy(tempstr,a[0],120);
  strncat(tempstr,newext,30);
  strncpy(newext,tempstr,120);

}  // end subexten

//
//  Move all files with a given extention to copies with another extention
//
void mvall( char *fromext, char *toext )
{
int ii;
char frmfilestr[120];
char toofilestr[120];
char dirstr[10];
int tscan_file_count;

  strncpy(dirstr,".",4);

  tscan_file_count = scandir_matchext( dirstr,0,fromext);

  ii =0;

  while(ii < tscan_file_count)
  {
	  strncpy(frmfilestr,scan_array[ii],120);
	  subexten(frmfilestr,toofilestr,toext);
	  
      move_one_file( frmfilestr, toofilestr);
      ii += 1;

  }

}  // mvall



void xgbrall_call( char *extstr, char *crossrefstr)
{

     strncpy(dirstr,"",4);

  
     mvall(extstr,".gbk");   //  copy all the files to .gbk files

     // tmp=$(ls *.gbk)  scan current directory for all files ending in .gbk

     filescan_count = scandir_matchext( dirstr,0,".gbk");

     //update all files

     while(( i < filescan_count) && ( i < 1000 ))
     {
        
		strncpy(infilestr,scan_array[i],120);
       //  name=${i%*.gbk}
        strncpy(namestr,infilestr,120);
		
        // printf( "RUNNING  updategbr -v file1=$2 $i > $name$1" 
		strncpy(outfilestr,namestr,100);
		strncat(outfilestr,extstr,20);

        updategbr_call(crossrefstr,infilestr,outfilestr); // $i > $name$1 
		i += 1;
	 }
 
}  // end xgbrall_call

int main(int argc, char **argv)
{


  strncpy(usage_str,"usage:  xgbrall .from crossref",60);
  strncpy(where_str,"    .from extention of gerber files",60);
  strncpy(example_str,"     ex:  xgbrall .gbr mergeaptref",60);

  if((argc != 3)) 
  {
   printf("incorrect number of arguments\n");
   printf("%s \n %s \n %s \n",usage_str,where_str,example_str);
   exit(-1);
  }
  else
  {
	  xgbrall_call(argv[1], argv[2]);
  }

}  // end main

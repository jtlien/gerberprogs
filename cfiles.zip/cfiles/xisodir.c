
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <process.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
 
#define WINDOWS 1

void mkdir( char *dirstr);

void xisodir_call( )
{

mkdir( "mfg");
mkdir( "mech");
mkdir( "models");
mkdir( "laser");
mkdir( "drill");
mkdir( "test");
mkdir( "symbols");
mkdir( "symbols/script");
mkdir( "netlist");
mkdir( "devices");
mkdir( "padstack");
mkdir( "script");
mkdir( "report");
mkdir( "review");
mkdir( "raw");
mkdir( "scm");
mkdir( "panel");
mkdir( "aper");
mkdir( "area");
mkdir( "area/mesh");
mkdir( "area/log");
mkdir( "area/array");
mkdir( "pcm");
mkdir( "274x");
mkdir( "artwork");
mkdir( "control");

if (WINDOWS)
{

  cp_file("m:/design/software/mmm/PANEL/SAMPLES/X.ctl", "control/pn.ctl");
  cp_file("m:/design/software/mmm/PANEL/SAMPLES/pcm.txt","control/pcm.txt");
}
else
{
cp_file( "/usr/local/bin/PANEL/SAMPLES/X.ctl", "control/pn.ctl");
cp_file( "/usr/local/bin/PANEL/SAMPLES/pcm.txt", "control/pcm.txt");
}

}  // end 

int main( int argc, char **argv)
{
   if (argc != 1)
   {
	   printf("xisodir does not take any arguments \n");
	   exit(-1);
   }
   else
   {
	   xisodir_call( );
   }

}  // end
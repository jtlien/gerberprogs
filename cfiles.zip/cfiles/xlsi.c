#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"
//
//  xlsi
//
//  require cadence tools report and 
//               techfile in current path
//  requires report/Linfo file 
//  requires createnew1.2 in current path
//  require rule_lsi in current path


void do_report( char *shortstr, char *pnstr)
{
char commandstr[300];

strncpy(commandstr,"report -v ",40);
strncat(commandstr,shortstr,30);
strncat(commandstr," ",4);
strncat(commandstr,pnstr,80);
strncat(commandstr," report",20);

if (WINDOWS)
{
	strncat(commandstr,"\\",4);
}
else
{
	strncat(commandstr,"/",3);
}

strncat(commandstr,pnstr,80);
strncat(commandstr,shortstr,30);
system(commandstr);

} // end do_report

void do_tech( char *shortstr, char *pnstr)
{
char commandstr[300];

strncpy(commandstr,"techfile -w ",40);
strncat(commandstr,pnstr,80);
strncat(commandstr," report",20);

if (WINDOWS)
{
	strncat(commandstr,"\\",4);
}
else
{
	strncat(commandstr,"/",3);
}

strncat(commandstr,pnstr,80);
strncat(commandstr,shortstr,20);
system(commandstr);

} // end do_tech



void xlsi_call(char *pnstr )
{
char commandstr[300];

if ( file_exists("report/Linfo")  )
{
 do_report("uaf",pnstr); 
 do_report("ucn",pnstr); 
 do_report("upc",pnstr);
 do_report("drc",pnstr);
 do_report("ecl",pnstr);
 do_report("cmp",pnstr);
 do_report("pcp",pnstr);
 do_report("spn",pnstr);
 do_report("pad",pnstr);
 do_tech(".tech",pnstr);

//report   -v drc $1 report/$1.drc
//report   -v ecl $1 report/$1.ecl
//report   -v cmp $1 report/$1.cmp
//report   -v pcp $1 report/$1.pcp
//report   -v spn $1 report/$1.spn
//report   -v pad $1 report/$1.pad
//techfile -w     $1 report/$1.tech
 strncpy( commandstr,"create_new1.2 ",120);
 strncat( commandstr,pnstr,120);

//create_new1.2 $1

 system(commandstr);
 strncpy( commandstr,"rule_lsi ",120);
 strncat( commandstr,pnstr,120);

 // rule_lsi $1

 rm_files_ext(".log"); //  *.log*

}
else
{
 printf("report/Linfo does not exist\n");
 printf("Must create before further processing\n");
}

}  // end xlsi


int main( int argc, char **argv)
{
	if (argc != 2)
	{

		printf("In xlsi, wrong number of arguments \n");
		printf("Usage: xlsi partstr \n");
		exit(-1);
	}
	else
	{
		xlsi_call(argv[1]);
	}

}  // end main



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <process.h>

#include "dirent.h"
#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

// create mechangical data ( must have c:\WCAD\Asm500 directory with binary
//                                   for gbr2gdxd.exe

// progname=${0##*/}
// USAGE="usage: $progname partnum "
// EXAMPLE="\tex:  $progname 96009" 
// REV="2.0"


// Program to convert input mech gerber files (.m) to
// route files (.dxf)
//
// Programmer Ted Ammann
// Utilizes gbr2acad from Artwork Conversion Software Inc.

// Revision history
// Rev 1.0  released to users on 8/14/97
// Rev 2.0  released to users on 9/08/98
//     changes to add handling of "CUTOUT" & "DRILL" layer types

int nf;
char thisline[200];
int kk;
char str_array[120][120];
int endoffile;
int retcode;

char revstr[120];
char example_str[200];
char usage_str[200];
char progname_str[200];
char controlfile_str[200];
char commandstr[1000];
char aptoutfilestr[200];
char fname[200];
char basestr[200];
char basestrup[200];
char extstr[200];
char pwd_str[200];

int flag;
int i;
int mfile_count;

char aptfilestr[300];
char doutfilestr[300];
char jobfilestr[300];
char apt1filestr[300];
char aperstr[300];
char execfilestr[300];

FILE *apt1file;
FILE *aptfile;
FILE *controlfile;
FILE *jfile;


void checklayer( char *fname)
{
char mfilestr[200];

       printf( "checking for %s.m ...\n",fname);

	   strncpy(mfilestr,fname,120);
	   strncat(mfilestr,".m",10);

       if (file_exists(mfilestr)) 
       {
            printf( "                        ... Found It\n");
	   }
       else
	   {
            flag=1;
            fprintf(stderr, "%s NOT FOUND\n",mfilestr);
            printf(  "%s NOT FOUND\n",mfilestr);
	   }

} // end checklayer



void xmech_call(char *infilestr)
{

  if (WINDOWS)
  {
	  strncpy(dirsep,"\\",4);
  }
  else
  {
	  strncpy(dirsep,"/",4);
  }

  
      // printf("RUNNING %s%s\n",progname_str,revstr);  // $progname$REV" 

	  strncpy(controlfile_str,"control",20);   // control/$1.ctl
	  strncat(controlfile_str,dirsep,4);
	  strncat(controlfile_str,infilestr,80);
	  strncat(controlfile_str,".ctl",5);

      if ( ! file_exists( controlfile_str ) )
	  {
	   fprintf(stderr,"FATAL ERROR\n");
	   fprintf(stderr,"%s is MISSING \n",controlfile_str);

         exit(-1);
      }

	  strncpy(aperstr,"aper",20);      // aper/$1.apt
	  strncat(aperstr,dirsep,10);
	  strncat(aperstr,infilestr,100);
	  strncat(aperstr,".apt",10);

      if ( ! file_exists( aperstr  ))
      {
	   fprintf(stderr,"FATAL ERROR\n");
	   fprintf(stderr,"%s is MISSING\n",aperstr);
         exit(-1);
      }

      if( ! dir_exists( "mech")) 
      {
	   fprintf(stderr,"FATAL ERROR \n");
	   fprintf(stderr,"mech directory not FOUND\n");
	   exit(-1);
      }


      //change_dir("mech");

      flag=0;
    //  chmod +w *.dxf
    //  rm -f *.dxf

	  rm_all_ext("mech",".dxf");
     
      change_dir("mech");

	  getwd(pwd_str);

	 //  printf("pwd = %s \n",pwd_str);

	  strncpy(aptfilestr,infilestr,120);    //$1.apt
	  strncat(aptfilestr,".apt",10);

      // delete old laser/.apt file if it exists
      if (  file_exists( aptfilestr)) 
	  {
	   // chmod +w $1.apt
	   rm_file(aptfilestr); //  -f $1.apt
      }

	  strncpy(apt1filestr,infilestr,120);   // $1.apt
	  strncat(apt1filestr,".apt1",10);

	  strncpy(aperstr,"..",10);    //   ../aper/$1.apt
	  strncat(aperstr,dirsep,10);
      strncat(aperstr,"aper",10);
	  strncat(aperstr,dirsep,5);
	  strncat(aperstr,infilestr,120);
	  strncat(aperstr,".apt",10);

      // ux2dos ../aper/$1.apt > $1.apt1

	  //printf("about to copy %s to %s \n",aperstr,apt1filestr);
	  cp_file( aperstr, apt1filestr);

	//  printf("Past copy file \n");

	  apt1file=fopen(apt1filestr,"r");
	  if (apt1file == NULL)
	  {
		  printf("In xmech, unable to open the input file = %s \n",apt1filestr);
		  exit(-1);
	  }

	  strncpy(aptoutfilestr,infilestr,120);
	  strncat(aptoutfilestr,".apt",10);

      aptfile=fopen(aptoutfilestr,"w");
	  if (aptfile == NULL)
	  {
		  printf("In xmech, unable to open the output aperture file = %s \n",aptoutfilestr);
		  exit(-1);
	  }

      endoffile=getline(apt1file,thisline);
	  nf=split_line(thisline);
      //  modify the aperture file

      while( endoffile == FALSE)    //  read first rest
	  {
     
        // case $first in
	    if (strcmp(str_array[0],"FLASH")== 0 )
		{
		  fprintf(aptfile, "FLASH  tff\n");  // >> $1.apt 
		}
	    if (strcmp(str_array[0],"PEND")== 0 )
		{
		fprintf(aptfile, "PEND 1 \n" );    // >> $1.apt;;
		}
	    if ((strcmp(str_array[0],"FLASH") != 0 ) || ( strcmp(str_array[0],"PEND") != 0 ))
		{
	     fprintf(aptfile,"%s",thisline);        //"$first $rest" >> $1.apt;;
		}

	  endoffile=getline(apt1file,thisline);
	  nf=split_line(thisline);
	  }

      fclose(apt1file);
	  fclose(aptfile);
	  
            //done < $1.apt
     
      //rm -f $1.apt1
	  rm_file( apt1filestr);

	  strncpy(controlfile_str,"..",10);    // ..\control\infilestr.ctl
	  strncat(controlfile_str,dirsep,10);
	  strncat(controlfile_str,"control",20);
	  strncat(controlfile_str,dirsep,10);
	  strncat(controlfile_str,infilestr,120);
	  strncat(controlfile_str,".ctl",10);

      controlfile=fopen(controlfile_str,"r");
	  if (controlfile==NULL)
	  {
		  printf("In xmech, unable to open the control file = %s \n",controlfile_str);
		  exit(-1);
	  }
	  endoffile=getline(controlfile,thisline);
	  nf=split_line(thisline);
   
     while(endoffile==FALSE) //  read name myfile type mfg photo layer mask pcmname
	 {
           //fname=${myfile%.*}
		 strncpy(fname,str_array[1],120);
		 kk=0;
		 while(kk < (signed int) strlen(fname))
		 {
			 if (fname[kk] == '.')
			 {
				 fname[kk]='\0';
			 }
			kk += 1;
		 }

	   // case $type in
        //      "OUTLINE"|"STIFFNER"|"STIFF"|"STIFFENER" | "MECH" |"CUTOUT" | "DRILL" )checklayer $fname ;;
	   if ((strcmp(str_array[2],"OUTLINE")== 0 ) ||
           (strcmp(str_array[2],"STIFFNER")== 0 ) ||
           (strcmp(str_array[2],"STIFFENER")== 0 ) ||
           (strcmp(str_array[2],"STIFF")== 0 ) ||
           (strcmp(str_array[2],"MECH")== 0 ) ||
           (strcmp(str_array[2],"CUTOUT")== 0 ) ||
           (strcmp(str_array[2],"DRILL")== 0 ) )
	   {
          checklayer(fname);
	   }
	  // printf("thisline = %s ",thisline);

	 endoffile=getline(controlfile,thisline);
	 nf=split_line(thisline);
	 }
	 fclose(controlfile);

                          // done < ../control/$1.ctl

     // get all the .m files into scan_array here


	 mfile_count =scandir_matchext(".",0,".m");    // not recursive

     //  perform conversion
     //if flag is a 0 then all .m files have been found
     if ( flag == 0 )
	 {
	   i=0;
	   while(i < mfile_count)
	   {        // create the job file
		   split(scan_array[i],basestr,extstr,".");

		   strncpy(jobfilestr,pwd_str,120);   // $dir/$basestr.job
		   strncat(jobfilestr,dirsep,10);
		   strncat(jobfilestr,basestr,60);
		   strncat(jobfilestr,".job",10);

		   jfile=fopen(jobfilestr,"w");
		   if (jfile == NULL)
		   {
			   printf("Unable to open the job file = %s.job \n",scan_array[i]);
			   exit(-1);
		   }
      
		   cv_toupper(basestr,basestrup);  // make an upper case for layer name

		   fprintf(jfile,"[General] \n");
		   fprintf(jfile,"layers= layer%d \n",i+1);
		   fprintf(jfile,"aptfile=%s%s%s.apt \n",pwd_str,dirsep,infilestr);
		   fprintf(jfile,"dxffile=%s%s%s.dxf\n",pwd_str,dirsep,basestr);
		   fprintf(jfile,"\n");
		   fprintf(jfile,"[layer%d] \n",i+1);
		   fprintf(jfile,"layer=%s,%s%s%s.m\n",basestrup,pwd_str,dirsep,basestr);
		   fprintf(jfile,"dfxcolor=%d \n",i+1);
		   fprintf(jfile,"\n");
		   fclose(jfile);

           // printf("RUNNING: gbr2gdxd %s.m -cfg:%s.apt -s:M  \n",basestr, infilestr);
		   strncpy(aptfilestr,"\"",10);
		   strncat(aptfilestr,"-cfg:",10);
		   strncat(aptfilestr,pwd_str,120);
		   strncat(aptfilestr,dirsep,10);
		   strncat(aptfilestr,infilestr,120);
		   strncat(aptfilestr,".apt",10);
		   strncat(aptfilestr,"\"",10);


		   strncpy(doutfilestr,"\"",10);
		   strncat(doutfilestr,"-out:",10);
		   strncat(doutfilestr,pwd_str,120);
		   strncat(doutfilestr,dirsep,10);
		   strncat(doutfilestr,basestr,120);
		   strncat(doutfilestr,".dxf",10);
		   strncat(doutfilestr,"\"",10);

		   strncpy(jobfilestr,"\"",10);
           strncat(jobfilestr,pwd_str,120);
		   strncat(jobfilestr,dirsep,10);
		   strncat(jobfilestr,basestr,60);
		   strncat(jobfilestr,".job",10);
		   strncat(jobfilestr,"\"",10);

		   strncpy(execfilestr,"C:",10);    // c:\WCAD\Asm500\gbr2gdxd
		   strncat(execfilestr,dirsep,10);
		   strncat(execfilestr,"WCAD",10);
		   strncat(execfilestr,dirsep,10);
		   strncat(execfilestr,"Asm500",20);
		   strncat(execfilestr,dirsep,10);
		   strncat(execfilestr,"gbr2gdxd.exe",20);

          printf("RUNNING: %s  %s %s -f %s -s:M  \n",execfilestr,
			  aptfilestr,doutfilestr, jobfilestr);

		   strncpy(commandstr,execfilestr,120);
		   strncat(commandstr," ",10);
		   strncat(commandstr,aptfilestr,120);
		   strncat(commandstr," ",4);
		   strncat(commandstr,doutfilestr,120);
		   strncat(commandstr," -f ",10);
		   strncat(commandstr,jobfilestr,120);

         // retcode=_execl(execfilestr,"gbr2gdxd",aptfilestr,doutfilestr,"-f",jobfilestr,NULL); // $i -c:$1.apt -s:M 
		   //retcode=CreateProcess("gbr2gdxd",commandstr,0,0,0,0);


          system( commandstr);

		  // printf("retcode = %d \n",retcode);
		  i+=1;
	   }
	 }
     else
	 {
	      printf( "\nFATAL ERROR: .m FILE(S) NOT FOUND\n");
     }

	 change_dir("..");

     //clean up
	 //printf("Cleaning up \n");

	    rm_all_ext("mech",".err");
	    rm_all_ext("mech",".apt");
	   rm_all_ext("mech",".apt1");
  
} // end xmech

/*
int main(int argc, char **argv)
{

  strncpy(usage_str,"usage: xmech partnum ",60);
  strncpy(revstr,"2.0",20);
  strncpy(example_str,"    ex:  xmech 96009",60);
  strncpy(progname_str,"xmech",20);

 if ( argc != 2)
  {
   printf( "incorrect number of arguments \n");
   printf("%s\n%s\n",usage_str,example_str);
  }
  else
  {
	  printf("RUNNING %s%s\n",progname_str,revstr);  // $progname$REV" 

	  xmech_call( argv[1]);
  }

} // end main

  */

  

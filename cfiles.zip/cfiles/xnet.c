#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0



#include "utilprogs.h"

//Creates net_info file or RLGC mode
//wlee 01/07/99
//
//Revision history                      
//09/25/97 - rev 1 - Initial release 

// rev 2 released to users on 10/25/02
// now calls Xnet_only2.0 to handle micron designs
// adds check for report/makelog file and for models directory
// all .awk files now in /usr/local/bin/net_files instead of /usr/local/awk/Xnet
// sub programs of Xnet all modified to handle this.

//------------------------------------------------------------------------------
// Runs Xnet script for 3, 5, 7 layer scm and 5, 7 layer WLBI designs
//------------------------------------------------------------------------------


void xnet_call( char *instr)
{
char systemstr[300];
int debug;


   debug=0;
   if ( file_exists( "report/makelog" ) )
   {
     if( strcmp(instr,"n") == 0 )          // $1 = "n" ]
     {
        printf("\n");
        printf("Extracting net information only\n");

//        /swtools/remote/bin/net_files/Xnet_only2.0

		strncpy(systemstr,"xnet_only2",40);

        if (debug) { printf("calling system: %s \n",systemstr); }
		system(systemstr);

	 }
    if ( strcmp(instr,"m")== 0 )          //$1 = "m" ] 	
     {
        if( dir_exists ("models" ) )
        {
           printf("\n");
           printf("Extracting net information and running RLGC modeling\n");
          // /swtools/remote/bin/net_files/Xnet_only2.0
           strncpy(systemstr,"xnet_only2",40);

		   if (debug) { printf("calling system: %s \n",systemstr); }

	       system(systemstr);

          // /swtools/remote/bin/net_files/model_type2.0
           strncpy(systemstr,"model_type2",40);

           if (debug) { printf("calling system: %s \n",systemstr); }


		   system(systemstr);

		}
        else
		{
           printf("FATAL ERROR: models directory not found\n");
        }
     }
   }
   else
   {
     printf("FATAL ERROR: report/makelog not found\n");
   }

}   // end xnet_call

//---------------------------------------------------------------
// Removes all tmp files when complete.
//---------------------------------------------------------------


int main( int argc, char **argv)
{
char USAGE[300];
char WHERE[300];
char progname[300];
char REV[30];

strncpy(progname,argv[0],120);          //   =${0##*/}


strncpy(USAGE,"usage:  ", 40);
strncat(USAGE,progname,120);
strncat(USAGE," n|m ",30);            // $progname n/m"

strncpy(WHERE,"\t 'n' - option creates net info file only \n      or 'm' - option creates RLGC model",120);

strncpy(REV,"2.0",20);

printf("Running %s   %s \n",progname,REV);

// localname=${PWD##*\/}.mcm

if(argc != 2)
{
   printf("In xnet, incorrect number of arguments\n");
   printf( "%s \n%s \n",USAGE,WHERE);
}
else
{
    xnet_call(argv[1]);
}

} // end main


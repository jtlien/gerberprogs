#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

//
//  Get the part of the filepath after the last slash
//
dir_tail( char *dirstr, char *basepath)
{
int kk;
int ll;
int endslash;

  for(kk=0;kk< (signed int) strlen(dirstr);kk+=1)
  {
	  if (WINDOWS)
	  {
	    if ( dirstr[kk] == '\\' )
		{
		  endslash=kk;
		}
	  }
	  else
	  {
		if (dirstr[kk] == '/' )
		 {
	      endslash=kk;
		}
	  }

  }
 // printf("endslash = %d \n",endslash);

  kk=0;
  for(ll=endslash+1; ll < (signed int) strlen(dirstr); ll += 1)
  {
	  basepath[kk]=dirstr[ll];
      kk+=1;
  }

  basepath[kk]=0;

}


// reads step.txt
//    Xstep   =  val  Ystep = val
//    Xnum    =  val  Ynum  = val    number of parts in the x and y direction
//    ????????????????????????????
//    X       =  val   Y   = val

void plate_call_out(char *infilestr,char *outfilestr)
{
int i;
int scale;
int dx;
int dy;
int nx;
int ny;
int lx;
int ly;
int endoffile;
FILE *file1;
FILE *outfile;
int nf;
char thisline[300];


 scale=10000;

    dx=0;
	dy=0;

   file1 = fopen(infilestr,"r");
   if (file1==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",infilestr);
	   exit(-1);
   }

   outfile= fopen(outfilestr,"w");
   if (outfile==NULL)
   {
	   printf("In plate, unable to open the input file = %s \n",outfilestr);
	   exit(-1);
   }

   endoffile=getline(file1,thisline);
   nf=split_line(thisline);

   while(endoffile==FALSE)
   {
    if ((strcmp(str_array[0],"Xstep")==0) && (strcmp(str_array[3],"Ystep")==0))
	{
     dx = atoi(str_array[2])*scale;
     dy = atoi(str_array[5])*scale;
	}
    if (dx == 0)
     dx = 1532500*2;
    if (dy == 0)
     dy = 1532500*2;

    endoffile=getline(file1,thisline);
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"Xnum")==0) && ( strcmp(str_array[3],"Ynum")==0))
	{                                        //$1 == "Xnum") && ($4 == "Ynum")){
    nx = atoi(str_array[2]); // $3
    ny = atoi(str_array[5]); // $6
	}
    endoffile=getline(file1,thisline);
    endoffile=getline(file1,thisline); // getline
	nf=split_line(thisline);

    if ((strcmp(str_array[0],"X")==0) && (strcmp(str_array[3],"Y")==0)) 
	{
    lx = atoi(str_array[2])*scale - dx/2;
    ly = atoi(str_array[5])*scale - dy/2;
	}
  endoffile=getline(file1,thisline);
  nf=split_line(thisline);
   }

 fclose(file1);

 fprintf(outfile,"D299*\n");
 fprintf(outfile,"X-1532500Y-1532500D02*\n");  // a box 1532500 x 1532500 to -1532500,-1532500
 fprintf(outfile,"X1532500Y-1532500D01*\n");
 fprintf(outfile,"X1532500Y1532500D01*\n");
 fprintf(outfile,"X-1532500Y1532500D01*\n");
 fprintf(outfile,"X-1532500Y-1532500D01*\n");

 fprintf(outfile,"X-1700000Y1300000D02*\n");   // 4 lines, Y=13000000
 fprintf(outfile,"X-1532500Y1300000D01*\n");
 fprintf(outfile,"X-1700000Y450000D02*\n");               //  Y=450000
 fprintf(outfile,"X-1532500Y450000D01*\n");
 fprintf(outfile,"X-1700000Y-1300000D02*\n");              // Y=-13000000 
 fprintf(outfile,"X-1532500Y-1300000D01*\n");  
 fprintf(outfile,"X-1700000Y-450000D02*\n");              // Y=-450000
 fprintf(outfile,"X-1532500Y-450000D01*\n");
 fprintf(outfile,"X1700000Y1300000D02*\n");    // 4 lines
 fprintf(outfile,"X1532500Y1300000D01*\n");
 fprintf(outfile,"X1700000Y450000D02*\n");    
 fprintf(outfile,"X1532500Y450000D01*\n");
 fprintf(outfile,"X1700000Y-1300000D02*\n");
 fprintf(outfile,"X1532500Y-1300000D01*\n");
 fprintf(outfile,"X1700000Y-450000D02*\n");
 fprintf(outfile,"X1532500Y-450000D01*\n");

 fprintf(outfile,"D298*\n");

 for (i = 1; i <= nx+1; i++) 
 {
   fprintf(outfile,"X%dY-1532500D02*\n", lx+(i-1)*dx);
   fprintf(outfile,"X%dY+1532500D01*\n", lx+(i-1)*dx);
 }
 for (i = 1; i <= ny+1; i++) 
 {
   fprintf(outfile,"X-1532500Y%dD02*\n", ly+(i-1)*dy);
   fprintf(outfile,"X1532500Y%dD01*\n", ly+(i-1)*dy);
 }
 fclose(outfile);

}  // end plate_call_out


//
//  reads in step.txt, creates tmp.art by running plate on it
//   contatenates this information onto mfg/$1.pan
//     copies the mfg/$1.pan to mfg/$1.org
//     adds apertures for D298 and D299 if they don't already exist
//       to aper/$basename.apt

int main( int argc, char **argv)
{
char basename[300];
char aptstr[10][200];
char fromfilestr[200];
char tofilestr[200];
char file1str[300];
FILE *aptfile;
int grep_cnt;
char shortbase[200];
int grep_ret;

  if (argc != 2)
  {
   printf( "Only one file allowed at a time!\n");
   exit(-1);
  }

  if (WINDOWS )
  {
	strncpy(dirsep,"\\",4);
  }
  else
  {
	strncpy(dirsep,"/",4);
  }

  strncpy(aptstr[0],"D298 1.30 d Round   1.3 1.3 ",130);
  strncpy(aptstr[1],"D299 1.30 d Square  1.3 1.3 ",130);

  
  getwd(basename);
  
  dir_tail(basename,shortbase);
 
  // printf("basename = %s shortbase = %s \n",basename, shortbase);

//gawk -f /project/dah/bin/plate.awk step.txt > tmp.art

  plate_call_out("step.txt","tmp.art");

  strncpy(fromfilestr,"mfg",10);
  strncat(fromfilestr,dirsep,10);
  strncat(fromfilestr,argv[1],120);
  strncat(fromfilestr,".pan",10);

  strncpy(tofilestr,"mfg",10);
  strncat(tofilestr,dirsep,10);
  strncat(tofilestr,argv[1],120);
  strncat(tofilestr,".org",10);;

 cp_file( fromfilestr,tofilestr);  // cp mfg/$1.pan to mfg/$1.org
//cp mfg/$1.pan mfg/$1.org

  strncpy(file1str,"mfg",10);
  strncat(file1str,dirsep,10);
  strncat(file1str,argv[1],120);
  strncat(file1str,".org",10);

  strncpy(tofilestr,"mfg",10);
  strncat(tofilestr,dirsep,10);
  strncat(tofilestr,argv[1],120);
  strncat(tofilestr,".pan",10);

  cat_files(file1str,"tmp.art",tofilestr); //  mfg/$1.org tmp.art > mfg/$1.pan

  strncpy(file1str,"aper",10);
  strncat(file1str,dirsep,10);
  strncat(file1str,shortbase,120);
  strncat(file1str,".apt",10);

  grep_ret=grep_counter(file1str,"D298",&grep_cnt); // -c D298 aper/$basename.apt > /dev/null

// retval=$?

  if ( grep_cnt == 0 )   // No D298 in aperture file so add one
  {
   strncpy(fromfilestr,"aper",20);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,shortbase,120);
   strncat(fromfilestr,".apt",10);

   if ( file_exists(fromfilestr))
   {
	 aptfile=fopen(fromfilestr,"a");
	 fprintf(aptfile,"%s\n",aptstr[0]);
	 fprintf(aptfile,"%s\n",aptstr[1]);
     fclose(aptfile);
   }
   else
   {
	  printf("In xplate,unable to open the aperture file = %s for write\n", fromfilestr);
	  exit(-1);
   }
  //cat_files aper/$basename.apt /project/dah/bin/plate.apt >aper/tmp.apt
  //mv aper/tmp.apt aper/$basename.apt
  }
 
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>

#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1

void plate14x18_call_out( char *infilestr, char *comstr, char *outfilestr);

//
//  Get the part of the filepath after the last slash
//
dir_tail( char *dirstr, char *basepath)
{
int kk;
int ll;
int endslash;

  for(kk=0;kk< (signed int) strlen(dirstr);kk+=1)
  {
	  if (WINDOWS)
	  {
	    if ( dirstr[kk] == '\\' )
		{
		  endslash=kk;
		}
	  }
	  else
	  {
		if (dirstr[kk] == '/' )
		 {
	      endslash=kk;
		}
	  }

  }
 // printf("endslash = %d \n",endslash);

  kk=0;
  for(ll=endslash+1; ll < (signed int) strlen(dirstr); ll += 1)
  {
	  basepath[kk]=dirstr[ll];
      kk+=1;
  }

  basepath[kk]=0;

}




//
//  reads in step.txt, creates tmp.art by running plate on it
//   contatenates this information onto mfg/$1.pan
//     copies the mfg/$1.pan to mfg/$1.org
//     adds apertures for D298 and D299 if they don't already exist
//       to aper/$basename.apt

int main( int argc, char **argv)
{
char basename[300];
char aptstr[10][200];
char fromfilestr[200];
char tofilestr[200];
char file1str[300];
char commandstr[300];
FILE *aptfile;
int grep_cnt;
int grep_ret;
char shortbase[200];

  if ((argc != 2) || (argc !=3 ))
  {
   printf( "Only one file allowed at a time!\n");
   exit(-1);
  }

  if (argc == 2)
  {
	  strncpy(commandstr,"",4);
  }
  else
  {
	  strncpy(commandstr,argv[2],10);
  }
  if (WINDOWS )
  {
	strncpy(dirsep,"\\",4);
  }
  else
  {
	strncpy(dirsep,"/",4);
  }

  strncpy(aptstr[0],"D298 1.30 d Round   1.3 1.3 ",130);
  strncpy(aptstr[1],"D299 1.30 d Square  1.3 1.3 ",130);

  
  getwd(basename);
  
  dir_tail(basename,shortbase);
 
  // printf("basename = %s shortbase = %s \n",basename, shortbase);

//gawk -f /project/dah/bin/plate.awk step.txt > tmp.art

  plate14x18_call_out("step.txt",commandstr,"tmp.art");

  strncpy(fromfilestr,"mfg",10);
  strncat(fromfilestr,dirsep,10);
  strncat(fromfilestr,argv[1],120);
  strncat(fromfilestr,".pan",10);

  strncpy(tofilestr,"mfg",10);
  strncat(tofilestr,dirsep,10);
  strncat(tofilestr,argv[1],120);
  strncat(tofilestr,".org",10);;

 cp_file( fromfilestr,tofilestr);  // cp mfg/$1.pan to mfg/$1.org
//cp mfg/$1.pan mfg/$1.org

  strncpy(file1str,"mfg",10);
  strncat(file1str,dirsep,10);
  strncat(file1str,argv[1],120);
  strncat(file1str,".org",10);

  strncpy(tofilestr,"mfg",10);
  strncat(tofilestr,dirsep,10);
  strncat(tofilestr,argv[1],120);
  strncat(tofilestr,".pan",10);

  cat_files(file1str,"tmp.art",tofilestr); //  mfg/$1.org tmp.art > mfg/$1.pan

  strncpy(file1str,"aper",10);
  strncat(file1str,dirsep,10);
  strncat(file1str,shortbase,120);
  strncat(file1str,".apt",10);

  grep_ret=grep_counter(file1str,"D298",&grep_cnt); // -c D298 aper/$basename.apt > /dev/null

// retval=$?

  if ( grep_cnt == 0 )   // No D298 in aperture file so add one
  {
   strncpy(fromfilestr,"aper",20);
   strncat(fromfilestr,dirsep,10);
   strncat(fromfilestr,shortbase,120);
   strncat(fromfilestr,".apt",10);

   if ( file_exists(fromfilestr))
   {
	 aptfile=fopen(fromfilestr,"a");
	 fprintf(aptfile,"%s\n",aptstr[0]);
	 fprintf(aptfile,"%s\n",aptstr[1]);
     fclose(aptfile);
   }
   else
   {
	  printf("In xplate,unable to open the aperture file = %s for write\n", fromfilestr);
	  exit(-1);
   }
  //cat_files aper/$basename.apt /project/dah/bin/plate.apt >aper/tmp.apt
  //mv aper/tmp.apt aper/$basename.apt
  }
 
}

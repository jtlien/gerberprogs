#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

//include "utilprogs.h"

#define WINDOWS 1

int newup_call_out( char *infile1, char *infile2, char *outfile);
int getoutref2_call_out(char *file1str, char *infilestr, char *outfilestr);
int placetext_call_out( char *infilestr, char *outfilestr);
void fixheader_call_out( char *infilestr, char *outfilestr);
int getplottext5_call( char *brd, char *tail, char *cust, char *controlfilesr);
void mkdir( char *dirstr);

char progname[300];
char USAGE[300];
char EXAMPLE[300];
char MASTER[300];
char VERSION[300];

//progname=${0##*/}

// 1.1 updated 8/12/97 
//     changes how files are named
// 2.0 updated 5/11/98
//     now plots "cutouts" with all layers
//     adds "bogus" LPC layer to outline layer to eliminate
//       not printing all of outline border.
//     "art" switch now prints from pre-bais directory not 274x
//     if gbrvu cannot print from layer from selected directory then trys to find
//       file in scm directory.
// 2.1 updated 11/5/98
//     now call fixoutline2; this fixes a problem the outline layer
//     not showing up on WLBI parts.
// 2.2 updated 12/15/98
//     now calls getplottext3; this handles not printing the board rev
// 2.3 updated 1/28/99
//     now calls fixoutline3; this fixes a bug in not handling the D01,D02,D03
//     codes being modal correctly.
// 2.4 updated 4/3/99
//     changed so error messages just go to standard output & not stderr.
//     added return values to calling script ( 0 = good, 1 = WARNING, >2 = ERROR) 
//     now calls getplottext4; this helps with above changes.
//     changed so now gets customer information from report/makelog
//     instead of summary.txt.
// 2.5 updated 12/06/99
//     nows calls xgbrvu instead of gbrvu 
//     no longer calls fixoutline3
//     uses new configuration files for xgbrvu plot settings
//     These configuration files were updated again on 3/7/2000
//     changed from postscriptII to postscript
//
// 2.6 updated 10/3/00
//     updated to use 3M logo, now calls getplottext5 (3M text)
//
// find occurances of a string in a file, returning count of lines
//    count only, do not put lines into grep_array
//
int grep_count_lines( char *infilestr, char *searchstr)
{
int ii;
FILE *infile;
int endfile;
char thisline[300];
int lines;

   infile=fopen(infilestr,"r");
   if (infile == NULL)
   {
	   printf("In grep_count_lines, unable to open the input file =%s\n",infilestr);
	   exit(-1);
   }

  ii=0;
  lines=0;
  endfile=getline(infile,thisline);

  while( endfile==FALSE)
  {
      // printf("line in = %s search val =%s: \n",thisline,searchstr);

	  if (strstr(thisline,searchstr) != NULL)
	  {
        strncpy(grep_array[lines],thisline,120);
		if (lines < 10000)
		{
		  lines += 1;
		}
		else
		{
			printf("In xplot, grep_count_lines, lines > 10000 \n");
			exit(-1);
		}
	  }
    endfile=getline(infile,thisline);
  }
  fclose(infile);

  
  return(lines);

}

// extenstr does not have a dot in front of it
//  partnumstr is part number


void xplot_call( char *partnumstr, char *extenstr, char *custstr)
{
char pwdstr[300];
char mypath[300];
char myfile[300];

int CUST;
int tmp;
char mycutout[300];
char fname[300];
char extstr[300];
int status;
char tail[300];
char chkfilestr[300];
char tmpname[300];
char fromfilestr[300];
char tofilestr[300];
int ulimit;
char systemstr[300];
char basestr[300];
char controlfilestr[300];
char chkfile2str[300];
char jbasestr[300];
char type[300];
FILE *controlfile;
FILE *baselistfile;
FILE *tmplistfile;
FILE *outcodefile;
FILE *thecodefile;
int thiscode;

char tcuststr[300];
int endoffile;
char thisline[300];
char tailstr[300];
int tailfilecount;
char mfg[300];
char pextstr[200];
char baselistfilestr[300];
char grepfilestr[300];
char junkstr[300];
int grep_count;
char *sptr;
char digit_str[300];
int found_codes[3000];

int i,jj,ll;
int nf;
int pwin_count;
int IsOK;
int kk;

int debug;


debug = 0;

for(jj=0; jj < 3000; jj += 1)
{
	found_codes[jj]=0;
}

if (WINDOWS)
{
strncpy(MASTER,"m:/design/software/mmm/PANEL",40);
}
else
{
strncpy(MASTER,"/swtools/remote/bin/PANEL",40);
}


strncpy(VERSION,"2.6",10);

getwd( pwdstr);

strncpy(mypath,pwdstr,300);   // we move around a little so,lets keep the current directory

printf("***** RUNNING %s Version %s *****\n",progname,VERSION);
ulimit =1000000;
status=0;

   
   strncpy(chkfilestr,"control/",20);  // control/$1.ctl
   strncat(chkfilestr,partnumstr,120);
   strncat(chkfilestr,".ctl",10);

   if ( ! ( file_exists( chkfilestr) ) )  // -f control/$1.ctl 
  {
      printf( "FATAL ERROR:");
      printf("\tcontrol/%s.ctl is MISSING\n" ,partnumstr);
      exit(3);
   }

   if ( (strcmp(extenstr,"gbx")==0) &&  (! (file_exists("mfg/outline.gbx") ) ) )
  {
      printf(  "FATAL ERROR:\n");
      printf( "\tmfg/outline.gbx is MISSING\n"); 
      exit(4);
   }

   if ( (strcmp(extenstr,"art")==0) &&  (! (file_exists("pre-bias/outline.art") ) ) )
  {
      printf( "FATAL ERROR:");
      printf( "\tpre-bias/outline.art is MISSING\n");
      exit(5);
   }

   if ( (strcmp(custstr,"cust")==0) && ( ! ( file_exists("report/makelog") ) ) )
  {
      printf( "FATAL ERROR:");
      printf( "\toption 'cust' but report/makelog is MISSING\n");
      exit(6);
   }

   // remove files in plot directory if it exists 
   // else create it
   if ( dir_exists(  "plot"  ) )
   {
       system("rm -f plot/*.*");
	}
   else
   {
       system("mkdir plot");
   } 

   CUST=0;   // 0 = no customer info printed on plots

          // This is the default state
   if ( file_exists( "report/makelog")  && (strcmp(extstr,"cust") == 0 ) ) // $3 =  cust )
  { 
       CUST=1;
       cp_file("report/makelog", "plot/makelog");
   }


   change_dir("plot");

   strncpy(systemstr,"cp ",10);   // cp $MASTER/PLOT/*.*
   strncat(systemstr,MASTER,120);
   strncat(systemstr,"/PLOT/*.* .",30);

   system(systemstr); 
  // cp $MASTER/PLOT/*.* .

   strncpy(fromfilestr,MASTER,120);
   
   strncat(fromfilestr,"/APER/PANEL.APT",30);

   cp_file( fromfilestr,  "panel.apt");


   if ( (strcmp(extenstr,"gbx")==0 )   )      // $2 =  gbx 
   { 
       strncpy(tail,".gbx",10);

       //ls -l ../mfg/*.gbx > finfo
	   system("ls -l ../mfg/*.gbx >finfo");

       //ls -l ../aoi/*.gbx >> finfo
	   system("ls -l ../aoi/*.gbx >>finfo");


       cp_files_ext("../mfg/",".gbx",".");   // *.gbx .
       cp_files_ext("../aoi/",".gbx",".");    // *.gbx .
      
	}
   else if ( (strcmp(extenstr,"art")==0 ) ) // $2 = art 
   {
       strncpy(tail,"art",10);

       //ls -l ../pre-bias/*.art > finfo
	   system("ls -l ../pre-bias/*.gbx >finfo");

       cp_files_ext("../pre-bias",".art",".");        //*.art .
      
    }
   else
   {
       printf(  "FATAL ERROR:\n");
       printf( "\tSecond parameter must be 'art' or 'gbx' \n");
       printf( "\t%s\n\t%s\n",USAGE,EXAMPLE);
       exit(7);
   }

  //THIS section of code is to handle gbrvu not being able to look at
  //multiple 274x layers- they have a problem with the aperture list
  //getting corrupted
       
     strncpy(mycutout,"",10);   // NULL;

	//printf (" mycutout = %s \n", mycutout);

        strncpy(controlfilestr,"../control/",30);
        strncat(controlfilestr,partnumstr,120);
		strncat(controlfilestr,".ctl",10);

		printf("about to open %s \n",controlfilestr);

        controlfile = fopen( controlfilestr,"r");
		if (controlfile == NULL)
	     {
		   printf("Unable to open the ../control/%s.ctl file for reading \n", partnumstr);
		   exit(-1);
		 }

        endoffile=getline(controlfile,thisline);
		nf=split_line(thisline);

        while(endoffile==FALSE) // read name myfile type mfg photo layer mask pcmname
         {
		  if (nf > 2)
		  {
		   strncpy(myfile,str_array[1],120);
		   strncpy(type,str_array[2],120);
		   strncpy(mfg,str_array[3],120);

	      //fname=${myfile%.*}
		   split(myfile,fname,extstr,".");

	      if ( strcmp(type,"CUTOUT" ) == 0 )
	      { 
		    //mycutout=$fname.$tail
			strncpy(mycutout,fname,120);
			strncat(mycutout,tail,30);

          }

         if( (strcmp(type,"CUTOUT")==0 ) || (strcmp(type,"OUTLINE" )==0 ))
	        {
			 if (debug) { printf( "in loop fname =  %s  tail = %s \n",fname, tail); }

			   strncpy(fromfilestr,fname,120);
			   strncat(fromfilestr,tail,30);

               strncpy(tofilestr,fname,120);
			   strncat(tofilestr,".tmp",10);

	           //mv $fname.$tail $fname.tmp
			   cp_file(fromfilestr,tofilestr);
               rm_file(fromfilestr);

			   thecodefile = fopen("thecodes","w");
			   if (thecodefile==NULL)
			   {
				   printf("Unable the open the file = thecodes     for writing \n");
				   exit(-1);
			   }

			   tailfilecount= scandir_matchext(".",0,tail);
               grep_count=0;
			   for(jj =0 ; jj < tailfilecount; jj += 1)
			   {
				   if (debug) { printf("grepping the file = %s \n", scan_array[jj]); }

	            grep_count=grep_count_lines( scan_array[jj],"ADD"); // *.$tail | getnum >thecodes
				if (debug) { printf(" grep of %s has count = %d \n", scan_array[jj], grep_count); }
				for( i=0; i < grep_count; i += 1)
				{
					if (debug) { printf("In loop, i = %d grep_array = %s \n",i, grep_array[i]);}

				   sptr = strstr( grep_array[i],"ADD");
				   if (sptr != NULL)
				   {
				     if (debug) { printf("i = %d grep_array first = %s \n",i, grep_array[i]); }
				     sptr++;
				     sptr++;
				     sptr++;
				     ll=0;
				     while( isdigit( *sptr) && ( ll < 30))
					 {
					   digit_str[ll] = *sptr;
					   sptr++;
					   ll += 1;
					 }
				    digit_str[ll] = '\0';
				    if (debug) { printf("digit str (1) = %s \n",digit_str); }
					thiscode=atoi(digit_str);

					if (( thiscode < 3000) && (found_codes[thiscode]== 0 ) )
					{
						found_codes[thiscode] = 1;
				        fprintf(thecodefile,"%d\n",thiscode );
					}
					else
					{
						if (thiscode > 2999 )
						{
							printf("In xplot, Dcode in file = %s exceeds 3000 , is = %d \n",
								   scan_array[jj], thiscode);
						}
					}
				   }
				}
			   }

			  fclose(thecodefile);

			 strncpy(grepfilestr,fname,120);
			 strncat(grepfilestr,".tmp",10);

			 outcodefile=fopen("outcodes","w");
			 if (outcodefile == NULL)
			 {
				 printf("Unable to open the file = outcodes   for writing \n");
				 exit(-1);
			 }
			 
			 if (debug) { printf("grepping file = %s \n", grepfilestr); }

	         grep_count=grep_count_lines(grepfilestr,"ADD");  //$fname.tmp | getnum > outcodes

			 if (debug) { printf("grep_count = %d \n",grep_count); }

			 for(i=0;i < grep_count; i += 1)
			 {
				 if (debug) { printf("i = %d grep_array = %s \n",i, grep_array[i]); }

				 sptr=strstr(grep_array[i],"ADD");   // point to ADD
				 if (sptr != NULL)
				 {
				   sptr++;
				   sptr++;
				   sptr++;
				   ll=0;
				   while( isdigit( *sptr) && (ll < 30))
				   {
					 digit_str[ll] = *sptr;
					 sptr++;
					 ll += 1;
				   }
				   digit_str[ll] = '\0';
				   if (debug) { printf("digit str (2) = %s \n",digit_str); }

				   fprintf(outcodefile,"%d\n",atoi(digit_str) );
				 }
			 }
			 fclose(outcodefile);

			 if (debug) { printf("done with the codefiles \n"); }

	         IsOK=getoutref2_call_out( "outcodes", "thecodes","tmpref");

	        // IsOK=$?

	         if( IsOK == 0 )
	         {
			    strncpy(fromfilestr,fname,120);  // $fname.tmp
				strncat(fromfilestr,".tmp",15);

                strncpy(tofilestr,fname,120);   // $fname$tail
				strncat(tofilestr,tail,120);

	            newup_call_out("tmpref",  fromfilestr,tofilestr );
	            //rm $fname.tmp
		     }
	         else
			 {
                printf( "FATAL ERROR:");
		        printf( "\tUnable to find free aperture for outline/cutout file \n");
	            exit(8);
			 }
		   }    
	    }

        endoffile=getline(controlfile,thisline);
		nf=split_line(thisline);

       }   // < ../control/$1.ctl


   fclose(controlfile);

  // End of gbrvu kludge

     //get text for all layers

 

   for(kk=1; kk < (int) strlen(tail); kk += 1)  // tailstr is tail without "."
   {
	   tailstr[kk-1]=tail[kk];
   }
   tailstr[kk-1]=tail[kk];
   tailstr[kk]='\0';

   printf( "Running getplottext5  %s %s %d   ../control/%s.ctl \n",
               partnumstr,tailstr,CUST,partnumstr);

  strncpy(tofilestr,"../control/",30);
  strncat(tofilestr,partnumstr,120);
  strncat(tofilestr,".ctl",15);

  _snprintf(tcuststr,300,"%d",CUST);

 status= getplottext5_call(  partnumstr, tailstr, tcuststr, tofilestr);
 if (debug) { printf("Returned from getplottext5 \n"); }


// status=$?

 pwin_count = scandir_matchext(".",0,".pwin");

 debug = 1;

 if (debug) { printf("pwin count = %d \n",pwin_count); }

 i = 0;
 for(i=0; i < pwin_count; i += 1)     //  i in *.pwin
   {
        split(scan_array[i],basestr,pextstr,".");

        //place the text for the layer
        printf( "Running placetext  %s > %s.pw \n", 
		    scan_array[i], basestr );

       // strncpy(fromfilestr,MASTER,120);    no longer used
	//	strncat(fromfilestr,"/TEXT90",30);

        strncpy(tofilestr,basestr,120);
		strncat(tofilestr,".pw",10);

        placetext_call_out( scan_array[i],tofilestr); //
		                                 // -v file1=$MASTER/TEXT90 $i > ${i%.*}.pw
     strncpy(fromfilestr,basestr,120);
	 strncat(fromfilestr,".pw",10);

	 strncpy(tofilestr,basestr,120);
	 strncat(tofilestr,".plt1",10);

	cat_files( "title.gbr", fromfilestr, tofilestr); //  > ${i%.*}.plt1

	//plot the text header and logo for each layer

	strncpy(baselistfilestr,basestr,120);
	strncat(baselistfilestr,".lst",10);

	baselistfile=fopen(baselistfilestr,"w");
    if (baselistfile==NULL)
	{
		printf("Unable to open the %s file for output \n", baselistfilestr);
		exit(-1);
	}
	fprintf(baselistfile, ":Cfg   panel.apt \n");    // > ${i%.*}.lst

	fprintf(baselistfile, ":Drw   %s.plt1 \n",basestr); // >> %s.lst

	cp_file("plot_header.cfg", "plot.cfg");

	printf( "Running gbrvu -iconic -plot %s.lst \n", basestr    );

	strncpy(systemstr,"gbrvu -iconic -plot ", 40);
	strncat(systemstr,basestr,120);
	strncat(systemstr,".lst",10);

    system( systemstr);

	strncpy(tofilestr,basestr,120);
	strncat(tofilestr,".plt2",10);

	fixheader_call_out( "plot1", tofilestr); // >${i%.*}.plt2

	//plot the part for each layer
	cp_file("plot_part.cfg", "plot.cfg");
//	j=${i%.*}
	strncpy(jbasestr,basestr,120);

	if ( strcmp(mycutout,"") == 0 )        // NULL )
	{
	   printf( "Running  gbrvu -274x -iconic -plot outline.%s %s.%s  \n",
		        tail, jbasestr, tail);
	            
	   strncpy(systemstr,"gbrvu -274x -iconic  -plot outline.",80);
	   strncat(systemstr,tail,30);
	   strncat(systemstr," ",4);
	   strncat(systemstr,jbasestr,120);
	   strncat(systemstr,".",4);
	   strncat(systemstr,tail,30);

	   system(systemstr);

	   tmplistfile = fopen("tmp.lst","w");
	   if (tmplistfile == NULL)
	   {
		   printf("Unable to open the file = tmp.lst   for writing \n");
		   exit(-1);
	   }

       system(systemstr);      // How to find out if xgbrvu fails? 
	  // tmp=$?
	   tmp = 0;
	   if(tmp != 0)
	    {
	       printf( "WARNING:\n\tUnable to print from %s data\n",extenstr);
	       printf( "\tattempting to print from 'artwork' data\n");
	       status=1;

		   strncpy(chkfilestr,"../artwork/",30);
		   strncat(chkfilestr,jbasestr,120);
		   strncat(chkfilestr,".art",10);

	       if ( file_exists(chkfilestr)  && file_exists( "../artwork/outline.art") )
	      {
                  //dos2ux ../artwork/${j#*.}.art > ${j#*.}.cen 
			      strncpy(fromfilestr,"../artwork/",30);
				  strncat(fromfilestr,jbasestr,120);
				  strncat(fromfilestr,".art",10);

				  strncpy(tofilestr,jbasestr,120);
				  strncat(tofilestr,".cen",10);

			      cp_file(fromfilestr,tofilestr);
		        //  dos2ux ../artwork/outline.art > outline.cen 
				  cp_file("../artwork/outline.art", "outline.cen");

		        //  dos2ux ../aper/$1.prt  > $1.apt
				  strncpy(fromfilestr,"../aper/",30);
				  strncat(fromfilestr,partnumstr,120);
				  strncat(fromfilestr,".prt",10);

				  strncpy(tofilestr,partnumstr,120);
				  strncat(tofilestr,".apt",10);

				  cp_file(fromfilestr,tofilestr);
		          fprintf(tmplistfile, ":Cfg   %s.apt \n",partnumstr); // > tmp.lst
		          fprintf(tmplistfile, ":Drw   outline.cen \n");          // >> tmp.lst
		          fprintf(tmplistfile, ":Drw   %s.cen \n",jbasestr);          //  >> tmp.lst
	              system("xgbrvu -iconic -plot tmp.lst");
		   }
	      else
		  {
		         printf("WARNING:");
		         printf("\tUnable to print from  'artwork (274D)' data \n");
		         printf("\tFile not found: %s.art, cutout.art or outline.art\n",jbasestr);
		         printf("\tCreate vector artwork and run Xplot again\n");
		         status=1;
           }
         }
        else
		{
	     printf( "Running  gbrvu -274x -iconic -plot outline.%s %s.%s %s \n",
			                          tail, jbasestr, tail, mycutout);
		 strncpy(systemstr,"gbrvu -274x -iconic -plot outline.",120);
		 strncat(systemstr,tail,30);
		 strncat(systemstr," ",4);
		 strncat(systemstr,jbasestr,120);
		 strncat(systemstr,".",10);
		 strncat(systemstr,tail,30);
		 strncat(systemstr," ",4);
		 strncat(systemstr,mycutout,120);


	   //  system( "gbrvu -274x -iconic -plot outline.$tail ${j#*.}.$tail $mycutout \n");
		 system(systemstr);

	    // tmp=$?
	     if(tmp != 0)
	      {
	       printf( "WARNING:\n\tUnable to print from %s data \n",partnumstr);
	       printf( "\tattempting to print from 'artwork' data\n");
	       status=1;
	       split(mycutout,tmpname,junkstr,"."); // =${mycutout%.*}

		   strncpy(chkfilestr,"../artwork/",20);
		   strncat(chkfilestr,jbasestr,120);
		   strncat(chkfilestr,".art",10);

		   strncpy(chkfile2str,"../artwork/",20);
		   strncat(chkfile2str,tmpname,120);
		   strncat(chkfile2str,".art",10);

	       if ( file_exists(chkfilestr)  && 
			    file_exists("/artwork/outline.art") && 
				file_exists(chkfile2str ) )
	       {
                 // dos2ux ../artwork/${j#*.}.art > ${j#*.}.cen 
		     // dos2ux ../artwork/outline.art > outline.cen 
			  cp_file("../artwork/outline.art","outline.cen");
		      //dos2ux ../artwork/$tmpname.art > $tmpname.cen 
			  strncpy(fromfilestr,"../artwork/",30);
			  strncat(fromfilestr,tmpname,120);
			  strncat(fromfilestr,".art",10);

			  cp_file(fromfilestr,tofilestr);

			  strncpy(fromfilestr,"../aper/",20);
			  strncat(fromfilestr,partnumstr,120);
			  strncat(fromfilestr,".prt",10);

			  strncpy(tofilestr,partnumstr,120);
			  strncat(tofilestr,".apt",10);
			  cp_file(fromfilestr,tofilestr);

		     // dos2ux ../aper/$1.prt  > $1.apt
		      fprintf(tmplistfile, ":Cfg   $1.apt \n", partnumstr); //  > tmp.lst
		      fprintf(tmplistfile,":Drw   outline.cen\n"); // >> tmp.lst
		      fprintf(tmplistfile,":Drw   %s.cen \n",jbasestr); // >> tmp.lst
		      fprintf(tmplistfile, ":Drw   %s.cen \n",tmpname); // >> tmp.lst
			   fclose(tmplistfile);
	          printf("RUNNING gbrvu -iconic -plot tmp.lst \n");
	          system("gbrvu -iconic -plot tmp.lst");
			}
	       else
		   {
		     printf( "WARNING:");
		     printf( "\tUnable to print from  'artwork (274D)' data \n");
		     printf( "\tFile not found: %s.art or outline.art\n", jbasestr );
		     printf( "\tCreate vector artwork and run Xplot again\n");
		     status=1;
            }
          }
        }

    }
	strncpy(fromfilestr,basestr,120);
	strncat(fromfilestr,".plt2",20);

	strncpy(tofilestr,basestr,120);
	strncat(tofilestr,".ps",20);

	cat_files(fromfilestr,"plot1",tofilestr); // ${i%.*}.plt2 plot1 > ${i%.*}.ps
	rm_file("plot1");
//	rm #${j#*.}.$tail    fix later
    }

	if (! debug) { rm_files_ext(".lst");      } // rm  *.lst 
	 rm_files_ext(".pwin");      // rm *.pwin 
	 rm_files_ext(".plt1");      //  *.plt1
	 rm_files_ext(".plt2");      // rm *.plt2 
	 rm_files_ext(tail);         // rm *.$tail  
	 rm_files_ext(".pw");        //  *.pw  2>/dev/null
     rm_files_ext(".tmp");       //  *.tmp 
	 rm_file("finfo"); 
	 system("rm cfg.*");
	 if ( ! debug ) { system("rm plot*.cfg"); }

	 rm_file("plot.log");
	 rm_files_ext(".gbr");           //  *.gbr 
	 rm_file("makelog");                 //   2>/dev/null
     rm_files_ext(".apt");           //  *.apt 
	 if (! debug) { system("rm *.job*"); }

	 rm_file("outcodes"); 
	 rm_file("thecodes");
	 rm_file("tmpref");
	 
	 system("rm rs274mac*"); // 2>/dev/null
     if( status == 0 )
     {
	   fprintf(stderr,"%s COMPLETED SUCCESSFULLY\n",progname);
      }
      exit(status);

}  // end xplot


int main( int argc, char **argv)
{

strncpy(progname, argv[0],120);

strncpy(USAGE,"usage: ", 30);
strncat(USAGE,progname,120);
strncat(USAGE," ",4);
strncat(USAGE,"partnum gbx|art [nocust|cust] ",120);

strncpy(EXAMPLE,"\tex:",30);
strncat(EXAMPLE,progname,120);
strncat(EXAMPLE,"96009 gbx cust ",40);     //  $progname 96009 gbx cust" 

if ((argc == 4 ) || (argc == 3 ) )
{

   strncpy(MASTER,"/usr/local/bin/PANEL",40);
   strncpy(VERSION,"2.6",10);
   if (argc == 3)
    {
	  xplot_call( argv[1], argv[2], "nocust");
	  }
   if (argc == 4)
    {
	  xplot_call( argv[1], argv[2], argv[3]);
	 }
}
else
{
  printf("%s \n",USAGE );
  printf("%s \n", EXAMPLE);
  exit(-1);
}

}  // end main

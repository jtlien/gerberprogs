#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>


#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

int chk_wb_call( char *wbstring);

//Script checks the C4 c4solder mask annular ring and writes to report/Xsmasklog file.
//01/08/97 wlee
//
//Revision History
//01/08/98 - rev 1 - initial release
//01/13/98 - rev 2 - Changed log file name to Xsmasklog
//		    Does not concate to Xsmasklog - overwrites file each time program is run
//01/23/98 - rev 3 - Changed varible C4OFFSET from 10 to 0  
//02/13/98 - rev 4 - Changed wording in error messages
//05/29/2001 - rev 5 - changed DRC value to 40 to coorespond to latest rule set.
//02/05/03 -rev 0.6 - Changed log filename to xsmasklog
//                  - now handles um designs
//                  - checks to see if part iw wirebond or if doesn't have top soldermask layer
//                  - and skips test in either case. 
//                  -checks for needed files and exits if not found. (tsa)


void exit_program_xs( int instatus)
{
int tmp_status;
char rmfilestr[300];
char chkfilestr[300];
char tofilestr[300];

   tmp_status=instatus;
   if( instatus == 0 )
   {
	   strncpy(rmfilestr,"report",20);  // report/xsmasklog.old
	   strncat(rmfilestr,dirsep,10);
	   strncat(rmfilestr,"xsmasklog.old",30);
	   rm_file(rmfilestr); 
       // rm -rf report/xsmask_bgalog.old
   }
   else
   {
	   strncpy(chkfilestr,"report",20);
	   strncat(chkfilestr,dirsep,10);
	   strncat(chkfilestr,"xsmasklog.old",30);

       if( file_exists( chkfilestr) )   // -r report/xsmasklog.old 
       {
		   strncpy(tofilestr,"report",20);
		   strncat(tofilestr,dirsep,10);
		   strncat(tofilestr,"xsmasklog",30);

		   cp_file(chkfilestr,tofilestr);
		   rm_file(chkfilestr);
          // mv report/xsmasklog.old report/xsmasklog
       }
   }

   rm_file("c4_extract_tmp");
   rm_file("c4_tmp"); 
   rm_file("input.txt");
   system("rm -f extract.log*");
   exit( instatus); 
}



void xsmask_call( )
{
int status;
int has_s0;
char myname[300];
char myfname[300];
char mytype[300];
char PARTNUMBER[300];
char fromfilestr[300];
char tofilestr[300];
char chkfilestr[300];
char systemstr[300];
char openfilestr[300];
char junkstr[300];
char units[300];
char AR[300];
char S0C4[300];
char datestr[300];
char DIFF[300];
char DRC[300];
int C4OFFSET;
int SMOFFSET;
int grepret;

double pad;
double sm;
double arval;
double diffval;
double l01c4val;
double s0c4val;

int mult;
int res;
char tempstr[300];
FILE *inputtxtfile;
FILE *masklogfile;
FILE *controlfile;
FILE *c4tmpfile;
FILE *c4extractfile;
double drcval;
int type_res;
int nf;
int endoffile;
char thisline[300];
char L01C4[300];

if (WINDOWS )
{
	strncpy(dirsep,"\\",10);
}
else
{
	strncpy(dirsep,"/",10);
}

//------------------------------------------------
// save smasklog to recover if program bombs
//------------------------------------------------


strncpy(chkfilestr,"report",30);  // report/xsmasklog
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"xsmasklog",30);

if( file_exists( chkfilestr) )   // -r report/xsmasklog 
{
	strncpy(tofilestr,chkfilestr,120);  // report/xsmasklog.old
    strncat(tofilestr,".old",10);

	cp_file(chkfilestr,tofilestr);
	rm_file(chkfilestr);

  // mv report/xsmasklog report/xsmasklog.old
}

rm_file("input.txt");

//---------------------------------------------------------------
// Set constants for ease of changing in future.
//---------------------------------------------------------------
C4OFFSET=0;   // C4 offset
SMOFFSET=0;   // S0 offset
strncpy(DRC,"40",6);      // Design rule size of S0 to C4 pad  

//---------------------------------------------------
// initialize varibles
//---------------------------------------------------
has_s0=0;     // if = 0 then part does not have S0 layer 
status=0;

//---------------------------------------------------------------
// Check for needed files and exit if not there
//---------------------------------------------------------------
strncpy(chkfilestr,"report",20);
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"makelog",20);

if(  ! (file_exists( chkfilestr) ) )        // -r report/makelog 
{
    printf("FATAL ERROR: report%smakelog does not exist or is not readable\n",dirsep);
    status=1;
    exit_program_xs(status);
}


// PARTNUMBER=`grep "Part Number" report/makelog | cut -d: -f2`  //extracts part number
grepret=sgrep(chkfilestr,"Part Number",100);

if (grepret == 0 )
{
  split( grep_array[0],junkstr,PARTNUMBER,":");

  strncpy(chkfilestr,PARTNUMBER,120);
  strncat(chkfilestr,".mcm",10);
}
else
{
	printf("Unable to find Part Number: string in report/makelog file \n");
	exit(-1);
}

if( ! (file_exists( chkfilestr) ) )  // -r $PARTNUMBER.mcm 
{
    printf("FATAL ERROR: %s.mcm does not exist or is not readable\n",
		         PARTNUMBER);
    status=2;
    exit_program_xs(status);
}
strncpy(chkfilestr,"control",20);  // control/$PARTNUMBER.ctl
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,PARTNUMBER,120);  
strncat(chkfilestr,".ctl",10);

if(! (file_exists( chkfilestr) ) )  //  -r control/$PARTNUMBER.ctl 
{
    printf("FATAL ERROR: control%s%s.ctl does not exist or is not readable\n",
		dirsep,PARTNUMBER);
    status=3;
    exit_program_xs( status);
}


//---------------------------------------------------------------------------
// Check to see if part is wirebond or if has soldermask
// exit program(without error) if is wirebond or does not have soldermask
//--------------------------------------------------------------------------- 
strncpy(fromfilestr,"report",20);  // report/makelog
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"makelog",20);

type_res =chk_wb_call( fromfilestr );

strncpy(openfilestr,"report",20);   // report/xsmasklog
strncat(openfilestr,dirsep,10);
strncat(openfilestr,"xsmasklog",30);

masklogfile=fopen(openfilestr,"w");
if (masklogfile == NULL)
{
	printf("Unable to open the report%sxsmasklog file \n",dirsep);
	exit(-1);
}


// type_res=chk_wb_call( report/makelog );

// type_res=$?

if( type_res == 1 ) // chk_wb.awk returns a 1 if part is wirebond 
{
     printf( "******* Part is wirebond so C4 SM DRC not run *******\n" );
	 
     fprintf(masklogfile,
		 "******* Part is wirebond so C4 SM DRC not run *******\n"); // > report/xsmasklog 
     exit_program_xs(status);
}

controlfile=fopen(chkfilestr,"r");
if (controlfile == FALSE)
{
	printf("Unable to open the file = %s for input \n",chkfilestr);
	exit(-1);
}

endoffile=getline(controlfile,thisline);
  nf=split_line(thisline);

while( endoffile==FALSE)   //  read myname myfname mytype rest
{
  strncpy(myname,str_array[0],120);
  strncpy(myfname,str_array[1],120);
  strncpy(mytype,str_array[2],120);
  
  if( strcmp( mytype,"TSOLDER") == 0 )
  {
      has_s0=1;
  }

  endoffile=getline(controlfile,thisline);
  nf=split_line(thisline);

}  // < control/$PARTNUMBER.ctl

fclose(controlfile);

if ( has_s0 == 0 )
{
     printf( "******* Part does not have S0 layer so C4 SM DRC not run *******\n" );
     fprintf(masklogfile, "******* Part does not have S0 layer so C4 SM DRC not run *******\n" );
	    //> report/xsmasklog
     exit_program_xs(status);
}


//---------------------------------------------------------------
// Extracts Package information
//---------------------------------------------------------------

inputtxtfile=fopen("input.txt","w");
if (inputtxtfile==NULL)
{
	printf("Unable to open the input.txt file for writing \n");
	exit(-1);
}

fprintf(inputtxtfile,"# VIEW:\n");            // >  input.txt
fprintf(inputtxtfile,"FULL_GEOMETRY\n");       // >>  input.txt
fprintf(inputtxtfile,"# VIEW OPTIONS:\n");    // >> input.txt
fprintf(inputtxtfile,"SUBCLASS\n");           // >> input.txt
fprintf(inputtxtfile,"PAD_STACK_NAME\n");     // >> input.txt
fprintf(inputtxtfile,"GRAPHIC_DATA_NAME\n");  // >> input.txt
fprintf(inputtxtfile,"GRAPHIC_DATA_10\n");    // >> input.txt
fprintf(inputtxtfile,"GRAPHIC_DATA_4\n");     // >> input.txt
fprintf(inputtxtfile,"GRAPHIC_DATA_5\n");     // >> input.txt
fprintf(inputtxtfile,"GRAPHIC_DATA_7\n");     //  >> input.txt
printf( "Extracting from %s.mcm\n",PARTNUMBER);

fclose(inputtxtfile);

//---------------------------------------------------------------
// Extracts information on the package and changes output file.
// so it is ready for the next step.
//---------------------------------------------------------------

strncpy(systemstr,"extract -q ",30);
strncat(systemstr,PARTNUMBER,120);
strncat(systemstr,".mcm input >ssed_input",30);

system(systemstr);

//extract -q  $PARTNUMBER.mcm input | sed "s/SOLDERMASK_TOP/S0/g" | \
//sed "s/TOP/L01/g" | sort | uniq > c4_extract_tmp

ssed( "ssed_input","SOLDERMASK_TOP","S0", "ssed_output");
ssed( "ssed_output","TOP","L01","ssed_tmp1");
system("sort ssed_tmp1 | uniq >c4_extract_tmp");
rm_file("ssed_input");
rm_file("ssed_output");
rm_file("ssed_tmp1");


//-----------------------------------------------------------------
// Finds lines in extract file with C4 and writes the size of the 
// C4 and S0 opening to c4_tmp.
//-----------------------------------------------------------------

// gawk 'BEGIN { FS = "!"}

 c4extractfile=fopen("c4_extract_tmp","r");

 if (c4extractfile == NULL)
	{
	 printf("Unable to open the input c4_extract_tmp file \n");
	 exit(-1);
	}

 endoffile=getline(c4extractfile,thisline);
 nf=split_line_seps(thisline,"!");

 while(endoffile==FALSE)
 {
  cv_toupper(str_array[0],tempstr);
  if(strcmp(tempstr,"J")==0)
  {
      cv_toupper(str_array[8],units);      // = toupper($9)

      if (strcmp(units,"MILLIMETERS")==0)
	  {
         mult = 1000;
         res = 0;
      }
      else if ( strcmp(units,"MICRONS")==0)
	  {
         mult = 1;
         res = 0;
      }
      else
	  {
         res = 1;
      }
  }

  if ((strcmp(str_array[1],"L01")==0) && (strcmp(str_array[2],"C4")==0)) 
  {
    //printf ("%s\t", $6*mult)
    pad = atof(str_array[5]) *mult;
  }
  else if ((strcmp(str_array[1],"S0")==0) && (strcmp(str_array[2],"C4")==0) )
  {
    //printf ("%s\n", $6*mult)
    sm = atof(str_array[5])*mult;
  }

  endoffile=getline(c4extractfile,thisline);
  nf=split_line_seps(thisline,"!");
}

fclose(c4extractfile);

c4tmpfile=fopen("c4_tmp","w");

fprintf(c4tmpfile,"%s\t%s\n",pad,sm);  //  ' < c4_extract_tmp > c4_tmp

fclose(c4tmpfile);

//---------------------------------------------------------------
// Sets variables to zero.
//---------------------------------------------------------------

strncpy(L01C4,"0",10);
strncpy(S0C4,"0",10);
strncpy(DIFF,"0",10); // =0;
strncpy(AR,"0",10);

arval=0;
diffval=0;
s0c4val=0;
l01c4val=0;

//-----------------------------------------------------------------
// Determines the size of L01 C4 and S0 C4 opening to check if
// c4solder mask annular ring design rule is meet.  50um+
//-----------------------------------------------------------------

//L01C4=`cut -f1 c4_tmp`- C4OFFSET;
l01c4val=pad-C4OFFSET;
//S0C4=`cut -f2 c4_tmp`+ SMOFFSET;
s0c4val=sm + SMOFFSET;

//DIFF=$S0C4-$L01C4
diffval=s0c4val - l01c4val;
arval=diffval/2;

//AR=DIFF/2;

sprintf(AR,"%f",arval);
sprintf(DIFF,"%f",diffval);
sprintf(L01C4,"%f",l01c4val);
sprintf(S0C4,"%f",s0c4val);

fprintf(masklogfile, "Report created on %s \n",datestr); // > report/xsmasklog
printf("\n");
fprintf(masklogfile,"\n");  //  >> report/xsmasklog
printf( "C4 pad size = %sum finished \n",L01C4);
fprintf(masklogfile, "C4 pad size = %sum finished \n",L01C4); // >> report/xsmasklog
printf( "S0 opening  = %sum finished\n",S0C4);
fprintf(masklogfile, "S0 opening  = %sum finished\n",S0C4); // >> report/xsmasklog
printf( "DELTA       = %sum \n",DIFF);
fprintf(masklogfile, "DELTA       = %sum \n",DIFF); // >> report/xsmasklog
printf("\n");
fprintf(masklogfile,"\n"); // >> report/xsmasklog

diffval=atof(DIFF);
drcval=atof(DRC);

if( diffval < drcval )
{
     fprintf(masklogfile,"\n"); // >> report/xsmasklog
     printf( "******* C4 SM DRC FAILED ******* C4 SM DRC FAILED ******* C4 SM DRC FAILED *******\n"); 
     fprintf(masklogfile,
	 "******* C4 SM DRC FAILED ******* C4 SM DRC FAILED ******* C4 SM DRC FAILED *******\n"); // >> report/xsmasklog
     printf("\n");
     fprintf(masklogfile,"\n");  //   >> report/xsmasklog
     printf("C4 Solder Mask annular ring is %sum, must be 20um+ finished. Change C4 padstack.\n",AR);
     fprintf(masklogfile,
		"C4 Solder Mask annular ring is %sum, must be 20um+ finished. Change C4 padstack.\n",AR); // >> report/xsmasklog
     printf("\n");
     fprintf(masklogfile,"\n"); //  >> report/xsmasklog
     printf("******* C4 SM DRC FAILED ******* C4 SM DRC FAILED ******* C4 SM DRC FAILED *******\n"); 
     fprintf(masklogfile,"******* C4 SM DRC FAILED ******* C4 SM DRC FAILED ******* C4 SM DRC FAILED *******\n"); // >> report/xsmasklog
     printf("\n");
     fprintf(masklogfile,"\n");   // >> report/xsmasklog
}
else
{
     fprintf(masklogfile,"\n");  // >> report/xsmasklog
     printf( "**************** C4 SM DRC PASSED ******************\n");
     fprintf(masklogfile, "**************** C4 SM DRC PASSED ******************\n"); // >> report/xsmasklog
     printf("\n");
     fprintf(masklogfile,"\n"); //  >> report/xsmasklog
     printf( "    C4 Solder Mask annualar ring is %sum.\n",AR); 
     fprintf(masklogfile, "    C4 Solder Mask annualar ring is %sum.\n",AR); // >> report/xsmasklog 
     printf("\n");
     fprintf(masklogfile,"\n");  //  >> report/xsmasklog
     printf( "**************** C4 SM DRC PASSED ******************\n");
     fprintf(masklogfile, "**************** C4 SM DRC PASSED ****************** \n"); // >> report/xsmasklog
     printf("\n");
     fprintf(masklogfile,"\n"); // >> report/xsmasklog
}

fclose(masklogfile);

exit_program_xs(status);

}  // end xsmask_call

/*
int main( int argc, char **argv)
{
char REV[300];

	if (argc != 1)
	{

		printf(" In xsmask, wrong number of arguments \n");
		printf("Usage: xsmask\n");
		exit(-1);
	}
	else
	{
      strncpy(REV,"0.6",10);

      printf( "Running %s %s \n",argv[1],REV);

		xsmask_call( );
	}


}  // end main

 
*/

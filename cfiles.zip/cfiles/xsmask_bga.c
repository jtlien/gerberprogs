#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"

int chk_wb_call( char *wbfilestr);

void parse_bga_call_out( char *wbstr, int smoff , int bgaoff, char *infilestr, char *outfilestr);

//Script checks the BGA solder mask annular ring and writes to report/Xsmasklog file.
//
//Revision History
//02/05/03 -rev 0.2 - Changed log filename to xsmasklog
//                  - now handles um designs
//                  - skips test if part has no bottom soldermask and is not a wirebond part
//                  - checks to see if part if wirebond and checks bga pads on l01 (if part has top soldermask)
//                  - now calls parse_bga.awk to process extracted data.
//                  - checks for needed files and exits if not found. (tsa)

void exit_program_xsbga( int instatus)
{
int tmp_status;
char rmfilestr[300];
char chkfilestr[300];
char tofilestr[300];

   tmp_status=instatus;
   if( instatus == 0 )
   {
	   strncpy(rmfilestr,"report",20);  // report/xsmask_bgalog.old
	   strncat(rmfilestr,dirsep,10);
	   strncat(rmfilestr,"xsmask_bgalog.old",30);
	   rm_file(rmfilestr); 
       // rm -rf report/xsmask_bgalog.old
   }
   else
   {
	   strncpy(chkfilestr,"report",20);
	   strncat(chkfilestr,dirsep,10);
	   strncat(chkfilestr,"xsmask_bgalog.old",30);

       if( file_exists( chkfilestr) )   // -r report/xsmask_bgalog.old 
       {
		   strncpy(tofilestr,"report",20);
		   strncat(tofilestr,dirsep,10);
		   strncat(tofilestr,"xsmask_bgalog",30);

		   cp_file(chkfilestr,tofilestr);
		   rm_file(chkfilestr);
          // mv report/xsmask_bgalog.old report/xsmask_bgalog
       }
   }

   rm_file("bga_extract_tmp");
   rm_file("bga_tmp"); 
   rm_file("input.txt");
   system("rm -f extract.log*");
   exit( instatus); 
}

void xsmask_bga_call( )
{
int status;
int has_s0;
int has_s59;
char myname[300];
char myfname[300];
char mytype[300];
char PARTNUMBER[300];
char fromfilestr[300];
char tofilestr[300];
char chkfilestr[300];
char systemstr[300];
char openfilestr[300];
char junkstr[300];
char AR[300];
char BGA[300];
char S59BGA[300];
char datestr[300];
char DIFF[300];
char DRC[300];
int BGAOFFSET;
int SMOFFSET;
int grepret;

char extractstr[300];
FILE *inputtxtfile;
FILE *masklogfile;
FILE *controlfile;
FILE *bgatmpfile;
double diffval;
double drcval;
int type_res;
int nf;
int endoffile;
char thisline[300];

if (WINDOWS )
{
	strncpy(dirsep,"\\",10);
	strncpy(extractstr,"extracta",30);
}
else
{
	strncpy(dirsep,"/",10);
	strncpy(extractstr,"extract",30);
}

get_date(datestr);

//------------------------------------------------
// save smasklog to recover if program bombs
//------------------------------------------------

strncpy(chkfilestr,"report",30);  // report/xsmask_bgalog
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"xsmask_bgalog",30);

if( file_exists( chkfilestr) )   // -r report/xsmask_bgalog 
{
	strncpy(tofilestr,chkfilestr,120);  // report/xsmask_bgalog.old
    strncat(tofilestr,".old",10);

	cp_file(chkfilestr,tofilestr);
	rm_file(chkfilestr);

  // mv report/xsmask_bgalog report/xsmask_bgalog.old
}

rm_file("input.txt");

rm_file(chkfilestr); // -rf report/Xsmask_bgalog // delete legacy log file

//---------------------------------------------------------------
// Set constants for ease of changing in future.
//---------------------------------------------------------------

BGAOFFSET=0;  // BGA offset
SMOFFSET=0;   // S0 offset
strncpy(DRC,"100",10) ;      // Design rule size of S59 to BGA pad  

//---------------------------------------------------
// initialize varibles
//---------------------------------------------------
has_s0=0;   // if = 0 then part does not have S0 layer
has_s59=0;    // if = 0 then part does not have S59 layer
status=0;

//---------------------------------------------------------------
// Check for needed files and exit if not there
//---------------------------------------------------------------

strncpy(chkfilestr,"report",20);
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,"makelog",20);

if(  ! (file_exists( chkfilestr) ) )        // -r report/makelog 
{
    printf("FATAL ERROR: report%smakelog does not exist or is not readable\n",dirsep);
    status=1;
    exit_program_xsbga(status);
}

//PARTNUMBER=`grep "Part Number" report/makelog | cut -d: -f2`  //extracts part number

grepret = sgrep(chkfilestr,"Part Number",100);

if (grepret == 0 )
{
   split( grep_array[0],junkstr,PARTNUMBER,":");
}
else
{
	printf("Unable to find the Part Number: string in report/makelog file \n");
	exit(-1);
}

strncpy(chkfilestr,PARTNUMBER,120);
strncat(chkfilestr,".mcm",10);

if( ! (file_exists( chkfilestr) ) )  // -r $PARTNUMBER.mcm 
{
    printf("FATAL ERROR: %s.mcm does not exist or is not readable\n",
		         PARTNUMBER);
    status=2;
    exit_program_xsbga(status);
}
strncpy(chkfilestr,"control",20);  // control/$PARTNUMBER.ctl
strncat(chkfilestr,dirsep,10);
strncat(chkfilestr,PARTNUMBER,120);  
strncat(chkfilestr,".ctl",10);

if(! (file_exists( chkfilestr) ) )  //  -r control/$PARTNUMBER.ctl 
{
    printf("FATAL ERROR: control%s%s.ctl does not exist or is not readable\n",
		dirsep,PARTNUMBER);
    status=3;
    exit_program_xsbga( status);
}

//---------------------------------------------------------------------------
// Check to see if part has bottom soldermask
// exit program(without error) does not have bottom soldermask
//---------------------------------------------------------------------------

controlfile=fopen(chkfilestr,"r");
if (controlfile == FALSE)
{
	printf("Unable to open the file = %s for input \n",chkfilestr);
	exit(-1);
}

endoffile=getline(controlfile,thisline);
  nf=split_line(thisline);

while( endoffile==FALSE)   //  read myname myfname mytype rest
{
  strncpy(myname,str_array[0],120);
  strncpy(myfname,str_array[1],120);
  strncpy(mytype,str_array[2],120);
  

  if(strcmp(mytype,"BSOLDER")==0)
  {
      has_s59=1;
  }
  if(strcmp(mytype,"TSOLDER" )==0)
  {
      has_s0=1;
  }
  endoffile=getline(controlfile,thisline);
  nf=split_line(thisline);

}      // < control/$PARTNUMBER.ctl

fclose(controlfile);


//---------------------------------------------------------------------------
// Check to see if part is wirebond.
// Result to be used later in program. Need to use L01 instead of BOTTOM
// for BGA check
//---------------------------------------------------------------------------


strncpy(fromfilestr,"report",20);  // report/makelog
strncat(fromfilestr,dirsep,10);
strncat(fromfilestr,"makelog",20);

type_res =chk_wb_call( fromfilestr );

strncpy(openfilestr,"report",20);
strncat(openfilestr,dirsep,10);
strncat(openfilestr,"xsmask_bgalog",30);

masklogfile=fopen(openfilestr,"w");
if (masklogfile == NULL)
{
	printf("Unable to open the report%sxsmask_bgalog file \n",dirsep);
	exit(-1);
}

// type_res=$?

if ((type_res == 1) && (has_s0 == 0))
{
      printf("******* Part is wirebond and does not have S0 layer so BGA SM DRC not run *******\n");
      fprintf(masklogfile,
		  "******* Part is wirebond and does not have S0 layer so BGA SM DRC not run *******\n");
	           
	  
      exit_program_xsbga(status);
}   

if ((type_res != 1) && ( has_s59 == 0 ))
{
     printf("******* Part does not have S59 layer so BGA SM DRC not run *******\n");
     fprintf(masklogfile,
		 "******* Part does not have S59 layer so BGA SM DRC not run *******\n"); //  > report/xsmask_bgalog
     exit_program_xsbga(status);
}

//---------------------------------------------------------------
// Extracts Package information
//---------------------------------------------------------------

inputtxtfile=fopen("input.txt","w");
if (inputtxtfile==NULL)
{
	printf("Unable to open the input.txt file for writing \n");
	exit(-1);
}

printf("\n");
fprintf(inputtxtfile,"# VIEW:\n");    //  >  input.txt
fprintf(inputtxtfile,"FULL_GEOMETRY\n"); //  >>  input.txt
fprintf(inputtxtfile,"# VIEW OPTIONS:\n"); // >> input.txt
fprintf(inputtxtfile,"SUBCLASS \n");  //  >> input.txt
fprintf(inputtxtfile,"PAD_STACK_NAME\n");  // >> input.txt
fprintf(inputtxtfile,"GRAPHIC_DATA_NAME\n");  // >> input.txt
fprintf(inputtxtfile,"GRAPHIC_DATA_10\n"); //  >> input.txt
fprintf(inputtxtfile,"GRAPHIC_DATA_4\n"); // >> input.txt
fprintf(inputtxtfile,"GRAPHIC_DATA_5\n");   // >> input.txt
fprintf(inputtxtfile,"GRAPHIC_DATA_7\n");  //  >> input.txt

fclose(inputtxtfile);

printf("Extracting from %s.mcm \n",PARTNUMBER);

//---------------------------------------------------------------
// Extracts information on the package and changes output file.
// so it is ready for the next step.
//---------------------------------------------------------------

strncpy(systemstr,extractstr,120);
strncat(systemstr," -q ",30);
strncat(systemstr,PARTNUMBER,120);
strncat(systemstr,".mcm input >ssed_input",30);

system(systemstr);

// extract -q  $PARTNUMBER.mcm input | sed "s/SOLDERMASK_BOTTOM/S59/g" | sed "s/SOLDERMASK_TOP/S0/g" | sort | uniq > bga_extract_tmp

ssed( "ssed_input","SOLDERMASK_BOTTOM","S59", "ssed_output");
ssed( "ssed_output","SOLDERMASK_TOP","S0","ssed_tmp1");
system("sort ssed_tmp1 | uniq >bga_extract_tmp");
rm_file("ssed_input");
rm_file("ssed_output");
rm_file("ssed_tmp1");

//---------------------------------------------------------------
// Sets variables to zero.
//---------------------------------------------------------------
strncpy(BGA,"0",10);
strncpy(S59BGA,"0",10);
strncpy(DIFF,"0",10);
strncpy(AR,"0",10);

//----------------------------------------------------------------
// Finds lines in extract file with BGA and writes the size of the 
// BGA and S59 opening to bga_tmp.
//-----------------------------------------------------------------
if(  type_res == 1 ) // chk_wb.awk returns a 1 if part is wirebond
{
    parse_bga_call_out( "wb", SMOFFSET , BGAOFFSET, "bga_extract_tmp" ,"bga_tmp"  );

}
else
{
    parse_bga_call_out( "scm", SMOFFSET, BGAOFFSET, "bga_extract_tmp", "bga_tmp");
		
}

bgatmpfile=fopen("bga_tmp","r");
if (bgatmpfile == FALSE)
{
	printf("Unable to open the bga_tmp file for input \n");
	exit(-1);
}
else
{
	endoffile = getline(bgatmpfile,thisline);

    nf=split_line(thisline);
   
	strncpy(BGA,str_array[0],120);
	strncpy(S59BGA,str_array[1],120);
	strncpy(DIFF,str_array[2],120);
	strncpy(AR,str_array[3],120);
}


//read BGA S59BGA DIFF AR< bga_tmp


fclose(bgatmpfile);


fprintf(masklogfile, "Report created on %s.\n",datestr);  // > report/xsmask_bgalog
printf("\n");
fprintf(masklogfile,"\n");   // >> report/xsmask_bgalog
printf("BGA pad size = %sum finished\n",BGA);
fprintf(masklogfile,"BGA pad size = %sum finished \n",BGA); //  >> report/xsmask_bgalog
printf("SM  opening  = %sum finished \n",S59BGA);
fprintf(masklogfile,"SM  opening  = %sum finished \n",S59BGA); //  >> report/xsmask_bgalog
printf("DELTA        = %sum \n",DIFF);
fprintf(masklogfile,"DELTA        = %sum \n",DIFF); //  >> report/xsmask_bgalog
printf("\n");
fprintf(masklogfile,"\n"); // >> report/xsmask_bgalog

diffval=atof(DIFF);
drcval=atof(DRC);

if( diffval <  drcval )
{	
   fprintf(masklogfile,"\n");  // >> report/xsmask_bgalog
   printf("******* BGA SM DRC FAILED ******* BGA SM DRC FAILED ******* BGA SM DRC FAILED *******\n"); 
   fprintf(masklogfile,
	 "******* BGA SM DRC FAILED ******* BGA SM DRC FAILED ******* BGA SM DRC FAILED *******\n"); //  >> report/xsmask_bgalog
   printf("\n");
   fprintf(masklogfile,"\n"); //  >> report/xsmask_bgalog
   printf(" BGA Solder Mask annular ring is %sum, must be 50um+ finished. Change BGA padstack.\n",AR);
   fprintf(masklogfile,
   " BGA Solder Mask annular ring is %sum, must be 50um+ finished. Change BGA padstack.\n",AR); // >> report/xsmask_bgalog
   printf("\n");
   fprintf(masklogfile,"\n"); // >> report/xsmask_bgalog
   printf("******* BGA SM DRC FAILED ******* BGA SM DRC FAILED ******* BGA SM DRC FAILED *******\n");
   fprintf(masklogfile,
	   "******* BGA SM DRC FAILED ******* BGA SM DRC FAILED ******* BGA SM DRC FAILED *******\n"); 
   printf("\n");
   fprintf(masklogfile,"\n"); // >> report/xsmask_bgalog
}
else
{
   fprintf(masklogfile,"\n");  // >> report/xsmask_bgalog
   printf("**************** BGA SM DRC PASSED ******************\n");
   fprintf(masklogfile,"**************** BGA SM DRC PASSED ******************\n"); // >> report/xsmask_bgalog
   printf("\n");
   fprintf(masklogfile,"\n");  // >> report/xsmask_bgalog
   printf("    BGA Solder Mask annualar ring is %sum.\n",AR);
   fprintf(masklogfile,"    BGA Solder Mask annualar ring is %sum.\n",AR);   // >> report/xsmask_bgalog 
   printf("\n");
   fprintf(masklogfile,"\n");   // >> report/xsmask_bgalog
   printf("**************** BGA SM DRC PASSED ******************\n");
   fprintf(masklogfile,"**************** BGA SM DRC PASSED ******************\n"); // >> report/xsmask_bgalog
   printf("\n");

   fprintf(masklogfile,"\n"); // >> report/xsmask_bgalog
}
fclose(masklogfile);

exit_program_xsbga(status);


}  // end xsmask_bga_call

/*
int main( int argc, char **argv)
{
char REV[300];

	if (argc != 1)
	{

		printf(" In xsmask_bga, wrong number of arguments \n");
		printf("Usage: xsmask_bga \n");
		exit(-1);
	}
	else
	{
      strncpy(REV,"0.2",10);

      printf( "Running %s %s \n",argv[1],REV);

		xsmask_bga_call( );
	}


}  // end main
*/

  
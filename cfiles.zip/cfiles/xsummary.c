
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include "dirent.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0

#include "utilprogs.h"


//int chk_wb_call(char *infilestr);
int makehdr_call();
void getoffset_call_out( char *infilestr, char *outfilestr);
void via_extract_call( );
void sumlength_extract_call( );
void ecl_prop_extract_call( );
int get_wbcnt_call_count( char *infilestr );
int get_wb_viacnt_call_count( char *infilestr, int select_val);
void formatviagbr1_call_out( char *infilestr, char *outfilestr);
void mod_top_bot2_call_out( char *infilestr, char *infile2str, char *outfilestr);
void summary_get_dist_call_append(double xsize, double ysize, char *infile1,
								  char *infile2, char *appendfilestr);

//
//Script produces output for updating 7 layer scm summary.txt file.
//09/26/97 - wlee
//
//Revision History
//09/26/97 - rev 1 - initial release
//09/29/97 - rev 2 - Changed STIFFSIZE to grep for "Stiff Opening:"
//                   in report/makelog.
//02/12/98 - rev 3 - changed method variable DESRULES was defined
//04/02/98 - rev 4 - added C4 / BGA pitch information
//11/15/02 - rev 5 - modified program completey. Simplifed number of sub-programs
//                   removed part information and stiffener information.
//                   adds more complete line length information  - tsa

//02/04/03 - rev 5.1 - now calls makehdr to create file header information
//                   - deletes temporary file "tmpsize"- tsa (comments added 3/3/03)

//03/03/03 - rev 5.2 - converts report/makelog to unix format
//                   - converts control/partnumber.ctl to unix format
//                   - converts artwork/outline.art to unix format 


void grep_cut( char *infilestr, char *srchstr, char *splitstr, char *resstr)
{
char junkstr[100];
int grepret;

	grepret = sgrep( infilestr, srchstr,100);
	if (grepret == 0 )
	{
	  split(grep_array[0], junkstr, resstr, splitstr);
	}
	else
	{
		strncpy(resstr,"",10);
		printf("Unable to find the %s: string in the file %s \n", srchstr, infilestr);
		exit(-1);
	}

}

void exit_program( int status)
{
int tmp_status;

   tmp_status= status;
   if ( status == 0 )
   {
       cat_files( "proto.hdr", "summary_tmp", "summary.txt");
       //un2dos summary.tmp > summary.txt
       printf("summary.txt has been updated \n");
       rm_file( "summary_myold.txt");
   }
   else
   {
       printf( "summary.txt has NOT been updated\n");
       if ( file_exists( "summary_myold.txt" ) )
       {
           cp_file("summary_myold.txt", "summary.txt");
		   rm_file("summary_myold.txt");
       }
   }

   rm_file("summary_tmp");
   rm_file("sum_length.txt");
   rm_file("proto.hdr");
   rm_file("sumlength_tmp"); 
   rm_file("sumlength_tmp2");
   system("rm  extract.log*");
   rm_file("len.tmp1");
   rm_file("len.tmp2");
   rm_file("len.tmp3");
   rm_file("len.tmp4");
   rm_file("len.tmp5");
   rm_file("len.tmp6 ");
   rm_file("viacount_tmp"); 
   rm_file("viacount_tmp2");
   rm_file("offval");
   rm_file("offval1"); 
   rm_file("ecl_prop.txt");
   rm_file("summary.tmp");
   rm_file("tmpsize");
   exit(status);              //$1 
}

void xsummary_call( )
{
int status;
char PROGNAME[300];
char PARTNUMBER[300];
char layers[300];
char stackup[300];
char viatype[300];
char part_type[300];
char die_con[300];
char chkfilestr[300];
char chkfile1str[300];
char comparestr[300];
char REV[40];
FILE *protohdrfile;
FILE *controlfile;
FILE *partsizefile;
FILE *summaryfile;

char BODYSIZE[300];
char DESRULES[300];

char tempstr[300];

char name[200];
char fname[200];
char lyr_type[200];
char DIESIZE[300];
char DIEPAD[300];
char DIEPITCH[300];
char PADPITCH[300];
char BGAPITCH[300];
char DIE[300];
char RESISTOR2[300];
char controlfilestr[300];
char fromfilestr[300];
int RESISTOR1;
int SENSE;
char TYPE[300];
char B_SIZE[300];
char mlog_xsize_str[300];
char mlog_ysize_str[300];

double x_size;
double y_size;
double mlog_xsize;
double mlog_ysize;
int endoffile;
int nf;
char thisline[300];
int C4COUNT;
int BGACOUNT;
int hdr_res;
//int type_res;
int tmpcnt;
int tmpcnt1;
int debug;
int jj;
int tmp_count;
int wire_count;
int web_count;
int die_count;

     debug = 0;

//PROGNAME=${0##*/}

strncpy(PROGNAME,"xsummary",30);

strncpy(REV,"5.2",10);

printf( "Running %s %s\n",PROGNAME,REV);


status=0;
SENSE=0;
RESISTOR1=0;


//LIBPATH="/usr/local/library"

if ( file_exists( "summary.txt" ) )
{
    cp_file( "summary.txt", "summary_myold.txt");
	rm_file( "summary.txt");
}

if ( ( ! file_exists("report/makelog") ) || ( ! file_is_readable("report/makelog") ))
{
    printf("FATAL ERROR: report/makelog does not exist or is not readable\n");
    status=1;
    exit_program(status);
}

//dos2ux report/makelog > report/makelog.tmp
//mv  report/makelog.tmp report/makelog


if (( ! file_exists( "artwork/outline.art" ) ) || ( ! file_is_readable( "artwork/outline.art" )) )
{
    printf("FATAL ERROR: artwork/outline.art does not exist or is not readable\n");
    status=2;
    exit_program(status);
}

//dos2ux artwork/outline.art > artwork/outline.art.tmp
//mv artwork/outline.art.tmp artwork/outline.art

  strncpy(PARTNUMBER,"",10);
  strncpy(layers,"",10);
  strncpy(stackup,"",10);
  strncpy(viatype,"",10);
  strncpy(part_type,"",10);
  strncpy(die_con,"",10);

//PARTNUMBER=`grep "Part Number" report/makelog | cut -d: -f2`  //extracts part number
 
  grep_cut("report/makelog","Part Number",":",PARTNUMBER);

  if (debug) { printf("PARTNUMBER = %s \n",PARTNUMBER ); }

//layers=`grep "Layers" report/makelog | cut -d: -f2`

  grep_cut("report/makelog","Layers",":",layers);

  if (debug) { printf("layers = %s \n",layers ); }

//stackup=`grep "Stack-up" report/makelog | cut -d: -f2`

  grep_cut("report/makelog","Stack-up",":",stackup);

  if (debug) { printf("stackup = %s \n",stackup); }

// viatype=`grep "Via combination" report/makelog | cut -d: -f2`

  grep_cut("report/makelog","Via combination",":",viatype);

 if (debug) { printf("viatype = %s \n",viatype); }

//part_type=`grep "Part Type" report/makelog | cut -d: -f2`

  grep_cut("report/makelog","Part Type",":",part_type);

  if (debug) { printf("part_type = %s \n",part_type); }

//die_con=`grep "Die Connection" report/makelog | cut -d: -f2`

 grep_cut("report/makelog","Die Connection",":",die_con);

 if (debug) { printf("die_con = %s \n",die_con); }

rm_file("summary_tmp");
rm_file("sum_length.txt"); 
rm_file("sumlength_tmp");

strncpy( chkfilestr,PARTNUMBER,120);  // $PARTNUMBER.mcm
strncat( chkfilestr,".mcm",10);

if ( (! file_exists(chkfilestr )) || ( ! file_is_readable(chkfilestr)) )
{
    printf( "FATAL ERROR: %s.mcm does not exist or is not readable\n",PARTNUMBER);
    status=3;
    exit_program(status);
}

strncpy( chkfilestr,"control/",30);   // control/$PARTNUMBER.ctl
strncat( chkfilestr,PARTNUMBER,120);
strncat( chkfilestr,".ctl",10);

if ( (! file_exists( chkfilestr ) ) || ( ! file_is_readable( chkfilestr) ) )
{
    printf("FATAL ERROR: control/%s.ctl does not exist or is not readable\n",PARTNUMBER);
    status=4;
    exit_program(status);
}

//dos2ux control/$PARTNUMBER.ctl > control/$PARTNUMBER.ctl.tmp
//mv control/$PARTNUMBER.ctl.tmp control/$PARTNUMBER.ctl

//typeset -u part_type

 strncpy(tempstr,part_type,120);
 cv_toupper(tempstr,part_type);

//typeset -u die_con

  strncpy(tempstr,die_con,120);
 cv_toupper(tempstr,die_con);

//--------------------------------------------------------------------
// set up header information
//--------------------------------------------------------------------
hdr_res = makehdr_call();       // update the header information.

//hdr_res=$?

if( hdr_res != 0 )
{
    printf("FATAL ERROR: unable to create header information\n");
    status=5;
    exit_program(status);
}

protohdrfile=fopen("proto.hdr","a");
if ( protohdrfile==NULL)
{
  printf("Unable to open the proto.hdr file for append \n");
  exit(-1);
}
else
{
fprintf(protohdrfile, "Stackup: \n"); // >> proto.hdr
fprintf(protohdrfile,"%s-layer %s %s %s %s  \n",
		layers,stackup, viatype, part_type , die_con ); // >> proto.hdr
}
fclose(protohdrfile);

//--------------------------------------------------------------------
// check to see if part is a wirebond
//--------------------------------------------------------------------
//type_res=chk_wb_call( "report/makelog");    
               // removed chk_wb_call 9/6/06  type_res is not used anywhere
//type_res=$?


//--------------------------------------------------------------------
// get part size
//--------------------------------------------------------------------
getoffset_call_out( "artwork/outline.art","offval"); // > offval
//formatsize partsize > tmpsize
//read x_size y_size < tmpsize

partsizefile=fopen("partsize","r");

strncpy(BODYSIZE,"",10);

if (partsizefile==NULL)
{
	printf("Unable to open the partsize file for reading \n");
	exit(-1);
}
else
{
	endoffile=getline(partsizefile,thisline);

	nf=split_line(thisline);
	if (nf > 1)
	{
 	 x_size = atof(str_array[0]);
	 y_size = atof(str_array[1]);
	}
	else
	{
		printf("Problems with format for partsize file \n");
		exit(-1);
	}

    x_size = x_size / 10000.0;
	y_size = y_size / 10000.0;

     _snprintf(BODYSIZE,200,"%fX%f",x_size,y_size);
}

fclose(partsizefile);

//--------------------------------------------------------------------
// Sets variables to zero.
// --------------------------------------------------------------------
C4COUNT=0;
BGACOUNT=0;

//--------------------------------------------------------------------
//Assigns the variables a value.
//--------------------------------------------------------------------
via_extract_call();

sumlength_extract_call();
    
ecl_prop_extract_call();
 
  strncpy(DESRULES,"",10);
  strncpy(B_SIZE,"",10);
  strncpy(DIESIZE,"",10);
  strncpy(BGAPITCH,"",10);
  strncpy(PADPITCH,"",10);

//C4COUNT=`grep -i C4 viacount_tmp |grep  -c -i -v "fid"`

  tmp_count=0;

  grep_ignore_count("viacount_tmp","C4",&tmp_count);  // look for lines with C4, ignore case

  C4COUNT = 0;
  for(jj=0; jj < tmp_count; jj += 1)
  {
	  cv_toupper( grep_array[jj],comparestr);         // do not count lines with FID

	  if (strstr("FID", comparestr) == NULL)  // no fid found
	  {
		  C4COUNT += 1;
	  }

  }


  if (debug) { printf("C4COUNT = %d \n",C4COUNT); }

// BGACOUNT=`grep -i BGA viacount_tmp |grep  -c -i -v fid ` 

  BGACOUNT=0;
  grep_ignore_count("viacount_tmp","BGA", &tmp_count);

  for(jj=0; jj < tmp_count; jj += 1)
  {
	  cv_toupper( grep_array[jj],comparestr);         // do not count lines with FID

	  if (strstr("FID", comparestr) == NULL)  // no fid found
	  {
		  BGACOUNT += 1;
	  }
  }

  if (debug) { printf("BGACOUNT = %d \n",BGACOUNT); }

//DESRULES=`grep "Rule Set:" report/makelog |  cut -d: -f2`

 grep_cut("report/makelog","Rule Set",":",DESRULES);

 if (debug) { printf("DESRULES = %s \n",DESRULES); }

//B_SIZE=`grep "Body Size:" report/makelog | cut -d: -f2`

  grep_cut("report/makelog","Body Size",":",B_SIZE);

  if (debug) { printf("B_SIZE = %s \n",B_SIZE); }

// DIESIZE=`grep "Die Size:" report/makelog | cut -d: -f2`

  grep_cut("report/makelog","Die Size",":",DIESIZE);

  if (debug) { printf("DIESIZE = %s \n",DIESIZE); }

// PADPITCH=`grep "Pad Pitch" report/makelog | cut -d: -f2`

  grep_cut("report/makelog","Pad Pitch",":",PADPITCH);

  if (debug) { printf("PADPITCH = %s \n",PADPITCH); }

//BGAPITCH=`grep "BGA Pitch" report/makelog | cut -d: -f2`

 grep_cut("report/makelog","BGA Pitch",":",BGAPITCH);

  if (debug) { printf("BGAPITCH = %s \n",BGAPITCH); }

//mlog_xsize=${B_SIZE%X*}

  split(B_SIZE,mlog_xsize_str,mlog_ysize_str,"X");

  mlog_xsize=atof( mlog_xsize_str);
  mlog_ysize=atof( mlog_ysize_str);

  if (debug) { printf("mlog_xsize = %f mlog_ysize = %f \n",mlog_xsize,mlog_ysize); }

//mlog_ysize=${B_SIZE#*X}

if (( mlog_xsize != x_size ) || ( mlog_ysize != y_size ))
{
    printf("makelog (x,y)  %f,%f \n",mlog_xsize,mlog_ysize );

    printf("outline (x,y)  %f,%f \n", x_size, y_size );
    printf("FATAL ERROR: part size from outline.art does not match part size in makelog\n");
    status=4;
    exit_program(status);
}

summaryfile=fopen("summary_tmp","w");

if (summaryfile==NULL)
{
	printf("Unable to open the summary_tmp file for writing \n");
	exit(-1);
}

//--------------------------------------------------------------------
//Creates a tmp file (summary_tmp) that is formatted for the
//summary.txt file.
//--------------------------------------------------------------------

RESISTOR1=0;
SENSE=0;

if ( strcmp(part_type,"WLBI" ) == 0)
{ 
   if ( ! file_exists("report/dangling_lines.log" ) )
   {
      printf( "FATAL ERROR: report/dangling_lines.log does not exist or is not readable\n");
      status=5;
      exit_program(status);
   }

  // RESISTOR1=`grep "R0" report/dangling_lines.log | wc -l'

     grep_counter("report/dangling_lines.log","R0",&RESISTOR1);

	 if (debug) { printf("RESISTOR1 = %d \n", RESISTOR1); }

  // SENSE=`grep "L02_STRAP" report/dangling_lines.log | wc -l`

     grep_counter("report/dangling_lines.log","L02_STRAP",&SENSE);

     if (debug) { printf("SENSE = %d \n", SENSE); }

   // RESISTOR2=`grep "Resistor Count" report/makelog | cut -d: -f2`

     grep_cut("report/makelog","Resistor Count",":",RESISTOR2);

   // TYPE=`grep "Customer" report/makelog | cut -d: -f2`

     grep_cut("report/makelog","Customer",":",TYPE);

   // DIE=`grep "Die Count" report/makelog | cut -d: -f2`

     grep_cut("report/makelog","Die Count",":",DIE);

   // DIEPAD=`grep "Die Pad Count" report/makelog | cut -d: -f2`

     grep_cut("report/makelog","Die Pad Count",":",DIEPAD);

   // DIEPITCH=`grep "Pad Pitch" report/makelog | cut -d: -f2`

     grep_cut("report/makelog","Pad Pitch",":",DIEPITCH);

   // DIESIZE=`grep "Die Size" report/makelog | cut -d: -f2`

    grep_cut("report/makelog","Die Size",":",DIESIZE);

   fprintf(summaryfile, "Mechanical:\n" );
   fprintf(summaryfile, "Inferno Body Size  = %s\n",BODYSIZE);
   fprintf(summaryfile, "\n");
   fprintf(summaryfile, "Die Information:\n"  );
   fprintf(summaryfile, "Die Count: = %s\n",DIE);
   fprintf(summaryfile, "Die Pads:  = %s\n",DIEPAD); 
   fprintf(summaryfile, "Die Pitch: = %s\n",DIEPITCH);
   fprintf(summaryfile, "Die Size:  = %s\n",DIESIZE);
   fprintf(summaryfile, "\n");
   fprintf(summaryfile, "\n");
   fprintf(summaryfile, "\n");
   fprintf(summaryfile, "Resistor Count\n" ); 
   fprintf(summaryfile, "%d\n",RESISTOR1 );
   fprintf(summaryfile, "\n");
   fprintf(summaryfile, "SENSE STRAP Count\n"); 
   fprintf(summaryfile, "%d\n",SENSE );
   fprintf(summaryfile, "\n");

}
else
{
   fprintf(summaryfile, "\n");
   fprintf(summaryfile, "Mechanical:\n" );
   fprintf(summaryfile,"Body Size  = %s\n",BODYSIZE);
   fprintf(summaryfile, "Die Size   = %s\n",DIESIZE);
   fprintf(summaryfile, "\n");
   fprintf(summaryfile, "BGA:\n");   
   fprintf(summaryfile, "Pitch = %s mm \n",BGAPITCH);
   fprintf(summaryfile, "Pads  = %d\n",BGACOUNT); 
   fprintf(summaryfile, "\n");

   if ( strcmp(die_con,"WIREBOND"  )==0)
   {
      fprintf(summaryfile, "WireBond:\n" );
      fprintf(summaryfile, "Pitch = %s mm\n",PADPITCH);
      wire_count=get_wbcnt_call_count( "sumlength_tmp");
	  fprintf(summaryfile,  "Wires = %d \n",wire_count);

      web_count =get_wb_viacnt_call_count( "viacount_tmp", 0 ); // >> summary_tmp
	  fprintf(summaryfile,  "Bond Fingers = %d \n", web_count);

	  die_count =get_wb_viacnt_call_count( "viacount_tmp", 1 );
	  fprintf(summaryfile,  "Die Pads = %d \n",die_count);
   }
   else
   {
      fprintf(summaryfile, "C4:\n" );
      fprintf(summaryfile, "Pitch = %f mm\n",PADPITCH);
      fprintf(summaryfile, "Pads  = %d\n",C4COUNT);  
   }
}
fprintf(summaryfile, "\nVia Usage:\n" );

strncpy(controlfilestr,"control/",15);
strncat(controlfilestr,PARTNUMBER,120);
strncat(controlfilestr,".ctl",10);

controlfile=fopen(controlfilestr,"r");
if ( controlfile==NULL)
{
	printf("Unable to open the control/%s.ctl file for reading \n",PARTNUMBER);
	exit(-1);
}

endoffile=getline(controlfile,thisline);
  nf=split_line(thisline);

printf("Reading  control files = %s \n",controlfilestr);

while(endoffile==FALSE) // read  name fname lyr_type rest
{

 if ( nf > 2 )
 {
  strncpy(name,str_array[0],120);
  strncpy(fname,str_array[1],120);
  strncpy(lyr_type,str_array[2],120);
 
   if (( strcmp(lyr_type,"BLINDOUT" )==0) ||
	  ( strcmp(lyr_type,"BLINDOUT2")==0) || 
	  ( strcmp(lyr_type,"BLINDIN" )==0)  || 
	  ( strcmp(lyr_type,"BURIED" ) ==0 ) ||
	  ( strcmp(lyr_type,"THRU" )==0 ) )
   {
	 strncpy(chkfilestr,"pre-bias/",20);  // pre_bias/$fname
	 strncat(chkfilestr,fname,120);

     strncpy(chkfile1str,"artwork/",20);  // artwork/$fname
	 strncat(chkfile1str,fname,120);

     if( ( ! file_exists( chkfilestr) ) || ( ! file_exists( chkfile1str ) ) )
     {
         printf("FATAL ERROR: either pre-bias/%s or \n",fname);
		 printf("artwork/%s does not exist or is not readable \n",fname);
         status=6;
         exit_program( status);
     }
     
     //tmpcnt=`formatviagbr1 pre-bias/$fname | wc -l`
	 formatviagbr1_call_out(chkfilestr,"tmpviagbr");
	 tmpcnt=count_lines("tmpviagbr");
	 rm_file("tmpviagbr");

     //tmpcnt1=`formatviagbr1 artwork/$fname | wc -l`
	 formatviagbr1_call_out(chkfile1str,"tmpviagbr");
	 tmpcnt1=count_lines("tmpviagbr");
	 rm_file("tmpviagbr");

     if ( tmpcnt != tmpcnt1 )
     {
        printf("FATAL ERROR: pre-bias/%s via count does not equal artwork/%s via count\n",
			fname,fname);
        status=7;
		exit_program(status);
     }
     //typeset -u name

      strncpy(tempstr,name,120);
	  cv_toupper(tempstr,name);

     fprintf(summaryfile,"%s = %d \n",name,tmpcnt); // >> summary_tmp
   }
   if ( strcmp(lyr_type,"DRILL" )==0 )
   {
	   strncpy(chkfilestr,"pre-bias/",30);  // pre-bias/$fname
	   strncat(chkfilestr,fname,120);

      if ( ! file_exists( chkfilestr) ) //     -r pre-bias/$fname )
      {
         printf("FATAL ERROR: pre-bias/%s or artwork/%s does not exist or is not readable\n",
			 fname,fname);
         status=8;
         exit_program(status);
      }
      //tmpcnt=`grep -c  -E  "G36|D03" pre-bias/$fname`
	  tmpcnt = 0;
	  grep_count2(chkfilestr,"G36","D03", &tmpcnt);    // get all lines with G36 or D03 into grep_array

      //typeset -u name
	  strncpy(tempstr,name,120);
	  cv_toupper(tempstr,name);

      fprintf(summaryfile, "%s = %s \n" , name,tmpcnt); // >> summary_tmp
   }

 }
  endoffile=getline(controlfile,thisline);
  nf=split_line(thisline);
}

fclose(controlfile);

//done < control/$PARTNUMBER.ctl

fprintf(summaryfile,"\n"); //  summary_tmp
fprintf(summaryfile, "Initial Design Rules:\n"); 
fprintf(summaryfile,"%s\n", DESRULES); //  >> summary_tmp

fprintf(summaryfile, "\nMetal Length:\n"); // >> summary_tmp 

//metal length code goes here.
strncpy(fromfilestr,"control/",15);
strncat(fromfilestr,PARTNUMBER,40);
strncat(fromfilestr,".ctl",10);

mod_top_bot2_call_out(fromfilestr , "sumlength_tmp","sumlength_tmp2");
summary_get_dist_call_append(x_size,y_size,"ecl_prop.txt",  "sumlength_tmp2","summary_tmp");

fclose(summaryfile);

exit_program(status);


}  // end xsummary_call

/*
void main( int argc, char **argv)
{

	if (argc != 1 )
	{
		printf("xsummary takes no arguments \n");
		exit(-1);
	}
	else
	{
		xsummary_call();
	}

}   // end main

*/





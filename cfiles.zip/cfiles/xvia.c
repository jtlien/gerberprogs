#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <process.h>

#include "dirent.h"
#include "utilprogs.h"

#define NULLCHAR 0
#define TRUE 1
#define FALSE 0
#define WINDOWS 1


// Program to convert input via gerber files (.l) to
// laser files (.dxf)
//
// Programmer Ted Ammann
// Utilizes splitvias written by Dave Hanson
// Utilizes gbr2acad from Artwork Conversion Software Inc.

// Revision history
// Rev 1.0  released to users on 6/23/97
// Rev 2.0  released to users on 2/28/98
//    now calls splitvia 2.0 which implements a faster
//    comparison process

// Rev 2.1 released to users 9/8/98
//    changes layer type from "BLIND" to "BLINDOUT" | "BLINDIN"

// Rev 2.2 released to users 3/22/00
//    now calls splitvia2.1- it adss check to insure core relief 
//    count matches non-core via count.

// Rev 2.3 released to users 8/30/01
// Adds support for BLINDOUT2 layer for VIP designs.

// Rev 2.4 released to users 12/12/03
// Fixes bug that gives a false error when no bureid or thru vias are
// in the control file.

int splitvia2_call( char *corefilestr, char *lfilestr);

char thisline[200];
char str_array[120][120];
int nf;
int endoffile;
FILE *file1;
FILE *apt1file;
FILE *aptfile;
FILE *jfile;

char apt1filestr[300];
char aptfilestr[300];
char file1str[300];
char scmfilestr[300];
char mfgfilestr[300];
char controlfilestr[300];
char pwd_str[300];
char basestr[200];
char basestrup[200];
char extstr[200];
char jobfilestr[300];
char tstr[200];
char aptfilestr[300];
char doutfilestr[300];
char execfilestr[300];
char commandstr[1000];

int flag;
int kk;

char example_str[120];
char usage_str[120];

char name_str[120];
char myfile_str[120];
char type_str[120];
char mfg_str[120];
char photo_str[120];
char layer_str[120];
char maskrev_str[120];
char pcmlayer_str[120];

char firststr[200];
char revstr[200];
char progname[200];
char fname[200];
char fnamestr[200];
char lfile_list[500][120];
int lfile_count;
int i;

//
// directly copy  a file from dos form to unix
//

void cp_dostou_file(  char *infile, char *outfile)
{
char buf[1024];
FILE *f_from;
FILE *f_to;


    /* copy source file to target file, line by line. */

/* open the source and the target files. */
    f_from = fopen(infile, "r");
    if (!f_from) {
	fprintf(stderr, "Cannot open source file: %s",infile);
	perror("");
	exit(1);
    }
    f_to = fopen(outfile, "w+");
    if (!f_to) {
	fprintf(stderr, "Cannot open target file: %s ",outfile);
	perror("");
	exit(1);
    }

/* copy source file to target file, line by line. */

    while (fgets(buf, 512, f_from)) 
	{
	 if (fputs(buf, f_to) == EOF)
	 {  /* error writing data */
	    fprintf(stderr, "Error writing to target file: ");
	    perror("");
	    exit(1);
	 }
    }
   fclose(f_from);
   fclose(f_to);
	
}  // cp_dostou_file



void processlayer( char *infile, char *in_ext)
{
char vxxfile[200];
char dotlfile[200];
char corefile[200];
int split_result;

      printf( "Processing  %s%s.l ... \n",infile,in_ext);

	  strncpy(dotlfile,infile,60);
	  strncat(dotlfile,in_ext,60);
	  strncat(dotlfile,".l",5);

      if ( file_exists(dotlfile) )
      {
          printf("  splitvia2.1 core.%s %s%s.l \n",in_ext,infile,in_ext);
		  strncpy(corefile,"core",10);
		  strncat(corefile,".",5);
		  strncat(corefile,in_ext,40);

           split_result =splitvia2_call( corefile,dotlfile );
          // split_result = 0;

          // split_result=$?

          if (( strcmp(in_ext,"scm") == 0 ) && ( split_result != 0 ))
          {
             printf("FATAL ERROR: Core relief count doesn't match non core via count\n");
             exit(93);
		  } 
   
          if ( file_exists("vxxnon.art") )
		  {
	         flag=1;
			 strncpy(vxxfile,infile,60);
			 strncat(vxxfile,in_ext,30);
			 strncat(vxxfile,"N.l",10);
             printf("  mv vxxnon.art %s  \n",vxxfile);

             cp_file("vxxnon.art",vxxfile);
			 rm_file("vxxnon.art");

          }
	  
          if ( file_exists("vxxcore.art") )
		  {
	         flag=1;
             strncpy(vxxfile,infile,60);
			 strncat(vxxfile,in_ext,30);
			 strncat(vxxfile,"C.l",10);
             printf(   "  mv vxxcore.art %s\n",vxxfile);

             cp_file("vxxcore.art",vxxfile);
			 rm_file("vxxcore.art");
          }
	  }
     else
	 {
	  fprintf(stderr,"%s NOT FOUND\n",dotlfile);
	  printf(  "%s%s.l NOT FOUND \n",infile, in_ext);
      exit(95);
	 }

} // end processing layer

//
//  sets flag to infile + in_ext + .l  exist, else exit with error code
//
void checklayer( char *infile, char *in_ext)
{
char dotlfile[200];

      printf( "checking for %s%s.l ...",infile,in_ext);

	  strncpy(dotlfile,infile,60);
	  strncat(dotlfile,in_ext,50);
	  strncat(dotlfile,".l",10);

      if ( file_exists( dotlfile ) )
	  {
         printf("                        ... Found It\n");
	     flag=1;
	  }
      else
	  {
	   fprintf(stderr,"%s%s.l NOT FOUND\n",infile,in_ext);
	   printf(  "%s%s.l NOT FOUND\n",infile,in_ext);
       exit(94);
      }


}   // end checklayer



int xvia_call( char *partnumberstr)
{

	if (WINDOWS)
	{
		strncpy(dirsep,"\\",4);
	}
	else
	{
		strncpy(dirsep,"/",4);
	}

	// printf("argc = %d \n",argc);

	  strncpy(progname,"xvia",10);

      printf("RUNNING %s%s \n",progname,revstr);

	  strncpy(controlfilestr,"control",20);
	  strncat(controlfilestr,dirsep,4);
	  strncat(controlfilestr,partnumberstr,80);
	  strncat(controlfilestr,".ctl",10);

	//  printf("controlfilestr=%s\n",controlfilestr);

      if ( ! file_exists(controlfilestr))
	  {
	   fprintf(stderr,"FATAL ERROR ");
	   fprintf(stderr,"control/%s.ctl is MISSING\n",partnumberstr);
       return(99);
      }

      strncpy(aptfilestr,"aper",20);
	  strncat(aptfilestr,dirsep,4);
	  strncat(aptfilestr,partnumberstr,80);
	  strncat(aptfilestr,".apt",10);

      if ( ! file_exists(aptfilestr))
      {
	    fprintf(stderr,"FATAL ERROR ");
	    fprintf(stderr,"aper/%s.apt is MISSING\n",partnumberstr);
         return(98);
      }

      strncpy(mfgfilestr,"mfg",20);
	  strncat(mfgfilestr,dirsep,4);
	  strncat(mfgfilestr,"core",10);
	  strncat(mfgfilestr,".pan",10);

      strncpy(scmfilestr,"scm",20);
	  strncat(scmfilestr,dirsep,4);
	  strncat(scmfilestr,"core",10);
	  strncat(scmfilestr,".cen",10);

	 // printf("mfgfilestr = %s scmfilestr=%s\n",mfgfilestr,scmfilestr);

      if (( ! (file_exists(mfgfilestr)) ) || (! (file_exists(scmfilestr))  ))
      {
	   fprintf(stderr,"FATAL ERROR \n");
	   fprintf(stderr,"mfg%score.pan or scm%score.cen is MISSING\n",dirsep,dirsep);
	   return(97);
      }

      if ( ! (dir_exists("laser" ) ) ) // exist and is a directory
      {
	   fprintf(stderr,"FATAL ERROR \n");
	   fprintf(stderr,"laser directory not FOUND\n");
	   return(96 );
      }


      flag=0;
     // change_dir("laser");
    //  chmod +w *.dxf
      // rm -f *.dxf
	  rm_all_ext("laser",".dxf");

      // dos2ux ../mfg/core.pan > core.pan
      // dos2ux ../scm/core.cen > core.scm 
     // dos2ux ../aper/$1.apt  > $1.apt1
      if (WINDOWS)
	  {
		 
		  printf("About to copy mfg\\core.pan \n");

		  cp_file("mfg\\core.pan","laser\\core.pan");
		  
          printf("Copied copy mfg\\core.pan \n");

          cp_file("scm\\core.cen","laser\\core.scm");
		  strncpy(aptfilestr,"aper",10);
		  strncat(aptfilestr,dirsep,4);
		  strncat(aptfilestr,partnumberstr,80);
		  strncat(aptfilestr,".apt",8);

          strncpy(apt1filestr,"laser",10);
	      strncat(apt1filestr,dirsep,4);
	      strncat(apt1filestr,partnumberstr,80);
	       strncat(apt1filestr,".apt1",6);
		   // printf("copy from %s to %s \n",aptfilestr,apt1filestr);

		  cp_file(aptfilestr,apt1filestr);
	  }
	  else
	  {
          cp_dostou_file("mfg/core.pan","laser/core.pan");
		  cp_dostou_file("scm/core.cen","laser/core.scm");
		  strncpy(aptfilestr,"aper",10);
		  strncat(aptfilestr,dirsep,4);
		  strncat(aptfilestr,partnumberstr,80);
		  strncat(aptfilestr,".apt",8);

          strncpy(apt1filestr,"laser",10);
	      strncat(apt1filestr,dirsep,4);
	      strncat(apt1filestr,partnumberstr,80);
	       strncat(apt1filestr,".apt1",6);
		  cp_dostou_file(aptfilestr,apt1filestr);
	  }

      // delete old laser/.apt file if it exists

	  strncpy(aptfilestr,"laser",15);
	  strncat(aptfilestr,dirsep,4);
	  strncat(aptfilestr,partnumberstr,60);
	  strncat(aptfilestr,".apt",8);

      if (  file_exists( aptfilestr )  )
	  {
	  // chmod +w $1.apt
	    rm_file(aptfilestr); 
	  }

	  strncpy(apt1filestr,"laser",10);
	  strncat(apt1filestr,dirsep,4);
	  strncat(apt1filestr,partnumberstr,80);
	  strncat(apt1filestr,".apt1",6);

	  file1=fopen(apt1filestr,"r");

	  if (file1 == NULL)
	  {
		  printf("FATAL ERROR:  Could not open the laser apt1 file = %s \n",apt1filestr);
		  return(97);
	  } 

	  strncpy(aptfilestr,"laser",10);
	  strncat(aptfilestr,dirsep,4);
	  strncat(aptfilestr,partnumberstr,80);
	  strncat(aptfilestr,".apt",6);

	  aptfile=fopen(aptfilestr,"w");

	  if (aptfile == NULL)
	  {
		  printf("FATAL ERROR:  Could not create the laser .apt file = %s \n",aptfilestr);
		  return(97);
	  }

      endoffile=getline(file1,thisline);
      nf=split_line(thisline);

      while(endoffile == FALSE)
	  {
		strncpy(firststr,str_array[0],120);

	    if(strcmp(firststr,"FLASH") == 0 )
		{
			fprintf(aptfile, "FLASH  tff" ); //  >> $1.apt ;
		}
	    if (strcmp(firststr,"PEND")== 0 )
		{
		  fprintf(aptfile,"PEND 1");    // >> $1.apt;;
		}
		if ((strcmp(firststr,"PEND") != 0 ) && 
			(strcmp(firststr,"FLASH") != 0 ))
		{
	          fprintf(aptfile, "%s",thisline); // >> $1.apt;
		}
        
		endoffile=getline(file1,thisline);
		nf=split_line(thisline);

      }        // < $1.apt1
     
	  fclose(aptfile);
	  fclose(file1);

	  strncpy(apt1filestr,"laser",10);
	  strncat(apt1filestr,dirsep,5);
	  strncat(apt1filestr,partnumberstr,60);
	  strncat(apt1filestr,".apt1",10);

      rm_file(apt1filestr);

     // split the vias for BURIED and THRU layers
     change_dir("laser");

	  strncpy(file1str,"..",10);
	  strncat(file1str,dirsep,10);
      strncat(file1str,"control",10);
	  strncat(file1str,dirsep,5);      // laser/$1.ctl
	  strncat(file1str,partnumberstr,80);
	  strncat(file1str,".ctl",10);

   //  while read name myfile type mfg photo layer mask pcmname

	 // printf("file1str = %s \n", file1str);
 
	 file1 = fopen(file1str,"r");
	 if (file1 == NULL)
	 {
		 printf("FATAL ERROR: Unable to open the laser .ctl file = %s \n", file1str);
		 return(96);
	 }

     endoffile = getline(file1,thisline);
	 nf=split_line(thisline);

	 // change_dir("laser");

     while(endoffile == FALSE)
	 {
		 strncpy(name_str,str_array[0],60);
		 strncpy(myfile_str,str_array[1],60);
         strncpy(type_str,str_array[2],60);
         strncpy(mfg_str,str_array[3],60);
         strncpy(photo_str,str_array[4],60);
         strncpy(layer_str,str_array[5],60);
         strncpy(maskrev_str,str_array[6],60);
		 strncpy(pcmlayer_str,str_array[7],60);

         strncpy(fname,myfile_str,60);   // =${myfile%.*}
		 
		 for(kk=0; kk < (signed int) strlen(fname); kk += 1)
		 {
			 if (fname[kk] == '.')
			 {
				 fname[kk] = 0;
			 }
		 }
		 if( strcmp( type_str,"BLINDOUT2") == 0)
		 {
			 checklayer(fname,"scm");
		 }
		 if(( strcmp( type_str,"BLINDIN") == 0) ||
            ( strcmp( type_str,"BLINDOUT") == 0) ||
            ( strcmp( type_str,"BLINDOUT2") == 0) )
		 {
			 checklayer(fname,"scm");
             checklayer(fname,"pan");
		     checklayer(fname,"scm");
		 }
         if( strcmp( type_str,"BURIED") == 0)
		 {

		       processlayer(fname,"pan");
		       processlayer(fname,"scm");
		     //  rm -f $fname"pan.l" $fname"scm.l" ;
              strncpy(fnamestr,fname,120);
			  strncat(fnamestr,"pan.l",10);

			  strncpy(fnamestr,fname,120);
			  strncat(fnamestr,"scm.l",10);
		      rm_file(fnamestr);
		 }
	     if (strcmp( type_str,"THRU") == 0 )
		 {
		      processlayer(fname,"pan");
		      processlayer(fname,"scm");
			  strncpy(fnamestr,fname,120);
			  strncat(fnamestr,"pan.l",10);

			  strncpy(fnamestr,fname,120);
			  strncat(fnamestr,"scm.l",10);
		      rm_file(fnamestr);
		 }

      endoffile = getline(file1,thisline);
	  nf=split_line(thisline);
 
	 }                // < ../control/$1.ctl
//
     fclose(file1);
     

     //perform conversion
     //if flag is a 1 then a .l file has been found and processed
     //correctly
	 
// get all the .l files in the laser subdir here

	 getwd(pwd_str);

	 lfile_count =scandir_matchext(".",0,".l");    // not recursive

	 printf("lfile_count = %d flag=%d\n",lfile_count,flag);

     if ( flag == 1)
     {
	   i=0;
       while( i < lfile_count)         // in *.l
	   {split(scan_array[i],basestr,extstr,".");

		   strncpy(jobfilestr,pwd_str,120);
		   strncat(jobfilestr,dirsep,10);
		   strncat(jobfilestr,basestr,60);
		   strncat(jobfilestr,".job",10);

		   jfile=fopen(jobfilestr,"w");
		   if (jfile == NULL)
		   {
			   printf("Unable to open the job file = %s.job \n",scan_array[i]);
			   return(-1);
		   }
      
		   cv_toupper(basestr,basestrup);

		   fprintf(jfile,"[General] \n");
		   fprintf(jfile,"layers= layer%d \n",i+1);
		   fprintf(jfile,"aptfile=%s%s%s.apt \n",pwd_str,dirsep,partnumberstr);
		   fprintf(jfile,"dxffile=%s%s%s.dxf\n",pwd_str,dirsep,basestr);
		   fprintf(jfile,"\n");
		   fprintf(jfile,"[layer%d] \n",i+1);
		   fprintf(jfile,"layer=%s,%s%s%s.l\n",basestrup,pwd_str,dirsep,basestr);
		   fprintf(jfile,"dfxcolor=%d \n",i+1);
		   fprintf(jfile,"\n");
		   fclose(jfile);

           // printf("RUNNING: gbr2gdxd %s.m -cfg:%s.apt -s:M  \n",basestr, infilestr);
		   strncpy(aptfilestr,"\"",10);
		   strncat(aptfilestr,"-cfg:",10);
		   strncat(aptfilestr,pwd_str,120);
		   strncat(aptfilestr,dirsep,10);
		   strncat(aptfilestr,partnumberstr,120);
		   strncat(aptfilestr,".apt",10);
		   strncat(aptfilestr,"\"",10);


		   strncpy(doutfilestr,"\"",10);
		   strncat(doutfilestr,"-out:",10);
		   strncat(doutfilestr,pwd_str,120);
		   strncat(doutfilestr,dirsep,10);
		   strncat(doutfilestr,basestr,120);
		   strncat(doutfilestr,".dxf",10);
		   strncat(doutfilestr,"\"",10);

		   strncpy(jobfilestr,"\"",10);
           strncat(jobfilestr,pwd_str,120);
		   strncat(jobfilestr,dirsep,10);
		   strncat(jobfilestr,basestr,60);
		   strncat(jobfilestr,".job",10);
		   strncat(jobfilestr,"\"",10);

		   strncpy(execfilestr,"C:",10);
		   strncat(execfilestr,dirsep,10);
		   strncat(execfilestr,"WCAD",10);
		   strncat(execfilestr,dirsep,10);
		   strncat(execfilestr,"Asm500",20);
		   strncat(execfilestr,dirsep,10);
		   strncat(execfilestr,"gbr2gdxd.exe",20);

          printf("RUNNING: %s  %s %s -f %s -s:M  \n",execfilestr,
			  aptfilestr,doutfilestr, jobfilestr);

		   strncpy(commandstr,execfilestr,120);
		   strncat(commandstr," ",10);
		   strncat(commandstr,aptfilestr,120);
		   strncat(commandstr," ",4);
		   strncat(commandstr,doutfilestr,120);
		   strncat(commandstr," -f ",10);
		   strncat(commandstr,jobfilestr,120);

           system( commandstr);

		 i +=1;
	   }
     }

	 change_dir("..");  // go back one level

     //clean up
     //rm -f *.err core.* *.apt*  // *.l
	 rm_all_ext("laser",".err");
	 rm_all_ext("laser",".apt");
	 rm_all_ext("laser",".apt1");

	 if (WINDOWS)
	 {
	 rm_file("laser\\core.pan");
     rm_file("laser\\core.scm");
	 }
	 else
	 {
		 rm_file("laser/core.pan");
		 rm_file("laser/core.scm");
	 }
     return(0);
  
}  // end main


int main( int argc, char **argv)
{
int retcode;

   strncpy(usage_str,"usage: xvia partnum ",60);
   strncpy(example_str,"    ex:  xvia 96009",60);
   strncpy(revstr,"2.4",10);
  

  // mypath=$PWD    we move around a little so,lets keep the current directory

  if (argc != 2)
  {
   printf("incorrect number of arguments\n");
   printf("%s \n %s\n",usage_str,example_str);
   return(-1);
  }
  else
  {
	  retcode=xvia_call( argv[1]);
	  exit(retcode);
  }


}  // end main
